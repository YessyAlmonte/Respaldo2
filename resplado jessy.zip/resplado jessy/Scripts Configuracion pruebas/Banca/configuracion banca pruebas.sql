--601805 nivelado 2020-11-30
--714196 decreciente 2021-10-03 
--845047
--795149
declare @numero int=187872


--827472
--316851

--consultamos socios conn ptmos revolvente
--select dias_vencidos,saldo_actual,e.numero,cast(HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(e.num_ptmo,10,numero,4,1) as date)--,COUNT(1) 
--from HAPE..VW_REVOLVENTE_LINEAS e
--join BANCA..tbl_banca_socios s on e.Numero=BANCA.dbo.FN_BANCA_DESCIFRAR(s.numero_socio)
--LEFT join BANCA.DBO.TBL_BANCA_DOMICILIACIONES d on e.Numero=BANCA.DBO.FN_BANCA_DESCIFRAR(d.numero_socio)
--where Saldo_Actual>0 
--AND D.numero_socio IS NULL
--and dias_vencidos>0

--select dias_vencidos,saldo_actual,e.numero,cast(HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(e.num_ptmo,10,numero,4,1) as date)--,COUNT(1) 
--from HAPE..EDO_DE_CUENTA e
--join BANCA..tbl_banca_socios s on e.Numero=BANCA.dbo.FN_BANCA_DESCIFRAR(s.numero_socio)
--where Saldo_Actual>0 
--AND e.Id_mov<10 and Saldo_Actual>0 and coalesce(interes_ordinario_diferido,0)>0


----consultamos socios con ptmos
--select top 10 e.numero--,COUNT(1) 
--from HAPE..EDO_DE_CUENTA e
--join BANCA..tbl_banca_socios s on BANCA.dbo.FN_BANCA_DESCIFRAR(s.numero_socio)=e.Numero
--LEFT join BANCA.DBO.TBL_BANCA_DOMICILIACIONES d on e.Numero=BANCA.DBO.FN_BANCA_DESCIFRAR(d.numero_socio)
--where E.Id_mov<10 and Saldo_Actual>0 
--and saldo_adelanto>0  
--and Id_Esquema=2 
--AND D.numero_socio IS NULL
--and e.Dias_Vencidos=0 
--and e.saldo_actual<50000
--and coalesce(meses_periodo_gracia,0)>0 
--and coalesce(interes_ordinario_diferido,0)>0
--and day(fecha_ptmo)=30
--and cast(HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(e.num_ptmo,e.id_mov,numero,Id_Esquema,1) as date)='20201130' 
--group by e.numero
--having count(1)>1


--select e.Id_mov,e.numero,cast(HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(E.num_ptmo,E.id_mov,numero,Id_Esquema,1) as date)
--from HAPE..EDO_DE_CUENTA e
--join BANCA..tbl_banca_socios s on e.Numero=BANCA.dbo.FN_BANCA_DESCIFRAR(s.numero_socio)
--left join BANCA.DBO.TBL_BANCA_DOMICILIACIONES d on e.Numero=BANCA.DBO.FN_BANCA_DESCIFRAR(d.numero_socio)
--where E.Id_mov<10 and Saldo_Actual>0  --and Id_Esquema=1 --and cast(HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(num_ptmo,id_mov,numero,Id_Esquema,1) as date)>=CAST(getdate() AS date)
--and Dias_Vencidos=0 --AND D.numero_socio IS NULL and s.id_Estatus_banca=8 --and id_amortizacion>1
--order by cast(HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(E.num_ptmo,E.id_mov,numero,Id_Esquema,1) as date)

--socios con ahorro comprometido
--select Ahorro_Base,e.numero
--from HAPE..EDO_DE_CUENTA e
--join BANCA..tbl_banca_socios s on e.Numero=BANCA.DBO.FN_BANCA_DESCIFRAR(s.numero_socio)
--where ID_MOV IN (1, 2, 3, 5, 7, 8, 9) AND ROUND(SALDO_ACTUAL, 2) > 0
--and Ahorro_Base>0

--select Ahorro_Base,e.saldo_actual,e.numero
--from HAPE..EDO_DE_CUENTA e
--join BANCA..tbl_banca_socios s on e.Numero=BANCA.DBO.FN_BANCA_DESCIFRAR(s.numero_socio)
--WHERE (ID_MOV = 6 AND (PLANX='N' OR PLANX='R')) AND ROUND(SALDO_ACTUAL, 2) > 0

--select meses_periodo_gracia,inicio_periodo_gracia,fin_periodo_gracia,Saldo_Actual,saldo_adelanto,Ahorro_Base,Id_mov,
--Id_Esquema,Ultimo_Abono,Num_ptmo,Dias_Vencidos,cast(HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(num_ptmo,id_mov,numero,Id_Esquema,1) as date),
--id_Amortizacion,Fecha_Ptmo 
--from HAPE..EDO_DE_CUENTA where Numero=@numero and Id_mov<10 and Saldo_Actual>0

--select * from hape..edo_de_cuenta where numero=@numero and id_mov=100

--SELECT * FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS where numero=@numero

--update HAPE..EDO_DE_CUENTA set Saldo_Actual=50000 where Numero=@numero and Id_mov=100

---
UPDATE hape..TBL_CONTRATOS_HABERES SET id_tipo_notificacion=3 WHERE id_tipo_contrato=3 AND numero=@numero

--cambiamos correo y telefono
UPDATE HAPE..PERSONA set Tel_Celular='4431155160',Mail='yessyalmonte@gmail.com' 
WHERE Numero=@numero and Id_Tipo_Persona=1

--Cambiar contrase�as para QA (12345678)
update [BANCA]..TBL_BANCA_SOCIOS set contrasena_temp='FA2A2E2BC761751A9D777FD9912929CB',id_motivo_bloqueo=1 where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero
update [BANCA]..TBL_BANCA_SOCIOS set contrasena='FA2A2E2BC761751A9D777FD9912929CB',id_motivo_bloqueo=1 where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero



--select object_name(id) from sys.syscomments where text like '%saldo_adelanto%'

--update A set ruta_imagen=B.ruta_imagen from [dbo].[CAT_BANCA_IMAGENES_ANTIPHISHING] A
--join [dbo].[CAT_BANCA_IMAGENES_ANTIPHISHING_RESPALDO] B on A.id_imagen_antiphishing=B.id_imagen_antiphishing 


