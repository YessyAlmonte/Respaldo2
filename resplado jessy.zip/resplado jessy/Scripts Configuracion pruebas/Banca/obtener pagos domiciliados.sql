--exec SP_BANCA_OBTENER_PAGOS_DOMICILIADOS @fecha='2020-12-12 00:00:00',@id_tipo_domiciliacion=1,@pendiente=1
--EXEC SP_BANCA_OBTENER_PAGOS_DOMICILIADOS '2020-12-12 00:00:00',1,@pendiente=0
--EXEC SP_BANCA_OBTENER_PAGOS_DOMICILIADOS '2020-12-12 00:00:00',3,@pendiente=0

		USE[BANCA]
		--*************************** SERVICIOS DOMICILIADOS *************************************************

		select BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) numero_socio,d.id_domiciliacion,d.clabe_corresponsalias_retiro,d.monto monto_maximo,d.id_tipo_domiciliacion
		,d.id_servicio,d.id_producto,d.alias,p.tipo_front,d.numero_referencia,d.telefono,p.comision_cmv,cast(p.precio as money) precio
		,'' num_ptmo,0 id_mov,0 monto,p.activo,cast(0 as bit) por_monto_requerido,d.clabe_corresponsalias_deposito,
		cast(1 as bit) requiere_pago_completo,c.id_mov id_mov_cuenta_retiro,
		d.por_dia_especifico_de_pago,d.dia_pago,por_periodicidad,fecha_ultimo_pago,d.fecha_alta,
		d.indefinido,d.con_vigencia,d.fecha_vencimiento,d.por_dia_limite_de_pago,0 id_esquema,id_periodicidad_pago
		INTO #DOMIILIACIONES 
		from TBL_BANCA_DOMICILIACIONES  d
		join CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO p on d.id_producto=p.id_producto and d.id_servicio=p.id_servicios_pago
		join HAPE..TBL_CORRESPONSALIAS_CUENTAS c on banca.dbo.FN_BANCA_DESCIFRAR(d.numero_socio)=c.numero and d.clabe_corresponsalias_retiro=c.cuenta
		where d.activo=1 and d.id_tipo_domiciliacion=3 --and (cast(fecha_ultimo_pago as date) is null or cast(fecha_ultimo_pago as date)<>cast(@fecha as date))
		

		--************************ PREST�MOS DOMICILIADOS ********************************
		union 

		select BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) numero_socio,d.id_domiciliacion,d.clabe_corresponsalias_retiro,0 monto_maximo,d.id_tipo_domiciliacion
		,0 id_servicio,0 id_producto,d.alias,0 tipo_front,'' numero_referencia,'' telefono,0 comision_cmv,0 precio
		,d.num_ptmo num_ptmo,d.id_mov id_mov,monto,cast(1 as bit) activo,por_monto_requerido,d.clabe_corresponsalias_deposito   
		,case when p.Id_Esquema=1 then cast(0 as bit) else  cast(1 as bit) end requiere_pago_completo,c.id_mov id_mov_cuenta_retiro,
		d.por_dia_especifico_de_pago,d.dia_pago,por_periodicidad,fecha_ultimo_pago,d.fecha_alta,
		d.indefinido,d.con_vigencia,d.fecha_vencimiento,d.por_dia_limite_de_pago,p.id_esquema,id_periodicidad_pago  
		from TBL_BANCA_DOMICILIACIONES  d
		join HAPE..TBL_CORRESPONSALIAS_CUENTAS c on banca.dbo.FN_BANCA_DESCIFRAR(d.numero_socio)=c.numero and d.clabe_corresponsalias_retiro=c.cuenta
		join HAPE..EDO_DE_CUENTA p on banca.dbo.FN_BANCA_DESCIFRAR(numero_socio)=p.Numero and d.num_ptmo=p.Num_ptmo and p.Saldo_Actual>0
		where d.activo=1 and id_tipo_domiciliacion=1
		--and (cast(fecha_ultimo_pago as date) is null or cast(fecha_ultimo_pago as date)<>cast(@fecha as date))
		and id_tipo_domiciliacion=1

		union

		select BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) numero_socio,d.id_domiciliacion,d.clabe_corresponsalias_retiro,0 monto_maximo,d.id_tipo_domiciliacion
		,0 id_servicio,0 id_producto,d.alias,0 tipo_front,'' numero_referencia,'' telefono,0 comision_cmv,0 precio
		,d.num_ptmo num_ptmo,d.id_mov id_mov,monto,cast(1 as bit) activo,por_monto_requerido,d.clabe_corresponsalias_deposito   
		,cast(1 as bit) requiere_pago_completo,c.id_mov id_mov_cuenta_retiro,
		d.por_dia_especifico_de_pago,d.dia_pago,por_periodicidad,fecha_ultimo_pago,d.fecha_alta,
		d.indefinido,d.con_vigencia,d.fecha_vencimiento,d.por_dia_limite_de_pago,4 id_esquema,id_periodicidad_pago  
		from TBL_BANCA_DOMICILIACIONES  d
		join HAPE..TBL_CORRESPONSALIAS_CUENTAS c on banca.dbo.FN_BANCA_DESCIFRAR(d.numero_socio)=c.numero and d.clabe_corresponsalias_retiro=c.cuenta
		join hape..TBL_REVOLVENTE_LINEAS_CREDITO r on banca.dbo.FN_BANCA_DESCIFRAR(numero_socio)=r.numero and d.num_ptmo=r.num_ptmo and r.saldo_actual>0	
		where d.activo=1 and id_tipo_domiciliacion=1
		--and (cast(fecha_ultimo_pago as date) is null or cast(fecha_ultimo_pago as date)<>cast(@fecha as date))
		and id_tipo_domiciliacion=1

		select id_tipo_domiciliacion,case when por_dia_especifico_de_pago=1 then CASE WHEN dia_pago>DAY(EOMONTH(GETDATE())) AND day(GETDATE())=DAY(EOMONTH(GETDATE())) then DAY(GETDATE()) else dia_pago end else 0 end por_dia_especifico_de_pago,
		case when por_periodicidad=1 then (case when id_periodicidad_pago=1 then  CAST(DATEADD(DAY,1,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
											when id_periodicidad_pago=2 then  CAST(DATEADD(DAY,15,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
											when id_periodicidad_pago=3 then  CAST(DATEADD(month,1,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
											when id_periodicidad_pago=4 then  CAST(DATEADD(month,2,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
											when id_periodicidad_pago=5 then  CAST(DATEADD(month,3,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
											when id_periodicidad_pago=6 then  CAST(DATEADD(month,6,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
											when id_periodicidad_pago=7 then  CAST(DATEADD(year,1,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
										end) else cast('19000101' as date) end por_periodicidad,
		case when por_dia_limite_de_pago=1 then cast(HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(num_ptmo,id_mov,numero_socio,Id_Esquema,1) as date) else cast('19000101' as date) end por_dia_limite_de_pago,* 
		from #DOMIILIACIONES
		
		drop table #DOMIILIACIONES

		