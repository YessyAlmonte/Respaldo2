
--Pantalla Login
exec SP_BANCA_OBTENER_IMAGENES @idTipoImagen=1 --ObtenerFondoPantalla
exec SP_BANCA_OBTENER_VALOR_CONFIGURACION @llave=N'Aviso de privacidad' --ObtenerAvisoPrivacidad
exec SP_BANCA_OBTENER_VALOR_CONFIGURACION @llave=N'Terminos y condiciones' --ObtenerTerminosCondiciones
exec SP_BANCA_OBTENER_CONFIGURACION_AYUDA --ObtenerAyuda


--Inicio
exec SP_BANCA_OBTENER_LIMITES_TRANSFERENCIAS --ObtenerLimitesTransferencias
exec SP_BANCA_OBTENER_VALOR_CONFIGURACION @llave=N'Aviso de privacidad' --ObtenerAvisoPrivacidad
exec SP_BANCA_OBTENER_VALOR_CONFIGURACION @llave=N'Terminos y condiciones' --ObtenerTerminosCondiciones
exec SP_BANCA_OBTENER_CONFIGURACION_AYUDA --ObtenerAyuda
exec SP_BANCA_OBTENER_VALOR_CONFIGURACION @llave=N'Aviso de privacidad' --ObtenerAvisoPrivacidad
exec SP_BANCA_OBTENER_VALOR_CONFIGURACION @llave=N'Terminos y condiciones' --ObtenerTerminosCondiciones
exec SP_BANCA_OBTENER_CONFIGURACION_AYUDA --ObtenerAyuda
exec SP_BANCA_OBTENER_CUENTAS @NUMERO=N'720209',@tipo_cuenta=0 --ObtenerCuentas
exec SP_BANCA_OBTENER_EDO_DE_CUENTA @numero=N'720209',@tipoEstadoCuenta=2 --ObtenerEstadosDeCuenta
exec SP_BANCA_OBTENER_IMAGENES @idTipoImagen=5,@numeroSocio=N'720209' --ObtenerPublicidadDirigida
exec SP_BANCA_OBTENER_CUENTAS @NUMERO=N'720209',@tipo_cuenta=0 --ObtenerCuentas
exec SP_BANCA_OBTENER_EDO_DE_CUENTA @numero=N'720209',@tipoEstadoCuenta=1 --ObtenerEstadosDeCuenta

---------------------------------------------------------------------------------------------------
--                               TRANSFERENCIAS
---------------------------------------------------------------------------------------------------
--Cuentas propias
exec SP_BANCA_OBTENER_CUENTAS_RETIRO @NUMERO=N'720209'
exec hape.dbo.SP_REVOLVENTE_CONSULTA_SOCIO @numero=N'720209',@id_tipo_persona=1,@fecha=N'20200914'
exec SP_BANCA_OBTENER_CUENTAS_RETIRO @NUMERO=N'720209'
exec SP_BANCA_OBTENER_CUENTAS @NUMERO=N'720209',@tipo_cuenta=0
exec SP_BANCA_OBTENER_CUENTAS @NUMERO=N'720209',@tipo_cuenta=0

--Entre otros socios
exec SP_BANCA_OBTENER_CUENTAS_RETIRO @NUMERO=N'720209'
exec SP_BANCA_OBTENER_CUENTAS @NUMERO=N'720209',@tipo_cuenta=0
exec SP_BANCA_OBTENER_CUENTAS_DEPOSITO_INTERNA @NUMERO=N'720209',@tipo_cuenta_deposito_interna=1

--Otros bancos
exec SP_BANCA_OBTENER_CUENTAS_DEPOSITO_EXTERNAS @NUMERO=N'720209',@TipoCuentaDepositoExterna=1
exec SP_BANCA_OBTENER_CUENTAS_RETIRO @NUMERO=N'720209'
exec SP_BANCA_OBTENER_CUENTAS @NUMERO=N'720209',@tipo_cuenta=0
