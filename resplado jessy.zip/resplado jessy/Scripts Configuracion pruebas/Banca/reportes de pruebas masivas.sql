USE[BANCA]

declare @fecha date='20210126'

select  A.id_bitacora,
        a.numero_socio as [Numero Socio],      
        --b.descripcion as [Evento],
		coalesce(tipo_transferencia.TIPO,b.descripcion) [Evento],
        a.fecha_alta as [Fecha Movimiento],
        --a.id_origen_operacion,
        --c.descripcion as [Movimiento Efectuado],
        case when a.id_origen_operacion in (1,4) then 'Portal Movil'     
        when a.id_origen_operacion in (3) then 'Portal Web'
        when a.id_origen_operacion=7 then 'SPEI'
        when a.id_origen_operacion=2 then 'Sucursal'		
		else c.descripcion
        END [Origen Operacion],
		coalesce(tipo_transferencia.descripcion,'N/A') [Estatus Transferencia],
		coalesce(CONVERT(VARCHAR(10), fecha_alta_transferencia, 103) + ' '  + convert(VARCHAR(8), fecha_alta_transferencia, 14),'N/A') [Fecha alta transferencia],
		coalesce(CONVERT(VARCHAR(10), fecha_transferencia_realizada, 103) + ' '  + convert(VARCHAR(8), fecha_transferencia_realizada, 14),'N/A') [Fecha transferencia realizada],		
		coalesce(DATEDIFF(SECOND,fecha_alta_transferencia,fecha_transferencia_realizada),0) [Duracion Segundos],
		null seconds,
		null total_movs
		INTO #MOVIMIENTOS_CMVFINANZAS
from
            TBL_BANCA_BITACORA_OPERACIONES a
join    cat_banca_tipos_bitacora b    on    a.id_tipo_bitacora=b.id_tipo_bitacora
join    CAT_BANCA_ORIGEN_OPERACION c    on    a.id_origen_operacion=c.id_origen_operacion
left join (

select id_banca_folio,'SPEI enviado' TIPO,B.id_estatus_transferencia,B.descripcion,
fecha_alta_transferencia,fecha_transferencia_realizada
from TBL_BANCA_TRANSFERENCIAS_EXTERNAS A
JOIN CAT_BANCA_ESTATUS_TRANSFERENCIAS B ON A.id_estatus_transferencia=B.id_estatus_transferencia

UNION

select id_banca_folio,'SPEI recibido' TIPO,B.id_estatus_transferencia,B.descripcion,
fecha_transferencia_realizada,fecha_transferencia_realizada
from TBL_BANCA_TRANSFERENCIAS_EXTERNAS_RECIBIDAS A
JOIN CAT_BANCA_ESTATUS_TRANSFERENCIAS B ON A.id_estatus_transferencia=B.id_estatus_transferencia

UNION

select id_banca_folio,'Transferencia interna' TIPO,B.id_estatus_transferencia,B.descripcion,
fecha_alta_transferencia,fecha_transferencia_realizada 
from TBL_BANCA_TRANSFERENCIAS_INTERNAS A
JOIN CAT_BANCA_ESTATUS_TRANSFERENCIAS B ON A.id_estatus_transferencia=B.id_estatus_transferencia

UNION

select id_banca_folio,'Pago de servicio' TIPO,B.id_estatus_transferencia,B.descripcion,
fecha_alta_pago,fecha_pago_realizado
from TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS A
JOIN CAT_BANCA_ESTATUS_TRANSFERENCIAS B ON A.id_estatus_transferencia=B.id_estatus_transferencia
) tipo_transferencia on a.id_banca_folio=tipo_transferencia.id_banca_folio

join (select coalesce(id_banca_folio,0) id_banca_folio,numero_socio,--,MIN(fecha_alta) fecha_alta,
MIN(id_bitacora) id_bitacora
from  TBL_BANCA_BITACORA_OPERACIONES a group by coalesce(id_banca_folio,0),numero_socio) bitacora 
	on a.numero_socio=bitacora.numero_socio and coalesce(a.id_banca_folio,0)=coalesce(bitacora.id_banca_folio,0) 
	--and a.fecha_alta=case when bitacora.id_banca_folio=0 then a.fecha_alta else bitacora.fecha_alta end
	and a.id_bitacora=case when bitacora.id_banca_folio=0 then a.id_bitacora else bitacora.id_bitacora end 
where cast(a.fecha_alta as date)=cast(@fecha as date)
--and (LEFT(CONVERT(TIME,a.fecha_alta,108),8) >='08:30:00' and LEFT(CONVERT(TIME,a.fecha_alta,108),8) <='09:00:59')
order by id_bitacora

--SELECT * FROM #MOVIMIENTOS_CMVFINANZAS order by [Fecha Movimiento]

declare @id_bitacora_actual int,@id_bitacora_ant int=0,@total_mov int
declare @fecha_mov_actual datetime,@fecha_mov_ant datetime,@diferencia int

while exists(SELECT * FROM #MOVIMIENTOS_CMVFINANZAS where seconds is null)
begin
  
  select @id_bitacora_actual=min(id_bitacora) from #MOVIMIENTOS_CMVFINANZAS where seconds is null
  
  select @fecha_mov_actual=[Fecha Movimiento] from #MOVIMIENTOS_CMVFINANZAS where id_bitacora=@id_bitacora_actual
  select @fecha_mov_ant=[Fecha Movimiento] from #MOVIMIENTOS_CMVFINANZAS where id_bitacora=@id_bitacora_ant
  select @fecha_mov_ant=coalesce(@fecha_mov_ant,@fecha_mov_actual)

  select @diferencia=coalesce(DATEDIFF(SECOND,@fecha_mov_ant,@fecha_mov_actual),0)

  UPDATE #MOVIMIENTOS_CMVFINANZAS SET seconds=@diferencia WHERE id_bitacora=@id_bitacora_actual

	  if(@diferencia<=10) and @id_bitacora_ant>0
	  begin
		 select @total_mov=coalesce(@total_mov,0) + 1
	  end
	  else 
	  begin    
	      if(@total_mov>0)
		     select @total_mov=coalesce(@total_mov,0) + 1
		UPDATE #MOVIMIENTOS_CMVFINANZAS SET total_movs=coalesce(@total_mov,0)  WHERE id_bitacora=@id_bitacora_ant
		select @total_mov=0
	  end


  select @id_bitacora_ant=@id_bitacora_actual
   

end

SELECT * FROM #MOVIMIENTOS_CMVFINANZAS

--109845
--select * from [dbo].[TBL_BANCA_FOLIOS] where Numero_Socio=720209

select COUNT(1) total_socios_utilizaron_cmvFinanzas
from
(select
        [Numero Socio]
from    #MOVIMIENTOS_CMVFINANZAS
group by [Numero Socio]) a

drop table #MOVIMIENTOS_CMVFINANZAS






