USE[HAPE]

--91
INSERT INTO TBL_CORRESPONSALIAS_CUENTAS(NUMERO,CUENTA,FECHA_ALTA,ID_MOV,NUM_PTMO,ACTIVO,id_tipo_bloqueo_tarjeta)
select e.Numero,('797001112' +(RIGHT('0000000' + Ltrim(Rtrim(e.Numero)),7))),GETDATE(),e.Id_mov,null num_ptmo,coalesce(s.SERVICIO_ACTIVO,cast(0 as bit)) activo,null id_tipo_bloqueo_tarjeta 
from EDO_DE_CUENTA e
left join TBL_CORRESPONSALIAS_SERVICIOS s on e.Numero=s.NUMERO and s.SERVICIO_ACTIVO=1 and s.ID_ESTATUS_ACTIVACION=2
left join TBL_CORRESPONSALIAS_CUENTAS c on e.Numero=c.NUMERO and e.Id_mov=c.ID_MOV
where e.Id_mov=112 and e.Tarjeta_activa='T' and c.CUENTA is null and e.Id_Tipo_persona=1 
group by e.Numero,e.Id_mov,s.SERVICIO_ACTIVO

--983
INSERT INTO TBL_CORRESPONSALIAS_CUENTAS(NUMERO,CUENTA,FECHA_ALTA,ID_MOV,NUM_PTMO,ACTIVO,id_tipo_bloqueo_tarjeta)
select e.Numero,('797002'+ RIGHT('000' + Ltrim(Rtrim(e.Id_mov)),3)+RIGHT('0000000' + Ltrim(Rtrim(e.Numero)),7)),GETDATE(),e.Id_mov,e.Num_ptmo,coalesce(s.SERVICIO_ACTIVO,cast(0 as bit)) activo,null id_tipo_bloqueo_tarjeta 
from EDO_DE_CUENTA e
left join TBL_CORRESPONSALIAS_SERVICIOS s on e.Numero=s.NUMERO and s.SERVICIO_ACTIVO=1 and s.ID_ESTATUS_ACTIVACION=2
left join TBL_CORRESPONSALIAS_CUENTAS c on e.Numero=c.NUMERO and e.Id_mov=c.ID_MOV and e.Num_ptmo=c.NUM_PTMO
where e.Id_mov<10 and e.Saldo_Actual>0 and c.CUENTA is null and e.Id_Tipo_persona=1
group by e.Numero,e.Id_mov,e.Num_ptmo,s.SERVICIO_ACTIVO


--73
INSERT INTO TBL_CORRESPONSALIAS_CUENTAS(NUMERO,CUENTA,FECHA_ALTA,ID_MOV,NUM_PTMO,ACTIVO,id_tipo_bloqueo_tarjeta)
select l.Numero,('797002'+ RIGHT('000' + Ltrim(Rtrim(10)),3)+RIGHT('0000000' + Ltrim(Rtrim(l.numero)),7)),GETDATE(),10 Id_mov,l.num_ptmo,coalesce(s.SERVICIO_ACTIVO,cast(0 as bit)) activo,null id_tipo_bloqueo_tarjeta 
from TBL_REVOLVENTE_LINEAS_CREDITO l
left join TBL_CORRESPONSALIAS_SERVICIOS s on l.Numero=s.NUMERO and s.SERVICIO_ACTIVO=1 and s.ID_ESTATUS_ACTIVACION=2
left join TBL_CORRESPONSALIAS_CUENTAS c on l.Numero=c.NUMERO and c.ID_MOV=10 and l.Num_ptmo=c.NUM_PTMO 
where c.CUENTA is null
group by l.Numero,l.num_ptmo,s.SERVICIO_ACTIVO

go

---Inserta cuenta clabe 
use BANCA
go

declare @NUMERO int=0

select BANCA.DBO.FN_BANCA_DESCIFRAR(b.numero_socio) numero_socio
INTO #SOCIOS_SIN_CLABE
from BANCA.dbo.TBL_BANCA_SOCIOS b
join HAPE..EDO_DE_CUENTA e on BANCA.DBO.FN_BANCA_DESCIFRAR(b.numero_socio)=e.Numero and e.Id_Tipo_persona=1 and id_mov=112 and Tarjeta_activa='T'
left join BANCA.DBO.TBL_BANCA_CUENTAS_INTERBANCARIAS i on BANCA.DBO.FN_BANCA_DESCIFRAR(B.numero_socio)=BANCA.DBO.FN_BANCA_DESCIFRAR(i.numero_socio)
WHERE id_estatus_banca not in(1,9) and i.numero_socio is null
order by BANCA.DBO.FN_BANCA_DESCIFRAR(b.numero_socio)

while ((select COUNT(1) from #SOCIOS_SIN_CLABE)>0)
begin
   
   select top 1 @NUMERO=numero_socio from #SOCIOS_SIN_CLABE order by numero_socio

   if exists(select 1 from hape..EDO_DE_CUENTA where Numero=@NUMERO and Id_mov=112 and Tarjeta_activa='T')
	begin
		--Se inserta la clabe interbancaria para su cuenta de debito
		if exists(select 1 from [BANCA].[DBO].TBL_BANCA_SOCIOS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @NUMERO AND id_estatus_banca not in(1,9) /*banca_activa =1*/)
		begin
			exec banca.dbo.SP_CMV_INSERTAR_CUENTA_INTERBANCARIA @NUMERO
		end
		else
			select 'no tiene cmv finanzas activo'
	end

	delete #SOCIOS_SIN_CLABE where numero_socio=@NUMERO

end







