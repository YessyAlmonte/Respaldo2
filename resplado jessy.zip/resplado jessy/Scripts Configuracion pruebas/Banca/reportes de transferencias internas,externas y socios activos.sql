USE[BANCA]
declare 
@fecha_ini date='20200330',
@fecha_fin date='20210304'
--@hora varchar(8)='09:30:59'

---TRANFERENCIAS SPEI ENVIADAS
select a.*
INTO #TRANSFERENCIAS_SPEI 
from TBL_BANCA_TRANSFERENCIAS_EXTERNAS a
where cast(a.fecha_transferencia_realizada as date)>=cast(@fecha_ini as date) and 
cast(a.fecha_transferencia_realizada as date)<=cast(@fecha_fin as date)
--and LEFT(CONVERT(TIME,a.fecha_transferencia_realizada,108),8) <=case when cast(a.fecha_transferencia_realizada as date)=cast(@fecha_fin as date) then @hora else LEFT(CONVERT(TIME,a.fecha_transferencia_realizada,108),8) end


SELECT 'Transferencias SPEI' tipo,@fecha_ini fecha_inicio,@fecha_fin fecha_fin,* FROM
(SELECT COUNT(1) total_transferencias_realizadas
FROM #TRANSFERENCIAS_SPEI) a
cross join
(SELECT COUNT(1) total_transferencias_exitosas
FROM #TRANSFERENCIAS_SPEI where id_estatus_transferencia=2) b
cross join
(SELECT COUNT(1) total_transferencias_rechazadas
FROM #TRANSFERENCIAS_SPEI where id_estatus_transferencia=3) c

---TRANFERENCIAS SPEI RECIBIDAS
select a.*
INTO #TRANSFERENCIAS_RECIBIDAS_SPEI 
from TBL_BANCA_TRANSFERENCIAS_EXTERNAS_RECIBIDAS a
where cast(a.fecha_transferencia_realizada as date)>=cast(@fecha_ini as date) and 
cast(a.fecha_transferencia_realizada as date)<=cast(@fecha_fin as date)
--and LEFT(CONVERT(TIME,a.fecha_transferencia_realizada,108),8) <=case when cast(a.fecha_transferencia_realizada as date)=cast(@fecha_fin as date) then @hora else LEFT(CONVERT(TIME,a.fecha_transferencia_realizada,108),8) end


SELECT 'Transferencias SPEI recibidas' tipo,@fecha_ini fecha_inicio,@fecha_fin fecha_fin,* FROM
(SELECT COUNT(1) total_transferencias_realizadas
FROM #TRANSFERENCIAS_RECIBIDAS_SPEI) a
cross join
(SELECT COUNT(1) total_transferencias_exitosas
FROM #TRANSFERENCIAS_RECIBIDAS_SPEI where id_estatus_transferencia=2) b
cross join
(SELECT COUNT(1) total_transferencias_rechazadas
FROM #TRANSFERENCIAS_RECIBIDAS_SPEI where id_estatus_transferencia=3) c



--TRANSFERENCIAS ENTRE CUENTAS PROPIAS

select *
INTO #TRANSFERENCIAS_CUENTAS_PROPIAS 
from TBL_BANCA_TRANSFERENCIAS_INTERNAS 
where cast(fecha_alta_transferencia as date)>=cast(@fecha_ini as date) and 
cast(fecha_alta_transferencia as date)<=cast(@fecha_fin as date)
--and LEFT(CONVERT(TIME,fecha_alta_transferencia,108),8) <=case when cast(fecha_alta_transferencia as date)=cast(@fecha_fin as date) then @hora else LEFT(CONVERT(TIME,fecha_alta_transferencia,108),8) end
AND CAST(substring(clave_corresponsalias_origen,10,7) as int) = CAST(substring(clave_corresponsalias_destino,10,7) as int)

SELECT 'Transferencias entre cuentas propias' tipo,@fecha_ini fecha_inicio,@fecha_fin fecha_fin,* FROM
(SELECT COUNT(1) total_transferencias_realizadas
FROM #TRANSFERENCIAS_CUENTAS_PROPIAS) a
cross join
(SELECT COUNT(1) total_transferencias_exitosas
FROM #TRANSFERENCIAS_CUENTAS_PROPIAS where id_estatus_transferencia=2) b
cross join
(SELECT COUNT(1) total_transferencias_rechazadas
FROM #TRANSFERENCIAS_CUENTAS_PROPIAS where id_estatus_transferencia=3) c

---TRANSFERENCIAS ENTRE SOCIOS

select *
INTO #TRANSFERENCIAS_ENTRE_SOCIOS
from TBL_BANCA_TRANSFERENCIAS_INTERNAS 
where cast(fecha_alta_transferencia as date)>=cast(@fecha_ini as date) and 
cast(fecha_alta_transferencia as date)<=cast(@fecha_fin as date)
--and LEFT(CONVERT(TIME,fecha_alta_transferencia,108),8) <=case when cast(fecha_alta_transferencia as date)=cast(@fecha_fin as date) then @hora else LEFT(CONVERT(TIME,fecha_alta_transferencia,108),8) end
AND CAST(substring(clave_corresponsalias_origen,10,7) as int) <> CAST(substring(clave_corresponsalias_destino,10,7) as int)

SELECT 'Transferencias entre socios' tipo,@fecha_ini fecha_inicio,@fecha_fin fecha_fin,* FROM
(SELECT COUNT(1) total_transferencias_realizadas
FROM #TRANSFERENCIAS_ENTRE_SOCIOS) a
cross join
(SELECT COUNT(1) total_transferencias_exitosas
FROM #TRANSFERENCIAS_ENTRE_SOCIOS where id_estatus_transferencia=2) b
cross join
(SELECT COUNT(1) total_transferencias_rechazadas
FROM #TRANSFERENCIAS_ENTRE_SOCIOS where id_estatus_transferencia=3) c

--PAGOS DE SERVICIOS

select *
INTO #PAGOS_SERVICIOS
from TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS 
where cast(fecha_alta_pago as date)>=cast(@fecha_ini as date) and 
cast(fecha_alta_pago as date)<=cast(@fecha_fin as date)
--and LEFT(CONVERT(TIME,fecha_alta_pago,108),8) <=case when cast(fecha_alta_pago as date)=cast(@fecha_fin as date) then @hora else LEFT(CONVERT(TIME,fecha_alta_pago,108),8) end

SELECT 'Pago de servicios' tipo,@fecha_ini fecha_inicio,@fecha_fin fecha_fin,* FROM
(SELECT COUNT(1) total_transferencias_realizadas
FROM #PAGOS_SERVICIOS where  id_estatus_transferencia in(2,3)) a
cross join
(SELECT COUNT(1) total_transferencias_exitosas
FROM #PAGOS_SERVICIOS where id_estatus_transferencia=2) b
cross join
(SELECT COUNT(1) total_transferencias_rechazadas
FROM #PAGOS_SERVICIOS where id_estatus_transferencia=3) c

--SOCIOS CON BANCA ACTIVA

select * 
INTO #SOCIOS_BANCA
from TBL_BANCA_SOCIOS
where
cast(fecha_alta_solicitud as date)>=cast(@fecha_ini as date) and 
cast(fecha_alta_solicitud as date)<=cast(@fecha_fin as date)
--and LEFT(CONVERT(TIME,fecha_alta_solicitud,108),8) <=case when cast(fecha_alta_solicitud as date)=cast(@fecha_fin as date) then @hora else LEFT(CONVERT(TIME,fecha_alta_solicitud,108),8) end
and id_estatus_banca>4

--SELECT 'Total socios banca' tipo,@fecha_ini fecha_inicio,@fecha_fin fecha_fin,* FROM
--(SELECT COUNT(1) total_socios
--FROM #SOCIOS_BANCA) a
--cross join
--(SELECT COUNT(1) total_socios_activos
--FROM #SOCIOS_BANCA where id_estatus_banca in (6,7,8) and banca_activa=1) b
--cross join
--(SELECT COUNT(1) total_socios_inactivos
--FROM #SOCIOS_BANCA where banca_activa=0) c

--SELECT 'Total socios banca' tipo,@fecha_ini fecha_inicio,@fecha_fin fecha_fin,* FROM
--(SELECT COUNT(1) total_socios
--FROM #SOCIOS_BANCA) a
--cross join
--(SELECT COUNT(1) total_socios_activos
--FROM #SOCIOS_BANCA where id_estatus_banca in (6,7,8) and banca_activa=1) b
--cross join
--(SELECT COUNT(1) total_socios_inactivos
--FROM #SOCIOS_BANCA where banca_activa=0) c


DROP TABLE #TRANSFERENCIAS_SPEI
DROP TABLE #TRANSFERENCIAS_RECIBIDAS_SPEI
DROP TABLE #TRANSFERENCIAS_CUENTAS_PROPIAS
DROP TABLE #TRANSFERENCIAS_ENTRE_SOCIOS
DROP TABLE #PAGOS_SERVICIOS
DROP TABLE #SOCIOS_BANCA

