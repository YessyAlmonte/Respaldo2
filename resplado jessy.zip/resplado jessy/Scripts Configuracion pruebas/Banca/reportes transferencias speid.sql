USE[BANCA2]

declare
 @fecha_ini date='20200424',
 @fecha_fin date='20200924',
 @hora varchar(8)='09:30:59'



select count(1) total,id_banco,(SUM(DATEDIFF(Second,fecha_alta_transferencia, fecha_transferencia_realizada)))/count(1) tiempo_promedio_respuesta 
INTO #TRANSFERENCIAS_ENVIADAS
from [dbo].[TBL_BANCA_TRANSFERENCIAS_EXTERNAS] a
join [dbo].[TBL_BANCA_CUENTAS_EXTERNAS] b on a.id_cuenta_externa=b.id_cuenta_externa
where cast(a.fecha_transferencia_realizada as date)>=@fecha_ini and cast(a.fecha_transferencia_realizada as date)<=@fecha_fin
and LEFT(CONVERT(TIME,a.fecha_transferencia_realizada,108),8) <=case when cast(a.fecha_transferencia_realizada as date)=cast(@fecha_fin as date) then @hora else LEFT(CONVERT(TIME,a.fecha_transferencia_realizada,108),8) end
group by id_banco

select count(1) total,id_banco 
INTO #TRANSFERENCIAS_REALIZADAS
from [dbo].[TBL_BANCA_TRANSFERENCIAS_EXTERNAS] a
join [dbo].[TBL_BANCA_CUENTAS_EXTERNAS] b on a.id_cuenta_externa=b.id_cuenta_externa
where id_Estatus_transferencia=2 
and cast(a.fecha_transferencia_realizada as date)>=@fecha_ini and cast(a.fecha_transferencia_realizada as date)<=@fecha_fin
and LEFT(CONVERT(TIME,a.fecha_transferencia_realizada,108),8) <=case when cast(a.fecha_transferencia_realizada as date)=cast(@fecha_fin as date) then @hora else LEFT(CONVERT(TIME,a.fecha_transferencia_realizada,108),8) end
group by id_banco

select count(1) total,id_banco 
INTO #TRANSFERENCIAS_RECHAZADAS
from [dbo].[TBL_BANCA_TRANSFERENCIAS_EXTERNAS] a
join [dbo].[TBL_BANCA_CUENTAS_EXTERNAS] b on a.id_cuenta_externa=b.id_cuenta_externa
where id_Estatus_transferencia=3
and cast(a.fecha_transferencia_realizada as date)>=@fecha_ini and cast(a.fecha_transferencia_realizada as date)<=@fecha_fin
and LEFT(CONVERT(TIME,a.fecha_transferencia_realizada,108),8) <=case when cast(a.fecha_transferencia_realizada as date)=cast(@fecha_fin as date) then @hora else LEFT(CONVERT(TIME,a.fecha_transferencia_realizada,108),8) end
group by id_banco


select b.id_banco_spei,b.institucion,coalesce(te.total,0) enviadas,coalesce(tr.total,0) realizadas,coalesce(tre.total,0) rechazas,tiempo_promedio_respuesta,
	(tiempo_promedio_respuesta % (24 * 60 * 60)) / (60 * 60) AS horas,
	((tiempo_promedio_respuesta % (24 * 60 * 60)) % (60 * 60)) / 60 AS minutos,
	((tiempo_promedio_respuesta % (24 * 60 * 60)) % (60 * 60)) % 60 AS segundos
from [dbo].[CAT_BANCA_BANCOS_CLABES_SPEI] b
JOIN #TRANSFERENCIAS_ENVIADAS te on b.id_banco_spei=te.id_banco
LEFT JOIN #TRANSFERENCIAS_REALIZADAS tr on b.id_banco_spei=tr.id_banco
LEFT JOIN #TRANSFERENCIAS_RECHAZADAS tre on b.id_banco_spei=tre.id_banco


DROP TABLE #TRANSFERENCIAS_ENVIADAS
DROP TABLE #TRANSFERENCIAS_REALIZADAS
DROP TABLE #TRANSFERENCIAS_RECHAZADAS

--select * from CAT_BANCA_BANCOS_CLABES_SPEI where clabe=37006

--enviadas
--select count(1) from [dbo].[TBL_BANCA_TRANSFERENCIAS_EXTERNAS]

--realizadas
--select count(1) from [dbo].[TBL_BANCA_TRANSFERENCIAS_EXTERNAS] 
--where id_Estatus_transferencia=2

--rechazadas
--select count(1) from [dbo].[TBL_BANCA_TRANSFERENCIAS_EXTERNAS] 
--where id_Estatus_transferencia=3

--select fecha_transferencia_realizada,fecha_alta_transferencia,
--      DATEDIFF (Day, fecha_alta_transferencia, fecha_transferencia_realizada) As Dias
--    , DATEDIFF (Hour, fecha_alta_transferencia, fecha_transferencia_realizada) % 24 As Horas
--    , DATEDIFF (Minute, fecha_alta_transferencia, fecha_transferencia_realizada) % 60 As Minutos
--    , DATEDIFF (Second, fecha_alta_transferencia, fecha_transferencia_realizada) % 60 As Segundos,
--	 DATEDIFF (Second, fecha_alta_transferencia, fecha_transferencia_realizada)  As Segundos  
--from [dbo].[TBL_BANCA_TRANSFERENCIAS_EXTERNAS] where id_Estatus_transferencia=3

--select fecha_alta_transferencia,fecha_transferencia_realizada,DATEDIFF(Second,fecha_alta_transferencia, fecha_transferencia_realizada) total_Seguntos,id_transferencia,monto 
--from [dbo].[TBL_BANCA_TRANSFERENCIAS_EXTERNAS] a
--join [dbo].[TBL_BANCA_CUENTAS_EXTERNAS] b on a.id_cuenta_externa=b.id_cuenta_externa
--where cast(a.fecha_transferencia_realizada as date)>=@fecha_ini and cast(a.fecha_transferencia_realizada as date)<=@fecha_fin
--and id_banco=7
--order by DATEDIFF(Second,fecha_alta_transferencia, fecha_transferencia_realizada) desc



--select count(1) total
--from [dbo].[TBL_BANCA_TRANSFERENCIAS_EXTERNAS] a
--join [dbo].[TBL_BANCA_CUENTAS_EXTERNAS] b on a.id_cuenta_externa=b.id_cuenta_externa
--where a.notificado_por_stp=0
--group by id_banco