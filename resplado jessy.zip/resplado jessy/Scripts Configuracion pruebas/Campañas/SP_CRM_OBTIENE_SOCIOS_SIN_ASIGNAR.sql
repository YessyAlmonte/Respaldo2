


use CRM
go

-- se crea procedimiento SP_CRM_OBTIENE_SOCIOS_SIN_ASIGNAR
if exists (select * from sysobjects where name like 'SP_CRM_OBTIENE_SOCIOS_SIN_ASIGNAR' and xtype = 'p' and db_name() = 'CRM')
	drop proc SP_CRM_OBTIENE_SOCIOS_SIN_ASIGNAR
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aaaa111111
Fecha			yyyymmdd
Objetivo		Obtener los socios que no estan asignados en una campa�a
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_CRM_OBTIENE_SOCIOS_SIN_ASIGNAR

	@id_campania int

	
as
	begin -- procedimiento
		
		select p.idPersona,per.Numero,per.Id_Tipo_Persona,
		per.Nombre_s + ' ' + isnull(per.Apellido_Paterno,'') + ' ' +isnull(per.Apellido_Materno,'') Nombre_socio,
		suc.Id_de_Sucursal,
		suc.Descripcion sucursal,
		s.num_usuario_asignado,
		clUsInicial.Nombre_s + ' ' + isnull(clUsInicial.Apellido_Paterno,'') + ' ' +isnull(clUsInicial.Apellido_Materno,'') Nombre_usuario_inicial
		from CRM..TBL_CRM_CAMPANIAS_SOCIO s
		join CRM..CRM_TBL_PERSONAS p on s.numero=p.NumeroSocio and p.IdEstadoPersona=2
		join HAPE..PERSONA per on p.NumeroSocio=per.Numero and per.Id_Tipo_Persona=1
		join HAPE..SUCURSALES suc on per.Id_de_Sucursal=suc.Id_de_Sucursal
		left join CRM..CRM_TBL_PROSPECTOS_POR_USUARIOS u on p.IdPersona=u.IdPersona
		left join HAPE..CLAVES clUsInicial on s.num_usuario_asignado=clUsInicial.Numusuario
		where fk_id_campania=@id_campania and u.NumUsuario is null
		and fk_id_estatus_socio_campania=5 
		
	end -- procedimiento
go

grant exec on SP_CRM_OBTIENE_SOCIOS_SIN_ASIGNAR to public
















