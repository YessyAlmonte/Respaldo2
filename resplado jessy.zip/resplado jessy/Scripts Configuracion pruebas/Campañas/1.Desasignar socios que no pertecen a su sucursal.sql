Use[CRM]

delete u from 
CRM..CRM_TBL_PERSONAS p
join HAPE..PERSONA per on p.NumeroSocio=per.Numero and per.Id_Tipo_Persona=1
join CRM_TBL_PROSPECTOS_POR_USUARIOS u on p.IdPersona=u.IdPersona
join HAPE..CLAVES cl on u.NumUsuario=cl.Numusuario
where IdEstadoPersona=2 and per.Id_de_Sucursal<>cl.Id_de_sucursal

select * from CRM..CRM_TBL_PERSONAS p
join HAPE..PERSONA per on p.NumeroSocio=per.Numero and per.Id_Tipo_Persona=1
join CRM_TBL_PROSPECTOS_POR_USUARIOS u on p.IdPersona=u.IdPersona
join HAPE..CLAVES cl on u.NumUsuario=cl.Numusuario
where IdEstadoPersona=2 and per.Id_de_Sucursal<>cl.Id_de_sucursal