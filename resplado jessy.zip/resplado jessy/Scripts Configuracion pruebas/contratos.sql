SELECT max(id_contrato),BANCA.DBO.FN_CMV_ELIMINAR_CARACTERES(PRODUCTO)--,LEYENDA, + '''' + leyenda  + '''' + ',' + '---' + PRODUCTO
FROM TBL_CRED_PRODUCTOS_LEYENDAS l
join cred_params_ptmo b on l.id_subproducto=b.contador
WHERE l.ACTIVO=1 and leyenda<>'' and b.activo='T'  --and requiere_hipoteca='S'
GROUP BY PRODUCTO--,LEYENDA
ORDER BY BANCA.DBO.FN_CMV_ELIMINAR_CARACTERES(PRODUCTO)

SELECT ID_CONTRATO,PRODUCTO,case when requiere_hipoteca='S' then cast(0 as bit) else cast(1 as bit) end contrato,ANEXO
FROM TBL_CRED_PRODUCTOS_LEYENDAS l
join cred_params_ptmo b on l.id_subproducto=b.contador
WHERE l.ACTIVO=1 and b.activo='T'  and leyenda<>''  
ORDER BY PRODUCTO


SELECT p.PRODUCTO, 
 STUFF(
    (   SELECT ', ' + cast(l.ID_SUBPRODUCTO as varchar)
		FROM TBL_CRED_PRODUCTOS_LEYENDAS l
		join cred_params_ptmo b on l.id_subproducto=b.contador
		WHERE l.ACTIVO=1 and b.activo='T'  and leyenda<>''
        and l.PRODUCTO = p.PRODUCTO
    FOR XML PATH('')),
    1, 2, '') As Categorias
FROM TBL_CRED_PRODUCTOS_LEYENDAS p
join cred_params_ptmo b on p.id_subproducto=b.contador
WHERE p.ACTIVO=1 and leyenda<>'' and b.activo='T'  --and requiere_hipoteca='S'
GROUP BY PRODUCTO--,LEYENDA
ORDER BY p.PRODUCTO









