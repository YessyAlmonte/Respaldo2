USE[HAPE]

SELECT  c.fecha_alta,a.meses_periodo_gracia,c.Fecha_alta,C.id_sol,
        c.Numero,
        s.ID_ESTATUS,
        d.DESCRIPCION 'ETAPA ACTUAL',
        DI.DESCRIPCION 'ETAPA SIGUIENTE',
        c.Usuario_AC 'Num Analista',
        cl.Usuario 'Usuario Analista',
        Usuario_AUT 'Num Autoriza' , 
        clj.Usuario 'Usuario Autoriza',
        c.Numusuario,
        cle.Usuario,
        cljef.Numusuario 'Num Jefe Suc',
        cljef.Usuario 'Usuario Jefe Suc',
		clcord.Numusuario 'Num Cordinador',
		clcord.Usuario 'Usuario Cordinador',
		suc.Id_de_Sucursal,
		suc.Descripcion sucursal,
		reg.Descripcion region,
		c.Tel_Celular
FROM CRED_SOLICITUD_CREDITO c
left join claves cl on c.Usuario_AC=cl.Numusuario
left join claves clj on c.usuario_aut= clj.Numusuario
left join claves cle on c.Numusuario= cle.Numusuario
left join claves clcord on c.Usuario_JS= clcord.Numusuario
left join claves cljef on c.Id_de_Sucursal=cljef.Id_de_sucursal and cljef.Usuario like 'Enc%'
left join TBL_DIG_DIGITALIZACION_SOLICITUD s on s.ID_SOLICITUD=c.id_sol 
left join CAT_DIG_DIGITALIZACION_ESTATUS d on d.ID_ESTATUS=s.ID_ESTATUS
left join CAT_DIG_DIGITALIZACION_ESTATUS DI on dI.ID_ESTATUS=s.ID_ESTATUS + 1
join hape..SUCURSALES SUC ON C.Id_de_Sucursal=suc.Id_de_Sucursal
join hape..REGIONES reg on suc.Region=reg.Region
join HAPE..TBL_CRED_DATOS_ADICIONALES_SOLICITUD a on c.id_sol=a.id_sol
--JOIN TBL_CRED_CODIGO_CELULAR_SOLICITUD a on c.id_sol=a.id_solicitud and validado=1
where
c.Numero in (653738) and
 --d.ID_ESTATUS=4 and
 -- meses_periodo_gracia>0 and
 --id_so  and
C.Activo='T'
and c.Usuario_AC=567
and c.Numero_Fin_LACP=1
order by Usuario_AC
--8751670301

--update s set enviado='F' from TBL_CRED_VERIFICACION_INVESTIGACION_CAMPO s where num_ptmo='9133630101'

--7849860102

---select * from TBL_COMITE_PARAMETRIZACION where numero in(292366,602017)
--update TBL_COMITE_PARAMETRIZACION set vehiculoAutomotriz=1 where numero in(261273,538355,261273)

--UPDATE TBL_CRED_DATOS_ADICIONALES_SOLICITUD set meses_periodo_gracia=3 where id_sol='950020103'

--836455 quiro sin periodos de gracia
--95002 socio puntual sin periodos de gracia
--20298 socio ordinario

---Socios con saldo en el ahorro
--select * from EDO_DE_CUENTA e
--join HAPE..PERSONA a on e.Numero=a.Numero and e.Id_Tipo_persona=a.Id_Tipo_Persona
--left join CRED_SOLICITUD_CREDITO cred on e.Numero=cred.Numero and cred.Activo='T'
--where a.Id_de_Sucursal=21 and a.Id_Tipo_Persona=1 and e.Id_mov=100 and e.Saldo_Actual>3000 and cred.id_sol is null
--and e.Numero not in (select Numero from EDO_DE_CUENTA where Numero=e.Numero and Id_mov<10 and Saldo_Actual>0)

----Socio Puntual
--select c.Alta_SocPuntual,E.numero,* from EDO_DE_CUENTA e
--join HAPE..PERSONA a on e.Numero=a.Numero and e.Id_Tipo_persona=a.Id_Tipo_Persona
--left join CRED_SOLICITUD_CREDITO cred on e.Numero=cred.Numero and cred.Activo='T'
--JOIN TBL_SOCIO_PUNTUAL c on e.Numero=c.Numero
--where a.Id_de_Sucursal=21 and a.Id_Tipo_Persona=1 and e.Id_mov=100 and e.Saldo_Actual>3000 and cred.id_sol is null
--and e.Numero not in (select Numero from EDO_DE_CUENTA where Numero=e.Numero and Id_mov<10 and Saldo_Actual>0)
--and Id_status in (2,3) and id_tipo_socio_puntual=1 
--and c.Alta_SocPuntual>'20200331'

----Renovaciones socio puntaul
--select ptmoSocioPuntual.Fecha_Ptmo,E.numero,* from EDO_DE_CUENTA e
--join HAPE..PERSONA a on e.Numero=a.Numero and e.Id_Tipo_persona=a.Id_Tipo_Persona
--left join CRED_SOLICITUD_CREDITO cred on e.Numero=cred.Numero and cred.Activo='T'
--JOIN TBL_SOCIO_PUNTUAL c on e.Numero=c.Numero
--JOIN EDO_DE_CUENTA ptmoSocioPuntual on a.Numero=ptmoSocioPuntual.Numero and ptmoSocioPuntual.Id_mov=1 and ptmoSocioPuntual.PlanX='J' and ptmoSocioPuntual.Saldo_Actual>0 and ptmoSocioPuntual.Dias_Vencidos=0
--where a.Id_de_Sucursal=21 and a.Id_Tipo_Persona=1 and e.Id_mov=100 and e.Saldo_Actual>3000 and cred.id_sol is null
--and Id_status in (2,3) and id_tipo_socio_puntual=1 

--Sobreprestamo

--select ptmoActual.PlanX,ptmoActual.Fecha_Ptmo,E.numero,* from EDO_DE_CUENTA e
--join HAPE..PERSONA a on e.Numero=a.Numero and e.Id_Tipo_persona=a.Id_Tipo_Persona
--left join CRED_SOLICITUD_CREDITO cred on e.Numero=cred.Numero and cred.Activo='T'
--JOIN EDO_DE_CUENTA ptmoActual on a.Numero=ptmoActual.Numero and ptmoActual.Id_mov=1 and ptmoActual.PlanX in ('N','O') and ptmoActual.Saldo_Actual>0 and ptmoActual.Dias_Vencidos=0 and ptmoActual.Max_dias_vencidos<5
--where a.Id_de_Sucursal=21 and a.Id_Tipo_Persona=1 and e.Id_mov=100 and e.Saldo_Actual>3000 and cred.id_sol is null


--EXEC SP_CMV_OBTENER_MESES_PERIODOS_GRACIA '2388680109'

--select * from EDO_DE_CUENTA where numero=238868 and Id_mov=1 and Saldo_Actual>0 and Num_ptmo='2388680109'



--Proceso cuando existe una garant�a prendaria

--Captura Garantia - Ejecutivo - SIDD
--Digitaliza Garant�a -Ejecutivo -SIDD
--Revision de Garant�as - Analista (Usuario AC) - Credito Digitalizador
--Adjuntar Avaluo - Analista (Usuario AC) - Credito Digitalizador
--Revisi�n Avaluo - Usuario Aut - Credito Digitalizador

--select * from BURO_REQUERIDA where numero=775980

--select * from DIGITALIZADOR..TBL_DIG_CONFIGURACION

--select * from sucursales


--select * from SUCURSALES where fk_id_tipologia_sucursal=1 AND baja_logica=0


--SELECT * FROM DIGITALIZADOR..CAT_DIG_TIPO_NOTIFICACION_CORREOS

--select * from HAPE..CLAVES 
--WHERE Numusuario in (1038,4070,50,929,591)

--SELECT ID_MOV,* FROM EDO_DE_CUENTA WHERE NUMERO=869136


--754173
--869272 -- rechaza dictamen
--869136
--869114
--610626 pendiente
--873510 especial dpf tipologia 1
--873462 Refaccionario tipologia 1
--873871 refaccionario tipologia 4
--871910 especial dpf tipologia 1



--UPDATE HAPE..CLAVES SET Correo='jessica.almonte@cmv.mx' 
--WHERE Numusuario in (1038,4070,50,113,10,4074,591)

--UPDATE HAPE..CLAVES SET Correo='nancy.medina@cmv.mx' 
--WHERE Numusuario in (4067)


--EXEC SP_DIG_RECHAZAR_SOLICITUD '7541730102', '', 1, 4
--Exec SP_DIG_CRED_MIGRA_SOLICITUD_HISTORICO '7541730102', 754173, 0, 1

--SELECT * FROM TBL_CRED_CODIGO_CELULAR_SOLICITUD WHERE celular='4431155160'

--SELECT * FROM CRED_SOLICITUD_CREDITO WHERE Numero=754173
			  
--insert into TBL_CRED_CODIGO_CELULAR_SOLICITUD(id_solicitud,codigo_celular,fecha_alta,validado,id_modulo,celular)
--SELECT '7541730102',1111,GETDATE(),1,5,4431155160

--SELECT * FROM CLAVES cl
--join SICORP_ROLES rol on cl.Id_Rol=rol.Id_Rol
--where rol.Nom_Rol like 'GERENTE REGIONAL%' and Numemp<>0

--and s.ID_ESTATUS=8

--select Ahorro_Base,Saldo_Actual,id_mov,* from EDO_DE_CUENTA where Numero=873879

--and s.ID_ESTATUS=1

--SELECT * FROM CLAVES WHERE Id_de_sucursal=7

--SELECT * 
--FROM PERSONA P
--join (select Numero from EDO_DE_CUENTA where Id_mov<10 group by numero having sum(Saldo_Actual)=0) ptmo on p.Numero=ptmo.Numero
--left join CRED_SOLICITUD_CREDITO cred on p.Numero=cred.Numero
-----join hape..BURO_REQUERIDA B ON P.NUMERO=B.NUMERO and b.id_tipo_solicitante 
--WHERE Id_Tipo_Persona=1 AND p.Id_de_Sucursal=21  and cred.id_sol is null

--175895


--select * from TBL_CRED_REFERENCIA_TELEFONICA where id_sol='6904380101'

--select * from CRED_PARAMS_PTMO where Id_mov=1 and Planx='L'

--EXEC SP_CRED_OBTENER_REFERENCIA_TELEFONICA '1356860101'

--INSERT INTO TBL_CRED_REFERENCIA_TELEFONICA(id_sol,nombre_s,apellido_paterno,apellido_materno,telefono_casa,telefono_celular,tipo_referencia,orden_referencia)
--select '1356860101',nombre_s,apellido_paterno,apellido_materno,telefono_casa,telefono_celular,tipo_referencia,orden_referencia 
--from TBL_CRED_REFERENCIA_TELEFONICA where id_sol='6904380101'

--update TBL_DIG_DIGITALIZACION_SOLICITUD set ID_ESTATUS=13 where ID_SOLICITUD='8189710101'

--select * from claves where Usuario like '%ROBO%'

----robot_ver_cam
----AB171E77A57839E7C7D78F85F8FD30

--update  TBL_CRED_VERIFICACION_INVESTIGACION_CAMPO set enviado='F' where num_ptmo in ('1356860101','6904380101')

--Simular verificacion de campo

--INSERT INTO CRED_CALIFICACION_C1_C4(id_solicitud,c1,c4,Fecha_alta)
--SELECT '8738790101',2.89,4.43,GETDATE()

--EXEC SP_DICTAMEN_GENERA_C1 '6904380101',690438
--EXEC SP_DICTAMEN_CONSULTA_PTMOS_SOCIO 690438,'6904380101'

--select * from CRED_SOLICITUD_CREDITO where id_sol='8738790101'
--exec DIGITALIZADOR..SP_DIG_OBTENER_DOCUMENTOS @id_solicitud=N'8692720101',@id_estatus=1,@id_responsable_actualizacion=0,@notificacion=NULL

--select * 
--from DIGITALIZADOR..TBL_DIG_SOLICITUD_DOCUMENTOS sd
--	left outer join DIGITALIZADOR..CAT_DIG_DOCUMENTOS doc
--		on doc.id_documento=sd.id_documento
--	left outer join DIGITALIZADOR..CAT_DIG_PROPIETARIOS p
--		on p.id_propietario=sd.id_propietario
--	left outer join DIGITALIZADOR..TBL_DIG_ETAPAS_DOCUMENTO_SOLICITUD eds
--		on eds.contador_solicitud_documento=sd.contador 
--	where sd.id_solicitud='8692720101' and
--		  sd.activo='T'
