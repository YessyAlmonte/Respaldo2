declare 
@numero int=736689,
@id_mov int=5,
@num_ptmo varchar(20)='7366890502',
@fecha_calculo date=getdate()

declare @interes_diferido money,@interes money

select @interes_diferido=sum(interes_diferido_actual)
from HAPE..TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES d
where numero=@numero and id_mov=@id_mov and num_ptmo=@num_ptmo
and capital_actual>0 and ((fecha_fin<@fecha_calculo) or (@fecha_calculo between (fecha_inicio + 1) and fecha_fin)) 
and version_calendario=(select  coalesce(MAX(version_calendario), 0)
						from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES with (nolock)
						where	numero = @numero
								and id_mov = @id_mov
								and num_ptmo = @num_ptmo)

select  @interes_diferido=total_interes_diferido_actual,
		@interes=total_interes
				from (
				select sum(interes) total_interes,sum(interes_diferido_actual) total_interes_diferido_actual
				from TBL_AUTOMOTRIZ_PTMOS
				where numero = @numero 
				and id_mov = @id_mov 
				and num_ptmo = @num_ptmo 
				and Id_status = 1 
				and ((fecha_pago<@fecha_calculo) or num_pago=(select min(num_pago) from TBL_AUTOMOTRIZ_PTMOS
				where numero = @numero 
				and id_mov = @id_mov 
				and num_ptmo = @num_ptmo 
				and Id_status = 1 and fecha_pago>=@fecha_calculo))
 

				union

				select sum(interes) total_interes,sum(interes_diferido_actual) total_interes_diferido_actual
				from TBL_HIPOTECARIO_PTMOS
				where numero = @numero 
				and id_mov = @id_mov 
				and num_ptmo = @num_Ptmo 
				and Id_status = 1
				and ((fecha_pago<@fecha_calculo) or num_pago=(select min(num_pago) from TBL_HIPOTECARIO_PTMOS
				where numero = @numero 
				and id_mov = @id_mov 
				and num_ptmo = @num_ptmo 
				and Id_status = 1 and fecha_pago>=@fecha_calculo))

				union

				select sum(interes) total_interes,sum(interes_diferido_actual) total_interes_diferido_actual 
				from TBL_NIVELADOS_PTMOS
				where numero = @numero 
				and id_mov = @id_mov 
				and num_ptmo = @num_Ptmo 
				and Id_status = 1
				and ((fecha_pago<@fecha_calculo) or num_pago=(select min(num_pago) from TBL_NIVELADOS_PTMOS
				where numero = @numero 
				and id_mov = @id_mov 
				and num_ptmo = @num_ptmo 
				and Id_status = 1 and fecha_pago>=@fecha_calculo))
				) ptmosNivelados

select DATEDIFF(DAY,coalesce(Ultimo_Abono,fecha_ptmo),GETDATE()) dias_transcurridos,(Int_Ord/3000) tasa_ord,Saldo_Actual,
case when id_esquema=1 then round(DATEDIFF(DAY,coalesce(Ultimo_Abono,fecha_ptmo),GETDATE()) * (Int_Ord/3000) * Saldo_Actual,2,0) else @interes end interes_ord,@interes_diferido interes_diferido,
(case when id_esquema=1 then (round(DATEDIFF(DAY,coalesce(Ultimo_Abono,fecha_ptmo),GETDATE()) * (Int_Ord/3000) * Saldo_Actual,2,0)) else @interes end + @interes_diferido) total_interes
,dias_vencidos
,* 
from hape..edo_de_cuenta e
where Numero=@numero and id_mov=@id_mov and num_ptmo=@num_ptmo

--select * 
--from hape..edo_de_cuenta e
--where id_mov<10 and saldo_actual>0 and id_esquema=2 and dias_vencidos>1  and interes_ordinario_diferido>0 and id_mov=9
--and day(fecha_ptmo)=8



--select num_ptmo,capital_actual,fecha_inicio,fecha_fin,interes_diferido_actual,* 
--from HAPE..TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES where numero=517607 and id_mov=1
--and capital_actual>0 and ((fecha_fin<getdate()) or (getdate() between (fecha_inicio + 1) and fecha_fin)) 

--select num_ptmo,capital,interes,IVA,interes_diferido_actual,fecha_pago,*
--				from TBL_AUTOMOTRIZ_PTMOS
--				where numero = @numero 
--				and id_mov = @id_mov 
--				and num_ptmo = @num_ptmo 
--				and Id_status = 1 
--				order by contador


--and  getdate() between (fecha_inicio + 1) and fecha_fin

--exec SP_INTERES_DIARIO_OBTIENE_SALDOS @numero,@id_mov
--exec SP_INTERES_DIARIO_OBTIENE_SALDOS_BANCA_NIVELADOS  @numero,@id_mov,@fecha_calculo

--select dias_vencidos,id_esquema,* from hape..edo_de_cuenta where numero=865048 and id_mov=1
--select fecha_inicio,fecha_fin,interes_diferido_actual,* from hape..TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES where numero=865048

--236.52
--236.52
--236.52

--select * from hape..movimientos where numero=865048 and id_mov=1
