SELECT l.*
INTO #CONTRATOS_NUEVOS
FROM TBL_CRED_PRODUCTOS_LEYENDAS l
join cred_params_ptmo b on l.id_subproducto=b.contador
WHERE l.ACTIVO=1 and b.activo='T'  and leyenda<>''  
ORDER BY PRODUCTO



select cs.id_subproducto,max(c.ID_CONTRATO) ID_CONTRATO,max(e.Num_ptmo) num_ptmo
INTO #SOLICITUDES_CONTRATOS_EXISTENTES
from EDO_DE_CUENTA e
join TBL_CRED_DATOS_ADICIONALES_SOLICITUD  c on e.num_ptmo=c.id_sol
join CRED_SOLICITUD_CREDITO cs on c.id_sol=cs.id_sol
join #CONTRATOS_NUEVOS cn on cs.id_subproducto=cn.ID_SUBPRODUCTO
where e.saldo_actual>0 and e.id_mov<10 and c.ID_CONTRATO>0
group by cs.id_subproducto

union

select cs.id_subproducto,max(c.ID_CONTRATO) ID_CONTRATO,max(rev.Num_ptmo) num_ptmo
from TBL_REVOLVENTE_LINEAS_CREDITO rev
join TBL_CRED_DATOS_ADICIONALES_SOLICITUD  c on rev.num_ptmo=c.id_sol
join CRED_SOLICITUD_CREDITO cs on c.id_sol=cs.id_sol
join #CONTRATOS_NUEVOS cn on cs.id_subproducto=cn.ID_SUBPRODUCTO
where rev.saldo_actual>0 and c.ID_CONTRATO>0
group by cs.id_subproducto


UPDATE a SET ID_CONTRATO=n.ID_CONTRATO
------select a.ID_CONTRATO,n.ID_CONTRATO,c.id_subproducto,n.ID_SUBPRODUCTO,*
FROM TBL_CRED_DATOS_ADICIONALES_SOLICITUD a
join #SOLICITUDES_CONTRATOS_EXISTENTES c on a.id_sol=c.num_ptmo
join #CONTRATOS_NUEVOS n on c.ID_SUBPRODUCTO=n.ID_SUBPRODUCTO
where n.ID_CONTRATO not in (select s.ID_CONTRATO 
from TBL_CRED_DATOS_ADICIONALES_SOLICITUD s
join #CONTRATOS_NUEVOS ct on s.ID_CONTRATO=ct.ID_CONTRATO)



--SELECT a.PRODUCTO,a.ID_SUBPRODUCTO,a.ID_CONTRATO idContratoNuevo,b.ID_CONTRATO idContratoAnt,c.num_ptmo,a.ANEXO 
--FROM #CONTRATOS_NUEVOS a
--join #CONTRATOS_ANTERIORES b on a.ID_SUBPRODUCTO=b.ID_SUBPRODUCTO
--left join #SOLICITUDES_CONTRATOS c on b.ID_CONTRATO=c.ID_CONTRATO
--order by a.PRODUCTO


--SELECT a.PRODUCTO,a.ID_SUBPRODUCTO,a.ID_CONTRATO idContratoNuevo,b.ID_CONTRATO idContratoAnt,c.id_sol,a.ANEXO 
--FROM #CONTRATOS_NUEVOS a
--join TBL_CRED_DATOS_ADICIONALES_SOLICITUD c on a.ID_CONTRATO=c.ID_CONTRATO
--join #CONTRATOS_ANTERIORES b on a.ID_SUBPRODUCTO=b.ID_SUBPRODUCTO
--order by a.PRODUCTO

SELECT a.PRODUCTO,a.LEYENDA,max(c.id_sol) id_sol
FROM #CONTRATOS_NUEVOS a
left join TBL_CRED_DATOS_ADICIONALES_SOLICITUD c on a.ID_CONTRATO=c.ID_CONTRATO
where a.ANEXO=1	
group by a.PRODUCTO,a.LEYENDA,ANEXO

union 

SELECT a.PRODUCTO,a.LEYENDA,max(c.id_sol) id_sol
FROM #CONTRATOS_NUEVOS a
left join TBL_CRED_DATOS_ADICIONALES_SOLICITUD c on a.ID_CONTRATO=c.ID_CONTRATO
where a.LEYENDA not in (SELECT a.LEYENDA
FROM #CONTRATOS_NUEVOS a
left join TBL_CRED_DATOS_ADICIONALES_SOLICITUD c on a.ID_CONTRATO=c.ID_CONTRATO
where a.ANEXO=1	
group by a.PRODUCTO,a.LEYENDA,ANEXO)
group by a.PRODUCTO,a.LEYENDA,ANEXO


DROP TABLE #CONTRATOS_NUEVOS
DROP TABLE #SOLICITUDES_CONTRATOS_EXISTENTES
