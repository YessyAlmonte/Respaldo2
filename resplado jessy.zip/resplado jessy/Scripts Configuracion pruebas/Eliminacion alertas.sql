USE[LAVADO_DINERO]

DECLARE @FECHA_INICIO DATE,
        @FECHA_FIN DATE,
		@ELIMINAR BIT=1,
		@id_tipo_origen int=5

SELECT @FECHA_INICIO='20200301',
       @FECHA_FIN='20200430'

IF (@ELIMINAR=1) 
BEGIN
	DELETE LAVADO_ALERTAS_DETALLE where ID_ALERTA in (
	SELECT ID_ALERTA FROM LAVADO_ALERTAS WHERE 
	cast(FECHA_ALTA as date) BETWEEN @FECHA_INICIO AND @FECHA_FIN
	AND id_tipo_origen=@id_tipo_origen
	)

	DELETE LAVADO_ALERTAS WHERE ID_ALERTA IN (
	SELECT ID_ALERTA FROM LAVADO_ALERTAS WHERE 
	cast(FECHA_ALTA as date) BETWEEN @FECHA_INICIO AND @FECHA_FIN
	AND id_tipo_origen=@id_tipo_origen
	)

	if(@id_tipo_origen=5)
	begin
	  delete lavado_dinero.dbo.lavado_perfil_tran_mensual where cast(FECHA_ALTA as date) BETWEEN @FECHA_INICIO AND @FECHA_FIN
	end

END
ELSE
BEGIN

	SELECT * 
	FROM LAVADO_ALERTAS WHERE 
	cast(FECHA_ALTA as date) BETWEEN @FECHA_INICIO AND @FECHA_FIN
	AND id_tipo_origen=@id_tipo_origen 


	SELECT * 
	FROM
	LAVADO_ALERTAS_DETALLE where ID_ALERTA in (
		SELECT ID_ALERTA FROM LAVADO_ALERTAS WHERE 
		cast(FECHA_ALTA as date) BETWEEN @FECHA_INICIO AND @FECHA_FIN
		AND id_tipo_origen=@id_tipo_origen 
		)
END