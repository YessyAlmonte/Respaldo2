--select * 
--from TBL_CRED_PRODUCTOS_LEYENDAS l
--join CRED_PARAMS_PTMO p on l.ID_SUBPRODUCTO=p.Contador
--where l.ACTIVO=1 and p.Activo='T' and p.Id_mov=1 and Planx='L' --and PRODUCTO like '%ORDINARIO 10 A 1%'

select Id_mov,Planx,* from TBL_CRED_PRODUCTOS_LEYENDAS  l
join CRED_PARAMS_PTMO p on l.ID_SUBPRODUCTO=p.Contador
where LEYENDA like '%2091-439-026259/04-04709-0818%'
and p.Activo='T'
union 
select Id_mov,Planx,* from TBL_CRED_PRODUCTOS_LEYENDAS  l
join CRED_PARAMS_PTMO p on l.ID_SUBPRODUCTO=p.Contador
where LEYENDA like '%2091-439-026259/05-06151-1118%'
and p.Activo='T'
order by ID_SUBPRODUCTO

select Id_mov,* from TBL_CRED_PRODUCTOS_LEYENDAS  l
join CRED_PARAMS_PTMO p on l.ID_SUBPRODUCTO=p.Contador
where LEYENDA like '%2091-439-026261/04-04716-0818%'
and  p.Activo='T'
union
select Id_mov,* from TBL_CRED_PRODUCTOS_LEYENDAS  l
join CRED_PARAMS_PTMO p on l.ID_SUBPRODUCTO=p.Contador
where LEYENDA like '%2091-439-026261/05-06158-1118%'
and  p.Activo='T'

select Id_mov,* from TBL_CRED_PRODUCTOS_LEYENDAS  l
join CRED_PARAMS_PTMO p on l.ID_SUBPRODUCTO=p.Contador
where LEYENDA like '%2091-439-026254/05-04717-0818%'
and  p.Activo='T'

union

select Id_mov,* from TBL_CRED_PRODUCTOS_LEYENDAS  l
join CRED_PARAMS_PTMO p on l.ID_SUBPRODUCTO=p.Contador
where LEYENDA like '%2091-439-026254/06-06159-1118%'
and  p.Activo='T'

UPDATE TBL_CRED_DATOS_ADICIONALES_SOLICITUD set ID_CONTRATO=354,meses_periodo_gracia=3
 WHERE id_sol='6626900101'


select * from TBL_CRED_DATOS_ADICIONALES_SOLICITUD where ID_CONTRATO=339


select * from CRED_PARAMS_PTMO where Id_mov=1 and Planx in ('N','L') and Activo='T'