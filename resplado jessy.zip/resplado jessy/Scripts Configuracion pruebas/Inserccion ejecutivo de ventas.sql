USE[HAPE]

--declare @id_sucursal int=21

--select * from hape..persona where id_de_sucursal=21 and Id_Tipo_Persona=1
--SELECT * FROM HAPE..CLAVES WHERE Numusuario=4070




insert into HAPE..CLAVES(Numusuario,Usuario,Numemp,autorizo,Correo,Nombre_s,Apellido_paterno,Apellido_materno,
Fecha_Cambio_Contrasena,Contrasena_Encriptada,Id_de_sucursal,Cierre,Cta_Deud,Permisos,Permisos_Respaldo,Id_area,
Nota_Cal,Aviso1_Cal,Aviso2_Cal,Aviso1_Estado,Aviso2_Estado,Leyenda_Ficha,Contrasena,Nom_Maquina,Gafete_Impreso,
Gafete_Fecha,NSS,Id_ccostos_nomina,Id_GeneroWoccu,Correo_externo,Permisos_CYC,Id_Dpto,Id_Rol,Id_bloqueo,Objetivo,
Numusuario_Jefe,Id_Ticket,Id_Proceso,Id_Accion,Comodin)
select 4070 Numusuario,'CRV07_MO_OTE' Usuario,P.Numero Numemp,autorizo,Correo,P.Nombre_s,P.Apellido_paterno,P.Apellido_materno,
Fecha_Cambio_Contrasena,Contrasena_Encriptada,P.Id_de_sucursal,Cierre,Cta_Deud,Permisos,Permisos_Respaldo,Id_area,
Nota_Cal,Aviso1_Cal,Aviso2_Cal,Aviso1_Estado,Aviso2_Estado,Leyenda_Ficha,Contrasena,Nom_Maquina,Gafete_Impreso,
Gafete_Fecha,NSS,Id_ccostos_nomina,Id_GeneroWoccu,Correo_externo,Permisos_CYC,Id_Dpto,411 Id_Rol,Id_bloqueo,Objetivo,
Numusuario_Jefe,Id_Ticket,Id_Proceso,Id_Accion,Comodin 
from HAPE..CLAVES C
CROSS JOIN HAPE..PERSONA P
WHERE C.Numusuario=4067 AND P.Id_Tipo_Persona=1 AND P.Numero=373344