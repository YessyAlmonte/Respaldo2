declare @total_delegados int,
        @total_registrados int,
		@porcentaje float


Select  @total_delegados=COUNT(1) From Delegados
Select  @total_registrados=COUNT(1) From Delegados where asistencia='T'

SELECT @total_delegados=0,@total_registrados=0

select 
@total_delegados total_delegados,
@total_registrados total_registrados,
CASE WHEN @total_delegados=0 THEN 0 ELSE (cast(@total_registrados AS float)/CAST(@total_delegados AS float))*100 END porcentaje