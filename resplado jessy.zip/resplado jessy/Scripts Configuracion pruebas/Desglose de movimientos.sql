use[lavado_dinero]

if object_id('tempdb..#movimientos') is not null drop table #movimientos
if object_id('tempdb..#captura') is not null drop table #captura
if object_id('tempdb..#captura_lacp') is not null drop table #captura_lacp
if object_id('tempdb..#TBL_HIPOTECARIO_PAGOS_REALIZADOS') is not null drop table #TBL_HIPOTECARIO_PAGOS_REALIZADOS
if object_id('tempdb..#TMP') is not null drop table #TMP
go

begin tran

declare @fecha_ini datetime='20200301',
        @fecha_fin datetime='20200331',
		@numero int=766493




select * 
into #movimientos
from ARCHIVO_HISTORICO.dbo.movimientos_haberes
where convert(date,fecha_mov) between @fecha_ini and @fecha_fin
and numero=@numero

insert #movimientos
select * 
from ARCHIVO_HISTORICO.dbo.MOVIMIENTOS_PTMOS_LIQUIDADOS
where convert(date,fecha_mov) between @fecha_ini and @fecha_fin
and numero=@numero

insert #movimientos
select * 
from HISTORICO.dbo.movimientos_haberes
where convert(date,fecha_mov) between @fecha_ini and @fecha_fin
and numero=@numero

insert #movimientos
select * 
from hape.dbo.movimientos
where convert(date,fecha_mov) between @fecha_ini and @fecha_fin
and numero=@numero

select * 
into #captura
from historico..CAPTURA
where convert(date,fecha_mov) between @fecha_ini and @fecha_fin
and numero=@numero

---------------------
--RECUERDA HACER FILTRO POR ID_MOV
-- 100 Ahorro; 103 Inver;112 d�bito;105
----------------------
select Numusuario,monto,t.Descripcion,t.id_tipomov,mov.fecha_mov,monto,saldo,Num_DPF,Folio,* 
FROM #movimientos mov
join hape..tipo_mov t on mov.id_tipomov=t.id_tipomov
WHERE  activo='T'
order by mov.fecha_mov


select NUMUSUARIO,Folio,fecha_mov f, Concepto,Monto,* 
from #captura where numero=@numero  and convert(date,fecha_mov) between @fecha_ini and @fecha_fin
order by fecha_mov

commit tran



