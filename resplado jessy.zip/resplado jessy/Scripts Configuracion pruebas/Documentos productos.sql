SELECT * FROM CRED_PARAMS_PTMO WHERE Id_mov=1 AND Planx='l'

SELECT d.id_documento,p.propietario,c.nombre_documento,s.DESCRIPCION etapa,requerido,impresion,e.*
FROM DIGITALIZADOR.[dbo].[TBL_DIG_SUBPRODUCTO_DOCUMENTO]  D
JOIN [DIGITALIZADOR].[DBO].[CAT_DIG_DOCUMENTOS] C
  ON C.ID_DOCUMENTO = D.ID_DOCUMENTO
  JOIN [DIGITALIZADOR].[DBO].[CAT_DIG_PROPIETARIOS] P
  ON P.ID_PROPIETARIO = D.ID_PROPIETARIO
 JOIN digitalizador..TBL_DIG_ETAPAS_DOCUMENTO_PRODUCTO  E ON D.contador=E.contador_subproducto_documento
 JOIN hape..CAT_DIG_DIGITALIZACION_ESTATUS  s on e.id_estatus=s.ID_ESTATUS
WHERE ID_SUBPRODUCTO=191 --and s.id_estatus>0
order by d.id_documento,s.ID_ESTATUS,p.id_propietario

select * from DIGITALIZADOR..TBL_DIG_ETAPAS_SUBPROCESO_CRED
select * from DIGITALIZADOR..TBL_DIG_SUB_SUBPROCESOS_DIGITALIZACION where id_proceso=1
select * from DIGITALIZADOR.[dbo].[TBL_DIG_SUBPRODUCTO_DOCUMENTO]

--select * from [DIGITALIZADOR].[DBO].[CAT_DIG_DOCUMENTOS] where nombre_documento like '%PRENDARIO%'


SELECT d.id_documento,p.propietario,c.nombre_documento,s.DESCRIPCION etapa,requerido,impresion
FROM DIGITALIZADOR.[dbo].[TBL_DIG_SUBPRODUCTO_DOCUMENTO]  D
JOIN [DIGITALIZADOR].[DBO].[CAT_DIG_DOCUMENTOS] C
  ON C.ID_DOCUMENTO = D.ID_DOCUMENTO
  JOIN [DIGITALIZADOR].[DBO].[CAT_DIG_PROPIETARIOS] P
  ON P.ID_PROPIETARIO = D.ID_PROPIETARIO
 JOIN digitalizador..TBL_DIG_ETAPAS_DOCUMENTO_PRODUCTO  E ON D.contador=E.contador_subproducto_documento
 JOIN hape..CAT_DIG_DIGITALIZACION_ESTATUS  s on e.id_estatus=s.ID_ESTATUS
WHERE ID_SUBPRODUCTO=189 and propietario='Garantia hipotecaria' --and s.id_estatus>0 
order by d.id_documento,s.ID_ESTATUS,p.id_propietario

select * from DIGITALIZADOR.[dbo].[TBL_DIG_SUBPRODUCTO_DOCUMENTO]
select * from [DIGITALIZADOR].[DBO].[CAT_DIG_DOCUMENTOS]
select * from DIGITALIZADOR..TBL_DIG_ETAPAS_DOCUMENTO_PRODUCTO


SELECT p.propietario,c.nombre_documento
FROM DIGITALIZADOR.[dbo].[TBL_DIG_SUBPRODUCTO_DOCUMENTO]  D
JOIN [DIGITALIZADOR].[DBO].[CAT_DIG_DOCUMENTOS] C
  ON C.ID_DOCUMENTO = D.ID_DOCUMENTO
  JOIN [DIGITALIZADOR].[DBO].[CAT_DIG_PROPIETARIOS] P
  ON P.ID_PROPIETARIO = D.ID_PROPIETARIO
 JOIN digitalizador..TBL_DIG_ETAPAS_DOCUMENTO_PRODUCTO  E ON D.contador=E.contador_subproducto_documento
 JOIN hape..CAT_DIG_DIGITALIZACION_ESTATUS  s on e.id_estatus=s.ID_ESTATUS
WHERE ID_SUBPRODUCTO=190  and s.id_estatus>0
group by p.propietario,c.nombre_documento,c.id_documento
order by c.id_documento
