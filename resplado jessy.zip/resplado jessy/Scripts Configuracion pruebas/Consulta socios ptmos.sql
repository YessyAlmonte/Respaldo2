declare @id_de_sucursal int=21

--SELECT TOP 10 * 
--FROM PERSONA P
--join (select Numero from EDO_DE_CUENTA where Id_mov=1 group by numero having sum(Saldo_Actual)=0) ptmo on p.Numero=ptmo.Numero
--left join CRED_SOLICITUD_CREDITO cred on p.Numero=cred.Numero
--WHERE Id_Tipo_Persona=1 AND p.Id_de_Sucursal=@id_de_sucursal  and cred.id_sol is null
--ORDER BY P.NUMERO DESC

SELECT * 
FROM CLAVES CL
JOIN SICORP_ROLES R ON CL.Id_Rol=R.Id_Rol
WHERE Id_de_sucursal=@id_de_sucursal and Numemp<>0 and (Nombre_s<>'COMODIN' or Nombre_s<>'BAJA LOGICA')
AND R.Nom_Rol LIKE 'EJEC%'

SELECT TOP 10 * 
FROM PERSONA P
join (select Numero from EDO_DE_CUENTA where Id_mov<10 group by numero having sum(Saldo_Actual)=0) ptmo on p.Numero=ptmo.Numero
join (select Numero from EDO_DE_CUENTA where Id_mov=105 group by numero having sum(Saldo_Actual)>0) dpf on p.Numero=dpf.Numero
left join CRED_SOLICITUD_CREDITO cred on p.Numero=cred.Numero
WHERE Id_Tipo_Persona=1 AND p.Id_de_Sucursal=@id_de_sucursal  and cred.id_sol is null
ORDER BY P.NUMERO DESC

---UPDATE EDO_DE_CUENTA SET Saldo_Actual=50000 WHERE NUMERO=872687 AND Id_mov=100

--SELECT top 10 e.* 
--FROM HAPE..PERSONA p
--join EDO_DE_CUENTA e on p.Numero=e.Numero and e.Id_Tipo_persona=p.Id_Tipo_Persona 
--where p.Id_Tipo_Persona=1 and p.Id_de_Sucursal=21 and Planx in ('N','O') and e.Id_mov=1 and e.Saldo_Actual>0
--and (Monto_Inicial - Saldo_Actual)/Monto_Inicial>0.40
--and DATEDIFF(MONTH,Fecha_Ptmo,GETDATE())<CEILING(Plazo * 0.8) 