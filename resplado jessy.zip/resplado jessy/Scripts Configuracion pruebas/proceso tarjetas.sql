USE[HAPE]

declare @numero int, @sucursal int

set @numero = 210303

declare @solicitud int = (select max(id_solicitud) from tbl_atm_layout where numero = @numero)

--update
--	tbl_atm_log_proceso
--set
--	id_status = 2
--where
--	id_solicitud = @solicitud

--    select * from TBL_ATM_TARJETAS_EXPRESS where numero_tarjeta = '4166053563201186'

--personalizada
--select * from TBL_ATM_TARJETAS_PENDIENTES_POR_ENTREGAR where numero = @numero
--la solicito

update
	tbl_atm_log_proceso
set
	id_status = 10
where
	id_solicitud = @solicitud

if not exists(select 1 from TBL_ATM_TARJETAS_PENDIENTES_POR_ENTREGAR where numero = @numero)
INSERT INTO TBL_ATM_TARJETAS_PENDIENTES_POR_ENTREGAR(numero,numero_tarjeta,id_archivo,fecha_alta,entregada) 
SELECT @numero,'4166050626' + CAST(@numero AS varchar),0,GETDATE(),0
