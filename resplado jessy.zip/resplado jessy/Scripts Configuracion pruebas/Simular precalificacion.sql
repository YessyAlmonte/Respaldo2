USE[HAPE]
declare 
       @numero int=836455,
       @Bc_Score varchar(30)='680',
	   @monto money=15000

IF EXISTS (SELECT NUMERO FROM BURO_REQUERIDA WHERE Numero=@numero)
		begin
			-- CONSULTA DE BURO VIGENTE	
			update BURO_REQUERIDA set Bc_Score=@Bc_Score, Id_Status=2 where Numero=@numero
		    
	    		-- RELACIONA LA CONSULTA BURO CON EL PRE CALIFICADOR
			update TBL_PRECALIFICADOR_BURO set contador_buro_requerida = (
			select  max(contador) from BURO_REQUERIDA where Numero=@numero)
			where contador in (select top 1 contador from TBL_PRECALIFICADOR_BURO where observacion=',' and historico='' ORDER BY NEWID())

				--ACTUALIZA SALDO DE CUENTA DEL SOCIO
			--update EDO_DE_CUENTA set Saldo_Actual=@monto where Numero = @numero and Id_mov=100

			update EDO_DE_CUENTA set Saldo_Actual=15000 where Numero = @numero and Id_mov=100 
		
		end   ELSE
				begin
						select 'NO TIENE CONSULTA DE BURO' as status
						return
				END
				
		--MOSTRAR DATOS ACTUALIZADOS
		select * from TBL_PRECALIFICADOR_BURO where contador_buro_requerida in 
		(select top 1 contador from BURO_REQUERIDA where Numero=@numero)
		select * from BURO_REQUERIDA where Numero=@numero
		select numero,Id_mov,Saldo_Actual from EDO_DE_CUENTA where Numero=@numero and Id_mov=100
		return