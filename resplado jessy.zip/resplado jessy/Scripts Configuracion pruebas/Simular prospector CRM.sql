declare @id_campania int=3        
        
        UPDATE TBL_CRM_CAMPANIAS_SOCIO
        SET limite_inferior = 6000, limite_superior = 19000, ingreso_estimado = 10000,
            bc_score = '0731', ICC = '0009', fecha_ini_envio = GETDATE(), fecha_fin_envio = GETDATE(),
            mensaje_buro = '', fk_id_status_buro = 2, clave_razon1 = '100', clave_razon2 = '54',
            clave_razon3 = '76'
        WHERE fk_id_campania = @Id_Campania

 

        EXEC SP_CRM_MOTOR_DECISION @ID_CAMPANIA

 

        exec SP_CRM_ACTUALIZA_ETAPA_CAMPANIA @id_campania,2,844


