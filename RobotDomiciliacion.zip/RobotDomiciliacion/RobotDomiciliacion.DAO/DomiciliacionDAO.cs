﻿using RobotDomiciliacion.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using AccesoDatos;
using static RobotDomiciliacion.Entidades.Enumeracion;
using SmsMailUtils;
using RobotDomiciliacion.Utils;
using System.Configuration;

namespace RobotDomiciliacion.DAO
{
    public class DomiciliacionDAO
    {
        private DBManager db;
        private IDbConnection dbDapper;

        public Result<string> InsertaHoraRobot(string nombreRobot)
        {
            Result<string> notificacion = new Result<string>();
            try
            {
                using (db = new DBManager(Conexion.ObtenerConexion()))
                {
                    db.Open();
                    //var result= dbDapper.Query("insert HAPE.DBO.registra_hora_robot (hora, tipo, robot) values (getdate(), 'F', '"+ nombreRobot + "')").FirstOrDefault();
                    db.ExecuteReader(System.Data.CommandType.Text, "insert HAPE.DBO.registra_hora_robot (hora, tipo, robot) values (getdate(), 'F', '" + nombreRobot + "')");
                    notificacion.estatus = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //throw ex;
            }
            return notificacion;
        }


        public Result<string> InsertaEntradaLogProcesosCriticos(int idProceso, DateTime fecha, int inicio, int status, string observaciones, int idGrupo)
        {
            Result<string> result = new Result<string>();
            try
            {
                using (db = new DBManager(Conexion.ObtenerConexion()))
                {
                    db.Open();
                    db.CreateParameters(6);
                    db.AddParameters(0, "@id_proceso", idProceso);
                    db.AddParameters(1, "@fecha", fecha);
                    db.AddParameters(2, "@inicio", inicio);
                    db.AddParameters(3, "@status", status);
                    db.AddParameters(4, "@observaciones", observaciones);
                    db.AddParameters(5, "@id_grupo", idGrupo == 0 ? (object)DBNull.Value : idGrupo);
                    db.ExecuteReader(CommandType.StoredProcedure, "HAPE.DBO.SP_CMV_INSERTA_ENTRADA_LOG_PROCESOS_CRITICOS");
                    if (db.DataReader.Read())
                    {
                        result.estatus = Convert.ToInt16(db.DataReader["status"]) == 1 ? true : false;
                        result.id = string.IsNullOrEmpty(db.DataReader["id_grupo"].ToString()) ? 0 : Convert.ToInt16(db.DataReader["id_grupo"]);
                        result.mensaje = db.DataReader["error_message"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        public int ObtenerInfoProcesoCritico(string nombreRobot)
        {
            int idProcesoCritico = 0;
            try
            {
                using (db = new DBManager(Conexion.ObtenerConexion()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@DescProceso", nombreRobot);
                    db.ExecuteReader(CommandType.StoredProcedure, "HAPE.DBO.SP_CMV_OBTENER_INFORMACION_PROCESO_CRITICO");
                    if (db.DataReader.Read())
                    {
                        idProcesoCritico = Convert.ToInt16(db.DataReader["status"]) == 1 ? Convert.ToInt16(db.DataReader["id_proceso"]) : 0;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return idProcesoCritico;
        }

        public List<Notificacion> ObtenerNotificacionSocio(string Numero, TipoBitacora tipoBitacora, Int64? IdDomiciliacion = null)
        {
            List<Notificacion> notificaciones = new List<Notificacion>();
            Notificacion notificacion = null;
            try
            {
                using (db = new DBManager(Conexion.ObtenerConexion()))
                {
                    db.Open();
                    db.CreateParameters(6);
                    db.AddParameters(0, "@numeroSocio", Numero);
                    db.AddParameters(1, "@id_tipo_bitacora", tipoBitacora);
                    db.AddParameters(2, "@id_tipo_notificacion", DBNull.Value);
                    db.AddParameters(3, "@noCel", DBNull.Value);
                    db.AddParameters(4, "@correo", DBNull.Value);
                    db.AddParameters(5, "@IdDomiciliacionSocio", IdDomiciliacion);
                    db.ExecuteReader(CommandType.StoredProcedure, "SP_BANCA_OBTENER_NOTIFICACION");

                    if (db.DataReader.Read())
                    {
                        if (db.DataReader["estatus"].ToString().Equals("200"))
                        {
                            if (db.DataReader.NextResult())
                            {
                                while (db.DataReader.Read())
                                {
                                    notificacion = new Notificacion();
                                    {
                                        notificacion.celular = db.DataReader["celular"] == DBNull.Value ? "" : db.DataReader["celular"].ToString();
                                        notificacion.correo = db.DataReader["correo"] == DBNull.Value ? "" : db.DataReader["correo"].ToString();
                                        notificacion.idTipoNotificacion = (TIPO_NOTIFICACION)Convert.ToInt16(db.DataReader["idTipoNotificacion"].ToString());
                                        notificacion.cuerpo = db.DataReader["cuerpo"] == DBNull.Value ? null : db.DataReader["cuerpo"].ToString();
                                        notificacion.asunto = db.DataReader["asunto"] == DBNull.Value ? null : db.DataReader["asunto"].ToString();
                                        if (db.DataReader["correo"] != DBNull.Value)
                                        {
                                            notificacion.para.Add(db.DataReader["correo"].ToString());
                                        }
                                    };
                                    notificaciones.Add(notificacion);
                                }
                            }
                        }
                        else
                        {
                            new Logg().Error("Al obtener las notificaciones: " + db.DataReader["mensaje"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                new Logg().Error("Al obtener las notificaciones: " + ex.Message);
            }

            return notificaciones;

        }



        public Result<string> RegistraPagoDomiciliado(PagoDomiciliado servicio, EstatusPago estatusPago)
        {
            Result<string> notificacion = new Result<string>();
            try
            {

                using (db = new DBManager(Conexion.ObtenerConexion()))
                {
                    db.Open();
                    db.CreateParameters(19);
                    db.AddParameters(0, "@id_domiciliacion", servicio.idDomiciliacion);
                    db.AddParameters(1, "@id_banca_folio", servicio.FolioBanca);
                    db.AddParameters(2, "@fecha_pago_domiciliado", servicio.fechaPago);
                    db.AddParameters(3, "@numero_autorizacion_servicio", servicio.FolioAutorizacion);
                    db.AddParameters(4, "@clabe_corresponsalias_retiro", servicio.ClabeCorresponsaliasRetiro);
                    db.AddParameters(5, "@clabe_corresponsalias_deposito", servicio.clabeCorresponsaliasDeposito);
                    db.AddParameters(6, "@id_producto", servicio.IdProducto);
                    db.AddParameters(7, "@id_servicio", servicio.IdServicio);
                    db.AddParameters(8, "@numero_referencias", servicio.NumeroReferencia);
                    db.AddParameters(9, "@monto", servicio.Monto);
                    db.AddParameters(10, "@id_tipo_domiciliacion", servicio.tipoDomiciliacion);
                    db.AddParameters(11, "@id_estatus_gesto_pago", servicio.Codigo);
                    db.AddParameters(12, "@id_estatus_pago_banca", estatusPago);
                    db.AddParameters(13, "@decripcion_mensaje_pago", servicio.Mensaje);
                    db.AddParameters(14, "@telefono", servicio.Telefono);
                    db.AddParameters(15, "@monto_pagado", servicio.montoPagado);
                    db.AddParameters(16, "@numero_socio", servicio.NumeroSocio);
                    db.AddParameters(17, "@id_mov_retiro", servicio.idMovCtaRetiro);
                    db.AddParameters(18, "@tipoOrigen", servicio.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_INSERTA_PAGO_DOMICILIADO");
                    if (db.DataReader.Read())
                    {

                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            notificacion.estatus = true;
                            if (estatusPago != EstatusPago.Error && Convert.ToInt32(db.DataReader["id_tipo_bitacora"]) > 0)
                            {
                                //int horaInicioNotificacionesBanca = Convert.ToInt32(ConfigurationManager.AppSettings["HoraInicioNotificaciones"].ToString());
                                //int horaFinNotificacionesBanca = Convert.ToInt32(ConfigurationManager.AppSettings["HoraFinNotificaciones"].ToString());
                                List<Notificacion> notificaciones = new List<Notificacion>();
                                notificaciones = ObtenerNotificacionSocio(servicio.NumeroSocio, (TipoBitacora)(db.DataReader["id_tipo_bitacora"]), servicio.idDomiciliacion);
                                foreach (var notificacionP in notificaciones)
                                {
                                    InsertarNotificacionPendiente(Convert.ToInt64(servicio.NumeroSocio), notificacionP);
                                }

                                /*if (DateTime.Now.Hour >= horaInicioNotificacionesBanca && DateTime.Now.Hour < horaFinNotificacionesBanca)
                                {
                                    //SmsMail.validarTipoNotificaion(notificaciones);

                                    foreach (var notificacionPendiente in notificaciones)
                                    {
                                        Dictionary<string, string> resultado = null;

                                        if (notificacionPendiente.idTipoNotificacion == TIPO_NOTIFICACION.SMS)
                                        {
                                            resultado = SmsMailUtils.SmsMail.SendSms(notificacionPendiente);
                                        }
                                        else if (notificacionPendiente.idTipoNotificacion == TIPO_NOTIFICACION.CORREO_ELECTRONICO)
                                        {
                                            resultado = SmsMailUtils.SmsMail.SendCorreExterno(notificacionPendiente);
                                        }
                                    }

                                }
                                else
                                {
                                    foreach (var notificacionP in notificaciones)
                                    {
                                        InsertarNotificacionPendiente(Convert.ToInt64(servicio.NumeroSocio), notificacionP);
                                    }   
                                }*/
                            }                            
                        }
                        else
                        {
                            notificacion.estatus = false;
                            notificacion.mensaje = db.DataReader["mensaje"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
            return notificacion;
        }
        public List<PagoDomiciliado> ObtenerPagosDomiciliados(DateTime fecha, TipoDomiciliacion tipoDomiciliacion, Boolean PendienteAplicar)
        {
            List<PagoDomiciliado> pagosDomiciliados = new List<PagoDomiciliado>();
            try
            {
                using (db = new DBManager(Conexion.ObtenerConexion()))
                {

                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "@fecha", fecha);
                    db.AddParameters(1, "@id_tipo_domiciliacion", tipoDomiciliacion);
                    db.AddParameters(2, "@pendiente", PendienteAplicar);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_PAGOS_DOMICILIADOS");

                    while (db.DataReader.Read())
                    {
                        PagoDomiciliado pagoDomiciliado = new PagoDomiciliado();

                        pagoDomiciliado.idDomiciliacion = Convert.ToInt64(db.DataReader["id_domiciliacion"]);
                        pagoDomiciliado.ClabeCorresponsaliasRetiro = db.DataReader["clabe_corresponsalias_retiro"].ToString();
                        pagoDomiciliado.clabeCorresponsaliasDeposito = db.DataReader["clabe_corresponsalias_deposito"].ToString();
                        pagoDomiciliado.montoMaximo = Convert.ToDecimal(db.DataReader["monto_maximo"].ToString());
                        pagoDomiciliado.tipoDomiciliacion = (TipoDomiciliacion)db.DataReader["id_tipo_domiciliacion"];
                        pagoDomiciliado.IdProducto = Convert.ToInt32(db.DataReader["id_producto"]);
                        pagoDomiciliado.IdServicio = Convert.ToInt32(db.DataReader["id_servicio"]);
                        pagoDomiciliado.Alias = db.DataReader["alias"].ToString();
                        pagoDomiciliado.TipoFront = Convert.ToInt32(db.DataReader["tipo_front"]);
                        pagoDomiciliado.NumeroReferencia = db.DataReader["numero_referencia"].ToString();
                        pagoDomiciliado.Telefono = db.DataReader["telefono"].ToString();
                        pagoDomiciliado.MontoComision = Convert.ToDecimal(db.DataReader["comision_cmv"]);
                        pagoDomiciliado.Precio = Convert.ToDecimal(db.DataReader["precio"].ToString());
                        pagoDomiciliado.numPtmo = db.DataReader["num_ptmo"].ToString();
                        pagoDomiciliado.idMov = Convert.ToInt32(db.DataReader["id_mov"].ToString());
                        pagoDomiciliado.Monto = Convert.ToDecimal(db.DataReader["monto"].ToString());
                        pagoDomiciliado.activo = Convert.ToBoolean(db.DataReader["activo"].ToString());
                        pagoDomiciliado.NumeroSocio = db.DataReader["numero_socio"].ToString();
                        pagoDomiciliado.fechaPago = Convert.ToDateTime(db.DataReader["fecha_pago"]);
                        pagoDomiciliado.porMontoRequerido = Convert.ToBoolean(db.DataReader["por_monto_requerido"]);
                        pagoDomiciliado.requierePagoCompleto = Convert.ToBoolean(db.DataReader["requiere_pago_completo"]);
                        pagoDomiciliado.idMovCtaRetiro = Convert.ToInt32(db.DataReader["id_mov_cuenta_retiro"]);
                        pagoDomiciliado.TipoOrigen = TipoOrigen.ROBOTDOMICILIACION;
                        pagosDomiciliados.Add(pagoDomiciliado);

                    }


                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return pagosDomiciliados;
        }


        public decimal ObtenerSaldoCtaRetiro(string numeroSocio, int idMov)
        {
            decimal SaldoCtaRetiro = 0;
            try
            {
                using (db = new DBManager(Conexion.ObtenerConexion()))
                {
                    db.Open();
                    //var result= dbDapper.Query("insert HAPE.DBO.registra_hora_robot (hora, tipo, robot) values (getdate(), 'F', '"+ nombreRobot + "')").FirstOrDefault();
                    db.ExecuteReader(System.Data.CommandType.Text, "select HAPE.dbo.FN_OBTENER_SALDO_DISPONIBLE_CTA_HABER(" + numeroSocio + "," + idMov + ",1) saldo");

                    if (db.DataReader.Read())
                    {
                        SaldoCtaRetiro = Convert.ToDecimal(db.DataReader["saldo"]);
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
                //throw ex;
            }
            return SaldoCtaRetiro;
        }

        public bool InsertarNotificacionPendiente(Int64 numSocio, Notificacion notificacion)
        {
            bool seRegistroNotificacon = false;
            try
            {
                using (db = new DBManager(Conexion.ObtenerConexion()))
                {
                    db.Open();
                    db.CreateParameters(6);
                    db.AddParameters(0, "@numero_socio", numSocio);
                    db.AddParameters(1, "@celular", notificacion.celular);
                    db.AddParameters(2, "@correo", notificacion.correo);
                    db.AddParameters(3, "@id_tipo_notificacion", notificacion.idTipoNotificacion);
                    db.AddParameters(4, "@cuerpo", notificacion.cuerpo);
                    db.AddParameters(5, "@asunto", notificacion.asunto);
                    db.ExecuteReader(CommandType.StoredProcedure, "BANCA.DBO.SP_CMV_REGISTRAR_NOTIFICACION_PENDIENTE_SOCIO");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            seRegistroNotificacon = true;
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return seRegistroNotificacon;
        }

        #region Servicios Domiciliados
        public Result<string> RealizarPagoServicio(PagoDomiciliado servicio, bool esConsulta)
        {
            Result<string> notificacion = new Result<string>();
            try
            {

                using (db = new DBManager(Conexion.ObtenerConexion()))
                {
                    db.Open();
                    db.CreateParameters(12);
                    db.AddParameters(0, "ClabeCorresponsaliasRetiro", servicio.ClabeCorresponsaliasRetiro);
                    db.AddParameters(1, "NumeroSocio", servicio.NumeroSocio);
                    db.AddParameters(2, "monto", servicio.Monto);
                    db.AddParameters(3, "IdProducto", servicio.IdProducto);
                    db.AddParameters(4, "idServicio", servicio.IdServicio);
                    db.AddParameters(5, "numeroReferencia", servicio.NumeroReferencia);
                    db.AddParameters(6, "telefono", servicio.Telefono);
                    db.AddParameters(7, "idTipoPersona", 1);
                    db.AddParameters(8, "@idTipoFront", servicio.TipoFront);
                    db.AddParameters(9, "tipo_origen", servicio.TipoOrigen);
                    db.AddParameters(10, "esConsulta", esConsulta);
                    db.AddParameters(11, "id_domiciliacion", servicio.idDomiciliacion);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_REALIZA_PAGO_SERVICIO");
                    if (db.DataReader.Read())
                    {

                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            notificacion.estatus = true;
                            notificacion.FolioBanca = Convert.ToInt64(string.IsNullOrEmpty(db.DataReader["id_folio_banca"].ToString()) ? "0" : db.DataReader["id_folio_banca"].ToString());
                            notificacion.necesitaPin = Convert.ToBoolean(db.DataReader["necesitaPin"]);
                            notificacion.Leyenda = string.IsNullOrEmpty(db.DataReader["leyenda"].ToString()) ? "" : db.DataReader["leyenda"].ToString();
                        }
                        else
                        {
                            notificacion.estatus = false;
                            notificacion.mensaje = db.DataReader["mensaje"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
            return notificacion;
        }

        public Result<string> ActualizarPagoDeServicio(PagoDomiciliado request)
        {
            Result<string> notificacion = new Result<string>();
            try
            {
                using (db = new DBManager(Conexion.ObtenerConexion()))
                {

                    db.Open();
                    db.CreateParameters(11);
                    db.AddParameters(0, "@idBancaFolio", request.FolioBanca);
                    db.AddParameters(1, "@codigo", Convert.ToInt16(request.Codigo));
                    db.AddParameters(2, "@folioAutorizacion", request.FolioAutorizacion);
                    db.AddParameters(3, "@mensaje", request.Mensaje);
                    db.AddParameters(4, "@pin", request.Pin);
                    db.AddParameters(5, "@monto", request.Monto);
                    db.AddParameters(6, "@request", request.request);
                    db.AddParameters(7, "@response", request.response);
                    db.AddParameters(8, "@signed", request.signed);
                    db.AddParameters(9, "@tipoOrigen", request.TipoOrigen);
                    db.AddParameters(10, "@id_domiciliacion", request.idDomiciliacion);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ACTUALIZA_ESTATUS_PAGO_SERVICIO");
                    if (db.DataReader.Read())
                    {

                        if (string.Compare(db.DataReader["estatus"].ToString(), "200") == 0 && db.DataReader["codigo"].ToString().Equals("1"))
                        {
                            notificacion.estatus = true;
                        }
                        else
                        {
                            notificacion.estatus = false;
                            notificacion.mensaje = db.DataReader["mensaje"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return notificacion;
        }

        public Result<PagoDomiciliado> ObtenerServicioConsulta(int idServicio, int idTipoFront)
        {
            Result<PagoDomiciliado> notificacion = new Result<PagoDomiciliado>();
            try
            {

                using (db = new DBManager(Conexion.ObtenerConexion()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@IdServicio", idServicio);
                    db.AddParameters(1, "@tipo_front", idTipoFront);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_PRODUCTOS_PAGO_SERVICIOS");
                    if (db.DataReader.Read())
                    {

                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {

                            if (db.DataReader.NextResult())
                            {
                                if (db.DataReader.Read())
                                {
                                    notificacion.estatus = true;
                                    notificacion.result = new PagoDomiciliado();
                                    notificacion.result.IdServicio = Convert.ToInt32(db.DataReader["id_servicios_pago"].ToString());
                                    notificacion.result.IdProducto = Convert.ToInt32(db.DataReader["id_producto"].ToString());
                                    notificacion.result.TipoFront = Convert.ToInt32(db.DataReader["tipo_front"].ToString());
                                }

                            }

                        }
                        else
                        {
                            notificacion.estatus = false;
                            notificacion.mensaje = db.DataReader["mensaje"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
            return notificacion;
        }

        #endregion

        #region Prestamos Domiciliados
        public Result<string> ObtenerDetallePtmo(PagoDomiciliado pagoDomiciliado)
        {
            Result<string> result = new Result<string>();
            try
            {
                using (db = new DBManager(Conexion.ObtenerConexion()))
                {

                    db.Open();
                    db.CreateParameters(4);
                    db.AddParameters(0, "@ClabeCorresponsalias", pagoDomiciliado.clabeCorresponsaliasDeposito);
                    db.AddParameters(1, "@tipoOrigen", pagoDomiciliado.TipoOrigen);
                    db.AddParameters(2, "@numeroSocio", pagoDomiciliado.NumeroSocio);
                    db.AddParameters(3, "@id_domiciliacion", pagoDomiciliado.idDomiciliacion);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_DETALLE_PRESTAMO");

                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            result.estatus = true;
                            result.monto = db.DataReader["PagoAlDiaDeHoy"] == DBNull.Value ? 0 : Convert.ToDecimal(db.DataReader["PagoAlDiaDeHoy"].ToString());
                            result.montoLiquidacion = db.DataReader["PagoParaLiquidar"] == DBNull.Value ? 0 : Convert.ToDecimal(db.DataReader["PagoParaLiquidar"].ToString());
                            result.montoMinimo = db.DataReader["pago_minimo"] == DBNull.Value ? 0 : Convert.ToDecimal(db.DataReader["pago_minimo"].ToString());
                        }
                        else
                        {
                            result.estatus = (db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"])) == 200 ? true : false;
                            result.mensaje = db.DataReader["mensaje"].ToString();
                        }
                    }


                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public Result<string> PagarPtmo(PagoDomiciliado pagoDomiciliado, TipoAnticipo tipoAnticipo)
        {
            Result<string> result = new Result<string>();
            try
            {
                using (db = new DBManager(Conexion.ObtenerConexion()))
                {

                    db.Open();
                    db.CreateParameters(6);
                    db.AddParameters(0, "clabeCorresponsaliasRetiro ", pagoDomiciliado.ClabeCorresponsaliasRetiro);
                    db.AddParameters(1, "clabeCorresponsaliasDeposito ", pagoDomiciliado.clabeCorresponsaliasDeposito);
                    db.AddParameters(2, "Monto ", pagoDomiciliado.montoPagado);
                    db.AddParameters(3, "TipoAnticipo ", tipoAnticipo);
                    db.AddParameters(4, "TipoOrigen ", pagoDomiciliado.TipoOrigen);
                    db.AddParameters(5, "id_domiciliacion", pagoDomiciliado.idDomiciliacion);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_PAGAR_PRESTAMO");

                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            result.estatus = true;
                            result.FolioBanca = Convert.ToInt64(db.DataReader["folio"].ToString());
                            result.monto = string.IsNullOrEmpty(db.DataReader["Monto"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["Monto"].ToString());
                        }
                        else
                        {
                            result.estatus = (db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"])) == 200 ? true : false;
                            result.mensaje = db.DataReader["error_messag"].ToString();
                        }
                    }


                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }


        #endregion



    }
}
