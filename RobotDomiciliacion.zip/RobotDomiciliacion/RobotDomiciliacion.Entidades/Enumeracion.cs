﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotDomiciliacion.Entidades
{
    public class Enumeracion
    {
        public enum TipoOrigen
        {
            MOVIL = 1,
            SUCURSAL = 2,
            BANCA_WEB_ = 3,
            DATABANKING = 4,
            ROBOTDOMICILIACION=13

        }

        public enum TipoBitacora
        {
            Pago_servicio_domiciliado=25,
            Pago_de_servicio_domiciliado_rechazado = 101,
            Pago_de_préstamo_domiciliado = 102,
            Pago_de_préstamo_domiciliado_rechazado = 103
        }

        public enum TipoDomiciliacion
        {
            
            Prestamos = 1,            
            Haberes = 2,           
            PagoServicios = 3,
        }

        public enum EstatusPago
        {
            Pendiente=1,
            Aplicado=2,
            NoAplicado=3,
            Cancelado=4,
            Error=5
        }

        public enum TipoAnticipo
        {
        
            Ninguno = 1,           
            ReduccionPlazo = 2,           
            ReduccionAmortizacion = 3,         
            PagoParaAdelantar = 4

        }
    }
}
