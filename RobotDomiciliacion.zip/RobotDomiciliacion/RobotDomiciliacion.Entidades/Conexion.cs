﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotDomiciliacion.Entidades
{
    public static class Conexion
    {
        public static string Servidor { get; set; }
        /// <summary>
        /// Representa la base de datos
        /// </summary>
        public static string BaseDatos { get; set; }
        /// <summary>
        /// Identifica el usuario con el que nos conectaremos al sistema
        /// </summary>
        public static string Usuario { get; set; }
        /// <summary>
        /// Identifica la contraseña del usuario
        /// </summary>
        public static string Password { get; set; }


        public static string ObtenerConexion()
        {            
            return "Server=" + Servidor + ";Database=" + BaseDatos + ";User Id=" + Usuario + ";Password=" + Password;          

        }
    }
}
