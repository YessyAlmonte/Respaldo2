﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotDomiciliacion.Entidades
{
    public class Result<T> where T:class
    {
        public string mensaje { get; set; }
        public Boolean estatus { get; set; }
        public T result { get; set; }

        public Int64 FolioBanca { get; set; }
        public Boolean necesitaPin { get; set; }
        public decimal monto { get; set; }
        public decimal montoLiquidacion { get; set; }
        public decimal montoMinimo { get; set; }
        public decimal saldoAdelanto { get; set; }
        public string Leyenda { get; set; }
        public int id { get; set; }




    }
}
