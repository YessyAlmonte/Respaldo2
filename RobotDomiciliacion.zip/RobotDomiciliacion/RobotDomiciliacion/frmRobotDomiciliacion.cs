﻿using AutoMapper;
using RobotDomiciliacion.BLL;
using RobotDomiciliacion.Entidades;
using RobotDomiciliacion.Utils;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Net.Mail;
using System.Runtime.InteropServices;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading;
using System.Windows.Forms;

namespace RobotDomiciliacion
{
    #region structs

    internal struct Report
    {
        internal string message;
        internal int overallProgress;
        internal Boolean status;
    }

    #endregion structs

    #region enums

    internal enum Close_ { _ }
    internal enum Execute { _ }
    internal enum Minimize { _ }
    internal enum Start { _ }
    internal enum Stop { _ }

    #endregion enums

    public partial class frmRobotDomiciliacion : System.Windows.Forms.Form
    {
        #region PERSONALIZABLES

        // Parametrización interna del robot

        private bool
            use_next_day_default = false,
            auto_close_default = true;

        #endregion PERSONALIZABLES

        #region fields

        //private Boolean adjustingDateTime;

        private Bitmap
            closeWhite = global::RobotDomiciliacion.Properties.Resources.close_white,
            minusWhite = global::RobotDomiciliacion.Properties.Resources.minus_white,
            playWhite = global::RobotDomiciliacion.Properties.Resources.play_white,
            closeDark = global::RobotDomiciliacion.Properties.Resources.close_dark,
            minusDark = global::RobotDomiciliacion.Properties.Resources.minus_dark,
            playDark = global::RobotDomiciliacion.Properties.Resources.play_dark;

        private Boolean executing = false, finalized = false;
        private MailManager mail;
        private List<MailAddress> mailRecipientsList = new List<MailAddress>();
        private MailAddress mailSenderAccount;

        private Color
            red = Color.FromArgb(192, 0, 0),
            //green = Color.FromArgb(120, 150, 80),
            blue = Color.FromArgb(200, 20, 60, 140),
            control = Color.FromKnownColor(KnownColor.Control),
            controlDark = Color.FromKnownColor(KnownColor.ControlDark),
            controlLight = Color.FromKnownColor(KnownColor.ControlLight);

        private Report report = new Report();

        private string
            robotName,
            mailServer,
            robotMail,
            colorMailHighlight;

        private int
            step,
            waitStart,
            waitClose,
            errors_count = 0;

        //Dependencia
        private int iIdProcesoCritico = 0, iIdGrupo = 0;

        private DateTime usingDateTime;
        private DomiciliacionBLL bll = new DomiciliacionBLL();
        private Logg logg = new Logg();

        #endregion fields

        #region constructors

        /// <summary>
        /// Constructor
        /// </summary>
        public frmRobotDomiciliacion()
        {
            InitializeComponent();
            InitializeApplication();
        }

        #endregion constructors

        #region drag override

        // auxiliares para la reubicación de la ventana sin borde

        public const int HT_CAPTION = 0x2;

        public const int WM_NCLBUTTONDOWN = 0xA1;

        [DllImportAttribute("user32.dll")]
        internal static extern bool ReleaseCapture();

        [DllImportAttribute("user32.dll")]
        internal static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        #endregion drag override

        #region CUSTOMIZABLE MEMBERS

        /// <summary>
        /// Realiza las tareas del robot en segundo plano
        /// </summary>
        private void ExecuteBackgroundWork()
        {
            Boolean                
                abort_on_error = true;  // true si desea saltar el resto de las tareas en caso de error,

            Result<string> result = new Result<string>();
            
            //o false si desea continuar la ejecucion de las tareas pendientes

            //Se agrega nuevo control de inicio y fin de los procesos que son dependientes y necesarios para la operacion
            result = TaskInsertaEntradaLogProcesosCriticos("Se inicia correctamente proceso de " + robotName, "Ejecución de SP_CMV_INSERTA_ENTRADA_LOG_PROCESOS_CRITICOS terminada", 5, 1, 1);
            //bInicioCorrecto = result;
            if (!result.estatus && abort_on_error)
            {
                goto _SEND_FINALIZE_NOTIFICATIONS;
            }

            // se reporta el inicio del robot en la base [debe iniciar en 0]
            result = new Result<string>();
            result = Mark("Escribiendo inicio de robot en la base", "Inicio de robot escrito en la base", 0, Start._);
            if (!result.estatus && abort_on_error) goto _SEND_FINALIZE_NOTIFICATIONS;

            // se llama la función de envío de correo de inicio [se deja fijo]
            result = SendMails("Enviando correo de inicio", "Correo de inicio enviado", 1, Start._);
            if (!result.estatus && abort_on_error) goto _SEND_FINALIZE_NOTIFICATIONS;

            // se ejecuta(n) la(s) tarea(s) del robot


            //prestamos domiciliados pendientes
            result = new Result<string>();
            result = PrestamosDomiciliados("Iniciando procedimiento pagos de prestamos domiciliados pendientes", "Procedimiento fin pago de prestamos domiciliados pendientes", 30, true);
            if (!result.estatus && abort_on_error) goto _SEND_FINALIZE_NOTIFICATIONS;

            //prestamos domiciliados
            result = PrestamosDomiciliados("Iniciando procedimiento pagos de prestamos domiciliados", "Procedimiento fin pago de prestamos domiciliados", 30, false);
            if (!result.estatus && abort_on_error) goto _SEND_FINALIZE_NOTIFICATIONS;

            //servicios domiciliados
            result = new Result<string>();
            result = ServiciosDomiciliados("Iniciando procedimiento pago de servicios domiciliados", "Procedimiento fin pago de servicios domiciliados", 20);
            if (!result.estatus && abort_on_error) goto _SEND_FINALIZE_NOTIFICATIONS;

            //migración a productivo si es la de diario
            //result = Task2("Iniciando procedimiento SP_2", "Procedimiento SP_2 finalizado", 97);
            //if (!result && abort_on_error) goto _SEND_FINALIZE_NOTIFICATIONS;

            // inicio de notificaciones de fin
            _SEND_FINALIZE_NOTIFICATIONS:
            {

                if (!result.estatus && abort_on_error)
                    TaskInsertaEntradaLogProcesosCriticos("Se termina con error el proceso de " + robotName + " en: " + result.mensaje, "Finalizando ejecución de " + robotName, 95, 0, 0);
                else
                    TaskInsertaEntradaLogProcesosCriticos("Finalizando ejecución de " + robotName, "Finalizando ejecución de " + robotName + " terminada", 95, 1, 0);


                // se reporta el fin
                Mark("Escribiendo fin de robot en la base", "Fin de robot escrito en la base", 98, Stop._);

                // se llama la función de envío de correo de fin [se deja fijo]
                SendMails("Enviando correo de fin", "Correo de fin enviado", 99, Stop._);

                // se finaliza el robot [debe finalizar en 100]
                Finalize("Finalizando el robot", 100);
            }
        }

        #region TASKS DEFINITION

        /// <summary>
        /// Funcion que se realiza para insertar en el log el proceso critico
        /// </summary>
        /// <param name="startMessage"></param>
        /// <param name="endMessage"></param>
        /// <param name="overallAdvanceReported"></param>
        /// <param name="iStatus"></param>
        /// <param name="iInicioFin"></param>
        /// <returns></returns>
        private Result<string> TaskInsertaEntradaLogProcesosCriticos(string startMessage, string endMessage, int overallAdvanceReported, int iStatus, int iInicioFin)
        {
            Result<string> result = new Result<string>();
            DateTime fecha = FechaDTPicker.Value;
            string sql = string.Empty;
            string sStringConection = string.Empty;
            ReportAdvance(startMessage);
            try
            {
                result = bll.InsertaEntradaLogProcesosCriticos(iIdProcesoCritico, fecha, iInicioFin, iStatus, startMessage, iInicioFin == 0 ? iIdGrupo : 0);
                if (result.estatus)
                    iIdGrupo = result.id;
            }
            catch (Exception ex)
            {
                errors_count++;
                LogException(ex);
                logg.Error("Se produjo un error en el proceso InsertaEntradaLogProcesosCriticos. \nDetalles: " + ex.Message);
                result.mensaje = "Se produjo un error en el proceso InsertaEntradaLogProcesosCriticos.";
                result.estatus = false;
            }
            ReportAdvance(endMessage + " " + result.mensaje, overallAdvanceReported, result.estatus);
            return result;
        }


        /// <summary>
        /// Función que realiza la reindexación de la tabla captura_lacp
        /// </summary>
        /// <param name="startMessage">Mensaje cuando inicia la tarea</param>
        /// <param name="endMessage">Mensaje cuando finaliza la tarea</param>
        /// <param name="overallAdvanceReported">Porcentaje global de avance al finalizar la tarea</param>
        /// <returns>Booleano que indica el estatus de la tarea</returns>
        private Result<string> ServiciosDomiciliados(string startMessage, string endMessage, int overallAdvanceReported)
        {
            Result<string> result = new Result<string>();
            result.estatus = true;
            ReportAdvance(startMessage);
            long totalPagos = 0, aplicados = 0, noAplicados = 0;
            try
            {
                List<PagoDomiciliado> listPagosDomiciliados = bll.ObtenerPagosDomiciliados(Convert.ToDateTime(string.Format("{0:dd/MM/yyyy}", usingDateTime)), Enumeracion.TipoDomiciliacion.PagoServicios, false);

                foreach (PagoDomiciliado pagoDomiciliado in listPagosDomiciliados)
                {
                    try
                    {

                        pagoDomiciliado.saldoCtaRetiro = bll.ObtenerSaldoCtaRetiro(pagoDomiciliado.NumeroSocio, pagoDomiciliado.idMovCtaRetiro);

                        Result<PagoDomiciliado> resultServConsulta = bll.ObtenerServicioConsulta(pagoDomiciliado.IdServicio, 4);

                        if (!resultServConsulta.estatus)
                        {
                            noAplicados = noAplicados + 1;
                            //pagoDomiciliado.Mensaje = "Servicio Domiciliado No Aplicado: " + pagoDomiciliado.Alias + " ," + "Error al consultar el saldo: " + resultServConsulta.mensaje;
                            pagoDomiciliado.Mensaje = resultServConsulta.mensaje;
                            ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.NoAplicado);
                            continue;
                        }


                        PagoDomiciliado requestConsulta = new PagoDomiciliado();
                        requestConsulta.ClabeCorresponsaliasRetiro = "";
                        requestConsulta.IdProducto = resultServConsulta.result.IdProducto;
                        requestConsulta.IdServicio = resultServConsulta.result.IdServicio;
                        requestConsulta.NumeroReferencia = pagoDomiciliado.NumeroReferencia;
                        //requestConsulta.OTP
                        requestConsulta.Precio = 0;
                        requestConsulta.Monto = 0;
                        requestConsulta.MontoComision = 0;
                        requestConsulta.Telefono = "";
                        requestConsulta.TipoFront = 4;
                        requestConsulta.NumeroSocio = pagoDomiciliado.NumeroSocio;
                        requestConsulta.idDomiciliacion = pagoDomiciliado.idDomiciliacion;
                        requestConsulta.TipoOrigen = pagoDomiciliado.TipoOrigen;                        

                        //INSERTAMOS EN LA TABLA DE TRANSFERENCIAS DE PAGO
                        Result<string> n = bll.RealizarPagoServicio(requestConsulta, true);               


                        if (!n.estatus)
                        {
                            noAplicados = noAplicados + 1;
                            //pagoDomiciliado.Mensaje = "Servicio Domiciliado No Aplicado: " + pagoDomiciliado.Alias + " ," + "Error al registar en la BD la consulta de servicio: " + n.mensaje;
                            pagoDomiciliado.Mensaje = n.mensaje;
                            ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.NoAplicado);
                            continue;
                        }
                        requestConsulta.FolioBanca = n.FolioBanca;
                        requestConsulta.EnvioUpc = requestConsulta.FolioBanca;
                        requestConsulta.HoraLocal = DateTime.Now.ToString("yyyyMMddHHmmss");

                        PagoDomiciliado resultConsulta = this.ConsumirServicioPago(requestConsulta, 1);


                        if (!resultConsulta.estatus)
                        {
                            noAplicados = noAplicados + 1;
                            //pagoDomiciliado.Mensaje = "Servicio Domiciliado No Aplicado: " + pagoDomiciliado.Alias + " ," + "Error al consumir el servicio de consulta saldo del socio: " + resultConsulta.Mensaje;
                            pagoDomiciliado.FolioBanca = resultConsulta.FolioBanca;
                            pagoDomiciliado.Mensaje = resultConsulta.Mensaje;
                            ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.NoAplicado);
                            continue;
                        }

                        pagoDomiciliado.Monto = resultConsulta.Monto;


                        if (pagoDomiciliado.Monto <= 0)
                        {
                            noAplicados = noAplicados + 1;
                            //pagoDomiciliado.Mensaje = "Servicio Domiciliado No Aplicado: " + pagoDomiciliado.Alias + " ," + "El monto de pago es menor o igual a 0: " + pagoDomiciliado.Monto;
                            pagoDomiciliado.Mensaje = "Sin Adeudo";
                            pagoDomiciliado.FolioBanca = resultConsulta.FolioBanca;
                            ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.NoAplicado);
                            continue;
                        }


                        if (pagoDomiciliado.Monto > pagoDomiciliado.montoMaximo)
                        {
                            noAplicados = noAplicados + 1;
                            //pagoDomiciliado.Mensaje = "Servicio Domiciliado No Aplicado: " + pagoDomiciliado.Alias + " ," + "El monto de pago excede del monto máximo: " + pagoDomiciliado.Monto;
                            pagoDomiciliado.Mensaje = "Monto excede al establecido";
                            pagoDomiciliado.FolioBanca = resultConsulta.FolioBanca;
                            ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.NoAplicado);
                            continue;
                        }


                        if (pagoDomiciliado.saldoCtaRetiro < pagoDomiciliado.Monto)
                        {
                            noAplicados = noAplicados + 1;
                            //pagoDomiciliado.Mensaje = "Servicio Domiciliado No Aplicado: " + pagoDomiciliado.Alias + " ," + "No cuenta con el saldo suficiente: " + pagoDomiciliado.saldoCtaRetiro;
                            pagoDomiciliado.Mensaje = "Fondos insuficientes";
                            pagoDomiciliado.FolioBanca = resultConsulta.FolioBanca;
                            ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.NoAplicado);
                            continue;
                        }

                        pagoDomiciliado.ObtenerParametros();//validamos que los parametros monto , referencia ,telefono sean correctos segun el tipoFront
                                                            //SE AFECTA LOS HABERES DEL SOCIO EN CASO DE QUE EXISTA UN ERROR AL TRATA DE AFECAR EDO_DE_CUENTA , MOVIMIENTO Y CAPTUTA SE LANZA UNA EXCEPTION
                        Result<string> pS = bll.RealizarPagoServicio(pagoDomiciliado, false);
                        pagoDomiciliado.FolioBanca = pS.FolioBanca;
                        //SE CONSUME EL WEB SERVICE DE GESTO  DEL PAGO DE SERVICIO
                        pagoDomiciliado.Telefono = pS.necesitaPin ? "#1111111111" : pagoDomiciliado.Telefono;
                        pagoDomiciliado.NumeroReferencia = pagoDomiciliado.NumeroReferencia.Equals("0") ? "" : pagoDomiciliado.NumeroReferencia;
                        pagoDomiciliado.EnvioUpc = pagoDomiciliado.FolioBanca;
                        pagoDomiciliado.HoraLocal = DateTime.Now.ToString("yyyyMMddHHmmss");

                        if (!pS.estatus)
                        {
                            noAplicados = noAplicados + 1;
                            //pagoDomiciliado.Mensaje = "Servicio Domiciliado No Aplicado: " + pagoDomiciliado.Alias + " ," + "Error al registar en la BD el pago de servicio: " + pS.mensaje;
                            pagoDomiciliado.Mensaje = "Servicio no disponible";//pS.mensaje;
                            ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.NoAplicado);
                            continue;
                        }


                        PagoDomiciliado resultPagoServicio = this.ConsumirServicioPago(pagoDomiciliado, 2);
                        resultPagoServicio.montoPagado = resultPagoServicio.estatus == false ? 0 : resultPagoServicio.Monto;

                        // bll.RegistraPagoDomiciliado(resultPagoServicio, resultPagoServicio.estatus == false ? Enumeracion.EstatusPago.NoAplicado : Enumeracion.EstatusPago.Aplicado);

                        if (!resultPagoServicio.estatus)
                        {
                            noAplicados = noAplicados + 1;
                            //pagoDomiciliado.Mensaje = "Servicio Domiciliado No Aplicado: " + pagoDomiciliado.Alias + " ," + "Error al consumir el servicio de pago: " + resultPagoServicio.Mensaje;
                            pagoDomiciliado.Mensaje = resultPagoServicio.Mensaje;
                            ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.NoAplicado);
                            continue;
                        }

                         aplicados = aplicados + 1;
                        //pagoDomiciliado.Mensaje = "Servicio Domiciliado Aplicado: " + pagoDomiciliado.Alias;
                        pagoDomiciliado.Mensaje = "";
                         ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.Aplicado);
                    }
                    catch (Exception ex)
                    {
                        errors_count++;
                        pagoDomiciliado.Mensaje = "Error al realizar el pago de servicio domiciliado del socio: " + pagoDomiciliado.NumeroSocio + " Msg: " + ex.Message;
                        ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.Error);
                        Utilerias.EscribirLog("Error al realizar el pago domiciliado del socio:" + pagoDomiciliado.NumeroSocio + " Alias: " + pagoDomiciliado.Alias + " ," + ex.Message + " " + ex.StackTrace);
                        logg.Error("Error al realizar el pago domiciliado del socio:" + pagoDomiciliado.NumeroSocio + " Alias: " + pagoDomiciliado.Alias + " ," + ex.Message + " " + ex.StackTrace);
                    }

                }

            }
            catch (Exception ex)
            {

                ReportAdvance("Se produjo un error en el metodo PagosDomiciliados: " + ex.Message + " " + ex.StackTrace);
                Utilerias.EscribirLog("Se produjo un error en el metodo PagosDomiciliados: " + ". \nDetalles: " + ex.Message);
                logg.Error("Se produjo un error el robot de domiciliaciones ServiciosDomiciliados: " + ". \nDetalles: " + ex.Message);
                //LogException(ex);
                result.estatus = false;
                result.mensaje = ex.Message;
            }
            ReportAdvance(endMessage + " Total de pagos: " + totalPagos + " Aplicados: " + aplicados + " No aplicados: " + noAplicados, overallAdvanceReported, result.estatus);
            ReportAdvance(endMessage, overallAdvanceReported, result.estatus);
            return result;
        }

        private PagoDomiciliado ConsumirServicioPago(PagoDomiciliado request, int idTipoConsulta)
        {
            RobotDomiciliacion.WsPagoDeServicios._ResponsePagarServicios wsResponsePagarServicio = null;
            RobotDomiciliacion.WsPagoDeServicios._ResponseConsultaSaldo wsResponseConsultaSaldo = null;
            try
            {

                //INSTANCIAMOS UN OBJETO DEL WEB SERVICE
                RobotDomiciliacion.WsPagoDeServicios.PagoDeServiciosClient wsPagoServicios = new RobotDomiciliacion.WsPagoDeServicios.PagoDeServiciosClient();


                //MAPPER PARA CONSUMIR EL WEB SERVICE
                Mapper.Initialize(x =>
                {
                    x.ValidateInlineMaps = false;
                    x.CreateMap<PagoDomiciliado, RobotDomiciliacion.WsPagoDeServicios.RequestPagarServicios>();
                });
                RobotDomiciliacion.WsPagoDeServicios.RequestPagarServicios wsRequest = Mapper.Map<RobotDomiciliacion.WsPagoDeServicios.RequestPagarServicios>(request);
                wsRequest.TipoOrigen = WsPagoDeServicios.TipoOrigen.MOVIL;
                Mapper.Reset();

                //SE CONSUME EL WEB SERVICE DE GESTO  DE PAGO DE SERVICIO
                using (new OperationContextScope(wsPagoServicios.InnerChannel))
                {
                    MessageHeader MessageHeaderUsuario = MessageHeader.CreateHeader("Usuario", "", "CMVF1nZ4S");
                    MessageHeader MessageHeaderContrasena = MessageHeader.CreateHeader("Contrasena", "", "8DED40B6E19F14D1651FDDF063CDD2");
                    OperationContext.Current.OutgoingMessageHeaders.Add(MessageHeaderUsuario);
                    OperationContext.Current.OutgoingMessageHeaders.Add(MessageHeaderContrasena);

                    if (idTipoConsulta == 1)//consulta de saldo
                        wsResponseConsultaSaldo = wsPagoServicios.ConsultarSaldoSerivicio(wsRequest);

                    if (idTipoConsulta == 2) //pago de servicio
                        wsResponsePagarServicio = wsPagoServicios.PagarServicio(wsRequest);

                }

                if (idTipoConsulta == 1)
                {
                    if (wsResponseConsultaSaldo != null)
                    {
                        if (wsResponseConsultaSaldo.EstatusCmv == RobotDomiciliacion.WsPagoDeServicios.EstatusCMV.Ok)
                        {
                            decimal Saldo = string.IsNullOrEmpty(wsResponseConsultaSaldo.ResponseAbonar.MENSAJE.SALDOCLIENTE) ? 0.0M : Convert.ToDecimal(wsResponseConsultaSaldo.ResponseAbonar.MENSAJE.SALDOCLIENTE);
                            request.response = wsResponseConsultaSaldo.response;
                            request.request = wsResponseConsultaSaldo.request;
                            request.Codigo = wsResponseConsultaSaldo.ResponseAbonar.MENSAJE.CODIGO.ToString();
                            request.FolioAutorizacion = wsResponseConsultaSaldo.ResponseAbonar.NUM_AUTORIZACION.ToString();
                            request.Mensaje = string.IsNullOrEmpty(wsResponseConsultaSaldo.ResponseAbonar.MENSAJE.TEXTO) ? wsResponseConsultaSaldo.MensajeCmv : wsResponseConsultaSaldo.ResponseAbonar.MENSAJE.TEXTO;
                            request.signed = wsResponseConsultaSaldo.Signed;
                            Result<string> rs = bll.ActualizarPagoDeServicio(request);
                            request.estatus = rs.estatus;
                            request.Mensaje = rs.mensaje;
                            request.Monto = Saldo;
                        }
                        else
                        {
                            request.estatus = false;
                            request.Mensaje = "Estatus CMV error " + wsResponseConsultaSaldo.EstatusCmv;
                        }
                    }
                    else
                    {
                        request.estatus = false;
                        request.Mensaje = "Servicio no disponible";//"El response wsResponseConsultaSaldo es nulo";
                    }


                }

                //servicio de pago
                if (idTipoConsulta == 2)
                {
                    if (wsResponsePagarServicio != null)
                    {
                        if (wsResponsePagarServicio.EstatusCmv == WsPagoDeServicios.EstatusCMV.Ok)
                        {
                            request.Pin = Convert.ToString(wsResponsePagarServicio.ResponseAbonar.MENSAJE.PIN);
                            request.FolioAutorizacion = wsResponsePagarServicio.ResponseAbonar.NUM_AUTORIZACION.ToString();
                            request.Mensaje = wsResponsePagarServicio.ResponseAbonar.MENSAJE.TEXTO;
                            request.Codigo = wsResponsePagarServicio.ResponseAbonar.MENSAJE.CODIGO.ToString();
                            request.response = wsResponsePagarServicio.response;
                            request.request = wsResponsePagarServicio.request;
                            request.signed = wsResponsePagarServicio.signed;
                            Result<string> responsePagarServicios = bll.ActualizarPagoDeServicio(request);
                            request.estatus = responsePagarServicios.estatus;
                            request.Mensaje = responsePagarServicios.mensaje;
                        }
                        else
                        {
                            request.estatus = false;
                            request.Mensaje = "Estatus CMV error " + wsResponsePagarServicio.EstatusCmv;
                        }
                    }
                    else
                    {
                        request.estatus = false;
                        request.Mensaje = "Servicio no disponible";//"El response wsResponsePagarServicio es nulo";
                    }
                }

            }
            catch (FaultException<WsPagoDeServicios._ExceptionPagarServicios> e)
            {
                //excepcion detonada por el web service 
                request.estatus = false;
                request.Mensaje = "Ocurrio un error en la Api de Gesto pago desarrollada por CMV:| " + e.Message;
                request.Codigo = "-1";
                 bll.ActualizarPagoDeServicio(request);
                request.Mensaje = "Servicio no disponible";

            }
            catch (Exception ex)
            {
                request.estatus = false;
                request.Mensaje = "Ocurrio un error funcion :ConsumirServicioPago()  CMV| " + ex.Message;
                request.Codigo = "-1";
                bll.ActualizarPagoDeServicio(request);
                request.Mensaje = "Servicio no disponible";

            }

            return request;
        }

        private Result<string> PrestamosDomiciliados(string startMessage, string endMessage, int overallAdvanceReported, Boolean pendienteAplicar)
        {
            Result<string> result = new Result<string>();
            result.estatus = true;
            ReportAdvance(startMessage);

            long totalPagos = 0, aplicados = 0, noAplicados = 0;
            try
            {
                List<PagoDomiciliado> listPagosDomiciliados = bll.ObtenerPagosDomiciliados(Convert.ToDateTime(string.Format("{0:dd/MM/yyyy}", usingDateTime)), Enumeracion.TipoDomiciliacion.Prestamos, pendienteAplicar);

                foreach (PagoDomiciliado pagoDomiciliado in listPagosDomiciliados)
                {
                    try
                    {
                        Result<string> resultDetallePtmo = bll.ObtenerDetallePtmo(pagoDomiciliado);

                        if (!resultDetallePtmo.estatus)
                        {
                            noAplicados = noAplicados + 1;
                            //pagoDomiciliado.Mensaje = "El pago domiciliado del ptmo no se aplico: " + pagoDomiciliado.numPtmo + " ,Msg: " + "Error al consultar el detalle del ptmo: " + resultDetallePtmo.mensaje;
                            pagoDomiciliado.Mensaje = resultDetallePtmo.mensaje;
                            ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.Pendiente);
                            continue;
                        }

                        pagoDomiciliado.saldoCtaRetiro = bll.ObtenerSaldoCtaRetiro(pagoDomiciliado.NumeroSocio, pagoDomiciliado.idMovCtaRetiro);
                        pagoDomiciliado.Monto = pagoDomiciliado.porMontoRequerido ? (pendienteAplicar ? resultDetallePtmo.montoMinimo : resultDetallePtmo.monto) : pagoDomiciliado.Monto;
                        pagoDomiciliado.Monto = pagoDomiciliado.Monto > resultDetallePtmo.montoLiquidacion ? resultDetallePtmo.montoLiquidacion : pagoDomiciliado.Monto;

                        if (pagoDomiciliado.Monto <= 0)
                        {
                            noAplicados = noAplicados + 1;
                            //pagoDomiciliado.Mensaje = "El pago domiciliado del ptmo no se aplico: " + pagoDomiciliado.numPtmo + " ,Msg: " + "No tiene pagos pendientes a la fecha";
                            pagoDomiciliado.Mensaje = "Sin Adeudo";
                            ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.NoAplicado);
                            continue;

                        }

                        if (pagoDomiciliado.saldoCtaRetiro <= 0)
                        {
                            noAplicados = noAplicados + 1;
                            //pagoDomiciliado.Mensaje = "El pago domiciliado del ptmo no se aplico: " + pagoDomiciliado.numPtmo + " ,Msg: " + "No cuenta con el saldo suficiente para realizar su pago domiciliado";
                            pagoDomiciliado.Mensaje = "Fondos insuficientes";
                            ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.Pendiente);
                            continue;
                        }


                        pagoDomiciliado.montoPagado = pagoDomiciliado.requierePagoCompleto || pagoDomiciliado.saldoCtaRetiro >= pagoDomiciliado.Monto ? pagoDomiciliado.Monto : pagoDomiciliado.saldoCtaRetiro;

                        if (pagoDomiciliado.requierePagoCompleto && pagoDomiciliado.montoPagado > pagoDomiciliado.saldoCtaRetiro)
                        {
                            noAplicados = noAplicados + 1;
                            pagoDomiciliado.montoPagado = 0;
                            //pagoDomiciliado.Mensaje = "El pago domiciliado del ptmo no se aplico: " + pagoDomiciliado.numPtmo + " ,Msg: " + "No cuenta con el saldo suficiente para realizar su pago domiciliado";
                            pagoDomiciliado.Mensaje = "Fondos insuficientes";
                            ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.Pendiente);
                            continue;
                        }

                        Enumeracion.TipoAnticipo tipoAnticipo = pagoDomiciliado.montoPagado >= resultDetallePtmo.montoLiquidacion ? Enumeracion.TipoAnticipo.Ninguno : ((resultDetallePtmo.monto == 0 || pagoDomiciliado.montoPagado > resultDetallePtmo.monto) ? Enumeracion.TipoAnticipo.ReduccionPlazo : Enumeracion.TipoAnticipo.Ninguno);

                        Result<string> resultPagoPtmo = bll.PagarPtmo(pagoDomiciliado, tipoAnticipo);
                        if (resultPagoPtmo.estatus)
                        {
                            aplicados = aplicados + 1;
                            //pagoDomiciliado.Mensaje = "Pago domiciliado aplicado del ptmo: " + pagoDomiciliado.numPtmo + " ,Msg: " + (pagoDomiciliado.Monto != pagoDomiciliado.montoPagado ? "Pago incompleto" : "Pago completo");
                            pagoDomiciliado.montoPagado = resultPagoPtmo.monto;
                            pagoDomiciliado.Mensaje = (pagoDomiciliado.Monto > pagoDomiciliado.montoPagado ? "Pago incompleto" : "Pago completo");
                            pagoDomiciliado.FolioBanca = resultPagoPtmo.FolioBanca;
                            ReportAdvance(pagoDomiciliado, pagoDomiciliado.montoPagado< pagoDomiciliado.Monto ? Enumeracion.EstatusPago.Pendiente : Enumeracion.EstatusPago.Aplicado);
                        }
                        else
                        {

                            noAplicados = noAplicados + 1;
                            pagoDomiciliado.montoPagado = 0;
                            //pagoDomiciliado.Mensaje = "El pago domiciliado del ptmo no se aplico: " + pagoDomiciliado.numPtmo + " ,Msg: " + resultPagoPtmo.mensaje;
                            pagoDomiciliado.Mensaje = resultPagoPtmo.mensaje;
                            ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.Pendiente);
                        }
                    }
                    catch (Exception ex)
                    {
                        errors_count++;
                        pagoDomiciliado.Mensaje = "Error al realizar el pago de prestamo domiciliado del socio: " + pagoDomiciliado.NumeroSocio + " Msg: " + ex.Message;
                        ReportAdvance(pagoDomiciliado, Enumeracion.EstatusPago.Error);
                        Utilerias.EscribirLog("Error al realizar el pago domiciliado del socio:" + pagoDomiciliado.NumeroSocio + " Alias: " + pagoDomiciliado.Alias + " ," + ex.Message + " " + ex.StackTrace);
                        logg.Error("Error al realizar el pago domiciliado del socio:" + pagoDomiciliado.NumeroSocio + " Alias: " + pagoDomiciliado.Alias + " ," + ex.Message + " " + ex.StackTrace);
                    }
                }
            }
            catch (Exception ex)
            {
                ReportAdvance("Se produjo un error en el metodo PagosDomiciliados: " + ex.Message + " " + ex.StackTrace);
                Utilerias.EscribirLog("Se produjo un error en el metodo PagosDomiciliados: " + ". \nDetalles: " + ex.Message);
                logg.Error("Se produjo un error el robot de domiciliaciones ServiciosDomiciliados: " + ". \nDetalles: " + ex.Message);
                //LogException(ex);
                result.estatus = false;
            }
            ReportAdvance(endMessage + " Total de pagos: " + totalPagos + " Aplicados: " + aplicados + " No aplicados: " + noAplicados, overallAdvanceReported, result.estatus);
            ReportAdvance(endMessage, overallAdvanceReported, result.estatus);
            return result;
        }

        private Result<string> ReportAdvance(PagoDomiciliado pagoDomiciliado, Enumeracion.EstatusPago estatusPago)
        {
            Result<string> result = new Result<string>();
            try
            {
                bll.RegistraPagoDomiciliado(pagoDomiciliado, estatusPago);
                if (pagoDomiciliado.tipoDomiciliacion == Enumeracion.TipoDomiciliacion.Prestamos)
                {
                    ReportAdvance("Ptmo: " + pagoDomiciliado.numPtmo + " - " + " Estatus Ptmo: " + estatusPago.ToString() + " ,Alias: " + pagoDomiciliado.Alias + " ," + pagoDomiciliado.Mensaje, 10, estatusPago==Enumeracion.EstatusPago.Error ? false : true);
                }
                else
                {
                    ReportAdvance("Socio: " + pagoDomiciliado.NumeroSocio + " - " +" Estatus Servicio: " + estatusPago.ToString() + " ,Alias: " + pagoDomiciliado.Alias + " ," + pagoDomiciliado.Mensaje, 10, estatusPago == Enumeracion.EstatusPago.Error ? false : true);

                }

                logg.Error("Socio:" + pagoDomiciliado.NumeroSocio + " Estatus Pago: " + estatusPago.ToString() + " ,Alias: " + pagoDomiciliado.Alias + " ," + pagoDomiciliado.Mensaje);
                Utilerias.EscribirLog("Socio:" + pagoDomiciliado.NumeroSocio + " Estatus Pago: " + estatusPago.ToString() + " ,Alias: " + pagoDomiciliado.Alias + " ," + pagoDomiciliado.Mensaje);

            }
            catch (Exception ex)
            {
                result.estatus = false;
                result.mensaje = ex.Message;
            }

            return result;
        }


        #endregion TASKS DEFINITION

        #region predefined members

        /// <summary>
        /// Reporta el fin del robot
        /// </summary>
        /// <param name="endMessage">Mensaje de finalización</param>
        /// <param name="overallAdvanceReported">Reporte del avance</param>
        private void Finalize(string endMessage, int overallAdvanceReported)
        {
            ReportAdvance(endMessage, overallAdvanceReported, true);
        }

        /// <summary>
        /// Obtener cabecera del correo
        /// </summary>
        /// <param name="tipo">Tipo de correo</param>
        /// <returns>Cadena con la cabecera</returns>
        private string GetHeader(string tipo)
        {
            try
            {


                //Console.WriteLine(str);
                //return str;

                string str = string.Format
                            (
                            "<b><font color = '{1}'>{0}</font></b><br><br>"

                            + "<table style='font-family:arial; font-size:12px; padding-left:20px; font-style: italic'>"

                            + SetHeaderNotification("Tipo de correo", tipo.ToUpper())
                            + SetHeaderNotification("Tipo de ejecución", ModoCheck.Checked ? "AUTOMÁTICO" : "MANUAL")
                            + SetHeaderNotification("Cerrar al finalizar", AutoCloseCheck.Checked ? "ACTIVADO" : "DESACTIVADO")
                            + SetHeaderNotification("Fecha de proceso", string.Format("{0:dd/MM/yyyy}", usingDateTime))
                            + SetHeaderNotification("Instancia", Conexion.Servidor.ToUpper())
                            + SetHeaderNotification("Host", Environment.UserName)
                            + SetHeaderNotification("Database User", Conexion.Usuario)
                            + "</table>"
                            + "<br><hr><br>"
                            + "<b><font color = '{1}'>RESUMEN</font></b><br><br>",
                            robotName,
                            colorMailHighlight
                            );

                return str;
            }

            catch (Exception ex)
            {
                LogException(ex);
                return "";
            }
        }

        private string SetHeaderNotification(string notificationKind, object value)
        {
            return string.Format("<tr><td>{0}:</td><td style='color:{2}'><b>{1}</b></td></tr>", notificationKind, value, colorMailHighlight);
        }

        /// <summary>
        /// Marcar el inicio del robot en la base de datos
        /// </summary>
        /// <param name="startMessage">Mensaje al inicio del marcado</param>
        /// <param name="endMessage">Mensaje al fin del marcado</param>
        /// <param name="overallAdvanceReported">Avance global por marcado de inicio</param>
        /// <param name="_">Distinción para sobrecarga de inicio</param>
        private Result<string> Mark(string startMessage, string endMessage, int overallAdvanceReported, Start _)
        {
            Result<string> result = new Result<string>();           
            ReportAdvance(startMessage);
            try
            {
                result.estatus = Mark(_);
                result.mensaje = !result.estatus ? "Error al escribir el inicio del robot en la base de datos" : "";
            }
            catch (Exception ex)
            {
                LogException(ex);
                errors_count++;
                result.estatus = false;
            }
            ReportAdvance(endMessage, overallAdvanceReported, result.estatus);
            return result;
        }

        /// <summary>
        /// Marcar el fin del robot en la base de datos
        /// </summary>
        /// <param name="startMessage">Mensaje al inicio del marcado</param>
        /// <param name="endMessage">Mensaje al fin del marcado</param>
        /// <param name="overallAdvanceReported">Avance global por marcado de fin</param>
        /// <param name="_">Distinción para sobrecarga de fin</param>
        private Boolean Mark(string startMessage, string endMessage, int overallAdvanceReported, Stop _)
        {
            Boolean result;
            ReportAdvance(startMessage);
            try
            {
                result = Mark(_);
            }
            catch (Exception ex)
            {
                LogException(ex);
                result = false;
            }
            ReportAdvance(endMessage, overallAdvanceReported, result);
            return result;
        }

        /// <summary>
        /// Insertar registro de inicio del robot en la base
        /// </summary>
        /// <param name="_">Distinción para sobrecarga de inicio</param>
        private Boolean Mark(Start _)
        {

            Boolean res = true;

            res = bll.InsertaHoraRobot(robotName + " [" + String.Format("{0:yyyyMMdd}", usingDateTime) + String.Format("_{0}]", errors_count == 0 ? "OK" : "ERRORS")).estatus;
            //database_.ExecuteScript
            //    (
            //    string.Format
            //        (
            //        "insert registra_hora_robot (hora, tipo, robot) values (getdate(), 'T', '{0}')",

            //        )
            //    );

            return res;

        }

        /// <summary>
        /// Insertar registro de fin del robot en la base
        /// </summary>
        /// <param name="_">Distinción para sobrecarga de fin</param>
        private Boolean Mark(Stop _)
        {

            Boolean res = true;

            res = bll.InsertaHoraRobot(robotName + " [" + String.Format("{0:yyyyMMdd}", usingDateTime) + String.Format("_{0}]", errors_count == 0 ? "OK" : "ERRORS")).estatus;
            //database_.ExecuteScript
            //    (
            //    string.Format
            //        (
            //        "insert registra_hora_robot (hora, tipo, robot) values (getdate(), 'F', '{0}')",
            //        robotName + " ["
            //        + String.Format("{0:yyyyMMdd}", usingDateTime) + String.Format("_{0}]", errors_count == 0 ? "OK" : "ERRORS")
            //        )
            //    );

            return res;

        }

        /// <summary>
        /// Reportar el fin de una tarea
        /// </summary>
        /// <param name="message">Mensaje que se va a reportar en el historial</param>
        /// <param name="overallAdvanceReported">Avance global a reportar por la tarea</param>
        private void ReportAdvance(string message, int overallAdvanceReported, Boolean status)
        {
            try
            {
                report.message = message;
                report.status = status;
                report.overallProgress = overallAdvanceReported;
                TasksBGWorker.ReportProgress(overallAdvanceReported);
                Application.DoEvents();
                Thread.Sleep(50);
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
        }

        /// <summary>
        /// Reporta el inicio de una tarea
        /// </summary>
        /// <param name="message">Mensaje que se va a reportar en el historial</param>
        private void ReportAdvance(string message)
        {
            try
            {
                int overallAdvanceReported = report.overallProgress;
                report.message = message;
                report.status = true;
                TasksBGWorker.ReportProgress(overallAdvanceReported);
                Application.DoEvents();
                Thread.Sleep(50);
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
        }

        /// <summary>
        /// Manda los correos de inicio del robot
        /// </summary>
        /// <param name="startMessage">Mensaje al inicio del envío de correos</param>
        /// <param name="endMessage">Mensaje al fin del envío de correos</param>
        /// <param name="overallAdvanceReported">Avance global a reportar por el envío de correos</param>
        /// <param name="_">Distinción para sobrecarga de inicio</param>
        private Result<string> SendMails(string startMessage, string endMessage, int overallAdvanceReported, Start _)
        {
            Result<string> result = new Result<string>();          
            ReportAdvance(startMessage);

            string
                    tipo = "Inicio",
                    body =
                        GetHeader(tipo);
            body += "<table style='font-family:arial; font-size:12px; padding-left:20px; font-style: italic'>";

            foreach (DataGridViewRow r in EstatusDGView.Rows)
            {
                body += string.Format(@"
<tr>
<td style='color:{6}'><b>{0:dd/MM/yyyy HH:mm:ss}</b></td>
<td><b>{1}</b></td>
<td>{2}</td>
<td style='color:{5}'><b>{3}</b></td>
<td style='color:{5}'><b>global: {4}</b></td>
</tr>",
            r.Cells[0].Value,
            r.Cells[1].Value,
            r.Cells[2].Value,
            r.Cells[3].Value,
            r.Cells[4].Value,
            (r.Cells[3].Value.ToString() == "OK" ? colorMailHighlight : "red"),
            colorMailHighlight
            );
            }

            body += "</table>";
            try
            {
                result.estatus = mail.SendMail(mailRecipientsList, tipo, body);
                result.mensaje = !result.estatus? "Ocurrio un error al enviar correos de inicio de robot":"";
            }
            catch (Exception ex)
            {
                LogException(ex);
                errors_count++;
                result.estatus = false;
            }
            ReportAdvance(endMessage, overallAdvanceReported, result.estatus);
            return result;
        }

        /// <summary>
        /// Manda los correos de fin del robot
        /// </summary>
        /// <param name="startMessage">Mensaje al inicio del envío de correos</param>
        /// <param name="endMessage">Mensaje al fin del envío de correos</param>
        /// <param name="overallAdvanceReported">Avance global a reportar por el envío de correos</param>
        /// <param name="_">Distinción para sobrecarga de inicio</param>
        private Boolean SendMails(string startMessage, string endMessage, int overallAdvanceReported, Stop _)
        {
            Boolean result;
            ReportAdvance(startMessage);
            string
                    tipo = "Fin" + (errors_count != 0 ? " (hubo errores)" : ""),
                    body =
                        GetHeader(tipo);

            body += "<table style='font-family:arial; font-size:12px; padding-left:20px; font-style: italic'>";

            foreach (DataGridViewRow r in EstatusDGView.Rows)
            {
                body += string.Format(@"
<tr>
<td style='color:{6}'><b>{0:dd/MM/yyyy HH:mm:ss}</b></td>
<td><b>{1}</b></td>
<td>{2}</td>
<td style='color:{5}'><b>{3}</b></td>
<td style='color:{5}'><b>global: {4}</b></td>
</tr>",
            r.Cells[0].Value,
            r.Cells[1].Value,
            r.Cells[2].Value,
            r.Cells[3].Value,
            r.Cells[4].Value,
            (r.Cells[3].Value.ToString() == "OK" ? colorMailHighlight : "red"),
            colorMailHighlight
            );
            }

            body += string.Format(@"
<tr>
<td style='color:{5}'><b>{0:dd/MM/yyyy HH:mm:ss}</b></td>
<td><b>{1}</b></td>
<td>{2}</td>
<td style='color:{5}'><b>{3}</b></td>
<td style='color:{5}'><b>global: {4}</b></td>
</tr>",
        DateTime.Now,
        step,
        "Correo de fin enviado",
        "OK",
        "100%",
        colorMailHighlight
        );

            body += "</table>";

            if (errors_count != 0)
            {
                body += string.Format(@"<br><br><b><font color = '{1}'>HUBO UNO O MÁS ERRORES.</font></b><br><br><font color='gray'><b>Para mayores detalles, haga debug de la aplicación o intente correr los procedimientos de bases de datos en forma manual.</b></font><br>{0}{0}{0}{0}{0}{0}
<br><br>", "&thinsp;", colorMailHighlight);
            }
            try
            {
                result = mail.SendMail(mailRecipientsList, tipo, body);
            }
            catch (Exception ex)
            {
                LogException(ex);
                result = false;
            }
            ReportAdvance(endMessage, overallAdvanceReported, result);
            return result;
        }

        #endregion predefined members

        #endregion CUSTOMIZABLE MEMBERS

        #region normal members

        /// <summary>
        /// Finaliza la aplicación
        /// </summary>
        private static void Exit()
        {
            Environment.Exit(0);
        }

        /// <summary>
        /// Realiza el ajuste de la fecha en caso de que así se indique, para agregar un día si la hora del sistema
        /// supera la hora indicada en la configuración
        /// </summary>
        private void AdjustDate()
        {
            //usingDateTime = FechaDTPicker.Value.AddDays(adjustingDateTime && DateTime.Now.TimeOfDay > adjustedTime ? 1 : 0);
            try
            {
                usingDateTime = new DateTime(FechaDTPicker.Value.Year, FechaDTPicker.Value.Month, FechaDTPicker.Value.Day);
                usingDateTime = usingDateTime.AddDays(AjusteFechaCheck.Checked ? 1 : 0);
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
        }

        /// <summary>
        /// Hace el cambio de modo de inicio
        /// </summary>
        private void ChangeMode()
        {
            try
            {
                if (ModoCheck.Checked)
                {
                    AjusteFechaCheck.Enabled = false;
                    AjusteFechaCheck.Checked = use_next_day_default;
                    AutoCloseCheck.Checked = auto_close_default;
                    ChangeMode_(Start._);
                }
                else
                {
                    AjusteFechaCheck.Enabled = true;
                    ChangeMode_(Stop._);
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
        }

        /// <summary>
        /// Prepara el modo de inicio en manual
        /// </summary>
        /// <param name="_">Distinción para sobrecarga de inicio manual</param>
        private void ChangeMode_(Stop _)
        {
            ProgressPBar.Maximum = 100;
            ProgressLabel.Text = "El proceso iniciará de manera manual";
            ModoCheck.Text = "Ejecutando en manual";
            FechaDTPicker.Enabled = true;
            EjecutarPBox.Visible = true;
            ProgressPBar.Value = 0;
            StartTimer.Enabled = false;
            AutoCloseCheck.Enabled = true;
        }

        /// <summary>
        /// Prepara el modo de inicio en automático
        /// </summary>
        /// <param name="_">Distinción para sobrecarga de inicio automático</param>
        private void ChangeMode_(Start _)
        {
            ProgressPBar.Maximum = 10 * waitStart;
            ProgressLabel.Text = string.Format("El proceso iniciará de forma automática en {0} segundos...", waitStart);
            ModoCheck.Text = "Ejecutando en automático";
            FechaDTPicker.Enabled = false;
            EjecutarPBox.Visible = false;
            ProgressPBar.Value = 0;
            StartTimer.Enabled = true;
            AjusteFechaCheck.Enabled = false;
            AutoCloseCheck.Enabled = false;
            FechaDTPicker.Value = DateTime.Now;
        }

        /// <summary>
        /// Reporta el finalizado de las tareas del robot
        /// </summary>
        private void Completed()
        {
            try
            {
                WorkingPBar.Visible = false;
                EjecutarPBox.BackColor = controlLight;
                ProgressPBar.Value = ProgressPBar.Maximum;
                ProgressLabel.Text = string.Format("{0}% completado...", 100);
                ClosePBox.Enabled = true;
                finalized = true;
                Application.DoEvents();
                if (AutoCloseCheck.Checked)
                {
                    ExitTimer.Enabled = true;
                    if (MessageBox.Show(string.Format("La aplicación se configuró para cerrarse\nde forma automática en {0} segundos...\n\nDesea abortar el cierre?", ExitTimer.Interval / 1000), "Notificación de cierre", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.Yes)
                    {
                        ExitTimer.Enabled = false;
                    }
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
        }

        /// <summary>
        /// Función para segmentar el contenido de listas de correo de destinatarios en el App.config
        /// y crear la lista de cuentas de correo global mailRecipientsList
        /// </summary>
        /// <param name="mailingList">El valor de la llave de correos</param>
        private void CreateMailingList(string mailingList)
        {
            try
            {
                MailAddress mailAddress;
                string[] accounts, account;
                if (mailingList.Contains(";"))
                {
                    accounts = mailingList.Split(';');
                    foreach (string s in accounts)
                    {
                        if (s.Contains(","))
                        {
                            account = s.Split(',');
                            mailAddress = new MailAddress(account[1].Trim().ToLower(), account[0].Trim());
                            mailRecipientsList.Add(mailAddress);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogException(ex);
            }
        }

        private static void LogException(Exception ex)
        {
            Console.WriteLine("{0}; {1}", ex.TargetSite, ex.Message);
        }

        /// <summary>
        /// Inicia la ejecución del robot
        /// </summary>
        private void ExecuteRobot()
        {
            AdjustDate();
            DialogResult dr = new DialogResult();
            if (!ModoCheck.Checked)
                dr = MessageBox.Show(
                    string.Format(@"Parámetros configurados:

    robot: {0}
    tipo de ejecución: {1}
    cerrar al finalizar: {2}
    fecha de proceso: {3:dd/MM/yyyy}
    instancia: {4}
    host: {5}
    database user: {6}

" + (executing ? "Estatus: [" + (finalized ? "FINALIZADO" : "EN EJECUCIÓN") + "]" : "¿Desea continuar?"),
                    robotName.ToUpper(),
                    ModoCheck.Checked ? "AUTOMÁTICO" : "MANUAL",
                    AutoCloseCheck.Checked ? "ACTIVADO" : "DESACTIVADO",
                    usingDateTime,
                    Conexion.Servidor.ToUpper(),
                    Environment.UserName.ToLower(),
                    Conexion.Usuario

        ), executing ? "El proceso ya se encuentra " + (finalized ? "finalizado" : "en ejecución") : "Confirmación de parámetros de inicio", executing ? MessageBoxButtons.OK : MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);
            if (ModoCheck.Checked || dr == DialogResult.Yes)
            {
                if (executing == false)
                {
                    WorkingPBar.Visible = true;
                    AjusteFechaCheck.Enabled = false;
                    ProgressPBar.Maximum = 100;
                    ClosePBox.BackColor = control;
                    ClosePBox.Image = closeDark;
                    ClosePBox.Enabled = false;
                    ModoCheck.Enabled = false;
                    AutoCloseCheck.Enabled = false;
                    FechaDTPicker.Enabled = false;
                    executing = true;
                    EjecutarPBox.BackColor = controlDark;
                    EjecutarPBox.Image = playWhite;
                    Application.DoEvents();
                    ProgressPBar.Value = 0;
                    step = 1;
                    TasksBGWorker.RunWorkerAsync();
                }
            }
        }

        /// <summary>
        /// Inicializar la aplicación
        /// </summary>
        private void InitializeApplication()
        {
            ReadConfiguration();
            NombreRobotLbl.Text = robotName;
            ProgressPBar.Maximum = 10 * waitStart;
            EstatusDGView.Columns.Add("TimeStamp", "marca_de_tiempo");
            EstatusDGView.Columns.Add("Step", "paso");
            EstatusDGView.Columns.Add("Desc", "descripcion");
            EstatusDGView.Columns.Add("Estatus", "estatus");
            EstatusDGView.Columns.Add("Progress", "progreso_global");
            EstatusDGView.AutoResizeColumns();
            mailSenderAccount = new MailAddress(robotMail, robotName);
            mail = new MailManager(mailServer, mailSenderAccount);
            ExitTimer.Interval = waitClose * 1000;
            AjusteFechaCheck.Checked = use_next_day_default;
            AutoCloseCheck.Checked = auto_close_default;
            colorMailHighlight = "#003ca0";
            ChangeMode_(Start._);
        }

        /// <summary>
        /// Minimizar la ventana
        /// </summary>
        private void MinimizeWindow()
        {
            WindowState = FormWindowState.Minimized;
        }

        /// <summary>
        /// Procesa el drag and drop del formulario sin borde
        /// </summary>
        /// <param name="e">Evento del click en el mouse</param>
        private void MouseDown_(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        /// <summary>
        /// Maneja el evento del MouseEnter en el botón de ejecución
        /// </summary>
        /// <param name="sender">Objeto que lo detona</param>
        private void MouseEnter_(object sender)
        {
            if (!executing)
                MouseEnter_((PictureBox)sender, Execute._);
        }

        /// <summary>
        /// Maneja el evento del MouseEnter en el botón de ejecución
        /// </summary>
        /// <param name="pb">Objeto que lo detona</param>
        /// <param name="_">Distinción para sobrecarga de ejecución</param>
        private void MouseEnter_(PictureBox pb, Execute _)
        {
            pb.BackColor = blue;
            pb.Image = playWhite;
        }

        /// <summary>
        /// Maneja el evento del MouseEnter en el botón de cierre
        /// </summary>
        /// <param name="pb">Objeto que lo detona</param>
        /// <param name="_">Distinción para sobrecarga de cierre</param>
        private void MouseEnter_(PictureBox pb, Close_ _)
        {
            pb.BackColor = red;
            pb.Image = closeWhite;
        }

        /// <summary>
        /// Maneja el evento del MouseEnter en el botón de minimizado
        /// </summary>
        /// <param name="pb">Objeto que lo detona</param>
        /// <param name="_">Distinción para sobrecarga de minimizado</param>
        private void MouseEnter_(PictureBox pb, Minimize _)
        {
            pb.BackColor = blue;
            pb.Image = minusWhite;
        }

        /// <summary>
        /// Maneja el evento del MouseLeave en el botón de ejecución
        /// </summary>
        /// <param name="sender">Objeto que lo detona</param>
        private void MouseLeave_(object sender)
        {
            if (!executing)
                MouseLeave_((PictureBox)sender, Execute._);
        }

        /// <summary>
        /// Maneja el evento del MouseLeave en el botón de cierre
        /// </summary>
        /// <param name="pb">Objeto que lo detona</param>
        /// <param name="_">Distinción para sobrecarga de cierre</param>
        private void MouseLeave_(PictureBox pb, Close_ _)
        {
            pb.BackColor = control;
            pb.Image = closeDark;
        }

        /// <summary>
        /// Maneja el evento del MouseLeave en el botón de minimizado
        /// </summary>
        /// <param name="pb">Objeto que lo detona</param>
        /// <param name="_">Distinción para sobrecarga de minimizado</param>
        private void MouseLeave_(PictureBox pb, Minimize _)
        {
            pb.BackColor = control;
            pb.Image = minusDark;
        }

        /// <summary>
        /// Maneja el evento del MouseLeave en el botón de ejecución
        /// </summary>
        /// <param name="pb">Objeto que lo detona</param>
        /// <param name="_">Distinción para sobrecarga de ejecución</param>
        private void MouseLeave_(PictureBox pb, Execute execute)
        {
            pb.BackColor = controlLight;
            pb.Image = playDark;
        }

        /// <summary>
        /// Realiza la recuperación de parámetros del archivo App.config
        /// </summary>
        private void ReadConfiguration()
        {
            try
            {
                robotName = ConfigurationManager.AppSettings["Nombre del Robot"].ToString();
                Conexion.Servidor = ConfigurationManager.AppSettings["Instancia"].ToString();
                Conexion.BaseDatos = ConfigurationManager.AppSettings["Base de Datos"].ToString();
                Conexion.Usuario = "robot_cobranza";
                Conexion.Password = "8DED40B6E19F14D1651FDDF063CDD2";
                mailServer = ConfigurationManager.AppSettings["Servidor de Correo"].ToString();
                robotMail = ConfigurationManager.AppSettings["Correo del Robot"].ToString();
                waitStart = Convert.ToInt32(ConfigurationManager.AppSettings["Tiempo Inicio Automático"].ToString());
                waitClose = Convert.ToInt32(ConfigurationManager.AppSettings["Tiempo Cierre Automático"].ToString());
                CreateMailingList(ConfigurationManager.AppSettings["Lista de correos de destinatarios"].ToString());
                iIdProcesoCritico = bll.ObtenerInfoProcesoCritico(robotName);
            }
            catch (Exception ex)
            {
                LogException(ex);
                MessageBox.Show(string.Format(@"Hubo un error al leer la plantilla de configuración de la aplicación.{0}
Por favor, revise que está usando la plantilla requerida deacuerdo a la versión de la aplicación.{0}{0}* Más información:{0}{1}{0}{2}", "\n", ex.TargetSite, ex.Message), "Error de plantilla de configuración", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        /// <summary>
        /// Acciones a realizar en el reporte de avance
        /// </summary>
        /// <param name="e">Argumentos de evento de reporte de progreso</param>
        private void ReportAdvance(System.ComponentModel.ProgressChangedEventArgs e)
        {
            ProgressPBar.Value = e.ProgressPercentage;
            ProgressLabel.Text = string.Format("{0}% completado...", e.ProgressPercentage);
            DataGridViewRow r = new DataGridViewRow();
            r.CreateCells(EstatusDGView);
            r.Cells[0].Value = string.Format("{0:dd/MM/yyyy HH:mm:ss}", DateTime.Now);
            r.Cells[1].Value = step++;
            r.Cells[2].Value = report.message;
            r.Cells[3].Value = report.status ? "OK" : "ERROR";
            r.Cells[4].Value = string.Format("{0}%", e.ProgressPercentage);
            EstatusDGView.Rows.Add(r);
            EstatusDGView.Rows[step - 2].Selected = true;
            EstatusDGView.Rows[step - 2].Cells[1].Selected = true;
        }

        /// <summary>
        /// Realiza el inicio automático del robot
        /// </summary>
        private void Tick()
        {
            ProgressPBar.PerformStep();
            if (ProgressPBar.Value % 10 == 0)
                ProgressLabel.Text = string.Format("El proceso iniciará de forma automática en {0} segundos...", (waitStart * 10 - ProgressPBar.Value) / 10);
            if (ProgressPBar.Value == ProgressPBar.Maximum)
            {
                StartTimer.Enabled = false;
                Application.DoEvents();
                ExecuteRobot();
            }
        }

        /// <summary>
        /// Cambia el modo de cierre al finalizar el robot
        /// </summary>
        private void ToogleAutoClose()
        {
            if (AutoCloseCheck.Checked)
                AutoCloseCheck.Text = "Cerrando automáticamente al finalizar";
            else
                AutoCloseCheck.Text = "Manteniendo abierto al finalizar";
        }

        private void ToogleDateAdjustment()
        {
            //adjustingDateTime = AjusteFechaCheck.Checked;
            if (AjusteFechaCheck.Checked)
                AjusteFechaCheck.Text = "Tomando día siguiente a la fecha actual";
            else
                AjusteFechaCheck.Text = "Tomando fecha actual";
        }

        #endregion normal members

        #region events

        private void AjusteFechaCheck_CheckedChanged(object sender, EventArgs e)
        {
            ToogleDateAdjustment();
        }

        private void AutoCloseCheck_CheckedChanged(object sender, EventArgs e)
        {
            ToogleAutoClose();
        }

        private void ClosePBox_Click(object sender, EventArgs e)
        {
            Exit();
        }

        private void ClosePBox_MouseEnter(object sender, EventArgs e)
        {
            MouseEnter_((PictureBox)sender, Close_._);
        }

        private void VersionCheck_CheckedChanged(object sender, EventArgs e)
        {
            ToogleVersion();
        }


        private void ClosePBox_MouseHover(object sender, EventArgs e)
        {
            MouseEnter_((PictureBox)sender, Close_._);
        }

        private void ClosePBox_MouseLeave(object sender, EventArgs e)
        {
            MouseLeave_((PictureBox)sender, Close_._);
        }

        private void EjecutarPBox_Click(object sender, EventArgs e)
        {
            ExecuteRobot();
        }

        private void EjecutarPBox_MouseEnter(object sender, EventArgs e)
        {
            MouseEnter_(sender);
        }

        private void EjecutarPBox_MouseLeave(object sender, EventArgs e)
        {
            MouseLeave_(sender);
        }

        private void ExitTimer_Tick(object sender, EventArgs e)
        {
            Exit();
        }

        private void FechaDTPicker_ValueChanged(object sender, EventArgs e)
        {
            FechaDTPicker.Value = FechaDTPicker.Value.Date;
        }

        private void MinimizePBox_Click(object sender, EventArgs e)
        {
            MinimizeWindow();
        }

        private void MinimizePBox_MouseEnter(object sender, EventArgs e)
        {
            MouseEnter_((PictureBox)sender, Minimize._);
        }

        private void MinimizePBox_MouseLeave(object sender, EventArgs e)
        {
            MouseLeave_((PictureBox)sender, Minimize._);
        }

        private void ModoCheck_CheckedChanged(object sender, EventArgs e)
        {
            ChangeMode();
        }

        private void MouseDown_(object sender, MouseEventArgs e)
        {
            MouseDown_(e);
        }

        private void StartTimer_Tick(object sender, EventArgs e)
        {
            Tick();
        }

        private void TasksBGWorker_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            ExecuteBackgroundWork();
        }

        private void TasksBGWorker_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            ReportAdvance(e);
        }

        private void TasksBGWorker_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            Completed();
        }

        #endregion events

        #region events_interfaces

        private void ToogleVersion()
        {
            mailSenderAccount = null;
            mail = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
            mailSenderAccount = new MailAddress(robotMail, robotName);
            mail = new MailManager(mailServer, mailSenderAccount);
        }


        #endregion events_interfaces
    }
}