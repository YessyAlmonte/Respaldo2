﻿namespace RobotDomiciliacion
{
    partial class frmRobotDomiciliacion
    {
        private System.Windows.Forms.CheckBox AjusteFechaCheck;

        private System.Windows.Forms.CheckBox AutoCloseCheck;

        private System.Windows.Forms.ToolTip AyudaTTip;

        private System.Windows.Forms.PictureBox ClosePBox;

        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel ControlsPanel;

        private System.Windows.Forms.PictureBox EjecutarPBox;

        private System.Windows.Forms.Panel EncabezadoPanel;

        private System.Windows.Forms.DataGridView EstatusDGView;

        private System.Windows.Forms.Timer ExitTimer;

        private System.Windows.Forms.DateTimePicker FechaDTPicker;

        private System.Windows.Forms.Label LogLabel;

        private System.Windows.Forms.PictureBox LogoPBox;

        private System.Windows.Forms.Panel MainPanel;

        private System.Windows.Forms.PictureBox MinimizePBox;

        private System.Windows.Forms.CheckBox ModoCheck;

        private System.Windows.Forms.Label NombreRobotLbl;

        private System.Windows.Forms.Panel NombreRobotPanel;

        private System.Windows.Forms.Label ProgressLabel;

        private System.Windows.Forms.ProgressBar ProgressPBar;

        private System.Windows.Forms.Timer StartTimer;

        private System.ComponentModel.BackgroundWorker TasksBGWorker;

        private System.Windows.Forms.ProgressBar WorkingPBar;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRobotDomiciliacion));
            this.ControlsPanel = new System.Windows.Forms.Panel();
            this.MinimizePBox = new System.Windows.Forms.PictureBox();
            this.ClosePBox = new System.Windows.Forms.PictureBox();
            this.EncabezadoPanel = new System.Windows.Forms.Panel();
            this.NombreRobotPanel = new System.Windows.Forms.Panel();
            this.NombreRobotLbl = new System.Windows.Forms.Label();
            this.LogoPBox = new System.Windows.Forms.PictureBox();
            this.MainPanel = new System.Windows.Forms.Panel();
            this.FechaLabel = new System.Windows.Forms.Label();
            this.AjusteFechaCheck = new System.Windows.Forms.CheckBox();
            this.WorkingPBar = new System.Windows.Forms.ProgressBar();
            this.LogLabel = new System.Windows.Forms.Label();
            this.AutoCloseCheck = new System.Windows.Forms.CheckBox();
            this.EjecutarPBox = new System.Windows.Forms.PictureBox();
            this.ProgressLabel = new System.Windows.Forms.Label();
            this.FechaDTPicker = new System.Windows.Forms.DateTimePicker();
            this.ModoCheck = new System.Windows.Forms.CheckBox();
            this.ProgressPBar = new System.Windows.Forms.ProgressBar();
            this.EstatusDGView = new System.Windows.Forms.DataGridView();
            this.StartTimer = new System.Windows.Forms.Timer(this.components);
            this.AyudaTTip = new System.Windows.Forms.ToolTip(this.components);
            this.TasksBGWorker = new System.ComponentModel.BackgroundWorker();
            this.ExitTimer = new System.Windows.Forms.Timer(this.components);
            this.ControlsPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MinimizePBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePBox)).BeginInit();
            this.EncabezadoPanel.SuspendLayout();
            this.NombreRobotPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPBox)).BeginInit();
            this.MainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EjecutarPBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EstatusDGView)).BeginInit();
            this.SuspendLayout();
            // 
            // ControlsPanel
            // 
            this.ControlsPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ControlsPanel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ControlsPanel.Controls.Add(this.MinimizePBox);
            this.ControlsPanel.Controls.Add(this.ClosePBox);
            this.ControlsPanel.Location = new System.Drawing.Point(562, 0);
            this.ControlsPanel.Name = "ControlsPanel";
            this.ControlsPanel.Size = new System.Drawing.Size(75, 38);
            this.ControlsPanel.TabIndex = 0;
            this.ControlsPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MouseDown_);
            // 
            // MinimizePBox
            // 
            this.MinimizePBox.BackColor = System.Drawing.SystemColors.Control;
            this.MinimizePBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.MinimizePBox.Image = global::RobotDomiciliacion.Properties.Resources.minus_dark;
            this.MinimizePBox.Location = new System.Drawing.Point(4, 3);
            this.MinimizePBox.Name = "MinimizePBox";
            this.MinimizePBox.Size = new System.Drawing.Size(32, 32);
            this.MinimizePBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.MinimizePBox.TabIndex = 1;
            this.MinimizePBox.TabStop = false;
            this.AyudaTTip.SetToolTip(this.MinimizePBox, "Minimiza la aplicación");
            this.MinimizePBox.Click += new System.EventHandler(this.MinimizePBox_Click);
            this.MinimizePBox.MouseEnter += new System.EventHandler(this.MinimizePBox_MouseEnter);
            this.MinimizePBox.MouseLeave += new System.EventHandler(this.MinimizePBox_MouseLeave);
            // 
            // ClosePBox
            // 
            this.ClosePBox.BackColor = System.Drawing.SystemColors.Control;
            this.ClosePBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClosePBox.Image = global::RobotDomiciliacion.Properties.Resources.close_dark;
            this.ClosePBox.Location = new System.Drawing.Point(40, 3);
            this.ClosePBox.Name = "ClosePBox";
            this.ClosePBox.Size = new System.Drawing.Size(32, 32);
            this.ClosePBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.ClosePBox.TabIndex = 0;
            this.ClosePBox.TabStop = false;
            this.AyudaTTip.SetToolTip(this.ClosePBox, "Cierra la aplicación");
            this.ClosePBox.Click += new System.EventHandler(this.ClosePBox_Click);
            this.ClosePBox.MouseEnter += new System.EventHandler(this.ClosePBox_MouseEnter);
            this.ClosePBox.MouseLeave += new System.EventHandler(this.ClosePBox_MouseLeave);
            this.ClosePBox.MouseHover += new System.EventHandler(this.ClosePBox_MouseHover);
            // 
            // EncabezadoPanel
            // 
            this.EncabezadoPanel.BackColor = System.Drawing.SystemColors.Control;
            this.EncabezadoPanel.Controls.Add(this.NombreRobotPanel);
            this.EncabezadoPanel.Controls.Add(this.LogoPBox);
            this.EncabezadoPanel.Controls.Add(this.ControlsPanel);
            this.EncabezadoPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.EncabezadoPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.EncabezadoPanel.Location = new System.Drawing.Point(0, 0);
            this.EncabezadoPanel.Name = "EncabezadoPanel";
            this.EncabezadoPanel.Size = new System.Drawing.Size(638, 104);
            this.EncabezadoPanel.TabIndex = 0;
            this.EncabezadoPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MouseDown_);
            // 
            // NombreRobotPanel
            // 
            this.NombreRobotPanel.Controls.Add(this.NombreRobotLbl);
            this.NombreRobotPanel.Location = new System.Drawing.Point(104, 37);
            this.NombreRobotPanel.Name = "NombreRobotPanel";
            this.NombreRobotPanel.Size = new System.Drawing.Size(452, 64);
            this.NombreRobotPanel.TabIndex = 4;
            // 
            // NombreRobotLbl
            // 
            this.NombreRobotLbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NombreRobotLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NombreRobotLbl.Location = new System.Drawing.Point(0, 0);
            this.NombreRobotLbl.Name = "NombreRobotLbl";
            this.NombreRobotLbl.Size = new System.Drawing.Size(452, 64);
            this.NombreRobotLbl.TabIndex = 0;
            this.NombreRobotLbl.Text = "__";
            this.NombreRobotLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.NombreRobotLbl.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MouseDown_);
            // 
            // LogoPBox
            // 
            this.LogoPBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.LogoPBox.Image = global::RobotDomiciliacion.Properties.Resources.logoCMV64;
            this.LogoPBox.Location = new System.Drawing.Point(0, 0);
            this.LogoPBox.Name = "LogoPBox";
            this.LogoPBox.Size = new System.Drawing.Size(98, 104);
            this.LogoPBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.LogoPBox.TabIndex = 3;
            this.LogoPBox.TabStop = false;
            this.LogoPBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MouseDown_);
            // 
            // MainPanel
            // 
            this.MainPanel.BackColor = System.Drawing.SystemColors.Control;
            this.MainPanel.Controls.Add(this.FechaLabel);
            this.MainPanel.Controls.Add(this.AjusteFechaCheck);
            this.MainPanel.Controls.Add(this.WorkingPBar);
            this.MainPanel.Controls.Add(this.LogLabel);
            this.MainPanel.Controls.Add(this.AutoCloseCheck);
            this.MainPanel.Controls.Add(this.EjecutarPBox);
            this.MainPanel.Controls.Add(this.ProgressLabel);
            this.MainPanel.Controls.Add(this.FechaDTPicker);
            this.MainPanel.Controls.Add(this.ModoCheck);
            this.MainPanel.Controls.Add(this.ProgressPBar);
            this.MainPanel.Controls.Add(this.EstatusDGView);
            this.MainPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.MainPanel.Location = new System.Drawing.Point(0, 110);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(638, 345);
            this.MainPanel.TabIndex = 0;
            this.MainPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MouseDown_);
            // 
            // FechaLabel
            // 
            this.FechaLabel.AutoSize = true;
            this.FechaLabel.Location = new System.Drawing.Point(86, 45);
            this.FechaLabel.Name = "FechaLabel";
            this.FechaLabel.Size = new System.Drawing.Size(72, 13);
            this.FechaLabel.TabIndex = 2;
            this.FechaLabel.Text = "Fecha actual:";
            // 
            // AjusteFechaCheck
            // 
            this.AjusteFechaCheck.Appearance = System.Windows.Forms.Appearance.Button;
            this.AjusteFechaCheck.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.AjusteFechaCheck.Location = new System.Drawing.Point(262, 15);
            this.AjusteFechaCheck.Name = "AjusteFechaCheck";
            this.AjusteFechaCheck.Size = new System.Drawing.Size(216, 24);
            this.AjusteFechaCheck.TabIndex = 1;
            this.AjusteFechaCheck.Text = "Tomando día siguiente a la fecha actual";
            this.AjusteFechaCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.AyudaTTip.SetToolTip(this.AjusteFechaCheck, resources.GetString("AjusteFechaCheck.ToolTip"));
            this.AjusteFechaCheck.UseVisualStyleBackColor = false;
            this.AjusteFechaCheck.CheckedChanged += new System.EventHandler(this.AjusteFechaCheck_CheckedChanged);
            // 
            // WorkingPBar
            // 
            this.WorkingPBar.Location = new System.Drawing.Point(262, 111);
            this.WorkingPBar.MarqueeAnimationSpeed = 25;
            this.WorkingPBar.Name = "WorkingPBar";
            this.WorkingPBar.Size = new System.Drawing.Size(336, 10);
            this.WorkingPBar.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.WorkingPBar.TabIndex = 7;
            this.AyudaTTip.SetToolTip(this.WorkingPBar, "Proceso ejecutándose en segundo plano.\r\n\r\nLa aplicación sigue respondiendo en for" +
        "ma\r\nadecuada a eventos; No es necesario detenerla.\r\n\r\n");
            this.WorkingPBar.UseWaitCursor = true;
            this.WorkingPBar.Visible = false;
            this.WorkingPBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MouseDown_);
            // 
            // LogLabel
            // 
            this.LogLabel.BackColor = System.Drawing.SystemColors.Control;
            this.LogLabel.Location = new System.Drawing.Point(40, 98);
            this.LogLabel.Name = "LogLabel";
            this.LogLabel.Size = new System.Drawing.Size(558, 23);
            this.LogLabel.TabIndex = 6;
            this.LogLabel.Text = "Reporte de actividades del robot";
            this.LogLabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.LogLabel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MouseDown_);
            // 
            // AutoCloseCheck
            // 
            this.AutoCloseCheck.Appearance = System.Windows.Forms.Appearance.Button;
            this.AutoCloseCheck.Checked = true;
            this.AutoCloseCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AutoCloseCheck.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.AutoCloseCheck.Location = new System.Drawing.Point(262, 71);
            this.AutoCloseCheck.Name = "AutoCloseCheck";
            this.AutoCloseCheck.Size = new System.Drawing.Size(216, 24);
            this.AutoCloseCheck.TabIndex = 5;
            this.AutoCloseCheck.Text = "Cerrando automáticamente al finalizar";
            this.AutoCloseCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.AyudaTTip.SetToolTip(this.AutoCloseCheck, "Intercambia el modo de cierre al finalizar el robot.");
            this.AutoCloseCheck.UseVisualStyleBackColor = false;
            this.AutoCloseCheck.CheckedChanged += new System.EventHandler(this.AutoCloseCheck_CheckedChanged);
            // 
            // EjecutarPBox
            // 
            this.EjecutarPBox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.EjecutarPBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.EjecutarPBox.Image = global::RobotDomiciliacion.Properties.Resources.play_dark;
            this.EjecutarPBox.Location = new System.Drawing.Point(502, 15);
            this.EjecutarPBox.Name = "EjecutarPBox";
            this.EjecutarPBox.Size = new System.Drawing.Size(80, 80);
            this.EjecutarPBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.EjecutarPBox.TabIndex = 7;
            this.EjecutarPBox.TabStop = false;
            this.AyudaTTip.SetToolTip(this.EjecutarPBox, "Ejecuta el robot en el modo manual.\r\n\r\nSi el proceso está en ejecución o finaliza" +
        "do,\r\nmuestra los parámetros configurados.");
            this.EjecutarPBox.Visible = false;
            this.EjecutarPBox.Click += new System.EventHandler(this.EjecutarPBox_Click);
            this.EjecutarPBox.MouseEnter += new System.EventHandler(this.EjecutarPBox_MouseEnter);
            this.EjecutarPBox.MouseLeave += new System.EventHandler(this.EjecutarPBox_MouseLeave);
            // 
            // ProgressLabel
            // 
            this.ProgressLabel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ProgressLabel.Location = new System.Drawing.Point(40, 287);
            this.ProgressLabel.Name = "ProgressLabel";
            this.ProgressLabel.Size = new System.Drawing.Size(558, 23);
            this.ProgressLabel.TabIndex = 10;
            this.ProgressLabel.Text = "_";
            this.ProgressLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ProgressLabel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MouseDown_);
            // 
            // FechaDTPicker
            // 
            this.FechaDTPicker.CustomFormat = "";
            this.FechaDTPicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.FechaDTPicker.Location = new System.Drawing.Point(161, 42);
            this.FechaDTPicker.Margin = new System.Windows.Forms.Padding(0);
            this.FechaDTPicker.Name = "FechaDTPicker";
            this.FechaDTPicker.Size = new System.Drawing.Size(95, 20);
            this.FechaDTPicker.TabIndex = 3;
            this.AyudaTTip.SetToolTip(this.FechaDTPicker, resources.GetString("FechaDTPicker.ToolTip"));
            this.FechaDTPicker.ValueChanged += new System.EventHandler(this.FechaDTPicker_ValueChanged);
            // 
            // ModoCheck
            // 
            this.ModoCheck.Appearance = System.Windows.Forms.Appearance.Button;
            this.ModoCheck.Checked = true;
            this.ModoCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ModoCheck.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.ModoCheck.Location = new System.Drawing.Point(56, 15);
            this.ModoCheck.Name = "ModoCheck";
            this.ModoCheck.Size = new System.Drawing.Size(200, 24);
            this.ModoCheck.TabIndex = 0;
            this.ModoCheck.Text = "Ejecutando en automático";
            this.ModoCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.AyudaTTip.SetToolTip(this.ModoCheck, resources.GetString("ModoCheck.ToolTip"));
            this.ModoCheck.UseVisualStyleBackColor = false;
            this.ModoCheck.CheckedChanged += new System.EventHandler(this.ModoCheck_CheckedChanged);
            // 
            // ProgressPBar
            // 
            this.ProgressPBar.Location = new System.Drawing.Point(40, 273);
            this.ProgressPBar.MarqueeAnimationSpeed = 20;
            this.ProgressPBar.Name = "ProgressPBar";
            this.ProgressPBar.Size = new System.Drawing.Size(558, 11);
            this.ProgressPBar.Step = 1;
            this.ProgressPBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.ProgressPBar.TabIndex = 9;
            this.AyudaTTip.SetToolTip(this.ProgressPBar, "Barra de progreso de las tareas del robot.");
            this.ProgressPBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MouseDown_);
            // 
            // EstatusDGView
            // 
            this.EstatusDGView.AllowUserToAddRows = false;
            this.EstatusDGView.AllowUserToDeleteRows = false;
            this.EstatusDGView.AllowUserToResizeRows = false;
            this.EstatusDGView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.EstatusDGView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.EstatusDGView.Location = new System.Drawing.Point(40, 124);
            this.EstatusDGView.MultiSelect = false;
            this.EstatusDGView.Name = "EstatusDGView";
            this.EstatusDGView.ReadOnly = true;
            this.EstatusDGView.RowHeadersVisible = false;
            this.EstatusDGView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.EstatusDGView.Size = new System.Drawing.Size(558, 143);
            this.EstatusDGView.TabIndex = 8;
            this.AyudaTTip.SetToolTip(this.EstatusDGView, "Muestra el historial de las tareas del robot");
            // 
            // StartTimer
            // 
            this.StartTimer.Tick += new System.EventHandler(this.StartTimer_Tick);
            // 
            // AyudaTTip
            // 
            this.AyudaTTip.AutomaticDelay = 200;
            this.AyudaTTip.AutoPopDelay = 20000;
            this.AyudaTTip.InitialDelay = 200;
            this.AyudaTTip.ReshowDelay = 200;
            this.AyudaTTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.AyudaTTip.UseAnimation = false;
            // 
            // TasksBGWorker
            // 
            this.TasksBGWorker.WorkerReportsProgress = true;
            this.TasksBGWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.TasksBGWorker_DoWork);
            this.TasksBGWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.TasksBGWorker_ProgressChanged);
            this.TasksBGWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.TasksBGWorker_RunWorkerCompleted);
            // 
            // ExitTimer
            // 
            this.ExitTimer.Interval = 5000;
            this.ExitTimer.Tick += new System.EventHandler(this.ExitTimer_Tick);
            // 
            // frmRobotDomiciliacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(638, 455);
            this.ControlBox = false;
            this.Controls.Add(this.MainPanel);
            this.Controls.Add(this.EncabezadoPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmRobotDomiciliacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MouseDown_);
            this.ControlsPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MinimizePBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePBox)).EndInit();
            this.EncabezadoPanel.ResumeLayout(false);
            this.NombreRobotPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LogoPBox)).EndInit();
            this.MainPanel.ResumeLayout(false);
            this.MainPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EjecutarPBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EstatusDGView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label FechaLabel;
    }
}

