﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotDomiciliacion.Utils
{
    public class Utilerias
    {
        public static string EscribirLog(string mensaje)
        {
            string resultado = "todo bien";
            try
            {
                string folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "LogRobotDomiciliacion");
                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);
                System.IO.File.WriteAllText(Path.Combine(folder, @"Log_" + Guid.NewGuid() + ".txt"), mensaje);
            }
            catch (Exception ex)
            {
                resultado = ex.Message;
            }
            return resultado;
        }
    }
}
