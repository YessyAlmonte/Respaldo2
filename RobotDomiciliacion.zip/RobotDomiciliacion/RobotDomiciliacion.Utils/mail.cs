﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;

namespace RobotDomiciliacion.Utils
{
    public class MailManager
    {
        private SmtpClient client;
        private MailAddress mailSenderAccount;
        private MailMessage message;
        private string server;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="server_">Servidor de correo</param>
        /// <param name="_mail">Cuenta de correo del remitente</param>
        /// <param name="_display">Nombre del remitente</param>
        public MailManager(string server_, MailAddress mailSenderAccount_)
        {
            message = new MailMessage();
            client = new SmtpClient();
            message.BodyEncoding = Encoding.UTF8;
            message.IsBodyHtml = true;
            client.Port = 25;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            server = server_;
            mailSenderAccount = mailSenderAccount_;
        }

        /// <summary>
        /// Envía el correo
        /// </summary>
        /// <param name="mailRecipientsList">Lista de destinatarios</param>
        /// <param name="subject">Asunto del correo</param>
        /// <param name="body">Cuerpo del correo</param>
        public Boolean SendMail(List<MailAddress> mailRecipientsList, string subject, string body)
        {
            body = string.Format("{0}{1}{2}", "<font face=\"arial\" size = \"2\">", body, "</font>");
            Boolean result = false;
            try
            {
                AddRecipients(mailRecipientsList);
                message.Subject = subject;
                message.Body += body;
                message.From = mailSenderAccount;
                client.Host = server;
                client.Send(message);
                message.Body = string.Empty;
                message.To.Clear();
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
                throw ex;
            }
            return result;
        }

        /// <summary>
        /// Agrega las cuentas de correo de los destinatarios al mensaje
        /// </summary>
        /// <param name="mailRecipientsList"></param>
        private void AddRecipients(List<MailAddress> mailRecipientsList)
        {
            foreach (MailAddress m in mailRecipientsList)
            {
                if (!string.IsNullOrEmpty(m.Address))
                    message.To.Add(m.Address);
            }
        }
    }
}