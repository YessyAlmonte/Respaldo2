﻿using RobotDomiciliacion.DAO;
using RobotDomiciliacion.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static RobotDomiciliacion.Entidades.Enumeracion;

namespace RobotDomiciliacion.BLL
{
    public class DomiciliacionBLL
    {
        public Result<string> InsertaHoraRobot(string nombreRobot)
        {
            try
            {
                return new DomiciliacionDAO().InsertaHoraRobot(nombreRobot);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Result<string> InsertaEntradaLogProcesosCriticos(int idProceso, DateTime fecha, int inicio, int status, string observaciones, int idGrupo)
        {
            try
            {
                return new DomiciliacionDAO().InsertaEntradaLogProcesosCriticos(idProceso,fecha,inicio,status,observaciones,idGrupo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public int ObtenerInfoProcesoCritico(string nombreRobot)
        {
            try
            {
                return new DomiciliacionDAO().ObtenerInfoProcesoCritico(nombreRobot);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public decimal ObtenerSaldoCtaRetiro(string numeroSocio, int idMov)
        {
            try
            {
                return new DomiciliacionDAO().ObtenerSaldoCtaRetiro(numeroSocio, idMov);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Result<string> RealizarPagoServicio(PagoDomiciliado servicio, bool esConsulta)
        {
            try
            {
                return new DomiciliacionDAO().RealizarPagoServicio(servicio, esConsulta);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Result<string> ActualizarPagoDeServicio(PagoDomiciliado request)
        {
            try
            {
                return new DomiciliacionDAO().ActualizarPagoDeServicio(request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<PagoDomiciliado> ObtenerPagosDomiciliados(DateTime fecha, TipoDomiciliacion tipoDomiciliacion,Boolean PendienteAplicar)
        {
            try
            {
                return new DomiciliacionDAO().ObtenerPagosDomiciliados(fecha, tipoDomiciliacion,PendienteAplicar);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public Result<PagoDomiciliado> ObtenerServicioConsulta(int idServicio, int idTipoFront)
        {
            try
            {
                return new DomiciliacionDAO().ObtenerServicioConsulta(idServicio, idTipoFront);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public Result<string> RegistraPagoDomiciliado(PagoDomiciliado servicio, EstatusPago estatusPago)
        {
            try
            {
                return new DomiciliacionDAO().RegistraPagoDomiciliado(servicio, estatusPago);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public Result<string> ObtenerDetallePtmo(PagoDomiciliado pagoDomiciliado)
        {
            try
            {
                return new DomiciliacionDAO().ObtenerDetallePtmo(pagoDomiciliado);
            }
            catch (Exception ex) 
            {

                throw ex;
            }
        }

        public Result<string> PagarPtmo(PagoDomiciliado pagoDomiciliado, TipoAnticipo tipoAnticipo)
        {
            try
            {
                return new DomiciliacionDAO().PagarPtmo(pagoDomiciliado, tipoAnticipo);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
