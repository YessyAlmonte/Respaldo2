﻿


//// NOTA: El código generado puede requerir, como mínimo, .NET Framework 4.5 o .NET Core/Standard 2.0.
///// <remarks/>
//[System.SerializableAttribute()]
//[System.ComponentModel.DesignerCategoryAttribute("code")]
//[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
//[System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
//public partial class RESPONSE
//{

//    private object iD_TXField;

//    private sbyte nUM_AUTORIZACIONField;

//    private decimal sALDOField;

//    private decimal cOMISIONField;

//    private decimal sALDO_FField;

//    private decimal cOMISION_FField;

//    private string fECHAField;

//    private decimal mONTOField;

//    private RESPONSEMENSAJE mENSAJEField;

//}

///// <remarks/>
//[System.SerializableAttribute()]
//[System.ComponentModel.DesignerCategoryAttribute("code")]
//[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
//public partial class RESPONSEMENSAJE
//{

//}


namespace GestoPago
{
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(ElementName = "RESPONSE", Namespace = "", IsNullable = false)]
    public partial class ResponseAbonar
    {
        private object iD_TXField;

        private long nUM_AUTORIZACIONField;

        private decimal sALDOField;

        private decimal cOMISIONField;

        private string sALDO_FField;

        private decimal cOMISION_FField;

        private string fECHAField;

        private decimal mONTOField;

        private RESPONSEMENSAJEABONAR mENSAJEField;

        /// <remarks/>
        public object ID_TX
        {
            get
            {
                return this.iD_TXField;
            }
            set
            {
                this.iD_TXField = value;
            }
        }

        /// <remarks/>
        public long NUM_AUTORIZACION
        {
            get
            {
                return this.nUM_AUTORIZACIONField;
            }
            set
            {
                this.nUM_AUTORIZACIONField = value;
            }
        }

        /// <remarks/>
        public decimal SALDO
        {
            get
            {
                return this.sALDOField;
            }
            set
            {
                this.sALDOField = value;
            }
        }

        /// <remarks/>
        public decimal COMISION
        {
            get
            {
                return this.cOMISIONField;
            }
            set
            {
                this.cOMISIONField = value;
            }
        }

        /// <remarks/>
        public string SALDO_F
        {
            get
            {
                return this.sALDO_FField;
            }
            set
            {
                this.sALDO_FField = value;
            }
        }

        /// <remarks/>
        public decimal COMISION_F
        {
            get
            {
                return this.cOMISION_FField;
            }
            set
            {
                this.cOMISION_FField = value;
            }
        }

        /// <remarks/>
        public string FECHA
        {
            get
            {
                return this.fECHAField;
            }
            set
            {
                this.fECHAField = value;
            }
        }

        /// <remarks/>
        public decimal MONTO
        {
            get
            {
                return this.mONTOField;
            }
            set
            {
                this.mONTOField = value;
            }
        }

        /// <remarks/>
        public RESPONSEMENSAJEABONAR MENSAJE
        {
            get
            {
                return this.mENSAJEField;
            }
            set
            {
                this.mENSAJEField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class RESPONSEMENSAJEABONAR
    {
        private byte cODIGOField;

        private uint pINField;

        private string legendField;

        private string tEXTOField;

        private object rEFERENCIAField;

        /// <remarks/>
        public byte CODIGO
        {
            get
            {
                return this.cODIGOField;
            }
            set
            {
                this.cODIGOField = value;
            }
        }

        /// <remarks/>
        public uint PIN
        {
            get
            {
                return this.pINField;
            }
            set
            {
                this.pINField = value;
            }
        }

        /// <remarks/>
        public string legend
        {
            get
            {
                return this.legendField;
            }
            set
            {
                this.legendField = value;
            }
        }

        /// <remarks/>
        public string TEXTO
        {
            get
            {
                return this.tEXTOField;
            }
            set
            {
                this.tEXTOField = value;
            }
        }

        /// <remarks/>
        public object REFERENCIA
        {
            get
            {
                return this.rEFERENCIAField;
            }
            set
            {
                this.rEFERENCIAField = value;
            }
        }
    }

}
















