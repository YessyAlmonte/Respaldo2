﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestoPago
{
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(ElementName = "RESPONSE" ,Namespace = "", IsNullable = false)]

    public class ResponseObtenerProductos_
    {

        /// <remarks/>
            private RESPONSEMENSAJE mENSAJEField;

            private RESPONSEProducto[] pRODUCTOSField;

            /// <remarks/>
            public RESPONSEMENSAJE MENSAJE
            {
                get
                {
                    return this.mENSAJEField;
                }
                set
                {
                    this.mENSAJEField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("producto", IsNullable = false)]
            public RESPONSEProducto[] PRODUCTOS
            {
                get
                {
                    return this.pRODUCTOSField;
                }
                set
                {
                    this.pRODUCTOSField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class RESPONSEMENSAJE
        {

            private byte cODIGOField;

            private string tEXTOField;

            /// <remarks/>
            public byte CODIGO
            {
                get
                {
                    return this.cODIGOField;
                }
                set
                {
                    this.cODIGOField = value;
                }
            }

            /// <remarks/>
            public string TEXTO
            {
                get
                {
                    return this.tEXTOField;
                }
                set
                {
                    this.tEXTOField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class RESPONSEProducto
        {

            private string servicioField;

            private string productoField;

            private ushort idServicioField;

            private ushort idProductoField;

            private byte idCatTipoServicioField;

            private byte tipoFrontField;

            private bool hasDigitoVerificadorField;

            private decimal precioField;

            private bool showAyudaField;

            private string tipoReferenciaField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string servicio
            {
                get
                {
                    return this.servicioField;
                }
                set
                {
                    this.servicioField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string producto
            {
                get
                {
                    return this.productoField;
                }
                set
                {
                    this.productoField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public ushort idServicio
            {
                get
                {
                    return this.idServicioField;
                }
                set
                {
                    this.idServicioField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public ushort idProducto
            {
                get
                {
                    return this.idProductoField;
                }
                set
                {
                    this.idProductoField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public byte idCatTipoServicio
            {
                get
                {
                    return this.idCatTipoServicioField;
                }
                set
                {
                    this.idCatTipoServicioField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public byte tipoFront
            {
                get
                {
                    return this.tipoFrontField;
                }
                set
                {
                    this.tipoFrontField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public bool hasDigitoVerificador
            {
                get
                {
                    return this.hasDigitoVerificadorField;
                }
                set
                {
                    this.hasDigitoVerificadorField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public decimal precio
            {
                get
                {
                    return this.precioField;
                }
                set
                {
                    this.precioField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public bool showAyuda
            {
                get
                {
                    return this.showAyudaField;
                }
                set
                {
                    this.showAyudaField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string tipoReferencia
            {
                get
                {
                    return this.tipoReferenciaField;
                }
                set
                {
                    this.tipoReferenciaField = value;
                }
            }
        }

    
}
