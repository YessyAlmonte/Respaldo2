﻿using Newtonsoft.Json;
using SmsMailUtils.DIalTecService;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SmsMailUtils
{
    public static class SmsMail
    {
        #region  METODOS PARA LAS NOTIFICACIONES POR CORREO Y SMS

        public static void validarTipoNotificaion(List<Notificacion> lstNotificaciones)
        {
            try
            {
                if (lstNotificaciones != null)
                {
                    if (lstNotificaciones.Count > 0)
                    {
                        foreach (var item in lstNotificaciones)
                        {
                            switch ((TIPO_NOTIFICACION)/*socio.tipoNotificacion.idTipoNotificacion*/item.idTipoNotificacion)
                            {
                                case TIPO_NOTIFICACION.SMS:
                                    //mensajeSMS = "SMS: Hola " + CultureInfo.CurrentCulture.TextInfo.ToTitleCase(socio.NombreCompleto.ToLower()) + " " + item.cuerpo;
                                    //MessageBox.Show(mensajeSMS);
                                    //MessageBox.Show(item.cuerpo);
                                    NotificaSMSThread(item);
                                    break;
                                case TIPO_NOTIFICACION.CORREO_ELECTRONICO:
                                    //mensajeEmail = "EMAIL: Hola " + CultureInfo.CurrentCulture.TextInfo.ToTitleCase(socio.NombreCompleto.ToLower()) + " " + item.cuerpo;
                                    //MessageBox.Show(mensajeEmail);
                                    NotificaCorreoThread(item);
                                    break;
                                case TIPO_NOTIFICACION.AMBOS:
                                    break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                EscribirLog("Error al enviar notificacion del socio ." + ex.Message);
            }
        }
        public static void NotificaSMSThread(Notificacion n)
        {
            try
            {
                Thread HiloSms = new Thread(new ThreadStart(() => SendSmsBanca(n)));
                HiloSms.Start();

            }
            catch (Exception ex)
            {
                EscribirLog(ex.Message);
            }

        }
        public static void NotificaCorreoThread(Notificacion n)
        {
            try
            {
                Thread HiloCorreo = new Thread(new ThreadStart(() => SendCorreExterno(n)));
                HiloCorreo.Start();
            }
            catch (Exception ex)
            {
                EscribirLog(ex.Message);
            }
        }
        public static Dictionary<string, string> SendSms(Notificacion n)
        {
            Dictionary<string, string> resultado = new Dictionary<string, string>();
            try
            {
                resultado["result"] = "0";
                if (string.IsNullOrEmpty(n.cuerpo))
                {
                    EscribirLog("No existe notificacion de mensaje para esta operación.");
                    resultado["mensaje"] = "No existe notificacion de mensaje para esta operación.";
                    resultado["result"] = "0";
                    return resultado;
                }
                DIalTecService.DialTec_ServiceClient obj = InitDialTec_ServiceClient();
                string resul = obj.Enviar_SMS(n.celular, RemoveDiacritics(n.cuerpo));
                responseDialtec response = JsonConvert.DeserializeObject<responseDialtec>(resul);

                
                if (string.Compare(response.estatus, "ok", false) == 0)
                {
                    resultado["result"] = "1";
                    resultado["mensaje"] = response.mensaje;
                }
                else
                {
                    EscribirLog("Respuesta Notificacion SMS ." + resul);
                    resultado["mensaje"] = response.mensaje;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Expcecion personaliza de CMV: ocurrio un error al enviar sms: " + ex.Message, ex);
            }
            return resultado;
        }

        public static void SendSmsBanca(Notificacion n)
        {           
            try
            {                
                if (string.IsNullOrEmpty(n.cuerpo))
                {                    
                    EscribirLog("No existe notificacion de mensaje para esta operación.");                    
                    return;
                }
                DIalTecService.DialTec_ServiceClient obj = InitDialTec_ServiceClient();
                string resul = obj.Enviar_SMS(n.celular, RemoveDiacritics(n.cuerpo));
            }
            catch (Exception ex)
            {
                throw new Exception("Expcecion personaliza de CMV: ocurrio un error al enviar sms: " + ex.Message, ex);
            }
  
        }


        public static Dictionary<string, string> SendCorreExterno(Notificacion n)
        {
            Dictionary<string, string> resultado = new Dictionary<string, string>();
            try
            {
                resultado["result"] = "0";
                DIalTecService.DialTec_ServiceClient servicio = InitDialTec_ServiceClient();

                List<Entidades.ArchivoAdjunto> lstAdjuntos = new List<Entidades.ArchivoAdjunto>();
                foreach (var item in n.adjunto)
                {
                    lstAdjuntos.Add(new Entidades.ArchivoAdjunto() { Archivo = item.Archivo, Nombre = item.Nombre });
                }

                DIalTecService.RespuestaAWS result = servicio.EnvioCorreo(n.para.ToArray(), n.cc.ToArray(), n.cco.ToArray(), n.asunto, n.cuerpo, lstAdjuntos.ToArray());
                if (result != null)
                {
                    resultado["mensaje"] = result.Mensaje;
                    resultado["result"] = Convert.ToInt16(result.Estatus).ToString();
                }
                else
                    resultado["mensaje"] = "el resultado del web service de DIALTEC es null";

            }
            catch (Exception ex)
            {
                EscribirLog("Expcecion personaliza de CMV: ocurrio un error al enviar Correo: " + ex.Message, ex);
            }
            return resultado;
        }

        #endregion

        public static string EscribirLog(string mensaje, Exception exec = null)
        {
            string resultado = "todo bien";
            try
            {
                string folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "LogSmsMail");
                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);
                System.IO.File.WriteAllText(Path.Combine(folder, @"Log_" + Guid.NewGuid() + ".txt"), System.DateTime.Now.ToShortDateString() + " | " + System.DateTime.Now.ToShortTimeString() + "\n Error : \n" + mensaje + "\n StackTrace: \n" + exec.StackTrace);
            }
            catch (Exception ex)
            {
                resultado = ex.Message;
            }
            return resultado;
        }
        private static string RemoveDiacritics(string text)
        {
            var normalizedString = text.Normalize(NormalizationForm.FormD);
            var stringBuilder = new StringBuilder();

            foreach (var c in normalizedString)
            {
                var unicodeCategory = CharUnicodeInfo.GetUnicodeCategory(c);
                if (unicodeCategory != UnicodeCategory.NonSpacingMark)
                {
                    stringBuilder.Append(c);
                }
            }

            return stringBuilder.ToString().Normalize(NormalizationForm.FormC);
        }

        private static DialTec_ServiceClient InitDialTec_ServiceClient()
        {
            // se construye los parametros de los binding por codigo,
            // con esto nos evitamos estar copiando y pegando los valores del app.config donde se utilize la dll
            Binding wsBinding = new WSHttpBinding() { Security = new WSHttpSecurity { Mode = SecurityMode.None } };
            EndpointAddress endpointAddress = new
            EndpointAddress("http://cmv4028/DialTec_Service/DialTec_Service.svc");
            return  new DIalTecService.DialTec_ServiceClient(wsBinding, endpointAddress);
        }
    }

    public enum TIPO_NOTIFICACION
    {
        SMS = 1,
        CORREO_ELECTRONICO = 2,
        AMBOS = 3,
    }


    public class Notificacion
    {
        public Notificacion()
        {
            para = new List<string>();
            cc = new List<string>();
            adjunto = new List<ArchivoAdjunto>();
            cco = new List<string>();
        }
        public ExtensionDataObject extencionArchivo { get; set; }

        public string celular { get; set; }
        public string correo { get; set; }
        public TIPO_NOTIFICACION idTipoNotificacion { get; set; }
        public string cuerpo { get; set; }
        public string asunto { get; set; }
        public decimal monto { get; set; }
        public int idMov { get; set; }
        public List<string> para { get; set; }
        public List<string> cc { get; set; }
        public List<string> cco { get; set; }
        public List<ArchivoAdjunto> adjunto { get; set; }
    }

    public class ArchivoAdjunto
    {
        public byte[] Archivo { get; set; }
        public string Nombre { get; set; }
    }

}


