﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmsMailUtils
{
    public class responseDialtec
    {
        public string estatus { get; set; }
        public string mensaje { get; set; }
        public string referencia { get; set; }
        public string codigo { get; set; }
    }
}

