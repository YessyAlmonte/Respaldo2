﻿using AccesoDatos;
using EnviaSmsMail.ServicioConectaPruebas;
using SmsMailUtils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace EnviaSmsMAil
{
    public partial class Form1 : Form
    {
        private DBManager db = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnviaSMS_Click(object sender, EventArgs e)
        {
            try
            {
                
               //MessageBox.Show(String.Format(CultureInfo.InvariantCulture, "{0:M-d-yyyy}", DateTime.Now));
                this.lblEstatus.Text = "-";
                Dictionary<string,string> resul =  SmsMail.SendSms(new Notificacion() { celular = this.txtNumero.Text, cuerpo = this.txtMensaje.Text });
                MessageBox.Show("Estatus Sms: " + (resul["result"].ToString().Equals("1") ? "Enviado" : "Error al enviar" + resul["mensaje"].ToString()));
            }
            catch (Exception ex)
            {
                SmsMail.EscribirLog(ex.Message);
            }
        }

        private void btnCorreo_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            List<Notificacion> notificaciones = new List<Notificacion>();
            Notificacion notificacion = null;
            try
            {
                using (db = new DBManager(ConfigurationManager.AppSettings["conexionString"].ToString()))
                {
                    db.Open();
                    db.CreateParameters(5);
                    db.AddParameters(0, "@numeroSocio", this.txtNoSocio.Text);
                    db.AddParameters(1, "@id_tipo_bitacora", this.txtIdTipoBitacora.Text);
                    db.AddParameters(2, "@id_tipo_notificacion", DBNull.Value);
                    db.AddParameters(3, "@noCel", DBNull.Value);
                    db.AddParameters(4, "@correo", DBNull.Value);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_NOTIFICACION");
                    if (db.DataReader.Read())
                    {
                        if (db.DataReader["estatus"].ToString().Equals("200"))
                        {
                            if (db.DataReader.NextResult())
                            {
                                while (db.DataReader.Read())
                                {
                                    notificacion = new Notificacion();
                                    notificacion.celular = db.DataReader["celular"] == DBNull.Value ? "" : db.DataReader["celular"].ToString();
                                    if (db.DataReader["correo"] != DBNull.Value)
                                    {
                                        notificacion.para.Add(db.DataReader["correo"].ToString());
                                    }
                                    notificacion.idTipoNotificacion = (TIPO_NOTIFICACION)Convert.ToInt16(db.DataReader["idTipoNotificacion"].ToString());
                                    notificacion.cuerpo = db.DataReader["cuerpo"] == DBNull.Value ? null : db.DataReader["cuerpo"].ToString();
                                    notificacion.asunto = db.DataReader["asunto"] == DBNull.Value ? null : db.DataReader["asunto"].ToString();
                                    notificaciones.Add(notificacion);
                                }
                            }
                        }
                    }

                }

                if (notificaciones != null)
                {

                    foreach (var item in notificaciones)
                    {
                        Dictionary<string, string> resul = null;
                        switch ((TIPO_NOTIFICACION)item.idTipoNotificacion)
                        {
                            case TIPO_NOTIFICACION.SMS:
                                 resul =  SmsMail.SendSms(item);
                                MessageBox.Show("Estatus Sms: " + (resul["result"].ToString().Equals("1") ? "Enviado" : "Error al enviar" + resul["mensaje"].ToString()));
                                break;
                            case TIPO_NOTIFICACION.CORREO_ELECTRONICO:
                                resul = SmsMail.SendCorreExterno(item);
                                MessageBox.Show("Estatus Mail: "+ (resul["result"].ToString().Equals("1") ? "Enviado" : "Error al enviar" + resul["mensaje"].ToString()));
                                break;
                            case TIPO_NOTIFICACION.AMBOS:
                                break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show(ex.Message);
            }
            this.Cursor = Cursors.Default;
        }

        private void btnBase_Click(object sender, EventArgs e)
        {
            try
            {
                EndpointAddress endpointAddress = new EndpointAddress("http://192.168.98.55:8080/ConectaWebApp/ConectaServicesImpl");
                var binding = new BasicHttpBinding()
                {
                    Name = "BasicHttpBinding_IFakeService",
                    MaxBufferSize = 2147483647,
                    MaxReceivedMessageSize = 2147483647
                };

                ConectaServicesImplClient c = new ConectaServicesImplClient(binding, endpointAddress);

                Console.WriteLine("Eliminado : " + c.EliminarUsuario("666480"));
                if (this.btnBase.Tag.ToString().Equals("1"))
                {
                    this.btnBase.Tag = 0;
                    var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(this.txtMensaje.Text.ToString());
                    this.txtMensaje.Text = System.Convert.ToBase64String(plainTextBytes);
                }
                else
                {
                    this.btnBase.Tag = 1;
                    var base64EncodedBytes = System.Convert.FromBase64String(this.txtMensaje.Text);
                    this.txtMensaje.Text = System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR : " + ex.Message);
            }
        }
        
        private void btnCorreo_Click_1(object sender, EventArgs e)
        {
            try
            {
              
                this.lblEstatus.Text = "-";
                Notificacion n = new Notificacion();
                n.cuerpo = this.txtMensaje.Text;
                n.para = new List<string>() { this.txtPara.Text };
                n.asunto = "Prueba de Correo";
                Dictionary<string, string> resul = SmsMail.SendCorreExterno(n);
                this.lblEstatus.Text = ("Estatus Mail: " + (resul["result"].ToString().Equals("1") ? "Enviado" : "Error al enviar" + resul["mensaje"].ToString()));

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void BtnValidar_Click(object sender, EventArgs e)
        {
            try
            {
                string apiKey = "161134749e345e2dfe9786e705493b16b9169103f9b4fcdf4b579af90342"; // Replace API_KEY with your API Key
                string emailToValidate = this.txtPara.Text; // Email address which need to be verified
                string responseString = "";
                string apiURL = "http://api.quickemailverification.com/v1/verify?email=" + HttpUtility.UrlEncode(emailToValidate) + "&apikey=" + apiKey;

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(apiURL);
                request.Method = "GET";

                using (WebResponse response = request.GetResponse())
                {
                    using (StreamReader ostream = new StreamReader(response.GetResponseStream()))
                    {
                        responseString = ostream.ReadToEnd();
                        this.lblValido.Text = "Es valido: " + responseString;
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR : " + ex.Message);
            }
        }
    }
}
