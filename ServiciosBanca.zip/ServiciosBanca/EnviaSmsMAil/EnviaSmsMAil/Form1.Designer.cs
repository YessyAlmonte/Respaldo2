﻿namespace EnviaSmsMAil
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEnviaSMS = new System.Windows.Forms.Button();
            this.btnNotificacion = new System.Windows.Forms.Button();
            this.btnBase = new System.Windows.Forms.Button();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.txtMensaje = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCorreo = new System.Windows.Forms.Button();
            this.lblEstatus = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDe = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPara = new System.Windows.Forms.TextBox();
            this.txtNoSocio = new System.Windows.Forms.TextBox();
            this.txtIdTipoBitacora = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.BtnValidar = new System.Windows.Forms.Button();
            this.lblValido = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnEnviaSMS
            // 
            this.btnEnviaSMS.Location = new System.Drawing.Point(40, 325);
            this.btnEnviaSMS.Name = "btnEnviaSMS";
            this.btnEnviaSMS.Size = new System.Drawing.Size(75, 23);
            this.btnEnviaSMS.TabIndex = 0;
            this.btnEnviaSMS.Text = "SMS";
            this.btnEnviaSMS.UseVisualStyleBackColor = true;
            this.btnEnviaSMS.Click += new System.EventHandler(this.btnEnviaSMS_Click);
            // 
            // btnNotificacion
            // 
            this.btnNotificacion.Location = new System.Drawing.Point(40, 380);
            this.btnNotificacion.Name = "btnNotificacion";
            this.btnNotificacion.Size = new System.Drawing.Size(75, 23);
            this.btnNotificacion.TabIndex = 1;
            this.btnNotificacion.Text = "Notificaciones";
            this.btnNotificacion.UseVisualStyleBackColor = true;
            this.btnNotificacion.Click += new System.EventHandler(this.btnCorreo_Click);
            // 
            // btnBase
            // 
            this.btnBase.Location = new System.Drawing.Point(250, 420);
            this.btnBase.Name = "btnBase";
            this.btnBase.Size = new System.Drawing.Size(75, 23);
            this.btnBase.TabIndex = 2;
            this.btnBase.Tag = "1";
            this.btnBase.Text = "Base 64";
            this.btnBase.UseVisualStyleBackColor = true;
            this.btnBase.Click += new System.EventHandler(this.btnBase_Click);
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new System.Drawing.Point(40, 45);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(285, 20);
            this.txtNumero.TabIndex = 3;
            this.txtNumero.Text = "4433740472";
            // 
            // txtMensaje
            // 
            this.txtMensaje.Location = new System.Drawing.Point(40, 197);
            this.txtMensaje.Multiline = true;
            this.txtMensaje.Name = "txtMensaje";
            this.txtMensaje.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtMensaje.Size = new System.Drawing.Size(285, 109);
            this.txtMensaje.TabIndex = 4;
            this.txtMensaje.WordWrap = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Numero";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Mensaje";
            // 
            // btnCorreo
            // 
            this.btnCorreo.Location = new System.Drawing.Point(40, 420);
            this.btnCorreo.Name = "btnCorreo";
            this.btnCorreo.Size = new System.Drawing.Size(75, 23);
            this.btnCorreo.TabIndex = 7;
            this.btnCorreo.Text = "Correo";
            this.btnCorreo.UseVisualStyleBackColor = true;
            this.btnCorreo.Click += new System.EventHandler(this.btnCorreo_Click_1);
            // 
            // lblEstatus
            // 
            this.lblEstatus.AutoSize = true;
            this.lblEstatus.Location = new System.Drawing.Point(40, 309);
            this.lblEstatus.Name = "lblEstatus";
            this.lblEstatus.Size = new System.Drawing.Size(10, 13);
            this.lblEstatus.TabIndex = 8;
            this.lblEstatus.Text = "-";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "De:";
            // 
            // txtDe
            // 
            this.txtDe.Location = new System.Drawing.Point(40, 91);
            this.txtDe.Name = "txtDe";
            this.txtDe.Size = new System.Drawing.Size(285, 20);
            this.txtDe.TabIndex = 9;
            this.txtDe.Text = "yo@cajamorelia.com.mx";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Para";
            // 
            // txtPara
            // 
            this.txtPara.Location = new System.Drawing.Point(40, 143);
            this.txtPara.Name = "txtPara";
            this.txtPara.Size = new System.Drawing.Size(285, 20);
            this.txtPara.TabIndex = 11;
            this.txtPara.Text = "adrian.reyes@cajamorelia.com.mx";
            // 
            // txtNoSocio
            // 
            this.txtNoSocio.Location = new System.Drawing.Point(122, 382);
            this.txtNoSocio.MaxLength = 9;
            this.txtNoSocio.Name = "txtNoSocio";
            this.txtNoSocio.Size = new System.Drawing.Size(100, 20);
            this.txtNoSocio.TabIndex = 13;
            // 
            // txtIdTipoBitacora
            // 
            this.txtIdTipoBitacora.Location = new System.Drawing.Point(274, 382);
            this.txtIdTipoBitacora.MaxLength = 2;
            this.txtIdTipoBitacora.Name = "txtIdTipoBitacora";
            this.txtIdTipoBitacora.Size = new System.Drawing.Size(22, 20);
            this.txtIdTipoBitacora.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(122, 363);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "# Socio";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(250, 363);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Tipo bitacora";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(332, 197);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(100, 109);
            this.richTextBox1.TabIndex = 17;
            this.richTextBox1.Text = "";
            this.richTextBox1.WordWrap = false;
            // 
            // BtnValidar
            // 
            this.BtnValidar.Location = new System.Drawing.Point(332, 143);
            this.BtnValidar.Name = "BtnValidar";
            this.BtnValidar.Size = new System.Drawing.Size(75, 23);
            this.BtnValidar.TabIndex = 18;
            this.BtnValidar.Text = "Validar";
            this.BtnValidar.UseVisualStyleBackColor = true;
            this.BtnValidar.Click += new System.EventHandler(this.BtnValidar_Click);
            // 
            // lblValido
            // 
            this.lblValido.AutoSize = true;
            this.lblValido.Location = new System.Drawing.Point(332, 173);
            this.lblValido.Name = "lblValido";
            this.lblValido.Size = new System.Drawing.Size(53, 13);
            this.lblValido.TabIndex = 19;
            this.lblValido.Text = "Es valido:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 455);
            this.Controls.Add(this.lblValido);
            this.Controls.Add(this.BtnValidar);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtIdTipoBitacora);
            this.Controls.Add(this.txtNoSocio);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPara);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtDe);
            this.Controls.Add(this.lblEstatus);
            this.Controls.Add(this.btnCorreo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMensaje);
            this.Controls.Add(this.txtNumero);
            this.Controls.Add(this.btnBase);
            this.Controls.Add(this.btnNotificacion);
            this.Controls.Add(this.btnEnviaSMS);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEnviaSMS;
        private System.Windows.Forms.Button btnNotificacion;
        private System.Windows.Forms.Button btnBase;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.TextBox txtMensaje;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCorreo;
        private System.Windows.Forms.Label lblEstatus;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDe;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPara;
        private System.Windows.Forms.TextBox txtNoSocio;
        private System.Windows.Forms.TextBox txtIdTipoBitacora;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button BtnValidar;
        private System.Windows.Forms.Label lblValido;
    }
}

