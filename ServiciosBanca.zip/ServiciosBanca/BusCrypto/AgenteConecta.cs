﻿using AgenteConectaWS.ServiceAutenticador;
using AgenteConectaWS.ServiceBusCrypto;
using AgenteConectaWS.ServiceConectaWebApp;
using ServiciosBancaDAO;
using ServiciosBancaEntidades;
using ServiciosBancaUtils;
using System;
using System.ServiceModel;
using ServiciosBancaUtils.Logg;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;

namespace BusCrypto
{
    public static class AgenteConecta
    {
      

        public static String CifrarInformacion(string cadena)
        {
            try
            {
                ConectaCryptographyClient c = AgenteConectaWS.Agente.ObtenerBusCrypto();
                return  c.EncryptionKey(ConexionAPI.ObtenerLlaveBusCrypto(), cadena);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static String DecifrarInformacion(string cadena)
        {
            try
            {
                ConectaCryptographyClient c = AgenteConectaWS.Agente.ObtenerBusCrypto();
                return c.DecryptionKey(ConexionAPI.ObtenerLlaveBusCrypto(), cadena);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static String GenerarLlave()
        {
            string x;
            try
            {
                ConectaCryptographyClient c = AgenteConectaWS.Agente.ObtenerBusCrypto();
                String login = c.loginHSM();
                x = c.GenerateKey("CmvBanca2018", "AES", 256);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return x;
        }

        public static String AgregarAprovisionarToken(Socio socio)
        {
            try
            {
                UserCustom u = new UserCustom();
                u.FirstName = socio.NombreSocio;
                u.Email = socio.Email;
                u.Lastname = socio.Apellidos;
                u.Mobile = socio.Celular;
                u.UserName = socio.NumeroSocio.ToString();

                
                ConectaServicesImplClient c = AgenteConectaWS.Agente.ObtenerConectaWebApp();
                return c.AgregarAprovisionarUsuario(u);
            }
            catch (FaultException ex)
            {
                int codigo=0;
                string mensaje= string.Empty;
                switch (ex.Message)
                {
                    case "Error: 0x01":
                        codigo = 400;
                        mensaje = "No existe el usuario";
                        break;
                    case "Error: 0x02":
                        codigo = 401;
                        mensaje = "No se pudo realizar la adición del usuario";
                        break;
                    case "Error: 0x03":
                        codigo = 402;
                        mensaje = "No ha sido posible el aprovisionamiento del usuario";
                        break;
                    case "Error: 0x04":
                        codigo = 403;
                        mensaje = "Ha ocurrido un error al revocar el token del usuario";
                        break;
                    case "Error: 0x05":
                        codigo = 404;
                        mensaje = "No ha sido posible la eliminación del usuario";
                        break;
                    default:
                        break;
                }

                ExceptionAprovisionarToken errorSAS = new ExceptionAprovisionarToken();
                errorSAS.Codigo = codigo;
                errorSAS.Descripcion = mensaje;
                errorSAS.Mensaje = mensaje;
                throw new FaultException<ExceptionAprovisionarToken>(errorSAS, mensaje);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static String ValidarOTP(string nombreUsuario, string tokenPin)
        {
            string endPointConnecta="";
            try
            {

                //if (string.Compare(tokenPin, "12345") == 0)
                //    return string.Empty;
                //else
                //{
                //    throw new FaultException("El OTP es incorrecto", new FaultCode("314"));
                //}
                 if (!System.Diagnostics.Debugger.IsAttached)
                 {
                    //escribimos en bitacora cuando mandamos llamar OTP
                    RequestValidaOTP requestValidaOTP = new RequestValidaOTP();
                    requestValidaOTP.NumeroSocio = nombreUsuario;
                    requestValidaOTP.OTP = tokenPin;
                    Bitacora<RequestValidaOTP> BitacoraRequestValidaOTP = new Bitacora<RequestValidaOTP>(nombreUsuario, requestValidaOTP, "Autenticar", "");
                    Utilerias.EscribirLogConnecta(SerializerManager<Bitacora<RequestValidaOTP>>.SerealizarObjtecToString(BitacoraRequestValidaOTP));

                    CRYPTOCardImplClient c = AgenteConectaWS.Agente.ObtenerAutenticador();
                    endPointConnecta = c.Endpoint.Address.ToString();
                    string result= c.Autenticar(Convert.ToInt64(nombreUsuario).ToString(), tokenPin);

                    //escribimos en bitacora el result de OTP
                    ResponseValidaOTP responseValidaOTP = new ResponseValidaOTP();
                    responseValidaOTP.Estatus = true;
                    Bitacora<ResponseValidaOTP> BitacoraResponseValidaOTP = new Bitacora<ResponseValidaOTP>(nombreUsuario, responseValidaOTP, "Autenticar", "");
                    Utilerias.EscribirLogConnecta(SerializerManager<Bitacora<ResponseValidaOTP>>.SerealizarObjtecToString(BitacoraResponseValidaOTP));

                    return result;
                }
                 return string.Empty;


            }
            catch (FaultException ex)
            {
                ExceptionValidaOTP exceptionValidaOTP = new ExceptionValidaOTP();
                exceptionValidaOTP.Codigo = 0;                
                exceptionValidaOTP.Mensaje = ex.Message;
                exceptionValidaOTP.Descripcion = "";
                Bitacora<ExceptionValidaOTP> BitacoraResponseValidaOTP = new Bitacora<ExceptionValidaOTP>(nombreUsuario, exceptionValidaOTP, "Autenticar", "");
                Utilerias.EscribirLogConnecta(SerializerManager<Bitacora<ExceptionValidaOTP>>.SerealizarObjtecToString(BitacoraResponseValidaOTP));

                string estatus = string.Empty;
                try
                {
                    estatus = EstatusToken(nombreUsuario);
                    if (string.Compare("SERVER_LOCK", estatus, false) == 0)
                    {
                        throw new FaultException(new ConfiguracionDAO().ActualizarBloqueoOTP(nombreUsuario, TipoBloqueoOTP.ActualizarTiempoRestante), new FaultCode("390"));
                    }
                }
                catch (FaultException exceptionToken)
                {                    
                    throw exceptionToken;
                }               

                throw new FaultException("Datos incorrectos", new FaultCode("314"));

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static String RevocarOTP(string nombreUsuario)
        {
            try
            {
                ConectaServicesImplClient c = AgenteConectaWS.Agente.ObtenerConectaWebApp();
                return  c.RevocarToken(nombreUsuario);
            }
            catch (FaultException ex)
            {
                string estatus = string.Empty;
                switch (ex.Message)
                {
                    case "Error: 0x01":
                        estatus =  "No existe el usuario";
                    break;

                    case "Error: 0x02":
                        estatus = "No se pudo realizar la adición del usuario.";
                        break;

                    case "Error: 0x03":
                        estatus = "No ha sido posible el aprovisionamiento del usuario.";
                        break;

                    case "Error: 0x04":
                        estatus = "Ha ocurrido un error al revocar el token del usuario.";
                        break;

                    case "Error: 0x05":
                        estatus = "No ha sido posible la eliminación del usuario";
                        break;

                }
                ExceptionRevocarToken exceptionRevocarToken = new ExceptionRevocarToken();
                exceptionRevocarToken.Codigo = 416;
                exceptionRevocarToken.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionRevocarToken.Mensaje = estatus;
                throw new FaultException<ExceptionRevocarToken>(exceptionRevocarToken);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static String EstatusToken(string nombreUsuario)
        {
            string endPoint="",estatus = "";
            try
            {
                RequestEstatusToken requestEstatusToken= new RequestEstatusToken();
                requestEstatusToken.NumeroSocio = nombreUsuario;               
                Bitacora<RequestEstatusToken> BitacoraRequestEstatusToken= new Bitacora<RequestEstatusToken>(nombreUsuario, requestEstatusToken, "ObtenerEstatusToken", "");
                Utilerias.EscribirLogConnecta(SerializerManager<Bitacora<RequestEstatusToken>>.SerealizarObjtecToString(BitacoraRequestEstatusToken));

                ConectaServicesImplClient c = AgenteConectaWS.Agente.ObtenerConectaWebApp();
                endPoint = c.Endpoint.Address.ToString();
                estatus = c.ObtenerEstatusToken(nombreUsuario);

                //escribimos en bitacora el result de OTP
                ResponseEstatusToken responseEstatusToken = new ResponseEstatusToken();
                responseEstatusToken.Estatus = estatus;
                Bitacora<ResponseEstatusToken> BitacoraResponseEstatusToken = new Bitacora<ResponseEstatusToken>(nombreUsuario, responseEstatusToken, "ObtenerEstatusToken", "");
                Utilerias.EscribirLogConnecta(SerializerManager<Bitacora<ResponseEstatusToken>>.SerealizarObjtecToString(BitacoraResponseEstatusToken));

                return estatus;//c.ObtenerEstatusToken(nombreUsuario);
            }
            catch (FaultException ex)
            {
                ExceptionEstatusToken exceptionEstatusToken = new ExceptionEstatusToken();
                exceptionEstatusToken.Codigo = 0;
                exceptionEstatusToken.Descripcion = "";
                exceptionEstatusToken.Mensaje = ex.Message;
                Bitacora<ExceptionEstatusToken> BitacoraExpectionEstatusToken = new Bitacora<ExceptionEstatusToken>(nombreUsuario, exceptionEstatusToken, "ObtenerEstatusToken", "");
                Utilerias.EscribirLogConnecta(SerializerManager<Bitacora<ExceptionEstatusToken>>.SerealizarObjtecToString(BitacoraExpectionEstatusToken));

                throw new FaultException("El error al consultar el estatus del token", new FaultCode("314"));

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static String EliminarUsuario(string nombreUsuario)
        {

            try
            {
                ConectaServicesImplClient c = AgenteConectaWS.Agente.ObtenerConectaWebApp();
                return c.EliminarUsuario(nombreUsuario);
            }
            catch (FaultException ex)
            {
                string estatus = string.Empty;
                switch (ex.Message)
                {
                    case "Error: 0x01":
                        estatus = "No existe el usuario";
                        break;

                    case "Error: 0x02":
                        estatus = "No se pudo realizar la adición del usuario.";
                        break;

                    case "Error: 0x03":
                        estatus = "No ha sido posible el aprovisionamiento del usuario.";
                        break;

                    case "Error: 0x04":
                        estatus = "Ha ocurrido un error al revocar el token del usuario.";
                        break;

                    case "Error: 0x05":
                        estatus = "No ha sido posible la eliminación del usuario";
                        break;

                }
                ExceptionEliminarUsuario exceptionRevocarToken = new ExceptionEliminarUsuario();
                exceptionRevocarToken.Codigo = 416;
                exceptionRevocarToken.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionRevocarToken.Mensaje = estatus;
                throw new FaultException<ExceptionEliminarUsuario>(exceptionRevocarToken);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        
        }
    }
}
