﻿using AgenteMail.ServicioValidaMail;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgenteMail
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.lblResult.Text = ValidaMail._ValidaMail(this.txtMail.Text) ? "Valido" : "In-valido " ;
            }
            catch (FaultException<ExceptionValidaCorreo> r)
            {
                MessageBox.Show(r.Message);
            }
            catch (Exception ex )
            {
                MessageBox.Show(ex.Message);
            }
        }
     

        
    }
}
