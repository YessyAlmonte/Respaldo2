﻿using AgenteMail.ServicioValidaMail;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;

namespace AgenteMail
{
    public static class ValidaMail
    {
        private static BasicHttpBinding initBasicHttpBinding()
        {
            return new BasicHttpBinding()
            {
                Name = "BasicHttpBinding_ValidaMail",
                MaxBufferSize = 2147483647,
                MaxReceivedMessageSize = 2147483647,
                SendTimeout = TimeSpan.FromMinutes(5)
            };
        }

        public static bool _ValidaMail(string mail)
        {
            bool bandera = false;
            try
            {
                string url = "http://cmv4024:5556/ValidaMail/Valida.svc";
                EndpointAddress endpointAddress = new EndpointAddress(url);

                ServicioValidaMail.ValidaClient client = new ServicioValidaMail.ValidaClient(initBasicHttpBinding(), endpointAddress);
                using (new OperationContextScope(client.InnerChannel))
                {
                    MessageHeader MessageHeaderUsuario = MessageHeader.CreateHeader("Usuario", "", "CMVF1nZ4S");
                    MessageHeader MessageHeaderContrasena = MessageHeader.CreateHeader("Contrasena", "", "8DED40B6E19F14D1651FDDF063CDD2");
                    OperationContext.Current.OutgoingMessageHeaders.Add(MessageHeaderUsuario);
                    OperationContext.Current.OutgoingMessageHeaders.Add(MessageHeaderContrasena);
                    ResponseValidaCorreo r = client.ValidaCorreo(mail);
                    bandera= r.result.result.ToString().Equals("valid") ? true : false;
                }
            }
            catch (FaultException<ExceptionValidaCorreo> r)
            {
                throw r;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return bandera;
        }
    }
}
