﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Domiciliacion
{
    [DataContract]
    public class TiposPagosDomiciliados
    {
        [DataMember]
        public int idTipoPagoDomiciliados { get; set; }
        [DataMember]
        public int descripcion { get; set; }
    }
}
