﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Domiciliacion
{
    [DataContract]
    public class Domiciliacion
    {
        [DataMember]
        public string NombreCuentaRetiro { get; set; }
        [DataMember]
        public string NombreCuentaDeposito{ get; set; }
        [DataMember]
        public string ClabeCorresponsaliasRetiro { get; set; }
        [DataMember]
        public string ClabeCorresponsaliasDeposito { get; set; }
        [DataMember]
        public string NumeroSocio { get; set; }
        [DataMember]
        public TipoDomiciliacion TipoDomiciliacion { get; set; }
        [DataMember]
        public string DescTipoDomiciliacion { get; set; }
        [DataMember]
        public string NumeroReferencia { get; set; }
        [DataMember]
        public int IdProducto { get; set; }
        [DataMember]
        public string DescProducto { get; set; }
        [DataMember]
        public string DescServicio { get; set; }
        [DataMember]
        public int IdServicio { get; set; }
        [DataMember]
        public TiposDePeriodicidad TipoPeriodicidadPago { get; set; }
        [DataMember]
        public string DescPeriodicidadPago { get; set; }
        [DataMember]
        public DateTime FechaPago { get; set; }
        [DataMember]
        public Decimal  MontoFijo { get; set; }
        [DataMember]
        public bool Indefinido { get; set; }
        [DataMember]
        public DateTime FechaDeVencimiento { get; set; }
        [DataMember]
        public Int64 IdDomiciliacion { get; set; }
        [DataMember]
        public string Alias { get; set; }
        [DataMember]
        public bool Activo { get; set; }

        [DataMember]
        public string NumTarjeta { get; set; }

        [DataMember]
        public string clabe { get; set; }

        [DataMember]
        public string nombreProveedorDest { get; set; }

        [DataMember]
        public string nombreProveedorOrigen { get; set; }

        [DataMember]
        public int diaPago { get; set; }

        [DataMember]
        public string telCelular { get; set; }

        [DataMember]
        public Boolean porMontoFijo { get; set; }

        [DataMember]
        public Boolean porMontoRequerido { get; set; }

        [DataMember]
        public string Ciudad { get; set; }

        [DataMember]
        public string nombreSocio { get; set; }

        [DataMember]
        public Decimal montoMaximo { get; set; }
    }
}
