﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Responses
{
    [DataContract]
    public class ResponseActivarBanca
    {
        [DataMember]
        public String NombreSocio { get; set; }
        [DataMember]
        public String NombreSocioOfuscado { get; set; }
        
        //public Notificacion Notificacion { get; set; }
    }
}
