﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Responses
{
    [DataContract]
    public class ResponseAltaCuentaExternaDebito
    {
        [DataMember]
        public int Estatus { get; set; }

        [DataMember]
        public String Mensaje { get; set; }

    }
}
