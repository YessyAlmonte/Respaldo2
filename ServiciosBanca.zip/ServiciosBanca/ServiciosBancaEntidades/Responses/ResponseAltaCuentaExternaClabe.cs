﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Responses
{
    [DataContract]
     public class ResponseAltaCuentaExternaClabe
    {
        [DataMember]
        public int Estatus { get; set; }

        /// <summary>
        /// representa la descripcion del estatus
        /// </summary>
        [DataMember]
        public string Mensaje { get; set; }
    }
}
