﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Bitacora
{
    [DataContract]
     public class BitacoraOperaciones
    {
        [DataMember]
        public string Hora { get; set; }
        [DataMember]
        public string Fecha { get; set; }
        [DataMember]
        public string DescripcionOperacion { get; set; }
        [DataMember]
        public bool EstatusOperacion { get; set; }
    }
}
