﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Inversiones
{
   [DataContract]
  public class CuentaInversion
    {
        [DataMember]
        public string ClabeCorresponsaliasRetiro { get; set; }

        [DataMember]
        public Decimal Monto { get; set; }
    }
}
