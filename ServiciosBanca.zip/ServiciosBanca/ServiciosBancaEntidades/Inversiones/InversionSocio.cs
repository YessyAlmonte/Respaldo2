﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Inversiones
{
  [DataContract]
    public  class InversionSocio
    {
        [DataMember(Name ="IdInversionSocio")]
        public Int64 numDPF { get; set; }
        [DataMember]
        public string Numerosocio { get; set; }
        //[DataMember]
        //public DateTime Fecha { get; set; }
        [DataMember]
        public String FechaApertura { get; set; }
        [DataMember]
        public Decimal Monto { get; set; }
        [DataMember]
        public Decimal Tasa { get; set; }
        [DataMember]
        public int Dias { get; set; }
        [DataMember]
        public bool sePuedeCancelar { get; set; }

        [DataMember]
        public string FechaCancelable { get; set; }

    }
}
