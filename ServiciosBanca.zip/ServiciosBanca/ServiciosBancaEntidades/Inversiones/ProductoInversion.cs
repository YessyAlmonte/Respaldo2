﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Inversiones
{
    [DataContract]
  public class ProductoInversion
    {
        [DataMember]
        public int IdProductoInversion { get; set; }
        [DataMember]
        public string Descripcion { get; set; }
        [DataMember]
        public int PLazoMin { get; set; }
        [DataMember]
        public int PLazoMax { get; set; }
        /* [DataMember]
       public Decimal MontoMin { get; set; }
        [DataMember]
        public Decimal  MontoMax { get; set; }
        */
    }
}
