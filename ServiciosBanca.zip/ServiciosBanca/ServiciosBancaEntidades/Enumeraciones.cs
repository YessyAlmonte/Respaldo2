﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades
{
    [DataContract]
    public enum TipoCuenta
    {
        [EnumMember]
        TODAS_LAS_CUENTAS = 0,
        [EnumMember]
        HABERES = 1,
        [EnumMember]
        INVERSIONES = 2,
        [EnumMember]
        PRESTAMOS = 3,
        //[EnumMember]
        //HABERES_MAS_INVERSIONES = 4
    }

    [DataContract]
    public enum TipoSocioPuntual
    {
        [EnumMember]
        Ordinario = 1,
        [EnumMember]
        AgroLeal = 2,
        [EnumMember]
        Ninguno = 3
    }

    [DataContract]
    public enum TipoEstadoCuenta
    {
        [EnumMember]
         HABERES = 1,
        [EnumMember]
        PRESTAMO = 2
    }


    [DataContract]
    public enum TipoOrigen
    {
        [EnumMember]
        MOVIL = 1,
        [EnumMember]
        SUCURSAL = 2,
        [EnumMember]
        BANCA_WEB_ = 3,
        [EnumMember]
        DATABANKING = 4,
        //[EnumMember]
        //DOMICILIACION = 13,

    }


    [DataContract]
    public enum TipoBloqueo
    {
        [EnumMember]
        Desbloqueado = 1,
        [EnumMember]
        Bloqueo_temporal_contrasena_incorrecta_3_ocaciones = 2,
        [EnumMember]
        Bloqueo_temporal_respuesta_incorrecta = 3,
        [EnumMember]
        Bloqueo_temporal_365_de_inactividad = 4,
        [EnumMember]
        Bloqueo_temporal_desde_sucursal = 5,
        [EnumMember]
        Bloqueo_temporal_desde_callcenter = 6,
        [EnumMember]
        Bloqueo_temporal_contrasena_caduco = 7,
        [EnumMember]
        Bloqueo_temporal_propio = 8

    }

    [DataContract]
    public enum TipoBusquedaComprobante
    {
        [EnumMember]
        Por_Dia = 1,
        [EnumMember]
        Por_rango_de_dias = 2,
        [EnumMember]
        Por_periodo = 3,
        [EnumMember]
        Por_movimiento = 4,

    }

    public enum TipoAfecta
    {
        DECRECIENTE = 1,
        NIVELADO = 2,
        REVOLVENTE = 3,
        ENTRE_HABERES = 4
    }

    [DataContract]
    public enum TipoCuentaExterna
    {
        [EnumMember]
        Celular_Clabe = 1,
        [EnumMember]
        Tarjeta_Credito = 2,
        [EnumMember]
        Tarjeta_Debito = 3,
        [EnumMember]
        Clabe_Interbancaria = 4,
    }

    [DataContract]
    public enum EstadoTarjeta
    {
        [EnumMember]
        Desbloqueada = 1,
        [EnumMember]
        Bloqueada = 2,
        [EnumMember]
        Todas
    }

    [DataContract]
    public enum TipoBloqueoTarjeta
    {
        [EnumMember]
        Bloqueo_Temporal = 1,
        [EnumMember]
        Bloqueo_Robo = 2,
        [EnumMember]
        Bloqueo_Extravio = 3,
        [EnumMember]
        Ninguno = 4
    }

    [DataContract]
    public enum TipoDomiciliacion
    {
        [EnumMember]
        Prestamos = 1,
        [EnumMember]
        Haberes = 2,
        [EnumMember]
        PagoServicios = 3,
    }

    [DataContract]
    public enum TipoSolicitado
    {
        [EnumMember]
        ServiciosDomiciliados = 1,
        [EnumMember]
        CreditosDomicialiados = 2,
        [EnumMember]
        DomiciliacionesServicios = 3,
        [EnumMember]
        DomiciliacionesCreditos = 4,
    }

    public enum TipoCuentaDepositoInterna
    {
        Cuentas_Haberes_Socios_Mismo_Banco =1,
        Cuentas_Prestamos_Socios_Mismo_Banco = 2,
        Todas_Las_Cuentas_De_Deposito_Internas = 3

    }

    [DataContract]
    public enum TipoCuentaDepositoExterna
    {
        [EnumMember]
        Transferencias_SPEI = 1,
        [EnumMember]
        Pago_Tarjeta_Credito = 2,
        [EnumMember]
        Todas = 3
    }


    [DataContract]
    public enum TipoPagoPtmo
    {
        [EnumMember]
        Liquidacion = 1,
        [EnumMember]
        PagoDiaHoy = 2,
        [EnumMember]
        Adelanto = 3,
        [EnumMember]
        OtraCantidad = 4

    }

    [DataContract]
    public enum TipoAnticipo
    {
        [EnumMember]
        Ninguno = 1, 
        [EnumMember]
        ReduccionPlazo = 2,
        [EnumMember]
        ReduccionAmortizacion = 3 ,
        [EnumMember]
        PagoParaAdelantar = 4

    }

    [DataContract]
    public enum TipoEsquema
    {
        [EnumMember]
        Ninguno = 0,
        [EnumMember]
        Decreciente = 1,
        [EnumMember]
        Nivelado = 2,
        [EnumMember]
        Nivelado_Quincenal = 3,
        [EnumMember]
        Revolvente = 4,


    }

    public enum TipoTransferencia
    {
        // deposito a los haberess propios o terceros mismo banco
        TrasferenciasInternas = 1, 
        //SPEI
        TransferenciasExternas = 2,
        //Pago de servicio
        PagoServicios=3,
        //los pagos a prestamos propios o terceros mismo banco
        PagoPrestamos = 4,
        todos = 5,
        PagosInterbancarios=6
    }

    
    public enum TiposDePeriodicidad
    {
        Diario = 1,
        Quincenal ,
        Mensual,
        Bimestral,
        Trimestral,
        Semestral,
        Anual,
    }

    [DataContract]
    public enum EstatusTransferencia {
        [EnumMember]
        Ninguno = 0,
        [EnumMember]
        Pendiente = 1,
        [EnumMember]
        Realizada = 2 ,
        [EnumMember]
        Rechazada = 3
    }

    public enum TipoTransferenciaInterna
    {
        CuentaPropia = 1,
        CuentaOtroSocio = 2
    }


    public enum TipoTransferenciaExterna
    {
        [EnumMember]
        Enviadas = 2,
        [EnumMember]
        Devueltas = 3
        /*[EnumMember]
        Recibidas = 2,*/
    }

    [DataContract]
    public enum TipoLimiteTransferencias
    {

        [EnumMember]
        Ninguno  =0,

        [EnumMember]
        MinMaxTransferencias = 1,

        [EnumMember]
        HorariosDeTransferencias,

        [EnumMember]
        MinMaxAltaDeCuentas,

        [EnumMember]
        MinMaxTransferenciasInversiones,

        [EnumMember]
        HorarioTransferenciaPTC=12

        //[EnumMember]
        //MinMaxTransferenciasSPEI
    }


    public enum TipoBloqueoOTP
    {
        ninguno =0,
        resetFecha = 1,
        ActualizarTiempoRestante=2
    }


    //public enum TIPO_NOTIFICACION
    //{
    //    SMS = 1,
    //    CORREO_ELECTRONICO = 2,
    //    AMBOS = 3,
    //}

    public enum TipoBitacora
    {

        Cobro_de_solicitud_CMV_Finanzas = 1,
        Genera_la_contraseña_temporal = 2,
        activacion_de_CMV_Finanzas = 3,
        bloqueo_de_cuenta_contraseña_incorrecta_en_3_ocaciones = 4,
        bloqueo_de_cuenta_inactividad_en_365_dias = 5,
        bloqueo_de_cuenta_desde__el_portal_web_o_movil = 6,
        bloqueo_de_cuenta_desde_sucursal = 7,
        bloqueo_de_cuenta_desde_Call_Center = 8,
        desbloqueo_de_cuenta_desde_sucursal = 9,
        desbloqueo_de_cuenta_desde_Call_Center = 10,
        restablecimiento_de_contraseña = 11,
        Olvidó_la_contraseña = 12,
        cancelación_de_servicio_desde_sucursal = 13,
        cambio_de_imagen_antiphishing = 14,
        transferencia_realizada_entre_cuentras_propias = 15,
        transferencia_realizada_cuentas_mismo_banco_entre_socios = 16,
        Transferencia__a_Terceros = 17,
        alta_cuenta_de_tercero = 18,
        depósito_de_Inverplus_CMV = 19,
        retiro_de_Inverplus_CMV = 20,
        Pago_de_Servicio = 21,
        Compra_de_Tiempo_de_Aire = 22,
        pago_realizado_Pago_a_PrestamoEntre_cuentas_propias = 23,
        Pago_programado_Pago_a_Prestamo_Entre_cuentas_propias = 24,
        Domiciliar_Pago = 25,
        Tarjeta_bloqueada_temporalmente = 26,
        Tarjeta_desbloqueada = 27,
        Alta_domiciliación = 28,
        Domiciliación_cancelada = 29,
        alta_de_cuentas_internas_mismo_banco = 30,
        Disponible_para_uso = 31,
        Bloqueo_de_acceso_de_cuenta_propio = 32,
        Bloqueo_temporal_respuesta_incorrecta = 33,
        Bloqueo_temporal_contrasena_caduco = 34,
        Consulta_datos_de_préstamo = 35,
        Tarjeta_bloqueada_por_robo = 36,
        Tarjeta_bloqueada_por_extravio = 37,
        Alta_de_pago_de_servicio = 38,
        Actualizacion_de_pago_de_servicio = 39,
        Solicitud_de_CMV_Finanzas = 40,
        cambio_del_medio_de_notificación = 41,
        Cambio_de_contraseña_para_estado_de_cuenta = 42,
        reposición_de_Token_NIP = 43,
        cambio_del_limite_de_monto = 44,
        cancelación_de_servicio_desde_Call_Center = 45,
        registro_de_CMV_Finanzas = 46,
        cambio_de_respuesta_pregunta = 47,
        baja_cuenta_de_tercero__Baja_de_cuentas_internas_mismo_banco = 48,
        modificación_cuenta_de_tercer__Modificación_de_cuentas_internas_mismo_banco = 49,
        pago_realizadoPago_a_Prestamocuentas_mismo_banco_entre_socios = 50,
        Retiro_de_Inverdinamica_ = 51,
        Retiro_de_Ahorro_ = 52,
        Retiro_de_Débito_ = 53,
        baja_de_cuenta_interna = 54,
        disponible_para_usar = 55,
        Bloqueo_automático_por_inactividad_en_el_servicio_en_365_días_En_base_al_último_acceso = 56,
        Bloqueo_automático_por_bloqueo_de_Imagen = 57,
        Bloqueo_automático_por_bloqueo_alto_de_Cobranza = 58,
        Bloqueo_automático_por_aplicación_de_quebrantos = 59,
        Bloqueo_automático_por_que_se_encuentra_en_proceso_de_bloqueo_de_exclusión = 60,
        Cancelación_automática_por_tener_más_de_180_días_de_bloqueo = 61,
        Cancelación_automática_por_motivo_de_fallecimiento = 62,
        registro_de_reporte_de_callcenter = 63,
        Transferencia_Programada_Entre_cuentas_propias = 70,
        Transferencia_Programada_cuentas_misma_institución_entre_socios =85,
        Pago_programado_Pago_a_Préstamo_Entre_socios=86,
        Bloqueo_automatico_por_intento_o_por__fraude_a_la__cuenta = 87,
        Transferencia_Programada__Entre_cuentas_externas = 88,
        Alta_cuenta_de_externas_Diferentes_instituciones = 89,
        Baja_de_cuenta_externa_Diferentes_instituciones = 90,
        Modificación_de_cuentas_externa_Diferentes_instituciones = 91,
        SPEI_RECIBIDO = 92,        
	    Pago_de_servicio_rechazado = 93,
        Baja_de_pago_de_servicio = 94,
        Bloqueo_automático_por_intento_de_fraude_o_por_fraude_a_la_cuenta = 95,
        SPEI_RECHAZADO = 96,
        Pago_de_Servicio_Codigo_de_Activacion = 97,
        Intento_contraseña_incorrecta = 98,
        Intento_contraseña_correcta = 99,
        Domiciliación_actualizada = 100,
        Pago_domiciliado_rechazado = 101


    }


    [DataContract]
    public enum TipoServicioRecurrente
    {
        [EnumMember]
        Domiciliacion = 1
    }

}
