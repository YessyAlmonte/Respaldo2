﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.CoreRestServices.Responses
{
    public class DescargarEstadoDeCuentaResponse
    {
        [JsonProperty("TipoDato")]
        public string TipoDato { get; set; }
        [JsonProperty("Archivo")]
        public string Archivo { get; set; }
    }
}
