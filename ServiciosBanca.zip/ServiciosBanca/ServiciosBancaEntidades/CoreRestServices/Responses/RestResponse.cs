﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.CoreRestServices.Responses
{
    public class RestResponse <T>
    {
        [JsonProperty("Codigo")]
        public string Codigo { get; set; }
        [JsonProperty("Mensaje")]
        public string Mensaje { get; set; }
        [JsonProperty("Estado")]
        public string Estado { get; set; }
        [JsonProperty("Entidad")]
        public T Entidad { get; set; }
    }
}
