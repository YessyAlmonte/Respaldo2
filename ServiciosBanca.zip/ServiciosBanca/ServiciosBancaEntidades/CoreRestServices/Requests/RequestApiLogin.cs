﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.CoreRestServices.Requests
{
    public class RequestApiLogin
    {
        [JsonProperty("Usuario")]
        public string Usuario { get; set; }

        [JsonProperty("Contrasena")]
        public string Contrasena { get; set; }
    }
}
