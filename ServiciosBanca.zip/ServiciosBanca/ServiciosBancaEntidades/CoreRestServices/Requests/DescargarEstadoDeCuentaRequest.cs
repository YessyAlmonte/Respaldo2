﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.CoreRestServices.Requests
{
    public class DescargarEstadoDeCuentaRequest
    {
        [JsonProperty("TipoEdoCuenta")]
        public string TipoEdoCuenta { get; set; }
        [JsonProperty("Folio")]
        public string Folio { get; set; }
    }
}
