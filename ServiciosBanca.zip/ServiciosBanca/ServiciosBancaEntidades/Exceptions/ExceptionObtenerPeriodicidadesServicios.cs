﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace ServiciosBancaEntidades.Exceptions
{
    [DataContract]
    public class ExceptionObtenerPeriodicidadesServicios
    {
        [DataMember]
        public int Codigo { get; set; }
        [DataMember]
        public String Mensaje { get; set; }
        [DataMember]
        public String Descripcion { get; set; }
    }
}
