﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Imagenes
{
    [DataContract]
   public class Antiphishing
    {
        [DataMember]
        public int idImagenAntiphishing { get; set; }
        [DataMember]
        public byte[] imagen { get; set; }
    }
}
