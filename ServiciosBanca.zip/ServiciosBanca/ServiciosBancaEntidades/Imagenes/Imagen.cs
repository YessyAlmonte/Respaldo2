﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Imagenes
{
    [DataContract]
    public  class Imagen
    {
        [DataMember]
        public int IdImagen { get; set; }
        [DataMember]
        public string Descripcion { get; set; }
        [DataMember]
        public string Titulo { get; set; }
        [DataMember]
        public int  Categoria { get; set; }
        [DataMember]
        public string rutaImagen { get; set; }

        //SE AGREGAN PARA EL DETALLE DE LA PUBLICIDAD
        [DataMember]
        public string FechaInicio { get; set; }
        [DataMember]
        public string FechaFin { get; set; }
        [DataMember]
        public string Detalles { get; set; }
    }
}
