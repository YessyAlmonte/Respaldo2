﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ServiciosBancaEntidades.Cuenta
{
    [DataContract]
    public class Haber : Cuenta
    {
        [DataMember]
        public int IdCuenta { get; set; }
        [DataMember]
        public string UltimoAbono { get; set; }
        [DataMember]
        public string NumeroTarjeta { get; set; }
        [DataMember]
        public EstadoTarjeta EstadoTarjeta { get; set; }
        [DataMember]
        public TipoBloqueoTarjeta TipoBloqueoTarjeta { get; set; }
        [DataMember]
        public Decimal MontoDepositos { get; set; }

        [DataMember]
        public Decimal MontoRetiros { get; set; }
    }
}
