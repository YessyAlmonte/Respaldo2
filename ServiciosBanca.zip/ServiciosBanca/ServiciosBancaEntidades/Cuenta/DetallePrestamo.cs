﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ServiciosBancaEntidades.Cuenta
{
    [DataContract]
    public class DetallePrestamo
    {
        [DataMember]
        public decimal PagoParaLiquidar { get; set; }
        [DataMember]
        public decimal PagoAlDiaDeHoy { get; set; }
        [DataMember]
        public bool PuedeAdelantar { get; set; }
        [DataMember]
        public int IdPeriodicidad { get; set; }
        [DataMember]
        public DateTime DiaCorte { get; set; }
        [DataMember]
        public decimal MontoMaximo { get; set; }
        [DataMember]
        [XmlElement(IsNullable = true)]
        public decimal ? PagoMinimoPeriodo { get; set; }
        [DataMember]
        [XmlElement(IsNullable = true)]
        public decimal ? PagoParaNoGenerarInt { get; set; }
        [DataMember]
        [XmlElement(IsNullable = true)]
        public decimal ? MontoFijo { get; set; }
        [DataMember]
        public TipoEsquema TipoEsquema { get; set; }


    }
}
