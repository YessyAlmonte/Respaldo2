﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ServiciosBancaEntidades.Cuenta
{
    [DataContract]
    [KnownType(typeof(Credito))]
    [KnownType(typeof(Haber))]
    [KnownType(typeof(Inversion))]
    public class Cuenta
    {

        [DataMember]
        public int IdMov { get; set; }
        [DataMember]
        public String NombreCuenta { get; set; }
        [DataMember]
        public Decimal Saldo { get; set; }
        [DataMember]
        public TipoCuenta TipoCuenta { get; set; }
        [DataMember]
        [XmlElement(IsNullable = true)]
        public String NumeroContrato { get; set; }

        [DataMember]
        [XmlElement(IsNullable = true)]
        public String ClabeCorresponsalias { get; set; }

        [DataMember]
        [XmlElement(IsNullable = true)]
        public String ClabeSpei { get; set; }

        [DataMember]
        public String FechaUltimoAbono { get; set; }

        [DataMember]
        public TipoEsquema TipoEsquema { get; set; }

    }
}
