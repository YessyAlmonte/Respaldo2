﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Cuenta
{
    [DataContract]
    public class Credito : Cuenta
    {
        [DataMember]
        public int DiasVencidos { get; set; }
        [DataMember]
        public string EstatusCredito { get; set; }
        [DataMember]
        public double PagoHoy { get; set; }
        [DataMember]
        public int PeriodosAtrasados { get; set; }
        [DataMember]
        public decimal MontoInicial { get; set; }
        [DataMember]
        public DateTime FechaPrestamo { get; set; }
        [DataMember]
        public string FechaCorte { get; set; }
        [DataMember]
        public string FechaLimitePago { get; set; }
        [DataMember]
        public double MontoDisponible { get; set; }
        [DataMember]

        public double LimiteCredito { get; set; }
        [DataMember]
        //public DateTime FechaUltimoPago { get; set; }
        public String FechaUltimoPago { get; set; }
        [DataMember]
        public string ReferenciaCorresponsales { get; set; } //este falta mapear en la bd

        [DataMember]
        public decimal SaldoAdelantado { get; set; }
    }
}
