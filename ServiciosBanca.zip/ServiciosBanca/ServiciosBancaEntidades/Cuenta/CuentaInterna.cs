﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Cuenta
{
    [DataContract]
    public class CuentaInterna
    {
        [DataMember]
        public int idCuentaInterna { get; set; }
        [DataMember]
        public string Alias { get; set; }
        [DataMember]
        public string Referencia { get; set; }
    }
}
