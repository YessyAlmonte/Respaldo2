﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Cuenta
{
    [DataContract]
    public class Movimiento
    {
        [DataMember]
        public decimal Monto { get; set; }
        [DataMember]
        public decimal SaldoPosterior { get; set; }
        [DataMember]
        public String DescripcionMov { get; set; }
        [DataMember]
        public string FechaMov { get; set; }
        [DataMember]
        public string Operacion { get; set; }
        [DataMember]
        public string ClabeSpei { get; set; }
        [DataMember]
        public string ClabeCorresponsalias { get; set; }
    }
}
