﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Configuracion
{
    [DataContract]
  public  class Limite
    {
        [DataMember]
        public string Descripcion { get; set; }
        [DataMember]
        public string Min { get; set; }
        [DataMember]
        public string Max { get; set; }
        [DataMember]
        public TipoLimiteTransferencias tipoLimite { get; set; }
}
}
