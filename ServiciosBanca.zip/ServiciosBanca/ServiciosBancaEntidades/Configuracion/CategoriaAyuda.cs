﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Configuracion
{

    [DataContract]
    public class CategoriaAyuda
    {
        [DataMember]
        public int idCategoria { get; set; }
        [DataMember]
        public string titulo { get; set; }
        [DataMember]
        public List<SeccionAyuda> secciones { get; set; }

        public CategoriaAyuda()
        {
            secciones = new List<SeccionAyuda>();
        }
    }


    [DataContract]
    public class SeccionAyuda
    {
        [DataMember]
        public int idSeccion { get; set; }
        [DataMember]
        public string titulo { get; set; }
        [DataMember]
        public string descripcion { get; set; }
        [DataMember]
        public List<PasoAyuda> pasos { get; set; }
        [DataMember]
        public int idCategoria { get; set; }

        public SeccionAyuda()
        {
            pasos = new List<PasoAyuda>();
        }
    }


    [DataContract]
    public class PasoAyuda
    {
        [DataMember]
        public int idPaso { get; set; }
        [DataMember]
        public string descripcion { get; set; }
        [DataMember]
        public int idSeccion { get; set; }
    }
}
