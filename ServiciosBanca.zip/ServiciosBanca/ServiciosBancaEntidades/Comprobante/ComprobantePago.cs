﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Comprobante
{

// beneficiario varchar(500) null ,
//importe decimal (18,2) null ,
//concepto varchar(500) null , 
//fecha varchar(20) null ,
//hora varchar(20) null ,
//folio bigint null , 
//correo varchar(100) null

    [DataContract]
   public class ComprobantePago
    {
        [DataMember]
        public Int64 IdComprobante { get; set; }
        [DataMember]
        public TipoTransferencia TipoTransferencia { get; set; }
        [DataMember]
        public String Celular { get; set; }
        [DataMember]
        public String BancoDestino { get; set; }
        [DataMember]
        public String Clabe { get; set; }
        //TITULAR  ó BENEFICIARIO
        [DataMember]
        public String TitularCuentaDeposito { get; set; }
        [DataMember]
        public Decimal Importe { get; set; }
        [DataMember]
        public String Concepto { get; set; }
        [DataMember]
        public String FechaAltaTransferencia { get; set; }
        [DataMember]
        public String HoraAltaTransferencia { get; set; }
        [DataMember]
        public String Correo { get; set; }
        [DataMember]
        public Int64 Folio { get; set; }

        [DataMember]
        public string EstadoTransferencia { get; set; }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
        [DataMember]
        public EstatusTransferencia EstatusTransferencia  { get; set; }

        public string FechaTransferenciaRealizada { get; set; }
        [DataMember]
        public string HoraTransferenciaRealizada { get; set; }
        [DataMember]
        public string FechaTransFerenciaProgramada { get; set; }
        [DataMember]
        public string HoraTransferenciaProgramada { get; set; }
        [DataMember]
        public string TitularCuentaRetiro { get; set; }
        [DataMember]
        public bool programdo { get; set; }

        /*Propiedades adicionales para  el PDF de comprobante de pago*/

        public string DescripcionComprobante { get; set; }

        public string ClabeRetiro { get; set; }

        public string ClabeDeposito { get; set; }
    }
}
    