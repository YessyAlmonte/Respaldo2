﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Comprobante
{
    [DataContract]
    public class ComprobantePagoServicio
    {
        [DataMember]
        public Int64 IdComprobante { get; set; }
       
        [DataMember]
        public string ClabeRetiro { get; set; }
        
        [DataMember]
        public string HoraTransaccion { get; set; }
        [DataMember]
        public string FechaTransacion { get; set; }

        [DataMember]
        public string HoraAutorizacion { get; set; }
        [DataMember]
        public string FechaAutorizacion { get; set; }

        [DataMember]
        public Decimal Importe { get; set; }

        [DataMember]
        public Decimal Comision { get; set; }

        [DataMember]
        public string Referencia { get; set; }

        /// <summary>
        /// id_banca_folio
        /// </summary>
        [DataMember]
        public string FolioAutorizacion { get; set; }

        /// <summary>
        /// Folio de autorizacion // y en el comprobante es Aprobación
        /// </summary>
        [DataMember]
        public string NumAutorizacion { get; set; }

        [DataMember]
        public string DescripcionProducto { get; set; }

        [DataMember]
        public int IdProducto { get; set; }

        [DataMember]
        public int IdTipoFront { get; set; }

        [DataMember]
        public string DescripcionServicio { get; set; }

        [DataMember]
        public int IdServicio { get; set; }

        [DataMember]
        public string Telefono { get; set; }

        [DataMember]
        public string EstadoTransferencia { get; set; }

        [DataMember]
        public EstatusTransferencia EstatusTransferencia { get; set; }


        public string leyenda { get; set; }
    }
}
