﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestActivarBanca
    {
        [DataMember (IsRequired =true)]
        public string NumeroSocio { get; set; }
        [DataMember (IsRequired =true)]
        public string NuevaContrasena { get; set; }
        [DataMember (IsRequired =true)]
        public string ContrasenaConfirmada { get; set; }
        [DataMember (IsRequired =true)]
        public int IdPregunta { get; set; }
        [DataMember (IsRequired =true)]
        public string Respuesta { get; set; }
        [DataMember (IsRequired =true)]
        public int IdImagenAntiphishing { get; set; }
        [DataMember (IsRequired =true)]
        public TipoOrigen TipoOrigen { get; set; }
    }
}
