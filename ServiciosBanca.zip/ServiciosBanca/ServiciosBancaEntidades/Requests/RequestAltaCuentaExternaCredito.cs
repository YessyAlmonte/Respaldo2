﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestAltaCuentaExternaCredito
    {
        [DataMember (IsRequired =true)]
        public string NumeroTarjeta { get; set; }

        //[DataMember (IsRequired =true)]
        //public string Clabe { get; set; }

        [DataMember (IsRequired =true)]
        public int  idBanco { get; set; }

        [DataMember (IsRequired =true)]
        public string Alias { get; set; }

        [DataMember (IsRequired =true)]
        public string TitularCuenta { get; set; }

        [DataMember (IsRequired =true)]
        public decimal MontoMaximo { get; set; }

        [DataMember (IsRequired =false)]
        public string Correo { get; set; }

        [DataMember (IsRequired =true)]
        public string NumeroSocio { get; set; }

        [DataMember (IsRequired =true)]
        public string OTP { get; set; }

        [DataMember(IsRequired = false)]
        public string idCuentaExterna { get; set; }

        //[DataMember(IsRequired = true)]
        //public string IdBancoBIN { get; set; }
    }
}
