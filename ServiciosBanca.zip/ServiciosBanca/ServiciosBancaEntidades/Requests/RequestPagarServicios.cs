﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestPagarServicios
    {
        // este si viene 0  quiere decir que el servicio no esta registrado por parte del socio
        [DataMember(IsRequired = false)]
        public int IdServicioSocio { get; set; }

        // debe de traer algun valor que el IdServicioSocio es 0
        [DataMember(IsRequired = false)]
        public string Alias { get; set; }

        [DataMember (IsRequired =true)]
        public int IdProducto { get; set; }

        [DataMember (IsRequired =true)]
        public int IdServicio { get; set; }

        [DataMember (IsRequired =true)]
        public String Telefono { get; set; }

        [DataMember (IsRequired =true)]
        public String NumeroReferencia { get; set; }

        [DataMember (IsRequired =true)]
        public Decimal Monto { get; set; }

        [DataMember (IsRequired =true)]
        public string ClabeCorresponsaliasRetiro { get; set; }

        [DataMember (IsRequired =true)]
        public int TipoFront { get; set; }

        [DataMember (IsRequired =true)]
        public Decimal Precio { get; set; }

        [DataMember (IsRequired =true)]
        public String NumeroSocio { get; set; }

        [DataMember (IsRequired =true)]
        public String OTP { get; set; }

        [DataMember (IsRequired =true)]
        public TipoOrigen TipoOrigen { get; set; }

        [DataMember(IsRequired = true)]
        public Decimal  MontoComision { get; set; }



        /// <summary>
        /// ESTAS PROPIEDADES SON INTERNAS NO SE EXPONEN EN EL WEB SERVICE
        /// </summary>
        /// 

        public string signed { get; set; }

        public string request { get; set; }
        public string response { get; set; }
        
        public Int64 FolioBanca { get; set; }

        public string FolioAutorizacion { get; set; }

        public string Mensaje { get; set; }

        public string Codigo { get; set; }

        public string Pin { get; set; }

        public Int64 EnvioUpc { get; set; }    

        public String HoraLocal { get; set; }



        public string ObtenerParametros()
        {
            string param = "&idServicio=" + this.IdServicio + "&idProducto=" + this.IdProducto;
            switch (this.TipoFront)
            {
                case 1:
                    if (String.IsNullOrEmpty(this.Telefono))
                        throw new Exception("Parametro Telefono es necesario para realizar el pago");
                    param += "&telefono=" + this.Telefono;
                    this.Monto = this.Precio; //Cuando es tipo drin 
                    
                    break;
                case 2:
                    if (String.IsNullOrEmpty(this.NumeroReferencia))
                        throw new Exception("Parametro Numero de Referencia es necesario para realizar el pago");
                    if (String.IsNullOrEmpty(this.Monto.ToString()) || this.Monto == 0)
                        throw new Exception("Parametro Monto es necesario para realizar el pago");
                    param += "&referencia=" + this.NumeroReferencia + "&montoPago=" + this.Monto;
                    break;
                case 4:
                    if (String.IsNullOrEmpty(this.NumeroReferencia))
                        throw new Exception("Parametro Numero de  Referencia es necesario para realizar el pago");
                    param += "&referencia=" + this.NumeroReferencia;
                    break;

                default:
                    break;
            }
            return param;

        }

    }
}
