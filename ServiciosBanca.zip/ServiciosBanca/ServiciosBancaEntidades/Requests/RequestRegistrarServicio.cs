﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
  public  class RequestRegistrarServicio
    {
        [DataMember (IsRequired =true)]
        public int IdProducto { get; set; }
        [DataMember (IsRequired =true)]
        public int IdServicio { get; set; }
        [DataMember (IsRequired =true)]
        public String Telefono { get; set; }
        [DataMember (IsRequired =true)]


        public String NumeroReferencia { get; set; }
        [DataMember (IsRequired =true)]
        public int TipoFront { get; set; }
        [DataMember (IsRequired =true)]
        public Decimal Precio { get; set; }
        [DataMember (IsRequired =true)]
        public String NumeroSocio { get; set; }

        /// <summary>
        /// ES el identificador del servicio cuando esta propiedad es 0 quiere decir nuevo servicio
        /// si esta propiedad es mayor que 0 quiere decir que se va actualizar el servicio
        /// </summary>
        [DataMember (IsRequired =true)]
        public int IdServicioSocio { get; set; }
        [DataMember (IsRequired =true)]
        public TipoOrigen TipoOrigen { get; set; }


        [DataMember(IsRequired = true)]
        public string OTP { get; set; }

        [DataMember(IsRequired = true)]
        public string Alias { get; set; }


    }
}
