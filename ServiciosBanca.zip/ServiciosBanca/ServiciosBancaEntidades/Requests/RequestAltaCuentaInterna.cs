﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestAltaCuentaInterna
    {
        [DataMember (IsRequired =true)]
        public string NumeroSocio { get; set; }
        [DataMember (IsRequired =true)]
        public Int64 IdCuentaInterna { get; set; }
        [DataMember (IsRequired =true)]
        public string Alias { get; set; }
        [DataMember (IsRequired =true)]
        public decimal MontoMaximo { get; set; }
        [DataMember (IsRequired =true)]
        public string Correo { get; set; }
        [DataMember (IsRequired =true)]
        public string OTP { get; set; }
        [DataMember (IsRequired =true)]
        public string ClabeCorresponsalias { get; set; }
        [DataMember (IsRequired =true)]
        public string TitularCuenta { get; set; }
       
       

    }
}
