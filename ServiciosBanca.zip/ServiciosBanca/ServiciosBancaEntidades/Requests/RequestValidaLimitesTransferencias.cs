﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestValidaLimitesTransferencias
    {
        [DataMember(IsRequired=true)]
        public TipoLimiteTransferencias Tipo { get; set; }

    }
}
