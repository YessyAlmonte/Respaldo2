﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
  public   class RequestConsultaSaldo
    {

        // este si viene 0  quiere decir que el servicio no esta registrado por parte del socio
        [DataMember(IsRequired = false)]
        public int IdServicioSocio { get; set; }

        [DataMember(IsRequired = true)]
        public int IdProducto { get; set; }

        [DataMember(IsRequired = true)]
        public int IdServicio { get; set; }

        [DataMember(IsRequired = true)]
        public String Telefono { get; set; }

        [DataMember(IsRequired = true)]
        public String NumeroReferencia { get; set; }

        /// <summary>
        /// Es la suma de las propiedades de MontoComision y Precio para PROSA / ANZEN
        /// </summary>
        [DataMember(IsRequired = true)]
        public Decimal Monto { get; set; }

        [DataMember(IsRequired = false)]
        public string ClabeCorresponsaliasRetiro { get; set; }

        [DataMember(IsRequired = true)]
        public int TipoFront { get; set; }

        [DataMember(IsRequired = true)]
        public Decimal Precio { get; set; }

        [DataMember(IsRequired = true)]
        public String NumeroSocio { get; set; }

        [DataMember(IsRequired = true)]
        public String OTP { get; set; }

        [DataMember(IsRequired = true)]
        public TipoOrigen TipoOrigen { get; set; }

        [DataMember(IsRequired = true)]
        public Decimal MontoComision { get; set; }

        public Int64 EnvioUpc { get; set; }

        public String HoraLocal { get; set; }


    }
}
