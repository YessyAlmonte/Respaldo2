﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestGenerarFormatoDomiciliacion
    {
        [DataMember]
        public int IdDomiciliacion { get; set; }

        [DataMember]
        public string NumeroSocio { get; set; }

        [DataMember]
        public TipoOrigen TipoOrigen { get; set; }

        [DataMember]
        public TipoDomiciliacion TipoDomiciliacion { get; set; }

    }
}
