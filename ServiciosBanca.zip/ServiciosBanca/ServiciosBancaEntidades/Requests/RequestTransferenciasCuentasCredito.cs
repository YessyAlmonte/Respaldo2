﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestTransferenciasCuentasCredito
    {
        [DataMember(IsRequired = true)]
        public string NumeroSocio { get; set; }

        [DataMember(IsRequired = true)]
        public decimal Monto { get; set; }

        [DataMember(IsRequired = true)]
        public string ClabeCorresponsaliasRetiro { get; set; }

        [DataMember(IsRequired = true)]
        public string NumeroTarjeta { get; set; }

        [DataMember(IsRequired = true)]
        public Boolean Programado { get; set; }

        [DataMember(IsRequired = true)]
        public DateTime HoraProgramada { get; set; }

        [DataMember(IsRequired = true)]
        public string ConceptoPago { get; set; }

        [DataMember(IsRequired = true)]
        public string OTP { get; set; }

        [DataMember(IsRequired = true)]
        public TipoOrigen TipoOrigen { get; set; }
    }
}
