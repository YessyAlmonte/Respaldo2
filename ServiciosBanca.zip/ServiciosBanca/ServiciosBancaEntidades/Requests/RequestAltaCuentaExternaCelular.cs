﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestAltaCuentaExternaCelular
    {
        /// <summary>
        /// es el auto-incremental de la tabla 0 es una registro nuevo diferente de 0 es una actualizacion
        /// </summary>
        [DataMember(IsRequired = true)]
        public string IdCuentaExterna { get; set; }
        [DataMember (IsRequired =true)]
        public string NumeroCelular { get; set; }
        [DataMember (IsRequired =true)]
        public int IdBanco { get; set; }
        [DataMember (IsRequired =true)]
        public string TitularCuenta { get; set; }
        [DataMember (IsRequired =true)]
        public decimal MontoMaximo { get; set; }
        [DataMember (IsRequired =true)]
        public string Alias { get; set; }
        [DataMember (IsRequired =true)]
        public string Correo { get; set; }
        [DataMember (IsRequired =true)]
        public string NumeroSocio { get; set; }
        [DataMember (IsRequired =true)]
        public string OTP { get; set; }

        [DataMember(IsRequired = true)]
        public string IdBancoBIN { get; set; }


    }
}
