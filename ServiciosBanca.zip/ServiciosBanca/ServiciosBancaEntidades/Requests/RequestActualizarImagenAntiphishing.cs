﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestActualizarImagenAntiphishing
    {
        [DataMember (IsRequired =true)]
        public string NumeroSocio { get; set; }
        [DataMember (IsRequired =true)]
        public int IdImagenAntiphishing { get; set; }
        [DataMember (IsRequired =true)]
        public string OTP { get; set; }
        [DataMember (IsRequired =true)]
        public TipoOrigen TipoOrigen { get; set; }


    }
}
