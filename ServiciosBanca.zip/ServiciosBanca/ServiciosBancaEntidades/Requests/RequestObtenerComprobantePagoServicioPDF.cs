﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestObtenerComprobantePagoServicioPDF
    {
        [DataMember(IsRequired = true)]
        public string NumeroSocio { get; set; }
        [DataMember(IsRequired = true)]
        public Int64 IdComprobante { get; set; }
        [DataMember(IsRequired = true)]
        public Int64 FolioAutorizacion { get; set; }
        [DataMember(IsRequired = true)]
        public TipoTransferencia TipoTransferencia { get; set; }

        [DataMember(IsRequired = true)]
        public TipoOrigen TipoOrigen { get; set; }
    }
}
