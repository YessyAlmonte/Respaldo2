﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestAltaDomiciliacion
    {

        [DataMember]
        public string ClabeCorresponsaliasRetiro { get; set; }

        /// <summary>
        /// Representa clabe corresponsalias
        /// (Esta cuenta deposito debe de tener valores cuando el tipo de domiciliación sean préstamos y haberes)
        /// de lo contrario su valor debe ser = vacío o nulo, 
        /// Cuando TipoDomiciliacion = Haberes la cuenta de corresponsalías debe pertenecer a una cuenta de haberes(Ahorro, Inverdinámica o Debito)
        /// Cuando TipoDomiciliacion = Prestamos la cuenta de corresponsalias debe pertenecer a una cuenta de prestamos
        /// </summary>
        /*[DataMember (IsRequired =true)]
        public string ClabeCorresponsaliasDeposito { get; set; }
        */
        [DataMember (IsRequired =true)]
        public string NumeroSocio { get; set; }
                
        [DataMember (IsRequired =true)]
        //public TiposPagosDomiciliados TipoDomiciliacion { get; set; }
        public TipoDomiciliacion TipoDomiciliacion { get; set; }

        /// <summary>
        /// Representa el número de referencia        Esta propiedad contiene un valor cuando tipoDomiciliacion=PagoServicios de lo contrario = 0
        /// </summary>
        [DataMember (EmitDefaultValue = true, IsRequired =false)]
        public string NumeroReferencia { get; set; }

        /// <summary>
        /// Representa el identificador del servicio
        ///Esta propiedad contiene un valor cuando tipoDomiciliacion=PagoServicios de lo contrario = 0
        /// </summary>
        [DataMember (EmitDefaultValue =false, IsRequired =false)]
        public int? IdProducto { get; set; }

        /// <summary>
        /// Representa el identificador del servicio
        ///Esta propiedad contiene un valor cuando tipoDomiciliacion=PagoServicios de lo contrario = 0
        /// </summary>
        [DataMember (EmitDefaultValue = false, IsRequired =false)]
        public int? IdServicio { get; set; }

        //[DataMember (IsRequired =true)]
        //public TipoPeriodicidadPago PeriodicidadPago { get; set; }

        [DataMember(EmitDefaultValue = false, IsRequired = false)]
        public RequestPeriodicidad RequestPeriodicidad { get; set; }

        [DataMember (EmitDefaultValue = false, IsRequired =false)]
        public Decimal MontoMaximo { get; set; }

        /*[DataMember (IsRequired =true)]
        public DateTime DiaPago { get; set; }*/

        /*[DataMember (IsRequired =true)]
        public bool Indefinido { get; set; }*/

        [DataMember]
        public DateTime FechaVencimiento { get; set; }

        [DataMember (IsRequired =true)]
        public string Alias { get; set; }

        [DataMember (IsRequired =true)]
        public string OTP { get; set; }

        [DataMember (IsRequired =true)]
        public long IdDomiciliacion { get; set; }

        [DataMember (IsRequired =true)]
        public TipoOrigen TipoOrigen { get; set; }



        [DataMember(IsRequired = true)]
        public Boolean ConVigencia { get; set; }

        [DataMember(IsRequired = true)]
        public Boolean EsIndefinido { get; set; }

        [DataMember(EmitDefaultValue = false, IsRequired = false)]
        public string telefono { get; set; }

        [DataMember(EmitDefaultValue = false, IsRequired = false)]
        public Boolean PorPeriodicidad { get; set; }

        [DataMember(EmitDefaultValue = false, IsRequired = false)]
        public Boolean PorDiaPago { get; set; }

        [DataMember(IsRequired = true)]
        public int? FechaDePago { get; set; }

        [DataMember(EmitDefaultValue = false, IsRequired = false)]
        public int? TipoFront { get; set; }

        [DataMember(EmitDefaultValue = false, IsRequired = false)]
        public string ClabeCorresponsaliasDestino { get; set; }

        [DataMember(EmitDefaultValue = false, IsRequired = false)]
        public Boolean DiaEspecificoDePago { get; set; }

        [DataMember(EmitDefaultValue = false, IsRequired = false)]
        public Boolean DiaLimiteDePago { get; set; }

        [DataMember(EmitDefaultValue = false, IsRequired = false)]
        public decimal Monto { get; set; }

        [DataMember(EmitDefaultValue = false, IsRequired = false)]
        public Boolean MontoRequerido { get; set; }

        [DataMember(EmitDefaultValue = false, IsRequired = false)]
        public Boolean MontoFijo { get; set; }
    }


}
