﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestObtenerComprobantePagoCEP
    {

        [DataMember(IsRequired = true)]
        public String NumeroSocio { get; set; }
        [DataMember(IsRequired = true)]
        public TipoBusquedaComprobante TipoBusquedaComprobante { get; set; }
        [DataMember(IsRequired = true)]
        public DateTime FechaInicio { get; set; }
        [DataMember(IsRequired = true)]
        public DateTime FechaFin { get; set; }

        [DataMember(IsRequired = true)]
        public TipoOrigen TipoOrigen { get; set; }

        [DataMember(IsRequired = true)]
        public TipoTransferenciaExterna TipoTransferenciaExterna { get; set; }

        [DataMember(IsRequired = true)]
        public Int64 FolioAutorizacion { get; set; }
    }
}
