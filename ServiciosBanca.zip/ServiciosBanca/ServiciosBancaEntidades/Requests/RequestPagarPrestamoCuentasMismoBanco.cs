﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestPagarPrestamoCuentasMismoBanco
    {
        [DataMember (IsRequired =true)]
        public string NumeroSocio { get; set; }
        [DataMember (IsRequired =true)]
        public string ClabeCorresponsaliasRetiro { get; set; }
        [DataMember (IsRequired =true)]
        public string ClabeCorresponsaliasDeposito { get; set; }
        [DataMember (IsRequired =true)]
        public Decimal Monto { get; set; }
        
        [DataMember (IsRequired =true)]
        public string OTP { get; set; }
        [DataMember (IsRequired =true)]
        public TipoOrigen TipoOrigen { get; set; }
        [DataMember (IsRequired =true)]
        public DateTime HoraProgramada { get; set; }
        [DataMember (IsRequired =true)]
        public bool Programada { get; set; }
    }
}
