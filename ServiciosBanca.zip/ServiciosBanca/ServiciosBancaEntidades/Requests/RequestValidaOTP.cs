﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
   public class RequestValidaOTP
    {
        [DataMember (IsRequired =true)]
        public String OTP { get; set; }

        [DataMember (IsRequired =true)]
        public String NumeroSocio { get; set; }
    }
}
