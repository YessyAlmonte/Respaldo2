﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestTransferenciasCuentasPropias
    {
        [DataMember (IsRequired =true)]
        public string NumeroSocio { get; set; }
        [DataMember (IsRequired =true)]
        public decimal Monto { get; set; }
        [DataMember (IsRequired =true)]
        public string ClabeCorresponsaliasRetiro { get; set; } // ClabeCorresponsalias debido que el web service ResponseObtenerCuentasRetiro es lo que regresa
        [DataMember (IsRequired =true)]
        //ClabeCorresponsalias debido a que el web service ObtenerCuentasDepositoInterna es el que retorno
        public string ClabeCorresponsaliasDeposito { get; set; }
        [DataMember (IsRequired =true)]
        public DateTime HoraProgramada { get; set; }
        [DataMember (IsRequired =true)]
        public bool Programada { get; set; }
        [DataMember (IsRequired =true)]
        public TipoOrigen tipoOrigen { get; set; }

        [DataMember (IsRequired =true)]
        public string OTP { get; set; }

        //  SI LAS PROPIEDADES NO TIENE LA NOTACION [DataMember (IsRequired =true)] QUIERE DECIR QUE NO SON VISIBLES PARA LOS WEB SERVICE 
        public string idMovDestino { get; set; }

        public Int64 numerSocioDestino { get; set; }

        public Int64 idTransferenica { get; set; }

        public TipoTransferenciaInterna TipoTransferenciaInterna { get; set; }
    }
}
