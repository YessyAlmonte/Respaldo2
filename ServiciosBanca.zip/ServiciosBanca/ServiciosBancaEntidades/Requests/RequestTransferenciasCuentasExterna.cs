﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestTransferenciasCuentasExterna
    {
        [DataMember(IsRequired = true)]
        public string NumeroSocio { get; set; }
        [DataMember(IsRequired = true)]
        public decimal Monto { get; set; }
        [DataMember(IsRequired = true)]
        public string ClabeSPEIRetiro { get; set; }
        [DataMember(IsRequired = true)]
        public string ClabeSPEIDeposito { get; set; }
        [DataMember(IsRequired = true)]
        public DateTime HoraProgramada { get; set; }

        [DataMember(IsRequired = true)]
        public Boolean Programado { get; set; }

        [DataMember(IsRequired = true)]
        public string OTP { get; set; }

        [DataMember(IsRequired = true)]
        public TipoOrigen TipoOrigen { get; set; }

        [DataMember(IsRequired = true)]
        public Int64 IdBanco { get; set; }

        //[DataMember(IsRequired = true)]
        public string Referencia { get; set; }

        [DataMember(IsRequired = true)]
        public string ConceptoPago { get; set; }

        [DataMember(IsRequired = true)]
        public string TitularCuenta { get; set; }

        [DataMember(IsRequired = true)]
        public string IdBancoBIN { get; set; }



    }
}
