﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestObtenerCuentasRetiro
    {
        [DataMember (IsRequired =true)]
        public string NumeroSocio { get; set; }
        //Cuando esta propiedad es=true regresa las cuentas de haber más la cuenta de revolvente activa. 
        //Cuando esta propiedad es = False regresa las cuentas: (Ahorro, Inverdinámica, debito)
        [DataMember (IsRequired =true)]
        public bool ConRevolvente { get; set; }

        [DataMember (IsRequired =true)]
        public TipoOrigen TipoOrigen { get; set; }
    }
}

