﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestBloquearTarjeta
    {
        [DataMember (IsRequired =true)]
        public string NumeroSocio { get; set; }
        [DataMember (IsRequired =true)]
        public string ClabeCorresponsalias { get; set; }
        [DataMember (IsRequired =true)]
        public TipoBloqueoTarjeta TipoBloqueoTarjeta { get; set; }
        [DataMember (IsRequired =true)]
        public string OTP { get; set; }
        [DataMember (IsRequired =true)]
        public TipoOrigen TipoOrigen { get; set; }
    }
}
