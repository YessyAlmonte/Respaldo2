﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.Requests
{
    [DataContract]
    public class RequestObtenerDomiciliacion
    {
        [DataMember (IsRequired =true)]
        public String NumeroSocio { get; set; }

        /// <summary>
        /// si esta bandera  viene un true regresa las domiciliaciones activas
        /// si esta bandera viene en false regresa las docimiliaciones canceladas
        /// </summary>
        [DataMember (IsRequired =true)]
        public bool Activo { get; set; }

        [DataMember(IsRequired = true)]
        public TipoOrigen TipoOrigen { get; set; }

        [DataMember(IsRequired = true)]
        public TipoDomiciliacion TipoDomiciliacion { get; set; }

        [DataMember(IsRequired = true)]
        public TipoSolicitado TipoSolicitado { get; set; }
    }
}
