﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.EstadoCuenta
{
    [DataContract]
   public class EstadoCuenta
    {
        [DataMember]
        public Int64 IdEstadoCuenta { get; set; }
        [DataMember]
        public string Periodo { get; set; }
        [DataMember]
        public TipoEstadoCuenta TipoEstadoCuenta { get; set; }
        [DataMember]
        public string ClabeCorresponsalias { get; set; }

        //[DataMember]
        //public byte[] ArchivoEdoCuenta { get; set; }
    }
}
