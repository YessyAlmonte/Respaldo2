﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades
{
    /*
     * ESTA CLASE SE MIGRO A LA DLL SmsMailUtils
     */
    //public class Notificacion
    //{
    //    public string celular { get; set; }
    //    public string correo { get; set; }
    //    public TIPO_NOTIFICACION idTipoNotificacion { get; set; }
    //    public string cuerpo { get; set; }
    //    public string asunto { get; set; }
    //    public decimal monto { get; set; }
    //    public int idMov { get; set; }
    //}
}
