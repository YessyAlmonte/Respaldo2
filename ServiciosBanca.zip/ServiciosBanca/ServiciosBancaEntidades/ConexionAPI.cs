﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades
{
    public class ConexionAPI
    {
        private static string server = string.Empty;
        private static string bd = string.Empty;
        private static string usuarioSa = string.Empty;
        private static string passUsuarioSa = string.Empty;
        private static string LlaveBusCrypto = string.Empty;

        //public static string Directorio = WebConfigurationManager.AppSettings["Request"].ToString();
        public static string ObtenerConexionSA()
        {
            try
            {
                RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM");
                if (key != null)
                {
                    bd = key.GetValue("1").ToString();
                    usuarioSa = key.GetValue("2").ToString();
                    passUsuarioSa = key.GetValue("3").ToString();
                    server = key.GetValue("4").ToString();
                    
                    key.Close();
                }
                else
                {
                    return string.Empty;
                }
                return @"Server=" + server + ";Database=" + bd + ";User Id=" + usuarioSa + ";Password=" + passUsuarioSa;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string ObtenerLlaveBusCrypto()
        {
            try
            {
                RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM");
                LlaveBusCrypto = key.GetValue("5").ToString();
                key.Close();
                return LlaveBusCrypto;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string ObtenerServerFormatos() {
            return ConfigurationManager.AppSettings["serverFormatos"];
        }
        public static string[] ObtenerUsuariosFormatos()
        {
            try
            {
                RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM");
                if (key != null)
                {
                    usuarioSa = key.GetValue("6").ToString();
                    passUsuarioSa = key.GetValue("7").ToString();
                    key.Close();
                    return new string[] { usuarioSa, passUsuarioSa };
                }
                else
                {
                    return new string[] { string.Empty, string.Empty };
                }
                //return @"Server=" + server + ";Database=" + bd + ";User Id=" + usuarioSa + ";Password=" + passUsuarioSa;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
