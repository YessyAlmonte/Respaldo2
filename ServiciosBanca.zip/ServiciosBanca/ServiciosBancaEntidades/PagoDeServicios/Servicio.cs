﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.PagoDeServicios
{
   [DataContract]
   public class Servicio
    {
        [DataMember]
        public int IdServicio { get; set; }
        [DataMember]
        public string Descripcion { get; set; }

        [DataMember]
        public string logotipoServicio { get; set; }

        [DataMember]
        public string referenciasServicio { get; set; }
    }
}
