﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.PagoDeServicios
{
    [DataContract]
    public class Producto
    {
        [DataMember]
        public int IdProducto { get; set; }
        [DataMember]
        public int IdServicio { get; set; }
        [DataMember]
        public string Descripcion { get; set; }
        [DataMember]
        public int TipoFront { get; set; }
        [DataMember]
        public Decimal Precio { get; set; }
        [DataMember]
        public string TipoReferencia { get; set; }

        [DataMember(IsRequired = true)]
        public int idCatTipoServicio { get; set; }

        [DataMember(IsRequired = true)]
        public Boolean hasDigitoVerificador { get; set; }

        [DataMember(IsRequired = true)]
        public Decimal MontoComision { get; set; }

        [DataMember(IsRequired = true)]
        public string Leyenda { get; set; }


        // estas propiedades no se exponen en el wsdl de producto

        public Int64 FolioBanca { get; set; }

        public bool necesitaPin { get; set; }

    }
}
