﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaEntidades.PagoDeServicios
{
    [DataContract]
  public  class ServicioSocio
    {
        [DataMember]
        public int IdServicioSocio { get; set; }

        [DataMember]
        public int IdProducto { get; set; }
        [DataMember]
        public string Descripcion { get; set; }
        [DataMember]
        public int TipoFront { get; set; }
        [DataMember]
        public decimal Precio { get; set; }
        [DataMember]
        public String TipoReferencia { get; set; }

        [DataMember]
        public int IdServicio { get; set; }

        [DataMember]
        public String Referencia { get; set; }

        [DataMember]
        public string telefono { get; set; }


        /*-----------------*/

        [DataMember(IsRequired = true)]
        public string Alias { get; set; }

        [DataMember(IsRequired = true)]

        public int idCatTipoServicio { get; set; }

        [DataMember(IsRequired = true)]

        public Boolean hasDigitoVerificador { get; set; }

        [DataMember(IsRequired = true)]

        public Decimal MontoComision { get; set; }


    }
}
