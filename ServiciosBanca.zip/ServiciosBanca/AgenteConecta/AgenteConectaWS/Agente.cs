﻿using AgenteConectaWS.ServiceAutenticador;
using AgenteConectaWS.ServiceBusCrypto;
using AgenteConectaWS.ServiceConectaWebApp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;

namespace AgenteConectaWS
{
    public static class Agente
    {
        private static string url = string.Empty;
        private static string hostProductvio = "http://192.168.60.10:8080/";//"http://192.168.60.78:8080/";
        private static string hostPruebas = "http://192.168.98.55:8080/";
        private static BouncyCastleHashing mainHashingLib = null;
        private static int iterations = 100000; // The number of times to encrypt the password - change this
        private static int saltByteSize = 64; // the salt size - change this
        private static int hashByteSize = 128; // the final hash - change this
        private static BasicHttpBinding initBasicHttpBinding()
        {
            return new BasicHttpBinding()
            {
                Name = "BasicHttpBinding_ConectaWebApp",
                MaxBufferSize = 2147483647,
                MaxReceivedMessageSize = 2147483647,
                SendTimeout = TimeSpan.FromMinutes(5)
            };
        }
        public static CRYPTOCardImplClient ObtenerAutenticador()
        {

            CRYPTOCardImplClient autenticador = null;
            try
            {
                url = ConfigurationManager.AppSettings["serviciosProductivo"].ToString().Equals("1") ? hostProductvio : hostPruebas;
                url += "Autenticador/CRYPTOCardImpl";
                EndpointAddress endpointAddress = new EndpointAddress(url);
                autenticador = new ServiceAutenticador.CRYPTOCardImplClient(initBasicHttpBinding(), endpointAddress);

            }
            catch (Exception ex)
            { throw new Exception("Excepcion generar desde la ddl de los servicios de conecta", ex); }

            return autenticador;
        }

        public static ConectaCryptographyClient ObtenerBusCrypto()
        {
            ConectaCryptographyClient conectaCryptographyClient = null;
            try
            {
                url = ConfigurationManager.AppSettings["serviciosProductivo"].ToString().Equals("1") ? hostProductvio : hostPruebas;
                url += "BusCrypto/ConectaCryptography";
                EndpointAddress endpointAddress = new EndpointAddress(url);

                conectaCryptographyClient = new ServiceBusCrypto.ConectaCryptographyClient(initBasicHttpBinding(), endpointAddress);
            }
            catch (Exception ex)
            { throw new Exception("Excepcion generar desde la ddl de los servicios de conecta", ex); }

            return conectaCryptographyClient;
        }

        public static ServiceConectaWebApp.ConectaServicesImplClient ObtenerConectaWebApp()
        {
            ConectaServicesImplClient conectaServicesImplClient = null;
            try
            {
                url = ConfigurationManager.AppSettings["serviciosProductivo"].ToString().Equals("1") ? hostProductvio : hostPruebas;
                url += "/ConectaWebApp/ConectaServicesImpl";
                EndpointAddress endpointAddress = new EndpointAddress(url);
                conectaServicesImplClient = new ServiceConectaWebApp.ConectaServicesImplClient(initBasicHttpBinding(), endpointAddress);
                //if (ConfigurationManager.AppSettings["serviciosProductivo"].ToString().Equals("1"))
                //{
                //    conectaServicesImplClient.ClientCredentials.ClientCertificate.SetCertificate(
                //    StoreLocation.CurrentUser,
                //    StoreName.,
                //    X509FindType.FindBySubjectName,
                //    "contoso.com");
                //}
            }
            catch (Exception ex)
            { throw new Exception("Excepcion generar desde la ddl de los servicios de conecta", ex); }

            return conectaServicesImplClient;
        }

        public static string PBKDF2CreateHash(string contra)
        {
            mainHashingLib = new BouncyCastleHashing();
            byte[] saltCaja = System.Text.Encoding.UTF8.GetBytes("BANCA_CMV_2019");
            string saltString = Convert.ToBase64String(saltCaja);
            string pwdHash = mainHashingLib.PBKDF2_SHA256_GetHash(contra, saltString, iterations, hashByteSize);
            return pwdHash;
        }

        public static bool PBKDF2Valida(string pass, string pwdHash)
        {
            mainHashingLib = new BouncyCastleHashing();
            byte[] saltCaja = System.Text.Encoding.UTF8.GetBytes("BANCA_CMV_2019");
            string saltString = Convert.ToBase64String(saltCaja);
            var isValid  = mainHashingLib.ValidatePassword(pass, saltString, iterations, hashByteSize, pwdHash);
            return isValid;
        }
    }
        
}
