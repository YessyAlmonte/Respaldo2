﻿namespace AgenteConecta
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.txtOtp = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnEstatusToken = new System.Windows.Forms.Button();
            this.btnpbkdf2 = new System.Windows.Forms.Button();
            this.lblPbkdf2 = new System.Windows.Forms.Label();
            this.txtPbk = new System.Windows.Forms.TextBox();
            this.btnComparar = new System.Windows.Forms.Button();
            this.txtPassComparar = new System.Windows.Forms.TextBox();
            this.lblResult = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 30);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Aprovisionar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 130);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 85);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Eliminar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(139, 30);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "Validar OTP";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // txtOtp
            // 
            this.txtOtp.Location = new System.Drawing.Point(221, 30);
            this.txtOtp.Name = "txtOtp";
            this.txtOtp.Size = new System.Drawing.Size(100, 20);
            this.txtOtp.TabIndex = 4;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.richTextBox1);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.btnEstatusToken);
            this.groupBox1.Location = new System.Drawing.Point(12, 182);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(404, 182);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(16, 58);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(382, 118);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(16, 22);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1;
            // 
            // btnEstatusToken
            // 
            this.btnEstatusToken.Location = new System.Drawing.Point(127, 19);
            this.btnEstatusToken.Name = "btnEstatusToken";
            this.btnEstatusToken.Size = new System.Drawing.Size(125, 23);
            this.btnEstatusToken.TabIndex = 0;
            this.btnEstatusToken.Text = "Estatus token";
            this.btnEstatusToken.UseVisualStyleBackColor = true;
            this.btnEstatusToken.Click += new System.EventHandler(this.btnEstatusToken_Click);
            // 
            // btnpbkdf2
            // 
            this.btnpbkdf2.Location = new System.Drawing.Point(368, 26);
            this.btnpbkdf2.Name = "btnpbkdf2";
            this.btnpbkdf2.Size = new System.Drawing.Size(75, 23);
            this.btnpbkdf2.TabIndex = 6;
            this.btnpbkdf2.Text = "pbkdf2";
            this.btnpbkdf2.UseVisualStyleBackColor = true;
            this.btnpbkdf2.Click += new System.EventHandler(this.btnpbkdf2_Click);
            // 
            // lblPbkdf2
            // 
            this.lblPbkdf2.AutoSize = true;
            this.lblPbkdf2.Location = new System.Drawing.Point(451, 37);
            this.lblPbkdf2.Name = "lblPbkdf2";
            this.lblPbkdf2.Size = new System.Drawing.Size(35, 13);
            this.lblPbkdf2.TabIndex = 7;
            this.lblPbkdf2.Text = "label1";
            // 
            // txtPbk
            // 
            this.txtPbk.Location = new System.Drawing.Point(454, 7);
            this.txtPbk.Name = "txtPbk";
            this.txtPbk.Size = new System.Drawing.Size(229, 20);
            this.txtPbk.TabIndex = 8;
            // 
            // btnComparar
            // 
            this.btnComparar.Location = new System.Drawing.Point(368, 75);
            this.btnComparar.Name = "btnComparar";
            this.btnComparar.Size = new System.Drawing.Size(75, 23);
            this.btnComparar.TabIndex = 9;
            this.btnComparar.Text = "Comparar";
            this.btnComparar.UseVisualStyleBackColor = true;
            this.btnComparar.Click += new System.EventHandler(this.btnComparar_Click);
            // 
            // txtPassComparar
            // 
            this.txtPassComparar.Location = new System.Drawing.Point(454, 65);
            this.txtPassComparar.Name = "txtPassComparar";
            this.txtPassComparar.Size = new System.Drawing.Size(229, 20);
            this.txtPassComparar.TabIndex = 10;
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(454, 92);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(35, 13);
            this.lblResult.TabIndex = 11;
            this.lblResult.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.txtPassComparar);
            this.Controls.Add(this.btnComparar);
            this.Controls.Add(this.txtPbk);
            this.Controls.Add(this.lblPbkdf2);
            this.Controls.Add(this.btnpbkdf2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtOtp);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox txtOtp;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnEstatusToken;
        private System.Windows.Forms.Button btnpbkdf2;
        private System.Windows.Forms.Label lblPbkdf2;
        private System.Windows.Forms.TextBox txtPbk;
        private System.Windows.Forms.Button btnComparar;
        private System.Windows.Forms.TextBox txtPassComparar;
        private System.Windows.Forms.Label lblResult;
    }
}

