﻿using AgenteConectaWS.ServiceBusCrypto;
using AgenteConectaWS.ServiceConectaWebApp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgenteConecta
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                ConectaCryptographyClient c = AgenteConectaWS.Agente.ObtenerBusCrypto();
                Console.WriteLine("Resultado: " + c.DecryptionKey("CMV_BANCA_2019", "Victor90"));
            }
            catch (Exception ex)
            {
                Error(ex);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                ConectaServicesImplClient c = AgenteConectaWS.Agente.ObtenerConectaWebApp();
                UserCustom u = new UserCustom();
                u.Email = "var901106@gmail.com";
                u.UserName = "666480";
                u.FirstName = "Victor";
                u.Lastname = "Reyes";

                Console.WriteLine("Resultado: " + c.AgregarAprovisionarUsuario(u));
            }
            catch (Exception ex)
            {

                Error(ex);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                ConectaServicesImplClient c = AgenteConectaWS.Agente.ObtenerConectaWebApp();
                Console.WriteLine("Resultado: " + c.EliminarUsuario("666480"));
            }
            catch (Exception ex)
            {

                Error(ex);
            }

        }

        public void Error(Exception ex)
        {
         
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                AgenteConectaWS.Agente.ObtenerAutenticador().Autenticar("554655", this.txtOtp.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnEstatusToken_Click(object sender, EventArgs e)
        {
            try
            {
                ConectaServicesImplClient c = AgenteConectaWS.Agente.ObtenerConectaWebApp();
                richTextBox1.Text = c.ObtenerEstatusToken(textBox1.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnpbkdf2_Click(object sender, EventArgs e)
        {
            try
            {
                this.lblPbkdf2.Text = AgenteConectaWS.Agente.PBKDF2CreateHash(this.txtPbk.Text);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            try
            {
                this.lblResult.Text = AgenteConectaWS.Agente.PBKDF2Valida(this.txtPassComparar.Text, this.lblPbkdf2.Text).ToString();
            }
            catch (Exception ex) 
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
