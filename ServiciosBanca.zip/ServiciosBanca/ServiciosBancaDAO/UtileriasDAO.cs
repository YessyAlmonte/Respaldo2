﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaUtils.Logg;
using SmsMailUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{
    public class UtileriasDAO
    {
        private DBManager db = null;
        #region NOTIFICACIONES 
        public List<Notificacion> ObtenerNotificacionSocio(string Numero, TipoBitacora tipoBitacora, int? IdServicioSocio = null, long? IdDomiciliacion = null, byte[] bytesArchivo=null,string NombreArchivo=null)
        {
            List<Notificacion> notificaciones = new List<Notificacion>();
            Notificacion notificacion = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(7);
                    db.AddParameters(0, "@numeroSocio", Numero);
                    db.AddParameters(1, "@id_tipo_bitacora", tipoBitacora);
                    db.AddParameters(2, "@id_tipo_notificacion", DBNull.Value);
                    db.AddParameters(3, "@noCel", DBNull.Value);
                    db.AddParameters(4, "@correo", DBNull.Value);
                    db.AddParameters(5, "@IdServicioSocio", IdServicioSocio);
                    db.AddParameters(6, "@IdDomiciliacionSocio", IdDomiciliacion);
                    db.ExecuteReader(CommandType.StoredProcedure, "SP_BANCA_OBTENER_NOTIFICACION");

                    if (db.DataReader.Read())
                    {
                        if (db.DataReader["estatus"].ToString().Equals("200"))
                        {
                            if (db.DataReader.NextResult())
                            {
                                while (db.DataReader.Read())
                                {
                                    notificacion = new Notificacion();
                                    {
                                        notificacion.celular = db.DataReader["celular"] == DBNull.Value ? "" : db.DataReader["celular"].ToString();
                                        notificacion.correo = db.DataReader["correo"] == DBNull.Value ? "" : db.DataReader["correo"].ToString();
                                        notificacion.idTipoNotificacion = (TIPO_NOTIFICACION)Convert.ToInt16(db.DataReader["idTipoNotificacion"].ToString());
                                        notificacion.cuerpo = db.DataReader["cuerpo"] == DBNull.Value ? null : db.DataReader["cuerpo"].ToString();
                                        notificacion.asunto = db.DataReader["asunto"] == DBNull.Value ? null : db.DataReader["asunto"].ToString();
                                        if (db.DataReader["correo"] != DBNull.Value)
                                        {
                                            notificacion.para.Add(db.DataReader["correo"].ToString());
                                        }
                                        if(notificacion.idTipoNotificacion == TIPO_NOTIFICACION.CORREO_ELECTRONICO && bytesArchivo!=null)
                                        {
                                            notificacion.adjunto.Add(new ArchivoAdjunto() { Nombre = NombreArchivo, Archivo = bytesArchivo });
                                        }
                                     
                                    };
                                    notificaciones.Add(notificacion);
                                }
                            }
                        }
                        else{
                            new Logg().Error("Al obtener las notificaciones: " + db.DataReader["mensaje"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                new Logg().Error("Al obtener las notificaciones: " + ex.Message );
            }

            return notificaciones;

        }
        #endregion
    }
}
