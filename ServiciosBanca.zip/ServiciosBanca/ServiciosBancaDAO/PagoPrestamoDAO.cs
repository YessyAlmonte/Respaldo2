﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Cuenta;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{

    public class PagoPrestamoDAO
    {

        private DBManager db = null;


        public DetallePrestamo ObtenerDetallePrestamo(RequestObtenerDetallePrestamo request)
        {
            DetallePrestamo detallePrestamo = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "numeroSocio", request.NumeroSocio);
                    db.AddParameters(1, "ClabeCorresponsalias", request.ClabeCorresponsalias);
                    db.AddParameters(2, "tipoOrigen", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_DETALLE_PRESTAMO");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            detallePrestamo = new DetallePrestamo();
                            detallePrestamo.DiaCorte = db.DataReader["DiaCorte"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(db.DataReader["DiaCorte"].ToString());
                            detallePrestamo.IdPeriodicidad = db.DataReader["IdPeriodicidad"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["IdPeriodicidad"].ToString());
                            detallePrestamo.MontoFijo = db.DataReader["MontoFijo"] == DBNull.Value ? (decimal?)null : Convert.ToDecimal(db.DataReader["MontoFijo"].ToString());
                            detallePrestamo.MontoMaximo = db.DataReader["MontoMaximo"] == DBNull.Value ? 0 : Convert.ToDecimal(db.DataReader["MontoMaximo"].ToString());
                            detallePrestamo.PagoAlDiaDeHoy = db.DataReader["PagoAlDiaDeHoy"] == DBNull.Value ? 0 : Convert.ToDecimal(db.DataReader["PagoAlDiaDeHoy"].ToString());
                            detallePrestamo.PagoMinimoPeriodo = db.DataReader["PagoMinimoPeriodo"] == DBNull.Value ? (decimal?)null : Convert.ToDecimal(db.DataReader["PagoMinimoPeriodo"].ToString());
                            detallePrestamo.PagoParaLiquidar = db.DataReader["PagoParaLiquidar"] == DBNull.Value ? 0 : Convert.ToDecimal(db.DataReader["PagoParaLiquidar"].ToString());
                            detallePrestamo.PagoParaNoGenerarInt = db.DataReader["PagoParaNoGenerarInt"] == DBNull.Value ? (decimal?)null : Convert.ToDecimal(db.DataReader["PagoParaNoGenerarInt"].ToString());
                            detallePrestamo.PuedeAdelantar = string.Equals(db.DataReader["PuedeAdelantar"].ToString(),"F") ? false : true;
                            detallePrestamo.TipoEsquema = db.DataReader["TipoEsquema"] == DBNull.Value ? TipoEsquema.Decreciente : (TipoEsquema)db.DataReader["TipoEsquema"];

                        }
                        else
                        {
                            ExceptionObtenerDetallePrestamo exceptionObtenerDetallePrestamo = new ExceptionObtenerDetallePrestamo();
                            exceptionObtenerDetallePrestamo.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionObtenerDetallePrestamo.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerDetallePrestamo>(exceptionObtenerDetallePrestamo, exceptionObtenerDetallePrestamo.Mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return detallePrestamo;
        }

        public ResponseCalcularImporteAPagar CalcularImporteAPagar(RequestCalcularImporteAPagar request)
        {
            ResponseCalcularImporteAPagar responseCalcularImporteAPagar = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "numeroSocio", request.NumeroSocio);
                    db.AddParameters(1, "ClabeCorresponsalias", request.ClabeCorresponsalias);
                    db.AddParameters(2, "NumeroMensualidades", request.NumeroMensualidades);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_CALCULAR_IMPORTE_A_PAGAR");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            responseCalcularImporteAPagar = new ResponseCalcularImporteAPagar();
                            responseCalcularImporteAPagar.ImporteAPagar = db.DataReader["ImporteAPagar"] == DBNull.Value ? 0 : Convert.ToDecimal(db.DataReader["ImporteAPagar"].ToString());
                        }
                        else
                        {
                            ExceptionCalcularImporteAPagar exceptionCalcularImporteAPagar = new ExceptionCalcularImporteAPagar();
                            exceptionCalcularImporteAPagar.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionCalcularImporteAPagar.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionCalcularImporteAPagar>(exceptionCalcularImporteAPagar, exceptionCalcularImporteAPagar.Mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return responseCalcularImporteAPagar;
        }
    }
}
