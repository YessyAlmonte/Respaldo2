﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.PagoDeServicios;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;
using SmsMailUtils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{
    public class PagoServicioDAO
    {
        private DBManager db = null;

        public ResponseRegistrarServicio RegistrarServicio(RequestRegistrarServicio request)
        {

            ResponseRegistrarServicio response = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(10);
                    db.AddParameters(0, "@IdServicioSocio", request.IdServicioSocio);
                    db.AddParameters(1, "@Numero", request.NumeroSocio);
                    db.AddParameters(2, "@IdProducto", request.IdProducto);
                    db.AddParameters(3, "@IdServicio", request.IdServicio);
                    db.AddParameters(4, "@TipoFront", request.TipoFront);
                    db.AddParameters(5, "@Precio", request.Precio);
                    db.AddParameters(6, "@Telefono", request.Telefono);
                    db.AddParameters(7, "@NumeroReferencia", request.NumeroReferencia);
                    db.AddParameters(8, "@TipoOrigen", request.TipoOrigen);
                    db.AddParameters(9, "@Alias", request.Alias);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_REGISTRAR_SERVICIO");
                    while (db.DataReader.Read())
                    {

                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {

                            response = new ResponseRegistrarServicio();
                            response.Estatus = true;
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, (request.IdServicioSocio == 0 ? TipoBitacora.Alta_de_pago_de_servicio : TipoBitacora.Actualizacion_de_pago_de_servicio), Convert.ToInt32(db.DataReader["IdServicioSocio"].ToString())));

                        }
                        else
                        {
                            ExceptionRegistrarServicio exceptionAprovisionarToken = new ExceptionRegistrarServicio();
                            exceptionAprovisionarToken.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionAprovisionarToken.Mensaje = db.DataReader["mensaje"].ToString();
                            Bitacora<ExceptionRegistrarServicio> bEx = new Bitacora<ExceptionRegistrarServicio>(request.NumeroSocio.ToString(), exceptionAprovisionarToken);
                            new Logg().Info(SerializerManager<Bitacora<ExceptionRegistrarServicio>>.SerealizarObjtecToString(bEx));
                            throw new FaultException<ExceptionRegistrarServicio>(exceptionAprovisionarToken);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }


        #region  FUNCIONES PARA INSERTAR , REALIZAR Y ACTUALIZAR EL PAGO DE UN SERVICIO
        public int? InsertarPagarServicio(RequestPagarServicios request)
        {
            int? idPagoServicioActual = null;
            try
            {
                db = new DBManager(ConexionAPI.ObtenerConexionSA());

                db.Open();
                db.CreateParameters(7);
                db.AddParameters(0, "idProducto", request.IdProducto);
                db.AddParameters(1, "idServicio", request.IdServicio);
                db.AddParameters(2, "ClabeCorresponsaliasRetiro", request.ClabeCorresponsaliasRetiro);
                db.AddParameters(3, "numeroSocio", request.NumeroSocio);
                db.AddParameters(4, "monto", request.Monto);
                db.AddParameters(5, "tipo_origen", request.TipoOrigen);
                db.AddParameters(6, "numeroReferencia", request.NumeroReferencia);
                db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_INSERTAR_PAGO_SERVICIO");
                if (db.DataReader.Read())
                {

                    if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                    {
                        idPagoServicioActual = Convert.ToInt32(db.DataReader["idPagoServicio"].ToString());
                    }
                    else
                    {
                        ExceptionPagarServicios exceptionPagarServicios = new ExceptionPagarServicios();
                        exceptionPagarServicios.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                        exceptionPagarServicios.Mensaje = db.DataReader["mensaje"].ToString();
                        throw new FaultException<ExceptionPagarServicios>(exceptionPagarServicios, exceptionPagarServicios.Mensaje);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return idPagoServicioActual;
        }
        public Producto RealizarPagoServicio(RequestPagarServicios request , bool esConsulta)
        {
            Producto p = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(11);
                    db.AddParameters(0, "ClabeCorresponsaliasRetiro", request.ClabeCorresponsaliasRetiro);
                    db.AddParameters(1, "NumeroSocio", request.NumeroSocio);
                    db.AddParameters(2, "monto", request.Monto);
                    db.AddParameters(3, "IdProducto", request.IdProducto);
                    db.AddParameters(4, "idServicio", request.IdServicio);
                    db.AddParameters(5, "numeroReferencia", request.NumeroReferencia);
                    db.AddParameters(6, "telefono", request.Telefono);
                    db.AddParameters(7, "idTipoPersona", 1);
                    db.AddParameters(8, "@idTipoFront", request.TipoFront);
                    db.AddParameters(9, "tipo_origen", request.TipoOrigen);
                    db.AddParameters(10, "esConsulta", esConsulta);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_REALIZA_PAGO_SERVICIO");
                    if (db.DataReader.Read())
                    {
                        p = new Producto();
                        if (string.Compare(db.DataReader["estatus"].ToString(), "200") == 0)
                        {
                            p.FolioBanca = Convert.ToInt64(string.IsNullOrEmpty(db.DataReader["id_folio_banca"].ToString()) ? "0" : db.DataReader["id_folio_banca"].ToString());
                            p.necesitaPin = Convert.ToBoolean(db.DataReader["necesitaPin"]);
                            p.Leyenda = string.IsNullOrEmpty(db.DataReader["leyenda"].ToString()) ? "" : db.DataReader["leyenda"].ToString();
                        }
                        else
                        {
                            ExceptionPagarServicios exceptionAprovisionarToken = new ExceptionPagarServicios();
                            exceptionAprovisionarToken.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionAprovisionarToken.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionPagarServicios>(exceptionAprovisionarToken, exceptionAprovisionarToken.Mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionPagarServicios exceptionPagarServicios = new ExceptionPagarServicios();
                exceptionPagarServicios.Codigo = 1000;
                exceptionPagarServicios.Mensaje = ex.Message + " | " + ex.Source;
                throw new FaultException<ExceptionPagarServicios>(exceptionPagarServicios, exceptionPagarServicios.Mensaje);
            }
            return p;
        }
        public ResponsePagarServicios ActualizarPagoDeServicio(RequestPagarServicios request)
        {
            ResponsePagarServicios responsePagarServicios = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(10);
                    db.AddParameters(0, "@idBancaFolio", request.FolioBanca);
                    db.AddParameters(1, "@codigo", Convert.ToInt16(request.Codigo));
                    db.AddParameters(2, "@folioAutorizacion", request.FolioAutorizacion);
                    db.AddParameters(3, "@mensaje", request.Mensaje);
                    db.AddParameters(4, "@pin", request.Pin);
                    db.AddParameters(5, "@monto", request.Monto);
                    db.AddParameters(6, "@request", request.request);
                    db.AddParameters(7, "@response", request.response);
                    db.AddParameters(8, "@signed", request.signed);
                    db.AddParameters(9, "@tipoOrigen", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ACTUALIZA_ESTATUS_PAGO_SERVICIO");
                    if (db.DataReader.Read())
                    {
                        if (string.Compare(db.DataReader["estatus"].ToString(), "200") == 0 && db.DataReader["codigo"].ToString().Equals("1"))
                        {
                            responsePagarServicios = new ResponsePagarServicios();
                            responsePagarServicios.FolioAutorizacion = request.FolioAutorizacion.ToString();
                            responsePagarServicios.NumAutorizacion = request.FolioBanca.ToString();
                            responsePagarServicios.Mensaje = request.Mensaje;
                            responsePagarServicios.Pin = request.Pin;
                            responsePagarServicios.EstadoOperacion = EstatusTransferencia.Realizada;
                            responsePagarServicios.Fecha = db.DataReader["fecha_transaccion"].ToString();
                            responsePagarServicios.Hora = db.DataReader["hora_transaccion"].ToString();
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, TipoBitacora.Pago_de_Servicio));
                        }
                        else
                        {
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, TipoBitacora.Pago_de_servicio_rechazado));
                            ExceptionPagarServicios exceptionPagarServicios = new ExceptionPagarServicios();
                            exceptionPagarServicios.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionPagarServicios.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionPagarServicios>(exceptionPagarServicios);
                        }
                    }
                }
            }
            catch (FaultException<ExceptionPagarServicios> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return responsePagarServicios;
        }
        public bool InsertarPagoServicioPendiente(RequestPagarServicios request)
        {
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(5);
                    db.AddParameters(0, "@idBancaFolio", request.FolioBanca);
                    db.AddParameters(1, "@request", request.request);
                    db.AddParameters(2, "@response", request.response);
                    db.AddParameters(3, "@numeroSocio", request.NumeroSocio);
                    db.AddParameters(4, "@signed", request.signed);
                   
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_INSERTAR_PAGOS_SERVICIO_PENDIENTES");
                    if (db.DataReader.Read())
                    {
                        if (string.Compare(db.DataReader["ESTATUS"].ToString(), "1") == 0)
                            return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return false;
        }

        #endregion
    }
}
