﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{
 public class ImagenesDAO
{
        DBManager db;
        //public ResponseObtenerImagenes ObtenerPublicidadGeneral()
        public ResponseObtenerPublicidadGeneral ObtenerPublicidadGeneral()
        {
            ResponseObtenerPublicidadGeneral responseObtenerImagenes;
            try
            {
                responseObtenerImagenes = new ResponseObtenerPublicidadGeneral();
                responseObtenerImagenes.Imagenes = new List<ServiciosBancaEntidades.Imagenes.Imagen>();
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@idTipoImagen", 2);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_IMAGENES");
                    while (db.DataReader.Read())
                    {
                        string rutaImagen = db.DataReader["ruta_imagen"].ToString();
                        ServiciosBancaEntidades.Imagenes.Imagen i = new ServiciosBancaEntidades.Imagenes.Imagen();
                        i.IdImagen = Convert.ToInt16(db.DataReader["id_imagen"]);
                        i.Titulo = db.DataReader["titulo"].ToString();
                        i.Descripcion = db.DataReader["descripcion"].ToString();
                        i.Categoria = string.IsNullOrEmpty(db.DataReader["categoria"].ToString()) ? 0 : Convert.ToInt16(db.DataReader["categoria"].ToString());
                        i.rutaImagen = rutaImagen;
                        i.FechaFin = string.IsNullOrEmpty(db.DataReader["fecha_fin"].ToString()) ? "" : db.DataReader["fecha_fin"].ToString();
                        i.FechaInicio = string.IsNullOrEmpty(db.DataReader["fecha_inicio"].ToString()) ? "" : db.DataReader["fecha_inicio"].ToString();
                        i.Detalles = string.IsNullOrEmpty(db.DataReader["fecha_inicio"].ToString()) ? "" : db.DataReader["detalles"].ToString();
                        /*if (!string.IsNullOrEmpty(rutaImagen))
                        {
                            if(File.Exists(rutaImagen))
                            i.imagen = File.ReadAllBytes(rutaImagen);
                        }*/
                        responseObtenerImagenes.Imagenes.Add(i);
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionObtenerPublicidadGeneral exceptionObtenerImagenFondo = new ExceptionObtenerPublicidadGeneral();
                exceptionObtenerImagenFondo.Codigo = 1000;
                exceptionObtenerImagenFondo.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerImagenFondo.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerPublicidadGeneral> Bex = new Bitacora<ExceptionObtenerPublicidadGeneral>("02", exceptionObtenerImagenFondo, "ObtenerImagenFondo");
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerPublicidadGeneral>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerPublicidadGeneral>(exceptionObtenerImagenFondo, exceptionObtenerImagenFondo.Mensaje);

            }
            return responseObtenerImagenes;
        }

        public string ObtenerFondoPantalla()
        {
            string rutaImagen = string.Empty;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@idTipoImagen", 1);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_IMAGENES");
                    while (db.DataReader.Read())
                    {
                        rutaImagen = db.DataReader["ruta_imagen"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionObtenerFondoPantalla exceptionObtenerImagenFondo = new ExceptionObtenerFondoPantalla();
                exceptionObtenerImagenFondo.Codigo = 1000;
                exceptionObtenerImagenFondo.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerImagenFondo.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerFondoPantalla> Bex = new Bitacora<ExceptionObtenerFondoPantalla>("02", exceptionObtenerImagenFondo, "ObtenerImagenFondo");
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerFondoPantalla>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerFondoPantalla>(exceptionObtenerImagenFondo, exceptionObtenerImagenFondo.Mensaje);

            }
            return rutaImagen;
        }

        public ResponseObtenerPublicidadDirigida ObtenerPublicidadDirigida(RequestObtenerPublicidadDirigida request)
        {
            ResponseObtenerPublicidadDirigida responseObtenerImagenes;
            try
            {
                responseObtenerImagenes = new ResponseObtenerPublicidadDirigida();
                responseObtenerImagenes.Imagenes = new List<ServiciosBancaEntidades.Imagenes.Imagen>();
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@idTipoImagen", 5);
                    db.AddParameters(1, "@numeroSocio", request.NumeroSocio);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_IMAGENES");
                    while (db.DataReader.Read())
                    {
                        string rutaImagen = db.DataReader["ruta_imagen"].ToString();
                        ServiciosBancaEntidades.Imagenes.Imagen i = new ServiciosBancaEntidades.Imagenes.Imagen();
                        i.IdImagen = Convert.ToInt16(db.DataReader["id_imagen"]);
                        i.Titulo = db.DataReader["titulo"].ToString();
                        i.Descripcion = db.DataReader["descripcion"].ToString();
                        i.Categoria = string.IsNullOrEmpty(db.DataReader["categoria"].ToString()) ? 0 : Convert.ToInt16(db.DataReader["categoria"].ToString());
                        i.rutaImagen = rutaImagen;
                        i.FechaFin = string.IsNullOrEmpty(db.DataReader["fecha_fin"].ToString()) ? "" : db.DataReader["fecha_fin"].ToString();
                        i.FechaInicio = string.IsNullOrEmpty(db.DataReader["fecha_inicio"].ToString()) ? "" : db.DataReader["fecha_inicio"].ToString();
                        i.Detalles = string.IsNullOrEmpty(db.DataReader["fecha_inicio"].ToString()) ? "" : db.DataReader["detalles"].ToString();
                        /*if (!string.IsNullOrEmpty(rutaImagen))
                        {
                            if(File.Exists(rutaImagen))
                            i.imagen = File.ReadAllBytes(rutaImagen);
                        }*/
                        responseObtenerImagenes.Imagenes.Add(i);
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionObtenerPublicidadDirigida exceptionObtenerPublicidadDirigida = new ExceptionObtenerPublicidadDirigida();
                exceptionObtenerPublicidadDirigida.Codigo = 1000;
                exceptionObtenerPublicidadDirigida.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerPublicidadDirigida.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerPublicidadDirigida> Bex = new Bitacora<ExceptionObtenerPublicidadDirigida>("02", exceptionObtenerPublicidadDirigida, "ObtenerImagenFondo");
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerPublicidadDirigida>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerPublicidadDirigida>(exceptionObtenerPublicidadDirigida, exceptionObtenerPublicidadDirigida.Mensaje);

            }
            return responseObtenerImagenes;
        }

        public ResponseObtenerImagenesAntiphishing ObtenerImagenesAntiphishing()
        {
            ResponseObtenerImagenesAntiphishing responseObtenerImagenesAntiphishing;
            try
            {
                responseObtenerImagenesAntiphishing = new ResponseObtenerImagenesAntiphishing();
                responseObtenerImagenesAntiphishing.Imagenes = new List<ServiciosBancaEntidades.Imagenes.Antiphishing>();
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_IMAGENES_ANTIPHISHING");
                    while (db.DataReader.Read())
                    {
                        string rutaImagen = db.DataReader["ruta_imagen"].ToString();
                        ServiciosBancaEntidades.Imagenes.Antiphishing i = new ServiciosBancaEntidades.Imagenes.Antiphishing();
                        i.idImagenAntiphishing = Convert.ToInt16(db.DataReader["id_imagen_antiphishing"]);
                        if (!string.IsNullOrEmpty(rutaImagen))
                        {
                            if(File.Exists(rutaImagen))
                            i.imagen = File.ReadAllBytes(rutaImagen);
                        }
                        responseObtenerImagenesAntiphishing.Imagenes.Add(i);
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionObtenerImagenesAntiphishing exceptionObtenerImagenesAntiphishing = new ExceptionObtenerImagenesAntiphishing();
                exceptionObtenerImagenesAntiphishing.Codigo = 1000;
                exceptionObtenerImagenesAntiphishing.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerImagenesAntiphishing.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerImagenesAntiphishing> Bex = new Bitacora<ExceptionObtenerImagenesAntiphishing>("02", exceptionObtenerImagenesAntiphishing, "ObtenerImagenFondo");
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerImagenesAntiphishing>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerImagenesAntiphishing>(exceptionObtenerImagenesAntiphishing, exceptionObtenerImagenesAntiphishing.Mensaje);

            }
            return responseObtenerImagenesAntiphishing;
        }

    }
}
