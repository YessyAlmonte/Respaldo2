﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{
    public class TokenDAO
    {
        private DBManager db = null;
        public ResponseAprovisionarToken AprovisionarToken(RequestAprovisionarToken request)
        {
            ResponseAprovisionarToken response = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@Numero", request.NumeroSocio);
                    db.AddParameters(1, "@Estatus",7);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ACTUALIZA_ESTATUS");
                    while (db.DataReader.Read())
                    {

                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response = new ResponseAprovisionarToken();
                            response.Estatus = true;

                        }
                        else
                        {
                            ExceptionAprovisionarToken exceptionAprovisionarToken = new ExceptionAprovisionarToken();
                            exceptionAprovisionarToken.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionAprovisionarToken.Mensaje = db.DataReader["mensaje"].ToString();
                            Bitacora<ExceptionAprovisionarToken> bEx = new Bitacora<ExceptionAprovisionarToken>(request.NumeroSocio.ToString(), exceptionAprovisionarToken);
                            new Logg().Info(SerializerManager<Bitacora<ExceptionAprovisionarToken>>.SerealizarObjtecToString(bEx));
                            throw new FaultException<ExceptionAprovisionarToken>(exceptionAprovisionarToken);
                        }
                    }
                }
                Bitacora<ResponseAprovisionarToken> b = new Bitacora<ResponseAprovisionarToken>(request.NumeroSocio.ToString(), response);
                //new Logg().Info(SerializerManager<Bitacora<ResponseActivarBanca>>.SerealizarObjtecToString(b));

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
    }
}
