﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Domiciliacion;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Inversiones;
using ServiciosBancaEntidades.PagoDeServicios;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{
    public class CatalogoDAO
    {
        private DBManager db = null;
        public List<ResponseObtenerCatalogoPreguntas> ObtenerCatalogoPreguntas()
        {
            ResponseObtenerCatalogoPreguntas pregunta = null;
            List<ResponseObtenerCatalogoPreguntas> catalogoPreguntas = new List<ResponseObtenerCatalogoPreguntas>();
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_CATALOGO_PREGUNTAS");
                    while (db.DataReader.Read())
                    {
                        //if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        //{
                        pregunta = new ResponseObtenerCatalogoPreguntas();
                        pregunta.IdPregunta = Convert.ToInt32(db.DataReader["id_pregunta_secreta"].ToString());
                        pregunta.Descripcion = String.IsNullOrEmpty(db.DataReader["pregunta_secreta"].ToString()) ? "" : db.DataReader["pregunta_secreta"].ToString();
                        catalogoPreguntas.Add(pregunta);
                        //}
                        //else
                        //{
                        //    ExceptionObtenerCatalogoPreguntas exceptionObtenerCatalogoPreguntas = new ExceptionObtenerCatalogoPreguntas();
                        //    exceptionObtenerCatalogoPreguntas.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                        //    exceptionObtenerCatalogoPreguntas.Mensaje = db.DataReader["mensaje"].ToString();
                        //    throw new FaultException<ExceptionObtenerCatalogoPreguntas>(exceptionObtenerCatalogoPreguntas);
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return catalogoPreguntas;
        }
        public List<ResponseObtenerBancos> ObtenerBancos(RequestObtenerBancos request)
        {
            ResponseObtenerBancos banco = null;
            List<ResponseObtenerBancos> catalogoBancos = new List<ResponseObtenerBancos>();
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(0);
                    //db.AddParameters(0, "@tipoCuentaExterna", request.TipoCuentaExterna);
                    //db.AddParameters(1, "@clabe", string.IsNullOrEmpty(request.Clabe) ? DBNull.Value : (Object)request.Clabe);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_BANCOS");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            db.DataReader.NextResult();
                            while (db.DataReader.Read())
                            {
                                banco = new ResponseObtenerBancos();
                                banco.IdBanco = Convert.ToInt32(db.DataReader["id_banco_spei"].ToString());
                                banco.Descripcion = String.IsNullOrEmpty(db.DataReader["institucion"].ToString()) ? "" : db.DataReader["institucion"].ToString();
                                banco.IdBancoBIN = String.IsNullOrEmpty(db.DataReader["clabe"].ToString()) ? "" : db.DataReader["clabe"].ToString();
                                catalogoBancos.Add(banco);
                            }
                        }
                        else
                        {
                            ExceptionObtenerBancos exceptionObtenerBancos = new ExceptionObtenerBancos();
                            exceptionObtenerBancos.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionObtenerBancos.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerBancos>(exceptionObtenerBancos);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return catalogoBancos;
        }
        public ResponseObtenerPeriodicidad ObtenerPeriodicidad()
        {

            ResponseObtenerPeriodicidad response = new ResponseObtenerPeriodicidad();
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_PERIODICIDAD");
                    while (db.DataReader.Read())
                    {
                        Periodicidad p = new Periodicidad();
                        p.Descripcion = db.DataReader["descripcion"].ToString();
                        p.IdPeriodicidad = Convert.ToInt16(db.DataReader["id_periodicidad_pago"]);
                        response.Periodicidad.Add(p);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
        public ResponseObtenerCategoriasServicios ObtenerCategorias(RequestObtenerCategoriasServicios request)
        {
            ResponseObtenerCategoriasServicios response = new ResponseObtenerCategoriasServicios();
            response.Categorias = new List<Categoria>();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@idGrupo", (request.IdGrupoCategoria == 0 ? DBNull.Value : (Object)request.IdGrupoCategoria));
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_CATEGORIAS_PAGO_SERVICIOS");
                    while (db.DataReader.Read())
                    {
                        Categoria c = new Categoria();
                        c.IdCategoria = Convert.ToInt32(db.DataReader["id_categoria_servicios_pago"].ToString());
                        c.Descripcion = String.IsNullOrEmpty(db.DataReader["descripcion"].ToString()) ? "" : db.DataReader["descripcion"].ToString();
                        response.Categorias.Add(c);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
        public ResponseObtenerServicios ObtenerServicios(RequestObtenerServicios request)
        {
            ResponseObtenerServicios response = new ResponseObtenerServicios();
            response.Servicios = new List<Servicio>();
            try
            {
                string logotipoServicios = ConfigurationManager.AppSettings["logotipoServicios"].ToString();
                string referenciasServicios = ConfigurationManager.AppSettings["referenciasServicios"].ToString();
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@IdCategoria", request.IdCategoria);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_SERVICIOS_PAGO_SERVICIOS");
                    while (db.DataReader.Read())
                    {
                        Servicio s = new Servicio();
                        s.IdServicio = string.IsNullOrEmpty(db.DataReader["id_servicios_pago"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_servicios_pago"].ToString());
                        s.Descripcion = String.IsNullOrEmpty(db.DataReader["descripcion"].ToString()) ? "" : db.DataReader["descripcion"].ToString();
                        s.logotipoServicio = Path.Combine(logotipoServicios, s.IdServicio + ".png");
                        s.referenciasServicio = Path.Combine(referenciasServicios, s.IdServicio + ".jpg");
                        response.Servicios.Add(s);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
        public ResponseObtenerProductos ObtenerProductos(RequestObtenerProductos request)
        {
            ResponseObtenerProductos response = new ResponseObtenerProductos();
            response.Productos = new List<Producto>();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@IdServicio", request.IdServicio);
                    db.AddParameters(1, "@tipo_front", request.tipoFront != 0 || request.tipoFront != null ? request.tipoFront : (object) DBNull.Value);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_PRODUCTOS_PAGO_SERVICIOS");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            db.DataReader.NextResult();
                            while (db.DataReader.Read())
                            {
                                Producto p = new Producto();
                                p.IdProducto = string.IsNullOrEmpty(db.DataReader["id_producto"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_producto"].ToString());
                                p.Descripcion = String.IsNullOrEmpty(db.DataReader["descripcion"].ToString()) ? "" : db.DataReader["descripcion"].ToString();
                                p.Precio = string.IsNullOrEmpty(db.DataReader["precio"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["precio"].ToString());
                                p.TipoFront = string.IsNullOrEmpty(db.DataReader["tipo_front"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["tipo_front"].ToString());
                                p.TipoReferencia = String.IsNullOrEmpty(db.DataReader["tipo_referencia"].ToString()) ? "" : db.DataReader["tipo_referencia"].ToString();
                                p.idCatTipoServicio = String.IsNullOrEmpty(db.DataReader["id_cat_tipo_servicio"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_cat_tipo_servicio"].ToString());
                                p.hasDigitoVerificador = Convert.ToBoolean(db.DataReader["has_digito_verificador"]);
                                p.MontoComision = string.IsNullOrEmpty(db.DataReader["comision_cmv"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["comision_cmv"].ToString());
                                p.Leyenda = string.IsNullOrEmpty(db.DataReader["leyenda"].ToString()) ? "" : db.DataReader["leyenda"].ToString();
                                response.Productos.Add(p);
                            }
                        }
                        else{
                            ExceptionObtenerProductos exception = new ExceptionObtenerProductos();
                            exception.Codigo = Convert.ToInt32(db.DataReader["estatus"].ToString());
                            exception.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerProductos>(exception,exception.Mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
        public ResponseObtenerServiciosRecurrentes ObtenerServiciosRecurrentes(RequestObtenerServiciosRecurrentes request)
        {
            ResponseObtenerServiciosRecurrentes response = new ResponseObtenerServiciosRecurrentes();
            response.Productos = new List<Producto>();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "id_tipo_servicio_frecuente", request.TipoServicioRecurrente);
                    //db.AddParameters(0, "id_origen_operacion", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_PRODUCTOS_PAGO_SERVICIOS_FRECUENTES");
                    while (db.DataReader.Read())
                    {
                        Producto p = new Producto();
                        p.IdProducto = string.IsNullOrEmpty(db.DataReader["id_producto"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_producto"].ToString());
                        p.IdServicio = string.IsNullOrEmpty(db.DataReader["id_servicios_pago"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_servicios_pago"].ToString());
                        p.Descripcion = String.IsNullOrEmpty(db.DataReader["descripcion"].ToString()) ? "" : db.DataReader["descripcion"].ToString();
                        p.Precio = string.IsNullOrEmpty(db.DataReader["precio"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["precio"].ToString());
                        p.TipoFront = string.IsNullOrEmpty(db.DataReader["tipo_front"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["tipo_front"].ToString());
                        p.TipoReferencia = String.IsNullOrEmpty(db.DataReader["tipo_referencia"].ToString()) ? "" : db.DataReader["tipo_referencia"].ToString();

                        p.idCatTipoServicio = String.IsNullOrEmpty(db.DataReader["id_cat_tipo_servicio"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_cat_tipo_servicio"].ToString());
                        p.hasDigitoVerificador = String.IsNullOrEmpty(db.DataReader["has_digito_verificador"].ToString()) ? false : Convert.ToBoolean(db.DataReader["has_digito_verificador"]);
                        p.MontoComision = string.IsNullOrEmpty(db.DataReader["comision_cmv"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["comision_cmv"].ToString());

                        response.Productos.Add(p);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
        public ResponseObtenerServiciosDomiciliadosRecurrentes ObtenerServiciosDomiciliadosRecurrentes()
        {
            ResponseObtenerServiciosDomiciliadosRecurrentes response = new ResponseObtenerServiciosDomiciliadosRecurrentes();
            response.Productos = new List<Producto>();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_PRODUCTOS_PAGO_SERVICIOS_DOMICILIADOS");
                    while (db.DataReader.Read())
                    {
                        Producto p = new Producto();
                        p.IdProducto = string.IsNullOrEmpty(db.DataReader["id_producto"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_producto"].ToString());
                        p.Descripcion = String.IsNullOrEmpty(db.DataReader["descripcion"].ToString()) ? "" : db.DataReader["descripcion"].ToString();
                        p.Precio = string.IsNullOrEmpty(db.DataReader["precio"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["precio"].ToString());
                        p.TipoFront = string.IsNullOrEmpty(db.DataReader["tipo_front"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["tipo_front"].ToString());
                        p.TipoReferencia = String.IsNullOrEmpty(db.DataReader["tipo_referencia"].ToString()) ? "" : db.DataReader["tipo_referencia"].ToString();

                        response.Productos.Add(p);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public ResponseObtenerProductosConsultaSaldo ObtenerProductosConsultaSaldo(RequestObtenerProductosConsultaSaldo request)
        {
            ResponseObtenerProductosConsultaSaldo response = new ResponseObtenerProductosConsultaSaldo();
            response.Productos = new List<Producto>();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@numero", request.NumeroSocio);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_PRODUCTOS_CONSULTA_SALDOS");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            db.DataReader.NextResult();
                            while (db.DataReader.Read())
                            {
                                Producto p = new Producto();
                                p.IdProducto = string.IsNullOrEmpty(db.DataReader["id_producto"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_producto"].ToString());
                                p.Descripcion = String.IsNullOrEmpty(db.DataReader["descripcion"].ToString()) ? "" : db.DataReader["descripcion"].ToString();
                                p.Precio = string.IsNullOrEmpty(db.DataReader["precio"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["precio"].ToString());
                                p.TipoFront = string.IsNullOrEmpty(db.DataReader["tipo_front"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["tipo_front"].ToString());
                                p.TipoReferencia = String.IsNullOrEmpty(db.DataReader["tipo_referencia"].ToString()) ? "" : db.DataReader["tipo_referencia"].ToString();
                                p.idCatTipoServicio = String.IsNullOrEmpty(db.DataReader["id_cat_tipo_servicio"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_cat_tipo_servicio"].ToString());
                                p.hasDigitoVerificador = Convert.ToBoolean(db.DataReader["has_digito_verificador"]);
                                p.MontoComision = string.IsNullOrEmpty(db.DataReader["comision"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["comision"].ToString());
                                p.Leyenda = String.IsNullOrEmpty(db.DataReader["leyenda"].ToString()) ? "" : db.DataReader["leyenda"].ToString();
                                response.Productos.Add(p);
                            }
                        }
                        else
                        {
                            ExceptionObtenerProductosConsultaSaldo exception = new ExceptionObtenerProductosConsultaSaldo();
                            exception.Codigo = Convert.ToInt32(db.DataReader["estatus"].ToString());
                            exception.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerProductosConsultaSaldo>(exception, exception.Mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public ResponseObtenerBancoClabeSPEI ObtenerBancoClabeSPEI(RequestObtenerBancoClabeSPEI request)
        {
            ResponseObtenerBancoClabeSPEI response = new ResponseObtenerBancoClabeSPEI();
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "numero", request.NumeroSocio);
                    db.AddParameters(1, "clabe", request.ClabeSPEI);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_BANCO_POR_CLABE");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.idBanco = Convert.ToInt32(db.DataReader["id_banco_spei"].ToString());
                            response.Institucion = String.IsNullOrEmpty(db.DataReader["institucion"].ToString()) ? "" : db.DataReader["institucion"].ToString();
                            response.Clabe = String.IsNullOrEmpty(db.DataReader["clabe"].ToString()) ? "" : db.DataReader["clabe"].ToString();
                            response.Nombre = String.IsNullOrEmpty(db.DataReader["nombre"].ToString()) ? "" : db.DataReader["nombre"].ToString();
                        }
                        else
                        {
                            ExceptionObtenerBancoClabeSPEI exception = new ExceptionObtenerBancoClabeSPEI();
                            exception.Codigo = Convert.ToInt32(db.DataReader["estatus"].ToString());
                            exception.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerBancoClabeSPEI>(exception, exception.Mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

        #region Inversiones
        public ResponseObtenerProductosInversion ObtenerProductosInversion()
        {

            ResponseObtenerProductosInversion response = null;
            try
            {
                response = new ResponseObtenerProductosInversion();
                response.ProductosInversiones = new List<ServiciosBancaEntidades.Inversiones.ProductoInversion>();
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_TIPOS_INVERSION");
                    if (db.DataReader.Read())
                    {
                        if (string.Compare(db.DataReader["estatus"].ToString(), "200") == 0)
                        {
                            db.DataReader.NextResult();
                            while (db.DataReader.Read())
                            {
                                ProductoInversion p = new ProductoInversion();
                                p.IdProductoInversion = string.IsNullOrEmpty(db.DataReader["id_tipo_inversion"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_tipo_inversion"].ToString());
                                p.Descripcion = String.IsNullOrEmpty(db.DataReader["descripcion"].ToString()) ? "" : db.DataReader["descripcion"].ToString();
                                p.PLazoMax = string.IsNullOrEmpty(db.DataReader["plazo_Max"].ToString()) ? 0 : Convert.ToInt16(db.DataReader["plazo_Max"].ToString());
                                p.PLazoMin = string.IsNullOrEmpty(db.DataReader["plazo_Min"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["plazo_Min"].ToString());
                                response.ProductosInversiones.Add(p);
                            }
                        }
                        else
                        {
                            ExceptionObtenerProductosInversion exceptionObtenerProductosInversion = new ExceptionObtenerProductosInversion();
                            exceptionObtenerProductosInversion.Codigo = 1000;
                            exceptionObtenerProductosInversion.Descripcion = db.DataReader["mensaje"].ToString();
                            exceptionObtenerProductosInversion.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerProductosInversion>(exceptionObtenerProductosInversion, db.DataReader["mensaje"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return response;
        }
        public ResponseObtenerTasaInversion ObtenerTasaInversion(RequestObtenerTasaInversion request)
        {
            ResponseObtenerTasaInversion response = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "@Monto", request.Monto);
                    db.AddParameters(1, "@Plazo", request.Dias);
                    db.AddParameters(2, "@numeroSocio", request.NumeroSocio);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_TASA_INVERSION");
                    if (db.DataReader.Read())
                    {
                        if (string.Compare(db.DataReader["estatus"].ToString(), "200") == 0)
                        {
                            response = new ResponseObtenerTasaInversion();
                            //db.DataReader.NextResult();
                            //while (db.DataReader.Read())
                            //{
                            response.Tasa = Convert.ToDecimal(db.DataReader["Tasa"].ToString());

                            //}
                        }
                        else
                        {
                            ExceptionObtenerTasaInversion exceptionObtenerTasaInversion = new ExceptionObtenerTasaInversion();
                            exceptionObtenerTasaInversion.Codigo = Convert.ToInt32(db.DataReader["estatus"].ToString());
                            exceptionObtenerTasaInversion.Descripcion = db.DataReader["mensaje"].ToString();
                            exceptionObtenerTasaInversion.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerTasaInversion>(exceptionObtenerTasaInversion, db.DataReader["mensaje"].ToString());
                        }
                    }
                }
            }
            catch (FaultException<ExceptionObtenerTasaInversion> eot)
            {
                throw eot;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return response;
        }




        #endregion
    }
}
