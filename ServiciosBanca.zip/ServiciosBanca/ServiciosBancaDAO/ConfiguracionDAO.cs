﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Configuracion;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{
    public class ConfiguracionDAO
    {
        private DBManager db = null;

        public ResponseObtenerLimitesTransferencias ObtenerLimitesTransferencias()
        {
            ResponseObtenerLimitesTransferencias LstLimites = new ResponseObtenerLimitesTransferencias();
            LstLimites.LimitesMontos = new List<Limite>();
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_LIMITES_TRANSFERENCIAS");
                    while (db.DataReader.Read())
                    {
                        Limite l = new Limite();
                        l.Descripcion = db.DataReader["descripcion"].ToString();
                        l.Max = string.IsNullOrEmpty(db.DataReader["maximo"].ToString()) ? "0" : db.DataReader["maximo"].ToString();
                        l.Min = string.IsNullOrEmpty(db.DataReader["minimo"].ToString()) ? "0" : db.DataReader["minimo"].ToString();
                        l.tipoLimite = string.IsNullOrEmpty(db.DataReader["id_limite_transferencia"].ToString()) ? TipoLimiteTransferencias.Ninguno : (TipoLimiteTransferencias) Convert.ToInt16((db.DataReader["id_limite_transferencia"]));
                        LstLimites.LimitesMontos.Add(l);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return LstLimites;
        }

        public ResponseObtenerAyuda ObtenerAyuda()
        {
            ResponseObtenerAyuda ayuda = new ResponseObtenerAyuda();
            try
            {
                List<CategoriaAyuda> categoriasAyuda = new List<CategoriaAyuda>();
                List<SeccionAyuda> seccionesAyuda = new List<SeccionAyuda>();
                List<PasoAyuda> pasosAyuda = new List<PasoAyuda>();
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_CONFIGURACION_AYUDA");
                    while (db.DataReader.Read())
                    {
                        if (db.DataReader["estatus"].ToString().Equals("200"))
                        {
                            CategoriaAyuda categoriaAyuda = new CategoriaAyuda();
                            categoriaAyuda.idCategoria = db.DataReader["id_ayuda_categoria"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["id_ayuda_categoria"].ToString());
                            categoriaAyuda.titulo = db.DataReader["titulo"] == DBNull.Value ? "" : db.DataReader["titulo"].ToString();
                            categoriasAyuda.Add(categoriaAyuda);
                        }
                    }
                    db.DataReader.NextResult();

                    while (db.DataReader.Read())
                    {
                        if (db.DataReader["estatus"].ToString().Equals("200"))
                        {
                            SeccionAyuda seccionAyuda = new SeccionAyuda();
                            seccionAyuda.idSeccion = db.DataReader["id_ayuda_seccion"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["id_ayuda_seccion"].ToString());
                            seccionAyuda.titulo = db.DataReader["titulo"] == DBNull.Value ? "" : db.DataReader["titulo"].ToString();
                            seccionAyuda.descripcion = db.DataReader["descripcion"] == DBNull.Value ? "" : db.DataReader["descripcion"].ToString();
                            seccionAyuda.idCategoria = db.DataReader["id_ayuda_categoria"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["id_ayuda_categoria"].ToString());
                            seccionesAyuda.Add(seccionAyuda);
                        }
                    }
                    db.DataReader.NextResult();

                    while (db.DataReader.Read())
                    {
                        if (db.DataReader["estatus"].ToString().Equals("200"))
                        {
                            PasoAyuda pasoAyuda = new PasoAyuda();
                            pasoAyuda.idPaso = db.DataReader["id_ayuda_paso"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["id_ayuda_paso"].ToString());
                            pasoAyuda.descripcion = db.DataReader["descripcion"] == DBNull.Value ? "" : db.DataReader["descripcion"].ToString();
                            pasoAyuda.idSeccion = db.DataReader["id_ayuda_seccion"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["id_ayuda_seccion"].ToString());
                            pasosAyuda.Add(pasoAyuda);
                        }
                    }
                    seccionesAyuda.ForEach(x => x.pasos.AddRange(pasosAyuda.FindAll(y => y.idSeccion == x.idSeccion)));
                    categoriasAyuda.ForEach(x => x.secciones.AddRange(seccionesAyuda.FindAll(y => y.idCategoria == x.idCategoria)));
                    ayuda.CategoriasAyuda=categoriasAyuda;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ayuda;
        }

        public string ObtenerValor(String llave)
        {
            string response = string.Empty;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@llave", llave);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_VALOR_CONFIGURACION");
                    while (db.DataReader.Read())
                    {
                        if (db.DataReader["estatus"].ToString().Equals("200"))
                        {
                            response = db.DataReader["valor"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }


        public string ActualizarBloqueoOTP(string NumeroSocio, TipoBloqueoOTP TipoBloqueoOTP)
        {
            string response = string.Empty;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@numero_socio", NumeroSocio);
                    db.AddParameters(1, "@Tipo_Bloqueo_OTP", TipoBloqueoOTP);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ACTUALIZA_BLOQUEO_OTP");
                    while (db.DataReader.Read())
                    {
                        if (db.DataReader["estatus"].ToString().Equals("200"))
                        {
                            response = db.DataReader["mensaje"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }


    }
}
