﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{
    public class SesionDAO
    {
        private DBManager db = null;
        public ResponseValidaNumero ValidaNumero(RequestValidaNumero request)
        {
            ResponseValidaNumero response = new ResponseValidaNumero();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "numero_socio", request.NumeroSocio);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_VALIDA_NUMERO");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.NombreSocio = db.DataReader["Nombre_Completo"].ToString();
                            response.NombreSocio = string.Empty;
                            response.NombreSocioEnmascarado =  Utilerias.Enmascarar(db.DataReader["Nombre_Completo"].ToString());
                            response.MotivoBloqueo = (TipoBloqueo)Convert.ToInt16(db.DataReader["id_motivo_bloqueo"].ToString());
                            response.VieneDeBloqueo = db.DataReader["viene_de_bloqueo"] == DBNull.Value ? false : Convert.ToBoolean(db.DataReader["viene_de_bloqueo"].ToString());
                            if (!string.IsNullOrEmpty(db.DataReader["ruta_imagen"].ToString()))
                            {
                                if (File.Exists(db.DataReader["ruta_imagen"].ToString()))
                                {
                                    response.ImagenAntiphishing = File.ReadAllBytes(db.DataReader["ruta_imagen"].ToString());
                                }
                            }
                        }
                        else
                        {
                            ExceptionValidaNumero exceptionValidaNumero = new ExceptionValidaNumero();
                            exceptionValidaNumero.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionValidaNumero.Mensaje = db.DataReader["error_message"].ToString();
                            throw new FaultException<ExceptionValidaNumero>(exceptionValidaNumero,exceptionValidaNumero.Mensaje);
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return response;
        }
        public ResponseIniciarSesion AutenticarSocio(RequestIniciarSesion request)
        {
            ResponseIniciarSesion response = new ResponseIniciarSesion();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "numero", request.NumeroSocio);
                    db.AddParameters(1, "contrasena", request.Contrasena);
                    db.AddParameters(2, "tipo_origen", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_AUTENTICAR_SOCIO");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.NombreSocio = db.DataReader["Nombre_Completo"].ToString();
                            response.NombreSocioEnmascarado=  Utilerias.Enmascarar(db.DataReader["Nombre_Completo"].ToString());
                            response.EsSocioPuntual = Convert.ToBoolean(db.DataReader["es_socio_puntual"]);
                            response.UltimaSesion = db.DataReader["ultima_sesion"] == DBNull.Value ? "" : db.DataReader["ultima_sesion"].ToString();
                            response.FechaUltimaSesion = db.DataReader["fecha_ultima_sesion"] == DBNull.Value ? DateTime.Now.ToShortDateString() : Convert.ToDateTime(db.DataReader["fecha_ultima_sesion"].ToString()).ToShortDateString();
                            response.HoraUltimaSesion = db.DataReader["fecha_ultima_sesion"] == DBNull.Value? DateTime.Now.ToShortTimeString(): Convert.ToDateTime(db.DataReader["fecha_ultima_sesion"].ToString()).ToShortTimeString();
                            response.TipoSocioPuntual = TipoSocioPuntual.Ninguno;
                            response.tarjetaActiva = Convert.ToBoolean(db.DataReader["tarjetaActiva"]);

                            if (response.EsSocioPuntual)
                            {
                                response.TipoSocioPuntual =(TipoSocioPuntual) Convert.ToInt16(db.DataReader["tipo_socio_puntual"].ToString());
                                response.LogoSocioPuntal =db.DataReader["path_imagen"].ToString();
                                
                            }
                        }
                        else
                        {
                            ExceptionIniciarSesion exceptionIniciarSesion = new ExceptionIniciarSesion();
                            exceptionIniciarSesion.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionIniciarSesion.Mensaje = db.DataReader["error_message"].ToString();
                            throw new FaultException<ExceptionIniciarSesion>(exceptionIniciarSesion, exceptionIniciarSesion.Mensaje);
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return response;
        }
    }
}
