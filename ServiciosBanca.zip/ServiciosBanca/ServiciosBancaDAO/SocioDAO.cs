﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Bitacora;
using ServiciosBancaEntidades.Cuenta;
using ServiciosBancaEntidades.EstadoCuenta;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Inversiones;
using ServiciosBancaEntidades.PagoDeServicios;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaEntidades.Tarjeta;
using ServiciosBancaEntidades.CoreRestServices.Requests;
using ServiciosBancaEntidades.CoreRestServices.Responses;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;
using SmsMailUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using SeguridadService;
using SeguridadService.Models;
using Newtonsoft.Json.Linq;

//Administrador de archivos
namespace ServiciosBancaDAO
{
    //917345
    //
    public class SocioDAO
    {
        private DBManager db = null;

        public ResponseActivarBanca ActivarBanca(RequestActivarBanca request)
        {
            ResponseActivarBanca informacion = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(7);
                    db.AddParameters(0, "NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "NuevaContrasena", request.NuevaContrasena);
                    db.AddParameters(2, "ContrasenaConfirmada", request.ContrasenaConfirmada);
                    db.AddParameters(3, "IdPregunta", request.IdPregunta);
                    db.AddParameters(4, "respuesta", request.Respuesta);
                    db.AddParameters(5, "idImagenAntiphishing", request.IdImagenAntiphishing);
                    db.AddParameters(6, "tipoOrigen", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ACTIVAR_BANCA");
                    while (db.DataReader.Read())
                    {

                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponseActivarBanca();
                            informacion.NombreSocio = db.DataReader["Nombre_Completo"].ToString();
                            informacion.NombreSocioOfuscado = Utilerias.Enmascarar(db.DataReader["Nombre_Completo"].ToString());

                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, TipoBitacora.activacion_de_CMV_Finanzas));
                        }
                        else
                        {
                            ExceptionActivarBanca exceptionActivarBanca = new ExceptionActivarBanca();
                            exceptionActivarBanca.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionActivarBanca.Mensaje = db.DataReader["mensaje"].ToString();
                            Bitacora<ExceptionActivarBanca> bEx = new Bitacora<ExceptionActivarBanca>(request.NumeroSocio.ToString(), exceptionActivarBanca);
                            new Logg().Info(SerializerManager<Bitacora<ExceptionActivarBanca>>.SerealizarObjtecToString(bEx));
                            throw new FaultException<ExceptionActivarBanca>(exceptionActivarBanca);
                        }
                    }
                }
                Bitacora<ResponseActivarBanca> b = new Bitacora<ResponseActivarBanca>(request.NumeroSocio.ToString(), informacion);
                new Logg().Info(SerializerManager<Bitacora<ResponseActivarBanca>>.SerealizarObjtecToString(b));

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }
        public ResponseObtenerInformacionSocio ObtenerInformacionSocio(RequestObtenerInformacionSocio request)
        {
            ResponseObtenerInformacionSocio informacion = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@NUMERO", request.NumeroSocio);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_DATOS_SOCIO");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponseObtenerInformacionSocio();
                            informacion.NombreSocio = db.DataReader["Nombre_Completo"].ToString();
                            informacion.NumeroSocio = Convert.ToInt32(db.DataReader["Numero"].ToString());
                            informacion.CodigoPostal = db.DataReader["Codigo_Postal"].ToString();
                            informacion.Celular = String.IsNullOrEmpty(db.DataReader["Tel_Celular"].ToString()) ? "" : db.DataReader["Tel_Celular"].ToString();
                            informacion.Email = String.IsNullOrEmpty(db.DataReader["Mail"].ToString()) ? "" : db.DataReader["Mail"].ToString();
                            informacion.FechaNacimiento = Convert.ToDateTime(db.DataReader["Fecha_de_nacimiento"].ToString());

                        }
                        else
                        {
                            ExceptionObtenerInformacionSocio exceptionObtenerInformacionSocio = new ExceptionObtenerInformacionSocio();
                            exceptionObtenerInformacionSocio.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionObtenerInformacionSocio.Mensaje = db.DataReader["mensaje"].ToString();
                            Bitacora<ExceptionObtenerInformacionSocio> Bex = new Bitacora<ExceptionObtenerInformacionSocio>(request.NumeroSocio.ToString(), exceptionObtenerInformacionSocio);
                            new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerInformacionSocio>>.SerealizarObjtecToString(Bex));
                            throw new FaultException<ExceptionObtenerInformacionSocio>(exceptionObtenerInformacionSocio);
                        }
                    }
                }

                Bitacora<ResponseObtenerInformacionSocio> b = new Bitacora<ResponseObtenerInformacionSocio>(informacion.NumeroSocio.ToString(), informacion);
                new Logg().Info(SerializerManager<Bitacora<ResponseObtenerInformacionSocio>>.SerealizarObjtecToString(b));


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }
        public ResponseRegistrarSocio RegistrarSocio(RequestRegistrarSocio request)
        {
            ResponseRegistrarSocio informacion = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@NUMERO", request.NumeroSocio);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_DATOS_SOCIO");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {

                            informacion.Estatus = true;

                        }
                        else
                        {
                            ExceptionRegistrarSocio exceptionRegistrarSocio = new ExceptionRegistrarSocio();
                            exceptionRegistrarSocio.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionRegistrarSocio.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionRegistrarSocio>(exceptionRegistrarSocio);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }
        public ResponseActualizarEstatus ActualizarEstatus(RequestActualizarEstatus request)
        {
            ResponseActualizarEstatus informacion = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@Numero", request.NumeroSocio);
                    db.AddParameters(1, "@Estatus", request.Estatus);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ACTUALIZA_ESTATUS");//id_estatus_banca
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponseActualizarEstatus();
                            informacion.Estatus = true;

                        }
                        else
                        {
                            ExceptionActualizarEstatus exceptionActualizarEstatus = new ExceptionActualizarEstatus();
                            exceptionActualizarEstatus.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionActualizarEstatus.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionActualizarEstatus>(exceptionActualizarEstatus);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }
        public ResponseValidaContrasenaTemporal ValidaContrasenaTemporal(RequestValidaContrasenaTemporal request)
        {
            ResponseValidaContrasenaTemporal informacion = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@numero_socio", request.NumeroSocio);
                    db.AddParameters(1, "@contrasena_temporal", request.ContrasenaTemporal);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_VALIDA_CONTRASENA_TEMPORAL");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponseValidaContrasenaTemporal();
                            informacion.Estatus = true;

                        }
                        else
                        {
                            ExceptionValidaContrasenaTemporal exceptionValidaContrasenaTemporal = new ExceptionValidaContrasenaTemporal();
                            exceptionValidaContrasenaTemporal.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionValidaContrasenaTemporal.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionValidaContrasenaTemporal>(exceptionValidaContrasenaTemporal);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }
        public Socio ObtenerInformacionSocioAprovisionaToken(string NumeroSocio)
        {
            Socio socio = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@NUMERO", NumeroSocio);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_DATOS_SOCIO");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            socio = new Socio();
                            socio.NombreSocio = db.DataReader["Nombre_s"].ToString();
                            socio.Apellidos = db.DataReader["Apellido_Paterno"].ToString();
                            if (!string.IsNullOrEmpty(db.DataReader["Apellido_Materno"].ToString()))
                                socio.Apellidos += " " + db.DataReader["Apellido_Materno"].ToString();
                            socio.NumeroSocio = Convert.ToInt32(db.DataReader["Numero"].ToString());
                            socio.CodigoPostal = db.DataReader["Codigo_Postal"].ToString();
                            socio.Celular = String.IsNullOrEmpty(db.DataReader["Tel_Celular"].ToString()) ? "" : db.DataReader["Tel_Celular"].ToString();
                            socio.Email = String.IsNullOrEmpty(db.DataReader["Mail"].ToString()) ? "" : db.DataReader["Mail"].ToString();
                            socio.FechaNacimiento = Convert.ToDateTime(db.DataReader["Fecha_de_nacimiento"].ToString());

                        }
                        else
                        {
                            FaultException ex = new FaultException(db.DataReader["mensaje"].ToString(), new FaultCode(db.DataReader["estatus"].ToString()));
                            throw ex;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return socio;
        }
        public ResponseCambiarContrasena CambiarContrasena(RequestCambiarContrasena request)
        {
            ResponseCambiarContrasena informacion = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(4);
                    db.AddParameters(0, "@NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "@contrasena_nueva", request.ContrasenaN);
                    db.AddParameters(2, "@contrasena_confirmacion", request.ConfirmarNuevaContrasena);
                    db.AddParameters(3, "@idTipoOrigen", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_CAMBIA_CONTRASENA");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponseCambiarContrasena();
                            informacion.Estatus = true;
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, TipoBitacora.restablecimiento_de_contraseña));

                        }
                        else
                        {
                            ExceptionCambiarContrasena exceptionCambiarContrasena = new ExceptionCambiarContrasena();
                            exceptionCambiarContrasena.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionCambiarContrasena.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionCambiarContrasena>(exceptionCambiarContrasena,exceptionCambiarContrasena.Mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }
        public ResponseValidarRespuesta RecuperarContrasena(RequestValidarRespuesta request)
        {
            ResponseValidarRespuesta informacion = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "numero", request.NumeroSocio);
                    db.AddParameters(1, "respuesta_secreta", request.RespuestaSecreta);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_RECUPERAR_CONTRASENA");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponseValidarRespuesta();
                            informacion.Estatus = true;
                            

                        }
                        else
                        {
                            ExceptionValidarRespuesta exceptionRecuperarContrasena = new ExceptionValidarRespuesta();
                            exceptionRecuperarContrasena.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionRecuperarContrasena.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionValidarRespuesta>(exceptionRecuperarContrasena,exceptionRecuperarContrasena.Mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }
        public ResponseObtenerGestionBeneficiarios ObtenerGestionBeneficiarios(RequestObtenerGestionBeneficiarios request)
        {
            ResponseObtenerGestionBeneficiarios response = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "numero_socio", request.NumeroSocio);
                    DataSet ds = db.ExecuteDataSet(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_GESTION_BENEFICIARIOS");
                    if (ds.Tables.Count > 0)
                    {
                        if (string.Compare(ds.Tables[0].Rows[0]["estatus"].ToString(), "200") == 0)
                        {
                            response = new ResponseObtenerGestionBeneficiarios();
                            foreach (DataRow dr in ds.Tables[1].Rows)
                            {

                                if (string.Compare(dr["tipoCuenta"].ToString(), "EXTERNA") == 0)
                                {
                                    CuentaExterna c = new CuentaExterna();
                                    c.IdCuentaExterna = (string.IsNullOrEmpty(dr["idCuenta"].ToString()) ? 0 : Convert.ToInt16(dr["idCuenta"].ToString()));
                                    c.Referencia = (string.IsNullOrEmpty(dr["referencia"].ToString()) ? string.Empty : dr["referencia"].ToString());
                                    c.Alias = (string.IsNullOrEmpty(dr["alias"].ToString()) ? string.Empty : dr["alias"].ToString());
                                    response.CuentasExternas.Add(c);

                                }
                                else if (string.Compare(dr["tipoCuenta"].ToString(), "INTERNA") == 0)
                                {
                                    CuentaInterna c = new CuentaInterna();
                                    c.idCuentaInterna = (string.IsNullOrEmpty(dr["idCuenta"].ToString()) ? 0 : Convert.ToInt16(dr["idCuenta"].ToString()));
                                    c.Referencia = (string.IsNullOrEmpty(dr["referencia"].ToString()) ? string.Empty : dr["referencia"].ToString());
                                    c.Alias = (string.IsNullOrEmpty(dr["alias"].ToString()) ? string.Empty : dr["alias"].ToString());
                                    response.CuentasInternas.Add(c);

                                }
                            }
                        }
                        else
                        {
                            ExceptionObtenerGestionBeneficiarios exceptionObtenerGestionBeneficiarios = new ExceptionObtenerGestionBeneficiarios();
                            exceptionObtenerGestionBeneficiarios.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionObtenerGestionBeneficiarios.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerGestionBeneficiarios>(exceptionObtenerGestionBeneficiarios);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
        public ResponseObtenerPreguntaSecreta ObtenerPreguntaSecreta(RequestObtenerPreguntaSecreta request)
        {
            ResponseObtenerPreguntaSecreta informacion = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@NUMERO", request.NumeroSocio);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_PREGUNTA_SECRETA_SOCIO");//id_estatus_banca
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponseObtenerPreguntaSecreta();
                            informacion.IdPreguntaSecreta = Convert.ToInt16(db.DataReader["id_pregunta_secreta"]);
                            informacion.Respuesta = db.DataReader["respuesta"].ToString();
                            informacion.DescripcionPregunta = db.DataReader["pregunta_secreta"].ToString();

                        }
                        else
                        {
                            ExceptionObtenerPreguntaSecreta exceptionActualizarEstatus = new ExceptionObtenerPreguntaSecreta();
                            exceptionActualizarEstatus.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionActualizarEstatus.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerPreguntaSecreta>(exceptionActualizarEstatus);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }
        public ResponseObtenerNombrePorClabe ObtenerNombrePorClabe(RequestObtenerNombrePorClabe request)
        {
            ResponseObtenerNombrePorClabe informacion = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@clabe_corresponsalias", request.Clabe);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_NOMBRE_POR_CLABE");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponseObtenerNombrePorClabe();
                            informacion.NombreBeneficiario = db.DataReader["nombre_completo"].ToString();
                        }
                        else
                        {
                            ExceptionObtenerNombrePorClabe obtenerNombrePorClabe = new ExceptionObtenerNombrePorClabe();
                            obtenerNombrePorClabe.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            obtenerNombrePorClabe.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerNombrePorClabe>(obtenerNombrePorClabe);
                        }
                    }
                }
            }
            catch (FaultException<ExceptionObtenerNombrePorClabe> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }

        public ResponseActualizaPreguntaRespuestaSecreta ActualizaPreguntaRespuestaSecreta(RequestActualizaPreguntaRespuestaSecreta request)
        {
            ResponseActualizaPreguntaRespuestaSecreta informacion = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(4);
                    db.AddParameters(0, "@numeroSocio", request.NumeroSocio);
                    db.AddParameters(1, "@idPreguntaSecreta", request.IdPregunta);
                    db.AddParameters(2, "@respuesta", request.Respuesta);
                    db.AddParameters(3, "@idTipoOrigen", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ACTUALIZAR_PREGUNTA_RESPUESTA_SECRETA");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponseActualizaPreguntaRespuestaSecreta();
                            informacion.Estatus = true;
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, TipoBitacora.cambio_de_respuesta_pregunta));
                        }
                        else
                        {
                            ExceptionActualizaPreguntaRespuestaSecreta exceptionActualizaPreguntaRespuestaSecreta = new ExceptionActualizaPreguntaRespuestaSecreta();
                            exceptionActualizaPreguntaRespuestaSecreta.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionActualizaPreguntaRespuestaSecreta.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionActualizaPreguntaRespuestaSecreta>(exceptionActualizaPreguntaRespuestaSecreta);
                        }
                    }
                }
            }
            catch (FaultException<ExceptionActualizaPreguntaRespuestaSecreta> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }

        public ResponseActualizarImagenAntiphishing ActualizarImagenAntiphishing(RequestActualizarImagenAntiphishing request)
        {
            ResponseActualizarImagenAntiphishing informacion = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "numero", request.NumeroSocio);
                    db.AddParameters(1, "id_imagen_antiphishing", request.IdImagenAntiphishing);
                    db.AddParameters(2, "tipo_origen", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ACTUALIZAR_IMAGEN_ANTIPHISHING");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponseActualizarImagenAntiphishing();
                            informacion.Estatus = true;
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, TipoBitacora.cambio_de_imagen_antiphishing));

                        }
                        else
                        {
                            ExceptionActualizarImagenAntiphishing exceptionActualizarImagenAntiphishing = new ExceptionActualizarImagenAntiphishing();
                            exceptionActualizarImagenAntiphishing.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionActualizarImagenAntiphishing.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionActualizarImagenAntiphishing>(exceptionActualizarImagenAntiphishing);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }
        
        #region Generar Contraseñas
        public ResponseGenerarContrasenaTemp GenerarContraseñaTemporal(RequestGenerarContrasenaTemp request, string contraseña)
        {
            ResponseGenerarContrasenaTemp response = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "@NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "@tipoOrigen", request.tipoOrigen);
                    db.AddParameters(2, "@contrasenaTemporal", contraseña);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_GENERAR_CONTRASENA_TEMP");
                    if (db.DataReader.Read())
                    {
                        response = new ResponseGenerarContrasenaTemp();
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                            //response.Notificacion = Utilerias.ObtenerNotificacion(db);
                        }
                        else
                        {
                            response = null;
                            ExceptionGenerarContrasenaTemp exceptionObtenerServiciosSocio = new ExceptionGenerarContrasenaTemp();
                            exceptionObtenerServiciosSocio.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionObtenerServiciosSocio.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionGenerarContrasenaTemp>(exceptionObtenerServiciosSocio);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
        #endregion

        #region pago de servicios
        public ResponseObtenerServiciosSocio ObtenerServiciosSocio(RequestObtenerServiciosSocio request)
        {
            ResponseObtenerServiciosSocio response = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@NumeroSocio", request.NumeroSocio);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_SERVICIOS_SOCIO_PAGO_SERVICIOS");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            if (db.DataReader.NextResult())
                            {
                                response = new ResponseObtenerServiciosSocio();
                                response.ServicioSocios = new List<ServicioSocio>();
                                while (db.DataReader.Read())
                                {
                                    ServicioSocio s = new ServicioSocio();
                                    s.Descripcion = db.DataReader["descripcion"].ToString();
                                    s.IdServicioSocio = Convert.ToInt16(db.DataReader["id_servicio_socio"].ToString());
                                    s.IdProducto = Convert.ToInt16(db.DataReader["id_producto"].ToString());
                                    s.IdServicio = Convert.ToInt16(db.DataReader["id_servicio"].ToString());
                                    s.Precio = Convert.ToDecimal(db.DataReader["precio"].ToString());
                                    s.TipoFront = Convert.ToInt16(db.DataReader["tipo_front"].ToString());
                                    s.Referencia = db.DataReader["numero_referencia"].ToString();
                                    s.Alias = string.IsNullOrEmpty(db.DataReader["alias"].ToString()) ? "" : db.DataReader["alias"].ToString();
                                    s.TipoReferencia = string.IsNullOrEmpty(db.DataReader["tipo_referencia"].ToString()) ? "" : db.DataReader["tipo_referencia"].ToString();
                                    s.telefono = string.IsNullOrEmpty(db.DataReader["telefono"].ToString()) ? "" : db.DataReader["telefono"].ToString();
                                    s.idCatTipoServicio = String.IsNullOrEmpty(db.DataReader["id_cat_tipo_servicio"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_cat_tipo_servicio"].ToString());
                                    s.hasDigitoVerificador = Convert.ToBoolean(db.DataReader["has_digito_verificador"]);
                                    s.MontoComision = string.IsNullOrEmpty(db.DataReader["comision_cmv"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["comision_cmv"].ToString());
                                    response.ServicioSocios.Add(s);
                                }
                            }
                            else
                                response = null;
                        }
                        else
                        {
                            response = null;
                            ExceptionObtenerServiciosSocio exceptionObtenerServiciosSocio = new ExceptionObtenerServiciosSocio();
                            exceptionObtenerServiciosSocio.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionObtenerServiciosSocio.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerServiciosSocio>(exceptionObtenerServiciosSocio);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
        public ResponseEliminarServicioSocio EliminarServicioSocio(RequestEliminarServicioSocio request)
        {
            ResponseEliminarServicioSocio response = new ResponseEliminarServicioSocio(); ;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@NumeroSocio", request.NumeroSocio);
                    db.AddParameters(1, "@IdServicioCmv", request.IdServicioSocio);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ELIMINAR_SERVICIOS_SOCIO_PAGO_SERVICIOS");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {

                            response.Estatus = true;
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, TipoBitacora.Baja_de_pago_de_servicio, request.IdServicioSocio));
                        }
                        else
                        {
                            response = null;
                            ExceptionEliminarServicioSocio exceptionEliminarServicioSocio = new ExceptionEliminarServicioSocio();
                            exceptionEliminarServicioSocio.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionEliminarServicioSocio.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionEliminarServicioSocio>(exceptionEliminarServicioSocio);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
        #endregion

        #region Invsersiones
        public ResponseObtenerInversionesSocio ObtenerInversionesSocio(RequestObtenerInversionesSocio request)
        {
            ResponseObtenerInversionesSocio response = new ResponseObtenerInversionesSocio();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@numero", request.NumeroSocio);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_INVERSIONES_SOCIO");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            if (db.DataReader.NextResult())
                                response.InversionesSocio = new List<ServiciosBancaEntidades.Inversiones.InversionSocio>();

                            while (db.DataReader.Read())
                            {
                                InversionSocio invS = new InversionSocio();
                                invS.Dias = string.IsNullOrEmpty(db.DataReader["dias"].ToString()) ? 0 : Convert.ToInt16(db.DataReader["dias"].ToString());
                                invS.Monto = string.IsNullOrEmpty(db.DataReader["monto"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["monto"].ToString());
                                invS.Numerosocio = request.NumeroSocio;
                                invS.numDPF = string.IsNullOrEmpty(db.DataReader["num_dpf"].ToString()) ? 0 : Convert.ToInt64(db.DataReader["num_dpf"].ToString());
                                invS.Tasa = string.IsNullOrEmpty(db.DataReader["tasa_dpf"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["tasa_dpf"].ToString());
                                invS.FechaApertura = db.DataReader["fecha_mov"].ToString();
                                invS.FechaCancelable = db.DataReader["fecha_vencimiento"].ToString();
                                invS.sePuedeCancelar = Convert.ToBoolean(Convert.ToInt16(db.DataReader["posible_cancelar"]));
                                response.InversionesSocio.Add(invS);
                            }

                        }
                        else
                        {
                            ExceptionObtenerInversionesSocio exceptionObtenerInversionesSocio = new ExceptionObtenerInversionesSocio();
                            exceptionObtenerInversionesSocio.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionObtenerInversionesSocio.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerInversionesSocio>(exceptionObtenerInversionesSocio, db.DataReader["mensaje"].ToString());
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public ResponseCancelarInversionSocio CancelarInversionSocio(RequestCancelarInversionSocio request)
        {
            ResponseCancelarInversionSocio response = new ResponseCancelarInversionSocio();
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "@NumeroSocio", request.NumeroSocio);
                    db.AddParameters(1, "@NumDPF", request.NumDPF);
                    db.AddParameters(2, "@idOrigen", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_CANCELAR_INVERSION_AFECTA");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.FechaOperacion = db.DataReader["fecha_transaccion"].ToString();
                            response.HoraOperacion = db.DataReader["hora_transaccion"].ToString();
                            response.NumDPF = db.DataReader["folioConstancia"].ToString();
                            response.NumeroSocio = request.NumeroSocio;
                            response.FolioOperacion = db.DataReader["folioOperacion"].ToString();
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, TipoBitacora.retiro_de_Inverplus_CMV));

                        }
                        else
                        {
                            ExceptionCancelarInversionSocio exceptionCancelarInversionSocio = new ExceptionCancelarInversionSocio();
                            exceptionCancelarInversionSocio.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionCancelarInversionSocio.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionCancelarInversionSocio>(exceptionCancelarInversionSocio, db.DataReader["mensaje"].ToString());
                        }
                    }
                }

            }
            catch (FaultException<ExceptionCancelarInversionSocio> fex)
            {
                throw fex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
        #endregion

        #region descargar y obtener los estados de cuenta (SAT)
        public ResponseDescargaEstadoDeCuenta DescargaEstadoDeCuenta(RequestDescargaEstadoDeCuenta request)
        {
            ResponseDescargaEstadoDeCuenta response = new ResponseDescargaEstadoDeCuenta();
            try
            {
                Int64 numeSocio = 0;
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "@numero", request.NumeroSocio);
                    db.AddParameters(1, "@idDescarga", request.idEstadoCuenta);
                    db.AddParameters(2, "@tipoEstadoCuenta", ((int) request.TipoEstadoCuenta));
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_DESCARGA_EDO_DE_CUENTA");//id_estatus_banca
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            string archivo = APIFormatosDescargarEstadoDeCuenta(((int)request.TipoEstadoCuenta) - 1, request.idEstadoCuenta.ToString());
                            /*if (!string.IsNullOrEmpty(db.DataReader["ruta"].ToString()))
                            {
                                numeSocio = Convert.ToInt64(request.NumeroSocio);
                                string archivo = Path.Combine(db.DataReader["ruta"].ToString(), "H" + numeSocio.ToString() + ".pdf");
                                if (request.TipoEstadoCuenta == TipoEstadoCuenta.PRESTAMO)
                                    archivo = Path.Combine(db.DataReader["ruta"].ToString(), "P" + numeSocio.ToString() + "_" + db.DataReader["NoPrestamo"].ToString() + ".pdf");
                                //archivo = @"\\cmv3005\Timbrado$\2017\SEPTIEMBRE\Haberes\SUC.ORIENTE\666480\H666480.pdf";
                                
                            if (File.Exists(archivo))
                            {
                                response.EstadoDeCuenta = Utilerias.AsginaContraseñaArchivo(archivo,db.DataReader["contrasena_estado_cuenta"].ToString());
                            }*/
                            if (!String.IsNullOrEmpty(archivo))
                            {
                                response.EstadoDeCuenta = Utilerias.AsginaContrasenaArchivoBase64(archivo, db.DataReader["contrasena_estado_cuenta"].ToString());
                            }
                        }
                        else
                        {
                            ExceptionDescargaEstadoDeCuenta exceptionActualizarEstatus = new ExceptionDescargaEstadoDeCuenta();
                            exceptionActualizarEstatus.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionActualizarEstatus.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionDescargaEstadoDeCuenta>(exceptionActualizarEstatus);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public string APIFormatosDescargarEstadoDeCuenta(int TipoEdoCuenta, string folio) {
            string server = ConexionAPI.ObtenerServerFormatos();
            string endpoint, endpointEdo;
            SeguridadServiceClient seguridadService = new SeguridadServiceClient();
            HttpClient edoClient  = new HttpClient();
            HttpResponseMessage httpResponse;
            HttpResponseMessage httpResponseEdo;
            RestResponse<ApiLogin> ressponseAuth;
            RestResponse<DescargarEstadoDeCuentaResponse> responseDescargar;


            endpointEdo = "socio/obtenerEstadoCuenta";
            edoClient.BaseAddress  = new Uri(server);
            edoClient.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue("application/json"));

            string[] credenciales = ConexionAPI.ObtenerUsuariosFormatos();
            LoginRequest payload = new LoginRequest
            {
                Usuario     = credenciales[0],
                Contrasena  = credenciales[1]
            };
            DescargarEstadoDeCuentaRequest EdoRequest = new DescargarEstadoDeCuentaRequest() {
                TipoEdoCuenta = Convert.ToString(TipoEdoCuenta),
                Folio           = folio
            };

            
            string payloadDescargarEdo  = JsonConvert.SerializeObject(EdoRequest);

            var httpContentEdo   = new StringContent(payloadDescargarEdo, Encoding.UTF8, "application/json");
            try
            {
                RestResponse<ApiLogin> token = new RestResponse<ApiLogin>();
                JObject token2 = (JObject)seguridadService.Login.Autenticar(payload);
                if (token2.GetValue("Estado").Value<bool>())
                {
                    edoClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token2.GetValue("Entidad")["Token"].Value<string>());
                    httpResponseEdo = edoClient.PostAsync(endpointEdo, httpContentEdo).Result;
                    if (httpResponseEdo.IsSuccessStatusCode)
                    {
                        var dataObjectsEdo = httpResponseEdo.Content.ReadAsStringAsync().Result;
                        responseDescargar = JsonConvert.DeserializeObject<RestResponse<DescargarEstadoDeCuentaResponse>>(dataObjectsEdo);
                        return responseDescargar.Entidad.Archivo;
                    }
                    else
                    {
                        throw new Exception("Error interno");
                    }

                }
                else
                {
                    throw new Exception("Error interno");
                }
            }
            catch (Exception e) {
                throw e;
            }

            return "";
        }

        public ResponseObtenerEstadoCuenta ObtenerEstadosDeCuenta(RequestObtenerEstadoCuenta request)
        {
            ResponseObtenerEstadoCuenta response = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    EstadoCuenta e = null;
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@numero", request.NumeroSocio);
                    db.AddParameters(1, "@tipoEstadoCuenta", request.TipoEstadoCuenta);
                    //db.AddParameters(2, "@periodo", request.Mes);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_EDO_DE_CUENTA");//id_estatus_banca
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response = new ResponseObtenerEstadoCuenta();

                            if (db.DataReader.NextResult())
                            {
                                response.EstadosDeCuenta = new List<EstadoCuenta>();
                                while (db.DataReader.Read())
                                {
                                    e = new EstadoCuenta();
                                    e.IdEstadoCuenta = Convert.ToInt64(db.DataReader["id_descarga"].ToString());
                                    e.Periodo = db.DataReader["Periodo"].ToString();
                                    e.TipoEstadoCuenta = (TipoEstadoCuenta)Convert.ToInt16(db.DataReader["id_tipo_edo_cuenta"].ToString());
                                    e.ClabeCorresponsalias = string.IsNullOrEmpty(db.DataReader["clabeCorresponsalias"].ToString()) ? string.Empty : db.DataReader["clabeCorresponsalias"].ToString();
                                    /*if (!string.IsNullOrEmpty(db.DataReader["ruta"].ToString()))
                                    {
                                        string archivo = Path.Combine(db.DataReader["ruta"].ToString(), "H" + request.NumeroSocio + ".pdf");
                                        if (request.TipoEstadoCuenta == TipoEstadoCuenta.PRESTAMO)
                                            archivo = Path.Combine(db.DataReader["ruta"].ToString(), "P" + request.NumeroSocio + "_" + db.DataReader["estatus"].ToString() + ".pdf");
                                        archivo = @"\\cmv3005\Timbrado$\2017\SEPTIEMBRE\Haberes\SUC.ORIENTE\666480\H666480.pdf";
                                        if (File.Exists(archivo))
                                            e.ArchivoEdoCuenta = File.ReadAllBytes(archivo);
                                    }*/
                                    response.EstadosDeCuenta.Add(e);
                                }
                            }
                        }
                        else
                        {
                            ExceptionObtenerEstadoCuenta exceptionObtenerEstadoCuenta = new ExceptionObtenerEstadoCuenta();
                            exceptionObtenerEstadoCuenta.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionObtenerEstadoCuenta.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerEstadoCuenta>(exceptionObtenerEstadoCuenta);
                        }
                    }
                }
            }
            catch (FaultException<ExceptionObtenerEstadoCuenta> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

        #endregion

        #region  TARJETAS DE CREDITO O DEBITO
        public ResponseObtenerTarjetas ObtenerTarjetas(RequestObtenerTarjetas request)
        {
            ResponseObtenerTarjetas informacion = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@numero", request.NumeroSocio);
                    db.AddParameters(1, "@estadoTarjeta", request.EstadoTarjeta);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_TARJETAS");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            if (db.DataReader.NextResult())
                            {
                                informacion = new ResponseObtenerTarjetas();
                                informacion.Tarjeta = new List<Tarjeta>();
                                while (db.DataReader.Read())
                                {
                                    Tarjeta tarjeta = new Tarjeta();
                                    tarjeta.ClabeCorresponsalias = db.DataReader["CUENTA"].ToString();
                                    tarjeta.EstadoTarjeta = (EstadoTarjeta)Convert.ToInt16(db.DataReader["estadoTarjeta"].ToString());
                                    tarjeta.TipoBloqueo = (TipoBloqueoTarjeta)Convert.ToInt16(db.DataReader["id_tipo_bloqueo_tarjeta"]);
                                    tarjeta.Descripcion = db.DataReader["nombreCuenta"].ToString();
                                    tarjeta.DescripcionBloqueo = db.DataReader["descripcionBloqueo"].ToString();
                                    informacion.Tarjeta.Add(tarjeta);
                                }
                            }
                        }
                        else
                        {
                            ExceptionObtenerNombrePorClabe obtenerNombrePorClabe = new ExceptionObtenerNombrePorClabe();
                            obtenerNombrePorClabe.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            obtenerNombrePorClabe.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerNombrePorClabe>(obtenerNombrePorClabe);
                        }
                    }
                }
            }
            catch (FaultException<ExceptionObtenerNombrePorClabe> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }
        public ResponseBloquearTarjeta BloquearTarjeta(RequestBloquearTarjeta request)
        {
            ResponseBloquearTarjeta informacion = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(4);
                    db.AddParameters(0, "numero_socio", request.NumeroSocio);
                    db.AddParameters(1, "clabe_corresponsalias", request.ClabeCorresponsalias);
                    db.AddParameters(2, "tipo_bloqueo_tarjeta", request.TipoBloqueoTarjeta);
                    db.AddParameters(3, "tipo_origen", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_BLOQUEO_TARJETA");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponseBloquearTarjeta();
                            informacion.Estatus = true;
                            informacion.Descripcion = db.DataReader["mensaje"].ToString();
                        }
                        else
                        {
                            ExceptionBloquearTarjeta exceptionBloquearTarjeta = new ExceptionBloquearTarjeta();
                            exceptionBloquearTarjeta.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionBloquearTarjeta.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionBloquearTarjeta>(exceptionBloquearTarjeta, exceptionBloquearTarjeta.Mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }

        public ResponseDesbloquearTarjeta DesBloquearTarjeta(RequestDesbloquearTarjeta request)
        {
            ResponseDesbloquearTarjeta informacion = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(4);
                    db.AddParameters(0, "numero_socio", request.NumeroSocio);
                    db.AddParameters(1, "clabe_corresponsalias", request.ClabeCorresponsalias);
                    db.AddParameters(2, "tipo_bloqueo_tarjeta", request.TipoBloqueoTarjeta);
                    db.AddParameters(3, "tipo_origen", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_BLOQUEO_TARJETA");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponseDesbloquearTarjeta();
                            informacion.Estatus = true;
                            informacion.Descripcion = db.DataReader["mensaje"].ToString();
                        }
                        else
                        {
                            ExceptionDesbloquearTarjeta exceptionDesbloquearTarjeta = new ExceptionDesbloquearTarjeta();
                            exceptionDesbloquearTarjeta.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionDesbloquearTarjeta.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionDesbloquearTarjeta>(exceptionDesbloquearTarjeta, exceptionDesbloquearTarjeta.Mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }
        #endregion
        
        #region PAGO DE  PRESTAMO
        public ResponsePagarPrestamoCuentasPropias PagarPrestamoCuentasPropias(RequestPagarPrestamoCuentasPropias request)
        {
            ResponsePagarPrestamoCuentasPropias informacion = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(7);
                    db.AddParameters(0, "clabeCorresponsaliasRetiro ", request.ClabeCorresponsaliasRetiro);
                    db.AddParameters(1, "clabeCorresponsaliasDeposito ", request.ClabeCorresponsaliasDeposito);
                    db.AddParameters(2, "Monto ", request.Monto);
                    db.AddParameters(3, "TipoAnticipo ", request.TipoAnticipo);
                    db.AddParameters(4, "TipoOrigen ", request.TipoOrigen);
                    db.AddParameters(5, "programada", request.Programada);
                    db.AddParameters(6, "horaProgramada", request.HoraProgramada);

                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_PAGAR_PRESTAMO");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponsePagarPrestamoCuentasPropias();
                            informacion.Estatus = true;
                            informacion.HoraTransaccion = db.DataReader["HoraTransaccion"].ToString();
                            informacion.Folio = db.DataReader["folio"].ToString();
                            informacion.Monto = string.IsNullOrEmpty(db.DataReader["Monto"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["Monto"].ToString());
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, (request.Programada ? TipoBitacora.Pago_programado_Pago_a_Prestamo_Entre_cuentas_propias: TipoBitacora.pago_realizado_Pago_a_PrestamoEntre_cuentas_propias)));

                        }
                        else
                        {
                            ExceptionPagarPrestamoCuentasPropias exceptionPagarPrestamoCuentasPropias = new ExceptionPagarPrestamoCuentasPropias();
                            exceptionPagarPrestamoCuentasPropias.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionPagarPrestamoCuentasPropias.Mensaje = db.DataReader["error_messag"].ToString();
                            throw new FaultException<ExceptionPagarPrestamoCuentasPropias>(exceptionPagarPrestamoCuentasPropias, exceptionPagarPrestamoCuentasPropias.Mensaje);
                        }
                    }
                }
            }
            catch (FaultException<ExceptionPagarPrestamoCuentasPropias> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }

        public ResponsePagarPrestamoCuentasMismoBanco PagarPrestamoCuentasMismoBanco(RequestPagarPrestamoCuentasMismoBanco request)
        {
            ResponsePagarPrestamoCuentasMismoBanco informacion = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(7);
                    db.AddParameters(0, "clabeCorresponsaliasRetiro ", request.ClabeCorresponsaliasRetiro);
                    db.AddParameters(1, "clabeCorresponsaliasDeposito ", request.ClabeCorresponsaliasDeposito);
                    db.AddParameters(2, "Monto ", request.Monto);
                    db.AddParameters(3, "TipoAnticipo ", DBNull.Value);
                    db.AddParameters(4, "TipoOrigen ", request.TipoOrigen);
                    db.AddParameters(5, "programada", request.Programada);
                    db.AddParameters(6, "horaProgramada", request.HoraProgramada);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_PAGAR_PRESTAMO");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            informacion = new ResponsePagarPrestamoCuentasMismoBanco();
                            informacion.Estatus = true;
                            informacion.HoraTransaccion = db.DataReader["HoraTransaccion"].ToString();
                            informacion.Folio = db.DataReader["folio"].ToString();
                            informacion.Monto = string.IsNullOrEmpty(db.DataReader["Monto"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["Monto"].ToString());
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, (request.Programada ? TipoBitacora.Pago_programado_Pago_a_Préstamo_Entre_socios : TipoBitacora.pago_realizadoPago_a_Prestamocuentas_mismo_banco_entre_socios)));
                        }
                        else
                        {
                            ExceptionPagarPrestamoCuentasMismoBanco exceptionPagarPrestamoCuentasMismoBanco = new ExceptionPagarPrestamoCuentasMismoBanco();
                            exceptionPagarPrestamoCuentasMismoBanco.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionPagarPrestamoCuentasMismoBanco.Mensaje = db.DataReader["error_messag"].ToString();
                            throw new FaultException<ExceptionPagarPrestamoCuentasMismoBanco>(exceptionPagarPrestamoCuentasMismoBanco);
                        }
                    }
                }
            }
            catch (FaultException<ExceptionPagarPrestamoCuentasMismoBanco> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return informacion;
        }

        #endregion


        #region BITACORA
        public ResponseObtenerBitacoraSocio ObtenerBitacoraSocio(RequestObtenerBitacoraSocio request)
        {
            ResponseObtenerBitacoraSocio response = new ResponseObtenerBitacoraSocio();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@numero", request.NumeroSocio);
                    db.AddParameters(1, "@pagina", request.Pagina);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_BITACORA_SOCIO");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            if (db.DataReader.NextResult())
                            {
                                db.DataReader.Read();
                                response.TotalPaginas = Convert.ToInt16(db.DataReader["TotalPaginas"].ToString());
                            }
                            if (db.DataReader.NextResult()) {
                                response.Operaciones = new List<ServiciosBancaEntidades.Bitacora.BitacoraOperaciones>();
                                while (db.DataReader.Read())
                                {
                                    BitacoraOperaciones b = new BitacoraOperaciones();
                                    b.DescripcionOperacion = db.DataReader["descripcion"].ToString();
                                    b.Hora = db.DataReader["hora"].ToString();
                                    b.Fecha = db.DataReader["fecha"].ToString();
                                    b.EstatusOperacion = true;
                                    response.Operaciones.Add(b);
                                }
                            }

                        }
                        else
                        {
                            ExceptionObtenerBitacoraSocio exceptionObtenerBitacoraSocio = new ExceptionObtenerBitacoraSocio();
                            exceptionObtenerBitacoraSocio.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionObtenerBitacoraSocio.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerBitacoraSocio>(exceptionObtenerBitacoraSocio, db.DataReader["mensaje"].ToString());
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;

        }
        #endregion


    }
}
