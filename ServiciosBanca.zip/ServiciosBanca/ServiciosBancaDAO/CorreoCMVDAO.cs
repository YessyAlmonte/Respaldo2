﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaUtils;
using ServiciosBancaUtils.CorreoCMV;
using ServiciosBancaUtils.Logg;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{
    public class CorreoCMVDAO
    {

        private DBManager db = null;
        public PlantillaCorreo ObtenerNotificacionCorreo(RequestCorreoCMV requestCorreoCMV)
        {
            PlantillaCorreo plantillaCorreo = null;
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "idSolicitud", requestCorreoCMV.NumeroSocio);
                    db.AddParameters(1, "tipoNotificacionCorreo", requestCorreoCMV.notificacionCMV);
                    DataSet ds = db.ExecuteDataSet(CommandType.StoredProcedure, "SP_BANCA_OBTENER_NOTIFICACION_CORREO");
                    if (ds.Tables.Count > 0)
                    {
                        if(ds.Tables[0].Rows.Count> 0)
                        {
                            if(Convert.ToInt32((ds.Tables[0].Rows[0] as DataRow)["estatus"].ToString()) == 200)
                            {
                                plantillaCorreo = new PlantillaCorreo();
                                if (ds.Tables[1].Rows.Count > 0)
                                {
                                    foreach (DataRow r in ds.Tables[0].Rows)
                                    {
                                        plantillaCorreo.asunto = r["asunto"].ToString();
                                        plantillaCorreo.cuerpo = r["cuerpo"].ToString().Trim();
                                    }

                                }
                                if (ds.Tables[2].Rows.Count > 0)
                                {
                                    foreach (DataRow r in ds.Tables[1].Rows)
                                    {
                                        plantillaCorreo.direccionesPara.Add(r["correo"].ToString());
                                    }
                                }
                                if (ds.Tables[3].Rows.Count > 0)
                                {
                                    foreach (DataRow r in ds.Tables[2].Rows)
                                    {
                                        plantillaCorreo.direccionesCC.Add(r["correo"].ToString());
                                    }
                                }
                            }
                            else
                            {
                                throw new Exception(db.DataReader["error_message"].ToString());
                            }
                        }
                    }
                }
                Bitacora<PlantillaCorreo> b = new Bitacora<PlantillaCorreo>(requestCorreoCMV.NumeroSocio.ToString(), plantillaCorreo);
                new Logg().Info(SerializerManager<Bitacora<PlantillaCorreo>>.SerealizarObjtecToString(b));

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return plantillaCorreo;
        }

    }
}
