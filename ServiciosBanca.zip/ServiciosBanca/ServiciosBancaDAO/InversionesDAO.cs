﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Inversiones;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using SmsMailUtils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{
  public  class InversionesDAO
    {
        private DBManager db = null;

        public ResponseRealizarInversion RealizarInversionesSocio(RequestRealizarInversion request)
        {

            ResponseRealizarInversion response = new ResponseRealizarInversion();
            try
            {
                MemoryStream ms = new MemoryStream();
                var dataContractSerializer = new DataContractSerializer(typeof(RequestRealizarInversion));
                dataContractSerializer.WriteObject(ms, request);
                string xml = System.Text.Encoding.UTF8.GetString(ms.ToArray());


                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(5);
                    db.AddParameters(0, "@NumeroSocio", request.NumeroSocio);
                    db.AddParameters(1, "@dias", request.PlazoInversion);
                    db.AddParameters(2, "@tasa", request.Tasa);
                    db.AddParameters(3, "@cuentas", xml);
                    db.AddParameters(4, "@idOrigen", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_REALIZAR_INVERSION");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.NumeroSocio = request.NumeroSocio;
                            response.NombreSocio = db.DataReader["nombreCompleto"].ToString();
                            response.DescripcionOperacion = db.DataReader["DescripcionOperacion"].ToString();
                            response.FechaOperacion = db.DataReader["fecha_transaccion"].ToString();
                            response.HoraOperacion = db.DataReader["hora_transaccion"].ToString();
                            response.FolioAutorizacion = db.DataReader["folioBanca"].ToString();//folioBanca
                            response.PlazoInversion = Convert.ToInt16(db.DataReader["PlazoInversion"]);
                            response.MontoInversion = Convert.ToDecimal(db.DataReader["montoInversion"]);
                            response.TasaInversion = Convert.ToDecimal(db.DataReader["tasaInversion"]);
                            response.FechaVencimiento = db.DataReader["fechaVencimiento"].ToString();
                            response.NumeroContrato = db.DataReader["folioConstancia"].ToString();//Numero de Plazo Fijo
                            SmsMail.validarTipoNotificaion(new  UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio,TipoBitacora.depósito_de_Inverplus_CMV));
                        }
                        else
                        {
                            ExceptionRealizarInversion exceptionRealizarInversion = new ExceptionRealizarInversion();
                            exceptionRealizarInversion.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionRealizarInversion.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionRealizarInversion>(exceptionRealizarInversion, db.DataReader["mensaje"].ToString());
                        }
                    }
                }

            }
            catch (FaultException<ExceptionRealizarInversion> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
    }
}
