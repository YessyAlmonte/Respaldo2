﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Domiciliacion;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.PagoDeServicios;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils.Reportes;
using SmsMailUtils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{
    public class DomiciliacionDAO
    {

        private DBManager db = null;

        public ResponseAltaDomiciliacion AltaDomicilacion(RequestAltaDomiciliacion request)
        {
            ResponseAltaDomiciliacion response = new ResponseAltaDomiciliacion();
            try
            {
                if (request.TipoDomiciliacion == TipoDomiciliacion.Prestamos)
                {
                    Result result = ValidaPtmoAlCorriente(request.ClabeCorresponsaliasDestino, request.TipoOrigen, request.NumeroSocio);
                    if (result.Codigo != 200)
                    {
                        ExceptionAltaDomiciliacion exceptionAltaDomiciliacion = new ExceptionAltaDomiciliacion();
                        exceptionAltaDomiciliacion.Codigo = result.Codigo;
                        exceptionAltaDomiciliacion.Mensaje = result.Mensaje;
                        throw new FaultException<ExceptionAltaDomiciliacion>(exceptionAltaDomiciliacion, exceptionAltaDomiciliacion.Mensaje);
                    }
                }


                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(24);
                    db.AddParameters(0, "@numero_socio", request.NumeroSocio);
                    db.AddParameters(1, "@alias", request.Alias);
                    db.AddParameters(2, "@id_tipo_domiciliacion", request.TipoDomiciliacion);
                    db.AddParameters(3, "@clabe_corresponsalias_retiro ", request.ClabeCorresponsaliasRetiro);
                    db.AddParameters(4, "@id_origen_operacion", request.TipoOrigen);
                    db.AddParameters(5, "@indefinido", request.EsIndefinido);
                    db.AddParameters(6, "@clabe_corresponsalias_deposito", request.ClabeCorresponsaliasDestino);
                    db.AddParameters(7, "@id_domiciliacion", request.IdDomiciliacion);
                    db.AddParameters(8, "@id_producto", request.IdProducto);
                    db.AddParameters(9, "@id_periodicidad_pago", request.RequestPeriodicidad == null ? (object)DBNull.Value : request.RequestPeriodicidad.IdPeriodicidad);
                    db.AddParameters(10, "@fecha_vencimiento", request.FechaVencimiento);
                    db.AddParameters(11, "@monto_maximo", request.MontoMaximo);
                    db.AddParameters(12, "@dia_pago", request.FechaDePago);
                    db.AddParameters(13, "@id_servicio", request.IdServicio);
                    db.AddParameters(14, "@numero_referencia", request.NumeroReferencia);
                    db.AddParameters(15, "@monto", request.Monto);
                    db.AddParameters(16, "@con_vigencia", request.ConVigencia);
                    db.AddParameters(17, "@por_periodicidad", request.PorPeriodicidad);
                    db.AddParameters(18, "@por_dia_pago", request.PorDiaPago);
                    db.AddParameters(19, "@por_dia_especifico_de_pago", request.DiaEspecificoDePago);
                    db.AddParameters(20, "@por_dia_limite_de_pago", request.DiaLimiteDePago);
                    db.AddParameters(21, "@por_monto_requerido", request.MontoRequerido);
                    db.AddParameters(22, "@por_monto_fijo", request.MontoFijo);
                    db.AddParameters(23, "@telefono", request.telefono);

                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ALTA_DOMICILIACION");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                            Domiciliacion domiciliacion = ObtenerInformacionDomiciliacion(Convert.ToInt32(db.DataReader["id_domiciliacion"].ToString()), request.NumeroSocio);
                            response.Archivo = Reportes.AltaDomiciliacion(domiciliacion);

                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, request.IdDomiciliacion > 0 ? TipoBitacora.Domiciliación_actualizada : TipoBitacora.Alta_domiciliación, null, domiciliacion.IdDomiciliacion, response.Archivo, "FormatoDomiciliacion.pdf"));
                        }

                        else
                        {
                            ExceptionAltaDomiciliacion exceptionAltaDomiciliacion = new ExceptionAltaDomiciliacion();
                            exceptionAltaDomiciliacion.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionAltaDomiciliacion.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionAltaDomiciliacion>(exceptionAltaDomiciliacion, exceptionAltaDomiciliacion.Mensaje);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }


        public ResponseObtenerDomiciliaciones ObtenerDomiciliaciones(RequestObtenerDomiciliacion request)
        {
            ResponseObtenerDomiciliaciones response = new ResponseObtenerDomiciliaciones();
            List<ResponseObtenerDomiciliacion> domiciliaciones = new List<ResponseObtenerDomiciliacion>();
            try
            {
                switch (request.TipoSolicitado)
                {
                    case TipoSolicitado.DomiciliacionesCreditos:

                        using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                        {

                            db.Open();
                            db.CreateParameters(2);
                            db.AddParameters(0, "@numero", request.NumeroSocio);
                            db.AddParameters(1, "@activo", request.Activo);

                            db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_DOMICILIACION_OBTENER_CREDITOS_DOMICILIADOS");

                            if (db.DataReader.Read())
                            {
                                if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                                {
                                    if (db.DataReader.NextResult())
                                    {
                                        ResponseObtenerDomiciliacion creditosDomicialiado = new ResponseObtenerDomiciliacion();
                                        while (db.DataReader.Read())
                                        {

                                            creditosDomicialiado = new ResponseObtenerDomiciliacion();
                                            {
                                                creditosDomicialiado.IdDomiciliacion = Convert.ToInt32(db.DataReader["Id_Domiciliacion"].ToString());
                                                creditosDomicialiado.NumeroSocio = db.DataReader["numero_socio"].ToString();
                                                creditosDomicialiado.ClabeCorresponsaliasRetiro = db.DataReader["clabe_corresponsalias_retiro"] == DBNull.Value ? "" : db.DataReader["clabe_corresponsalias_retiro"].ToString();
                                                creditosDomicialiado.Alias = db.DataReader["Alias"].ToString();
                                                creditosDomicialiado.ConVigencia = db.DataReader["Con_Vigencia"] == DBNull.Value ? false : Convert.ToBoolean(db.DataReader["Con_Vigencia"].ToString());
                                                creditosDomicialiado.FechaVencimiento = db.DataReader["Fecha_Vencimiento"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(db.DataReader["Fecha_Vencimiento"].ToString());
                                                creditosDomicialiado.EsIndefinido = Convert.ToBoolean(db.DataReader["Indefinido"].ToString());
                                                creditosDomicialiado.TipoDomiciliacion = (TipoDomiciliacion)Convert.ToInt32(db.DataReader["id_Tipo_Domiciliacion"].ToString());
                                                creditosDomicialiado.FechaAlta = Convert.ToDateTime(db.DataReader["Fecha_Alta"].ToString());
                                                creditosDomicialiado.MontoRequerido = Convert.ToDecimal(db.DataReader["Monto_requerido"].ToString());
                                                creditosDomicialiado.FechaLimitePago = db.DataReader["Fecha_Limite_Pago"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(db.DataReader["Fecha_Limite_Pago"].ToString());
                                                creditosDomicialiado.ClabeCorresponsaliasDestino = db.DataReader["clabe_corresponsalias_deposito"] == DBNull.Value ? "" : db.DataReader["clabe_corresponsalias_deposito"].ToString();
                                                creditosDomicialiado.DiaEspecificoDePago = db.DataReader["por_dia_especifico_de_pago"] == DBNull.Value ? false : Convert.ToBoolean(db.DataReader["por_dia_especifico_de_pago"].ToString());
                                                creditosDomicialiado.DiaLimiteDePago = db.DataReader["por_dia_limite_de_pago"] == DBNull.Value ? false : Convert.ToBoolean(db.DataReader["por_dia_limite_de_pago"].ToString());
                                                creditosDomicialiado.FechaDePago = db.DataReader["Fecha_Pago"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["Fecha_Pago"].ToString());
                                                creditosDomicialiado.Monto = db.DataReader["Monto"] == DBNull.Value ? 0 : Convert.ToDecimal(db.DataReader["Monto"].ToString());
                                                //creditosDomicialiado.TipoEsquema = (TipoEsquema) Convert.ToInt32(db.DataReader["id_esquema"].ToString());
                                                //creditosDomicialiado.IdMov = Convert.ToInt32(db.DataReader["id_mov"].ToString());
                                                //creditosDomicialiado.NumeroContrato = db.DataReader["num_ptmo"].ToString();
                                                creditosDomicialiado.PorDiaPago = db.DataReader["por_dia_pago"] == DBNull.Value ? false : Convert.ToBoolean(db.DataReader["por_dia_pago"].ToString());
                                                //creditosDomicialiado.PorPeriodicidad = null;
                                                creditosDomicialiado.TipoSolicitado = TipoSolicitado.DomiciliacionesCreditos;
                                                creditosDomicialiado.PorMontoRequerido = db.DataReader["por_monto_requerido"] == DBNull.Value ? false : Convert.ToBoolean(db.DataReader["por_monto_requerido"].ToString());
                                                creditosDomicialiado.PorMontoFijo = db.DataReader["por_monto_fijo"] == DBNull.Value ? false : Convert.ToBoolean(db.DataReader["por_monto_fijo"].ToString());
                                                creditosDomicialiado.Descripcion = db.DataReader["descripcion"].ToString();
                                                creditosDomicialiado.TipoEsquema = (TipoEsquema)Convert.ToInt32(db.DataReader["Tipo_Esquema"].ToString());
                                                //creditosDomicialiado.Estatus = true;
                                                //creditosDomicialiado.Mensaje = "OK";

                                            };
                                            domiciliaciones.Add(creditosDomicialiado);

                                        }

                                    }
                                }
                                else
                                {
                                    ExceptionObtenerDomiciliaciones exceptionObtenerDomiciliaciones = new ExceptionObtenerDomiciliaciones();
                                    exceptionObtenerDomiciliaciones.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                                    exceptionObtenerDomiciliaciones.Mensaje = db.DataReader["mensaje"].ToString();
                                    throw new FaultException<ExceptionObtenerDomiciliaciones>(exceptionObtenerDomiciliaciones, db.DataReader["mensaje"].ToString());
                                }
                            }
                        }
                        break;
                    case TipoSolicitado.DomiciliacionesServicios:
                        using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                        {

                            db.Open();
                            db.CreateParameters(3);
                            db.AddParameters(0, "@numeroSocio", request.NumeroSocio);
                            db.AddParameters(1, "@tipoOrigen", request.TipoOrigen);
                            db.AddParameters(2, "@activo", request.Activo);

                            db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_DOMICILIACION_OBTENER_SERVICIOS_DOMICILIADOS");

                            if (db.DataReader.Read())
                            {
                                if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                                {
                                    if (db.DataReader.NextResult())
                                    {
                                        ResponseObtenerDomiciliacion serviciosDomicialiado = new ResponseObtenerDomiciliacion();
                                        while (db.DataReader.Read())
                                        {

                                            serviciosDomicialiado = new ResponseObtenerDomiciliacion();
                                            {
                                                serviciosDomicialiado.IdDomiciliacion = Convert.ToInt32(db.DataReader["Id_Domiciliacion"].ToString());
                                                serviciosDomicialiado.NumeroSocio = db.DataReader["numero_socio"].ToString();
                                                serviciosDomicialiado.ClabeCorresponsaliasRetiro = db.DataReader["clabe_corresponsalias"] == DBNull.Value ? "" : db.DataReader["clabe_corresponsalias"].ToString();
                                                serviciosDomicialiado.Alias = db.DataReader["Alias"].ToString();
                                                serviciosDomicialiado.MontoMaximo = Convert.ToDecimal(db.DataReader["Monto_Maximo"].ToString());
                                                serviciosDomicialiado.NumeroReferencia = db.DataReader["Numero_Referencia"].ToString();
                                                serviciosDomicialiado.ConVigencia = db.DataReader["Con_Vigencia"] == DBNull.Value ? false : Convert.ToBoolean(db.DataReader["Con_Vigencia"].ToString());
                                                serviciosDomicialiado.FechaVencimiento = Convert.ToDateTime(db.DataReader["Fecha_Vencimiento"].ToString());
                                                serviciosDomicialiado.EsIndefinido = Convert.ToBoolean(db.DataReader["Es_Indefinido"].ToString());
                                                //serviciosDomicialiado.Periodicidad.IdPeriodicidad = db.DataReader["id_Periodicidad"] == DBNull.Value ? 0 : Convert.ToInt16(db.DataReader["id_Periodicidad"].ToString());
                                                if (db.DataReader["id_Periodicidad"] != DBNull.Value)
                                                {
                                                    serviciosDomicialiado.ResponsePeriodicidad = new ResponsePeriodicidad()
                                                    {
                                                        IdPeriodicidad = db.DataReader["id_Periodicidad"] == DBNull.Value ? 0 : Convert.ToInt16(db.DataReader["id_Periodicidad"].ToString()),
                                                        Descripcion = db.DataReader["descripcion_Periodicidad"] == DBNull.Value ? "" : db.DataReader["descripcion_Periodicidad"].ToString()
                                                    };

                                                }

                                                serviciosDomicialiado.TipoDomiciliacion = (TipoDomiciliacion)Convert.ToInt32(db.DataReader["Tipo_Domiciliacion"].ToString());
                                                serviciosDomicialiado.FechaAlta = Convert.ToDateTime(db.DataReader["Fecha_Alta"].ToString());
                                                serviciosDomicialiado.TipoFront = Convert.ToInt32(db.DataReader["Tipo_Front"].ToString());
                                                serviciosDomicialiado.IdProducto = Convert.ToInt32(db.DataReader["Id_Producto"].ToString());
                                                serviciosDomicialiado.IdServicio = Convert.ToInt32(db.DataReader["Id_Servicio"].ToString());
                                                serviciosDomicialiado.FechaDePago = db.DataReader["Fecha_Pago"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["Fecha_Pago"].ToString());
                                                serviciosDomicialiado.Descripcion = db.DataReader["descripcion"].ToString();
                                                serviciosDomicialiado.Telefono = db.DataReader["telefono"] == DBNull.Value ? "" : db.DataReader["telefono"].ToString();
                                                serviciosDomicialiado.PorDiaPago = db.DataReader["por_dia_pago"] == DBNull.Value ? false : Convert.ToBoolean(db.DataReader["por_dia_pago"].ToString());
                                                serviciosDomicialiado.PorPeriodicidad = db.DataReader["por_periodicidad"] == DBNull.Value ? false : Convert.ToBoolean(db.DataReader["por_periodicidad"].ToString());
                                                serviciosDomicialiado.TipoSolicitado = TipoSolicitado.DomiciliacionesServicios;

                                                serviciosDomicialiado.Estatus = true;
                                                serviciosDomicialiado.Mensaje = "OK";

                                            };
                                            domiciliaciones.Add(serviciosDomicialiado);

                                        }

                                    }
                                }
                                else
                                {
                                    ExceptionObtenerDomiciliaciones exceptionObtenerDomiciliaciones = new ExceptionObtenerDomiciliaciones();
                                    exceptionObtenerDomiciliaciones.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                                    exceptionObtenerDomiciliaciones.Mensaje = db.DataReader["mensaje"].ToString();
                                    throw new FaultException<ExceptionObtenerDomiciliaciones>(exceptionObtenerDomiciliaciones, db.DataReader["mensaje"].ToString());
                                }
                            }
                        }
                        break;
                    case TipoSolicitado.CreditosDomicialiados:
                        using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                        {

                            db.Open();
                            db.CreateParameters(2);
                            db.AddParameters(0, "@numeroSocio", request.NumeroSocio);
                            db.AddParameters(1, "@tipoOrigen", request.TipoOrigen);

                            db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_DOMICILIACION_OBTENER_CREDITOS");

                            if (db.DataReader.Read())
                            {
                                if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                                {
                                    if (db.DataReader.NextResult())
                                    {
                                        ResponseObtenerDomiciliacion creditosDomicialiado = new ResponseObtenerDomiciliacion();
                                        while (db.DataReader.Read())
                                        {

                                            creditosDomicialiado = new ResponseObtenerDomiciliacion();
                                            {
                                                creditosDomicialiado.ClabeCorresponsalias = db.DataReader["clabe_corresponsalias"].ToString();
                                                creditosDomicialiado.ClabeSpei = db.DataReader["Clabe_Spei"].ToString();
                                                creditosDomicialiado.FechaUltimoAbono = Convert.ToDateTime(db.DataReader["Fecha_Ultimo_Abono"].ToString());
                                                creditosDomicialiado.IdMov = Convert.ToInt32(db.DataReader["Id_Mov"].ToString());
                                                creditosDomicialiado.NombreCuenta = db.DataReader["Nombre_Cuenta"].ToString();
                                                creditosDomicialiado.NumeroContrato = db.DataReader["Numero_Contrato"].ToString();
                                                creditosDomicialiado.Saldo = Convert.ToDecimal(db.DataReader["saldo"].ToString());
                                                creditosDomicialiado.TipoCuenta = (TipoCuenta)Convert.ToInt32(db.DataReader["Tipo_Cuenta"].ToString());
                                                creditosDomicialiado.TipoEsquema = (TipoEsquema)Convert.ToInt32(db.DataReader["Tipo_Esquema"].ToString());
                                                creditosDomicialiado.DiasVencidos = Convert.ToInt32(db.DataReader["Dias_Vencidos"].ToString());
                                                creditosDomicialiado.EstatusCredito = db.DataReader["Estatus_Credito"].ToString();
                                                creditosDomicialiado.FechaCorte = Convert.ToDateTime(db.DataReader["fecha_corte"].ToString());
                                                creditosDomicialiado.FechaLimitePago = Convert.ToDateTime(db.DataReader["Fecha_Limite_Pago"].ToString());
                                                creditosDomicialiado.FechaPrestamo = Convert.ToDateTime(db.DataReader["Fecha_Prestamo"].ToString());
                                                creditosDomicialiado.FechaUltimoPago = Convert.ToDateTime(db.DataReader["Fecha_Ultimo_Pago"].ToString());
                                                creditosDomicialiado.LimiteCredito = Convert.ToDecimal(db.DataReader["Limite_Credito"].ToString());
                                                creditosDomicialiado.MontoDisponible = Convert.ToDecimal(db.DataReader["Monto_Disponible"].ToString());
                                                creditosDomicialiado.MontoInicial = Convert.ToDecimal(db.DataReader["Monto_Inicial"].ToString());
                                                ///////// PagoHoy
                                                creditosDomicialiado.PeriodosAtrasados = Convert.ToDecimal(db.DataReader["Periodos_Atrasados"].ToString());
                                                creditosDomicialiado.ReferenciaCorresponsales = db.DataReader["Referencia_Corresponsales"].ToString();
                                                //////// SaldoAdelantado                                                
                                                creditosDomicialiado.MontoRequerido = Convert.ToDecimal(db.DataReader["monto_requerido"].ToString());
                                                creditosDomicialiado.TipoSolicitado = TipoSolicitado.CreditosDomicialiados;
                                                //creditosDomicialiado.NumeroSocio = db.DataReader["Numero_Socio"].ToString();
                                                //creditosDomicialiado.PorDiaPago = null;
                                                //creditosDomicialiado.PorPeriodicidad = null;

                                                creditosDomicialiado.Estatus = true;
                                                creditosDomicialiado.Mensaje = "OK";
                                                creditosDomicialiado.TipoSolicitado = TipoSolicitado.CreditosDomicialiados;


                                            };
                                            domiciliaciones.Add(creditosDomicialiado);

                                        }

                                        foreach (ResponseObtenerDomiciliacion r in domiciliaciones)
                                        {

                                            using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                                            {
                                                db.Open();
                                                db.CreateParameters(3);
                                                db.AddParameters(0, "@ClabeCorresponsalias", r.ClabeCorresponsalias);
                                                db.AddParameters(1, "@tipoOrigen", request.TipoOrigen);
                                                db.AddParameters(2, "@numeroSocio", request.NumeroSocio);
                                                db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_DETALLE_PRESTAMO");
                                                if (db.DataReader.Read())
                                                {
                                                    if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                                                    {
                                                        //r.FechaCorte = Convert.ToDateTime(db.DataReader["DiaCorte"].ToString());
                                                        r.PagoHoy = Convert.ToDecimal(db.DataReader["PagoAlDiaDeHoy"].ToString());
                                                        r.SaldoAdelantado = Convert.ToDecimal(db.DataReader["saldo_adelanto"].ToString());
                                                        //r.MontoRequerido =;
                                                    }
                                                    else
                                                    {
                                                        ExceptionObtenerDomiciliaciones exceptionObtenerDomiciliaciones = new ExceptionObtenerDomiciliaciones();
                                                        exceptionObtenerDomiciliaciones.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                                                        exceptionObtenerDomiciliaciones.Mensaje = db.DataReader["mensaje"].ToString();
                                                        throw new FaultException<ExceptionObtenerDomiciliaciones>(exceptionObtenerDomiciliaciones, db.DataReader["mensaje"].ToString());
                                                    }
                                                }
                                            }

                                        }
                                    }
                                }
                                else
                                {
                                    ExceptionObtenerDomiciliaciones exceptionObtenerDomiciliaciones = new ExceptionObtenerDomiciliaciones();
                                    exceptionObtenerDomiciliaciones.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                                    exceptionObtenerDomiciliaciones.Mensaje = db.DataReader["mensaje"].ToString();
                                    throw new FaultException<ExceptionObtenerDomiciliaciones>(exceptionObtenerDomiciliaciones, db.DataReader["mensaje"].ToString());
                                }
                            }
                        }

                        break;
                    case TipoSolicitado.ServiciosDomiciliados:
                        using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                        {

                            db.Open();
                            db.CreateParameters(2);
                            db.AddParameters(0, "@numeroSocio", request.NumeroSocio);
                            db.AddParameters(1, "@tipoOrigen", request.TipoOrigen);

                            db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_DOMICILIACION_OBTENER_SERVICIOS");

                            if (db.DataReader.Read())
                            {
                                if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                                {
                                    if (db.DataReader.NextResult())
                                    {
                                        ResponseObtenerDomiciliacion serviciosDomicialiado = new ResponseObtenerDomiciliacion();
                                        while (db.DataReader.Read())
                                        {

                                            serviciosDomicialiado = new ResponseObtenerDomiciliacion();
                                            {
                                                serviciosDomicialiado.TipoFront = Convert.ToInt32(db.DataReader["tipo_front"].ToString());
                                                serviciosDomicialiado.IdProducto = Convert.ToInt32(db.DataReader["Id_Producto"].ToString());
                                                serviciosDomicialiado.IdServicio = Convert.ToInt32(db.DataReader["Id_Servicio"].ToString());
                                                serviciosDomicialiado.Descripcion = db.DataReader["Descripcion"].ToString();
                                                serviciosDomicialiado.Precio = Convert.ToDecimal(db.DataReader["Precio"].ToString());
                                                serviciosDomicialiado.TipoReferencia = db.DataReader["Tipo_Referencia"].ToString();
                                                serviciosDomicialiado.idCatTipoServicio = Convert.ToInt32(db.DataReader["id_Cat_Tipo_Servicio"].ToString());
                                                serviciosDomicialiado.hasDigitoVerificador = Convert.ToBoolean(db.DataReader["has_Digito_Verificador"].ToString());
                                                serviciosDomicialiado.MontoComision = Convert.ToDecimal(db.DataReader["Monto_Comision"].ToString());
                                                serviciosDomicialiado.Leyenda = db.DataReader["Leyenda"].ToString();
                                                serviciosDomicialiado.TipoSolicitado = TipoSolicitado.ServiciosDomiciliados;
                                                //serviciosDomicialiado.NumeroSocio = db.DataReader["numero_socio"].ToString();
                                                //serviciosDomicialiado.PorDiaPago = null;
                                                //serviciosDomicialiado.PorPeriodicidad = null;
                                                serviciosDomicialiado.Estatus = true;
                                                serviciosDomicialiado.Mensaje = "OK";

                                            };
                                            domiciliaciones.Add(serviciosDomicialiado);

                                        }

                                    }
                                }
                                else
                                {
                                    ExceptionObtenerDomiciliaciones exceptionObtenerDomiciliaciones = new ExceptionObtenerDomiciliaciones();
                                    exceptionObtenerDomiciliaciones.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                                    exceptionObtenerDomiciliaciones.Mensaje = db.DataReader["mensaje"].ToString();
                                    throw new FaultException<ExceptionObtenerDomiciliaciones>(exceptionObtenerDomiciliaciones, db.DataReader["mensaje"].ToString());
                                }
                            }
                        }

                        break;
                }
                response.ResponseObtenerDomiciliacion = domiciliaciones;
                /*using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@numeroSocio", request.NumeroSocio);
                    db.AddParameters(1, "@activo ", request.Activo);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_DOMICILIACIONES");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            if (db.DataReader.NextResult()) {
                                response.Domiciliaciones = new List<ServiciosBancaEntidades.Domiciliacion.Domiciliacion>();
                                while (db.DataReader.Read())
                                {
                                    ServiciosBancaEntidades.Domiciliacion.Domiciliacion d = new ServiciosBancaEntidades.Domiciliacion.Domiciliacion();
                                    d.IdDomiciliacion = Convert.ToInt64(db.DataReader["id_domiciliacion"].ToString());
                                    d.DescProducto = db.DataReader["descProducto"].ToString();
                                    d.NombreCuentaRetiro = string.IsNullOrEmpty(db.DataReader["descClabeRetiro"].ToString()) ? "" : db.DataReader["descClabeRetiro"].ToString();
                                    d.NombreCuentaDeposito = string.IsNullOrEmpty(db.DataReader["descCuentaDeposito"].ToString()) ? "" : db.DataReader["descCuentaDeposito"].ToString();
                                    d.DescTipoDomiciliacion = string.IsNullOrEmpty(db.DataReader["descTipoDomiciliacion"].ToString()) ? "" : db.DataReader["descTipoDomiciliacion"].ToString();
                                    d.DescPeriodicidadPago = string.IsNullOrEmpty(db.DataReader["descPeriodicidadago"].ToString()) ? "" : db.DataReader["descPeriodicidadago"].ToString();
                                    d.TipoDomiciliacion =(TipoDomiciliacion)Convert.ToInt16(db.DataReader["id_tipo_domiciliacion"].ToString());
                                    d.TipoPeriodicidadPago =(ServiciosBancaEntidades.TiposDePeriodicidad) Convert.ToInt16(db.DataReader["id_periodicidad_pago"].ToString());
                                    d.IdProducto =string.IsNullOrEmpty(db.DataReader["id_producto"].ToString()) ? 0 : Convert.ToInt16(db.DataReader["id_producto"].ToString());
                                    d.Activo = string.IsNullOrEmpty(db.DataReader["activo"].ToString()) ? false : Convert.ToBoolean(db.DataReader["activo"].ToString());

                                    d.FechaDeVencimiento = Convert.ToDateTime(db.DataReader["fecha_vencimiento"].ToString());
                                    d.MontoMaximo =Convert.ToDecimal(db.DataReader["monto_maximo"].ToString());
                                    d.Indefinido = Convert.ToBoolean(db.DataReader["indefinido"]);
                                    d.DiaPago =Convert.ToDateTime(db.DataReader["dia_pago"].ToString());
                                    d.ClabeCorresponsaliasRetiro = string.IsNullOrEmpty(db.DataReader["clabe_corresponsalias_retiro"].ToString()) ? "" : db.DataReader["clabe_corresponsalias_retiro"].ToString();
                                    d.ClabeCorresponsaliasDeposito = string.IsNullOrEmpty(db.DataReader["clabe_corresponsalias_deposito"].ToString()) ? "" : db.DataReader["clabe_corresponsalias_deposito"].ToString();
                                    d.IdServicio = string.IsNullOrEmpty(db.DataReader["id_servicio"].ToString()) ? 0 : Convert.ToInt16(db.DataReader["id_servicio"].ToString());
                                    d.NumeroReferencia = string.IsNullOrEmpty(db.DataReader["numero_referencia"].ToString()) ? "":  db.DataReader["numero_referencia"].ToString();
                                    d.Alias = db.DataReader["alias"].ToString();
                                    d.NumeroSocio = db.DataReader["numero_socio"].ToString(); //Se llena esta propiedad ya q no se estaba realizando
                                    response.Domiciliaciones.Add(d);
                                }
                            }
                        }
                        else
                        {
                            ExceptionObtenerDomiciliaciones exceptionObtenerDomiciliaciones = new ExceptionObtenerDomiciliaciones();
                            exceptionObtenerDomiciliaciones.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionObtenerDomiciliaciones.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerDomiciliaciones>(exceptionObtenerDomiciliaciones, db.DataReader["mensaje"].ToString());
                        }
                    }
                }
*/
            }
            catch (FaultException<ExceptionObtenerDomiciliaciones> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public ResponseEliminarDomiciliacion EliminarDomiciliacion(RequestEliminarDomiciliacion request)
        {
            ResponseEliminarDomiciliacion response = new ResponseEliminarDomiciliacion();
            try
            {
                //response.Mensaje = "MENSAJE ELIMINACION";
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "@idDomiciliacion", request.IdDomiciliacion);
                    db.AddParameters(1, "@numeroSocio", request.NumeroSocio);
                    db.AddParameters(2, "@tipoOrigen", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_DOMICILIACION_CANCELAR_DOMICILIACION");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                            response.Mensaje = db.DataReader["mensaje"].ToString();
                            Domiciliacion domiciliacion = ObtenerInformacionDomiciliacion(request.IdDomiciliacion, request.NumeroSocio);
                            response.Archivo = Reportes.CancelacionDeDomiciliacion(domiciliacion);
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, TipoBitacora.Domiciliación_cancelada, null, request.IdDomiciliacion, response.Archivo, "FormatoCancelacionDomiciliacion.pdf"));
                        }
                        else
                        {
                            response.Estatus = false;
                            ExceptionEliminarDomiciliacion exceptionEliminarDomiciliacion = new ExceptionEliminarDomiciliacion();
                            exceptionEliminarDomiciliacion.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionEliminarDomiciliacion.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionEliminarDomiciliacion>(exceptionEliminarDomiciliacion, db.DataReader["mensaje"].ToString());
                        }
                    }
                }

            }
            catch (FaultException<ExceptionEliminarDomiciliacion> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;


        }

        public ResponseObtenerPeriodicidadesServicios ObtenerPeriodicidadesServicios(RequestObtenerPeriodicidadesServicios request)
        {
            ResponseObtenerPeriodicidadesServicios response = new ResponseObtenerPeriodicidadesServicios();
            try
            {
                response.periodicidades = new List<ResponsePeriodicidad>();
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_PERIODICIDAD");
                    while (db.DataReader.Read())
                    {
                        ResponsePeriodicidad ResponsePeriodicidad = new ResponsePeriodicidad();
                        ResponsePeriodicidad.Descripcion = db.DataReader["descripcion"].ToString();
                        ResponsePeriodicidad.IdPeriodicidad = Convert.ToInt16(db.DataReader["id_periodicidad_pago"]);
                        response.periodicidades.Add(ResponsePeriodicidad);
                    }

                }

                response.Estatus = true;
                response.Mensaje = "";
            }
            catch (FaultException<ExceptionCancelarDomiciliacion> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return response;
        }

        public ResponseGenerarFormatoDomiciliacion GenerarFormatoDomiciliacion(RequestGenerarFormatoDomiciliacion request)
        {
            ResponseGenerarFormatoDomiciliacion response = new ResponseGenerarFormatoDomiciliacion();
            try
            {
                Domiciliacion domiciliacion = ObtenerInformacionDomiciliacion(request.IdDomiciliacion, request.NumeroSocio);
                if (domiciliacion != null)
                {
                    if (domiciliacion.Activo)
                        response.Archivo = Reportes.AltaDomiciliacion(domiciliacion);
                    else
                        response.Archivo = Reportes.CancelacionDeDomiciliacion(domiciliacion);
                    response.Estatus = true;
                }
                else
                {
                    response.Estatus = false;
                    ExceptionGenerarFormatoDomiciliacion exceptionFormatoDomiciliacion = new ExceptionGenerarFormatoDomiciliacion();
                    exceptionFormatoDomiciliacion.Codigo = 326;
                    exceptionFormatoDomiciliacion.Mensaje = "Id de cuenta domiciliación no existe";
                    throw new FaultException<ExceptionGenerarFormatoDomiciliacion>(exceptionFormatoDomiciliacion, "Id de cuenta domiciliación no existe");
                }
            }
            catch (FaultException<ExceptionGenerarFormatoDomiciliacion> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;

        }

        public Domiciliacion ObtenerInformacionDomiciliacion(Int64 idDomiciliacion, string numeroSocio)
        {
            Domiciliacion domiciliacion = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@Id_domiciliacion", idDomiciliacion);
                    db.AddParameters(1, "@numero_socio", numeroSocio);

                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_DOMICILIACION_OBTENER_INFO_REPORTE");
                    if (db.DataReader.Read())
                    {
                        domiciliacion = new Domiciliacion()
                        {
                            Ciudad = db.DataReader["Ciudad"].ToString(),
                            nombreProveedorDest = db.DataReader["nombre_proveedor_destino"].ToString(),
                            DescProducto = db.DataReader["nombre_producto"].ToString(),
                            NumeroReferencia = db.DataReader["referencia"].ToString(),
                            DescPeriodicidadPago = db.DataReader["periodicidad_pago"].ToString(),
                            diaPago = string.IsNullOrEmpty(db.DataReader["dia_pago"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["dia_pago"].ToString()),
                            nombreProveedorOrigen = db.DataReader["nombre_proveedor_origen"].ToString(),
                            NumTarjeta = db.DataReader["Num_tarjeta"].ToString(),
                            clabe = db.DataReader["clabe_interbancaria"].ToString(),
                            telCelular = db.DataReader["Tel_Celular"].ToString(),
                            MontoFijo = string.IsNullOrEmpty(db.DataReader["monto_fijo"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["monto_fijo"].ToString()),
                            porMontoFijo = string.IsNullOrEmpty(db.DataReader["por_monto_fijo"].ToString()) ? false : Convert.ToBoolean(db.DataReader["por_monto_fijo"].ToString()),
                            porMontoRequerido = string.IsNullOrEmpty(db.DataReader["por_monto_requerido"].ToString()) ? false : Convert.ToBoolean(db.DataReader["por_monto_requerido"].ToString()),
                            Indefinido = string.IsNullOrEmpty(db.DataReader["indefinido"].ToString()) ? false : Convert.ToBoolean(db.DataReader["indefinido"].ToString()),
                            FechaDeVencimiento = string.IsNullOrEmpty(db.DataReader["fecha_vencimiento"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(db.DataReader["fecha_vencimiento"].ToString()),
                            TipoDomiciliacion = (TipoDomiciliacion)Convert.ToInt32(db.DataReader["id_tipo_domiciliacion"].ToString()),
                            nombreSocio = db.DataReader["nombre_completo_socio"].ToString(),
                            Activo = Convert.ToBoolean(db.DataReader["activo"].ToString()),
                            montoMaximo = string.IsNullOrEmpty(db.DataReader["monto_maximo"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["monto_maximo"].ToString()),
                            IdDomiciliacion = idDomiciliacion,
                            ClabeCorresponsaliasRetiro = db.DataReader["clabe_corresponsalias_retiro"].ToString()
                        };

                    }

                }

            }
            catch (FaultException<ExceptionCancelarDomiciliacion> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return domiciliacion;
        }


        public Result ValidaPtmoAlCorriente(string ClabeCorresponsalias, TipoOrigen tipoOrigen, string numeroSocio)
        {
            Result result = new Result();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "@ClabeCorresponsalias", ClabeCorresponsalias);
                    db.AddParameters(1, "@tipoOrigen", tipoOrigen);
                    db.AddParameters(2, "@numeroSocio", numeroSocio);

                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_DETALLE_PRESTAMO");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            if (Convert.ToDecimal(db.DataReader["capital_vencido"].ToString()) == 0)
                            {
                                result.Codigo = 200;
                            }
                            else
                            {
                                result.Codigo = 420;
                                result.Mensaje = "El préstamo se encuentra vencido";
                            }
                        }
                        else
                        {
                            result.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            result.Mensaje = db.DataReader["mensaje"].ToString();
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

    }
}
