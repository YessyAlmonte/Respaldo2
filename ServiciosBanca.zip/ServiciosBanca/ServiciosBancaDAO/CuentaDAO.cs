﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Cuenta;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{
    public class CuentaDAO
    {
        private DBManager db = null;
        public ResponseObtenerCuentas ObtenerCuentas(RequestObtenerCuentas request)
        {
            ResponseObtenerCuentas response = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "tipo_cuenta", request.TipoCuenta);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_CUENTAS");//Modificar SP para nuevos parametros
                    response = new ResponseObtenerCuentas();
                    response.Cuentas = new List<Cuenta>();
                    while (db.DataReader.Read())
                    {
                        if (db.DataReader["ESTATUS"].ToString().Equals("200"))
                        {
                            dynamic c = null;
                            if (Convert.ToInt16(db.DataReader["IdMov"].ToString()) == 112)
                            {
                                c = new Haber();
                                c.EstadoTarjeta = db.DataReader["estado_tarjeta"] == DBNull.Value ? EstadoTarjeta.Desbloqueada : (EstadoTarjeta)db.DataReader["estado_tarjeta"];
                                c.TipoBloqueoTarjeta = db.DataReader["tipo_bloqueo_tarjeta"] == DBNull.Value ? TipoBloqueoTarjeta.Ninguno : (TipoBloqueoTarjeta)db.DataReader["tipo_bloqueo_tarjeta"];
                            }
                            else if (Enum.Parse(typeof(TipoCuenta), db.DataReader["TipoCuenta"].ToString()).Equals(TipoCuenta.PRESTAMOS))
                            {
                                c = new Credito();
                                c.MontoInicial = string.IsNullOrEmpty(db.DataReader["MontoIncialPrestamo"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["MontoIncialPrestamo"].ToString());
                            }
                            else
                                c = new Cuenta();

                            c.TipoEsquema =string.IsNullOrEmpty(db.DataReader["idEsquema"].ToString()) ? TipoEsquema.Ninguno : ( (TipoEsquema)Convert.ToInt16(db.DataReader["idEsquema"].ToString()) );
                            c.IdMov = Convert.ToInt16(db.DataReader["IdMov"].ToString());
                            c.NombreCuenta = db.DataReader["NombreCuenta"].ToString();
                            c.Saldo = Convert.ToDecimal( string.IsNullOrEmpty(db.DataReader["Saldo"].ToString()) ? "0" : db.DataReader["Saldo"].ToString());
                            c.FechaUltimoAbono = string.IsNullOrEmpty(db.DataReader["FechaUltimoAbono"].ToString()) ? "N/A" : db.DataReader["FechaUltimoAbono"].ToString();
                            c.TipoCuenta = (TipoCuenta)Enum.Parse(typeof(TipoCuenta), db.DataReader["TipoCuenta"].ToString());
                            c.NumeroContrato = db.DataReader["NumeroContrato"].ToString();
                            c.ClabeCorresponsalias = db.DataReader["clabe_corresponsalias"].ToString();
                            c.ClabeSpei = db.DataReader["clabe_spei"].ToString();
                            response.Cuentas.Add(c);
                        }
                        else
                        {
                            ExceptionObtenerCuentas exceptionObtenerCuentas = new ExceptionObtenerCuentas();
                            exceptionObtenerCuentas.Codigo = db.DataReader["estatus"] == DBNull.Value ? 1000 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionObtenerCuentas.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerCuentas>(exceptionObtenerCuentas, exceptionObtenerCuentas.Mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;

        }

        public Cuenta ObtenerDetalleCuenta(RequestObtenerDetalleCuenta request)
        {
            Cuenta cuenta = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "clabe_corresponsalias", request.ClabeCorresponsalias);
                    db.AddParameters(2, "numero_contrato", request.NumeroContrato);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "BANCA.DBO.SP_BANCA_OBTENER_DETALLE_CUENTA");//Modificar SP para nuevos parametros
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            if (Enum.Parse(typeof(TipoCuenta), db.DataReader["TipoCuenta"].ToString()).Equals(TipoCuenta.HABERES))
                            {
                                Haber cuentaHaber = new Haber();
                                cuentaHaber.IdMov = db.DataReader["IdMov"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["IdMov"].ToString());
                                cuentaHaber.NombreCuenta = db.DataReader["NombreCuenta"] == DBNull.Value ? "" : db.DataReader["NombreCuenta"].ToString();
                                cuentaHaber.Saldo = db.DataReader["Saldo"] == DBNull.Value ? 0 : Convert.ToDecimal(db.DataReader["Saldo"].ToString());
                                cuentaHaber.TipoCuenta = (TipoCuenta)Convert.ToInt32(db.DataReader["TipoCuenta"].ToString());
                                cuentaHaber.NumeroTarjeta = db.DataReader["NumeroTarjeta"] == DBNull.Value ? "" : db.DataReader["NumeroTarjeta"].ToString();
                                cuentaHaber.UltimoAbono = string.IsNullOrEmpty(db.DataReader["FechaUltimoAbono"].ToString()) ? "N/A" : db.DataReader["FechaUltimoAbono"].ToString();
                                cuentaHaber.EstadoTarjeta = db.DataReader["EstadoTarjeta"] == DBNull.Value ? EstadoTarjeta.Desbloqueada : (EstadoTarjeta)db.DataReader["EstadoTarjeta"];
                                cuentaHaber.TipoBloqueoTarjeta = db.DataReader["TipoBloqueoTarjeta"] == DBNull.Value ? TipoBloqueoTarjeta.Ninguno : (TipoBloqueoTarjeta)db.DataReader["TipoBloqueoTarjeta"];
                                cuentaHaber.MontoRetiros = string.IsNullOrEmpty(db.DataReader["NumeroRetiros"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["NumeroRetiros"].ToString());
                                cuentaHaber.MontoDepositos =string.IsNullOrEmpty( db.DataReader["NumeroDepositos"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["NumeroDepositos"].ToString());
                                cuenta = cuentaHaber;
                            }
                            if (Enum.Parse(typeof(TipoCuenta), db.DataReader["TipoCuenta"].ToString()).Equals(TipoCuenta.PRESTAMOS))
                            {
                                Credito cuentaCredito = new Credito();
                                cuentaCredito.IdMov = db.DataReader["IdMov"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["IdMov"].ToString());
                                cuentaCredito.NombreCuenta = db.DataReader["NombreCuenta"] == DBNull.Value ? "" : db.DataReader["NombreCuenta"].ToString();
                                cuentaCredito.Saldo = db.DataReader["Saldo"] == DBNull.Value ? 0 : Convert.ToDecimal(db.DataReader["Saldo"].ToString());
                                cuentaCredito.TipoCuenta = (TipoCuenta)Convert.ToInt32(db.DataReader["TipoCuenta"].ToString());
                                //-----------
                                cuentaCredito.DiasVencidos = db.DataReader["DiasVencidos"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["DiasVencidos"].ToString());
                                cuentaCredito.EstatusCredito = db.DataReader["EstatusCredito"] == DBNull.Value ? "" : db.DataReader["EstatusCredito"].ToString();
                                cuentaCredito.PagoHoy = db.DataReader["PagoHoy"] == DBNull.Value ? 0 : Convert.ToDouble(db.DataReader["PagoHoy"].ToString());//PagoAlCorriente
                                cuentaCredito.PeriodosAtrasados = db.DataReader["PeriodosAtrasados"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["PeriodosAtrasados"].ToString());
                                cuentaCredito.MontoInicial = db.DataReader["MontoInicial"] == DBNull.Value ? 0 : Convert.ToDecimal(db.DataReader["MontoInicial"].ToString());
                                cuentaCredito.FechaPrestamo = db.DataReader["FechaPrestamo"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(db.DataReader["FechaPrestamo"].ToString());

                                DateTime  fCorte;
                                if (DateTime.TryParse(db.DataReader["FechaCorte"].ToString(),out fCorte))
                                    cuentaCredito.FechaCorte = fCorte.ToShortDateString();
                                else
                                    cuentaCredito.FechaCorte = db.DataReader["FechaCorte"] == DBNull.Value ? "" : db.DataReader["FechaCorte"].ToString();

                                DateTime fLimitePago;
                                if (DateTime.TryParse(db.DataReader["FechaLimitePago"].ToString(), out fLimitePago))
                                    cuentaCredito.FechaLimitePago = fLimitePago.ToShortDateString();
                                else
                                    cuentaCredito.FechaLimitePago = db.DataReader["FechaLimitePago"] == DBNull.Value ? "" : db.DataReader["FechaLimitePago"].ToString();

                                DateTime fUltimoPago;
                                if (DateTime.TryParse(db.DataReader["FechaUltimoPago"].ToString(), out fUltimoPago))
                                    cuentaCredito.FechaUltimoPago = fUltimoPago.ToShortDateString();
                                else
                                    cuentaCredito.FechaUltimoPago = string.IsNullOrEmpty(db.DataReader["FechaUltimoPago"].ToString()) ? "N/A" : db.DataReader["FechaUltimoPago"].ToString();

                                cuentaCredito.MontoDisponible = db.DataReader["MontoDisponible"] == DBNull.Value ? 0 : Convert.ToDouble(db.DataReader["MontoDisponible"].ToString());
                                cuentaCredito.LimiteCredito = db.DataReader["LimiteCredito"] == DBNull.Value ? 0 : Convert.ToDouble(db.DataReader["LimiteCredito"].ToString());
                                
                                cuentaCredito.SaldoAdelantado = string.IsNullOrEmpty(db.DataReader["SaldoAdelantado"].ToString()) ? 0 :Convert.ToDecimal(db.DataReader["SaldoAdelantado"].ToString());
                                //cuentaCredito.ReferenciaCorresponsales = db.DataReader["ReferenciaCorresponsales"] == DBNull.Value ? "" : db.DataReader["ReferenciaCorresponsales"].ToString();
                                cuenta = cuentaCredito;
                                cuenta.TipoEsquema = (TipoEsquema)Convert.ToInt16(db.DataReader["idEsquema"].ToString());
                                
                            }
                            if (Enum.Parse(typeof(TipoCuenta), db.DataReader["TipoCuenta"].ToString()).Equals(TipoCuenta.INVERSIONES))
                            {
                                Inversion inversion = new Inversion();
                                inversion.IdMov = db.DataReader["IdMov"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["IdMov"].ToString());
                                inversion.NombreCuenta = db.DataReader["NombreCuenta"] == DBNull.Value ? "" : db.DataReader["NombreCuenta"].ToString();
                                inversion.FechaApertura = db.DataReader["FechaApertura"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(db.DataReader["FechaApertura"].ToString());
                                inversion.NumeroContrato = db.DataReader["NoContrato"] == DBNull.Value ? "" : db.DataReader["NoContrato"].ToString();
                                inversion.FechaVencimiento = db.DataReader["FechaVencimiento"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(db.DataReader["FechaVencimiento"].ToString());
                                inversion.Plazo = db.DataReader["plazo"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["plazo"].ToString());
                                inversion.Tasa = db.DataReader["Tasa"] == DBNull.Value ? 0 : Convert.ToDouble(db.DataReader["Tasa"].ToString());
                                inversion.TipoCuenta = (TipoCuenta)Convert.ToInt32(db.DataReader["TipoCuenta"].ToString());
                                inversion.Saldo = db.DataReader["Saldo"] == DBNull.Value ? 0 : Convert.ToDecimal(db.DataReader["Saldo"].ToString());
                                cuenta = inversion;
                            }
                            cuenta.ClabeCorresponsalias = string.IsNullOrEmpty(db.DataReader["ClabeCorresponsalias"].ToString())? "" : db.DataReader["ClabeCorresponsalias"].ToString();
                            cuenta.ClabeSpei = string.IsNullOrEmpty(db.DataReader["ClabeSpei"].ToString())? "" : db.DataReader["ClabeSpei"].ToString();
                            
                        }
                        else
                        {
                            ExceptionObtenerDetalleCuenta exceptionObtenerDetalleCuenta = new ExceptionObtenerDetalleCuenta();
                            exceptionObtenerDetalleCuenta.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionObtenerDetalleCuenta.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerDetalleCuenta>(exceptionObtenerDetalleCuenta, exceptionObtenerDetalleCuenta.Mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return cuenta;
        }

        public ResponseObtenerMovimientosCuenta ObtenerMovimientosCuenta(RequestObtenerMovimientosCuenta request)
        {
            ResponseObtenerMovimientosCuenta response = null;
            try
            {


                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(4);
                    db.AddParameters(0, "@numero ", request.NumeroSocio);
                    db.AddParameters(1, "@clabeCorresponsalias", request.ClabeCorresponsalias);
                    db.AddParameters(2, "@periodo", request.PeriodoActual);
                    db.AddParameters(3, "@fecha_calculo", DBNull.Value);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_MOVIMIENTOS_CUENTA");//Modificar SP para nuevos parametros
                    response = new ResponseObtenerMovimientosCuenta();
                    response.Movimientos = new List<Movimiento>();
                    if (db.existeRegistro)
                    {
                        while (db.DataReader.Read())
                        {
                            if (db.DataReader["ESTATUS"].ToString().Equals("200"))
                            {
                                Movimiento m = new Movimiento();
                                m.Monto = Convert.ToDecimal(db.DataReader["Monto"].ToString());
                                m.DescripcionMov = db.DataReader["Descripcion"].ToString();
                                m.SaldoPosterior = Convert.ToDecimal(db.DataReader["Saldo"].ToString());
                                m.FechaMov = string.IsNullOrEmpty(db.DataReader["Fecha_Mov"].ToString()) ? "N/A" : db.DataReader["Fecha_Mov"].ToString();
                                m.Operacion = db.DataReader["Debe_haber"].ToString();
                                m.ClabeCorresponsalias = request.ClabeCorresponsalias;
                                m.ClabeSpei = db.DataReader["clabeInterbancaria"].ToString();
                                response.Movimientos.Add(m);
                            }
                            else
                            {
                                ExceptionObtenerMovimientosCuenta exceptionObtenerMovimientosCuenta = new ExceptionObtenerMovimientosCuenta();
                                exceptionObtenerMovimientosCuenta.Codigo = db.DataReader["estatus"] == DBNull.Value ? 1000 : Convert.ToInt32(db.DataReader["estatus"]);
                                exceptionObtenerMovimientosCuenta.Mensaje = db.DataReader["mensaje"].ToString();
                                Bitacora<ExceptionObtenerMovimientosCuenta> Bex = new Bitacora<ExceptionObtenerMovimientosCuenta>(request.NumeroSocio.ToString(), exceptionObtenerMovimientosCuenta, request.NumeroSocio.ToString());
                                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerMovimientosCuenta>>.SerealizarObjtecToString(Bex));
                                throw new FaultException<ExceptionObtenerMovimientosCuenta>(exceptionObtenerMovimientosCuenta, exceptionObtenerMovimientosCuenta.Mensaje);
                            }
                        }
                    }
                    else
                    {
                        ExceptionObtenerMovimientosCuenta exceptionObtenerMovimientosCuenta = new ExceptionObtenerMovimientosCuenta();
                        exceptionObtenerMovimientosCuenta.Codigo = 338;
                        exceptionObtenerMovimientosCuenta.Mensaje = "No existen movimientos en la cuenta";
                        Bitacora<ExceptionObtenerMovimientosCuenta> Bex = new Bitacora<ExceptionObtenerMovimientosCuenta>(request.NumeroSocio.ToString(), exceptionObtenerMovimientosCuenta, request.NumeroSocio.ToString());
                        new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerMovimientosCuenta>>.SerealizarObjtecToString(Bex));
                        throw new FaultException<ExceptionObtenerMovimientosCuenta>(exceptionObtenerMovimientosCuenta, exceptionObtenerMovimientosCuenta.Mensaje);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;

        }
    }
}
