﻿using AccesoDatos;
using ServiciosBancaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{
   public  class PruebaDAO
    {
        private DBManager db = null;
        public bool AcutalizarContraseñas()
        {
 
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.ExecuteNonQuery(System.Data.CommandType.Text, "update TBL_BANCA_SOCIOS set fecha_contrasena_temporal = GETDATE()");
                    return true;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }
    }
}
