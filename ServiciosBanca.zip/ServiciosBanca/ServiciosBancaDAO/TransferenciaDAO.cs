﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Comprobante;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaEntidades.Transferencias;
using ServiciosBancaUtils.Reportes;
using SmsMailUtils;
using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace ServiciosBancaDAO
{
    public class TransferenciaDAO
    {
        private DBManager db = null;

        #region Cuentas Internas
        public ResponseAltaCuentaInterna AltaCuentaInterna(RequestAltaCuentaInterna request)
        {
            ResponseAltaCuentaInterna response = new ResponseAltaCuentaInterna();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(7);
                    db.AddParameters(0, "NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "titular_cuenta", request.TitularCuenta);
                    db.AddParameters(2, "clabe_corresponsalias ", request.ClabeCorresponsalias);
                    db.AddParameters(3, "alias", request.Alias);
                    db.AddParameters(4, "monto_maximo", request.MontoMaximo);
                    db.AddParameters(5, "correo", request.Correo);
                    db.AddParameters(6, "id_cuenta_interna", request.IdCuentaInterna);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ALTA_CUENTA_INTERNA");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, (request.IdCuentaInterna == 0 ? TipoBitacora.alta_de_cuentas_internas_mismo_banco : TipoBitacora.modificación_cuenta_de_tercer__Modificación_de_cuentas_internas_mismo_banco)));
                        }
                        else
                        {
                            ExceptionAltaCuentaInterna exceptionAltaCuentaInterna = new ExceptionAltaCuentaInterna();
                            exceptionAltaCuentaInterna.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionAltaCuentaInterna.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionAltaCuentaInterna>(exceptionAltaCuentaInterna, exceptionAltaCuentaInterna.Mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
        public ResponseEliminarCuentaInterna EliminaCuentaInterna(RequestEliminarCuentaInterna request)
        {
            ResponseEliminarCuentaInterna response = new ResponseEliminarCuentaInterna();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "id_cuenta_interna", request.IdCuentaInterna);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ELIMINA_CUENTA_INTERNA");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, TipoBitacora.baja_de_cuenta_interna));
                        }
                        else
                        {
                            ExceptionEliminarCuentaInterna exceptionEliminarCuentaInterna = new ExceptionEliminarCuentaInterna();
                            exceptionEliminarCuentaInterna.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionEliminarCuentaInterna.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionEliminarCuentaInterna>(exceptionEliminarCuentaInterna, "Reason: Testing the Fault contract");
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return response;
        }

        public ResponseTransferenciasCuentasPropias TransferenciasCuentasPropias(RequestTransferenciasCuentasPropias request)
        {
            ResponseTransferenciasCuentasPropias response = new ResponseTransferenciasCuentasPropias();
            ExceptionTransferenciasCuentasPropias exceptionTransferenciasCuentasPropias = null;

            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(8);
                    db.AddParameters(0, "numeroSocio", request.NumeroSocio);
                    db.AddParameters(1, "monto", request.Monto);
                    db.AddParameters(2, "clabeCorresponsaliasRetiro", request.ClabeCorresponsaliasRetiro);
                    db.AddParameters(3, "clabeCorresponsaliasDeposito ", request.ClabeCorresponsaliasDeposito);
                    db.AddParameters(4, "programada", request.Programada);
                    db.AddParameters(5, "horaProgramada", request.HoraProgramada);
                    db.AddParameters(6, "tipoOrigen", request.tipoOrigen);
                    db.AddParameters(7, "tipoTransferenciaInterna", request.TipoTransferenciaInterna);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_REALIZA_TRANSFERENCIA_INTERNA");
                    if (db.DataReader.Read())
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                            TipoBitacora tipoBitacora = 0;
                            //tranferencia entre mis cuentas y no es programada
                            if (string.IsNullOrEmpty(request.OTP) && !request.Programada)
                                tipoBitacora = TipoBitacora.transferencia_realizada_entre_cuentras_propias;
                            else if (string.IsNullOrEmpty(request.OTP) && request.Programada)
                                tipoBitacora = TipoBitacora.Transferencia_Programada_Entre_cuentas_propias;
                            else if (!string.IsNullOrEmpty(request.OTP) && !request.Programada)
                                tipoBitacora = TipoBitacora.transferencia_realizada_cuentas_mismo_banco_entre_socios;
                            else if (!string.IsNullOrEmpty(request.OTP) && request.Programada)
                                tipoBitacora = TipoBitacora.Transferencia_Programada_cuentas_misma_institución_entre_socios;

                            response.FechaTransaccion = string.IsNullOrEmpty(db.DataReader["HoraTransaccion"].ToString()) ? null : Convert.ToDateTime(db.DataReader["HoraTransaccion"].ToString()).ToShortDateString();
                            response.HoraTransaccion = string.IsNullOrEmpty(db.DataReader["HoraTransaccion"].ToString()) ? null : Convert.ToDateTime(db.DataReader["HoraTransaccion"].ToString()).ToShortTimeString();
                            response.Folio = db.DataReader["folio"].ToString();
                            response.Monto = string.IsNullOrEmpty(db.DataReader["Monto"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["Monto"].ToString());
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, tipoBitacora));


                        }
                        else
                        {
                            exceptionTransferenciasCuentasPropias = new ExceptionTransferenciasCuentasPropias();
                            exceptionTransferenciasCuentasPropias.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionTransferenciasCuentasPropias.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionTransferenciasCuentasPropias>(exceptionTransferenciasCuentasPropias, exceptionTransferenciasCuentasPropias.Mensaje);
                        }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;

        }

        #endregion Cuentas Internas

        #region Cuentas Externas

        public ResponseAltaCuentaExternaCredito AltaCuentaExternaCredito(RequestAltaCuentaExternaCredito request)
        {
            ResponseAltaCuentaExternaCredito response = new ResponseAltaCuentaExternaCredito();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(8);
                    db.AddParameters(0, "Numero", request.NumeroSocio);
                    db.AddParameters(1, "numero_tarjeta", request.NumeroTarjeta);
                    db.AddParameters(2, "alias", request.Alias);
                    db.AddParameters(3, "titular_cuenta", request.TitularCuenta);
                    db.AddParameters(4, "monto_maximo ", request.MontoMaximo);
                    db.AddParameters(5, "correo", request.Correo);
                    db.AddParameters(6, "id_banco", request.idBanco);
                    db.AddParameters(7, "id_cuenta_externa", request.idCuentaExterna);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ALTA_CUENTA_EXTERNA_CREDITO");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                            response.Mensaje = db.DataReader["mensaje"].ToString();
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, (request.idCuentaExterna == "0" ? TipoBitacora.Alta_cuenta_de_externas_Diferentes_instituciones : TipoBitacora.Modificación_de_cuentas_externa_Diferentes_instituciones)));
                        }
                        else
                        {
                            ExceptionAltaCuentaExternaCredito exceptionAltaCuentaExternaCredito = new ExceptionAltaCuentaExternaCredito();
                            exceptionAltaCuentaExternaCredito.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionAltaCuentaExternaCredito.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionAltaCuentaExternaCredito>(exceptionAltaCuentaExternaCredito);
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return response;
        }

        public ResponseAltaCuentaExternaDebito AltaCuentaExternaDebito(RequestAltaCuentaExternaDebito request)
        {
            ResponseAltaCuentaExternaDebito response = new ResponseAltaCuentaExternaDebito();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(8);
                    db.AddParameters(0, "NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "numero_tarjeta", request.NumeroTarjeta);
                    db.AddParameters(2, "alias", request.Alias);
                    db.AddParameters(3, "titular_cuenta ", request.TitularCuenta);
                    db.AddParameters(4, "monto_maximo", request.MontoMaximo);
                    db.AddParameters(5, "correo", request.Correo);
                    db.AddParameters(6, "id_cuenta_externa", request.IdCuentaExterna);
                    db.AddParameters(7, "id_banco", request.IdBanco);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ALTA_CUENTA_EXTERNA_DEBITO");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = Convert.ToInt32(db.DataReader["estatus"]);
                            response.Mensaje = db.DataReader["mensaje"].ToString();
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, (request.IdCuentaExterna == "0" ? TipoBitacora.Alta_cuenta_de_externas_Diferentes_instituciones : TipoBitacora.Modificación_de_cuentas_externa_Diferentes_instituciones)));
                        }
                        else
                        {
                            ExceptionAltaCuentaExternaDebito exceptionAltaCuentaExternaDebito = new ExceptionAltaCuentaExternaDebito();
                            exceptionAltaCuentaExternaDebito.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionAltaCuentaExternaDebito.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionAltaCuentaExternaDebito>(exceptionAltaCuentaExternaDebito, "Reason: Testing the Fault contract");
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return response;
        }

        public ResponseAltaCuentaExternaCelular AltaCuentaExternaCelular(RequestAltaCuentaExternaCelular request)
        {
            ResponseAltaCuentaExternaCelular response = new ResponseAltaCuentaExternaCelular();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(8);
                    db.AddParameters(0, "NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "numero_celular", request.NumeroCelular);
                    db.AddParameters(2, "id_banco", request.IdBanco);
                    db.AddParameters(3, "alias", request.Alias);
                    db.AddParameters(4, "titular_cuenta", request.TitularCuenta);
                    db.AddParameters(5, "monto_maximo", request.MontoMaximo);
                    db.AddParameters(6, "correo", request.Correo);
                    db.AddParameters(7, "idCuentaCelular", request.IdCuentaExterna);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ALTA_CUENTA_EXTERNA_CELULAR");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = Convert.ToInt32(db.DataReader["estatus"]);
                            response.Mensaje = db.DataReader["mensaje"].ToString();
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, (request.IdCuentaExterna == "0" ? TipoBitacora.Alta_cuenta_de_externas_Diferentes_instituciones : TipoBitacora.Modificación_de_cuentas_externa_Diferentes_instituciones)));
                        }
                        else
                        {
                            ExceptionAltaCuentaExternaCelular exceptionAltaCuentaInterna = new ExceptionAltaCuentaExternaCelular();
                            exceptionAltaCuentaInterna.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionAltaCuentaInterna.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionAltaCuentaExternaCelular>(exceptionAltaCuentaInterna, "Reason: Testing the Fault contract");
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return response;
        }

        public ResponseAltaCuentaExternaClabe AltaCuentaExternaClabe(RequestAltaCuentaExternaClabe request)
        {
            ResponseAltaCuentaExternaClabe response = new ResponseAltaCuentaExternaClabe();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(8);
                    db.AddParameters(0, "NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "titular_cuenta", request.TitularCuenta);
                    db.AddParameters(2, "clabe_spei", request.ClabeSPEI);
                    db.AddParameters(3, "alias", request.Alias);
                    db.AddParameters(4, "monto_maximo", request.MontoMaximo);
                    db.AddParameters(5, "correo", request.Correo);
                    db.AddParameters(6, "id_cuenta_externa", request.IdCuentaExterna);
                    db.AddParameters(7, "id_banco", request.IdBanco);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ALTA_CUENTA_EXTERNA_CLABE");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = Convert.ToInt32(db.DataReader["estatus"]);
                            response.Mensaje = db.DataReader["mensaje"].ToString();
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, (request.IdCuentaExterna == "0" ? TipoBitacora.Alta_cuenta_de_externas_Diferentes_instituciones : TipoBitacora.Modificación_de_cuentas_externa_Diferentes_instituciones)));
                        }
                        else
                        {
                            ExceptionAltaCuentaExternaClabe exceptionAltaCuentaExternaClabe = new ExceptionAltaCuentaExternaClabe();
                            exceptionAltaCuentaExternaClabe.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionAltaCuentaExternaClabe.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionAltaCuentaExternaClabe>(exceptionAltaCuentaExternaClabe, "Reason: Testing the Fault contract");
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return response;
        }

        #region Eliminar Cuenta Externa  no se usan a no ser que en la base de datos se separen las cuentas
        public ResponseEliminaCuentaNumeroCelular EliminaCuentaNumeroCelular(RequestEliminaCuentaNumeroCelular request)
        {
            ResponseEliminaCuentaNumeroCelular response = new ResponseEliminaCuentaNumeroCelular();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@numero_socio", request.NumeroSocio);
                    db.AddParameters(1, "@idCuenta", request.idCuentaExterna);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ELIMINAR_CUENTAS_EXTERNAS");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                        }
                        else
                        {
                            ExceptionEliminaCuentaNumeroCelular exceptionEliminaCuentaNumeroCelular = new ExceptionEliminaCuentaNumeroCelular();
                            exceptionEliminaCuentaNumeroCelular.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionEliminaCuentaNumeroCelular.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionEliminaCuentaNumeroCelular>(exceptionEliminaCuentaNumeroCelular, "Reason: Testing the Fault contract");
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return response;
        }

        public ResponseEliminaCuentaExternaClabe EliminaCuentaExternaClabe(RequestEliminaCuentaExternaClabe request)
        {
            ResponseEliminaCuentaExternaClabe response = new ResponseEliminaCuentaExternaClabe();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@numero_socio", request.NumeroSocio);
                    db.AddParameters(1, "@idCuenta", request.idCuentaExterna);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ELIMINAR_CUENTAS_EXTERNAS");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                        }
                        else
                        {
                            ExceptionEliminaCuentaExternaClabe exceptionEliminaCuentaExternaClabe = new ExceptionEliminaCuentaExternaClabe();
                            exceptionEliminaCuentaExternaClabe.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionEliminaCuentaExternaClabe.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionEliminaCuentaExternaClabe>(exceptionEliminaCuentaExternaClabe, "Reason: Testing the Fault contract");
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return response;
        }

        public ResponseEliminaCuentaDebito EliminaCuentaDebito(RequestEliminaCuentaDebito request)
        {
            ResponseEliminaCuentaDebito response = new ResponseEliminaCuentaDebito();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@numero_socio", request.NumeroSocio);
                    db.AddParameters(1, "@idCuenta", request.idCuentaExterna);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ELIMINAR_CUENTAS_EXTERNAS");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                        }
                        else
                        {
                            ExceptionEliminaCuentaDebito exceptionEliminaCuentaDebito = new ExceptionEliminaCuentaDebito();
                            exceptionEliminaCuentaDebito.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionEliminaCuentaDebito.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionEliminaCuentaDebito>(exceptionEliminaCuentaDebito);
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return response;
        }

        #endregion

        public ResponseEliminaCuentaExterna EliminaCuentaExterna(RequestEliminaCuentaExterna request)
        {
            ResponseEliminaCuentaExterna response = new ResponseEliminaCuentaExterna();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@numero_socio", request.NumeroSocio);
                    db.AddParameters(1, "@idCuenta", request.IdCuentaExterna);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ELIMINAR_CUENTAS_EXTERNAS");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                            response.Mensaje = db.DataReader["mensaje"].ToString();
                            SmsMail.validarTipoNotificaion(new UtileriasDAO().ObtenerNotificacionSocio(request.NumeroSocio, TipoBitacora.Baja_de_cuenta_externa_Diferentes_instituciones));

                        }
                        else
                        {
                            ExceptionEliminaCuentaExterna exceptionEliminaCuentaExterna = new ExceptionEliminaCuentaExterna();
                            exceptionEliminaCuentaExterna.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionEliminaCuentaExterna.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionEliminaCuentaExterna>(exceptionEliminaCuentaExterna);
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return response;
        }

        public ResponseTransferenciasCuentasExterna TransferenciasCuentasExterna(RequestTransferenciasCuentasExterna request)
        {
            ResponseTransferenciasCuentasExterna response = new ResponseTransferenciasCuentasExterna();
            ExceptionTransferenciasCuentasExterna exceptionTransferenciasCuentasExterna = null;

            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(8);
                    db.AddParameters(0, "numero", request.NumeroSocio);
                    db.AddParameters(1, "monto", request.Monto);
                    db.AddParameters(2, "clabe_spei_retiro", request.ClabeSPEIRetiro);
                    db.AddParameters(3, "clabe_spei_deposito ", request.ClabeSPEIDeposito);
                    db.AddParameters(4, "fecha_programada", (request.HoraProgramada == DateTime.MinValue ? (object)DBNull.Value : request.HoraProgramada));
                    db.AddParameters(5, "programado", request.Programado);
                    db.AddParameters(6, "tipo_origen", request.TipoOrigen);
                    db.AddParameters(7, "concepto_pago", request.ConceptoPago);

                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_REALIZA_TRANSFERENCIA_EXTERNA");
                    if (db.DataReader.Read())
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.EstatusTransferencia = EstatusTransferencia.Pendiente;
                            response.FechaTransaccion = string.IsNullOrEmpty(db.DataReader["HoraTransaccion"].ToString()) ? null : Convert.ToDateTime(db.DataReader["HoraTransaccion"].ToString()).ToShortDateString();
                            response.HoraTransaccion = string.IsNullOrEmpty(db.DataReader["HoraTransaccion"].ToString()) ? null : Convert.ToDateTime(db.DataReader["HoraTransaccion"].ToString()).ToShortTimeString();
                            response.Monto = string.IsNullOrEmpty(db.DataReader["Monto"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["Monto"].ToString());
                            response.IdTransferenciaCMV = string.IsNullOrEmpty(db.DataReader["IdTransferenciaCMV"].ToString()) ? "" : db.DataReader["IdTransferenciaCMV"].ToString();
                            response.ClaveRastreo = string.IsNullOrEmpty(db.DataReader["claveRastreo"].ToString()) ? "" : db.DataReader["claveRastreo"].ToString();
                            response.ReferenciaNumerica = string.IsNullOrEmpty(db.DataReader["referenciaNumerica"].ToString()) ? 0 : Convert.ToInt64(db.DataReader["referenciaNumerica"].ToString());
                            response.ConceptoPago = string.IsNullOrEmpty(db.DataReader["concepto_pago"].ToString()) ? "" : db.DataReader["concepto_pago"].ToString();
                            response.nombreOrigen = string.IsNullOrEmpty(db.DataReader["nombre_origen"].ToString()) ? "" : db.DataReader["nombre_origen"].ToString();
                            response.rfcpOrigen = string.IsNullOrEmpty(db.DataReader["rfc_origen"].ToString()) ? "" : db.DataReader["rfc_origen"].ToString();
                            response.idTipoCuentaExterna = string.IsNullOrEmpty(db.DataReader["id_tipo_cuenta_externa"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_tipo_cuenta_externa"].ToString());
                        }
                        else
                        {
                            exceptionTransferenciasCuentasExterna = new ExceptionTransferenciasCuentasExterna();
                            exceptionTransferenciasCuentasExterna.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionTransferenciasCuentasExterna.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionTransferenciasCuentasExterna>(exceptionTransferenciasCuentasExterna, exceptionTransferenciasCuentasExterna.Mensaje);
                        }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;

        }

        public ResponseTransferenciasCuentasCredito TransferenciasCuentasCredito(RequestTransferenciasCuentasCredito request)
        {
            ResponseTransferenciasCuentasCredito response = new ResponseTransferenciasCuentasCredito();
            ExceptionTransferenciasCuentasCredito exception = null;

            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(8);
                    db.AddParameters(0, "numero", request.NumeroSocio);
                    db.AddParameters(1, "monto", request.Monto);
                    db.AddParameters(2, "clabe_corresponsalias_retiro", request.ClabeCorresponsaliasRetiro);
                    db.AddParameters(3, "numero_tarjeta", request.NumeroTarjeta);
                    db.AddParameters(4, "fecha_programada", (request.HoraProgramada == DateTime.MinValue ? (object)DBNull.Value : request.HoraProgramada));
                    db.AddParameters(5, "programado", request.Programado);
                    db.AddParameters(6, "tipo_origen", request.TipoOrigen);
                    db.AddParameters(7, "concepto_pago", request.ConceptoPago);

                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_REALIZA_TRANSFERENCIA_EXTERNA_TDC");
                    if (db.DataReader.Read())
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.EstatusTransferencia = EstatusTransferencia.Pendiente;
                            response.FechaTransaccion = string.IsNullOrEmpty(db.DataReader["HoraTransaccion"].ToString()) ? null : Convert.ToDateTime(db.DataReader["HoraTransaccion"].ToString()).ToShortDateString();
                            response.HoraTransaccion = string.IsNullOrEmpty(db.DataReader["HoraTransaccion"].ToString()) ? null : Convert.ToDateTime(db.DataReader["HoraTransaccion"].ToString()).ToShortTimeString();
                            response.Monto = string.IsNullOrEmpty(db.DataReader["Monto"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["Monto"].ToString());
                            response.IdTransferenciaCMV = string.IsNullOrEmpty(db.DataReader["IdTransferenciaCMV"].ToString()) ? "" : db.DataReader["IdTransferenciaCMV"].ToString();
                            response.Folio = string.IsNullOrEmpty(db.DataReader["folio"].ToString()) ? "" : db.DataReader["folio"].ToString();
                            response.Leyenda = db.DataReader["mensaje"].ToString();
                        }
                        else
                        {
                            exception = new ExceptionTransferenciasCuentasCredito();
                            exception.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exception.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionTransferenciasCuentasCredito>(exception, exception.Mensaje);
                        }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;

        }


        public void AsignarIdTransferenciaSPEI(string numeroSocio, string idTransferencia, Int64 idTransferenciaSpei)
        {
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "numero", numeroSocio);
                    db.AddParameters(1, "id_transferencia", idTransferencia);
                    db.AddParameters(2, "id_transferencia_spei", idTransferenciaSpei);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ASIGNA_ID_TRANSFERENCIA_SPEI");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) != 1)
                        {
                            throw new Exception(db.DataReader["mensaje"].ToString());
                        }
                    }
                    else
                    {
                        throw new Exception(db.DataReader["mensaje"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool ErrorRegistraOrdenSPEI(string idTransferencia, string claveRastreo, int idErrorRegistraOrden, string mensajeError)
        {
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(4);
                    db.AddParameters(0, "id_transferencia", idTransferencia);
                    db.AddParameters(1, "clave_rastreo", claveRastreo);
                    db.AddParameters(2, "id_error_registra_orden", idErrorRegistraOrden);
                    db.AddParameters(3, "mensaje_error", mensajeError);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ERROR_REGISTRA_ORDEN_SPEI");
                    if (db.DataReader.Read())
                    {
                        if (db.DataReader["estatus"].ToString().Equals("200"))
                        {
                            return true;
                        }
                        else
                        {
                            new Exception(db.DataReader["mensaje"].ToString());
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }
        #endregion Cuentas Externas

        public List<ResponseObtenerCuentasRetiro> ObtenerCuentasRetiro(RequestObtenerCuentasRetiro request)
        {
            ResponseObtenerCuentasRetiro cuenta = null;
            List<ResponseObtenerCuentasRetiro> cuentas = new List<ResponseObtenerCuentasRetiro>();
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@NUMERO", request.NumeroSocio);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_CUENTAS_RETIRO");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            cuenta = new ResponseObtenerCuentasRetiro();
                            cuenta.ClabeCorresponsalias = string.IsNullOrEmpty(db.DataReader["clabe_corresponsalias"].ToString()) ? "" : db.DataReader["clabe_corresponsalias"].ToString();
                            cuenta.Saldo = Convert.ToDecimal(db.DataReader["Saldo_Actual"].ToString());
                            cuenta.NombreCuenta = db.DataReader["Nombre_Cuenta"].ToString();
                            cuenta.Id = Convert.ToInt64(db.DataReader["Id_mov"].ToString());
                            cuentas.Add(cuenta);
                        }
                        else
                        {
                            ExceptionObtenerCuentasRetiro exceptionObtenerCuentasRetiro = new ExceptionObtenerCuentasRetiro();
                            exceptionObtenerCuentasRetiro.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionObtenerCuentasRetiro.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerCuentasRetiro>(exceptionObtenerCuentasRetiro);
                        }
                    }
                }
                // OBTENEMOS LA INFORMACION DE REVOLVENTE
                if (request.ConRevolvente)
                {

                    using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                    {
                        db.Open();
                        db.CreateParameters(3);
                        db.AddParameters(0, "@numero", request.NumeroSocio);
                        db.AddParameters(1, "@id_tipo_persona", 1);
                        db.AddParameters(2, "@fecha", System.DateTime.Now.ToString("yyyyMMdd"));
                        db.ExecuteReader(System.Data.CommandType.StoredProcedure, "hape.dbo.SP_REVOLVENTE_CONSULTA_SOCIO");
                        while (db.DataReader.Read())
                        {
                            if (Convert.ToBoolean(db.DataReader["activa"].ToString()))
                            {
                                cuenta = new ResponseObtenerCuentasRetiro();
                                cuenta.ClabeCorresponsalias = string.IsNullOrEmpty(db.DataReader["clabe_corresponsalias"].ToString()) ? "" : db.DataReader["clabe_corresponsalias"].ToString();
                                cuenta.Saldo = Convert.ToDecimal(db.DataReader["disponible"].ToString());
                                cuenta.NombreCuenta = "PRESTAMO REVOLVENTE";
                                cuenta.Id = 10;
                                cuentas.Add(cuenta);
                            }
                        }
                    }
                }
            }
            catch (FaultException<ExceptionObtenerCuentasRetiro> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                ExceptionObtenerCuentasRetiro exceptionObtenerCuentasRetiro = new ExceptionObtenerCuentasRetiro();
                exceptionObtenerCuentasRetiro.Codigo = 100;
                exceptionObtenerCuentasRetiro.Mensaje = "Error desconocido, no se encuentra definido en el catalogo de cmv";
                throw new FaultException<ExceptionObtenerCuentasRetiro>(exceptionObtenerCuentasRetiro);
            }
            return cuentas;
        }
        public List<ResponseObtenerCuentasDepositoInterna> ObtenerCuentasDepositoInterna(RequestObtenerCuentasDepositoInterna request)
        {
            ResponseObtenerCuentasDepositoInterna cuenta = null;
            List<ResponseObtenerCuentasDepositoInterna> cuentas = new List<ResponseObtenerCuentasDepositoInterna>();
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "@tipo_cuenta_deposito_interna", request.TipoCuentaDepositoInterna);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_CUENTAS_DEPOSITO_INTERNA");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            cuenta = new ResponseObtenerCuentasDepositoInterna();
                            cuenta.IdCuentaInterna = db.DataReader["id_cuenta_interna"] == DBNull.Value ? 0 : Convert.ToInt64(db.DataReader["id_cuenta_interna"].ToString());
                            cuenta.TitularCuenta = db.DataReader["titular_cuenta"].ToString();
                            cuenta.ClabeCorresponsalias = db.DataReader["clabe_corresponsalias"].ToString();
                            cuenta.Alias = db.DataReader["alias"].ToString();
                            cuenta.MontoMaximo = db.DataReader["monto_maximo"] == DBNull.Value ? 0 : Convert.ToDecimal(db.DataReader["monto_maximo"].ToString());
                            cuenta.Correo = db.DataReader["correo"].ToString();
                            cuentas.Add(cuenta);
                        }
                        else
                        {
                            ExceptionObtenerCuentasDepositoInterna exceptionObtenerCuentasDepositoInterna = new ExceptionObtenerCuentasDepositoInterna();
                            exceptionObtenerCuentasDepositoInterna.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionObtenerCuentasDepositoInterna.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerCuentasDepositoInterna>(exceptionObtenerCuentasDepositoInterna);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return cuentas;
        }
        public List<ResponseObtenerCuentasDepositoExternas> ObtenerCuentasDepositoExternas(RequestObtenerCuentasDepositoExternas request)
        {
            ResponseObtenerCuentasDepositoExternas cuenta = null;
            List<ResponseObtenerCuentasDepositoExternas> cuentas = new List<ResponseObtenerCuentasDepositoExternas>();
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "@TipoCuentaDepositoExterna", request.TipoCuentaDepositoExterna);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_CUENTAS_DEPOSITO_EXTERNAS");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            if (db.DataReader.NextResult())
                            {
                                while (db.DataReader.Read())
                                {
                                    cuenta = new ResponseObtenerCuentasDepositoExternas();
                                    cuenta.IdCuentaExterna = db.DataReader["id_cuenta_externa"].ToString();
                                    cuenta.TipoCuentaExterna = (TipoCuentaExterna)Convert.ToInt16(db.DataReader["id_tipo_externa"].ToString());
                                    cuenta.ClabeSPEI = db.DataReader["clabe"].ToString();
                                    cuenta.TitularCuenta = db.DataReader["titular_cuenta"].ToString();
                                    cuenta.Alias = db.DataReader["alias"].ToString();
                                    cuenta.MontoMaximo = Convert.ToDecimal(db.DataReader["monto_maximo"].ToString());
                                    cuenta.Correo = db.DataReader["correo"].ToString();
                                    cuenta.IdBanco = Convert.ToInt16(db.DataReader["id_banco"].ToString());
                                    cuenta.Banco = db.DataReader["institucion"].ToString();
                                    cuenta.IdBancoBIN = db.DataReader["id_banco_bin"].ToString();
                                    cuentas.Add(cuenta);
                                }
                            }
                            else
                            {
                                ExceptionObtenerCuentasDepositoExternas exceptionObtenerCuentasDepositoExternas = new ExceptionObtenerCuentasDepositoExternas();
                                exceptionObtenerCuentasDepositoExternas.Codigo = 340;
                                exceptionObtenerCuentasDepositoExternas.Mensaje = "No existen cuentas";
                                throw new FaultException<ExceptionObtenerCuentasDepositoExternas>(exceptionObtenerCuentasDepositoExternas, "No existen cuenta", new FaultCode("340"));
                            }
                        }
                        else
                        {
                            ExceptionObtenerCuentasDepositoExternas exceptionObtenerCuentasDepositoExternas = new ExceptionObtenerCuentasDepositoExternas();
                            exceptionObtenerCuentasDepositoExternas.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionObtenerCuentasDepositoExternas.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerCuentasDepositoExternas>(exceptionObtenerCuentasDepositoExternas);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return cuentas;
        }

        #region Comprobantes de pago
        public ResponseObtenerComprobantePago ObtenerComprobantesPago(RequestObtenerComprobantePago request)
        {
            ResponseObtenerComprobantePago comprobante = new ResponseObtenerComprobantePago();
            comprobante.Comprobantes = new List<ComprobantePago>();
            try
            {


                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(5);
                    db.AddParameters(0, "@NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "@idTipoBusqueda", request.TipoBusquedaComprobante);
                    db.AddParameters(2, "@fechaInicio", request.FechaInicio);
                    db.AddParameters(3, "@fechaFin", request.FechaFin);
                    db.AddParameters(4, "@folioAutorizacion", request.FolioAutorizacion);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_COMPROBANTE_PAGO_INTERNO_EXTERNO");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            if (db.DataReader.NextResult())
                            {
                                while (db.DataReader.Read())
                                {
                                    ComprobantePago c = new ComprobantePago();
                                    c.IdComprobante = Convert.ToInt64(db.DataReader["id_comprobante"]);
                                    c.TipoTransferencia = (TipoTransferencia)Convert.ToInt16(db.DataReader["tipo_transferencia"].ToString());
                                    c.Celular = string.IsNullOrEmpty(db.DataReader["celular"].ToString()) ? string.Empty : db.DataReader["celular"].ToString();
                                    c.BancoDestino = db.DataReader["bancoDestino"].ToString();
                                    c.Clabe = db.DataReader["clabe"].ToString();
                                    c.Importe = Convert.ToDecimal(db.DataReader["importe"].ToString());
                                    c.Concepto = db.DataReader["concepto"].ToString();
                                    c.FechaAltaTransferencia = db.DataReader["fechaAltaTransferencia"].ToString();
                                    c.HoraAltaTransferencia = db.DataReader["horaAltaTransferencia"].ToString();
                                    c.FechaTransFerenciaProgramada = db.DataReader["fechaTransferenciaProgramada"].ToString();
                                    c.HoraTransferenciaProgramada = db.DataReader["horaTransferenciaProgramada"].ToString();
                                    c.FechaTransferenciaRealizada = db.DataReader["fechaTransferenciaRealizada"].ToString();
                                    c.HoraTransferenciaRealizada = db.DataReader["horaTransferenciaRealizada"].ToString();
                                    c.Folio = string.IsNullOrEmpty(db.DataReader["folio"].ToString()) ? 0 : Convert.ToInt64(db.DataReader["folio"]);
                                    c.Correo = db.DataReader["correo"].ToString();
                                    c.TitularCuentaDeposito = string.IsNullOrEmpty(db.DataReader["TitularCuentaDeposito"].ToString()) ? string.Empty : db.DataReader["TitularCuentaDeposito"].ToString();
                                    c.EstadoTransferencia = db.DataReader["estadoTransferencia"].ToString();
                                    c.EstatusTransferencia = (EstatusTransferencia)Convert.ToInt16(db.DataReader["idEstatusTransferecnia"].ToString());
                                    c.TitularCuentaRetiro = string.IsNullOrEmpty(db.DataReader["TitularCuentaRetiro"].ToString()) ? string.Empty : db.DataReader["TitularCuentaRetiro"].ToString();
                                    c.programdo = Convert.ToBoolean(db.DataReader["programado"]);
                                    comprobante.Comprobantes.Add(c);
                                }
                            }
                            else
                            {
                                ExceptionObtenerComprobantePago exceptionObtenerCuentasDepositoExternas = new ExceptionObtenerComprobantePago();
                                exceptionObtenerCuentasDepositoExternas.Codigo = 353;
                                exceptionObtenerCuentasDepositoExternas.Mensaje = "No existen comprobantes";
                                throw new FaultException<ExceptionObtenerComprobantePago>(exceptionObtenerCuentasDepositoExternas);
                            }
                        }
                        else
                        {
                            ExceptionObtenerComprobantePago exceptionObtenerCuentasDepositoExternas = new ExceptionObtenerComprobantePago();
                            exceptionObtenerCuentasDepositoExternas.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionObtenerCuentasDepositoExternas.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerComprobantePago>(exceptionObtenerCuentasDepositoExternas);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return comprobante;
        }

        public List<ResponseObtenerComprobantePagoCEP> ObtenerComprobantesPagoCEP(RequestObtenerComprobantePagoCEP request)
        {
            List<ResponseObtenerComprobantePagoCEP> comprobantes = new List<ResponseObtenerComprobantePagoCEP>();
            ResponseObtenerComprobantePagoCEP c = new ResponseObtenerComprobantePagoCEP();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(7);
                    db.AddParameters(0, "@NumeroSocio", request.NumeroSocio);
                    db.AddParameters(1, "@TipoBusquedaComprobante", request.TipoBusquedaComprobante);
                    db.AddParameters(2, "@FechaInicio", request.FechaInicio);
                    db.AddParameters(3, "@FechaFin", request.FechaFin);
                    db.AddParameters(4, "@TipoOrigen", request.TipoOrigen);
                    db.AddParameters(5, "@TipoTransferenciaExterna", request.TipoTransferenciaExterna);
                    db.AddParameters(6, "@folioAutorizacion", request.FolioAutorizacion);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_COMPROBANTES_PAGO_CEP");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            if (db.DataReader.NextResult())
                            {
                                while (db.DataReader.Read())
                                {
                                    c.IdTransferenciaCMV = db.DataReader["IdTransferenciaCMV"] == DBNull.Value ? "" : db.DataReader["IdTransferenciaCMV"].ToString();
                                    c.BancoReceptor = string.IsNullOrEmpty(db.DataReader["BancoReceptor"].ToString()) ? string.Empty : db.DataReader["BancoReceptor"].ToString();
                                    c.BancoEmisor = string.IsNullOrEmpty(db.DataReader["BancoEmisor"].ToString()) ? string.Empty : db.DataReader["BancoEmisor"].ToString();
                                    c.ClableSPEIRetiro = string.IsNullOrEmpty(db.DataReader["ClableSPEIRetiro"].ToString()) ? string.Empty : db.DataReader["ClableSPEIRetiro"].ToString();
                                    c.ClaveRastreo = string.IsNullOrEmpty(db.DataReader["ClaveRastreo"].ToString()) ? string.Empty : db.DataReader["ClaveRastreo"].ToString();
                                    c.ConceptoPago = string.IsNullOrEmpty(db.DataReader["ConceptoPago"].ToString()) ? string.Empty : db.DataReader["ConceptoPago"].ToString();
                                    c.FechaAutorizacion = db.DataReader["FechaAutorizacion"].ToString();
                                    c.FechaProgramada = db.DataReader["FechaProgramada"].ToString();
                                    c.FechaTransacion = db.DataReader["FechaTransacion"].ToString();
                                    c.HoraProgramada = db.DataReader["HoraProgramada"].ToString();
                                    c.HoraTransaccion = db.DataReader["HoraTransaccion"].ToString();
                                    c.IdComprantePagoCEP = db.DataReader["IdComprantePagoCEP"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["IdComprantePagoCEP"].ToString());
                                    c.NombreEmisor = string.IsNullOrEmpty(db.DataReader["NombreEmisor"].ToString()) ? string.Empty : db.DataReader["NombreEmisor"].ToString();
                                    c.Plazo = db.DataReader["Plazo"].ToString();
                                    c.Programado = Convert.ToBoolean(db.DataReader["Programado"]);


                                    c.ReferenciaNumerica = string.IsNullOrEmpty(db.DataReader["ReferenciaNumerica"].ToString()) ? string.Empty : db.DataReader["ReferenciaNumerica"].ToString();
                                    c.TitularCuenta = string.IsNullOrEmpty(db.DataReader["TitularCuenta"].ToString()) ? string.Empty : db.DataReader["TitularCuenta"].ToString();

                                    comprobantes.Add(c);
                                }
                            }
                            else
                            {
                                ExceptionObtenerComprobantePagoCEP exception = new ExceptionObtenerComprobantePagoCEP();
                                exception.Codigo = 353;
                                exception.Mensaje = "No existen comprobantes";
                                throw new FaultException<ExceptionObtenerComprobantePagoCEP>(exception);
                            }
                        }
                        else
                        {
                            ExceptionObtenerComprobantePagoCEP exception = new ExceptionObtenerComprobantePagoCEP();
                            exception.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exception.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerComprobantePagoCEP>(exception);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return comprobantes;
        }

        public ResponseObtenerComprobantePagoPDF ObtenerComprobantesPagoPDF(RequestObtenerComprobantePagoPDF request)
        {
            ResponseObtenerComprobantePagoPDF responseObtenerComprobantePagoPDF = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(6);
                    db.AddParameters(0, "@NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "@idTipoBusqueda", TipoBusquedaComprobante.Por_movimiento);
                    db.AddParameters(2, "@fechaInicio", System.DateTime.Now);
                    db.AddParameters(3, "@fechaFin", System.DateTime.Now);
                    db.AddParameters(4, "@folioAutorizacion", request.FolioAutorizacion);
                    db.AddParameters(5, "@tipoTransferencia", request.TipoTransferencia);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_COMPROBANTE_PAGO_INTERNO_EXTERNO");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            if (db.DataReader.NextResult())
                            {
                                if (db.DataReader.Read())
                                {
                                    responseObtenerComprobantePagoPDF = new ResponseObtenerComprobantePagoPDF();
                                    ComprobantePago c = new ComprobantePago();
                                    c.IdComprobante = Convert.ToInt64(db.DataReader["id_comprobante"]);
                                    c.TipoTransferencia = (TipoTransferencia)Convert.ToInt16(db.DataReader["tipo_transferencia"].ToString());
                                    c.Celular = string.IsNullOrEmpty(db.DataReader["celular"].ToString()) ? string.Empty : db.DataReader["celular"].ToString();
                                    c.BancoDestino = db.DataReader["bancoDestino"].ToString();
                                    c.Clabe = db.DataReader["clabe"].ToString();
                                    c.ClabeDeposito = db.DataReader["clabeDeposito"].ToString();
                                    c.ClabeRetiro = db.DataReader["clabeRetiro"].ToString();
                                    c.Importe = Convert.ToDecimal(db.DataReader["importe"].ToString());
                                    c.Concepto = db.DataReader["concepto"].ToString();
                                    c.FechaAltaTransferencia = db.DataReader["fechaAltaTransferencia"].ToString();
                                    c.HoraAltaTransferencia = db.DataReader["horaAltaTransferencia"].ToString();
                                    c.FechaTransFerenciaProgramada = db.DataReader["fechaTransferenciaProgramada"].ToString();
                                    c.HoraTransferenciaProgramada = db.DataReader["horaTransferenciaProgramada"].ToString();
                                    c.FechaTransferenciaRealizada = db.DataReader["fechaTransferenciaRealizada"].ToString();
                                    c.HoraTransferenciaRealizada = db.DataReader["horaTransferenciaRealizada"].ToString();
                                    c.Folio = string.IsNullOrEmpty(db.DataReader["folio"].ToString()) ? 0 : Convert.ToInt64(db.DataReader["folio"]);
                                    c.Correo = db.DataReader["correo"].ToString();
                                    c.TitularCuentaDeposito = string.IsNullOrEmpty(db.DataReader["TitularCuentaDeposito"].ToString()) ? string.Empty : db.DataReader["TitularCuentaDeposito"].ToString();
                                    c.EstadoTransferencia = db.DataReader["estadoTransferencia"].ToString();
                                    c.EstatusTransferencia = (EstatusTransferencia)Convert.ToInt16(db.DataReader["idEstatusTransferecnia"].ToString());
                                    c.TitularCuentaRetiro = string.IsNullOrEmpty(db.DataReader["TitularCuentaRetiro"].ToString()) ? string.Empty : db.DataReader["TitularCuentaRetiro"].ToString();
                                    c.programdo = Convert.ToBoolean(db.DataReader["programado"]);
                                    c.DescripcionComprobante = db.DataReader["descComprobantePago"].ToString();
                                    responseObtenerComprobantePagoPDF.Archivo = Reportes.ComprobanteDePago(c);
                                }
                            }
                            else
                            {
                                ExceptionObtenerComprobantePagoPDF exceptionObtenerCuentasDepositoExternas = new ExceptionObtenerComprobantePagoPDF();
                                exceptionObtenerCuentasDepositoExternas.Codigo = 353;
                                exceptionObtenerCuentasDepositoExternas.Mensaje = "No existn comprobante";
                                throw new FaultException<ExceptionObtenerComprobantePagoPDF>(exceptionObtenerCuentasDepositoExternas);
                            }
                        }
                        else
                        {
                            ExceptionObtenerComprobantePagoPDF exceptionObtenerCuentasDepositoExternas = new ExceptionObtenerComprobantePagoPDF();
                            exceptionObtenerCuentasDepositoExternas.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionObtenerCuentasDepositoExternas.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerComprobantePagoPDF>(exceptionObtenerCuentasDepositoExternas);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return responseObtenerComprobantePagoPDF;
        }

        public ResponseObtenerComprobantePagoServicios ObtenerComprobantesPagoServicios(RequestObtenerComprobantePagoServicios request)
        {
            ResponseObtenerComprobantePagoServicios response = new ResponseObtenerComprobantePagoServicios();
            ComprobantePagoServicio c = new ComprobantePagoServicio();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(6);
                    db.AddParameters(0, "@NumeroSocio", request.NumeroSocio);
                    db.AddParameters(1, "@TipoBusquedaComprobante", request.TipoBusquedaComprobante);
                    db.AddParameters(2, "@FechaInicio", request.FechaInicio);
                    db.AddParameters(3, "@FechaFin", request.FechaFin);
                    db.AddParameters(4, "@TipoOrigen", request.TipoOrigen);
                    db.AddParameters(5, "@folioAutorizacion", request.FolioAutorizacion);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_COMPROBANTES_PAGO_SERVICIOS");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Comprobantes = new List<ComprobantePagoServicio>();
                            if (db.DataReader.NextResult())
                            {
                                while (db.DataReader.Read())
                                {
                                    c.IdComprobante = db.DataReader["IdComprobante"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["IdComprobante"].ToString());
                                    c.ClabeRetiro = string.IsNullOrEmpty(db.DataReader["ClabeRetiro"].ToString()) ? string.Empty : db.DataReader["ClabeRetiro"].ToString();
                                    c.HoraTransaccion = string.IsNullOrEmpty(db.DataReader["HoraTransaccion"].ToString()) ? string.Empty : db.DataReader["HoraTransaccion"].ToString();
                                    c.FechaTransacion = string.IsNullOrEmpty(db.DataReader["FechaTransacion"].ToString()) ? string.Empty : db.DataReader["FechaTransacion"].ToString();
                                    c.HoraAutorizacion = string.IsNullOrEmpty(db.DataReader["HoraAutorizacion"].ToString()) ? string.Empty : db.DataReader["HoraAutorizacion"].ToString();
                                    c.FechaAutorizacion = string.IsNullOrEmpty(db.DataReader["FechaAutorizacion"].ToString()) ? string.Empty : db.DataReader["FechaAutorizacion"].ToString();
                                    c.Importe = string.IsNullOrEmpty(db.DataReader["Importe"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["Importe"].ToString());
                                    c.Comision = string.IsNullOrEmpty(db.DataReader["Comision"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["Comision"].ToString());
                                    c.Referencia = db.DataReader["Referencia"].ToString();
                                    c.FolioAutorizacion = db.DataReader["FolioAutorizacion"].ToString();
                                    c.NumAutorizacion = db.DataReader["NumAutorizacion"].ToString();
                                    c.DescripcionProducto = db.DataReader["DescripcionProducto"].ToString();
                                    c.IdProducto = db.DataReader["IdProducto"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["IdProducto"].ToString());
                                    c.IdTipoFront = db.DataReader["IdTipoFront"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["IdTipoFront"].ToString());
                                    c.DescripcionServicio = string.IsNullOrEmpty(db.DataReader["DescripcionServicio"].ToString()) ? string.Empty : db.DataReader["DescripcionServicio"].ToString();
                                    c.IdServicio = db.DataReader["IdServicio"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["IdServicio"].ToString());
                                    c.Referencia = db.DataReader["Referencia"].ToString();
                                    c.Telefono = db.DataReader["Telefono"].ToString();
                                    c.EstadoTransferencia = db.DataReader["EstadoTransferencia"].ToString();
                                    c.EstatusTransferencia = string.IsNullOrEmpty(db.DataReader["EstatusTransferencia"].ToString()) ? EstatusTransferencia.Ninguno : (EstatusTransferencia)Convert.ToInt32((db.DataReader["EstatusTransferencia"].ToString()));
                                    response.Comprobantes.Add(c);
                                }
                            }
                            else
                            {
                                ExceptionObtenerComprobantePagoCEP exception = new ExceptionObtenerComprobantePagoCEP();
                                exception.Codigo = 353;
                                exception.Mensaje = "No existen comprobantes";
                                throw new FaultException<ExceptionObtenerComprobantePagoCEP>(exception);
                            }
                        }
                        else
                        {
                            ExceptionObtenerComprobantePagoCEP exception = new ExceptionObtenerComprobantePagoCEP();
                            exception.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exception.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerComprobantePagoCEP>(exception);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public ResponseObtenerComprobantePagoServicioPDF ObtenerComprobantesPagoServicioPDF(RequestObtenerComprobantePagoServicioPDF request)
        {
            ResponseObtenerComprobantePagoServicioPDF response = new ResponseObtenerComprobantePagoServicioPDF();
            ComprobantePagoServicio c = new ComprobantePagoServicio();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(6);
                    db.AddParameters(0, "@NumeroSocio", request.NumeroSocio);
                    db.AddParameters(1, "@TipoBusquedaComprobante", TipoBusquedaComprobante.Por_movimiento);
                    db.AddParameters(2, "@FechaInicio", System.DateTime.Now);
                    db.AddParameters(3, "@FechaFin", System.DateTime.Now);
                    db.AddParameters(4, "@TipoOrigen", request.TipoOrigen);
                    db.AddParameters(5, "@folioAutorizacion", request.FolioAutorizacion);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_COMPROBANTES_PAGO_SERVICIOS");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            if (db.DataReader.NextResult())
                            {
                                if (db.DataReader.Read())
                                {
                                    c.IdComprobante = db.DataReader["IdComprobante"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["IdComprobante"].ToString());
                                    c.ClabeRetiro = string.IsNullOrEmpty(db.DataReader["ClabeRetiro"].ToString()) ? string.Empty : db.DataReader["ClabeRetiro"].ToString();
                                    c.HoraTransaccion = string.IsNullOrEmpty(db.DataReader["HoraTransaccion"].ToString()) ? string.Empty : db.DataReader["HoraTransaccion"].ToString();
                                    c.FechaTransacion = string.IsNullOrEmpty(db.DataReader["FechaTransacion"].ToString()) ? string.Empty : db.DataReader["FechaTransacion"].ToString();
                                    c.HoraAutorizacion = string.IsNullOrEmpty(db.DataReader["HoraAutorizacion"].ToString()) ? string.Empty : db.DataReader["HoraAutorizacion"].ToString();
                                    c.FechaAutorizacion = string.IsNullOrEmpty(db.DataReader["FechaAutorizacion"].ToString()) ? string.Empty : db.DataReader["FechaAutorizacion"].ToString();
                                    c.Importe = string.IsNullOrEmpty(db.DataReader["Importe"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["Importe"].ToString());
                                    c.Comision = string.IsNullOrEmpty(db.DataReader["Comision"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["Comision"].ToString());
                                    c.Referencia = db.DataReader["Referencia"].ToString();
                                    c.FolioAutorizacion = db.DataReader["FolioAutorizacion"].ToString();
                                    c.NumAutorizacion = db.DataReader["NumAutorizacion"].ToString();
                                    c.DescripcionProducto = db.DataReader["DescripcionProducto"].ToString();
                                    c.IdProducto = db.DataReader["IdProducto"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["IdProducto"].ToString());
                                    c.IdTipoFront = db.DataReader["IdTipoFront"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["IdTipoFront"].ToString());
                                    c.DescripcionServicio = string.IsNullOrEmpty(db.DataReader["DescripcionServicio"].ToString()) ? string.Empty : db.DataReader["DescripcionServicio"].ToString();
                                    c.IdServicio = db.DataReader["IdServicio"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["IdServicio"].ToString());
                                    c.Referencia = db.DataReader["Referencia"].ToString();
                                    c.Telefono = db.DataReader["Telefono"].ToString();
                                    c.EstadoTransferencia = db.DataReader["EstadoTransferencia"].ToString();
                                    c.EstatusTransferencia = string.IsNullOrEmpty(db.DataReader["EstatusTransferencia"].ToString()) ? EstatusTransferencia.Ninguno : (EstatusTransferencia)Convert.ToInt32((db.DataReader["EstatusTransferencia"].ToString()));
                                    c.leyenda = db.DataReader["leyendaProducto"].ToString();
                                    response.Archivo = Reportes.ComprobantesPagoServicioPDF(c);
                                }
                            }

                        }
                        else
                        {
                            ExceptionObtenerComprobantePagoServicioPDF exception = new ExceptionObtenerComprobantePagoServicioPDF();
                            exception.Codigo = 353;
                            exception.Mensaje = "No existen comprobantes";
                            throw new FaultException<ExceptionObtenerComprobantePagoServicioPDF>(exception);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
        #endregion

        #region OBTENER PROXIMOS PAGOS PROGRAMADOS
        public ResponseObtenerProximasTransferenciasProgramadas ObtenerProximasTransferenciasProgramadas(RequestObtenerProximasTransferenciasProgramadas request)
        {
            ResponseObtenerProximasTransferenciasProgramadas response = null;

            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "@tipoTransferencia", TipoTransferencia.todos);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_TRANSFERENCIAS_PAGOS_PROGRAMADOS");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response = new ResponseObtenerProximasTransferenciasProgramadas();
                            response.ProximosTransferencias = new List<ProximasTransferenciasProgramadas>();
                            if (db.DataReader.NextResult())
                            {

                                while (db.DataReader.Read())
                                {
                                    ProximasTransferenciasProgramadas p = new ProximasTransferenciasProgramadas();
                                    p.TipoTransferencia = (TipoTransferencia)Convert.ToInt16(db.DataReader["tipo_transferencia"].ToString());
                                    p.Alias = db.DataReader["concepto"].ToString();
                                    p.Importe = Convert.ToDecimal(db.DataReader["importe"].ToString());
                                    p.FechaProgramada = db.DataReader["fechaTransferenciaProgramada"].ToString();
                                    response.ProximosTransferencias.Add(p);
                                }
                            }
                            else
                            {
                                ExceptionObtenerProximasTransferenciasProgramadas exceptionObtenerCuentasDepositoExternas = new ExceptionObtenerProximasTransferenciasProgramadas();
                                exceptionObtenerCuentasDepositoExternas.Codigo = 388;
                                exceptionObtenerCuentasDepositoExternas.Mensaje = "No existen Transferencias programadas";
                                throw new FaultException<ExceptionObtenerProximasTransferenciasProgramadas>(exceptionObtenerCuentasDepositoExternas, "No existen Transferencias programadas", new FaultCode("388"));
                            }
                        }
                        else
                        {
                            ExceptionObtenerProximasTransferenciasProgramadas exceptionObtenerCuentasDepositoExternas = new ExceptionObtenerProximasTransferenciasProgramadas();
                            exceptionObtenerCuentasDepositoExternas.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionObtenerCuentasDepositoExternas.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerProximasTransferenciasProgramadas>(exceptionObtenerCuentasDepositoExternas);
                        }
                    }
                }
                if (response != null)
                {
                    if (response.ProximosTransferencias != null)
                    {
                        response.ProximosTransferencias = response.ProximosTransferencias.FindAll(x => x.TipoTransferencia == TipoTransferencia.TrasferenciasInternas);
                    }
                    if (response.ProximosTransferencias.Count == 0)
                    {
                        ExceptionObtenerProximasTransferenciasProgramadas exceptionObtenerCuentasDepositoExternas = new ExceptionObtenerProximasTransferenciasProgramadas();
                        exceptionObtenerCuentasDepositoExternas.Codigo = 388;
                        exceptionObtenerCuentasDepositoExternas.Mensaje = "No existen Transferencias programadas";
                        throw new FaultException<ExceptionObtenerProximasTransferenciasProgramadas>(exceptionObtenerCuentasDepositoExternas, "No existen Transferencias programadas", new FaultCode("388"));
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }


        public ResponseObtenerProximosPagosProgramados ObtenerProximosPagosProgramadas(RequestObtenerProximosPagosProgramados request)
        {
            ResponseObtenerProximosPagosProgramados response = null;

            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "@tipoTransferencia", TipoTransferencia.todos);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_TRANSFERENCIAS_PAGOS_PROGRAMADOS");
                    if (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response = new ResponseObtenerProximosPagosProgramados();
                            response.ProximosPagos = new List<ProximasTransferenciasProgramadas>();
                            if (db.DataReader.NextResult())
                            {

                                while (db.DataReader.Read())
                                {
                                    ProximasTransferenciasProgramadas p = new ProximasTransferenciasProgramadas();
                                    p.TipoTransferencia = (TipoTransferencia)Convert.ToInt16(db.DataReader["tipo_transferencia"].ToString());
                                    p.Alias = db.DataReader["concepto"].ToString();
                                    p.Importe = Convert.ToDecimal(db.DataReader["importe"].ToString());
                                    p.FechaProgramada = db.DataReader["fechaTransferenciaProgramada"].ToString();
                                    response.ProximosPagos.Add(p);
                                }
                            }
                            else
                            {
                                ExceptionObtenerProximosPagosProgramadas exceptionObtenerProximosPagosProgramadas = new ExceptionObtenerProximosPagosProgramadas();
                                exceptionObtenerProximosPagosProgramadas.Codigo = 389;
                                exceptionObtenerProximosPagosProgramadas.Mensaje = "No existen pagos programados";
                                throw new FaultException<ExceptionObtenerProximosPagosProgramadas>(exceptionObtenerProximosPagosProgramadas, "No existen pagos programados", new FaultCode("389"));
                            }
                        }
                        else
                        {
                            ExceptionObtenerProximosPagosProgramadas exceptionObtenerProximosPagosProgramadas = new ExceptionObtenerProximosPagosProgramadas();
                            exceptionObtenerProximosPagosProgramadas.Codigo = Convert.ToInt16(db.DataReader["estatus"].ToString());
                            exceptionObtenerProximosPagosProgramadas.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionObtenerProximosPagosProgramadas>(exceptionObtenerProximosPagosProgramadas);
                        }
                    }
                }
                if (response != null)
                {
                    if (response.ProximosPagos != null)
                    {
                        response.ProximosPagos = response.ProximosPagos.FindAll(x => x.TipoTransferencia == TipoTransferencia.PagoPrestamos);
                    }

                    if (response.ProximosPagos.Count == 0)
                    {
                        ExceptionObtenerProximosPagosProgramadas exceptionObtenerProximosPagosProgramadas = new ExceptionObtenerProximosPagosProgramadas();
                        exceptionObtenerProximosPagosProgramadas.Codigo = 389;
                        exceptionObtenerProximosPagosProgramadas.Mensaje = "No existen pagos programados";
                        throw new FaultException<ExceptionObtenerProximosPagosProgramadas>(exceptionObtenerProximosPagosProgramadas, "No existen pagos programados", new FaultCode("389"));
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

        #endregion

        #region Limites Transferencias

        public ResponseValidaLimitesTransferencias ValidaLimitesTransferencias(RequestValidaLimitesTransferencias request)
        {
            ResponseValidaLimitesTransferencias response = new ResponseValidaLimitesTransferencias();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@id_limite_transferencia", request.Tipo);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_VALIDAR_LIMITES_TRANSFERENCIAS");
                    if (db.DataReader.Read())
                    {
                        response.Estatus = Convert.ToBoolean(db.DataReader["valido"]);
                        response.Mensaje = db.DataReader["mensaje"].ToString();
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return response;
        }

        #endregion


    }
}
