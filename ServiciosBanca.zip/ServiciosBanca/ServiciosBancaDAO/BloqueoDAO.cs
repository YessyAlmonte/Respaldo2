﻿using AccesoDatos;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaDAO
{
    public class BloqueoDAO
    {
        private DBManager db = null;
        public ResponseBloqueoTemporal BloqueoTemporal(RequestBloqueoTemporal request)
        {
            ResponseBloqueoTemporal response = new ResponseBloqueoTemporal();
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "NUMERO", request.NumeroSocio);
                    db.AddParameters(1, "id_motivo_bloqueo", request.IdMotivoBloqueo);
                    db.AddParameters(2, "tipo_origen", request.TipoOrigen);
                    //db.AddParameters(3, "OTP", request.OTP);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_BLOQUEO_TEMPORAL");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                        }
                        else
                        {
                            ExceptionBloqueoTemporal exceptionBloqueoTemporal = new ExceptionBloqueoTemporal();
                            exceptionBloqueoTemporal.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionBloqueoTemporal.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionBloqueoTemporal>(exceptionBloqueoTemporal, exceptionBloqueoTemporal.Mensaje);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }
        public ResponseBloqueoTemporalDataBanking BloqueoTemporalDataBanking(RequestBloqueoTemporalDataBanking request)
        {
            ResponseBloqueoTemporalDataBanking response = new ResponseBloqueoTemporalDataBanking();
            try
            {
    
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@numero_socio", request.NumeroSocio);
                    db.AddParameters(1, "@id_motivo_bloqueo", TipoBloqueo.Bloqueo_temporal_desde_callcenter);
                    
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_BLOQUEO_DATABANKING");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                        }
                        else
                        {
                            ExceptionBloqueoTemporalDataBanking exceptionBloqueoTemporal = new ExceptionBloqueoTemporalDataBanking();
                            exceptionBloqueoTemporal.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionBloqueoTemporal.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionBloqueoTemporalDataBanking>(exceptionBloqueoTemporal, "Reason: Testing the Fault contract");
                        }
                    }
                }
            } catch (Exception ex)
            {
                throw ex;
            }

            return response;
        }

        public ResponseDesbloqueoCuentaBanca DesbloqueoCuentaBanca(RequestDesbloqueoCuentaBanca request)
        {
            ResponseDesbloqueoCuentaBanca response = new ResponseDesbloqueoCuentaBanca();
            try
            {

                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(2);
                    db.AddParameters(0, "@numero_socio", request.NumeroSocio);
                    db.AddParameters(1, "@id_motivo_bloqueo", TipoBloqueo.Desbloqueado);
                    db.AddParameters(2, "@tipoOrigen", request.TipoOrigen);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_DESBLOQUEO_DATABANKING");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            response.Estatus = true;
                            //response.Notificacion = Utilerias.ObtenerNotificacion(db);
                        }
                        else
                        {
                            ExceptionDesbloqueoCuentaBanca exceptionDesbloqueoCuentaBanca = new ExceptionDesbloqueoCuentaBanca();
                            exceptionDesbloqueoCuentaBanca.Codigo = db.DataReader["estatus"] == DBNull.Value ? 0 : Convert.ToInt32(db.DataReader["estatus"]);
                            exceptionDesbloqueoCuentaBanca.Mensaje = db.DataReader["mensaje"].ToString();
                            throw new FaultException<ExceptionDesbloqueoCuentaBanca>(exceptionDesbloqueoCuentaBanca, "Reason: Testing the Fault contract");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return response;
        }

        
    }

}
