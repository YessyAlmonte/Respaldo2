﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using BusCrypto;
using ServiciosBancaDAO;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;
using ServiciosBancaEntidades.Autenticacion;
//using log4net;
using ServiciosBancaCMV.Autenticacion;

namespace ServiciosBancaCMV.Sesion
{
    [CustomBehavior]
    public class Sesion : ServiceLog, ISesion
    {
        //private readonly ILog log;
        public Sesion() : base()
        {
            //Get logger for Service1
            //log = LogManager.GetLogger(typeof(Sesion));
        }

        public ResponseIniciarSesion AutenticarSocio(RequestIniciarSesion request)
        {
            try
            {                
                request.Contrasena = AgenteConecta.CifrarInformacion(request.Contrasena);
                Bitacora<RequestIniciarSesion> b = new Bitacora<RequestIniciarSesion>(request.NumeroSocio.ToString(), request);
                return new SesionDAO().AutenticarSocio(request);
            }
            catch (FaultException<ExceptionIniciarSesion> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {              
                ExceptionIniciarSesion exceptionIniciarSesion = new ExceptionIniciarSesion();
                exceptionIniciarSesion.Codigo = 1000;
                exceptionIniciarSesion.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionIniciarSesion.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                //Bitacora<ExceptionIniciarSesion> Bex = new Bitacora<ExceptionIniciarSesion>(request.NumeroSocio.ToString(), exceptionIniciarSesion, request.NumeroSocio.ToString());
                //new Logg().Error(SerializerManager<Bitacora<ExceptionIniciarSesion>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionIniciarSesion>(exceptionIniciarSesion);
            }
        }

        /// <summary>
        /// Se agregar el motivo bloqueo del socio para que prosa pueda identificar si se trata de un ingreso nuevo
        /// o si el socio esta intentado entrar a parti de un bloqueo 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ResponseValidaNumero ValidaNumero(RequestValidaNumero request)
        {
            try
            {
                return new SesionDAO().ValidaNumero(request);
            }
            catch (FaultException<ExceptionValidaNumero> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionValidaNumero exceptionValidaNumero = new ExceptionValidaNumero();
                exceptionValidaNumero.Codigo = 1000;
                exceptionValidaNumero.Descripcion = Utilerias.ExcepcionDebug(ex);
                
                exceptionValidaNumero.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionValidaNumero>(exceptionValidaNumero);
            }
        }
    }
}
