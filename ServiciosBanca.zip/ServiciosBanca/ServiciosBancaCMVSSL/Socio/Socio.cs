﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ServiciosBancaDAO;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils.Logg;
using ServiciosBancaEntidades;
using ServiciosBancaUtils;
using BusCrypto;
using System.IO;
using ServiciosBancaEntidades.Autenticacion;

namespace ServiciosBancaCMV.Socio
{
    [CustomBehavior]
    public class Socio : ISocio
    {
        #region PROCESOS BANCA 
        public ResponseActualizarEstatus ActualizarEstatus(RequestActualizarEstatus request)
        {
            try
            {
                //Bitacora<RequestActualizarEstatus> b = new Bitacora<RequestActualizarEstatus>(request.NumeroSocio.ToString(), request);
                //new Logg().Info(SerializerManager<Bitacora<RequestActualizarEstatus>>.SerealizarObjtecToString(b));
                               
                return new SocioDAO().ActualizarEstatus(request);
            }
            catch (FaultException<ExceptionActualizarEstatus> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionActualizarEstatus exceptionActualizarEstatus = new ExceptionActualizarEstatus();
                exceptionActualizarEstatus.Codigo = 1000;
                exceptionActualizarEstatus.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionActualizarEstatus.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionActualizarEstatus> Bex = new Bitacora<ExceptionActualizarEstatus>(request.NumeroSocio.ToString(), exceptionActualizarEstatus, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionActualizarEstatus>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionActualizarEstatus>(exceptionActualizarEstatus);
            }

        }
        
        public ResponseActivarBanca ActivarBanca(RequestActivarBanca request)
        {
            try
            {
                string errorContraseña= string.Empty;
                if (!Utilerias.ValidaEstructuraContrasena(request.NuevaContrasena,ref errorContraseña , request.NumeroSocio))
                {
                    ExceptionActivarBanca exceptionObtenerInformacionSocio = new ExceptionActivarBanca();
                    exceptionObtenerInformacionSocio.Codigo = 317;
                    exceptionObtenerInformacionSocio.Descripcion = "Message :";
                    exceptionObtenerInformacionSocio.Mensaje = errorContraseña;//"Las contraseña no cumple con políticacs de seguridad";
                    throw new FaultException<ExceptionActivarBanca>(exceptionObtenerInformacionSocio);
                }
                else
                {
                    request.NuevaContrasena = AgenteConecta.CifrarInformacion(request.NuevaContrasena);
                    request.ContrasenaConfirmada = AgenteConecta.CifrarInformacion(request.ContrasenaConfirmada);
                    request.Respuesta = AgenteConecta.CifrarInformacion(request.Respuesta.Replace(" ",""));
                    Bitacora<RequestActivarBanca> b = new Bitacora<RequestActivarBanca>(request.NumeroSocio.ToString(), request);
                    return new SocioDAO().ActivarBanca(request);
                }
            }
            catch (FaultException<ExceptionActivarBanca> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {

                ExceptionActivarBanca exceptionObtenerInformacionSocio = new ExceptionActivarBanca();
                exceptionObtenerInformacionSocio.Codigo = 1000;
                exceptionObtenerInformacionSocio.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerInformacionSocio.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionActivarBanca> Bex = new Bitacora<ExceptionActivarBanca>(request.NumeroSocio.ToString(), exceptionObtenerInformacionSocio, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionActivarBanca>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionActivarBanca>(exceptionObtenerInformacionSocio);
            }
        }

        public ResponseObtenerInformacionSocio ObtenerInformacionSocio(RequestObtenerInformacionSocio request)
        {
            try
            {                                              

                Bitacora<RequestObtenerInformacionSocio> b = new Bitacora<RequestObtenerInformacionSocio>(request.NumeroSocio.ToString() , request, "responseObtenerInformacionSocio");
                new Logg().Info(SerializerManager<Bitacora<RequestObtenerInformacionSocio>>.SerealizarObjtecToString(b));             
                return new SocioDAO().ObtenerInformacionSocio(request);
            }
            catch (FaultException<ExceptionObtenerInformacionSocio> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerInformacionSocio exceptionObtenerInformacionSocio = new ExceptionObtenerInformacionSocio();
                exceptionObtenerInformacionSocio.Codigo = 1000;
                exceptionObtenerInformacionSocio.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerInformacionSocio.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerInformacionSocio> Bex = new Bitacora<ExceptionObtenerInformacionSocio>(request.NumeroSocio.ToString(), exceptionObtenerInformacionSocio, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerInformacionSocio>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerInformacionSocio>(exceptionObtenerInformacionSocio);
            }
        }

        public ResponseRegistrarSocio RegistrarSocio(RequestRegistrarSocio request)
        {
            try
            {
               
                Bitacora<RequestRegistrarSocio> b = new Bitacora<RequestRegistrarSocio>(request.NumeroSocio.ToString(), request);
                new Logg().Info(SerializerManager<Bitacora<RequestRegistrarSocio>>.SerealizarObjtecToString(b));
                return new SocioDAO().RegistrarSocio(request);
            }
            catch (FaultException<ExceptionRegistrarSocio> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionRegistrarSocio exceptionRegistrarSocio = new ExceptionRegistrarSocio();
                exceptionRegistrarSocio.Codigo = 1000;
                exceptionRegistrarSocio.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionRegistrarSocio.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionRegistrarSocio>(exceptionRegistrarSocio);
            }
        }

        public ResponseObtenerNombrePorClabe ObtenerNombrePorClabe(RequestObtenerNombrePorClabe request)
        {
            try
            {
                return new SocioDAO().ObtenerNombrePorClabe(request);
            }
            catch (FaultException<ExceptionObtenerNombrePorClabe> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionGenerarContrasenaTemp exceptionGenerarContrasenaTemp = new ExceptionGenerarContrasenaTemp();
                exceptionGenerarContrasenaTemp.Codigo = 1000;
                exceptionGenerarContrasenaTemp.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionGenerarContrasenaTemp.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionGenerarContrasenaTemp>(exceptionGenerarContrasenaTemp);
            }
        }

        public ResponseActualizaPreguntaRespuestaSecreta ActualizaPreguntaRespuestaSecreta(RequestActualizaPreguntaRespuestaSecreta request)
        {

            try
            {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                request.Respuesta = AgenteConecta.CifrarInformacion(request.Respuesta.Replace(" ",""));
                return new SocioDAO().ActualizaPreguntaRespuestaSecreta(request);
            }
            catch (FaultException<ExceptionActualizaPreguntaRespuestaSecreta> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionCambiarContrasena exceptionValidaOTP = new ExceptionCambiarContrasena();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                throw new FaultException<ExceptionCambiarContrasena>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                ExceptionGenerarContrasenaTemp exceptionGenerarContrasenaTemp = new ExceptionGenerarContrasenaTemp();
                exceptionGenerarContrasenaTemp.Codigo = 1000;
                exceptionGenerarContrasenaTemp.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionGenerarContrasenaTemp.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionGenerarContrasenaTemp> Bex = new Bitacora<ExceptionGenerarContrasenaTemp>(request.NumeroSocio.ToString(), exceptionGenerarContrasenaTemp, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionGenerarContrasenaTemp>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionGenerarContrasenaTemp>(exceptionGenerarContrasenaTemp);
            }
        }

        public ResponseActualizarImagenAntiphishing ActualizarImagenAntiphishing(RequestActualizarImagenAntiphishing request)
        {
            try
            {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new SocioDAO().ActualizarImagenAntiphishing(request);
            }
            catch (FaultException<ExceptionActualizarImagenAntiphishing> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionActualizarImagenAntiphishing exceptionValidaOTP = new ExceptionActualizarImagenAntiphishing();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionActualizarImagenAntiphishing> Bex = new Bitacora<ExceptionActualizarImagenAntiphishing>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionActualizarImagenAntiphishing>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionActualizarImagenAntiphishing>(exceptionValidaOTP, exceptionValidaOTP.Mensaje);
            }
            catch (Exception ex)
            {
                ExceptionActualizarImagenAntiphishing exceptionActualizarImagenAntiphishing = new ExceptionActualizarImagenAntiphishing();
                exceptionActualizarImagenAntiphishing.Codigo = 1000;
                exceptionActualizarImagenAntiphishing.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionActualizarImagenAntiphishing.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionActualizarImagenAntiphishing> Bex = new Bitacora<ExceptionActualizarImagenAntiphishing>(request.NumeroSocio.ToString(), exceptionActualizarImagenAntiphishing, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionActualizarImagenAntiphishing>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionActualizarImagenAntiphishing>(exceptionActualizarImagenAntiphishing, exceptionActualizarImagenAntiphishing.Descripcion);
            }
        }

        public ResponseObtenerGestionBeneficiarios ObtenerGestionBeneficiarios(RequestObtenerGestionBeneficiarios request)
        {
            try
            {
                    Bitacora<RequestObtenerGestionBeneficiarios> b = new Bitacora<RequestObtenerGestionBeneficiarios>(request.NumeroSocio.ToString(), request);
                    new Logg().Info(SerializerManager<Bitacora<RequestObtenerGestionBeneficiarios>>.SerealizarObjtecToString(b));
                    return new SocioDAO().ObtenerGestionBeneficiarios(request);
                
            }
            catch (FaultException<ExceptionObtenerGestionBeneficiarios> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerGestionBeneficiarios exceptionObtenerGestionBeneficiarios = new ExceptionObtenerGestionBeneficiarios();
                exceptionObtenerGestionBeneficiarios.Codigo = 1000;
                exceptionObtenerGestionBeneficiarios.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerGestionBeneficiarios.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerGestionBeneficiarios> Bex = new Bitacora<ExceptionObtenerGestionBeneficiarios>(request.NumeroSocio.ToString(), exceptionObtenerGestionBeneficiarios, request.NumeroSocio.ToString());
                //new Logg().Error(SerializerManager<Bitacora<ExceptionRecuperarContrasena>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerGestionBeneficiarios>(exceptionObtenerGestionBeneficiarios);
            }

        }

        #endregion

        #region CONTRASEÑAS ValidaContrasenaTemporal ,CambiarContrasena, GenerarContrasenaTemp ,ValidarRespuesta ObtenerPreguntaSecreta
        public ResponseValidaContrasenaTemporal ValidaContrasenaTemporal(RequestValidaContrasenaTemporal request)
        {
            try
            {
                request.ContrasenaTemporal = AgenteConecta.CifrarInformacion(request.ContrasenaTemporal);
                return new SocioDAO().ValidaContrasenaTemporal(request);
            }
            catch (FaultException<ExceptionValidaContrasenaTemporal> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionValidaContrasenaTemporal exceptionValidaContrasenaTemporal = new ExceptionValidaContrasenaTemporal();
                exceptionValidaContrasenaTemporal.Codigo = 1000;
                exceptionValidaContrasenaTemporal.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionValidaContrasenaTemporal.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionValidaContrasenaTemporal> Bex = new Bitacora<ExceptionValidaContrasenaTemporal>(request.NumeroSocio.ToString(), exceptionValidaContrasenaTemporal, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionValidaContrasenaTemporal>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionValidaContrasenaTemporal>(exceptionValidaContrasenaTemporal);
            }
        }
        public ResponseCambiarContrasena CambiarContrasena(RequestCambiarContrasena request)
        {
            try
            {
                string errorContraseña = string.Empty;
                if (!Utilerias.ValidaEstructuraContrasena(request.ContrasenaN, ref errorContraseña, request.NumeroSocio))
                {
                    ExceptionCambiarContrasena exceptionCambiarContrasena = new ExceptionCambiarContrasena();
                    exceptionCambiarContrasena.Codigo = 317;
                    exceptionCambiarContrasena.Descripcion = "Message :";
                    exceptionCambiarContrasena.Mensaje = errorContraseña;//"Las contraseña no cumple con políticas de seguridad";
                    throw new FaultException<ExceptionCambiarContrasena>(exceptionCambiarContrasena,exceptionCambiarContrasena.Mensaje);
                }
                if(string.Compare(request.ContrasenaN, request.ConfirmarNuevaContrasena) != 0)
                {
                    ExceptionCambiarContrasena exceptionCambiarContrasena = new ExceptionCambiarContrasena();
                    exceptionCambiarContrasena.Codigo = 317;
                    exceptionCambiarContrasena.Descripcion = "Message :";
                    exceptionCambiarContrasena.Mensaje = "Las contraseñas no coinciden.";
                    throw new FaultException<ExceptionCambiarContrasena>(exceptionCambiarContrasena, exceptionCambiarContrasena.Mensaje);
                }
                else
                {
                    if(!request.VieneDeBloqueo)
                        AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);

                    request.ContrasenaN = AgenteConecta.CifrarInformacion(request.ContrasenaN);
                    request.ConfirmarNuevaContrasena = AgenteConecta.CifrarInformacion(request.ConfirmarNuevaContrasena);
                    Bitacora<RequestCambiarContrasena> b = new Bitacora<RequestCambiarContrasena>(request.NumeroSocio.ToString(), request);
                    new Logg().Info(SerializerManager<Bitacora<RequestCambiarContrasena>>.SerealizarObjtecToString(b));
                    return new SocioDAO().CambiarContrasena(request);
                }
            }
            catch (FaultException<ExceptionCambiarContrasena> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionCambiarContrasena exceptionValidaOTP = new ExceptionCambiarContrasena();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionCambiarContrasena> Bex = new Bitacora<ExceptionCambiarContrasena>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionCambiarContrasena>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionCambiarContrasena>(exceptionValidaOTP,exceptionValidaOTP.Mensaje);
            }
            catch (Exception ex)
            {
                ExceptionCambiarContrasena exceptionCambiarContrasena = new ExceptionCambiarContrasena();
                exceptionCambiarContrasena.Codigo = 1000;
                exceptionCambiarContrasena.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionCambiarContrasena.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionCambiarContrasena> Bex = new Bitacora<ExceptionCambiarContrasena>(request.NumeroSocio.ToString(), exceptionCambiarContrasena, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionCambiarContrasena>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionCambiarContrasena>(exceptionCambiarContrasena,exceptionCambiarContrasena.Mensaje);
            }
        }
        public ResponseGenerarContrasenaTemp GenerarContrasenaTemp(RequestGenerarContrasenaTemp request)
        {
            try
            {

                String contraseña = string.Empty;
                contraseña = Utilerias.GenerarContraseña();
                contraseña = AgenteConecta.CifrarInformacion(contraseña);
                return new SocioDAO().GenerarContraseñaTemporal(request, contraseña);

            }
            catch (FaultException<ExceptionGenerarContrasenaTemp> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionGenerarContrasenaTemp exceptionGenerarContrasenaTemp = new ExceptionGenerarContrasenaTemp();
                exceptionGenerarContrasenaTemp.Codigo = 1000;
                exceptionGenerarContrasenaTemp.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionGenerarContrasenaTemp.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionGenerarContrasenaTemp> Bex = new Bitacora<ExceptionGenerarContrasenaTemp>(request.NumeroSocio.ToString(), exceptionGenerarContrasenaTemp, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionGenerarContrasenaTemp>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionGenerarContrasenaTemp>(exceptionGenerarContrasenaTemp);
            }

            return null;
        }
        public ResponseValidarRespuesta ValidarRespuesta(RequestValidarRespuesta request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.RespuestaSecreta))
                {
                    ExceptionValidarRespuesta exceptionRecuperarContrasena = new ExceptionValidarRespuesta();
                    exceptionRecuperarContrasena.Codigo = 317;
                    exceptionRecuperarContrasena.Descripcion = "Message :";
                    exceptionRecuperarContrasena.Mensaje = "Las respuesta no cumple con políticas de seguridad";
                    Bitacora<ExceptionValidarRespuesta> Bex = new Bitacora<ExceptionValidarRespuesta>(request.NumeroSocio.ToString(), exceptionRecuperarContrasena, request.NumeroSocio.ToString());
                    new Logg().Error(SerializerManager<Bitacora<ExceptionValidarRespuesta>>.SerealizarObjtecToString(Bex));
                    throw new FaultException<ExceptionValidarRespuesta>(exceptionRecuperarContrasena);
                }
                else
                {
                    Bitacora<RequestValidarRespuesta> b = new Bitacora<RequestValidarRespuesta>(request.NumeroSocio.ToString(), request);
                    request.RespuestaSecreta = AgenteConecta.CifrarInformacion(request.RespuestaSecreta.Replace(" ",""));
                    new Logg().Info(SerializerManager<Bitacora<RequestValidarRespuesta>>.SerealizarObjtecToString(b));
                    return new SocioDAO().RecuperarContrasena(request);
                }
            }
            catch (FaultException<ExceptionValidarRespuesta> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionValidarRespuesta exceptionRecuperarContrasena = new ExceptionValidarRespuesta();
                exceptionRecuperarContrasena.Codigo = 1000;
                exceptionRecuperarContrasena.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionRecuperarContrasena.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionValidarRespuesta> Bex = new Bitacora<ExceptionValidarRespuesta>(request.NumeroSocio.ToString(), exceptionRecuperarContrasena, request.NumeroSocio.ToString());
                //new Logg().Error(SerializerManager<Bitacora<ExceptionRecuperarContrasena>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionValidarRespuesta>(exceptionRecuperarContrasena);
            }
        }
        public ResponseObtenerPreguntaSecreta ObtenerPreguntaSecreta(RequestObtenerPreguntaSecreta request)
        {
            try
            {
                Bitacora<RequestObtenerPreguntaSecreta> b = new Bitacora<RequestObtenerPreguntaSecreta>(request.NumeroSocio.ToString(), request);
                new Logg().Info(SerializerManager<Bitacora<RequestObtenerPreguntaSecreta>>.SerealizarObjtecToString(b));
                return new SocioDAO().ObtenerPreguntaSecreta(request);

            }
            catch (FaultException<ExceptionObtenerPreguntaSecreta> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerPreguntaSecreta exceptionObtenerPreguntaSecreta = new ExceptionObtenerPreguntaSecreta();
                exceptionObtenerPreguntaSecreta.Codigo = 1000;
                exceptionObtenerPreguntaSecreta.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerPreguntaSecreta.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerPreguntaSecreta> Bex = new Bitacora<ExceptionObtenerPreguntaSecreta>(request.NumeroSocio.ToString(), exceptionObtenerPreguntaSecreta, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerPreguntaSecreta>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerPreguntaSecreta>(exceptionObtenerPreguntaSecreta);
            }

        }
        #endregion

        #region  PAGO DE SERVICIOS ObtenerServiciosSocio,EliminarServicioSocio
        public ResponseObtenerServiciosSocio ObtenerServiciosSocio(RequestObtenerServiciosSocio request)
        {
            try
            {
                //Bitacora<RequestObtenerServiciosSocio> b = new Bitacora<RequestObtenerServiciosSocio>(request.NumeroSocio.ToString(), request);
                //new Logg().Info(SerializerManager<Bitacora<RequestObtenerServiciosSocio>>.SerealizarObjtecToString(b));
                return new SocioDAO().ObtenerServiciosSocio(request);
            }
            catch (FaultException<ExceptionObtenerServiciosSocio> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerServiciosSocio exceptionObtenerServiciosSocio = new ExceptionObtenerServiciosSocio();
                exceptionObtenerServiciosSocio.Codigo = 1000;
                exceptionObtenerServiciosSocio.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerServiciosSocio.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerServiciosSocio> Bex = new Bitacora<ExceptionObtenerServiciosSocio>(request.NumeroSocio.ToString(), exceptionObtenerServiciosSocio, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerServiciosSocio>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerServiciosSocio>(exceptionObtenerServiciosSocio);
            }
        }

        public ResponseEliminarServicioSocio EliminarServicioSocio(RequestEliminarServicioSocio request)
        {
            try
            {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new SocioDAO().EliminarServicioSocio(request);
            }
            catch (FaultException<ExceptionObtenerServiciosSocio> exG)
            {
                throw exG;
            }
            catch (FaultException exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionEliminarServicioSocio exceptionEliminarServicioSocio = new ExceptionEliminarServicioSocio();
                exceptionEliminarServicioSocio.Codigo = 1000;
                exceptionEliminarServicioSocio.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionEliminarServicioSocio.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionEliminarServicioSocio> Bex = new Bitacora<ExceptionEliminarServicioSocio>(request.NumeroSocio.ToString(), exceptionEliminarServicioSocio, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionEliminarServicioSocio>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionEliminarServicioSocio>(exceptionEliminarServicioSocio);
            }
        }
        #endregion

        #region Inversiones
        public ResponseCancelarInversionSocio CancelarInversionSocio(RequestCancelarInversionSocio request)
        {
            try
            {
                //Bitacora<RequestCancelarInversionSocio> b = new Bitacora<RequestCancelarInversionSocio>(request.NumeroSocio.ToString(), request);
                //new Logg().Info(SerializerManager<Bitacora<RequestCancelarInversionSocio>>.SerealizarObjtecToString(b));
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new SocioDAO().CancelarInversionSocio(request);
            }
            catch (FaultException<ExceptionCancelarInversionSocio> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionCancelarInversionSocio exceptionCancelarInversionSocio = new ExceptionCancelarInversionSocio();
                exceptionCancelarInversionSocio.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionCancelarInversionSocio.Descripcion = ef.Message;
                exceptionCancelarInversionSocio.Mensaje = ef.Message;
                //Bitacora<ExceptionCancelarInversionSocio> Bex = new Bitacora<ExceptionCancelarInversionSocio>(request.NumeroSocio.ToString(), exceptionCancelarInversionSocio, request.NumeroSocio.ToString());
                //new Logg().Error(SerializerManager<Bitacora<ExceptionCancelarInversionSocio>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionCancelarInversionSocio>(exceptionCancelarInversionSocio);
            }
            catch (Exception ex)
            {
                ExceptionObtenerInversionesSocio exceptionObtenerInversionesSocio = new ExceptionObtenerInversionesSocio();
                exceptionObtenerInversionesSocio.Codigo = 1000;
                exceptionObtenerInversionesSocio.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerInversionesSocio.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerInversionesSocio> Bex = new Bitacora<ExceptionObtenerInversionesSocio>(request.NumeroSocio.ToString(), exceptionObtenerInversionesSocio, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerInversionesSocio>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerInversionesSocio>(exceptionObtenerInversionesSocio);
            }
        }

        public ResponseObtenerInversionesSocio ObtenerInversionesSocio(RequestObtenerInversionesSocio request)
        {
            try
            {
                Bitacora<RequestObtenerInversionesSocio> b = new Bitacora<RequestObtenerInversionesSocio>(request.NumeroSocio.ToString(), request);
                new Logg().Info(SerializerManager<Bitacora<RequestObtenerInversionesSocio>>.SerealizarObjtecToString(b));
                return new SocioDAO().ObtenerInversionesSocio(request);
            }
            catch (FaultException<ExceptionObtenerInversionesSocio> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerInversionesSocio exceptionObtenerInversionesSocio = new ExceptionObtenerInversionesSocio();
                exceptionObtenerInversionesSocio.Codigo = 1000;
                exceptionObtenerInversionesSocio.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerInversionesSocio.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerInversionesSocio> Bex = new Bitacora<ExceptionObtenerInversionesSocio>(request.NumeroSocio.ToString(), exceptionObtenerInversionesSocio, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerInversionesSocio>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerInversionesSocio>(exceptionObtenerInversionesSocio);
            }
        }

        #endregion

        #region descargar y obtener los estados de cuenta (SAT)

        public ResponseObtenerEstadoCuenta ObtenerEstadosDeCuenta(RequestObtenerEstadoCuenta request)
        {
            try
            {
                return new SocioDAO().ObtenerEstadosDeCuenta(request);
            }
            catch (FaultException<ExceptionObtenerEstadoCuenta> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionObtenerEstadoCuenta exceptionCancelarInversionSocio = new ExceptionObtenerEstadoCuenta();
                exceptionCancelarInversionSocio.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionCancelarInversionSocio.Descripcion = ef.Message;
                exceptionCancelarInversionSocio.Mensaje = ef.Message;
                Bitacora<ExceptionObtenerEstadoCuenta> Bex = new Bitacora<ExceptionObtenerEstadoCuenta>(request.NumeroSocio.ToString(), exceptionCancelarInversionSocio, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerEstadoCuenta>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerEstadoCuenta>(exceptionCancelarInversionSocio);
            }
            catch (Exception ex)
            {
                ExceptionObtenerEstadoCuenta exceptionObtenerEstadoCuenta = new ExceptionObtenerEstadoCuenta();
                exceptionObtenerEstadoCuenta.Codigo = 1000;
                exceptionObtenerEstadoCuenta.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerEstadoCuenta.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerEstadoCuenta> Bex = new Bitacora<ExceptionObtenerEstadoCuenta>(request.NumeroSocio.ToString(), exceptionObtenerEstadoCuenta, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerEstadoCuenta>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerEstadoCuenta>(exceptionObtenerEstadoCuenta);
            }

        }

        public ResponseDescargaEstadoDeCuenta DescargaEstadoDeCuenta(RequestDescargaEstadoDeCuenta request)
        {
           try
           {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new SocioDAO().DescargaEstadoDeCuenta(request);
            }
            catch (FaultException<ExceptionDescargaEstadoDeCuenta> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionDescargaEstadoDeCuenta exceptionDescargaEstadoDeCuenta = new ExceptionDescargaEstadoDeCuenta();
                exceptionDescargaEstadoDeCuenta.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionDescargaEstadoDeCuenta.Descripcion = ef.Message;
                exceptionDescargaEstadoDeCuenta.Mensaje = ef.Message;
                Bitacora<ExceptionDescargaEstadoDeCuenta> Bex = new Bitacora<ExceptionDescargaEstadoDeCuenta>(request.NumeroSocio.ToString(), exceptionDescargaEstadoDeCuenta, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionDescargaEstadoDeCuenta>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionDescargaEstadoDeCuenta>(exceptionDescargaEstadoDeCuenta);
            }
            catch (Exception ex)
            {
                ExceptionDescargaEstadoDeCuenta exceptionDescargaEstadoDeCuenta = new ExceptionDescargaEstadoDeCuenta();
                exceptionDescargaEstadoDeCuenta.Codigo = 1000;
                exceptionDescargaEstadoDeCuenta.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionDescargaEstadoDeCuenta.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionDescargaEstadoDeCuenta> Bex = new Bitacora<ExceptionDescargaEstadoDeCuenta>(request.NumeroSocio.ToString(), exceptionDescargaEstadoDeCuenta, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionDescargaEstadoDeCuenta>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionDescargaEstadoDeCuenta>(exceptionDescargaEstadoDeCuenta);
            }

        }
        #endregion
            
        #region TARJETAS DE CREDITO O DEBITO
        public ResponseObtenerTarjetas ObtenerTarjetas(RequestObtenerTarjetas request)
        {
            try
            {
                return new SocioDAO().ObtenerTarjetas(request);
            }
            catch (FaultException<ExceptionObtenerTarjetas> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerTarjetas exceptionObtenerTarjetas = new ExceptionObtenerTarjetas();
                exceptionObtenerTarjetas.Codigo = 1000;
                exceptionObtenerTarjetas.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerTarjetas.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerTarjetas>(exceptionObtenerTarjetas, exceptionObtenerTarjetas.Descripcion);
            }

        }

        public ResponseBloquearTarjeta BloquearTarjeta(RequestBloquearTarjeta request)
        {
            try
            {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new SocioDAO().BloquearTarjeta(request);
            }
            catch (FaultException<ExceptionBloquearTarjeta> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionBloquearTarjeta exceptionValidaOTP = new ExceptionBloquearTarjeta();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionBloquearTarjeta> Bex = new Bitacora<ExceptionBloquearTarjeta>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionBloquearTarjeta>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionBloquearTarjeta>(exceptionValidaOTP, exceptionValidaOTP.Mensaje);
            }
            catch (Exception ex)
            {
                ExceptionBloquearTarjeta exceptionBloquearTarjeta = new ExceptionBloquearTarjeta();
                exceptionBloquearTarjeta.Codigo = 1000;
                exceptionBloquearTarjeta.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionBloquearTarjeta.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionBloquearTarjeta> Bex = new Bitacora<ExceptionBloquearTarjeta>(request.NumeroSocio.ToString(), exceptionBloquearTarjeta, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionBloquearTarjeta>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionBloquearTarjeta>(exceptionBloquearTarjeta, exceptionBloquearTarjeta.Descripcion);
            }
        }

        public ResponseDesbloquearTarjeta DesbloquearTarjeta(RequestDesbloquearTarjeta request)
        {
            try
            {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                request.TipoBloqueoTarjeta = TipoBloqueoTarjeta.Ninguno;
                return new SocioDAO().DesBloquearTarjeta(request);
            }
            catch (FaultException<ExceptionDesbloquearTarjeta> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionDesbloquearTarjeta exceptionValidaOTP = new ExceptionDesbloquearTarjeta();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionDesbloquearTarjeta> Bex = new Bitacora<ExceptionDesbloquearTarjeta>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionDesbloquearTarjeta>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionDesbloquearTarjeta>(exceptionValidaOTP, exceptionValidaOTP.Mensaje);
            }
            catch (Exception ex)
            {
                ExceptionDesbloquearTarjeta exceptionDesbloquearTarjeta = new ExceptionDesbloquearTarjeta();
                exceptionDesbloquearTarjeta.Codigo = 1000;
                exceptionDesbloquearTarjeta.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionDesbloquearTarjeta.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionDesbloquearTarjeta> Bex = new Bitacora<ExceptionDesbloquearTarjeta>(request.NumeroSocio.ToString(), exceptionDesbloquearTarjeta, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionDesbloquearTarjeta>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionDesbloquearTarjeta>(exceptionDesbloquearTarjeta, exceptionDesbloquearTarjeta.Descripcion);
            }
        }
        #endregion TARJETAS DE CREDITO O DEBITO
                
        #region PAGO DE  PRESTAMO
        public ResponsePagarPrestamoCuentasPropias PagarPrestamoCuentasPropias(RequestPagarPrestamoCuentasPropias request)
        {

            try
            {
                //
                //string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new SocioDAO().PagarPrestamoCuentasPropias(request);
            }
            catch (FaultException<ExceptionPagarPrestamoCuentasPropias> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionPagarPrestamoCuentasPropias exceptionValidaOTP = new ExceptionPagarPrestamoCuentasPropias();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                throw new FaultException<ExceptionPagarPrestamoCuentasPropias>(exceptionValidaOTP, exceptionValidaOTP.Mensaje);
            }
            catch (Exception ex)
            {
                ExceptionPagarPrestamoCuentasPropias exceptionPagarPrestamoCuentasPropias = new ExceptionPagarPrestamoCuentasPropias();
                exceptionPagarPrestamoCuentasPropias.Codigo = 1000;
                exceptionPagarPrestamoCuentasPropias.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionPagarPrestamoCuentasPropias.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionPagarPrestamoCuentasPropias>(exceptionPagarPrestamoCuentasPropias, exceptionPagarPrestamoCuentasPropias.Descripcion);
            }
        }

        public ResponsePagarPrestamoCuentasMismoBanco PagarPrestamoCuentasMismoBanco(RequestPagarPrestamoCuentasMismoBanco request)
        {

            try
            {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new SocioDAO().PagarPrestamoCuentasMismoBanco(request);
            }
            catch (FaultException<ExceptionPagarPrestamoCuentasMismoBanco> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionPagarPrestamoCuentasMismoBanco exceptionValidaOTP = new ExceptionPagarPrestamoCuentasMismoBanco();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                throw new FaultException<ExceptionPagarPrestamoCuentasMismoBanco>(exceptionValidaOTP, exceptionValidaOTP.Mensaje);
            }
            catch (Exception ex)
            {
                ExceptionPagarPrestamoCuentasMismoBanco exceptionPagarPrestamoCuentasMismoBanco = new ExceptionPagarPrestamoCuentasMismoBanco();
                exceptionPagarPrestamoCuentasMismoBanco.Codigo = 1000;
                exceptionPagarPrestamoCuentasMismoBanco.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionPagarPrestamoCuentasMismoBanco.Mensaje = ex.Message;
                throw new FaultException<ExceptionPagarPrestamoCuentasMismoBanco>(exceptionPagarPrestamoCuentasMismoBanco, exceptionPagarPrestamoCuentasMismoBanco.Mensaje);
            }
        }

        #endregion


        #region BITACORA
        public ResponseObtenerBitacoraSocio ObtenerBitacoraSocio(RequestObtenerBitacoraSocio request)
        {

            try
            {
                return new SocioDAO().ObtenerBitacoraSocio(request);
            }
            catch (FaultException<ExceptionObtenerBitacoraSocio> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerBitacoraSocio exceptionObtenerBitacoraSocio = new ExceptionObtenerBitacoraSocio();
                exceptionObtenerBitacoraSocio.Codigo = 1000;
                exceptionObtenerBitacoraSocio.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerBitacoraSocio.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerBitacoraSocio>(exceptionObtenerBitacoraSocio);
            }
        }

        #endregion






    }
}
