﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using BusCrypto;
using ServiciosBancaDAO;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;

namespace ServiciosBancaCMV.Domiciliacion
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Domiciliacion" en el código y en el archivo de configuración a la vez.
    public class Domiciliacion : IDomiciliacion
    {
        public ResponseAltaDomiciliacion AltaDomiciliacion(RequestAltaDomiciliacion request)
        {
            try
            {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new DomiciliacionDAO().AltaDomicilacion(request);
            }
            catch (FaultException<ExceptionAltaDomiciliacion> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionAltaDomiciliacion exceptionValidaOTP = new ExceptionAltaDomiciliacion();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionAltaDomiciliacion> Bex = new Bitacora<ExceptionAltaDomiciliacion>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionAltaDomiciliacion>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaDomiciliacion>(exceptionValidaOTP, exceptionValidaOTP.Mensaje);
            }
            catch (Exception ex)
            {
                ExceptionAltaDomiciliacion exceptionAltaCuentaInterna = new ExceptionAltaDomiciliacion();
                exceptionAltaCuentaInterna.Codigo = 1000;
                exceptionAltaCuentaInterna.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionAltaCuentaInterna.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionAltaDomiciliacion> Bex = new Bitacora<ExceptionAltaDomiciliacion>(request.NumeroSocio.ToString(), exceptionAltaCuentaInterna, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionAltaDomiciliacion>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaDomiciliacion>(exceptionAltaCuentaInterna, exceptionAltaCuentaInterna.Descripcion);
            }
        }

        public ResponseEliminarDomiciliacion EliminarDomiciliacion(RequestEliminarDomiciliacion request)
        {
            try
            {
                Bitacora<RequestEliminarDomiciliacion> b = new Bitacora<RequestEliminarDomiciliacion>(request.idPagoDomiciliado.ToString(), request);
                new Logg().Info(SerializerManager<Bitacora<RequestEliminarDomiciliacion>>.SerealizarObjtecToString(b));

                return new ResponseEliminarDomiciliacion();//new SocioDAO().ActualizarEstatus(request);
            }
            catch (FaultException<ExceptionEliminarDomiciliacion> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionEliminarDomiciliacion exceptionEliminarDomiciliacion = new ExceptionEliminarDomiciliacion();
                exceptionEliminarDomiciliacion.Codigo = 1000;
                exceptionEliminarDomiciliacion.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionEliminarDomiciliacion.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionEliminarDomiciliacion> Bex = new Bitacora<ExceptionEliminarDomiciliacion>("0", exceptionEliminarDomiciliacion, "0");
                new Logg().Error(SerializerManager<Bitacora<ExceptionEliminarDomiciliacion>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionEliminarDomiciliacion>(exceptionEliminarDomiciliacion);
            }
        }

        public ResponseObtenerDomiciliaciones ObtenerDomiciliaciones(RequestObtenerDomiciliaciones request)
        {
            try
            {

                return new DomiciliacionDAO().ObtenerDomiciliaciones(request);
            }
            catch (FaultException<ExceptionObtenerDomiciliaciones> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerDomiciliaciones exceptionObtenerDomiciliaciones = new ExceptionObtenerDomiciliaciones();
                exceptionObtenerDomiciliaciones.Codigo = 1000;
                exceptionObtenerDomiciliaciones.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerDomiciliaciones.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerDomiciliaciones>(exceptionObtenerDomiciliaciones);
            }
        }

        public ResponseCancelarDomiciliacion CancelarDomiciliacion(RequestCancelarDomiciliacion request)
        {
            try
            {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new DomiciliacionDAO().CancelarDomiciliacion(request);
            }
            catch (FaultException<ExceptionCancelarDomiciliacion> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionAltaDomiciliacion exceptionValidaOTP = new ExceptionAltaDomiciliacion();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                throw new FaultException<ExceptionAltaDomiciliacion>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                ExceptionCancelarDomiciliacion exceptionCancelarDomiciliacion = new ExceptionCancelarDomiciliacion();
                exceptionCancelarDomiciliacion.Codigo = 1000;
                exceptionCancelarDomiciliacion.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionCancelarDomiciliacion.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionCancelarDomiciliacion>(exceptionCancelarDomiciliacion);
            }
        }
    }
}
