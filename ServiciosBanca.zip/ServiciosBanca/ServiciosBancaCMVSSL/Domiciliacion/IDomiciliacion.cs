﻿using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosBancaCMV.Domiciliacion
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IDomiciliacion" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IDomiciliacion
    {
        [OperationContract]
        [FaultContract(typeof(ExceptionAltaDomiciliacion))]
        ResponseAltaDomiciliacion AltaDomiciliacion(RequestAltaDomiciliacion request);


        //[OperationContract]
        [FaultContract(typeof(ExceptionEliminarDomiciliacion))]
        ResponseEliminarDomiciliacion EliminarDomiciliacion(RequestEliminarDomiciliacion request);

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerDomiciliaciones))]
        ResponseObtenerDomiciliaciones ObtenerDomiciliaciones(RequestObtenerDomiciliaciones request);

        [OperationContract]
        [FaultContract(typeof(ExceptionCancelarDomiciliacion))]
        ResponseCancelarDomiciliacion CancelarDomiciliacion(RequestCancelarDomiciliacion request);



    }
}
