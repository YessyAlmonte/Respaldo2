﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using BusCrypto;
using ServiciosBancaDAO;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;
using ServiciosBancaEntidades.Autenticacion;

using System.ServiceModel.Channels;
using System.Net;
using ServiciosBancaCMVSSL.WsCmvDispersion;

namespace ServiciosBancaCMV.Transferencia
{
    [CustomBehavior]
    public class Transferencia : ITransferencia
    {

        public ResponseAltaCuentaInterna AltaCuentaInterna(RequestAltaCuentaInterna request)//Falta validar otp
        {
            try
            {

                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new TransferenciaDAO().AltaCuentaInterna(request);
            }
            catch (FaultException<ExceptionAltaCuentaInterna> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionAltaCuentaInterna exceptionValidaOTP = new ExceptionAltaCuentaInterna();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionAltaCuentaInterna> Bex = new Bitacora<ExceptionAltaCuentaInterna>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionAltaCuentaInterna>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaCuentaInterna>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                ExceptionAltaCuentaInterna exceptionAltaCuentaInterna = new ExceptionAltaCuentaInterna();
                exceptionAltaCuentaInterna.Codigo = 1000;
                exceptionAltaCuentaInterna.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionAltaCuentaInterna.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionAltaCuentaInterna> Bex = new Bitacora<ExceptionAltaCuentaInterna>(request.NumeroSocio.ToString(), exceptionAltaCuentaInterna, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionAltaCuentaInterna>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaCuentaInterna>(exceptionAltaCuentaInterna);
            }
        }

        public ResponseAltaCuentaExternaCelular AltaCuentaExternaCelular(RequestAltaCuentaExternaCelular request)
        {
            try
            {

                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new TransferenciaDAO().AltaCuentaExternaCelular(request);
                /*return new ResponseAltaCuentaExternaCelular()
                {
                    Estatus = true,
                    Mensaje = "Registro de cuenta exitoso"
                };*/
            }
            catch (FaultException<ExceptionAltaCuentaExternaCelular> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionAltaCuentaExternaCelular exceptionValidaOTP = new ExceptionAltaCuentaExternaCelular();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionAltaCuentaExternaCelular> Bex = new Bitacora<ExceptionAltaCuentaExternaCelular>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionAltaCuentaExternaCelular>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaCuentaExternaCelular>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                ExceptionAltaCuentaExternaCelular exceptionAltaCuentaExternaCelular = new ExceptionAltaCuentaExternaCelular();
                exceptionAltaCuentaExternaCelular.Codigo = 1000;
                exceptionAltaCuentaExternaCelular.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionAltaCuentaExternaCelular.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionAltaCuentaExternaCelular> Bex = new Bitacora<ExceptionAltaCuentaExternaCelular>(request.NumeroSocio.ToString(), exceptionAltaCuentaExternaCelular, request.NumeroSocio.ToString());
                //new Logg().Error(SerializerManager<Bitacora<ExceptionAltaCuentaExternaCelular>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaCuentaExternaCelular>(exceptionAltaCuentaExternaCelular);
            }
        }

        public ResponseAltaCuentaExternaDebito AltaCuentaExternaDebito(RequestAltaCuentaExternaDebito request)
        {
            try
            {

                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new TransferenciaDAO().AltaCuentaExternaDebito(request);
                
            }
            catch (FaultException<ExceptionAltaCuentaExternaDebito> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionAltaCuentaExternaDebito exceptionValidaOTP = new ExceptionAltaCuentaExternaDebito();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionAltaCuentaExternaDebito> Bex = new Bitacora<ExceptionAltaCuentaExternaDebito>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionAltaCuentaExternaDebito>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaCuentaExternaDebito>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                ExceptionAltaCuentaExternaDebito exceptionAltaCuentaExternaDebito = new ExceptionAltaCuentaExternaDebito();
                exceptionAltaCuentaExternaDebito.Codigo = 1000;
                exceptionAltaCuentaExternaDebito.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionAltaCuentaExternaDebito.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionAltaCuentaExternaDebito> Bex = new Bitacora<ExceptionAltaCuentaExternaDebito>(request.NumeroSocio.ToString(), exceptionAltaCuentaExternaDebito, request.NumeroSocio.ToString());
                //new Logg().Error(SerializerManager<Bitacora<ExceptionAltaCuentaExternaDebito>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaCuentaExternaDebito>(exceptionAltaCuentaExternaDebito);
            }
        }

        public ResponseAltaCuentaExternaCredito AltaCuentaExternaCredito(RequestAltaCuentaExternaCredito request)
        {
            try
            {
                //Bitacora<RequestAltaCuentaExternaCredito> b = new Bitacora<RequestAltaCuentaExternaCredito>(request.NumeroSocio.ToString(), request, "ResponseAltaCuentaExternaDebito");
                //new Logg().Info(SerializerManager<Bitacora<RequestAltaCuentaExternaCredito>>.SerealizarObjtecToString(b));
                ////string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                //return new TransferenciaDAO().AltaCuentaExternaCredito(request);
                return new ResponseAltaCuentaExternaCredito()
                {
                    Estatus = true,
                    Mensaje = "Registro de cuenta exitoso"
                };
            }
            catch (FaultException<ExceptionAltaCuentaExternaCredito> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionAltaCuentaExternaCredito exceptionValidaOTP = new ExceptionAltaCuentaExternaCredito();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionAltaCuentaExternaCredito> Bex = new Bitacora<ExceptionAltaCuentaExternaCredito>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionAltaCuentaExternaCredito>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaCuentaExternaCredito>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                ExceptionAltaCuentaExternaCredito exceptionAltaCuentaExternaCredito = new ExceptionAltaCuentaExternaCredito();
                exceptionAltaCuentaExternaCredito.Codigo = 1000;
                exceptionAltaCuentaExternaCredito.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionAltaCuentaExternaCredito.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionAltaCuentaExternaCredito> Bex = new Bitacora<ExceptionAltaCuentaExternaCredito>(request.NumeroSocio.ToString(), exceptionAltaCuentaExternaCredito, request.NumeroSocio.ToString());
                //new Logg().Error(SerializerManager<Bitacora<ExceptionAltaCuentaExternaDebito>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaCuentaExternaCredito>(exceptionAltaCuentaExternaCredito);
            }
        }

        public ResponseAltaCuentaExternaClabe AltaCuentaExternaClabe(RequestAltaCuentaExternaClabe request)//Falta validar OTP
        {
            try
            {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
               return new TransferenciaDAO().AltaCuentaExternaClabe(request);
               
            }
            catch (FaultException<ExceptionAltaCuentaExternaClabe> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionAltaCuentaExternaClabe exceptionValidaOTP = new ExceptionAltaCuentaExternaClabe();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionAltaCuentaExternaClabe> Bex = new Bitacora<ExceptionAltaCuentaExternaClabe>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionAltaCuentaExternaClabe>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaCuentaExternaClabe>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                ExceptionAltaCuentaExternaClabe exceptionAltaCuentaExternaClabe = new ExceptionAltaCuentaExternaClabe();
                exceptionAltaCuentaExternaClabe.Codigo = 1000;
                exceptionAltaCuentaExternaClabe.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionAltaCuentaExternaClabe.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionAltaCuentaExternaClabe> Bex = new Bitacora<ExceptionAltaCuentaExternaClabe>(request.NumeroSocio.ToString(), exceptionAltaCuentaExternaClabe, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionAltaCuentaExternaClabe>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaCuentaExternaClabe>(exceptionAltaCuentaExternaClabe);
            }
        }

        public ResponseEliminarCuentaInterna EliminaCuentaInterna(RequestEliminarCuentaInterna request)
        {
            try
            {
                Bitacora<RequestEliminarCuentaInterna> b = new Bitacora<RequestEliminarCuentaInterna>(request.NumeroSocio.ToString(), request, "responseAltaCuentaIntern");
                new Logg().Info(SerializerManager<Bitacora<RequestEliminarCuentaInterna>>.SerealizarObjtecToString(b));
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new TransferenciaDAO().EliminaCuentaInterna(request);
            }
            catch (FaultException<ExceptionEliminarCuentaInterna> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionEliminarCuentaInterna exceptionValidaOTP = new ExceptionEliminarCuentaInterna();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionEliminarCuentaInterna> Bex = new Bitacora<ExceptionEliminarCuentaInterna>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionEliminarCuentaInterna>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionEliminarCuentaInterna>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                ExceptionEliminarCuentaInterna exceptionEliminarCuentaInterna = new ExceptionEliminarCuentaInterna();
                exceptionEliminarCuentaInterna.Codigo = 1000;
                exceptionEliminarCuentaInterna.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionEliminarCuentaInterna.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionEliminarCuentaInterna> Bex = new Bitacora<ExceptionEliminarCuentaInterna>(request.NumeroSocio.ToString(), exceptionEliminarCuentaInterna, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionEliminarCuentaInterna>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionEliminarCuentaInterna>(exceptionEliminarCuentaInterna);
            }
        }

        public ResponseEliminaCuentaExterna EliminaCuentaExterna(RequestEliminaCuentaExterna request)
        {
            try
            {
                //Bitacora<RequestEliminaCuentaExterna> b = new Bitacora<RequestEliminaCuentaExterna>(request.NumeroSocio.ToString(), request);
                //new Logg().Info(SerializerManager<Bitacora<RequestEliminaCuentaExterna>>.SerealizarObjtecToString(b));
                 string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                 return new TransferenciaDAO().EliminaCuentaExterna(request);
                //return new ResponseEliminaCuentaExterna()
                //{
                //    Estatus = true,
                //    Mensaje = "Se elimino correctamente la cuenta"
                //};
            }
            catch (FaultException<ExceptionEliminaCuentaExterna> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionEliminaCuentaExterna exceptionValidaOTP = new ExceptionEliminaCuentaExterna();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionEliminaCuentaExterna> Bex = new Bitacora<ExceptionEliminaCuentaExterna>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionEliminaCuentaExterna>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionEliminaCuentaExterna>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                ExceptionEliminaCuentaExterna exceptionEliminaCuentaExterna = new ExceptionEliminaCuentaExterna();
                exceptionEliminaCuentaExterna.Codigo = 1000;
                exceptionEliminaCuentaExterna.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionEliminaCuentaExterna.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionEliminaCuentaExterna> Bex = new Bitacora<ExceptionEliminaCuentaExterna>(request.NumeroSocio.ToString(), exceptionEliminaCuentaExterna, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionEliminaCuentaExterna>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionEliminaCuentaExterna>(exceptionEliminaCuentaExterna);
            }
        }

        public List<ResponseObtenerCuentasRetiro> ObtenerCuentasRetiro(RequestObtenerCuentasRetiro request)
        {
            try
            {
                Bitacora<RequestObtenerCuentasRetiro> b = new Bitacora<RequestObtenerCuentasRetiro>(request.NumeroSocio.ToString(), request);
                new Logg().Info(SerializerManager<Bitacora<RequestObtenerCuentasRetiro>>.SerealizarObjtecToString(b));
                return new TransferenciaDAO().ObtenerCuentasRetiro(request);

            }
            catch (FaultException<ExceptionObtenerCuentasRetiro> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerCuentasRetiro exceptionObtenerCuentasRetiro = new ExceptionObtenerCuentasRetiro();
                exceptionObtenerCuentasRetiro.Codigo = 1000;
                exceptionObtenerCuentasRetiro.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerCuentasRetiro.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerCuentasRetiro> Bex = new Bitacora<ExceptionObtenerCuentasRetiro>(request.NumeroSocio.ToString(), exceptionObtenerCuentasRetiro, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerCuentasRetiro>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerCuentasRetiro>(exceptionObtenerCuentasRetiro);
            }
        }

        public List<ResponseObtenerCuentasDepositoInterna> ObtenerCuentasDepositoInterna(RequestObtenerCuentasDepositoInterna request)
        {
            try
            {
                //Bitacora<RequestObtenerCuentasDepositoInterna> b = new Bitacora<RequestObtenerCuentasDepositoInterna>(request.NumeroSocio.ToString(), request);
                //new Logg().Info(SerializerManager<Bitacora<RequestObtenerCuentasDepositoInterna>>.SerealizarObjtecToString(b));
                return new TransferenciaDAO().ObtenerCuentasDepositoInterna(request);

            }
            catch (FaultException<ExceptionObtenerCuentasDepositoInterna> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerCuentasDepositoInterna exceptionObtenerCuentasDepositoInterna = new ExceptionObtenerCuentasDepositoInterna();
                exceptionObtenerCuentasDepositoInterna.Codigo = 1000;
                exceptionObtenerCuentasDepositoInterna.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerCuentasDepositoInterna.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerCuentasDepositoInterna> Bex = new Bitacora<ExceptionObtenerCuentasDepositoInterna>(request.NumeroSocio.ToString(), exceptionObtenerCuentasDepositoInterna, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerCuentasDepositoInterna>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerCuentasDepositoInterna>(exceptionObtenerCuentasDepositoInterna);
            }
        }

        public List<ResponseObtenerCuentasDepositoExternas> ObtenerCuentasDepositoExternas(RequestObtenerCuentasDepositoExternas request)
        {
            try
            {
                //Bitacora<RequestObtenerCuentasDepositoExternas> b = new Bitacora<RequestObtenerCuentasDepositoExternas>(request.NumeroSocio.ToString(), request);
                //new Logg().Info(SerializerManager<Bitacora<RequestObtenerCuentasDepositoExternas>>.SerealizarObjtecToString(b));
                return new TransferenciaDAO().ObtenerCuentasDepositoExternas(request);
                //List<ResponseObtenerCuentasDepositoExternas> cuentas = new List<ResponseObtenerCuentasDepositoExternas>();
                //ResponseObtenerCuentasDepositoExternas cuenta = new ResponseObtenerCuentasDepositoExternas();
                //for (int i = 1; i < 5; i++)
                //{
                //    cuenta.Alias = "Edson" + i;
                //    cuenta.Banco = "Inbursa" + i;
                //    cuenta.ClabeSPEI = "442445556488978512";
                //    cuenta.IdBanco = 1;
                //    cuenta.IdBancoBIN = "2123";
                //    cuenta.IdCuentaExterna = "1";
                //    cuenta.MontoMaximo = 2000;
                //    cuenta.TipoCuentaExterna = TipoCuentaExterna.Clabe_Interbancaria;
                //    cuenta.TitularCuenta = "Edson Peña_" + i;
                //    cuentas.Add(cuenta);
                //}
                //return cuentas;
            }
            catch (FaultException<ExceptionObtenerCuentasDepositoExternas> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerCuentasDepositoExternas exceptionObtenerCuentasDepositoExternas = new ExceptionObtenerCuentasDepositoExternas();
                exceptionObtenerCuentasDepositoExternas.Codigo = 1000;
                exceptionObtenerCuentasDepositoExternas.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerCuentasDepositoExternas.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerCuentasDepositoExternas> Bex = new Bitacora<ExceptionObtenerCuentasDepositoExternas>(request.NumeroSocio.ToString(), exceptionObtenerCuentasDepositoExternas, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerCuentasDepositoExternas>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerCuentasDepositoExternas>(exceptionObtenerCuentasDepositoExternas);
            }
        }

        public ResponseTransferenciasCuentasPropias TransferenciasCuentasPropias(RequestTransferenciasCuentasPropias request)//Falta validar OTP
        {
            try
            {
                if (string.IsNullOrEmpty(request.OTP))
                    request.TipoTransferenciaInterna = TipoTransferenciaInterna.CuentaPropia;
                else
                {
                    string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                    request.TipoTransferenciaInterna = TipoTransferenciaInterna.CuentaOtroSocio;
                }


                return new TransferenciaDAO().TransferenciasCuentasPropias(request);
            }
            catch (FaultException<ExceptionTransferenciasCuentasPropias> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionTransferenciasCuentasPropias exceptionValidaOTP = new ExceptionTransferenciasCuentasPropias();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionTransferenciasCuentasPropias> Bex = new Bitacora<ExceptionTransferenciasCuentasPropias>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionTransferenciasCuentasPropias>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionTransferenciasCuentasPropias>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                ExceptionTransferenciasCuentasPropias exceptionAltaCuentaExternaClabe = new ExceptionTransferenciasCuentasPropias();
                exceptionAltaCuentaExternaClabe.Codigo = 1000;
                exceptionAltaCuentaExternaClabe.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionAltaCuentaExternaClabe.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionTransferenciasCuentasPropias> Bex = new Bitacora<ExceptionTransferenciasCuentasPropias>(request.NumeroSocio.ToString(), exceptionAltaCuentaExternaClabe, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionTransferenciasCuentasPropias>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionTransferenciasCuentasPropias>(exceptionAltaCuentaExternaClabe);
            }
        }

        public ResponseTransferenciasCuentasExterna TransferenciasCuentasExterna(RequestTransferenciasCuentasExterna request)//Falta validar OTP
         {
            ResponseTransferenciasCuentasExterna response = new ResponseTransferenciasCuentasExterna();
            try
            {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                CmvDispersionClient cmvDispersionClient = new CmvDispersionClient();
                ordenPagoWS ordenPagoWS = new ordenPagoWS();
                speiServiceResponse speiServiceResponse;
                response =  new TransferenciaDAO().TransferenciasCuentasExterna(request);
                if(response.EstatusTransferencia == EstatusTransferencia.Pendiente)
                {
                    if (request.Programado)
                        return response;
                    else
                    {
                        ordenPagoWS.claveRastreoField = response.ClaveRastreo;
                        ordenPagoWS.referenciaNumericaField = Convert.ToInt32(response.ReferenciaNumerica);
                        ordenPagoWS.cuentaBeneficiarioField = request.ClabeSPEIDeposito;
                        ordenPagoWS.nombreBeneficiarioField = request.TitularCuenta;
                        ordenPagoWS.conceptoPagoField = request.ConceptoPago;
                        ordenPagoWS.institucionContraparteField = Convert.ToInt32(request.IdBancoBIN);
                        ordenPagoWS.montoField = request.Monto;

                        System.Net.ServicePointManager.SecurityProtocol =
                        SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
                        ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) =>
                        {
                            return true;
                        };
                        try
                        {
                            using (new OperationContextScope(cmvDispersionClient.InnerChannel))
                            {
                                MessageHeader MessageHeaderUsuario = MessageHeader.CreateHeader("Usuario", "", "CMVF1nZ4S");
                                MessageHeader MessageHeaderContrasena = MessageHeader.CreateHeader("Contrasena", "", "8DED40B6E19F14D1651FDDF063CDD2");
                                OperationContext.Current.OutgoingMessageHeaders.Add(MessageHeaderUsuario);
                                OperationContext.Current.OutgoingMessageHeaders.Add(MessageHeaderContrasena);
                                speiServiceResponse = cmvDispersionClient.RegistraOrden(ordenPagoWS);
                            }
                            if (speiServiceResponse.idField > 0)
                            {
                                new TransferenciaDAO().AsignarIdTransferenciaSPEI(request.NumeroSocio, response.IdTransferenciaCMV, speiServiceResponse.idField);
                                response.IdTransferenciaSPEI = speiServiceResponse.idField.ToString();
                                return response;
                            }
                            else
                            {
                                new TransferenciaDAO().ErrorRegistraOrdenSPEI(response.IdTransferenciaCMV, response.ClaveRastreo, speiServiceResponse.idField, "");
                                ExceptionTransferenciasCuentasExterna exceptionTransferenciasCuentasExterna = new ExceptionTransferenciasCuentasExterna();
                                exceptionTransferenciasCuentasExterna.Codigo = speiServiceResponse.idField;
                                exceptionTransferenciasCuentasExterna.Mensaje = (string.IsNullOrEmpty(speiServiceResponse.descripcionErrorField) ? "Error al registrar la transacción, intente mas tarde" : speiServiceResponse.descripcionErrorField);
                                throw new FaultException<ExceptionTransferenciasCuentasExterna>(exceptionTransferenciasCuentasExterna, exceptionTransferenciasCuentasExterna.Mensaje);
                            }
                        }
                        catch (FaultException<ExceptionTransferenciasCuentasExterna> exG)
                        {
                            throw new FaultException<ExceptionTransferenciasCuentasExterna>(exG.Detail, exG.Detail.Mensaje);
                        }
                        catch (Exception ex)
                        {
                            new TransferenciaDAO().ErrorRegistraOrdenSPEI(response.IdTransferenciaCMV, response.ClaveRastreo, 0,ex.Message);
                            throw new Exception("Error al registrar la transacción, intente mas tarde");
                        }
                    }
                }
                else
                {
                    throw new Exception("Error al registrar la transacción, intente mas tarde");
                }
            }
            catch (FaultException<ExceptionTransferenciasCuentasExterna> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionTransferenciasCuentasExterna exceptionValidaOTP = new ExceptionTransferenciasCuentasExterna();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionTransferenciasCuentasExterna> Bex = new Bitacora<ExceptionTransferenciasCuentasExterna>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionTransferenciasCuentasExterna>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionTransferenciasCuentasExterna>(exceptionValidaOTP,exceptionValidaOTP.Mensaje);
            }
            catch (Exception ex)
            {
                ExceptionTransferenciasCuentasExterna exceptionTransferenciasCuentasExterna = new ExceptionTransferenciasCuentasExterna();
                exceptionTransferenciasCuentasExterna.Codigo = 1000;
                exceptionTransferenciasCuentasExterna.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionTransferenciasCuentasExterna.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionTransferenciasCuentasExterna> Bex = new Bitacora<ExceptionTransferenciasCuentasExterna>(request.NumeroSocio.ToString(), exceptionTransferenciasCuentasExterna, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionTransferenciasCuentasExterna>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionTransferenciasCuentasExterna>(exceptionTransferenciasCuentasExterna,exceptionTransferenciasCuentasExterna.Mensaje);
            }
        }

        public List<ResponseObtenerComprobantePagoCEP> ObtenerComprobantesPagoCEP(RequestObtenerComprobantePagoCEP request)
        {
            //List<ResponseObtenerComprobantePagoCEP> lstCEP = null;
            try
            {
                return new TransferenciaDAO().ObtenerComprobantesPagoCEP(request);
            }
            catch (FaultException ef)
            {
                ExceptionObtenerComprobantePagoCEP exceptionObtenerComprobantePagoCEP = new ExceptionObtenerComprobantePagoCEP();
                exceptionObtenerComprobantePagoCEP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionObtenerComprobantePagoCEP.Descripcion = ef.Message;
                exceptionObtenerComprobantePagoCEP.Mensaje = ef.Message;
                throw new FaultException<ExceptionObtenerComprobantePagoCEP>(exceptionObtenerComprobantePagoCEP);
            }
        }

        public ResponseObtenerComprobantePago ObtenerComprobantesPago(RequestObtenerComprobantePago request)
        {
            try
            {

                Bitacora<RequestObtenerComprobantePago> b = new Bitacora<RequestObtenerComprobantePago>(request.NumeroSocio.ToString(), request, "ResponseTransferenciasCuentasPropias");
                new Logg().Info(SerializerManager<Bitacora<RequestObtenerComprobantePago>>.SerealizarObjtecToString(b));
                //string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new TransferenciaDAO().ObtenerComprobantesPago(request);
            }
            catch (FaultException<ExceptionObtenerComprobantePago> exG)
            {
                throw exG;
            }
            /*para validar otp
             * catch (FaultException ef)
            {
                ExceptionTransferenciasCuentasPropias exceptionValidaOTP = new ExceptionTransferenciasCuentasPropias();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionTransferenciasCuentasPropias> Bex = new Bitacora<ExceptionTransferenciasCuentasPropias>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionTransferenciasCuentasPropias>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionTransferenciasCuentasPropias>(exceptionValidaOTP);
            }*/
            catch (Exception ex)
            {
                ExceptionObtenerComprobantePago exceptionAltaCuentaExternaClabe = new ExceptionObtenerComprobantePago();
                exceptionAltaCuentaExternaClabe.Codigo = 1000;
                exceptionAltaCuentaExternaClabe.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionAltaCuentaExternaClabe.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerComprobantePago> Bex = new Bitacora<ExceptionObtenerComprobantePago>(request.NumeroSocio.ToString(), exceptionAltaCuentaExternaClabe, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerComprobantePago>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerComprobantePago>(exceptionAltaCuentaExternaClabe);
            }
        }

        public ResponseObtenerComprobantePagoPDF ObtenerComprobantesPagoPDF(RequestObtenerComprobantePagoPDF request)
        {
            try
            {
                return new TransferenciaDAO().ObtenerComprobantesPagoPDF(request);
            }
            catch (FaultException<ExceptionObtenerComprobantePago> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerComprobantePagoPDF exceptionObtenerComprobantePagoPDF = new ExceptionObtenerComprobantePagoPDF();
                exceptionObtenerComprobantePagoPDF.Codigo = 1000;
                exceptionObtenerComprobantePagoPDF.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerComprobantePagoPDF.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerComprobantePagoPDF> Bex = new Bitacora<ExceptionObtenerComprobantePagoPDF>(request.NumeroSocio.ToString(), exceptionObtenerComprobantePagoPDF, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerComprobantePagoPDF>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerComprobantePagoPDF>(exceptionObtenerComprobantePagoPDF);
            }
        }


        public ResponseObtenerComprobantePagoServicios ObtenerComprobantesPagoServicios(RequestObtenerComprobantePagoServicios request)
        {
            try
            {
                return new TransferenciaDAO().ObtenerComprobantesPagoServicios(request);
            }
            catch (FaultException ef)
            {
                ExceptionObtenerComprobantePagoServicios exception = new ExceptionObtenerComprobantePagoServicios();
                exception.Codigo = Convert.ToInt32(ef.Code.Name);
                exception.Descripcion = ef.Message;
                exception.Mensaje = ef.Message;
                throw new FaultException<ExceptionObtenerComprobantePagoServicios>(exception);
            }
            catch (Exception ex)
            {
                ExceptionObtenerComprobantePagoServicios exception = new ExceptionObtenerComprobantePagoServicios();
                exception.Codigo = 1000;
                exception.Descripcion = Utilerias.ExcepcionDebug(ex);
                exception.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerComprobantePagoServicios>(exception);
            }

        }

        public ResponseObtenerComprobantePagoServicioPDF ObtenerComprobantesPagoServicioPDF(RequestObtenerComprobantePagoServicioPDF request)
        {
            try
            {
                return new TransferenciaDAO().ObtenerComprobantesPagoServicioPDF(request);
            }
            catch (FaultException<ExceptionObtenerComprobantePagoServicioPDF> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerComprobantePagoServicioPDF exceptionObtenerComprobantePagoServicioPDF = new ExceptionObtenerComprobantePagoServicioPDF();
                exceptionObtenerComprobantePagoServicioPDF.Codigo = 1000;
                exceptionObtenerComprobantePagoServicioPDF.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerComprobantePagoServicioPDF.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                
                throw new FaultException<ExceptionObtenerComprobantePagoServicioPDF>(exceptionObtenerComprobantePagoServicioPDF);
            }
        }


        #region Obtener proximas transferencias  y pagos programados
        public ResponseObtenerProximasTransferenciasProgramadas ObtenerProximasTransferenciasProgramadas(RequestObtenerProximasTransferenciasProgramadas request)
        {
            try
            {
                return new TransferenciaDAO().ObtenerProximasTransferenciasProgramadas(request);
            }
            catch (FaultException<ExceptionObtenerProximasTransferenciasProgramadas> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerProximasTransferenciasProgramadas exceptionObtenerProximasTransferenciasProgramadas = new ExceptionObtenerProximasTransferenciasProgramadas();
                exceptionObtenerProximasTransferenciasProgramadas.Codigo = 1000;
                exceptionObtenerProximasTransferenciasProgramadas.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerProximasTransferenciasProgramadas.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerProximasTransferenciasProgramadas>(exceptionObtenerProximasTransferenciasProgramadas);
            }
        }

        public ResponseObtenerProximosPagosProgramados ObtenerProximosPagosProgramadas(RequestObtenerProximosPagosProgramados request)
        {
            try
            {
                return new TransferenciaDAO().ObtenerProximosPagosProgramadas(request);
            }
            catch (FaultException<ExceptionObtenerProximosPagosProgramadas> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerProximosPagosProgramadas exceptionObtenerComprobantePagoPDF = new ExceptionObtenerProximosPagosProgramadas();
                exceptionObtenerComprobantePagoPDF.Codigo = 1000;
                exceptionObtenerComprobantePagoPDF.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerComprobantePagoPDF.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerProximosPagosProgramadas>(exceptionObtenerComprobantePagoPDF);
            }
        }
        #endregion
    }
}
