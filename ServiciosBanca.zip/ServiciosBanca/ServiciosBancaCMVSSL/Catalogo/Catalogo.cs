﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ServiciosBancaDAO;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils.Logg;
using ServiciosBancaEntidades;
using ServiciosBancaUtils;
using ServiciosBancaEntidades.Autenticacion;

namespace ServiciosBancaCMV.Catalogo
{
    [CustomBehavior]
    public class Catalogo : ICatalogo
    {
        public List<ResponseObtenerBancos> ObtenerBancos(RequestObtenerBancos request)
        {
            try
            {
                  return new CatalogoDAO().ObtenerBancos(request);
            }
            catch (FaultException<ExceptionObtenerBancos> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerBancos exceptionObtenerBancos = new ExceptionObtenerBancos();
                exceptionObtenerBancos.Codigo = 1000;
                exceptionObtenerBancos.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerBancos.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerBancos>(exceptionObtenerBancos);
            }
        }
        public List<ResponseObtenerCatalogoPreguntas> ObtenerCatalogoPreguntas()
        {
            try
            {

                return new CatalogoDAO().ObtenerCatalogoPreguntas();
            }
            catch (FaultException<ExceptionObtenerCatalogoPreguntas> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerCatalogoPreguntas exceptionObtenerCatalogoPreguntas = new ExceptionObtenerCatalogoPreguntas();
                exceptionObtenerCatalogoPreguntas.Codigo = 1000;
                exceptionObtenerCatalogoPreguntas.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerCatalogoPreguntas.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerCatalogoPreguntas>(exceptionObtenerCatalogoPreguntas);
            }
        }
        public ResponseObtenerCategoriasServicios ObtenerCategoriasServicios(RequestObtenerCategoriasServicios request )
        {
            try
            {
                new  Logg().Info("Obteniendo Categoras para pago de servicios");
                return new CatalogoDAO().ObtenerCategorias(request);
            }
            catch (FaultException<ExceptionObtenerCategoriasServicios> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerCategoriasServicios exceptionObtenerCategoriasServicios = new ExceptionObtenerCategoriasServicios();
                exceptionObtenerCategoriasServicios.Codigo = 1000;
                exceptionObtenerCategoriasServicios.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerCategoriasServicios.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerCategoriasServicios>(exceptionObtenerCategoriasServicios);
            }
        }
        public ResponseObtenerProductos ObtenerProductos(RequestObtenerProductos request)
        {
            try
            {
                return new CatalogoDAO().ObtenerProductos(request);
            }
            catch (FaultException<ExceptionObtenerProductos> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerProductos exceptionObtenerProductos = new ExceptionObtenerProductos();
                exceptionObtenerProductos.Codigo = 1000;
                exceptionObtenerProductos.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerProductos.Mensaje = ex.Message;
                throw new FaultException<ExceptionObtenerProductos>(exceptionObtenerProductos);
            }
        }
        public ResponseObtenerServicios ObtenerServicios(RequestObtenerServicios request)
        {
            try
            {

                Bitacora<RequestObtenerServicios> b = new Bitacora<RequestObtenerServicios>(" ObtenerServicios ", request);
                new Logg().Info(SerializerManager<Bitacora<RequestObtenerServicios>>.SerealizarObjtecToString(b));

                return new CatalogoDAO().ObtenerServicios(request);
            }
            catch (FaultException<ExceptionObtenerCategoriasServicios> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerServicios exceptionObtenerServicios = new ExceptionObtenerServicios();
                exceptionObtenerServicios.Codigo = 1000;
                exceptionObtenerServicios.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerServicios.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerServicios>(exceptionObtenerServicios);
            }
        }
        public ResponseObtenerServiciosRecurrentes ObtenerServiciosRecurrentes(RequestObtenerServiciosRecurrentes request)
        {
            try
            {
                //new Logg().Info(" ObtenerServiciosRecurrentes ");
                return new CatalogoDAO().ObtenerServiciosRecurrentes();
            }
            catch (FaultException<ExceptionObtenerServiciosRecurrentes> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerServiciosRecurrentes exceptionObtenerServiciosRecurrentes = new ExceptionObtenerServiciosRecurrentes();
                exceptionObtenerServiciosRecurrentes.Codigo = 1000;
                exceptionObtenerServiciosRecurrentes.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerServiciosRecurrentes.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerServiciosRecurrentes>(exceptionObtenerServiciosRecurrentes);
            }
            
        }
        public ResponseObtenerServiciosDomiciliadosRecurrentes ObtenerServiciosDomiciliadosRecurrentes()
        {
            try
            {
                //new Logg().Info(" ExceptionObtenerServiciosDomiciliadosRecurrentes ");
                return new CatalogoDAO().ObtenerServiciosDomiciliadosRecurrentes();
            }
            catch (FaultException<ExceptionObtenerServiciosDomiciliadosRecurrentes> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerServiciosDomiciliadosRecurrentes exceptionObtenerServiciosDomiciliadosRecurrentes = new ExceptionObtenerServiciosDomiciliadosRecurrentes();
                exceptionObtenerServiciosDomiciliadosRecurrentes.Codigo = 1000;
                exceptionObtenerServiciosDomiciliadosRecurrentes.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerServiciosDomiciliadosRecurrentes.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerServiciosDomiciliadosRecurrentes>(exceptionObtenerServiciosDomiciliadosRecurrentes);
            }

        }
        public ResponseObtenerProductosConsultaSaldo ObtenerProductosConsultaSaldo(RequestObtenerProductosConsultaSaldo request)
        {
            try
            {
                return new CatalogoDAO().ObtenerProductosConsultaSaldo(request);
            }
            catch (FaultException<ExceptionObtenerProductosConsultaSaldo> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerProductosConsultaSaldo exception = new ExceptionObtenerProductosConsultaSaldo();
                exception.Codigo = 1000;
                exception.Descripcion = Utilerias.ExcepcionDebug(ex);
                exception.Mensaje = ex.Message;
                throw new FaultException<ExceptionObtenerProductosConsultaSaldo>(exception);
            }
        }
        #region Inversiones
        public ResponseObtenerTasaInversion ObtenerTasaInversion(RequestObtenerTasaInversion request)
        {
            try
            {
                new Logg().Info(" ObtenerTasaInversion ");
                return new CatalogoDAO().ObtenerTasaInversion(request);
            }
            catch (FaultException<ExceptionObtenerTasaInversion> exG)
            {
                //new Logg().Error(SerializerManager<ExceptionObtenerTasaInversion>.SerealizarObjtecToString(exG.Detail));
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerTasaInversion exceptionObtenerTasaInversion = new ExceptionObtenerTasaInversion();
                exceptionObtenerTasaInversion.Codigo = 1000;
                exceptionObtenerTasaInversion.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerTasaInversion.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                new Logg().Error(SerializerManager<ExceptionObtenerTasaInversion>.SerealizarObjtecToString(exceptionObtenerTasaInversion));
                throw new FaultException<ExceptionObtenerTasaInversion>(exceptionObtenerTasaInversion);
            }
        }

        public ResponseObtenerProductosInversion ObtenerProductosInversion()
        {
            try
            {
                new Logg().Info(" ObtenerProductosInversion ");
                return new CatalogoDAO().ObtenerProductosInversion();
            }
            catch (FaultException<ExceptionObtenerProductosInversion> exG)
            {
                new Logg().Error(SerializerManager<ExceptionObtenerProductosInversion>.SerealizarObjtecToString(exG.Detail));
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerProductosInversion exceptionObtenerServiciosRecurrentes = new ExceptionObtenerProductosInversion();
                exceptionObtenerServiciosRecurrentes.Codigo = 1000;
                exceptionObtenerServiciosRecurrentes.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerServiciosRecurrentes.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                new Logg().Error(SerializerManager<ExceptionObtenerProductosInversion>.SerealizarObjtecToString(exceptionObtenerServiciosRecurrentes));
                throw new FaultException<ExceptionObtenerProductosInversion>(exceptionObtenerServiciosRecurrentes);
            }
        }

        #endregion

        public ResponseObtenerPeriodicidad ObtenerPeriodicidad()
        {
            try
            {
                new Logg().Info(" ObtenerPeriodicidad ");
                return new CatalogoDAO().ObtenerPeriodicidad();
            }
            catch (Exception ex)
            {
                ExceptionObtenerProductosInversion exceptionObtenerServiciosRecurrentes = new ExceptionObtenerProductosInversion();
                exceptionObtenerServiciosRecurrentes.Codigo = 1000;
                exceptionObtenerServiciosRecurrentes.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerServiciosRecurrentes.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                new Logg().Error(SerializerManager<ExceptionObtenerProductosInversion>.SerealizarObjtecToString(exceptionObtenerServiciosRecurrentes));
                throw new FaultException<ExceptionObtenerProductosInversion>(exceptionObtenerServiciosRecurrentes);
            }

        }

        public ResponseObtenerBancoClabeSPEI ObtenerBancoClabeSPEI(RequestObtenerBancoClabeSPEI request)
        {
            try
            {
                new Logg().Info(" ObtenerBancoClabeSPEI ");
                return new CatalogoDAO().ObtenerBancoClabeSPEI(request);
            }
            catch (FaultException<ExceptionObtenerBancoClabeSPEI> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerBancoClabeSPEI exception = new ExceptionObtenerBancoClabeSPEI();
                exception.Codigo = 1000;
                exception.Descripcion = Utilerias.ExcepcionDebug(ex);
                exception.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                new Logg().Error(SerializerManager<ExceptionObtenerBancoClabeSPEI>.SerealizarObjtecToString(exception));
                throw new FaultException<ExceptionObtenerBancoClabeSPEI>(exception);
            }
        }
    }
}
