﻿using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosBancaCMV.Catalogo
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "ICatalogo" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface ICatalogo
    {
        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerCatalogoPreguntas))]
        List <ResponseObtenerCatalogoPreguntas> ObtenerCatalogoPreguntas();

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerBancos))]
        List<ResponseObtenerBancos> ObtenerBancos(RequestObtenerBancos request);

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerPeriodicidad))]
        ResponseObtenerPeriodicidad ObtenerPeriodicidad();


        #region Pago de servicios

            [OperationContract]
            [FaultContract(typeof(ExceptionObtenerCategoriasServicios))]
            ResponseObtenerCategoriasServicios ObtenerCategoriasServicios(RequestObtenerCategoriasServicios request);
       
            [OperationContract]
            [FaultContract(typeof(ExceptionObtenerServicios))]
            ResponseObtenerServicios ObtenerServicios(RequestObtenerServicios request);//recibe idCategoria

            [OperationContract]
            [FaultContract(typeof(ExceptionObtenerProductos))]
            ResponseObtenerProductos ObtenerProductos(RequestObtenerProductos request);//recibe idServicio

            [OperationContract]
            [FaultContract(typeof(ExceptionObtenerServiciosRecurrentes))]
            ResponseObtenerServiciosRecurrentes ObtenerServiciosRecurrentes(RequestObtenerServiciosRecurrentes request);//recibe idServicio

            [OperationContract]
            [FaultContract(typeof(ExceptionObtenerServiciosRecurrentes))]
            ResponseObtenerServiciosDomiciliadosRecurrentes ObtenerServiciosDomiciliadosRecurrentes();


            [OperationContract]
            [FaultContract(typeof(ExceptionObtenerProductosConsultaSaldo))]
            ResponseObtenerProductosConsultaSaldo ObtenerProductosConsultaSaldo(RequestObtenerProductosConsultaSaldo request);
        #endregion

        #region Inversiones
        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerProductosInversion))]
        ResponseObtenerProductosInversion ObtenerProductosInversion();

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerTasaInversion))]
        ResponseObtenerTasaInversion ObtenerTasaInversion(RequestObtenerTasaInversion request );
        #endregion

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerBancoClabeSPEI))]
        ResponseObtenerBancoClabeSPEI ObtenerBancoClabeSPEI(RequestObtenerBancoClabeSPEI request);
    }
}
