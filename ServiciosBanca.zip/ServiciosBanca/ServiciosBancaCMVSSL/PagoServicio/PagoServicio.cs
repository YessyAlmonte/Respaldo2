﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaEntidades;
using ServiciosBancaUtils.Logg;
using ServiciosBancaUtils;
using ServiciosBancaDAO;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.PagoDeServicios;
using BusCrypto;
using System.Net;
using ServiciosBancaEntidades.Autenticacion;
using GestoPago;
using AutoMapper;
using System.ServiceModel.Channels;
using ServiciosBancaCMVSSL;


namespace ServiciosBancaCMV.PagoServicio
{
    [CustomBehavior]
    public class PagoServicio : IPagoServicio
    {
        public ResponseConsultaSaldo ConsultaSaldo(RequestConsultaSaldo request)
        {
            ResponseConsultaSaldo responseConsultaSaldo = null;
            ServiciosBancaCMVSSL.WsPagoDeServicios._ResponseConsultaSaldo wsResponse = null;
            try
            {

                if (request.Monto != (request.MontoComision + request.Precio))
                {
                    ExceptionPagarServicios exceptionPagarServicios = new ExceptionPagarServicios();
                    exceptionPagarServicios.Codigo = 413;
                    exceptionPagarServicios.Mensaje = "Ocurrio un problema al consultar el saldo, por favor verifique los montos";
                    throw new FaultException<ExceptionPagarServicios>(exceptionPagarServicios); ;
                }

                AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);// SE VALIDA EL OTP
                PagoServicioDAO pagoServicioDAO = new PagoServicioDAO();
                responseConsultaSaldo = new ResponseConsultaSaldo();

                //MAPPER PARA LA  INSERTAR LA CONSULTA DE SALDO EN LA TABLA DE TRANSFERENCIAS
                Mapper.Initialize(x => { x.CreateMap<RequestConsultaSaldo, RequestPagarServicios>(); });
                RequestPagarServicios requestPagarServicios = Mapper.Map<RequestPagarServicios>(request);
                Mapper.Reset();

                //INSERTAMOS EN LA TABLA DE TRANSFERENCIAS DE PAGO
                Producto p = pagoServicioDAO.RealizarPagoServicio(requestPagarServicios, true);
                requestPagarServicios.FolioBanca = p.FolioBanca;

                //INSTANCIAMOS UN OBJETO DEL WEB SERVICE
                ServiciosBancaCMVSSL.WsPagoDeServicios.PagoDeServiciosClient wsPagoServicos = new ServiciosBancaCMVSSL.WsPagoDeServicios.PagoDeServiciosClient();

                //MAPPER PARA CONSUMIR EL WEB SERVICE
                Mapper.Initialize(x =>
                {
                    x.ValidateInlineMaps = false;
                    x.CreateMap<RequestPagarServicios, ServiciosBancaCMVSSL.WsPagoDeServicios.RequestPagarServicios>();
                });
                ServiciosBancaCMVSSL.WsPagoDeServicios.RequestPagarServicios wsRequest = Mapper.Map<ServiciosBancaCMVSSL.WsPagoDeServicios.RequestPagarServicios>(request);
                Mapper.Reset();

                //SE CONSUME EL WEB SERVICE DE GESTO  DE PAGO DE SERVICIO
                using (new OperationContextScope(wsPagoServicos.InnerChannel))
                {
                    MessageHeader MessageHeaderUsuario = MessageHeader.CreateHeader("Usuario", "", "CMVF1nZ4S");
                    MessageHeader MessageHeaderContrasena = MessageHeader.CreateHeader("Contrasena", "", "8DED40B6E19F14D1651FDDF063CDD2");
                    OperationContext.Current.OutgoingMessageHeaders.Add(MessageHeaderUsuario);
                    OperationContext.Current.OutgoingMessageHeaders.Add(MessageHeaderContrasena);
                    wsResponse = wsPagoServicos.ConsultarSaldoSerivicio(wsRequest);
                }

                if (wsResponse != null)
                {
                    if (wsResponse.EstatusCmv == ServiciosBancaCMVSSL.WsPagoDeServicios.EstatusCMV.Ok)
                    {
                        responseConsultaSaldo.Saldo = string.IsNullOrEmpty(wsResponse.ResponseAbonar.MENSAJE.SALDOCLIENTE) ? 0.0M : Convert.ToDecimal(wsResponse.ResponseAbonar.MENSAJE.SALDOCLIENTE);
                        responseConsultaSaldo.IdProducto = request.IdProducto;
                        responseConsultaSaldo.IdServicio = request.IdServicio;
                        requestPagarServicios.response = wsResponse.response;
                        requestPagarServicios.request = wsResponse.request;
                        requestPagarServicios.Codigo = wsResponse.ResponseAbonar.MENSAJE.CODIGO.ToString();
                        requestPagarServicios.FolioAutorizacion = wsResponse.ResponseAbonar.NUM_AUTORIZACION.ToString();
                        requestPagarServicios.Mensaje = string.IsNullOrEmpty(wsResponse.ResponseAbonar.MENSAJE.TEXTO) ? wsResponse.MensajeCmv : wsResponse.ResponseAbonar.MENSAJE.TEXTO;
                        requestPagarServicios.signed = wsResponse.Signed;
                        responseConsultaSaldo.Mensaje = requestPagarServicios.Mensaje;
                        pagoServicioDAO.ActualizarPagoDeServicio(requestPagarServicios);
                    }
                    else
                    {
                        ExceptionConsultaSaldo exceptionConsultaSaldo = new ExceptionConsultaSaldo();
                        exceptionConsultaSaldo.Codigo = 412;
                        exceptionConsultaSaldo.Mensaje = "Consulta de servicio no disponible.";
                        requestPagarServicios.response = wsResponse.MensajeCmv;
                        requestPagarServicios.request = wsResponse.request;
                        pagoServicioDAO.InsertarPagoServicioPendiente(requestPagarServicios);
                        throw new FaultException<ExceptionConsultaSaldo>(exceptionConsultaSaldo);
                    }
                }
            }
            catch (FaultException<ServiciosBancaCMVSSL.WsPagoDeServicios._ExceptionPagarServicios> e)
            {
                //excepcion detonada por el web service 
                ExceptionConsultaSaldo exceptionConsultaSaldo = new ExceptionConsultaSaldo();
                exceptionConsultaSaldo.Codigo = e.Detail.Codigo;
                exceptionConsultaSaldo.Mensaje = "El error no se encuentra en un catálogo definido por CMV (verificar conexion GestoPago)" + e.Detail.Mensaje;
                throw new FaultException<ExceptionConsultaSaldo>(exceptionConsultaSaldo); ;
            }
            catch (FaultException<ExceptionConsultaSaldo> exG)
            {
                throw exG;
            }
            catch (FaultException<ExceptionPagarServicios> exG)
            {
                ExceptionConsultaSaldo exceptionConsultaSaldo = new ExceptionConsultaSaldo();
                exceptionConsultaSaldo.Codigo = exG.Detail.Codigo;
                exceptionConsultaSaldo.Mensaje = exG.Detail.Mensaje;
                throw new FaultException<ExceptionConsultaSaldo>(exceptionConsultaSaldo); ;
            }
            catch (FaultException ef)
            {
                //excepcion detonada por OTP
                ExceptionConsultaSaldo exceptionValidaOTP = new ExceptionConsultaSaldo();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Mensaje = ef.Message;
                throw new FaultException<ExceptionConsultaSaldo>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                //excepcion no controlada
                ExceptionConsultaSaldo exceptionConsultaSaldo = new ExceptionConsultaSaldo();
                exceptionConsultaSaldo.Codigo = 1000;
                exceptionConsultaSaldo.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionConsultaSaldo.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionConsultaSaldo>(exceptionConsultaSaldo);
            }
            return responseConsultaSaldo;
        }

        public ResponsePagarServicios PagarServicio(ServiciosBancaEntidades.Requests.RequestPagarServicios request)
        {
            ResponsePagarServicios responsePagarServicios = null;
            PagoServicioDAO pagoServicioDAO = null;
            ServiciosBancaCMVSSL.WsPagoDeServicios._ResponsePagarServicios wsResponse = null;
            try
            {
                AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);// SE VALIDA EL OTP
                pagoServicioDAO = new PagoServicioDAO();
                request.ObtenerParametros();//validamos que los parametros monto , referencia ,telefono sean correctos segun el tipoFront

                //SE AFECTA LOS HABERES DEL SOCIO EN CASO DE QUE EXISTA UN ERROR AL TRATA DE AFECAR EDO_DE_CUENTA , MOVIMIENTO Y CAPTUTA SE LANZA UNA EXCEPTION
                Producto p = pagoServicioDAO.RealizarPagoServicio(request, false);
                request.FolioBanca = p.FolioBanca;
                //SE CONSUME EL WEB SERVICE DE GESTO  DEL PAGO DE SERVICIO
                request.Telefono = p.necesitaPin ? "#1111111111" : request.Telefono;
                request.NumeroReferencia = request.NumeroReferencia.Equals("0") ? "" : request.NumeroReferencia;
                ServiciosBancaCMVSSL.WsPagoDeServicios.PagoDeServiciosClient wsPagoServicos = new ServiciosBancaCMVSSL.WsPagoDeServicios.PagoDeServiciosClient();
                Mapper.Initialize(x => { x.CreateMap<RequestPagarServicios, ServiciosBancaCMVSSL.WsPagoDeServicios.RequestPagarServicios>(); });
                ServiciosBancaCMVSSL.WsPagoDeServicios.RequestPagarServicios wsRequest = Mapper.Map<ServiciosBancaCMVSSL.WsPagoDeServicios.RequestPagarServicios>(request);
                Mapper.Reset();
                using (new OperationContextScope(wsPagoServicos.InnerChannel))
                {
                    MessageHeader MessageHeaderUsuario = MessageHeader.CreateHeader("Usuario", "", "CMVF1nZ4S");
                    MessageHeader MessageHeaderContrasena = MessageHeader.CreateHeader("Contrasena", "", "8DED40B6E19F14D1651FDDF063CDD2");
                    OperationContext.Current.OutgoingMessageHeaders.Add(MessageHeaderUsuario);
                    OperationContext.Current.OutgoingMessageHeaders.Add(MessageHeaderContrasena);
                    wsResponse = wsPagoServicos.PagarServicio(wsRequest);
                }
                if (wsResponse != null)
                {

                    if (wsResponse.EstatusCmv == ServiciosBancaCMVSSL.WsPagoDeServicios.EstatusCMV.Ok)
                    {
                        request.Pin = Convert.ToString(wsResponse.ResponseAbonar.MENSAJE.PIN);
                        request.FolioAutorizacion = wsResponse.ResponseAbonar.NUM_AUTORIZACION.ToString() + " " + ((string.IsNullOrEmpty(request.Pin) || request.Pin.Equals("0")) ? string.Empty : "Codigo de Activación: " + request.Pin);
                        request.Mensaje = wsResponse.ResponseAbonar.MENSAJE.TEXTO;
                        request.Codigo = wsResponse.ResponseAbonar.MENSAJE.CODIGO.ToString();
                        /*if (request.Codigo.ToString().Equals("4"))
                        {
                            request.Codigo = "1";
                            request.Mensaje = "Transacción realizada exitosamente";
                        }*/
                        request.response = wsResponse.response;
                        request.request = wsResponse.request;
                        request.signed = wsResponse.signed;
                        responsePagarServicios = pagoServicioDAO.ActualizarPagoDeServicio(request);
                        responsePagarServicios.Leyenda = p.Leyenda;

                    }
                    else
                    {
                        ExceptionPagarServicios exceptionPagarServicios = new ExceptionPagarServicios();
                        exceptionPagarServicios.Codigo = 411;
                        exceptionPagarServicios.Mensaje = "Pago de servicio pendiente por aplicar, por favor revise su pago mas tarde.";
                        request.response = wsResponse.MensajeCmv;
                        request.request = wsResponse.request;
                        request.signed = wsResponse.signed;
                        pagoServicioDAO.InsertarPagoServicioPendiente(request);
                        throw new FaultException<ExceptionPagarServicios>(exceptionPagarServicios);
                    }
                }
            }
            catch (FaultException<ServiciosBancaCMVSSL.WsPagoDeServicios._ExceptionPagarServicios> e)
            {
                //excepcion detonada por el web service 
                request.Codigo = "-1";
                request.Mensaje = "Ocurrio un error en la Api de Gesto pago desarrollada por CMV:| " + e.Message;
                pagoServicioDAO.ActualizarPagoDeServicio(request);
                //ExceptionPagarServicios exceptionPagarServicios = new ExceptionPagarServicios();
                //exceptionPagarServicios.Codigo = e.Detail.Codigo;
                //exceptionPagarServicios.Mensaje = "El error no se encuentra en un catálogo definido por CMV" + e.Detail.Mensaje;
                //throw new FaultException<ExceptionPagarServicios>(exceptionPagarServicios);
            }
            catch (FaultException<ExceptionPagarServicios> exG)
            {
                //request.Codigo = "-1";
                //request.Mensaje = "Ocurrio un error funcion :PagarServicio()  CMV:| " + exG.Message+" | "+exG.Source;
                //pagoServicioDAO.ActualizarPagoDeServicio(request);
                throw exG;
            }
            catch (FaultException ef)
            {
                //excepcion detonada por OTP
                ExceptionPagarServicios exceptionValidaOTP = new ExceptionPagarServicios();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Mensaje = ef.Message;
                throw new FaultException<ExceptionPagarServicios>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                request.Codigo = "-1";
                request.Mensaje = "Ocurrio un error funcion :PagarServicio()  CMV| " + ex.Message;
                pagoServicioDAO.ActualizarPagoDeServicio(request);
                //excepcion no controlada
                ExceptionPagarServicios exceptionPagarServicios = new ExceptionPagarServicios();
                exceptionPagarServicios.Codigo = 1000;
                exceptionPagarServicios.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionPagarServicios.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionPagarServicios>(exceptionPagarServicios);
            }
            return responsePagarServicios;
        }

       

        public ResponseRegistrarServicio RegistrarServicio(RequestRegistrarServicio request)
        {
            try
            {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new PagoServicioDAO().RegistrarServicio(request);

            }
            catch (FaultException<ExceptionRegistrarServicio> exG)
            {
                throw exG;
            }
            catch (FaultException exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionRegistrarServicio exceptionRegistrarServicio = new ExceptionRegistrarServicio();
                exceptionRegistrarServicio.Codigo = 1000;
                exceptionRegistrarServicio.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionRegistrarServicio.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionRegistrarServicio> Bex = new Bitacora<ExceptionRegistrarServicio>(request.NumeroSocio.ToString(), exceptionRegistrarServicio, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionRegistrarServicio>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionRegistrarServicio>(exceptionRegistrarServicio);
            }
        }
    }
}
