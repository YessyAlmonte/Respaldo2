﻿using System.Windows.Forms;

namespace ClienteServiciosBancaCMV
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.TabPrincipal = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btnValidaNumero = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbNumeroSocioValidaNumero = new System.Windows.Forms.TextBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.btnIniciarSesion = new System.Windows.Forms.Button();
            this.tbContrasenaIniciarSesion = new System.Windows.Forms.TextBox();
            this.tbNumeroSocioIniciarSesion = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.btnObtenerInformacionSocio = new System.Windows.Forms.Button();
            this.tbNumeroSocioObtenerInformacionSocio = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.btnActualizarEstatus = new System.Windows.Forms.Button();
            this.tbEstatusActualizarEstatus = new System.Windows.Forms.TextBox();
            this.tbNumeroSocioActualizarEstatus = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.btnValidaContrasenaTemporal = new System.Windows.Forms.Button();
            this.tbContrasenaTemporalValidaContrasenaTemporal = new System.Windows.Forms.TextBox();
            this.tbNumeroSocioValidaContrasenaTemporal = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.btnActivarBanca = new System.Windows.Forms.Button();
            this.tbRespuestaActivarBanca = new System.Windows.Forms.TextBox();
            this.tbConfirmaContrasenaActivarBanca = new System.Windows.Forms.TextBox();
            this.tbContrasenaActivarBanca = new System.Windows.Forms.TextBox();
            this.tbNumeroSocioActivarBanca = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.tbOTPCambiarContrasena = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.btnCambiarContrasena = new System.Windows.Forms.Button();
            this.tbConfirmarContrasenaCambiarContrasena = new System.Windows.Forms.TextBox();
            this.tbNuevaContrasenaCambiarContrasena = new System.Windows.Forms.TextBox();
            this.tbNumeroSocioCambiarContrasena = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.tabPage41 = new System.Windows.Forms.TabPage();
            this.btnObtenerPreguntaSecreta1 = new System.Windows.Forms.Button();
            this.txtNumeroSocioPreguntaSecreta1 = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.tabPage42 = new System.Windows.Forms.TabPage();
            this.btnRegistrarServicio1 = new System.Windows.Forms.Button();
            this.tbNumeroSocioRegistrarServicio1 = new System.Windows.Forms.TextBox();
            this.tbPrecioRegistrarServicio1 = new System.Windows.Forms.TextBox();
            this.tbTipoFrontRegistrarServicio1 = new System.Windows.Forms.TextBox();
            this.tbNumeroReferenciaRegistrarServicio1 = new System.Windows.Forms.TextBox();
            this.tbTelefonoRegistrarServicio1 = new System.Windows.Forms.TextBox();
            this.tbIdServicioRegistrarServicio1 = new System.Windows.Forms.TextBox();
            this.tbIdProductoRegistrarServicio1 = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.btnRealizarInversion = new System.Windows.Forms.Button();
            this.label88 = new System.Windows.Forms.Label();
            this.txtOTPInver = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.txtTasaInversion = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.txtMontoInversion = new System.Windows.Forms.TextBox();
            this.txtDiasInversion = new System.Windows.Forms.TextBox();
            this.txtNumeroInversion = new System.Windows.Forms.TextBox();
            this.tabPage44 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.tbOTPBloqueoTemporal = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.cbMotivoBloqueoBloqueoTemporal = new System.Windows.Forms.ComboBox();
            this.btnBloqueoTemporal = new System.Windows.Forms.Button();
            this.tbNumeroSocioBloqueoTemporal = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage28 = new System.Windows.Forms.TabPage();
            this.btnDesbloqueoTemporalDB = new System.Windows.Forms.Button();
            this.tbNumeroSocioDesbloqueoTemporalDB = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.tabPage31 = new System.Windows.Forms.TabPage();
            this.btnBloqueoTemporalDB1 = new System.Windows.Forms.Button();
            this.tbNumeroSocioBloqueoTemporalDB = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.btnObtenerCatalogoPreguntas = new System.Windows.Forms.Button();
            this.tabPage29 = new System.Windows.Forms.TabPage();
            this.btnObtenerBancos = new System.Windows.Forms.Button();
            this.tabPage36 = new System.Windows.Forms.TabPage();
            this.btnObtenerCategorias = new System.Windows.Forms.Button();
            this.tabPage37 = new System.Windows.Forms.TabPage();
            this.label63 = new System.Windows.Forms.Label();
            this.btnObtenerServicios = new System.Windows.Forms.Button();
            this.tbObtenerServicio = new System.Windows.Forms.TextBox();
            this.tabPage38 = new System.Windows.Forms.TabPage();
            this.btnObtenerProductos = new System.Windows.Forms.Button();
            this.label64 = new System.Windows.Forms.Label();
            this.tbObtenerProductos = new System.Windows.Forms.TextBox();
            this.tabPage43 = new System.Windows.Forms.TabPage();
            this.btnObtenerServiciosRecurrentes = new System.Windows.Forms.Button();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.tabControl6 = new System.Windows.Forms.TabControl();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.btnObtenerCuentas = new System.Windows.Forms.Button();
            this.tbObtenerCuentas = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.label26 = new System.Windows.Forms.Label();
            this.txtNoContratoObDetalleCuenta = new System.Windows.Forms.TextBox();
            this.txtIdCuentaObDetalleCuenta = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.btnObtenerDetalleCuenta = new System.Windows.Forms.Button();
            this.txtNumeroObDetalleCuenta = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.cbIdMovObtenerMovimientosCuenta = new System.Windows.Forms.ComboBox();
            this.tbNumeroSocioObtenerMovimientosCuenta = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.cbPeriodoObtenerMovimientosCuenta = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.BtnObtenerMovimientosCuentas = new System.Windows.Forms.Button();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.tabControl7 = new System.Windows.Forms.TabControl();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.btAprovisionarToken = new System.Windows.Forms.Button();
            this.btNumeroSocioAprovisionarToken = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.btnValidaOTP = new System.Windows.Forms.Button();
            this.tbOTPValidaOTP = new System.Windows.Forms.TextBox();
            this.tbNumeroSocioValidaOTP = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.tabImagenes = new System.Windows.Forms.TabPage();
            this.tabControl8 = new System.Windows.Forms.TabControl();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.btEnviarImagenFondo = new System.Windows.Forms.Button();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.tabControl9 = new System.Windows.Forms.TabControl();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.tbClabeAltaCuentasInternas = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.tbOTPAltaCuentasInternas = new System.Windows.Forms.TextBox();
            this.tbCorreoAltaCuentasInternas = new System.Windows.Forms.TextBox();
            this.tbMontoAltaCuentasInternas = new System.Windows.Forms.TextBox();
            this.tbAliasAltaCuentasInternas = new System.Windows.Forms.TextBox();
            this.tbIdCuentaAltaCuentasInternas = new System.Windows.Forms.TextBox();
            this.tbNumeroSocioBeneficiarioAltaCuentasInternas = new System.Windows.Forms.TextBox();
            this.tbNumeroSocioAltaCuentasInternas = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.btnAltaCuentaInterna = new System.Windows.Forms.Button();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage26 = new System.Windows.Forms.TabPage();
            this.tbIdCuentaExtenaAltaCuentasExternasClabes = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.tbOTPAltaCuentasExternasClabes = new System.Windows.Forms.TextBox();
            this.tbCURPAltaCuentasExternasClabes = new System.Windows.Forms.TextBox();
            this.tbRFCAltaCuentasExternasClabes = new System.Windows.Forms.TextBox();
            this.tbCorreoAltaCuentasExternasClabes = new System.Windows.Forms.TextBox();
            this.tbMontoAltaCuentasExternasClabes = new System.Windows.Forms.TextBox();
            this.tbAliasAltaCuentasExternasClabes = new System.Windows.Forms.TextBox();
            this.tbClabeAltaCuentasExternasClabes = new System.Windows.Forms.TextBox();
            this.tbNombreBeneficiarioAltaCuentasExternasClabes = new System.Windows.Forms.TextBox();
            this.tbNumeroSocioAltaCuentasExternasClabes = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.btnAltaCuentasExternasClabes = new System.Windows.Forms.Button();
            this.CURP = new System.Windows.Forms.Label();
            this.RFC = new System.Windows.Forms.Label();
            this.Correo = new System.Windows.Forms.Label();
            this.Monto = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.tabPage27 = new System.Windows.Forms.TabPage();
            this.txtOTPAlExDeb = new System.Windows.Forms.TextBox();
            this.txtCURPAlExDeb = new System.Windows.Forms.TextBox();
            this.txtCorreoAlExDeb = new System.Windows.Forms.TextBox();
            this.txtMontoAlExDeb = new System.Windows.Forms.TextBox();
            this.txtAliasAlExDeb = new System.Windows.Forms.TextBox();
            this.txtNumeroTarjetaAlExDeb = new System.Windows.Forms.TextBox();
            this.txtBeneficiarioAlExDeb = new System.Windows.Forms.TextBox();
            this.txtNoSocAlExDeb = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.btnAltaCtaExtDebito = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.tabPage30 = new System.Windows.Forms.TabPage();
            this.btnEliminaCuentaInterna = new System.Windows.Forms.Button();
            this.tbOTPEliminaCuentaInterna = new System.Windows.Forms.TextBox();
            this.tbIdCuentaEliminaCuentaInterna = new System.Windows.Forms.TextBox();
            this.tbNumeroSocioEliminaCuentaInterna = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.tabPage32 = new System.Windows.Forms.TabPage();
            this.btnEliminaCuentaClabe = new System.Windows.Forms.Button();
            this.tbOTPEliminaCuentaClabe = new System.Windows.Forms.TextBox();
            this.tbIdCuentaEliminaCuentaClabe = new System.Windows.Forms.TextBox();
            this.tbNumeroSocioEliminaCuentaClabe = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.tabPage33 = new System.Windows.Forms.TabPage();
            this.btnObtenerCuentasRetiroInternas = new System.Windows.Forms.Button();
            this.tbNumeroSocioObtenerCuentasRetiroInternas = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.tabPage34 = new System.Windows.Forms.TabPage();
            this.btnObtenerCuentasDepositoInternas = new System.Windows.Forms.Button();
            this.cbTipoCuentaObtenerCuentasDepositoInternas = new System.Windows.Forms.ComboBox();
            this.tbNumeroSocioObtenerCuentasDepositoInternas = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.tabPage35 = new System.Windows.Forms.TabPage();
            this.btnObtenerCuentasDepositoExternas = new System.Windows.Forms.Button();
            this.tbNumeroSocioObtenerCuentasDepositoExternas = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.tabPage39 = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage40 = new System.Windows.Forms.TabPage();
            this.btnRegistrarServicio = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tbPrecioRegistrarServicio = new System.Windows.Forms.TextBox();
            this.tbTipoFrontRegistrarServicio = new System.Windows.Forms.TextBox();
            this.tbNumeroReferenciaRegistrarServicio = new System.Windows.Forms.TextBox();
            this.tbTelefonoRegistrarServicio = new System.Windows.Forms.TextBox();
            this.tbIdServicioRegistrarServicio = new System.Windows.Forms.TextBox();
            this.tbIdProductoRegistrarServicio = new System.Windows.Forms.TextBox();
            this.tbNumeroSocioRegistrarServicio = new System.Windows.Forms.Label();
            this.label701 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label681 = new System.Windows.Forms.Label();
            this.label671 = new System.Windows.Forms.Label();
            this.label651 = new System.Windows.Forms.Label();
            this.tabPage411 = new System.Windows.Forms.TabPage();
            this.btnEliminarServicio = new System.Windows.Forms.Button();
            this.tbNumeroSocioEliminarServicio = new System.Windows.Forms.TextBox();
            this.tbIdServicioEliminarServicio = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.btnObtenerPreguntaSecreta = new System.Windows.Forms.Button();
            this.txtNumeroSocioPreguntaSecreta = new System.Windows.Forms.TextBox();
            this.tabPagarServicio = new System.Windows.Forms.TabPage();
            this.tabControl10 = new System.Windows.Forms.TabControl();
            this.tabPage45 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.cbCategoria = new System.Windows.Forms.ComboBox();
            this.cbServicios = new System.Windows.Forms.ComboBox();
            this.cbProductos = new System.Windows.Forms.ComboBox();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.txtReferencia = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.txtMonto = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.btnPagarServicio = new System.Windows.Forms.Button();
            this.lbl21654 = new System.Windows.Forms.Label();
            this.txtNumeroSocioPagoServicio = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblRespuesta = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.TabPrincipal.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabPage22.SuspendLayout();
            this.tabPage41.SuspendLayout();
            this.tabPage42.SuspendLayout();
            this.tabPage21.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.tabPage28.SuspendLayout();
            this.tabPage31.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabPage29.SuspendLayout();
            this.tabPage36.SuspendLayout();
            this.tabPage37.SuspendLayout();
            this.tabPage38.SuspendLayout();
            this.tabPage43.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabControl6.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.tabPage18.SuspendLayout();
            this.tabControl7.SuspendLayout();
            this.tabPage19.SuspendLayout();
            this.tabPage20.SuspendLayout();
            this.tabImagenes.SuspendLayout();
            this.tabControl8.SuspendLayout();
            this.tabPage23.SuspendLayout();
            this.tabPage24.SuspendLayout();
            this.tabControl9.SuspendLayout();
            this.tabPage25.SuspendLayout();
            this.tabPage26.SuspendLayout();
            this.tabPage27.SuspendLayout();
            this.tabPage30.SuspendLayout();
            this.tabPage32.SuspendLayout();
            this.tabPage33.SuspendLayout();
            this.tabPage34.SuspendLayout();
            this.tabPage35.SuspendLayout();
            this.tabPage39.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage40.SuspendLayout();
            this.tabPage411.SuspendLayout();
            this.tabPagarServicio.SuspendLayout();
            this.tabControl10.SuspendLayout();
            this.tabPage45.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.TabPrincipal, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 182F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(856, 475);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // TabPrincipal
            // 
            this.TabPrincipal.Controls.Add(this.tabPage1);
            this.TabPrincipal.Controls.Add(this.tabPage2);
            this.TabPrincipal.Controls.Add(this.tabPage3);
            this.TabPrincipal.Controls.Add(this.tabPage4);
            this.TabPrincipal.Controls.Add(this.tabPage14);
            this.TabPrincipal.Controls.Add(this.tabPage18);
            this.TabPrincipal.Controls.Add(this.tabImagenes);
            this.TabPrincipal.Controls.Add(this.tabPage24);
            this.TabPrincipal.Controls.Add(this.tabPage39);
            this.TabPrincipal.Controls.Add(this.tabPagarServicio);
            this.TabPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabPrincipal.Location = new System.Drawing.Point(3, 3);
            this.TabPrincipal.Name = "TabPrincipal";
            this.TabPrincipal.SelectedIndex = 0;
            this.TabPrincipal.Size = new System.Drawing.Size(850, 287);
            this.TabPrincipal.TabIndex = 0;
            this.TabPrincipal.SelectedIndexChanged += new System.EventHandler(this.btnBloqueoTemporalDB_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(842, 261);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sesión";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(836, 255);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.btnValidaNumero);
            this.tabPage5.Controls.Add(this.label1);
            this.tabPage5.Controls.Add(this.tbNumeroSocioValidaNumero);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(828, 229);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Valida Número";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // btnValidaNumero
            // 
            this.btnValidaNumero.Location = new System.Drawing.Point(224, 97);
            this.btnValidaNumero.Name = "btnValidaNumero";
            this.btnValidaNumero.Size = new System.Drawing.Size(75, 23);
            this.btnValidaNumero.TabIndex = 2;
            this.btnValidaNumero.Text = "Enviar";
            this.btnValidaNumero.UseVisualStyleBackColor = true;
            this.btnValidaNumero.Click += new System.EventHandler(this.btnValidaNumero_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(90, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Numero de Socio";
            // 
            // tbNumeroSocioValidaNumero
            // 
            this.tbNumeroSocioValidaNumero.Location = new System.Drawing.Point(197, 21);
            this.tbNumeroSocioValidaNumero.Name = "tbNumeroSocioValidaNumero";
            this.tbNumeroSocioValidaNumero.Size = new System.Drawing.Size(129, 20);
            this.tbNumeroSocioValidaNumero.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.btnIniciarSesion);
            this.tabPage6.Controls.Add(this.tbContrasenaIniciarSesion);
            this.tabPage6.Controls.Add(this.tbNumeroSocioIniciarSesion);
            this.tabPage6.Controls.Add(this.label3);
            this.tabPage6.Controls.Add(this.label2);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(654, 229);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Autenticar Socio";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // btnIniciarSesion
            // 
            this.btnIniciarSesion.Location = new System.Drawing.Point(231, 112);
            this.btnIniciarSesion.Name = "btnIniciarSesion";
            this.btnIniciarSesion.Size = new System.Drawing.Size(100, 23);
            this.btnIniciarSesion.TabIndex = 4;
            this.btnIniciarSesion.Text = "Enviar";
            this.btnIniciarSesion.UseVisualStyleBackColor = true;
            this.btnIniciarSesion.Click += new System.EventHandler(this.btnIniciarSesion_Click);
            // 
            // tbContrasenaIniciarSesion
            // 
            this.tbContrasenaIniciarSesion.Location = new System.Drawing.Point(231, 68);
            this.tbContrasenaIniciarSesion.Name = "tbContrasenaIniciarSesion";
            this.tbContrasenaIniciarSesion.Size = new System.Drawing.Size(100, 20);
            this.tbContrasenaIniciarSesion.TabIndex = 3;
            // 
            // tbNumeroSocioIniciarSesion
            // 
            this.tbNumeroSocioIniciarSesion.Location = new System.Drawing.Point(231, 30);
            this.tbNumeroSocioIniciarSesion.Name = "tbNumeroSocioIniciarSesion";
            this.tbNumeroSocioIniciarSesion.Size = new System.Drawing.Size(100, 20);
            this.tbNumeroSocioIniciarSesion.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(71, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Contraseña";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(71, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Numero de Socio";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tabControl3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(842, 261);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Socio";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage7);
            this.tabControl3.Controls.Add(this.tabPage8);
            this.tabControl3.Controls.Add(this.tabPage9);
            this.tabControl3.Controls.Add(this.tabPage10);
            this.tabControl3.Controls.Add(this.tabPage11);
            this.tabControl3.Controls.Add(this.tabPage22);
            this.tabControl3.Controls.Add(this.tabPage41);
            this.tabControl3.Controls.Add(this.tabPage42);
            this.tabControl3.Controls.Add(this.tabPage21);
            this.tabControl3.Controls.Add(this.tabPage44);
            this.tabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl3.Location = new System.Drawing.Point(3, 3);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(836, 255);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.btnObtenerInformacionSocio);
            this.tabPage7.Controls.Add(this.tbNumeroSocioObtenerInformacionSocio);
            this.tabPage7.Controls.Add(this.label4);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(828, 229);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "Obtener Informacion Socio";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // btnObtenerInformacionSocio
            // 
            this.btnObtenerInformacionSocio.Location = new System.Drawing.Point(215, 97);
            this.btnObtenerInformacionSocio.Name = "btnObtenerInformacionSocio";
            this.btnObtenerInformacionSocio.Size = new System.Drawing.Size(100, 23);
            this.btnObtenerInformacionSocio.TabIndex = 3;
            this.btnObtenerInformacionSocio.Text = "Enviar";
            this.btnObtenerInformacionSocio.UseVisualStyleBackColor = true;
            this.btnObtenerInformacionSocio.Click += new System.EventHandler(this.btnObtenerInformacionSocio_Click);
            // 
            // tbNumeroSocioObtenerInformacionSocio
            // 
            this.tbNumeroSocioObtenerInformacionSocio.Location = new System.Drawing.Point(215, 25);
            this.tbNumeroSocioObtenerInformacionSocio.Name = "tbNumeroSocioObtenerInformacionSocio";
            this.tbNumeroSocioObtenerInformacionSocio.Size = new System.Drawing.Size(100, 20);
            this.tbNumeroSocioObtenerInformacionSocio.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(86, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Numero de Socio";
            // 
            // tabPage8
            // 
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(828, 229);
            this.tabPage8.TabIndex = 1;
            this.tabPage8.Text = "Registrar Socio";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.btnActualizarEstatus);
            this.tabPage9.Controls.Add(this.tbEstatusActualizarEstatus);
            this.tabPage9.Controls.Add(this.tbNumeroSocioActualizarEstatus);
            this.tabPage9.Controls.Add(this.label6);
            this.tabPage9.Controls.Add(this.label5);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(828, 229);
            this.tabPage9.TabIndex = 2;
            this.tabPage9.Text = "Actualizar Estatus";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // btnActualizarEstatus
            // 
            this.btnActualizarEstatus.Location = new System.Drawing.Point(246, 110);
            this.btnActualizarEstatus.Name = "btnActualizarEstatus";
            this.btnActualizarEstatus.Size = new System.Drawing.Size(75, 23);
            this.btnActualizarEstatus.TabIndex = 4;
            this.btnActualizarEstatus.Text = "Enviar";
            this.btnActualizarEstatus.UseVisualStyleBackColor = true;
            this.btnActualizarEstatus.Click += new System.EventHandler(this.btnActualizarEstatus_Click);
            // 
            // tbEstatusActualizarEstatus
            // 
            this.tbEstatusActualizarEstatus.Location = new System.Drawing.Point(213, 63);
            this.tbEstatusActualizarEstatus.Name = "tbEstatusActualizarEstatus";
            this.tbEstatusActualizarEstatus.Size = new System.Drawing.Size(149, 20);
            this.tbEstatusActualizarEstatus.TabIndex = 3;
            // 
            // tbNumeroSocioActualizarEstatus
            // 
            this.tbNumeroSocioActualizarEstatus.Location = new System.Drawing.Point(213, 20);
            this.tbNumeroSocioActualizarEstatus.Name = "tbNumeroSocioActualizarEstatus";
            this.tbNumeroSocioActualizarEstatus.Size = new System.Drawing.Size(149, 20);
            this.tbNumeroSocioActualizarEstatus.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(89, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Estatus";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(89, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Numero de Socio";
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.btnValidaContrasenaTemporal);
            this.tabPage10.Controls.Add(this.tbContrasenaTemporalValidaContrasenaTemporal);
            this.tabPage10.Controls.Add(this.tbNumeroSocioValidaContrasenaTemporal);
            this.tabPage10.Controls.Add(this.label8);
            this.tabPage10.Controls.Add(this.label7);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(828, 229);
            this.tabPage10.TabIndex = 3;
            this.tabPage10.Text = "Valida Contraseña Temporal";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // btnValidaContrasenaTemporal
            // 
            this.btnValidaContrasenaTemporal.Location = new System.Drawing.Point(270, 106);
            this.btnValidaContrasenaTemporal.Name = "btnValidaContrasenaTemporal";
            this.btnValidaContrasenaTemporal.Size = new System.Drawing.Size(75, 23);
            this.btnValidaContrasenaTemporal.TabIndex = 4;
            this.btnValidaContrasenaTemporal.Text = "Enviar";
            this.btnValidaContrasenaTemporal.UseVisualStyleBackColor = true;
            this.btnValidaContrasenaTemporal.Click += new System.EventHandler(this.btnValidaContrasenaTemporal_Click);
            // 
            // tbContrasenaTemporalValidaContrasenaTemporal
            // 
            this.tbContrasenaTemporalValidaContrasenaTemporal.Location = new System.Drawing.Point(232, 61);
            this.tbContrasenaTemporalValidaContrasenaTemporal.Name = "tbContrasenaTemporalValidaContrasenaTemporal";
            this.tbContrasenaTemporalValidaContrasenaTemporal.Size = new System.Drawing.Size(140, 20);
            this.tbContrasenaTemporalValidaContrasenaTemporal.TabIndex = 3;
            // 
            // tbNumeroSocioValidaContrasenaTemporal
            // 
            this.tbNumeroSocioValidaContrasenaTemporal.Location = new System.Drawing.Point(232, 14);
            this.tbNumeroSocioValidaContrasenaTemporal.Name = "tbNumeroSocioValidaContrasenaTemporal";
            this.tbNumeroSocioValidaContrasenaTemporal.Size = new System.Drawing.Size(140, 20);
            this.tbNumeroSocioValidaContrasenaTemporal.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(71, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Contraseña Temporal";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(71, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Numero de Socio";
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.btnActivarBanca);
            this.tabPage11.Controls.Add(this.tbRespuestaActivarBanca);
            this.tabPage11.Controls.Add(this.tbConfirmaContrasenaActivarBanca);
            this.tabPage11.Controls.Add(this.tbContrasenaActivarBanca);
            this.tabPage11.Controls.Add(this.tbNumeroSocioActivarBanca);
            this.tabPage11.Controls.Add(this.label13);
            this.tabPage11.Controls.Add(this.label12);
            this.tabPage11.Controls.Add(this.label11);
            this.tabPage11.Controls.Add(this.label10);
            this.tabPage11.Controls.Add(this.label9);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Size = new System.Drawing.Size(828, 229);
            this.tabPage11.TabIndex = 4;
            this.tabPage11.Text = "Activar Banca";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // btnActivarBanca
            // 
            this.btnActivarBanca.Location = new System.Drawing.Point(192, 122);
            this.btnActivarBanca.Name = "btnActivarBanca";
            this.btnActivarBanca.Size = new System.Drawing.Size(97, 23);
            this.btnActivarBanca.TabIndex = 9;
            this.btnActivarBanca.Text = "Enviar";
            this.btnActivarBanca.UseVisualStyleBackColor = true;
            this.btnActivarBanca.Click += new System.EventHandler(this.btnActivarBanca_Click);
            // 
            // tbRespuestaActivarBanca
            // 
            this.tbRespuestaActivarBanca.Location = new System.Drawing.Point(313, 44);
            this.tbRespuestaActivarBanca.Name = "tbRespuestaActivarBanca";
            this.tbRespuestaActivarBanca.Size = new System.Drawing.Size(122, 20);
            this.tbRespuestaActivarBanca.TabIndex = 8;
            // 
            // tbConfirmaContrasenaActivarBanca
            // 
            this.tbConfirmaContrasenaActivarBanca.Location = new System.Drawing.Point(112, 78);
            this.tbConfirmaContrasenaActivarBanca.Name = "tbConfirmaContrasenaActivarBanca";
            this.tbConfirmaContrasenaActivarBanca.Size = new System.Drawing.Size(122, 20);
            this.tbConfirmaContrasenaActivarBanca.TabIndex = 7;
            // 
            // tbContrasenaActivarBanca
            // 
            this.tbContrasenaActivarBanca.Location = new System.Drawing.Point(112, 44);
            this.tbContrasenaActivarBanca.Name = "tbContrasenaActivarBanca";
            this.tbContrasenaActivarBanca.Size = new System.Drawing.Size(122, 20);
            this.tbContrasenaActivarBanca.TabIndex = 6;
            // 
            // tbNumeroSocioActivarBanca
            // 
            this.tbNumeroSocioActivarBanca.Location = new System.Drawing.Point(112, 9);
            this.tbNumeroSocioActivarBanca.Name = "tbNumeroSocioActivarBanca";
            this.tbNumeroSocioActivarBanca.Size = new System.Drawing.Size(122, 20);
            this.tbNumeroSocioActivarBanca.TabIndex = 5;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(249, 44);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(58, 13);
            this.label13.TabIndex = 4;
            this.label13.Text = "Respuesta";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(249, 12);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "Pregunta";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(108, 13);
            this.label11.TabIndex = 2;
            this.label11.Text = "Confirmar Contraseña";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 44);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 13);
            this.label10.TabIndex = 1;
            this.label10.Text = "Contraseña";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 12);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Numero de Socio";
            // 
            // tabPage22
            // 
            this.tabPage22.Controls.Add(this.tbOTPCambiarContrasena);
            this.tabPage22.Controls.Add(this.label39);
            this.tabPage22.Controls.Add(this.label30);
            this.tabPage22.Controls.Add(this.label29);
            this.tabPage22.Controls.Add(this.btnCambiarContrasena);
            this.tabPage22.Controls.Add(this.tbConfirmarContrasenaCambiarContrasena);
            this.tabPage22.Controls.Add(this.tbNuevaContrasenaCambiarContrasena);
            this.tabPage22.Controls.Add(this.tbNumeroSocioCambiarContrasena);
            this.tabPage22.Controls.Add(this.label27);
            this.tabPage22.Location = new System.Drawing.Point(4, 22);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Size = new System.Drawing.Size(828, 229);
            this.tabPage22.TabIndex = 5;
            this.tabPage22.Text = "Cambiar Contraseña";
            this.tabPage22.UseVisualStyleBackColor = true;
            // 
            // tbOTPCambiarContrasena
            // 
            this.tbOTPCambiarContrasena.Location = new System.Drawing.Point(225, 94);
            this.tbOTPCambiarContrasena.Name = "tbOTPCambiarContrasena";
            this.tbOTPCambiarContrasena.Size = new System.Drawing.Size(133, 20);
            this.tbOTPCambiarContrasena.TabIndex = 12;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(77, 94);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(29, 13);
            this.label39.TabIndex = 11;
            this.label39.Text = "OTP";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(77, 45);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(96, 13);
            this.label30.TabIndex = 10;
            this.label30.Text = "Nueva Contraseña";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(77, 23);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(89, 13);
            this.label29.TabIndex = 9;
            this.label29.Text = "Numero de Socio";
            // 
            // btnCambiarContrasena
            // 
            this.btnCambiarContrasena.Location = new System.Drawing.Point(262, 138);
            this.btnCambiarContrasena.Name = "btnCambiarContrasena";
            this.btnCambiarContrasena.Size = new System.Drawing.Size(75, 23);
            this.btnCambiarContrasena.TabIndex = 8;
            this.btnCambiarContrasena.Text = "Enviar";
            this.btnCambiarContrasena.UseVisualStyleBackColor = true;
            this.btnCambiarContrasena.Click += new System.EventHandler(this.btnCambiarContrasena_Click);
            // 
            // tbConfirmarContrasenaCambiarContrasena
            // 
            this.tbConfirmarContrasenaCambiarContrasena.Location = new System.Drawing.Point(225, 68);
            this.tbConfirmarContrasenaCambiarContrasena.Name = "tbConfirmarContrasenaCambiarContrasena";
            this.tbConfirmarContrasenaCambiarContrasena.Size = new System.Drawing.Size(133, 20);
            this.tbConfirmarContrasenaCambiarContrasena.TabIndex = 6;
            // 
            // tbNuevaContrasenaCambiarContrasena
            // 
            this.tbNuevaContrasenaCambiarContrasena.Location = new System.Drawing.Point(225, 42);
            this.tbNuevaContrasenaCambiarContrasena.Name = "tbNuevaContrasenaCambiarContrasena";
            this.tbNuevaContrasenaCambiarContrasena.Size = new System.Drawing.Size(133, 20);
            this.tbNuevaContrasenaCambiarContrasena.TabIndex = 5;
            // 
            // tbNumeroSocioCambiarContrasena
            // 
            this.tbNumeroSocioCambiarContrasena.Location = new System.Drawing.Point(225, 17);
            this.tbNumeroSocioCambiarContrasena.Name = "tbNumeroSocioCambiarContrasena";
            this.tbNumeroSocioCambiarContrasena.Size = new System.Drawing.Size(133, 20);
            this.tbNumeroSocioCambiarContrasena.TabIndex = 4;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(77, 68);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(108, 13);
            this.label27.TabIndex = 2;
            this.label27.Text = "Confirmar Contraseña";
            // 
            // tabPage41
            // 
            this.tabPage41.Controls.Add(this.btnObtenerPreguntaSecreta1);
            this.tabPage41.Controls.Add(this.txtNumeroSocioPreguntaSecreta1);
            this.tabPage41.Controls.Add(this.label65);
            this.tabPage41.Location = new System.Drawing.Point(4, 22);
            this.tabPage41.Name = "tabPage41";
            this.tabPage41.Size = new System.Drawing.Size(828, 229);
            this.tabPage41.TabIndex = 6;
            this.tabPage41.Text = "Obtener Pregunta S";
            this.tabPage41.UseVisualStyleBackColor = true;
            // 
            // btnObtenerPreguntaSecreta1
            // 
            this.btnObtenerPreguntaSecreta1.Location = new System.Drawing.Point(239, 112);
            this.btnObtenerPreguntaSecreta1.Name = "btnObtenerPreguntaSecreta1";
            this.btnObtenerPreguntaSecreta1.Size = new System.Drawing.Size(100, 23);
            this.btnObtenerPreguntaSecreta1.TabIndex = 6;
            this.btnObtenerPreguntaSecreta1.Text = "Enviar";
            this.btnObtenerPreguntaSecreta1.UseVisualStyleBackColor = true;
            this.btnObtenerPreguntaSecreta1.Click += new System.EventHandler(this.btnObtenerPreguntaSecreta_Click);
            // 
            // txtNumeroSocioPreguntaSecreta1
            // 
            this.txtNumeroSocioPreguntaSecreta1.Location = new System.Drawing.Point(239, 40);
            this.txtNumeroSocioPreguntaSecreta1.Name = "txtNumeroSocioPreguntaSecreta1";
            this.txtNumeroSocioPreguntaSecreta1.Size = new System.Drawing.Size(100, 20);
            this.txtNumeroSocioPreguntaSecreta1.TabIndex = 5;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(110, 40);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(89, 13);
            this.label65.TabIndex = 4;
            this.label65.Text = "Numero de Socio";
            // 
            // tabPage42
            // 
            this.tabPage42.Controls.Add(this.btnRegistrarServicio1);
            this.tabPage42.Controls.Add(this.tbNumeroSocioRegistrarServicio1);
            this.tabPage42.Controls.Add(this.tbPrecioRegistrarServicio1);
            this.tabPage42.Controls.Add(this.tbTipoFrontRegistrarServicio1);
            this.tabPage42.Controls.Add(this.tbNumeroReferenciaRegistrarServicio1);
            this.tabPage42.Controls.Add(this.tbTelefonoRegistrarServicio1);
            this.tabPage42.Controls.Add(this.tbIdServicioRegistrarServicio1);
            this.tabPage42.Controls.Add(this.tbIdProductoRegistrarServicio1);
            this.tabPage42.Controls.Add(this.label77);
            this.tabPage42.Controls.Add(this.label76);
            this.tabPage42.Controls.Add(this.label75);
            this.tabPage42.Controls.Add(this.label70);
            this.tabPage42.Controls.Add(this.label68);
            this.tabPage42.Controls.Add(this.label67);
            this.tabPage42.Controls.Add(this.label66);
            this.tabPage42.Location = new System.Drawing.Point(4, 22);
            this.tabPage42.Name = "tabPage42";
            this.tabPage42.Size = new System.Drawing.Size(828, 229);
            this.tabPage42.TabIndex = 7;
            this.tabPage42.Text = "Registrar Servicio";
            this.tabPage42.UseVisualStyleBackColor = true;
            // 
            // btnRegistrarServicio1
            // 
            this.btnRegistrarServicio1.Location = new System.Drawing.Point(287, 130);
            this.btnRegistrarServicio1.Name = "btnRegistrarServicio1";
            this.btnRegistrarServicio1.Size = new System.Drawing.Size(75, 23);
            this.btnRegistrarServicio1.TabIndex = 14;
            this.btnRegistrarServicio1.Text = "Enviar";
            this.btnRegistrarServicio1.UseVisualStyleBackColor = true;
            this.btnRegistrarServicio1.Click += new System.EventHandler(this.btnRegistrarServicio_Click);
            // 
            // tbNumeroSocioRegistrarServicio1
            // 
            this.tbNumeroSocioRegistrarServicio1.Location = new System.Drawing.Point(348, 76);
            this.tbNumeroSocioRegistrarServicio1.Name = "tbNumeroSocioRegistrarServicio1";
            this.tbNumeroSocioRegistrarServicio1.Size = new System.Drawing.Size(100, 20);
            this.tbNumeroSocioRegistrarServicio1.TabIndex = 13;
            // 
            // tbPrecioRegistrarServicio1
            // 
            this.tbPrecioRegistrarServicio1.Location = new System.Drawing.Point(348, 47);
            this.tbPrecioRegistrarServicio1.Name = "tbPrecioRegistrarServicio1";
            this.tbPrecioRegistrarServicio1.Size = new System.Drawing.Size(100, 20);
            this.tbPrecioRegistrarServicio1.TabIndex = 12;
            // 
            // tbTipoFrontRegistrarServicio1
            // 
            this.tbTipoFrontRegistrarServicio1.Location = new System.Drawing.Point(348, 19);
            this.tbTipoFrontRegistrarServicio1.Name = "tbTipoFrontRegistrarServicio1";
            this.tbTipoFrontRegistrarServicio1.Size = new System.Drawing.Size(100, 20);
            this.tbTipoFrontRegistrarServicio1.TabIndex = 11;
            // 
            // tbNumeroReferenciaRegistrarServicio1
            // 
            this.tbNumeroReferenciaRegistrarServicio1.Location = new System.Drawing.Point(132, 104);
            this.tbNumeroReferenciaRegistrarServicio1.Name = "tbNumeroReferenciaRegistrarServicio1";
            this.tbNumeroReferenciaRegistrarServicio1.Size = new System.Drawing.Size(100, 20);
            this.tbNumeroReferenciaRegistrarServicio1.TabIndex = 10;
            // 
            // tbTelefonoRegistrarServicio1
            // 
            this.tbTelefonoRegistrarServicio1.Location = new System.Drawing.Point(132, 71);
            this.tbTelefonoRegistrarServicio1.Name = "tbTelefonoRegistrarServicio1";
            this.tbTelefonoRegistrarServicio1.Size = new System.Drawing.Size(100, 20);
            this.tbTelefonoRegistrarServicio1.TabIndex = 9;
            // 
            // tbIdServicioRegistrarServicio1
            // 
            this.tbIdServicioRegistrarServicio1.Location = new System.Drawing.Point(132, 44);
            this.tbIdServicioRegistrarServicio1.Name = "tbIdServicioRegistrarServicio1";
            this.tbIdServicioRegistrarServicio1.Size = new System.Drawing.Size(100, 20);
            this.tbIdServicioRegistrarServicio1.TabIndex = 8;
            // 
            // tbIdProductoRegistrarServicio1
            // 
            this.tbIdProductoRegistrarServicio1.Location = new System.Drawing.Point(132, 19);
            this.tbIdProductoRegistrarServicio1.Name = "tbIdProductoRegistrarServicio1";
            this.tbIdProductoRegistrarServicio1.Size = new System.Drawing.Size(100, 20);
            this.tbIdProductoRegistrarServicio1.TabIndex = 7;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(253, 79);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(89, 13);
            this.label77.TabIndex = 6;
            this.label77.Text = "Numero de Socio";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(305, 47);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(37, 13);
            this.label76.TabIndex = 5;
            this.label76.Text = "Precio";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(294, 19);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(48, 13);
            this.label75.TabIndex = 4;
            this.label75.Text = "tipoFront";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(7, 104);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(114, 13);
            this.label70.TabIndex = 3;
            this.label70.Text = "Numero de Referencia";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(68, 79);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(49, 13);
            this.label68.TabIndex = 2;
            this.label68.Text = "Telefono";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(68, 47);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(53, 13);
            this.label67.TabIndex = 1;
            this.label67.Text = "idServicio";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(68, 19);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(58, 13);
            this.label66.TabIndex = 0;
            this.label66.Text = "idProducto";
            // 
            // tabPage21
            // 
            this.tabPage21.Controls.Add(this.btnRealizarInversion);
            this.tabPage21.Controls.Add(this.label88);
            this.tabPage21.Controls.Add(this.txtOTPInver);
            this.tabPage21.Controls.Add(this.label87);
            this.tabPage21.Controls.Add(this.txtTasaInversion);
            this.tabPage21.Controls.Add(this.label80);
            this.tabPage21.Controls.Add(this.label79);
            this.tabPage21.Controls.Add(this.label78);
            this.tabPage21.Controls.Add(this.txtMontoInversion);
            this.tabPage21.Controls.Add(this.txtDiasInversion);
            this.tabPage21.Controls.Add(this.txtNumeroInversion);
            this.tabPage21.Location = new System.Drawing.Point(4, 22);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage21.Size = new System.Drawing.Size(828, 229);
            this.tabPage21.TabIndex = 8;
            this.tabPage21.Text = "Realizar Inversion";
            this.tabPage21.UseVisualStyleBackColor = true;
            // 
            // btnRealizarInversion
            // 
            this.btnRealizarInversion.Location = new System.Drawing.Point(360, 22);
            this.btnRealizarInversion.Name = "btnRealizarInversion";
            this.btnRealizarInversion.Size = new System.Drawing.Size(124, 23);
            this.btnRealizarInversion.TabIndex = 10;
            this.btnRealizarInversion.Text = "Realizar Inversion";
            this.btnRealizarInversion.UseVisualStyleBackColor = true;
            this.btnRealizarInversion.Click += new System.EventHandler(this.btnRealizarInversion_Click);
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(43, 197);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(29, 13);
            this.label88.TabIndex = 9;
            this.label88.Text = "OTP";
            // 
            // txtOTPInver
            // 
            this.txtOTPInver.Location = new System.Drawing.Point(138, 190);
            this.txtOTPInver.Name = "txtOTPInver";
            this.txtOTPInver.Size = new System.Drawing.Size(100, 20);
            this.txtOTPInver.TabIndex = 8;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(43, 157);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(31, 13);
            this.label87.TabIndex = 7;
            this.label87.Text = "Tasa";
            // 
            // txtTasaInversion
            // 
            this.txtTasaInversion.Location = new System.Drawing.Point(138, 150);
            this.txtTasaInversion.Name = "txtTasaInversion";
            this.txtTasaInversion.Size = new System.Drawing.Size(100, 20);
            this.txtTasaInversion.TabIndex = 6;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(43, 69);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(28, 13);
            this.label80.TabIndex = 5;
            this.label80.Text = "Dias";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(43, 116);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(37, 13);
            this.label79.TabIndex = 4;
            this.label79.Text = "Monto";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(43, 33);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(44, 13);
            this.label78.TabIndex = 3;
            this.label78.Text = "Numero";
            // 
            // txtMontoInversion
            // 
            this.txtMontoInversion.Location = new System.Drawing.Point(138, 109);
            this.txtMontoInversion.Name = "txtMontoInversion";
            this.txtMontoInversion.Size = new System.Drawing.Size(100, 20);
            this.txtMontoInversion.TabIndex = 2;
            // 
            // txtDiasInversion
            // 
            this.txtDiasInversion.Location = new System.Drawing.Point(138, 66);
            this.txtDiasInversion.Name = "txtDiasInversion";
            this.txtDiasInversion.Size = new System.Drawing.Size(100, 20);
            this.txtDiasInversion.TabIndex = 1;
            // 
            // txtNumeroInversion
            // 
            this.txtNumeroInversion.Location = new System.Drawing.Point(138, 26);
            this.txtNumeroInversion.Name = "txtNumeroInversion";
            this.txtNumeroInversion.Size = new System.Drawing.Size(100, 20);
            this.txtNumeroInversion.TabIndex = 0;
            // 
            // tabPage44
            // 
            this.tabPage44.Location = new System.Drawing.Point(4, 22);
            this.tabPage44.Name = "tabPage44";
            this.tabPage44.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage44.Size = new System.Drawing.Size(828, 229);
            this.tabPage44.TabIndex = 9;
            this.tabPage44.Text = "Cancelar Inversion";
            this.tabPage44.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tabControl4);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(842, 261);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Bloqueo";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage12);
            this.tabControl4.Controls.Add(this.tabPage28);
            this.tabControl4.Controls.Add(this.tabPage31);
            this.tabControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl4.Location = new System.Drawing.Point(0, 0);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(842, 261);
            this.tabControl4.TabIndex = 0;
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.tbOTPBloqueoTemporal);
            this.tabPage12.Controls.Add(this.label48);
            this.tabPage12.Controls.Add(this.cbMotivoBloqueoBloqueoTemporal);
            this.tabPage12.Controls.Add(this.btnBloqueoTemporal);
            this.tabPage12.Controls.Add(this.tbNumeroSocioBloqueoTemporal);
            this.tabPage12.Controls.Add(this.label15);
            this.tabPage12.Controls.Add(this.label14);
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(834, 235);
            this.tabPage12.TabIndex = 0;
            this.tabPage12.Text = "Bloqueo Temporal";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // tbOTPBloqueoTemporal
            // 
            this.tbOTPBloqueoTemporal.Location = new System.Drawing.Point(207, 87);
            this.tbOTPBloqueoTemporal.Name = "tbOTPBloqueoTemporal";
            this.tbOTPBloqueoTemporal.Size = new System.Drawing.Size(124, 20);
            this.tbOTPBloqueoTemporal.TabIndex = 9;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(85, 95);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(29, 13);
            this.label48.TabIndex = 8;
            this.label48.Text = "OTP";
            // 
            // cbMotivoBloqueoBloqueoTemporal
            // 
            this.cbMotivoBloqueoBloqueoTemporal.AutoCompleteCustomSource.AddRange(new string[] {
            "Desbloqueado",
            "Bloqueo temporal por intentos fallidos",
            "Bloqueo temporal de acceso",
            "Bloqueo temporal a petición en sucursales"});
            this.cbMotivoBloqueoBloqueoTemporal.FormattingEnabled = true;
            this.cbMotivoBloqueoBloqueoTemporal.Items.AddRange(new object[] {
            "Desbloqueado",
            "Bloqueo temporal por intentos fallidos",
            "Bloqueo temporal de acceso",
            "Bloqueo temporal a petición en sucursales"});
            this.cbMotivoBloqueoBloqueoTemporal.Location = new System.Drawing.Point(207, 60);
            this.cbMotivoBloqueoBloqueoTemporal.Name = "cbMotivoBloqueoBloqueoTemporal";
            this.cbMotivoBloqueoBloqueoTemporal.Size = new System.Drawing.Size(237, 21);
            this.cbMotivoBloqueoBloqueoTemporal.TabIndex = 7;
            // 
            // btnBloqueoTemporal
            // 
            this.btnBloqueoTemporal.Location = new System.Drawing.Point(223, 130);
            this.btnBloqueoTemporal.Name = "btnBloqueoTemporal";
            this.btnBloqueoTemporal.Size = new System.Drawing.Size(89, 23);
            this.btnBloqueoTemporal.TabIndex = 6;
            this.btnBloqueoTemporal.Text = "Enviar";
            this.btnBloqueoTemporal.UseVisualStyleBackColor = true;
            this.btnBloqueoTemporal.Click += new System.EventHandler(this.btnBloqueoTemporal_Click);
            // 
            // tbNumeroSocioBloqueoTemporal
            // 
            this.tbNumeroSocioBloqueoTemporal.Location = new System.Drawing.Point(207, 20);
            this.tbNumeroSocioBloqueoTemporal.Name = "tbNumeroSocioBloqueoTemporal";
            this.tbNumeroSocioBloqueoTemporal.Size = new System.Drawing.Size(124, 20);
            this.tbNumeroSocioBloqueoTemporal.TabIndex = 4;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(82, 60);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(81, 13);
            this.label15.TabIndex = 2;
            this.label15.Text = "Motivo Bloqueo";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(82, 23);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(89, 13);
            this.label14.TabIndex = 1;
            this.label14.Text = "Numero de Socio";
            // 
            // tabPage28
            // 
            this.tabPage28.Controls.Add(this.btnDesbloqueoTemporalDB);
            this.tabPage28.Controls.Add(this.tbNumeroSocioDesbloqueoTemporalDB);
            this.tabPage28.Controls.Add(this.label40);
            this.tabPage28.Location = new System.Drawing.Point(4, 22);
            this.tabPage28.Name = "tabPage28";
            this.tabPage28.Size = new System.Drawing.Size(660, 235);
            this.tabPage28.TabIndex = 2;
            this.tabPage28.Text = "Desbloqueo Temporal DB";
            this.tabPage28.UseVisualStyleBackColor = true;
            // 
            // btnDesbloqueoTemporalDB
            // 
            this.btnDesbloqueoTemporalDB.Location = new System.Drawing.Point(223, 102);
            this.btnDesbloqueoTemporalDB.Name = "btnDesbloqueoTemporalDB";
            this.btnDesbloqueoTemporalDB.Size = new System.Drawing.Size(75, 23);
            this.btnDesbloqueoTemporalDB.TabIndex = 2;
            this.btnDesbloqueoTemporalDB.Text = "Enviar";
            this.btnDesbloqueoTemporalDB.UseVisualStyleBackColor = true;
            this.btnDesbloqueoTemporalDB.Click += new System.EventHandler(this.btnDesbloqueoTemporalDB_Click);
            // 
            // tbNumeroSocioDesbloqueoTemporalDB
            // 
            this.tbNumeroSocioDesbloqueoTemporalDB.Location = new System.Drawing.Point(181, 21);
            this.tbNumeroSocioDesbloqueoTemporalDB.Name = "tbNumeroSocioDesbloqueoTemporalDB";
            this.tbNumeroSocioDesbloqueoTemporalDB.Size = new System.Drawing.Size(172, 20);
            this.tbNumeroSocioDesbloqueoTemporalDB.TabIndex = 1;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(85, 21);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(89, 13);
            this.label40.TabIndex = 0;
            this.label40.Text = "Numero de Socio";
            // 
            // tabPage31
            // 
            this.tabPage31.Controls.Add(this.btnBloqueoTemporalDB1);
            this.tabPage31.Controls.Add(this.tbNumeroSocioBloqueoTemporalDB);
            this.tabPage31.Controls.Add(this.label55);
            this.tabPage31.Location = new System.Drawing.Point(4, 22);
            this.tabPage31.Name = "tabPage31";
            this.tabPage31.Size = new System.Drawing.Size(660, 235);
            this.tabPage31.TabIndex = 3;
            this.tabPage31.Text = "Bloqueo Temporal DB";
            this.tabPage31.UseVisualStyleBackColor = true;
            // 
            // btnBloqueoTemporalDB1
            // 
            this.btnBloqueoTemporalDB1.Location = new System.Drawing.Point(206, 112);
            this.btnBloqueoTemporalDB1.Name = "btnBloqueoTemporalDB1";
            this.btnBloqueoTemporalDB1.Size = new System.Drawing.Size(134, 23);
            this.btnBloqueoTemporalDB1.TabIndex = 2;
            this.btnBloqueoTemporalDB1.Text = "button1";
            this.btnBloqueoTemporalDB1.UseVisualStyleBackColor = true;
            this.btnBloqueoTemporalDB1.Click += new System.EventHandler(this.btnBloqueoTemporalDB1_Click);
            // 
            // tbNumeroSocioBloqueoTemporalDB
            // 
            this.tbNumeroSocioBloqueoTemporalDB.Location = new System.Drawing.Point(206, 31);
            this.tbNumeroSocioBloqueoTemporalDB.Name = "tbNumeroSocioBloqueoTemporalDB";
            this.tbNumeroSocioBloqueoTemporalDB.Size = new System.Drawing.Size(134, 20);
            this.tbNumeroSocioBloqueoTemporalDB.TabIndex = 1;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(78, 31);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(89, 13);
            this.label55.TabIndex = 0;
            this.label55.Text = "Numero de Socio";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.tabControl5);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(842, 261);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Catalogo";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabControl5
            // 
            this.tabControl5.Controls.Add(this.tabPage13);
            this.tabControl5.Controls.Add(this.tabPage29);
            this.tabControl5.Controls.Add(this.tabPage36);
            this.tabControl5.Controls.Add(this.tabPage37);
            this.tabControl5.Controls.Add(this.tabPage38);
            this.tabControl5.Controls.Add(this.tabPage43);
            this.tabControl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl5.Location = new System.Drawing.Point(0, 0);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(842, 261);
            this.tabControl5.TabIndex = 0;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.btnObtenerCatalogoPreguntas);
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(834, 235);
            this.tabPage13.TabIndex = 0;
            this.tabPage13.Text = "Obtener Catalogo Pregunta";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // btnObtenerCatalogoPreguntas
            // 
            this.btnObtenerCatalogoPreguntas.Location = new System.Drawing.Point(204, 58);
            this.btnObtenerCatalogoPreguntas.Name = "btnObtenerCatalogoPreguntas";
            this.btnObtenerCatalogoPreguntas.Size = new System.Drawing.Size(75, 23);
            this.btnObtenerCatalogoPreguntas.TabIndex = 0;
            this.btnObtenerCatalogoPreguntas.Text = "Enviar";
            this.btnObtenerCatalogoPreguntas.UseVisualStyleBackColor = true;
            this.btnObtenerCatalogoPreguntas.Click += new System.EventHandler(this.btnObtenerCatalogoPreguntas_Click);
            // 
            // tabPage29
            // 
            this.tabPage29.Controls.Add(this.btnObtenerBancos);
            this.tabPage29.Location = new System.Drawing.Point(4, 22);
            this.tabPage29.Name = "tabPage29";
            this.tabPage29.Size = new System.Drawing.Size(660, 235);
            this.tabPage29.TabIndex = 1;
            this.tabPage29.Text = "Obtener Bancos";
            this.tabPage29.UseVisualStyleBackColor = true;
            // 
            // btnObtenerBancos
            // 
            this.btnObtenerBancos.Location = new System.Drawing.Point(176, 54);
            this.btnObtenerBancos.Name = "btnObtenerBancos";
            this.btnObtenerBancos.Size = new System.Drawing.Size(75, 23);
            this.btnObtenerBancos.TabIndex = 0;
            this.btnObtenerBancos.Text = "Enviar";
            this.btnObtenerBancos.UseVisualStyleBackColor = true;
            this.btnObtenerBancos.Click += new System.EventHandler(this.btnObtenerBancos_Click);
            // 
            // tabPage36
            // 
            this.tabPage36.Controls.Add(this.btnObtenerCategorias);
            this.tabPage36.Location = new System.Drawing.Point(4, 22);
            this.tabPage36.Name = "tabPage36";
            this.tabPage36.Size = new System.Drawing.Size(660, 235);
            this.tabPage36.TabIndex = 2;
            this.tabPage36.Text = "Obtener Categorias";
            this.tabPage36.UseVisualStyleBackColor = true;
            // 
            // btnObtenerCategorias
            // 
            this.btnObtenerCategorias.Location = new System.Drawing.Point(181, 58);
            this.btnObtenerCategorias.Name = "btnObtenerCategorias";
            this.btnObtenerCategorias.Size = new System.Drawing.Size(75, 23);
            this.btnObtenerCategorias.TabIndex = 0;
            this.btnObtenerCategorias.Text = "Enviar";
            this.btnObtenerCategorias.UseVisualStyleBackColor = true;
            this.btnObtenerCategorias.Click += new System.EventHandler(this.btnObtenerCategorias_Click);
            // 
            // tabPage37
            // 
            this.tabPage37.Controls.Add(this.label63);
            this.tabPage37.Controls.Add(this.btnObtenerServicios);
            this.tabPage37.Controls.Add(this.tbObtenerServicio);
            this.tabPage37.Location = new System.Drawing.Point(4, 22);
            this.tabPage37.Name = "tabPage37";
            this.tabPage37.Size = new System.Drawing.Size(660, 235);
            this.tabPage37.TabIndex = 3;
            this.tabPage37.Text = "Obtener Servicios";
            this.tabPage37.UseVisualStyleBackColor = true;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(93, 25);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(64, 13);
            this.label63.TabIndex = 2;
            this.label63.Text = "Id Categoria";
            // 
            // btnObtenerServicios
            // 
            this.btnObtenerServicios.Location = new System.Drawing.Point(190, 82);
            this.btnObtenerServicios.Name = "btnObtenerServicios";
            this.btnObtenerServicios.Size = new System.Drawing.Size(100, 23);
            this.btnObtenerServicios.TabIndex = 1;
            this.btnObtenerServicios.Text = "Enviar";
            this.btnObtenerServicios.UseVisualStyleBackColor = true;
            this.btnObtenerServicios.Click += new System.EventHandler(this.btnObtenerServicios_Click);
            // 
            // tbObtenerServicio
            // 
            this.tbObtenerServicio.Location = new System.Drawing.Point(190, 22);
            this.tbObtenerServicio.Name = "tbObtenerServicio";
            this.tbObtenerServicio.Size = new System.Drawing.Size(100, 20);
            this.tbObtenerServicio.TabIndex = 0;
            // 
            // tabPage38
            // 
            this.tabPage38.Controls.Add(this.btnObtenerProductos);
            this.tabPage38.Controls.Add(this.label64);
            this.tabPage38.Controls.Add(this.tbObtenerProductos);
            this.tabPage38.Location = new System.Drawing.Point(4, 22);
            this.tabPage38.Name = "tabPage38";
            this.tabPage38.Size = new System.Drawing.Size(660, 235);
            this.tabPage38.TabIndex = 4;
            this.tabPage38.Text = "Obtener Productos";
            this.tabPage38.UseVisualStyleBackColor = true;
            // 
            // btnObtenerProductos
            // 
            this.btnObtenerProductos.Location = new System.Drawing.Point(195, 100);
            this.btnObtenerProductos.Name = "btnObtenerProductos";
            this.btnObtenerProductos.Size = new System.Drawing.Size(100, 23);
            this.btnObtenerProductos.TabIndex = 2;
            this.btnObtenerProductos.Text = "Enviar";
            this.btnObtenerProductos.UseVisualStyleBackColor = true;
            this.btnObtenerProductos.Click += new System.EventHandler(this.btnObtenerProductos_Click);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(105, 23);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(57, 13);
            this.label64.TabIndex = 1;
            this.label64.Text = "Id Servicio";
            // 
            // tbObtenerProductos
            // 
            this.tbObtenerProductos.Location = new System.Drawing.Point(195, 20);
            this.tbObtenerProductos.Name = "tbObtenerProductos";
            this.tbObtenerProductos.Size = new System.Drawing.Size(100, 20);
            this.tbObtenerProductos.TabIndex = 0;
            // 
            // tabPage43
            // 
            this.tabPage43.Controls.Add(this.btnObtenerServiciosRecurrentes);
            this.tabPage43.Location = new System.Drawing.Point(4, 22);
            this.tabPage43.Name = "tabPage43";
            this.tabPage43.Size = new System.Drawing.Size(660, 235);
            this.tabPage43.TabIndex = 5;
            this.tabPage43.Text = "Obtener Servicios Recurrentes";
            this.tabPage43.UseVisualStyleBackColor = true;
            // 
            // btnObtenerServiciosRecurrentes
            // 
            this.btnObtenerServiciosRecurrentes.Location = new System.Drawing.Point(206, 69);
            this.btnObtenerServiciosRecurrentes.Name = "btnObtenerServiciosRecurrentes";
            this.btnObtenerServiciosRecurrentes.Size = new System.Drawing.Size(75, 23);
            this.btnObtenerServiciosRecurrentes.TabIndex = 0;
            this.btnObtenerServiciosRecurrentes.Text = "Enviar";
            this.btnObtenerServiciosRecurrentes.UseVisualStyleBackColor = true;
            this.btnObtenerServiciosRecurrentes.Click += new System.EventHandler(this.btnObtenerServiciosRecurrentes_Click);
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.tabControl6);
            this.tabPage14.Location = new System.Drawing.Point(4, 22);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Size = new System.Drawing.Size(842, 261);
            this.tabPage14.TabIndex = 4;
            this.tabPage14.Text = "Cuenta";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // tabControl6
            // 
            this.tabControl6.Controls.Add(this.tabPage15);
            this.tabControl6.Controls.Add(this.tabPage16);
            this.tabControl6.Controls.Add(this.tabPage17);
            this.tabControl6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl6.Location = new System.Drawing.Point(0, 0);
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.SelectedIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(842, 261);
            this.tabControl6.TabIndex = 0;
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.btnObtenerCuentas);
            this.tabPage15.Controls.Add(this.tbObtenerCuentas);
            this.tabPage15.Controls.Add(this.label17);
            this.tabPage15.Location = new System.Drawing.Point(4, 22);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage15.Size = new System.Drawing.Size(834, 235);
            this.tabPage15.TabIndex = 0;
            this.tabPage15.Text = "Obtener Cuentas";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // btnObtenerCuentas
            // 
            this.btnObtenerCuentas.Location = new System.Drawing.Point(195, 125);
            this.btnObtenerCuentas.Name = "btnObtenerCuentas";
            this.btnObtenerCuentas.Size = new System.Drawing.Size(104, 23);
            this.btnObtenerCuentas.TabIndex = 2;
            this.btnObtenerCuentas.Text = "Enviar";
            this.btnObtenerCuentas.UseVisualStyleBackColor = true;
            this.btnObtenerCuentas.Click += new System.EventHandler(this.btnObtenerCuentas_Click);
            // 
            // tbObtenerCuentas
            // 
            this.tbObtenerCuentas.Location = new System.Drawing.Point(178, 23);
            this.tbObtenerCuentas.Name = "tbObtenerCuentas";
            this.tbObtenerCuentas.Size = new System.Drawing.Size(133, 20);
            this.tbObtenerCuentas.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(69, 26);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(89, 13);
            this.label17.TabIndex = 0;
            this.label17.Text = "Número de Socio";
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.label26);
            this.tabPage16.Controls.Add(this.txtNoContratoObDetalleCuenta);
            this.tabPage16.Controls.Add(this.txtIdCuentaObDetalleCuenta);
            this.tabPage16.Controls.Add(this.label25);
            this.tabPage16.Controls.Add(this.btnObtenerDetalleCuenta);
            this.tabPage16.Controls.Add(this.txtNumeroObDetalleCuenta);
            this.tabPage16.Controls.Add(this.label18);
            this.tabPage16.Location = new System.Drawing.Point(4, 22);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage16.Size = new System.Drawing.Size(660, 235);
            this.tabPage16.TabIndex = 1;
            this.tabPage16.Text = "Obtener Detalle Cuenta";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(27, 101);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(81, 13);
            this.label26.TabIndex = 6;
            this.label26.Text = "No. de contrato";
            // 
            // txtNoContratoObDetalleCuenta
            // 
            this.txtNoContratoObDetalleCuenta.Location = new System.Drawing.Point(122, 94);
            this.txtNoContratoObDetalleCuenta.Name = "txtNoContratoObDetalleCuenta";
            this.txtNoContratoObDetalleCuenta.Size = new System.Drawing.Size(150, 20);
            this.txtNoContratoObDetalleCuenta.TabIndex = 5;
            // 
            // txtIdCuentaObDetalleCuenta
            // 
            this.txtIdCuentaObDetalleCuenta.Location = new System.Drawing.Point(122, 59);
            this.txtIdCuentaObDetalleCuenta.Name = "txtIdCuentaObDetalleCuenta";
            this.txtIdCuentaObDetalleCuenta.Size = new System.Drawing.Size(150, 20);
            this.txtIdCuentaObDetalleCuenta.TabIndex = 4;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(27, 66);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(78, 13);
            this.label25.TabIndex = 3;
            this.label25.Text = "Id de la cuenta";
            // 
            // btnObtenerDetalleCuenta
            // 
            this.btnObtenerDetalleCuenta.Location = new System.Drawing.Point(159, 136);
            this.btnObtenerDetalleCuenta.Name = "btnObtenerDetalleCuenta";
            this.btnObtenerDetalleCuenta.Size = new System.Drawing.Size(113, 23);
            this.btnObtenerDetalleCuenta.TabIndex = 2;
            this.btnObtenerDetalleCuenta.Text = "Enviar";
            this.btnObtenerDetalleCuenta.UseVisualStyleBackColor = true;
            this.btnObtenerDetalleCuenta.Click += new System.EventHandler(this.btnObtenerDetalleCuenta_Click);
            // 
            // txtNumeroObDetalleCuenta
            // 
            this.txtNumeroObDetalleCuenta.Location = new System.Drawing.Point(122, 25);
            this.txtNumeroObDetalleCuenta.Name = "txtNumeroObDetalleCuenta";
            this.txtNumeroObDetalleCuenta.Size = new System.Drawing.Size(150, 20);
            this.txtNumeroObDetalleCuenta.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(27, 28);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(89, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "Número de Socio";
            // 
            // tabPage17
            // 
            this.tabPage17.Controls.Add(this.cbIdMovObtenerMovimientosCuenta);
            this.tabPage17.Controls.Add(this.tbNumeroSocioObtenerMovimientosCuenta);
            this.tabPage17.Controls.Add(this.label21);
            this.tabPage17.Controls.Add(this.cbPeriodoObtenerMovimientosCuenta);
            this.tabPage17.Controls.Add(this.label20);
            this.tabPage17.Controls.Add(this.label19);
            this.tabPage17.Controls.Add(this.BtnObtenerMovimientosCuentas);
            this.tabPage17.Location = new System.Drawing.Point(4, 22);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Size = new System.Drawing.Size(660, 235);
            this.tabPage17.TabIndex = 2;
            this.tabPage17.Text = "Obtener Movimientos Cuentas";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // cbIdMovObtenerMovimientosCuenta
            // 
            this.cbIdMovObtenerMovimientosCuenta.FormattingEnabled = true;
            this.cbIdMovObtenerMovimientosCuenta.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.cbIdMovObtenerMovimientosCuenta.Location = new System.Drawing.Point(212, 64);
            this.cbIdMovObtenerMovimientosCuenta.Name = "cbIdMovObtenerMovimientosCuenta";
            this.cbIdMovObtenerMovimientosCuenta.Size = new System.Drawing.Size(133, 21);
            this.cbIdMovObtenerMovimientosCuenta.TabIndex = 13;
            // 
            // tbNumeroSocioObtenerMovimientosCuenta
            // 
            this.tbNumeroSocioObtenerMovimientosCuenta.Location = new System.Drawing.Point(212, 30);
            this.tbNumeroSocioObtenerMovimientosCuenta.Name = "tbNumeroSocioObtenerMovimientosCuenta";
            this.tbNumeroSocioObtenerMovimientosCuenta.Size = new System.Drawing.Size(133, 20);
            this.tbNumeroSocioObtenerMovimientosCuenta.TabIndex = 12;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(121, 30);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(74, 13);
            this.label21.TabIndex = 11;
            this.label21.Text = "Numero Socio";
            // 
            // cbPeriodoObtenerMovimientosCuenta
            // 
            this.cbPeriodoObtenerMovimientosCuenta.FormattingEnabled = true;
            this.cbPeriodoObtenerMovimientosCuenta.Items.AddRange(new object[] {
            "Actual",
            "3 Meses"});
            this.cbPeriodoObtenerMovimientosCuenta.Location = new System.Drawing.Point(212, 92);
            this.cbPeriodoObtenerMovimientosCuenta.Name = "cbPeriodoObtenerMovimientosCuenta";
            this.cbPeriodoObtenerMovimientosCuenta.Size = new System.Drawing.Size(133, 21);
            this.cbPeriodoObtenerMovimientosCuenta.TabIndex = 10;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(121, 95);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(43, 13);
            this.label20.TabIndex = 9;
            this.label20.Text = "Periodo";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(121, 64);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(36, 13);
            this.label19.TabIndex = 8;
            this.label19.Text = "idMov";
            // 
            // BtnObtenerMovimientosCuentas
            // 
            this.BtnObtenerMovimientosCuentas.Location = new System.Drawing.Point(221, 136);
            this.BtnObtenerMovimientosCuentas.Name = "BtnObtenerMovimientosCuentas";
            this.BtnObtenerMovimientosCuentas.Size = new System.Drawing.Size(75, 23);
            this.BtnObtenerMovimientosCuentas.TabIndex = 0;
            this.BtnObtenerMovimientosCuentas.Text = "Enviar";
            this.BtnObtenerMovimientosCuentas.UseVisualStyleBackColor = true;
            this.BtnObtenerMovimientosCuentas.Click += new System.EventHandler(this.BtnObtenerMovimientosCuentas_Click);
            // 
            // tabPage18
            // 
            this.tabPage18.Controls.Add(this.tabControl7);
            this.tabPage18.Location = new System.Drawing.Point(4, 22);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Size = new System.Drawing.Size(842, 261);
            this.tabPage18.TabIndex = 5;
            this.tabPage18.Text = "Token";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // tabControl7
            // 
            this.tabControl7.Controls.Add(this.tabPage19);
            this.tabControl7.Controls.Add(this.tabPage20);
            this.tabControl7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl7.Location = new System.Drawing.Point(0, 0);
            this.tabControl7.Name = "tabControl7";
            this.tabControl7.SelectedIndex = 0;
            this.tabControl7.Size = new System.Drawing.Size(842, 261);
            this.tabControl7.TabIndex = 0;
            // 
            // tabPage19
            // 
            this.tabPage19.Controls.Add(this.btAprovisionarToken);
            this.tabPage19.Controls.Add(this.btNumeroSocioAprovisionarToken);
            this.tabPage19.Controls.Add(this.label22);
            this.tabPage19.Location = new System.Drawing.Point(4, 22);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage19.Size = new System.Drawing.Size(834, 235);
            this.tabPage19.TabIndex = 0;
            this.tabPage19.Text = "Aprovisionar Token";
            this.tabPage19.UseVisualStyleBackColor = true;
            // 
            // btAprovisionarToken
            // 
            this.btAprovisionarToken.Location = new System.Drawing.Point(248, 103);
            this.btAprovisionarToken.Name = "btAprovisionarToken";
            this.btAprovisionarToken.Size = new System.Drawing.Size(88, 23);
            this.btAprovisionarToken.TabIndex = 2;
            this.btAprovisionarToken.Text = "Enviar";
            this.btAprovisionarToken.UseVisualStyleBackColor = true;
            this.btAprovisionarToken.Click += new System.EventHandler(this.btAprovisionarToken_Click);
            // 
            // btNumeroSocioAprovisionarToken
            // 
            this.btNumeroSocioAprovisionarToken.Location = new System.Drawing.Point(232, 31);
            this.btNumeroSocioAprovisionarToken.Name = "btNumeroSocioAprovisionarToken";
            this.btNumeroSocioAprovisionarToken.Size = new System.Drawing.Size(126, 20);
            this.btNumeroSocioAprovisionarToken.TabIndex = 1;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(116, 31);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(89, 13);
            this.label22.TabIndex = 0;
            this.label22.Text = "Numero de Socio";
            // 
            // tabPage20
            // 
            this.tabPage20.Controls.Add(this.btnValidaOTP);
            this.tabPage20.Controls.Add(this.tbOTPValidaOTP);
            this.tabPage20.Controls.Add(this.tbNumeroSocioValidaOTP);
            this.tabPage20.Controls.Add(this.label24);
            this.tabPage20.Controls.Add(this.label23);
            this.tabPage20.Location = new System.Drawing.Point(4, 22);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Size = new System.Drawing.Size(660, 235);
            this.tabPage20.TabIndex = 1;
            this.tabPage20.Text = "Valida OTP";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // btnValidaOTP
            // 
            this.btnValidaOTP.Location = new System.Drawing.Point(254, 119);
            this.btnValidaOTP.Name = "btnValidaOTP";
            this.btnValidaOTP.Size = new System.Drawing.Size(75, 23);
            this.btnValidaOTP.TabIndex = 4;
            this.btnValidaOTP.Text = "Enviar";
            this.btnValidaOTP.UseVisualStyleBackColor = true;
            this.btnValidaOTP.Click += new System.EventHandler(this.btnValidaOTP_Click);
            // 
            // tbOTPValidaOTP
            // 
            this.tbOTPValidaOTP.Location = new System.Drawing.Point(219, 65);
            this.tbOTPValidaOTP.Name = "tbOTPValidaOTP";
            this.tbOTPValidaOTP.Size = new System.Drawing.Size(140, 20);
            this.tbOTPValidaOTP.TabIndex = 3;
            // 
            // tbNumeroSocioValidaOTP
            // 
            this.tbNumeroSocioValidaOTP.Location = new System.Drawing.Point(219, 26);
            this.tbNumeroSocioValidaOTP.Name = "tbNumeroSocioValidaOTP";
            this.tbNumeroSocioValidaOTP.Size = new System.Drawing.Size(140, 20);
            this.tbNumeroSocioValidaOTP.TabIndex = 2;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(104, 72);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 13);
            this.label24.TabIndex = 1;
            this.label24.Text = "OTP";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(101, 26);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(89, 13);
            this.label23.TabIndex = 0;
            this.label23.Text = "Numero de Socio";
            // 
            // tabImagenes
            // 
            this.tabImagenes.Controls.Add(this.tabControl8);
            this.tabImagenes.Location = new System.Drawing.Point(4, 22);
            this.tabImagenes.Name = "tabImagenes";
            this.tabImagenes.Size = new System.Drawing.Size(842, 261);
            this.tabImagenes.TabIndex = 6;
            this.tabImagenes.Text = "Imagenes";
            this.tabImagenes.UseVisualStyleBackColor = true;
            // 
            // tabControl8
            // 
            this.tabControl8.Controls.Add(this.tabPage23);
            this.tabControl8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl8.Location = new System.Drawing.Point(0, 0);
            this.tabControl8.Name = "tabControl8";
            this.tabControl8.SelectedIndex = 0;
            this.tabControl8.Size = new System.Drawing.Size(842, 261);
            this.tabControl8.TabIndex = 0;
            // 
            // tabPage23
            // 
            this.tabPage23.Controls.Add(this.btEnviarImagenFondo);
            this.tabPage23.Location = new System.Drawing.Point(4, 22);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage23.Size = new System.Drawing.Size(834, 235);
            this.tabPage23.TabIndex = 1;
            this.tabPage23.Text = "Imagen Fondo";
            this.tabPage23.UseVisualStyleBackColor = true;
            // 
            // btEnviarImagenFondo
            // 
            this.btEnviarImagenFondo.Location = new System.Drawing.Point(200, 72);
            this.btEnviarImagenFondo.Name = "btEnviarImagenFondo";
            this.btEnviarImagenFondo.Size = new System.Drawing.Size(75, 23);
            this.btEnviarImagenFondo.TabIndex = 0;
            this.btEnviarImagenFondo.Text = "Enviar";
            this.btEnviarImagenFondo.UseVisualStyleBackColor = true;
            this.btEnviarImagenFondo.Click += new System.EventHandler(this.btEnviarImagenFondo_Click);
            // 
            // tabPage24
            // 
            this.tabPage24.Controls.Add(this.tabControl9);
            this.tabPage24.Location = new System.Drawing.Point(4, 22);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Size = new System.Drawing.Size(842, 261);
            this.tabPage24.TabIndex = 7;
            this.tabPage24.Text = "Transferencia";
            this.tabPage24.UseVisualStyleBackColor = true;
            // 
            // tabControl9
            // 
            this.tabControl9.Controls.Add(this.tabPage25);
            this.tabControl9.Controls.Add(this.tabPage26);
            this.tabControl9.Controls.Add(this.tabPage27);
            this.tabControl9.Controls.Add(this.tabPage30);
            this.tabControl9.Controls.Add(this.tabPage32);
            this.tabControl9.Controls.Add(this.tabPage33);
            this.tabControl9.Controls.Add(this.tabPage34);
            this.tabControl9.Controls.Add(this.tabPage35);
            this.tabControl9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl9.Location = new System.Drawing.Point(0, 0);
            this.tabControl9.Name = "tabControl9";
            this.tabControl9.SelectedIndex = 0;
            this.tabControl9.Size = new System.Drawing.Size(842, 261);
            this.tabControl9.TabIndex = 0;
            // 
            // tabPage25
            // 
            this.tabPage25.Controls.Add(this.tbClabeAltaCuentasInternas);
            this.tabPage25.Controls.Add(this.label73);
            this.tabPage25.Controls.Add(this.tbOTPAltaCuentasInternas);
            this.tabPage25.Controls.Add(this.tbCorreoAltaCuentasInternas);
            this.tabPage25.Controls.Add(this.tbMontoAltaCuentasInternas);
            this.tabPage25.Controls.Add(this.tbAliasAltaCuentasInternas);
            this.tabPage25.Controls.Add(this.tbIdCuentaAltaCuentasInternas);
            this.tabPage25.Controls.Add(this.tbNumeroSocioBeneficiarioAltaCuentasInternas);
            this.tabPage25.Controls.Add(this.tbNumeroSocioAltaCuentasInternas);
            this.tabPage25.Controls.Add(this.label49);
            this.tabPage25.Controls.Add(this.btnAltaCuentaInterna);
            this.tabPage25.Controls.Add(this.label35);
            this.tabPage25.Controls.Add(this.label34);
            this.tabPage25.Controls.Add(this.label33);
            this.tabPage25.Controls.Add(this.label32);
            this.tabPage25.Controls.Add(this.label31);
            this.tabPage25.Controls.Add(this.label16);
            this.tabPage25.Location = new System.Drawing.Point(4, 22);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage25.Size = new System.Drawing.Size(834, 235);
            this.tabPage25.TabIndex = 0;
            this.tabPage25.Text = "Alta Cuentas Internas";
            this.tabPage25.UseVisualStyleBackColor = true;
            // 
            // tbClabeAltaCuentasInternas
            // 
            this.tbClabeAltaCuentasInternas.Location = new System.Drawing.Point(339, 111);
            this.tbClabeAltaCuentasInternas.Name = "tbClabeAltaCuentasInternas";
            this.tbClabeAltaCuentasInternas.Size = new System.Drawing.Size(128, 20);
            this.tbClabeAltaCuentasInternas.TabIndex = 16;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(303, 114);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(34, 13);
            this.label73.TabIndex = 15;
            this.label73.Text = "Clabe";
            // 
            // tbOTPAltaCuentasInternas
            // 
            this.tbOTPAltaCuentasInternas.Location = new System.Drawing.Point(339, 74);
            this.tbOTPAltaCuentasInternas.Name = "tbOTPAltaCuentasInternas";
            this.tbOTPAltaCuentasInternas.Size = new System.Drawing.Size(128, 20);
            this.tbOTPAltaCuentasInternas.TabIndex = 14;
            // 
            // tbCorreoAltaCuentasInternas
            // 
            this.tbCorreoAltaCuentasInternas.Location = new System.Drawing.Point(339, 44);
            this.tbCorreoAltaCuentasInternas.Name = "tbCorreoAltaCuentasInternas";
            this.tbCorreoAltaCuentasInternas.Size = new System.Drawing.Size(128, 20);
            this.tbCorreoAltaCuentasInternas.TabIndex = 12;
            // 
            // tbMontoAltaCuentasInternas
            // 
            this.tbMontoAltaCuentasInternas.Location = new System.Drawing.Point(339, 9);
            this.tbMontoAltaCuentasInternas.Name = "tbMontoAltaCuentasInternas";
            this.tbMontoAltaCuentasInternas.Size = new System.Drawing.Size(128, 20);
            this.tbMontoAltaCuentasInternas.TabIndex = 11;
            // 
            // tbAliasAltaCuentasInternas
            // 
            this.tbAliasAltaCuentasInternas.Location = new System.Drawing.Point(162, 112);
            this.tbAliasAltaCuentasInternas.Name = "tbAliasAltaCuentasInternas";
            this.tbAliasAltaCuentasInternas.Size = new System.Drawing.Size(128, 20);
            this.tbAliasAltaCuentasInternas.TabIndex = 10;
            // 
            // tbIdCuentaAltaCuentasInternas
            // 
            this.tbIdCuentaAltaCuentasInternas.Location = new System.Drawing.Point(161, 74);
            this.tbIdCuentaAltaCuentasInternas.Name = "tbIdCuentaAltaCuentasInternas";
            this.tbIdCuentaAltaCuentasInternas.Size = new System.Drawing.Size(128, 20);
            this.tbIdCuentaAltaCuentasInternas.TabIndex = 9;
            // 
            // tbNumeroSocioBeneficiarioAltaCuentasInternas
            // 
            this.tbNumeroSocioBeneficiarioAltaCuentasInternas.Location = new System.Drawing.Point(162, 44);
            this.tbNumeroSocioBeneficiarioAltaCuentasInternas.Name = "tbNumeroSocioBeneficiarioAltaCuentasInternas";
            this.tbNumeroSocioBeneficiarioAltaCuentasInternas.Size = new System.Drawing.Size(128, 20);
            this.tbNumeroSocioBeneficiarioAltaCuentasInternas.TabIndex = 8;
            // 
            // tbNumeroSocioAltaCuentasInternas
            // 
            this.tbNumeroSocioAltaCuentasInternas.Location = new System.Drawing.Point(162, 9);
            this.tbNumeroSocioAltaCuentasInternas.Name = "tbNumeroSocioAltaCuentasInternas";
            this.tbNumeroSocioAltaCuentasInternas.Size = new System.Drawing.Size(128, 20);
            this.tbNumeroSocioAltaCuentasInternas.TabIndex = 7;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(300, 77);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(29, 13);
            this.label49.TabIndex = 13;
            this.label49.Text = "OTP";
            // 
            // btnAltaCuentaInterna
            // 
            this.btnAltaCuentaInterna.Location = new System.Drawing.Point(303, 144);
            this.btnAltaCuentaInterna.Name = "btnAltaCuentaInterna";
            this.btnAltaCuentaInterna.Size = new System.Drawing.Size(75, 23);
            this.btnAltaCuentaInterna.TabIndex = 6;
            this.btnAltaCuentaInterna.Text = "Enviar";
            this.btnAltaCuentaInterna.UseVisualStyleBackColor = true;
            this.btnAltaCuentaInterna.Click += new System.EventHandler(this.btnAltaCuentaInterna_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(300, 47);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(38, 13);
            this.label35.TabIndex = 5;
            this.label35.Text = "Correo";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(297, 12);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(37, 13);
            this.label34.TabIndex = 4;
            this.label34.Text = "Monto";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(126, 115);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(29, 13);
            this.label33.TabIndex = 3;
            this.label33.Text = "Alias";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(114, 81);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(41, 13);
            this.label32.TabIndex = 2;
            this.label32.Text = "Cuenta";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(9, 47);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(147, 13);
            this.label31.TabIndex = 1;
            this.label31.Text = "Numero de Socio Beneficiario";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(67, 12);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Numero de Socio";
            // 
            // tabPage26
            // 
            this.tabPage26.Controls.Add(this.tbIdCuentaExtenaAltaCuentasExternasClabes);
            this.tabPage26.Controls.Add(this.label74);
            this.tabPage26.Controls.Add(this.tbOTPAltaCuentasExternasClabes);
            this.tabPage26.Controls.Add(this.tbCURPAltaCuentasExternasClabes);
            this.tabPage26.Controls.Add(this.tbRFCAltaCuentasExternasClabes);
            this.tabPage26.Controls.Add(this.tbCorreoAltaCuentasExternasClabes);
            this.tabPage26.Controls.Add(this.tbMontoAltaCuentasExternasClabes);
            this.tabPage26.Controls.Add(this.tbAliasAltaCuentasExternasClabes);
            this.tabPage26.Controls.Add(this.tbClabeAltaCuentasExternasClabes);
            this.tabPage26.Controls.Add(this.tbNombreBeneficiarioAltaCuentasExternasClabes);
            this.tabPage26.Controls.Add(this.tbNumeroSocioAltaCuentasExternasClabes);
            this.tabPage26.Controls.Add(this.label50);
            this.tabPage26.Controls.Add(this.btnAltaCuentasExternasClabes);
            this.tabPage26.Controls.Add(this.CURP);
            this.tabPage26.Controls.Add(this.RFC);
            this.tabPage26.Controls.Add(this.Correo);
            this.tabPage26.Controls.Add(this.Monto);
            this.tabPage26.Controls.Add(this.label38);
            this.tabPage26.Controls.Add(this.label37);
            this.tabPage26.Controls.Add(this.label36);
            this.tabPage26.Controls.Add(this.label28);
            this.tabPage26.Location = new System.Drawing.Point(4, 22);
            this.tabPage26.Name = "tabPage26";
            this.tabPage26.Size = new System.Drawing.Size(660, 235);
            this.tabPage26.TabIndex = 1;
            this.tabPage26.Text = "Alta Cuentas Externas Clabe";
            this.tabPage26.UseVisualStyleBackColor = true;
            // 
            // tbIdCuentaExtenaAltaCuentasExternasClabes
            // 
            this.tbIdCuentaExtenaAltaCuentasExternasClabes.Location = new System.Drawing.Point(347, 117);
            this.tbIdCuentaExtenaAltaCuentasExternasClabes.Name = "tbIdCuentaExtenaAltaCuentasExternasClabes";
            this.tbIdCuentaExtenaAltaCuentasExternasClabes.Size = new System.Drawing.Size(100, 20);
            this.tbIdCuentaExtenaAltaCuentasExternasClabes.TabIndex = 20;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(287, 120);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(49, 13);
            this.label74.TabIndex = 19;
            this.label74.Text = "idCuenta";
            // 
            // tbOTPAltaCuentasExternasClabes
            // 
            this.tbOTPAltaCuentasExternasClabes.Location = new System.Drawing.Point(58, 125);
            this.tbOTPAltaCuentasExternasClabes.Name = "tbOTPAltaCuentasExternasClabes";
            this.tbOTPAltaCuentasExternasClabes.Size = new System.Drawing.Size(114, 20);
            this.tbOTPAltaCuentasExternasClabes.TabIndex = 18;
            // 
            // tbCURPAltaCuentasExternasClabes
            // 
            this.tbCURPAltaCuentasExternasClabes.Location = new System.Drawing.Point(347, 91);
            this.tbCURPAltaCuentasExternasClabes.Name = "tbCURPAltaCuentasExternasClabes";
            this.tbCURPAltaCuentasExternasClabes.Size = new System.Drawing.Size(100, 20);
            this.tbCURPAltaCuentasExternasClabes.TabIndex = 15;
            // 
            // tbRFCAltaCuentasExternasClabes
            // 
            this.tbRFCAltaCuentasExternasClabes.Location = new System.Drawing.Point(347, 65);
            this.tbRFCAltaCuentasExternasClabes.Name = "tbRFCAltaCuentasExternasClabes";
            this.tbRFCAltaCuentasExternasClabes.Size = new System.Drawing.Size(100, 20);
            this.tbRFCAltaCuentasExternasClabes.TabIndex = 14;
            // 
            // tbCorreoAltaCuentasExternasClabes
            // 
            this.tbCorreoAltaCuentasExternasClabes.Location = new System.Drawing.Point(347, 39);
            this.tbCorreoAltaCuentasExternasClabes.Name = "tbCorreoAltaCuentasExternasClabes";
            this.tbCorreoAltaCuentasExternasClabes.Size = new System.Drawing.Size(100, 20);
            this.tbCorreoAltaCuentasExternasClabes.TabIndex = 13;
            // 
            // tbMontoAltaCuentasExternasClabes
            // 
            this.tbMontoAltaCuentasExternasClabes.Location = new System.Drawing.Point(347, 13);
            this.tbMontoAltaCuentasExternasClabes.Name = "tbMontoAltaCuentasExternasClabes";
            this.tbMontoAltaCuentasExternasClabes.Size = new System.Drawing.Size(100, 20);
            this.tbMontoAltaCuentasExternasClabes.TabIndex = 12;
            // 
            // tbAliasAltaCuentasExternasClabes
            // 
            this.tbAliasAltaCuentasExternasClabes.Location = new System.Drawing.Point(139, 93);
            this.tbAliasAltaCuentasExternasClabes.Name = "tbAliasAltaCuentasExternasClabes";
            this.tbAliasAltaCuentasExternasClabes.Size = new System.Drawing.Size(118, 20);
            this.tbAliasAltaCuentasExternasClabes.TabIndex = 7;
            // 
            // tbClabeAltaCuentasExternasClabes
            // 
            this.tbClabeAltaCuentasExternasClabes.Location = new System.Drawing.Point(139, 67);
            this.tbClabeAltaCuentasExternasClabes.Name = "tbClabeAltaCuentasExternasClabes";
            this.tbClabeAltaCuentasExternasClabes.Size = new System.Drawing.Size(118, 20);
            this.tbClabeAltaCuentasExternasClabes.TabIndex = 6;
            // 
            // tbNombreBeneficiarioAltaCuentasExternasClabes
            // 
            this.tbNombreBeneficiarioAltaCuentasExternasClabes.Location = new System.Drawing.Point(139, 41);
            this.tbNombreBeneficiarioAltaCuentasExternasClabes.Name = "tbNombreBeneficiarioAltaCuentasExternasClabes";
            this.tbNombreBeneficiarioAltaCuentasExternasClabes.Size = new System.Drawing.Size(118, 20);
            this.tbNombreBeneficiarioAltaCuentasExternasClabes.TabIndex = 5;
            // 
            // tbNumeroSocioAltaCuentasExternasClabes
            // 
            this.tbNumeroSocioAltaCuentasExternasClabes.Location = new System.Drawing.Point(139, 13);
            this.tbNumeroSocioAltaCuentasExternasClabes.Name = "tbNumeroSocioAltaCuentasExternasClabes";
            this.tbNumeroSocioAltaCuentasExternasClabes.Size = new System.Drawing.Size(118, 20);
            this.tbNumeroSocioAltaCuentasExternasClabes.TabIndex = 4;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(22, 125);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(29, 13);
            this.label50.TabIndex = 17;
            this.label50.Text = "OTP";
            // 
            // btnAltaCuentasExternasClabes
            // 
            this.btnAltaCuentasExternasClabes.Location = new System.Drawing.Point(204, 139);
            this.btnAltaCuentasExternasClabes.Name = "btnAltaCuentasExternasClabes";
            this.btnAltaCuentasExternasClabes.Size = new System.Drawing.Size(75, 23);
            this.btnAltaCuentasExternasClabes.TabIndex = 16;
            this.btnAltaCuentasExternasClabes.Text = "Enviar";
            this.btnAltaCuentasExternasClabes.UseVisualStyleBackColor = true;
            this.btnAltaCuentasExternasClabes.Click += new System.EventHandler(this.btnAltaCuentasExternasClabes_Click);
            // 
            // CURP
            // 
            this.CURP.AutoSize = true;
            this.CURP.Location = new System.Drawing.Point(284, 93);
            this.CURP.Name = "CURP";
            this.CURP.Size = new System.Drawing.Size(37, 13);
            this.CURP.TabIndex = 11;
            this.CURP.Text = "CURP";
            // 
            // RFC
            // 
            this.RFC.AutoSize = true;
            this.RFC.Location = new System.Drawing.Point(284, 70);
            this.RFC.Name = "RFC";
            this.RFC.Size = new System.Drawing.Size(28, 13);
            this.RFC.TabIndex = 10;
            this.RFC.Text = "RFC";
            // 
            // Correo
            // 
            this.Correo.AutoSize = true;
            this.Correo.Location = new System.Drawing.Point(284, 44);
            this.Correo.Name = "Correo";
            this.Correo.Size = new System.Drawing.Size(38, 13);
            this.Correo.TabIndex = 9;
            this.Correo.Text = "Correo";
            // 
            // Monto
            // 
            this.Monto.AutoSize = true;
            this.Monto.Location = new System.Drawing.Point(284, 13);
            this.Monto.Name = "Monto";
            this.Monto.Size = new System.Drawing.Size(37, 13);
            this.Monto.TabIndex = 8;
            this.Monto.Text = "Monto";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(19, 93);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(29, 13);
            this.label38.TabIndex = 3;
            this.label38.Text = "Alias";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(19, 70);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(41, 13);
            this.label37.TabIndex = 2;
            this.label37.Text = "CLABE";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(19, 44);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(102, 13);
            this.label36.TabIndex = 1;
            this.label36.Text = "Nombre Beneficiario";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(19, 13);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(89, 13);
            this.label28.TabIndex = 0;
            this.label28.Text = "Numero de Socio";
            // 
            // tabPage27
            // 
            this.tabPage27.Controls.Add(this.txtOTPAlExDeb);
            this.tabPage27.Controls.Add(this.txtCURPAlExDeb);
            this.tabPage27.Controls.Add(this.txtCorreoAlExDeb);
            this.tabPage27.Controls.Add(this.txtMontoAlExDeb);
            this.tabPage27.Controls.Add(this.txtAliasAlExDeb);
            this.tabPage27.Controls.Add(this.txtNumeroTarjetaAlExDeb);
            this.tabPage27.Controls.Add(this.txtBeneficiarioAlExDeb);
            this.tabPage27.Controls.Add(this.txtNoSocAlExDeb);
            this.tabPage27.Controls.Add(this.label51);
            this.tabPage27.Controls.Add(this.btnAltaCtaExtDebito);
            this.tabPage27.Controls.Add(this.label41);
            this.tabPage27.Controls.Add(this.label42);
            this.tabPage27.Controls.Add(this.label43);
            this.tabPage27.Controls.Add(this.label44);
            this.tabPage27.Controls.Add(this.label45);
            this.tabPage27.Controls.Add(this.label46);
            this.tabPage27.Controls.Add(this.label47);
            this.tabPage27.Location = new System.Drawing.Point(4, 22);
            this.tabPage27.Name = "tabPage27";
            this.tabPage27.Size = new System.Drawing.Size(660, 235);
            this.tabPage27.TabIndex = 1;
            this.tabPage27.Text = "Alta Cuenta Externa Debito";
            this.tabPage27.UseVisualStyleBackColor = true;
            // 
            // txtOTPAlExDeb
            // 
            this.txtOTPAlExDeb.Location = new System.Drawing.Point(353, 103);
            this.txtOTPAlExDeb.Name = "txtOTPAlExDeb";
            this.txtOTPAlExDeb.Size = new System.Drawing.Size(100, 20);
            this.txtOTPAlExDeb.TabIndex = 35;
            // 
            // txtCURPAlExDeb
            // 
            this.txtCURPAlExDeb.Location = new System.Drawing.Point(353, 69);
            this.txtCURPAlExDeb.Name = "txtCURPAlExDeb";
            this.txtCURPAlExDeb.Size = new System.Drawing.Size(100, 20);
            this.txtCURPAlExDeb.TabIndex = 31;
            // 
            // txtCorreoAlExDeb
            // 
            this.txtCorreoAlExDeb.Location = new System.Drawing.Point(353, 43);
            this.txtCorreoAlExDeb.Name = "txtCorreoAlExDeb";
            this.txtCorreoAlExDeb.Size = new System.Drawing.Size(100, 20);
            this.txtCorreoAlExDeb.TabIndex = 30;
            // 
            // txtMontoAlExDeb
            // 
            this.txtMontoAlExDeb.Location = new System.Drawing.Point(353, 17);
            this.txtMontoAlExDeb.Name = "txtMontoAlExDeb";
            this.txtMontoAlExDeb.Size = new System.Drawing.Size(100, 20);
            this.txtMontoAlExDeb.TabIndex = 29;
            // 
            // txtAliasAlExDeb
            // 
            this.txtAliasAlExDeb.Location = new System.Drawing.Point(145, 97);
            this.txtAliasAlExDeb.Name = "txtAliasAlExDeb";
            this.txtAliasAlExDeb.Size = new System.Drawing.Size(118, 20);
            this.txtAliasAlExDeb.TabIndex = 24;
            // 
            // txtNumeroTarjetaAlExDeb
            // 
            this.txtNumeroTarjetaAlExDeb.Location = new System.Drawing.Point(145, 71);
            this.txtNumeroTarjetaAlExDeb.Name = "txtNumeroTarjetaAlExDeb";
            this.txtNumeroTarjetaAlExDeb.Size = new System.Drawing.Size(118, 20);
            this.txtNumeroTarjetaAlExDeb.TabIndex = 23;
            // 
            // txtBeneficiarioAlExDeb
            // 
            this.txtBeneficiarioAlExDeb.Location = new System.Drawing.Point(145, 45);
            this.txtBeneficiarioAlExDeb.Name = "txtBeneficiarioAlExDeb";
            this.txtBeneficiarioAlExDeb.Size = new System.Drawing.Size(118, 20);
            this.txtBeneficiarioAlExDeb.TabIndex = 22;
            // 
            // txtNoSocAlExDeb
            // 
            this.txtNoSocAlExDeb.Location = new System.Drawing.Point(145, 17);
            this.txtNoSocAlExDeb.Name = "txtNoSocAlExDeb";
            this.txtNoSocAlExDeb.Size = new System.Drawing.Size(118, 20);
            this.txtNoSocAlExDeb.TabIndex = 21;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(293, 103);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(29, 13);
            this.label51.TabIndex = 34;
            this.label51.Text = "OTP";
            // 
            // btnAltaCtaExtDebito
            // 
            this.btnAltaCtaExtDebito.Location = new System.Drawing.Point(210, 143);
            this.btnAltaCtaExtDebito.Name = "btnAltaCtaExtDebito";
            this.btnAltaCtaExtDebito.Size = new System.Drawing.Size(75, 23);
            this.btnAltaCtaExtDebito.TabIndex = 33;
            this.btnAltaCtaExtDebito.Text = "Enviar";
            this.btnAltaCtaExtDebito.UseVisualStyleBackColor = true;
            this.btnAltaCtaExtDebito.Click += new System.EventHandler(this.btnAltaCtaExtDebito_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(290, 74);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(37, 13);
            this.label41.TabIndex = 27;
            this.label41.Text = "CURP";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(290, 48);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(38, 13);
            this.label42.TabIndex = 26;
            this.label42.Text = "Correo";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(290, 17);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(37, 13);
            this.label43.TabIndex = 25;
            this.label43.Text = "Monto";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(25, 97);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(29, 13);
            this.label44.TabIndex = 20;
            this.label44.Text = "Alias";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(25, 74);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(68, 13);
            this.label45.TabIndex = 19;
            this.label45.Text = "No de tarjeta";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(25, 48);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(102, 13);
            this.label46.TabIndex = 18;
            this.label46.Text = "Nombre Beneficiario";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(25, 17);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(89, 13);
            this.label47.TabIndex = 17;
            this.label47.Text = "Numero de Socio";
            // 
            // tabPage30
            // 
            this.tabPage30.Controls.Add(this.btnEliminaCuentaInterna);
            this.tabPage30.Controls.Add(this.tbOTPEliminaCuentaInterna);
            this.tabPage30.Controls.Add(this.tbIdCuentaEliminaCuentaInterna);
            this.tabPage30.Controls.Add(this.tbNumeroSocioEliminaCuentaInterna);
            this.tabPage30.Controls.Add(this.label54);
            this.tabPage30.Controls.Add(this.label53);
            this.tabPage30.Controls.Add(this.label52);
            this.tabPage30.Location = new System.Drawing.Point(4, 22);
            this.tabPage30.Name = "tabPage30";
            this.tabPage30.Size = new System.Drawing.Size(660, 235);
            this.tabPage30.TabIndex = 2;
            this.tabPage30.Text = "Elimina Cuenta Interna";
            this.tabPage30.UseVisualStyleBackColor = true;
            // 
            // btnEliminaCuentaInterna
            // 
            this.btnEliminaCuentaInterna.Location = new System.Drawing.Point(265, 126);
            this.btnEliminaCuentaInterna.Name = "btnEliminaCuentaInterna";
            this.btnEliminaCuentaInterna.Size = new System.Drawing.Size(75, 23);
            this.btnEliminaCuentaInterna.TabIndex = 6;
            this.btnEliminaCuentaInterna.Text = "Enviar";
            this.btnEliminaCuentaInterna.UseVisualStyleBackColor = true;
            this.btnEliminaCuentaInterna.Click += new System.EventHandler(this.btnEliminaCuentaInterna_Click);
            // 
            // tbOTPEliminaCuentaInterna
            // 
            this.tbOTPEliminaCuentaInterna.Location = new System.Drawing.Point(241, 76);
            this.tbOTPEliminaCuentaInterna.Name = "tbOTPEliminaCuentaInterna";
            this.tbOTPEliminaCuentaInterna.Size = new System.Drawing.Size(129, 20);
            this.tbOTPEliminaCuentaInterna.TabIndex = 5;
            // 
            // tbIdCuentaEliminaCuentaInterna
            // 
            this.tbIdCuentaEliminaCuentaInterna.Location = new System.Drawing.Point(241, 51);
            this.tbIdCuentaEliminaCuentaInterna.Name = "tbIdCuentaEliminaCuentaInterna";
            this.tbIdCuentaEliminaCuentaInterna.Size = new System.Drawing.Size(129, 20);
            this.tbIdCuentaEliminaCuentaInterna.TabIndex = 4;
            // 
            // tbNumeroSocioEliminaCuentaInterna
            // 
            this.tbNumeroSocioEliminaCuentaInterna.Location = new System.Drawing.Point(241, 22);
            this.tbNumeroSocioEliminaCuentaInterna.Name = "tbNumeroSocioEliminaCuentaInterna";
            this.tbNumeroSocioEliminaCuentaInterna.Size = new System.Drawing.Size(129, 20);
            this.tbNumeroSocioEliminaCuentaInterna.TabIndex = 3;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(102, 79);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(29, 13);
            this.label54.TabIndex = 2;
            this.label54.Text = "OTP";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(102, 51);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(53, 13);
            this.label53.TabIndex = 1;
            this.label53.Text = "Id Cuenta";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(99, 22);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(89, 13);
            this.label52.TabIndex = 0;
            this.label52.Text = "Numero de Socio";
            // 
            // tabPage32
            // 
            this.tabPage32.Controls.Add(this.btnEliminaCuentaClabe);
            this.tabPage32.Controls.Add(this.tbOTPEliminaCuentaClabe);
            this.tabPage32.Controls.Add(this.tbIdCuentaEliminaCuentaClabe);
            this.tabPage32.Controls.Add(this.tbNumeroSocioEliminaCuentaClabe);
            this.tabPage32.Controls.Add(this.label58);
            this.tabPage32.Controls.Add(this.label57);
            this.tabPage32.Controls.Add(this.label56);
            this.tabPage32.Location = new System.Drawing.Point(4, 22);
            this.tabPage32.Name = "tabPage32";
            this.tabPage32.Size = new System.Drawing.Size(660, 235);
            this.tabPage32.TabIndex = 3;
            this.tabPage32.Text = "Elimina Cuenta Externa";
            this.tabPage32.UseVisualStyleBackColor = true;
            // 
            // btnEliminaCuentaClabe
            // 
            this.btnEliminaCuentaClabe.Location = new System.Drawing.Point(239, 136);
            this.btnEliminaCuentaClabe.Name = "btnEliminaCuentaClabe";
            this.btnEliminaCuentaClabe.Size = new System.Drawing.Size(75, 23);
            this.btnEliminaCuentaClabe.TabIndex = 6;
            this.btnEliminaCuentaClabe.Text = "Enviar";
            this.btnEliminaCuentaClabe.UseVisualStyleBackColor = true;
            this.btnEliminaCuentaClabe.Click += new System.EventHandler(this.btnEliminaCuentaClabe_Click);
            // 
            // tbOTPEliminaCuentaClabe
            // 
            this.tbOTPEliminaCuentaClabe.Location = new System.Drawing.Point(230, 95);
            this.tbOTPEliminaCuentaClabe.Name = "tbOTPEliminaCuentaClabe";
            this.tbOTPEliminaCuentaClabe.Size = new System.Drawing.Size(100, 20);
            this.tbOTPEliminaCuentaClabe.TabIndex = 5;
            // 
            // tbIdCuentaEliminaCuentaClabe
            // 
            this.tbIdCuentaEliminaCuentaClabe.Location = new System.Drawing.Point(230, 58);
            this.tbIdCuentaEliminaCuentaClabe.Name = "tbIdCuentaEliminaCuentaClabe";
            this.tbIdCuentaEliminaCuentaClabe.Size = new System.Drawing.Size(100, 20);
            this.tbIdCuentaEliminaCuentaClabe.TabIndex = 4;
            // 
            // tbNumeroSocioEliminaCuentaClabe
            // 
            this.tbNumeroSocioEliminaCuentaClabe.Location = new System.Drawing.Point(230, 22);
            this.tbNumeroSocioEliminaCuentaClabe.Name = "tbNumeroSocioEliminaCuentaClabe";
            this.tbNumeroSocioEliminaCuentaClabe.Size = new System.Drawing.Size(100, 20);
            this.tbNumeroSocioEliminaCuentaClabe.TabIndex = 3;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(86, 95);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(29, 13);
            this.label58.TabIndex = 2;
            this.label58.Text = "OTP";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(83, 58);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(68, 13);
            this.label57.TabIndex = 1;
            this.label57.Text = "Id de Cuenta";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(83, 25);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(89, 13);
            this.label56.TabIndex = 0;
            this.label56.Text = "Numero de Socio";
            // 
            // tabPage33
            // 
            this.tabPage33.Controls.Add(this.btnObtenerCuentasRetiroInternas);
            this.tabPage33.Controls.Add(this.tbNumeroSocioObtenerCuentasRetiroInternas);
            this.tabPage33.Controls.Add(this.label59);
            this.tabPage33.Location = new System.Drawing.Point(4, 22);
            this.tabPage33.Name = "tabPage33";
            this.tabPage33.Size = new System.Drawing.Size(660, 235);
            this.tabPage33.TabIndex = 4;
            this.tabPage33.Text = "Obtener Cuentas Retiro Internas";
            this.tabPage33.UseVisualStyleBackColor = true;
            // 
            // btnObtenerCuentasRetiroInternas
            // 
            this.btnObtenerCuentasRetiroInternas.Location = new System.Drawing.Point(246, 103);
            this.btnObtenerCuentasRetiroInternas.Name = "btnObtenerCuentasRetiroInternas";
            this.btnObtenerCuentasRetiroInternas.Size = new System.Drawing.Size(75, 23);
            this.btnObtenerCuentasRetiroInternas.TabIndex = 2;
            this.btnObtenerCuentasRetiroInternas.Text = "Enviar";
            this.btnObtenerCuentasRetiroInternas.UseVisualStyleBackColor = true;
            this.btnObtenerCuentasRetiroInternas.Click += new System.EventHandler(this.btnObtenerCuentasRetiroInternas_Click);
            // 
            // tbNumeroSocioObtenerCuentasRetiroInternas
            // 
            this.tbNumeroSocioObtenerCuentasRetiroInternas.Location = new System.Drawing.Point(213, 33);
            this.tbNumeroSocioObtenerCuentasRetiroInternas.Name = "tbNumeroSocioObtenerCuentasRetiroInternas";
            this.tbNumeroSocioObtenerCuentasRetiroInternas.Size = new System.Drawing.Size(132, 20);
            this.tbNumeroSocioObtenerCuentasRetiroInternas.TabIndex = 1;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(105, 33);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(89, 13);
            this.label59.TabIndex = 0;
            this.label59.Text = "Numero de Socio";
            // 
            // tabPage34
            // 
            this.tabPage34.Controls.Add(this.btnObtenerCuentasDepositoInternas);
            this.tabPage34.Controls.Add(this.cbTipoCuentaObtenerCuentasDepositoInternas);
            this.tabPage34.Controls.Add(this.tbNumeroSocioObtenerCuentasDepositoInternas);
            this.tabPage34.Controls.Add(this.label61);
            this.tabPage34.Controls.Add(this.label60);
            this.tabPage34.Location = new System.Drawing.Point(4, 22);
            this.tabPage34.Name = "tabPage34";
            this.tabPage34.Size = new System.Drawing.Size(660, 235);
            this.tabPage34.TabIndex = 5;
            this.tabPage34.Text = "Obtener Cuentas Deposito Internas";
            this.tabPage34.UseVisualStyleBackColor = true;
            // 
            // btnObtenerCuentasDepositoInternas
            // 
            this.btnObtenerCuentasDepositoInternas.Location = new System.Drawing.Point(253, 123);
            this.btnObtenerCuentasDepositoInternas.Name = "btnObtenerCuentasDepositoInternas";
            this.btnObtenerCuentasDepositoInternas.Size = new System.Drawing.Size(75, 23);
            this.btnObtenerCuentasDepositoInternas.TabIndex = 4;
            this.btnObtenerCuentasDepositoInternas.Text = "Enviar";
            this.btnObtenerCuentasDepositoInternas.UseVisualStyleBackColor = true;
            this.btnObtenerCuentasDepositoInternas.Click += new System.EventHandler(this.btnObtenerCuentasDepositoInternas_Click);
            // 
            // cbTipoCuentaObtenerCuentasDepositoInternas
            // 
            this.cbTipoCuentaObtenerCuentasDepositoInternas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTipoCuentaObtenerCuentasDepositoInternas.FormattingEnabled = true;
            this.cbTipoCuentaObtenerCuentasDepositoInternas.Items.AddRange(new object[] {
            "Todas",
            "Credito",
            "Haberes"});
            this.cbTipoCuentaObtenerCuentasDepositoInternas.Location = new System.Drawing.Point(232, 60);
            this.cbTipoCuentaObtenerCuentasDepositoInternas.Name = "cbTipoCuentaObtenerCuentasDepositoInternas";
            this.cbTipoCuentaObtenerCuentasDepositoInternas.Size = new System.Drawing.Size(121, 21);
            this.cbTipoCuentaObtenerCuentasDepositoInternas.TabIndex = 3;
            // 
            // tbNumeroSocioObtenerCuentasDepositoInternas
            // 
            this.tbNumeroSocioObtenerCuentasDepositoInternas.Location = new System.Drawing.Point(232, 15);
            this.tbNumeroSocioObtenerCuentasDepositoInternas.Name = "tbNumeroSocioObtenerCuentasDepositoInternas";
            this.tbNumeroSocioObtenerCuentasDepositoInternas.Size = new System.Drawing.Size(121, 20);
            this.tbNumeroSocioObtenerCuentasDepositoInternas.TabIndex = 2;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(107, 60);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(80, 13);
            this.label61.TabIndex = 1;
            this.label61.Text = "Tipo de Cuenta";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(104, 18);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(89, 13);
            this.label60.TabIndex = 0;
            this.label60.Text = "Numero de Socio";
            // 
            // tabPage35
            // 
            this.tabPage35.Controls.Add(this.btnObtenerCuentasDepositoExternas);
            this.tabPage35.Controls.Add(this.tbNumeroSocioObtenerCuentasDepositoExternas);
            this.tabPage35.Controls.Add(this.label62);
            this.tabPage35.Location = new System.Drawing.Point(4, 22);
            this.tabPage35.Name = "tabPage35";
            this.tabPage35.Size = new System.Drawing.Size(660, 235);
            this.tabPage35.TabIndex = 6;
            this.tabPage35.Text = "Obtener Cuentas Deposito Externas";
            this.tabPage35.UseVisualStyleBackColor = true;
            // 
            // btnObtenerCuentasDepositoExternas
            // 
            this.btnObtenerCuentasDepositoExternas.Location = new System.Drawing.Point(203, 101);
            this.btnObtenerCuentasDepositoExternas.Name = "btnObtenerCuentasDepositoExternas";
            this.btnObtenerCuentasDepositoExternas.Size = new System.Drawing.Size(100, 23);
            this.btnObtenerCuentasDepositoExternas.TabIndex = 2;
            this.btnObtenerCuentasDepositoExternas.Text = "Enviar";
            this.btnObtenerCuentasDepositoExternas.UseVisualStyleBackColor = true;
            this.btnObtenerCuentasDepositoExternas.Click += new System.EventHandler(this.btnObtenerCuentasDepositoExternas_Click);
            // 
            // tbNumeroSocioObtenerCuentasDepositoExternas
            // 
            this.tbNumeroSocioObtenerCuentasDepositoExternas.Location = new System.Drawing.Point(203, 28);
            this.tbNumeroSocioObtenerCuentasDepositoExternas.Name = "tbNumeroSocioObtenerCuentasDepositoExternas";
            this.tbNumeroSocioObtenerCuentasDepositoExternas.Size = new System.Drawing.Size(100, 20);
            this.tbNumeroSocioObtenerCuentasDepositoExternas.TabIndex = 1;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(89, 31);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(89, 13);
            this.label62.TabIndex = 0;
            this.label62.Text = "Numero de Socio";
            // 
            // tabPage39
            // 
            this.tabPage39.Controls.Add(this.tabControl1);
            this.tabPage39.Controls.Add(this.btnObtenerPreguntaSecreta);
            this.tabPage39.Controls.Add(this.txtNumeroSocioPreguntaSecreta);
            this.tabPage39.Location = new System.Drawing.Point(4, 22);
            this.tabPage39.Name = "tabPage39";
            this.tabPage39.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage39.Size = new System.Drawing.Size(842, 261);
            this.tabPage39.TabIndex = 6;
            this.tabPage39.Text = "Obtener Pregunta S";
            this.tabPage39.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage40);
            this.tabControl1.Controls.Add(this.tabPage411);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(836, 255);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage40
            // 
            this.tabPage40.Controls.Add(this.btnRegistrarServicio);
            this.tabPage40.Controls.Add(this.textBox1);
            this.tabPage40.Controls.Add(this.tbPrecioRegistrarServicio);
            this.tabPage40.Controls.Add(this.tbTipoFrontRegistrarServicio);
            this.tabPage40.Controls.Add(this.tbNumeroReferenciaRegistrarServicio);
            this.tabPage40.Controls.Add(this.tbTelefonoRegistrarServicio);
            this.tabPage40.Controls.Add(this.tbIdServicioRegistrarServicio);
            this.tabPage40.Controls.Add(this.tbIdProductoRegistrarServicio);
            this.tabPage40.Controls.Add(this.tbNumeroSocioRegistrarServicio);
            this.tabPage40.Controls.Add(this.label701);
            this.tabPage40.Controls.Add(this.label69);
            this.tabPage40.Controls.Add(this.label681);
            this.tabPage40.Controls.Add(this.label671);
            this.tabPage40.Controls.Add(this.label651);
            this.tabPage40.Location = new System.Drawing.Point(4, 22);
            this.tabPage40.Name = "tabPage40";
            this.tabPage40.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage40.Size = new System.Drawing.Size(828, 229);
            this.tabPage40.TabIndex = 0;
            this.tabPage40.Text = "Registrar Servicio";
            this.tabPage40.UseVisualStyleBackColor = true;
            // 
            // btnRegistrarServicio
            // 
            this.btnRegistrarServicio.Location = new System.Drawing.Point(228, 143);
            this.btnRegistrarServicio.Name = "btnRegistrarServicio";
            this.btnRegistrarServicio.Size = new System.Drawing.Size(75, 23);
            this.btnRegistrarServicio.TabIndex = 14;
            this.btnRegistrarServicio.Text = "Enviar";
            this.btnRegistrarServicio.UseVisualStyleBackColor = true;
            this.btnRegistrarServicio.Click += new System.EventHandler(this.btnRegistrarServicio_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(353, 74);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 13;
            // 
            // tbPrecioRegistrarServicio
            // 
            this.tbPrecioRegistrarServicio.Location = new System.Drawing.Point(353, 44);
            this.tbPrecioRegistrarServicio.Name = "tbPrecioRegistrarServicio";
            this.tbPrecioRegistrarServicio.Size = new System.Drawing.Size(100, 20);
            this.tbPrecioRegistrarServicio.TabIndex = 12;
            // 
            // tbTipoFrontRegistrarServicio
            // 
            this.tbTipoFrontRegistrarServicio.Location = new System.Drawing.Point(353, 17);
            this.tbTipoFrontRegistrarServicio.Name = "tbTipoFrontRegistrarServicio";
            this.tbTipoFrontRegistrarServicio.Size = new System.Drawing.Size(100, 20);
            this.tbTipoFrontRegistrarServicio.TabIndex = 11;
            // 
            // tbNumeroReferenciaRegistrarServicio
            // 
            this.tbNumeroReferenciaRegistrarServicio.Location = new System.Drawing.Point(151, 98);
            this.tbNumeroReferenciaRegistrarServicio.Name = "tbNumeroReferenciaRegistrarServicio";
            this.tbNumeroReferenciaRegistrarServicio.Size = new System.Drawing.Size(100, 20);
            this.tbNumeroReferenciaRegistrarServicio.TabIndex = 10;
            // 
            // tbTelefonoRegistrarServicio
            // 
            this.tbTelefonoRegistrarServicio.Location = new System.Drawing.Point(151, 71);
            this.tbTelefonoRegistrarServicio.Name = "tbTelefonoRegistrarServicio";
            this.tbTelefonoRegistrarServicio.Size = new System.Drawing.Size(100, 20);
            this.tbTelefonoRegistrarServicio.TabIndex = 9;
            // 
            // tbIdServicioRegistrarServicio
            // 
            this.tbIdServicioRegistrarServicio.Location = new System.Drawing.Point(151, 44);
            this.tbIdServicioRegistrarServicio.Name = "tbIdServicioRegistrarServicio";
            this.tbIdServicioRegistrarServicio.Size = new System.Drawing.Size(100, 20);
            this.tbIdServicioRegistrarServicio.TabIndex = 8;
            // 
            // tbIdProductoRegistrarServicio
            // 
            this.tbIdProductoRegistrarServicio.Location = new System.Drawing.Point(151, 17);
            this.tbIdProductoRegistrarServicio.Name = "tbIdProductoRegistrarServicio";
            this.tbIdProductoRegistrarServicio.Size = new System.Drawing.Size(100, 20);
            this.tbIdProductoRegistrarServicio.TabIndex = 7;
            // 
            // tbNumeroSocioRegistrarServicio
            // 
            this.tbNumeroSocioRegistrarServicio.AutoSize = true;
            this.tbNumeroSocioRegistrarServicio.Location = new System.Drawing.Point(262, 77);
            this.tbNumeroSocioRegistrarServicio.Name = "tbNumeroSocioRegistrarServicio";
            this.tbNumeroSocioRegistrarServicio.Size = new System.Drawing.Size(74, 13);
            this.tbNumeroSocioRegistrarServicio.TabIndex = 6;
            this.tbNumeroSocioRegistrarServicio.Text = "Numero Socio";
            // 
            // label701
            // 
            this.label701.AutoSize = true;
            this.label701.Location = new System.Drawing.Point(283, 42);
            this.label701.Name = "label701";
            this.label701.Size = new System.Drawing.Size(37, 13);
            this.label701.TabIndex = 5;
            this.label701.Text = "Precio";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(283, 17);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(48, 13);
            this.label69.TabIndex = 4;
            this.label69.Text = "tipo front";
            // 
            // label681
            // 
            this.label681.AutoSize = true;
            this.label681.Location = new System.Drawing.Point(41, 101);
            this.label681.Name = "label681";
            this.label681.Size = new System.Drawing.Size(99, 13);
            this.label681.TabIndex = 3;
            this.label681.Text = "Numero Referencia";
            // 
            // label671
            // 
            this.label671.AutoSize = true;
            this.label671.Location = new System.Drawing.Point(41, 68);
            this.label671.Name = "label671";
            this.label671.Size = new System.Drawing.Size(49, 13);
            this.label671.TabIndex = 2;
            this.label671.Text = "Telefono";
            // 
            // label651
            // 
            this.label651.AutoSize = true;
            this.label651.Location = new System.Drawing.Point(41, 17);
            this.label651.Name = "label651";
            this.label651.Size = new System.Drawing.Size(62, 13);
            this.label651.TabIndex = 0;
            this.label651.Text = "Id Producto";
            // 
            // tabPage411
            // 
            this.tabPage411.Controls.Add(this.btnEliminarServicio);
            this.tabPage411.Controls.Add(this.tbNumeroSocioEliminarServicio);
            this.tabPage411.Controls.Add(this.tbIdServicioEliminarServicio);
            this.tabPage411.Controls.Add(this.label72);
            this.tabPage411.Controls.Add(this.label71);
            this.tabPage411.Location = new System.Drawing.Point(4, 22);
            this.tabPage411.Name = "tabPage411";
            this.tabPage411.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage411.Size = new System.Drawing.Size(654, 229);
            this.tabPage411.TabIndex = 1;
            this.tabPage411.Text = "Eliminar Servicio";
            this.tabPage411.UseVisualStyleBackColor = true;
            // 
            // btnEliminarServicio
            // 
            this.btnEliminarServicio.Location = new System.Drawing.Point(256, 113);
            this.btnEliminarServicio.Name = "btnEliminarServicio";
            this.btnEliminarServicio.Size = new System.Drawing.Size(75, 23);
            this.btnEliminarServicio.TabIndex = 4;
            this.btnEliminarServicio.Text = "Enviar";
            this.btnEliminarServicio.UseVisualStyleBackColor = true;
            this.btnEliminarServicio.Click += new System.EventHandler(this.btnEliminarServicio_Click);
            // 
            // tbNumeroSocioEliminarServicio
            // 
            this.tbNumeroSocioEliminarServicio.Location = new System.Drawing.Point(235, 52);
            this.tbNumeroSocioEliminarServicio.Name = "tbNumeroSocioEliminarServicio";
            this.tbNumeroSocioEliminarServicio.Size = new System.Drawing.Size(129, 20);
            this.tbNumeroSocioEliminarServicio.TabIndex = 3;
            // 
            // tbIdServicioEliminarServicio
            // 
            this.tbIdServicioEliminarServicio.Location = new System.Drawing.Point(235, 17);
            this.tbIdServicioEliminarServicio.Name = "tbIdServicioEliminarServicio";
            this.tbIdServicioEliminarServicio.Size = new System.Drawing.Size(129, 20);
            this.tbIdServicioEliminarServicio.TabIndex = 2;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(104, 52);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(89, 13);
            this.label72.TabIndex = 1;
            this.label72.Text = "Numero de Socio";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(136, 20);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(57, 13);
            this.label71.TabIndex = 0;
            this.label71.Text = "Id Servicio";
            // 
            // btnObtenerPreguntaSecreta
            // 
            this.btnObtenerPreguntaSecreta.Location = new System.Drawing.Point(174, 77);
            this.btnObtenerPreguntaSecreta.Name = "btnObtenerPreguntaSecreta";
            this.btnObtenerPreguntaSecreta.Size = new System.Drawing.Size(75, 23);
            this.btnObtenerPreguntaSecreta.TabIndex = 9;
            this.btnObtenerPreguntaSecreta.Text = "Enviar";
            this.btnObtenerPreguntaSecreta.UseVisualStyleBackColor = true;
            this.btnObtenerPreguntaSecreta.Click += new System.EventHandler(this.btnObtenerPreguntaSecreta_Click);
            // 
            // txtNumeroSocioPreguntaSecreta
            // 
            this.txtNumeroSocioPreguntaSecreta.Location = new System.Drawing.Point(206, 36);
            this.txtNumeroSocioPreguntaSecreta.Name = "txtNumeroSocioPreguntaSecreta";
            this.txtNumeroSocioPreguntaSecreta.Size = new System.Drawing.Size(140, 20);
            this.txtNumeroSocioPreguntaSecreta.TabIndex = 7;
            // 
            // tabPagarServicio
            // 
            this.tabPagarServicio.Controls.Add(this.tabControl10);
            this.tabPagarServicio.Location = new System.Drawing.Point(4, 22);
            this.tabPagarServicio.Name = "tabPagarServicio";
            this.tabPagarServicio.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagarServicio.Size = new System.Drawing.Size(842, 261);
            this.tabPagarServicio.TabIndex = 8;
            this.tabPagarServicio.Text = "Pagar Servicio";
            this.tabPagarServicio.UseVisualStyleBackColor = true;
            // 
            // tabControl10
            // 
            this.tabControl10.Controls.Add(this.tabPage45);
            this.tabControl10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl10.Location = new System.Drawing.Point(3, 3);
            this.tabControl10.Name = "tabControl10";
            this.tabControl10.SelectedIndex = 0;
            this.tabControl10.Size = new System.Drawing.Size(836, 255);
            this.tabControl10.TabIndex = 1;
            // 
            // tabPage45
            // 
            this.tabPage45.Controls.Add(this.tableLayoutPanel2);
            this.tabPage45.Location = new System.Drawing.Point(4, 22);
            this.tabPage45.Name = "tabPage45";
            this.tabPage45.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage45.Size = new System.Drawing.Size(828, 229);
            this.tabPage45.TabIndex = 0;
            this.tabPage45.Text = "Registrar Servicio";
            this.tabPage45.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.37923F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75.62077F));
            this.tableLayoutPanel2.Controls.Add(this.cbCategoria, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.cbServicios, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.cbProductos, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.txtTelefono, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.txtReferencia, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.label81, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label82, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label83, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label84, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label85, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.txtMonto, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.label86, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.btnPagarServicio, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.lbl21654, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.txtNumeroSocioPagoServicio, 1, 6);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 8;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(822, 223);
            this.tableLayoutPanel2.TabIndex = 3;
            // 
            // cbCategoria
            // 
            this.cbCategoria.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbCategoria.FormattingEnabled = true;
            this.cbCategoria.Location = new System.Drawing.Point(203, 3);
            this.cbCategoria.Name = "cbCategoria";
            this.cbCategoria.Size = new System.Drawing.Size(616, 21);
            this.cbCategoria.TabIndex = 0;
            this.cbCategoria.SelectionChangeCommitted += new System.EventHandler(this.cbCategoria_SelectionChangeCommitted);
            // 
            // cbServicios
            // 
            this.cbServicios.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbServicios.FormattingEnabled = true;
            this.cbServicios.Location = new System.Drawing.Point(203, 31);
            this.cbServicios.Name = "cbServicios";
            this.cbServicios.Size = new System.Drawing.Size(616, 21);
            this.cbServicios.TabIndex = 1;
            this.cbServicios.SelectionChangeCommitted += new System.EventHandler(this.cbServicios_SelectionChangeCommitted);
            // 
            // cbProductos
            // 
            this.cbProductos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbProductos.FormattingEnabled = true;
            this.cbProductos.Location = new System.Drawing.Point(203, 59);
            this.cbProductos.Name = "cbProductos";
            this.cbProductos.Size = new System.Drawing.Size(616, 21);
            this.cbProductos.TabIndex = 2;
            this.cbProductos.SelectionChangeCommitted += new System.EventHandler(this.cbProductos_SelectionChangeCommitted);
            // 
            // txtTelefono
            // 
            this.txtTelefono.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTelefono.Location = new System.Drawing.Point(203, 88);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(616, 20);
            this.txtTelefono.TabIndex = 3;
            // 
            // txtReferencia
            // 
            this.txtReferencia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtReferencia.Location = new System.Drawing.Point(203, 116);
            this.txtReferencia.Name = "txtReferencia";
            this.txtReferencia.Size = new System.Drawing.Size(616, 20);
            this.txtReferencia.TabIndex = 4;
            // 
            // label81
            // 
            this.label81.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(3, 7);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(194, 13);
            this.label81.TabIndex = 5;
            this.label81.Text = "Categoria";
            // 
            // label82
            // 
            this.label82.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(3, 35);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(194, 13);
            this.label82.TabIndex = 6;
            this.label82.Text = "Servicio";
            // 
            // label83
            // 
            this.label83.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(3, 63);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(194, 13);
            this.label83.TabIndex = 7;
            this.label83.Text = "Producto";
            // 
            // label84
            // 
            this.label84.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(3, 91);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(194, 13);
            this.label84.TabIndex = 8;
            this.label84.Text = "Telefono";
            // 
            // label85
            // 
            this.label85.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(3, 119);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(194, 13);
            this.label85.TabIndex = 9;
            this.label85.Text = "Referencia";
            // 
            // txtMonto
            // 
            this.txtMonto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMonto.Location = new System.Drawing.Point(203, 144);
            this.txtMonto.Name = "txtMonto";
            this.txtMonto.Size = new System.Drawing.Size(616, 20);
            this.txtMonto.TabIndex = 10;
            // 
            // label86
            // 
            this.label86.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(3, 147);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(194, 13);
            this.label86.TabIndex = 11;
            this.label86.Text = "Monto";
            // 
            // btnPagarServicio
            // 
            this.btnPagarServicio.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPagarServicio.Location = new System.Drawing.Point(203, 199);
            this.btnPagarServicio.Name = "btnPagarServicio";
            this.btnPagarServicio.Size = new System.Drawing.Size(616, 21);
            this.btnPagarServicio.TabIndex = 12;
            this.btnPagarServicio.Text = "Pagar";
            this.btnPagarServicio.UseVisualStyleBackColor = true;
            this.btnPagarServicio.Click += new System.EventHandler(this.btnPagarServicio_Click);
            // 
            // lbl21654
            // 
            this.lbl21654.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl21654.AutoSize = true;
            this.lbl21654.Location = new System.Drawing.Point(3, 175);
            this.lbl21654.Name = "lbl21654";
            this.lbl21654.Size = new System.Drawing.Size(194, 13);
            this.lbl21654.TabIndex = 13;
            this.lbl21654.Text = "Numero Socio";
            // 
            // txtNumeroSocioPagoServicio
            // 
            this.txtNumeroSocioPagoServicio.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNumeroSocioPagoServicio.Location = new System.Drawing.Point(203, 172);
            this.txtNumeroSocioPagoServicio.Name = "txtNumeroSocioPagoServicio";
            this.txtNumeroSocioPagoServicio.Size = new System.Drawing.Size(616, 20);
            this.txtNumeroSocioPagoServicio.TabIndex = 14;
            this.txtNumeroSocioPagoServicio.Text = "666480";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.lblRespuesta);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 296);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(850, 176);
            this.panel1.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(404, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(202, 143);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lblRespuesta
            // 
            this.lblRespuesta.AutoSize = true;
            this.lblRespuesta.Location = new System.Drawing.Point(9, 12);
            this.lblRespuesta.Name = "lblRespuesta";
            this.lblRespuesta.Size = new System.Drawing.Size(41, 13);
            this.lblRespuesta.TabIndex = 1;
            this.lblRespuesta.Text = "label17";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(856, 475);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Cliente Servicios Banca Electronica CMV";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.TabPrincipal.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            this.tabPage22.ResumeLayout(false);
            this.tabPage22.PerformLayout();
            this.tabPage41.ResumeLayout(false);
            this.tabPage41.PerformLayout();
            this.tabPage42.ResumeLayout(false);
            this.tabPage42.PerformLayout();
            this.tabPage21.ResumeLayout(false);
            this.tabPage21.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            this.tabPage28.ResumeLayout(false);
            this.tabPage28.PerformLayout();
            this.tabPage31.ResumeLayout(false);
            this.tabPage31.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabControl5.ResumeLayout(false);
            this.tabPage13.ResumeLayout(false);
            this.tabPage29.ResumeLayout(false);
            this.tabPage36.ResumeLayout(false);
            this.tabPage37.ResumeLayout(false);
            this.tabPage37.PerformLayout();
            this.tabPage38.ResumeLayout(false);
            this.tabPage38.PerformLayout();
            this.tabPage43.ResumeLayout(false);
            this.tabPage14.ResumeLayout(false);
            this.tabControl6.ResumeLayout(false);
            this.tabPage15.ResumeLayout(false);
            this.tabPage15.PerformLayout();
            this.tabPage16.ResumeLayout(false);
            this.tabPage16.PerformLayout();
            this.tabPage17.ResumeLayout(false);
            this.tabPage17.PerformLayout();
            this.tabPage18.ResumeLayout(false);
            this.tabControl7.ResumeLayout(false);
            this.tabPage19.ResumeLayout(false);
            this.tabPage19.PerformLayout();
            this.tabPage20.ResumeLayout(false);
            this.tabPage20.PerformLayout();
            this.tabImagenes.ResumeLayout(false);
            this.tabControl8.ResumeLayout(false);
            this.tabPage23.ResumeLayout(false);
            this.tabPage24.ResumeLayout(false);
            this.tabControl9.ResumeLayout(false);
            this.tabPage25.ResumeLayout(false);
            this.tabPage25.PerformLayout();
            this.tabPage26.ResumeLayout(false);
            this.tabPage26.PerformLayout();
            this.tabPage27.ResumeLayout(false);
            this.tabPage27.PerformLayout();
            this.tabPage30.ResumeLayout(false);
            this.tabPage30.PerformLayout();
            this.tabPage32.ResumeLayout(false);
            this.tabPage32.PerformLayout();
            this.tabPage33.ResumeLayout(false);
            this.tabPage33.PerformLayout();
            this.tabPage34.ResumeLayout(false);
            this.tabPage34.PerformLayout();
            this.tabPage35.ResumeLayout(false);
            this.tabPage35.PerformLayout();
            this.tabPage39.ResumeLayout(false);
            this.tabPage39.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage40.ResumeLayout(false);
            this.tabPage40.PerformLayout();
            this.tabPage411.ResumeLayout(false);
            this.tabPage411.PerformLayout();
            this.tabPagarServicio.ResumeLayout(false);
            this.tabControl10.ResumeLayout(false);
            this.tabPage45.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TabControl TabPrincipal;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.Button btnValidaNumero;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbNumeroSocioValidaNumero;
        private System.Windows.Forms.Button btnIniciarSesion;
        private System.Windows.Forms.TextBox tbContrasenaIniciarSesion;
        private System.Windows.Forms.TextBox tbNumeroSocioIniciarSesion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnObtenerInformacionSocio;
        private System.Windows.Forms.TextBox tbNumeroSocioObtenerInformacionSocio;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnActualizarEstatus;
        private System.Windows.Forms.TextBox tbEstatusActualizarEstatus;
        private System.Windows.Forms.TextBox tbNumeroSocioActualizarEstatus;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnValidaContrasenaTemporal;
        private System.Windows.Forms.TextBox tbContrasenaTemporalValidaContrasenaTemporal;
        private System.Windows.Forms.TextBox tbNumeroSocioValidaContrasenaTemporal;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnActivarBanca;
        private System.Windows.Forms.TextBox tbRespuestaActivarBanca;
        private System.Windows.Forms.TextBox tbConfirmaContrasenaActivarBanca;
        private System.Windows.Forms.TextBox tbContrasenaActivarBanca;
        private System.Windows.Forms.TextBox tbNumeroSocioActivarBanca;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnBloqueoTemporal;
        private System.Windows.Forms.TextBox tbNumeroSocioBloqueoTemporal;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnObtenerCatalogoPreguntas;
        private System.Windows.Forms.Label lblRespuesta;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.TabControl tabControl6;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.Button btnObtenerCuentas;
        private System.Windows.Forms.TextBox tbObtenerCuentas;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.Button btnObtenerDetalleCuenta;
        private System.Windows.Forms.TextBox txtNumeroObDetalleCuenta;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button BtnObtenerMovimientosCuentas;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cbPeriodoObtenerMovimientosCuenta;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox tbNumeroSocioObtenerMovimientosCuenta;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cbIdMovObtenerMovimientosCuenta;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.TabControl tabControl7;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.Button btAprovisionarToken;
        private System.Windows.Forms.TextBox btNumeroSocioAprovisionarToken;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.Button btnValidaOTP;
        private System.Windows.Forms.TextBox tbOTPValidaOTP;
        private System.Windows.Forms.TextBox tbNumeroSocioValidaOTP;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TabPage tabImagenes;
        private System.Windows.Forms.TabControl tabControl8;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.Button btEnviarImagenFondo;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.Button btnCambiarContrasena;
        private System.Windows.Forms.TextBox tbConfirmarContrasenaCambiarContrasena;
        private System.Windows.Forms.TextBox tbNuevaContrasenaCambiarContrasena;
        private System.Windows.Forms.TextBox tbNumeroSocioCambiarContrasena;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtNoContratoObDetalleCuenta;
        private System.Windows.Forms.TextBox txtIdCuentaObDetalleCuenta;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox cbMotivoBloqueoBloqueoTemporal;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.TabPage tabPage28;
        private System.Windows.Forms.Button btnDesbloqueoTemporalDB;
        private System.Windows.Forms.TextBox tbNumeroSocioDesbloqueoTemporalDB;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TabPage tabPage29;
        private System.Windows.Forms.Button btnObtenerBancos;
        private System.Windows.Forms.TextBox tbOTPCambiarContrasena;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox tbOTPBloqueoTemporal;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TabPage tabPage31;
        private System.Windows.Forms.Button btnBloqueoTemporalDB1;
        private System.Windows.Forms.TextBox tbNumeroSocioBloqueoTemporalDB;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TabControl tabControl9;
        private System.Windows.Forms.TabPage tabPage25;
        private System.Windows.Forms.TextBox tbOTPAltaCuentasInternas;
        private System.Windows.Forms.TextBox tbCorreoAltaCuentasInternas;
        private System.Windows.Forms.TextBox tbMontoAltaCuentasInternas;
        private System.Windows.Forms.TextBox tbAliasAltaCuentasInternas;
        private System.Windows.Forms.TextBox tbIdCuentaAltaCuentasInternas;
        private System.Windows.Forms.TextBox tbNumeroSocioBeneficiarioAltaCuentasInternas;
        private System.Windows.Forms.TextBox tbNumeroSocioAltaCuentasInternas;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Button btnAltaCuentaInterna;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TabPage tabPage26;
        private System.Windows.Forms.TextBox tbOTPAltaCuentasExternasClabes;
        private System.Windows.Forms.TextBox tbCURPAltaCuentasExternasClabes;
        private System.Windows.Forms.TextBox tbRFCAltaCuentasExternasClabes;
        private System.Windows.Forms.TextBox tbCorreoAltaCuentasExternasClabes;
        private System.Windows.Forms.TextBox tbMontoAltaCuentasExternasClabes;
        private System.Windows.Forms.TextBox tbAliasAltaCuentasExternasClabes;
        private System.Windows.Forms.TextBox tbClabeAltaCuentasExternasClabes;
        private System.Windows.Forms.TextBox tbNombreBeneficiarioAltaCuentasExternasClabes;
        private System.Windows.Forms.TextBox tbNumeroSocioAltaCuentasExternasClabes;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Button btnAltaCuentasExternasClabes;
        private System.Windows.Forms.Label CURP;
        private System.Windows.Forms.Label RFC;
        private System.Windows.Forms.Label Correo;
        private System.Windows.Forms.Label Monto;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TabPage tabPage27;
        private System.Windows.Forms.TextBox txtOTPAlExDeb;
        private System.Windows.Forms.TextBox txtCURPAlExDeb;
        private System.Windows.Forms.TextBox txtCorreoAlExDeb;
        private System.Windows.Forms.TextBox txtMontoAlExDeb;
        private System.Windows.Forms.TextBox txtAliasAlExDeb;
        private System.Windows.Forms.TextBox txtNumeroTarjetaAlExDeb;
        private System.Windows.Forms.TextBox txtBeneficiarioAlExDeb;
        private System.Windows.Forms.TextBox txtNoSocAlExDeb;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Button btnAltaCtaExtDebito;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TabPage tabPage30;
        private System.Windows.Forms.Button btnEliminaCuentaInterna;
        private System.Windows.Forms.TextBox tbOTPEliminaCuentaInterna;
        private System.Windows.Forms.TextBox tbIdCuentaEliminaCuentaInterna;
        private System.Windows.Forms.TextBox tbNumeroSocioEliminaCuentaInterna;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TabPage tabPage32;
        private System.Windows.Forms.Button btnEliminaCuentaClabe;
        private System.Windows.Forms.TextBox tbOTPEliminaCuentaClabe;
        private System.Windows.Forms.TextBox tbIdCuentaEliminaCuentaClabe;
        private System.Windows.Forms.TextBox tbNumeroSocioEliminaCuentaClabe;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TabPage tabPage33;
        private System.Windows.Forms.Button btnObtenerCuentasRetiroInternas;
        private System.Windows.Forms.TextBox tbNumeroSocioObtenerCuentasRetiroInternas;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TabPage tabPage34;
        private System.Windows.Forms.Button btnObtenerCuentasDepositoInternas;
        private System.Windows.Forms.ComboBox cbTipoCuentaObtenerCuentasDepositoInternas;
        private System.Windows.Forms.TextBox tbNumeroSocioObtenerCuentasDepositoInternas;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TabPage tabPage35;
        private System.Windows.Forms.Button btnObtenerCuentasDepositoExternas;
        private System.Windows.Forms.TextBox tbNumeroSocioObtenerCuentasDepositoExternas;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TabPage tabPage36;
        private System.Windows.Forms.Button btnObtenerCategorias;
        private System.Windows.Forms.TabPage tabPage37;
        private System.Windows.Forms.Button btnObtenerServicios;
        private System.Windows.Forms.TextBox tbObtenerServicio;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TabPage tabPage38;
        private System.Windows.Forms.Button btnObtenerProductos;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox tbObtenerProductos;
        private System.Windows.Forms.TabPage tabPage39;

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage40;
        private System.Windows.Forms.Button btnRegistrarServicio;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox tbPrecioRegistrarServicio;
        private System.Windows.Forms.TextBox tbTipoFrontRegistrarServicio;
        private System.Windows.Forms.TextBox tbNumeroReferenciaRegistrarServicio;
        private System.Windows.Forms.TextBox tbTelefonoRegistrarServicio;
        private System.Windows.Forms.TextBox tbIdServicioRegistrarServicio;
        private System.Windows.Forms.TextBox tbIdProductoRegistrarServicio;
        private System.Windows.Forms.Label tbNumeroSocioRegistrarServicio;
        private System.Windows.Forms.Label label701;
        private Label label691;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label681;
        private System.Windows.Forms.Label label671;
        private System.Windows.Forms.Label label661;
        private System.Windows.Forms.Label label651;
        private System.Windows.Forms.TabPage tabPage411;
        private System.Windows.Forms.Button btnEliminarServicio;
        private System.Windows.Forms.TextBox tbNumeroSocioEliminarServicio;
        private System.Windows.Forms.TextBox tbIdServicioEliminarServicio;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox tbClabeAltaCuentasInternas;
        private System.Windows.Forms.TextBox tbIdCuentaExtenaAltaCuentasExternasClabes;
        private System.Windows.Forms.Label label74;

        private System.Windows.Forms.Button btnObtenerPreguntaSecreta;
        private System.Windows.Forms.TextBox txtNumeroSocioPreguntaSecreta;
        private TabPage tabPage41;
        private Button btnObtenerPreguntaSecreta1;
        private TextBox txtNumeroSocioPreguntaSecreta1;
        private Label label65;
        private TabPage tabPage42;
        private Label label66;
        private Label label67;
        private Label label70;
        private Label label68;
        private Label label75;
        private Label label76;
        private TextBox tbIdProductoRegistrarServicio1;
        private Label label77;
        private TextBox tbIdServicioRegistrarServicio1;
        private TextBox tbNumeroSocioRegistrarServicio1;
        private TextBox tbPrecioRegistrarServicio1;
        private TextBox tbTipoFrontRegistrarServicio1;
        private TextBox tbNumeroReferenciaRegistrarServicio1;
        private TextBox tbTelefonoRegistrarServicio1;
        private Button btnRegistrarServicio1;
        private TabPage tabPage43;
        private Button btnObtenerServiciosRecurrentes;
        private TabPage tabPagarServicio;
        private TabControl tabControl10;
        private TabPage tabPage45;
        private TableLayoutPanel tableLayoutPanel2;
        private ComboBox cbCategoria;
        private ComboBox cbServicios;
        private ComboBox cbProductos;
        private TextBox txtTelefono;
        private TextBox txtReferencia;
        private Label label81;
        private Label label82;
        private Label label83;
        private Label label84;
        private Label label85;
        private TextBox txtMonto;
        private Label label86;
        private Button btnPagarServicio;
        private Label lbl21654;
        private TextBox txtNumeroSocioPagoServicio;
        private TabPage tabPage21;
        private Label label80;
        private Label label79;
        private Label label78;
        private TextBox txtMontoInversion;
        private TextBox txtDiasInversion;
        private TextBox txtNumeroInversion;
        private TabPage tabPage44;
        private Label label88;
        private TextBox txtOTPInver;
        private Label label87;
        private TextBox txtTasaInversion;
        private Button btnRealizarInversion;
        //private System.Windows.Forms.Label label66;

    }
}

