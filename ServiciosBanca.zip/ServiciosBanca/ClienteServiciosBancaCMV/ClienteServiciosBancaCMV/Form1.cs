﻿using ClienteServiciosBancaCMV.ServiceSesion;
using ClienteServiciosBancaCMV.ServiceSocio;
using ClienteServiciosBancaCMV.ServiceCatalogo;
using ServiciosBancaUtils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClienteServiciosBancaCMV.ServiceCuenta;
using ClienteServiciosBancaCMV.ServiceToken;
using ClienteServiciosBancaCMV.ServiceImagenes;
using System.IO;
using ClienteServiciosBancaCMV.ServiceBloqueo;
using ClienteServiciosBancaCMV.ServiceTransferencia;
using ClienteServiciosBancaCMV.ServiceServicios;
using ClienteServiciosBancaCMV.DAO;
using ClienteServiciosBancaCMV.ServiceInversiones;
using System.ServiceModel.Channels;

namespace ClienteServiciosBancaCMV
{
    public partial class Form1 : Form
    {
        private GestoPagoDAO gDAO = null;

        public Form1()
        {
            InitializeComponent();
            gDAO = new GestoPagoDAO();
        }

        private void btnValidaNumero_Click(object sender, EventArgs e)
        {
            try
            {
                RequestValidaNumero request = new RequestValidaNumero();
                request.NumeroSocio = this.tbNumeroSocioValidaNumero.Text;
                SesionClient obj = new SesionClient();
                ResponseValidaNumero response = obj.ValidaNumero(request);
                this.lblRespuesta.Text = SerializerManager<ResponseValidaNumero>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionValidaNumero> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionValidaNumero>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            try
            {
                RequestIniciarSesion request = new RequestIniciarSesion();
                request.NumeroSocio = this.tbNumeroSocioIniciarSesion.Text;
                request.Contrasena = this.tbContrasenaIniciarSesion.Text;
                SesionClient obj = new SesionClient();
                ResponseIniciarSesion response = obj.AutenticarSocio(request);
                this.lblRespuesta.Text = SerializerManager<ResponseIniciarSesion>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionIniciarSesion> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionIniciarSesion>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnObtenerInformacionSocio_Click(object sender, EventArgs e)
        {
            try
            {
                RequestObtenerInformacionSocio request = new RequestObtenerInformacionSocio();
                request.NumeroSocio = this.tbNumeroSocioObtenerInformacionSocio.Text;
                SocioClient obj = new SocioClient();
                ResponseObtenerInformacionSocio response = obj.ObtenerInformacionSocio(request);
                this.lblRespuesta.Text = SerializerManager<ResponseObtenerInformacionSocio>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionObtenerInformacionSocio> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionObtenerInformacionSocio>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnActualizarEstatus_Click(object sender, EventArgs e)
        {
            try
            {
                RequestActualizarEstatus request = new RequestActualizarEstatus();
                request.NumeroSocio = tbNumeroSocioActualizarEstatus.Text;
                request.Estatus = Convert.ToInt32(tbEstatusActualizarEstatus.Text); 
                SocioClient obj = new SocioClient();
                ResponseActualizarEstatus response = obj.ActualizarEstatus(request);
                this.lblRespuesta.Text = SerializerManager<ResponseActualizarEstatus>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionActualizarEstatus> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionActualizarEstatus>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnValidaContrasenaTemporal_Click(object sender, EventArgs e)
        {
            try
            {
                RequestValidaContrasenaTemporal request = new RequestValidaContrasenaTemporal();
                request.NumeroSocio = tbNumeroSocioValidaContrasenaTemporal.Text;
                request.ContrasenaTemporal = tbContrasenaTemporalValidaContrasenaTemporal.Text;
                SocioClient obj = new SocioClient();
                ResponseValidaContrasenaTemporal response = obj.ValidaContrasenaTemporal(request);
                this.lblRespuesta.Text = SerializerManager<ResponseValidaContrasenaTemporal>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionValidaContrasenaTemporal> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionValidaContrasenaTemporal>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnActivarBanca_Click(object sender, EventArgs e)
        {
            try
            {
                RequestActivarBanca request = new RequestActivarBanca();
                request.NumeroSocio = this.tbNumeroSocioActivarBanca.Text;
                request.NuevaContrasena = this.tbContrasenaActivarBanca.Text;
                request.ContrasenaConfirmada = this.tbConfirmaContrasenaActivarBanca.Text;
                request.IdPregunta = 1;
                request.Respuesta = this.tbRespuestaActivarBanca.Text;
                SocioClient obj = new SocioClient();
                ResponseActivarBanca response = obj.ActivarBanca(request);
                this.lblRespuesta.Text = SerializerManager<ResponseActivarBanca>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionActivarBanca> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionActivarBanca>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnObtenerCatalogoPreguntas_Click(object sender, EventArgs e)
        {
            try
            {
                CatalogoClient obj = new CatalogoClient();
                List<ResponseObtenerCatalogoPreguntas> response = obj.ObtenerCatalogoPreguntas().ToList();
                this.lblRespuesta.Text = SerializerManager<List<ResponseObtenerCatalogoPreguntas>>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionActivarBanca> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionActivarBanca>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnObtenerCuentas_Click(object sender, EventArgs e)
        {
            try
            {
                RequestObtenerCuentas request = new RequestObtenerCuentas();
                request.NumeroSocio = this.tbObtenerCuentas.Text;
                request.TipoCuenta = 0;
                CuentasClient obj = new CuentasClient();
                ResponseObtenerCuentas response = obj.ObtenerCuentas(request);
                this.lblRespuesta.Text = SerializerManager<ResponseObtenerCuentas>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionObtenerCuentas> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionObtenerCuentas>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnObtenerDetalleCuenta_Click(object sender, EventArgs e)
        {
            try
            {
                RequestObtenerDetalleCuenta request = new RequestObtenerDetalleCuenta();
                request.NumeroSocio = this.txtNumeroObDetalleCuenta.Text;
                request.IdCuenta = Convert.ToInt32(this.txtIdCuentaObDetalleCuenta.Text);
                request.NumeroContrato= string.IsNullOrEmpty(this.txtNoContratoObDetalleCuenta.Text) ? "0": this.txtNoContratoObDetalleCuenta.Text;
                CuentasClient obj = new CuentasClient();
                ResponseObtenerDetalleCuenta response = obj.ObtenerDetalleCuenta(request);
                this.lblRespuesta.Text = SerializerManager<ResponseObtenerDetalleCuenta>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionObtenerDetalleCuenta> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionObtenerDetalleCuenta>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void BtnObtenerMovimientosCuentas_Click(object sender, EventArgs e)
        {
            try
            {
                RequestObtenerMovimientosCuenta request = new RequestObtenerMovimientosCuenta();
               
                request.NumeroSocio = this.tbNumeroSocioObtenerMovimientosCuenta.Text;
                request.IdCuenta = Convert.ToInt32(this.cbIdMovObtenerMovimientosCuenta.Text);
                request.PeriodoActual = (this.cbPeriodoObtenerMovimientosCuenta.Text.Equals("Actual") ? true : false);
                CuentasClient obj = new CuentasClient();
                var eab = new EndpointAddressBuilder(obj.Endpoint.Address);
                eab.Headers.Add(AddressHeader.CreateAddressHeader("Usuario",string.Empty, "CMVF1nZ4S"));
                eab.Headers.Add(AddressHeader.CreateAddressHeader("Contrasena", string.Empty, "8DED40B6E19F14D1651FDDF063CDD2"));
                obj.Endpoint.Address = eab.ToEndpointAddress();
                ResponseObtenerMovimientosCuenta response = obj.ObtenerMovimientosCuenta(request);
                this.lblRespuesta.Text = SerializerManager<ResponseObtenerMovimientosCuenta>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionObtenerMovimientosCuenta> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionObtenerMovimientosCuenta>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btAprovisionarToken_Click(object sender, EventArgs e)
        {
            try
            {
                RequestAprovisionarToken request = new RequestAprovisionarToken();
                request.NumeroSocio = this.btNumeroSocioAprovisionarToken.Text;
                TokenClient  obj = new TokenClient();
                ResponseAprovisionarToken response = obj.AprovisionarToken(request);
                this.lblRespuesta.Text = SerializerManager<ResponseAprovisionarToken>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionAprovisionarToken> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionAprovisionarToken>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnValidaOTP_Click(object sender, EventArgs e)
        {
            try
            {
                RequestValidaOTP request = new RequestValidaOTP();
                request.NumeroSocio = this.tbNumeroSocioValidaOTP.Text;
                request.OTP = this.tbOTPValidaOTP.Text;
                TokenClient obj = new TokenClient();
                ResponseValidaOTP response = obj.ValidarOTP(request);
                this.lblRespuesta.Text = SerializerManager<ResponseValidaOTP>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionValidaOTP> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionValidaOTP>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btEnviarImagenFondo_Click(object sender, EventArgs e)
        {
            try
            {
                
                ImagenesClient obj = new ImagenesClient();
                byte[] imagen = obj.ObtenerFondoPantalla();
                MemoryStream ms = new MemoryStream(imagen);
                this.pictureBox1.Image = Image.FromStream(ms);
                this.lblRespuesta.Text = SerializerManager<byte[]>.SerealizarObjtecToString(imagen);

            }
            catch (FaultException<ExceptionValidaOTP> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionValidaOTP>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnCambiarContrasena_Click(object sender, EventArgs e)
        {
            try
            {
                RequestCambiarContrasena request = new RequestCambiarContrasena();
                request.NumeroSocio = this.tbNumeroSocioCambiarContrasena.Text;
                request.ContrasenaN = this.tbNuevaContrasenaCambiarContrasena.Text;
                request.ConfirmarNuevaContrasena = this.tbConfirmarContrasenaCambiarContrasena.Text;
                request.OTP = this.tbOTPCambiarContrasena.Text;
                SocioClient obj = new SocioClient();
                ResponseCambiarContrasena response = obj.CambiarContrasena(request);
                this.lblRespuesta.Text = SerializerManager<ResponseCambiarContrasena>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionCambiarContrasena> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionCambiarContrasena>.SerealizarObjtecToString(ex.Detail);
            }
            catch (FaultException ef)
            {
                
                this.lblRespuesta.Text = SerializerManager<FaultException>.SerealizarObjtecToString(ef);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnBloqueoTemporal_Click(object sender, EventArgs e)
        {
            try
            {
                string bloqueo = string.Empty;
                RequestBloqueoTemporal request = new RequestBloqueoTemporal();
                request.NumeroSocio = this.tbNumeroSocioBloqueoTemporal.Text;
                bloqueo = this.cbMotivoBloqueoBloqueoTemporal.Text;
                switch (bloqueo)
                {
                    case "Desbloqueado":
                        request.IdMotivoBloqueo = 1;
                    break;
                    case "Bloqueo temporal por intentos fallidos":
                        request.IdMotivoBloqueo = 2;
                    break;
                    case "Bloqueo temporal de acceso":
                        request.IdMotivoBloqueo = 3;
                    break;
                    case "Bloqueo temporal a petición en sucursales":
                        request.IdMotivoBloqueo = 4;
                    break;
                    default:
                    break;
                }
                request.OTP = this.tbOTPBloqueoTemporal.Text;
                BloqueoClient obj = new BloqueoClient();
                ResponseBloqueoTemporal response = obj.BloqueoTemporal(request);
                this.lblRespuesta.Text = SerializerManager<ResponseBloqueoTemporal>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionBloqueoTemporal> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionBloqueoTemporal>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnAltaCuentaInterna_Click(object sender, EventArgs e)
        {
            try
            {
                RequestAltaCuentaInterna request = new RequestAltaCuentaInterna();
                request.NumeroSocioAlta = this.tbNumeroSocioAltaCuentasInternas.Text;
                request.NumeroSocio = this.tbNumeroSocioBeneficiarioAltaCuentasInternas.Text;
                request.IdCuentaDestino = Convert.ToInt32(this.tbIdCuentaAltaCuentasInternas.Text);
                request.Alias = this.tbAliasAltaCuentasInternas.Text;
                request.MontoMaximo = Convert.ToDecimal(this.tbMontoAltaCuentasInternas.Text);
                request.Correo = this.tbCorreoAltaCuentasInternas.Text;
                request.OTP = this.tbOTPAltaCuentasInternas.Text;
                request.Clabe = this.tbClabeAltaCuentasInternas.Text;              
                TransferenciaClient obj = new TransferenciaClient();
                ResponseAltaCuentaInterna response = obj.AltaCuentaInterna(request);
                this.lblRespuesta.Text = SerializerManager<ResponseAltaCuentaInterna>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionAltaCuentaInterna> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionAltaCuentaInterna>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }

        }

        private void btnAltaCuentasExternasClabes_Click(object sender, EventArgs e)
        {
            try
            {
                RequestAltaCuentaExternaClabe request = new RequestAltaCuentaExternaClabe();
                request.NumeroSocio = this.tbNumeroSocioAltaCuentasExternasClabes.Text;
                request.Alias = this.tbAliasAltaCuentasExternasClabes.Text;
                request.MontoMaximo = Convert.ToDecimal(this.tbMontoAltaCuentasExternasClabes.Text);
                request.Correo = this.tbCorreoAltaCuentasExternasClabes.Text;
                request.NombreBeneficiario = this.tbNombreBeneficiarioAltaCuentasExternasClabes.Text;
                request.Clabe = this.tbClabeAltaCuentasExternasClabes.Text;
                request.RFC = this.tbRFCAltaCuentasExternasClabes.Text;
                request.CURP = this.tbCURPAltaCuentasExternasClabes.Text;
                request.OTP = this.tbOTPAltaCuentasExternasClabes.Text;
                request.IdCuentaExterna = Convert.ToInt32(this.tbIdCuentaExtenaAltaCuentasExternasClabes.Text);
                TransferenciaClient obj = new TransferenciaClient();
                ResponseAltaCuentaExternaClabe response = obj.AltaCuentaExternaClabe(request);
                this.lblRespuesta.Text = SerializerManager<ResponseAltaCuentaExternaClabe>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionAltaCuentaExternaClabe> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionAltaCuentaExternaClabe>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnAltaCtaExtDebito_Click(object sender, EventArgs e)
        {
            try
            {
                RequestAltaCuentaExternaDebito request = new RequestAltaCuentaExternaDebito();
                request.NumeroSocio = this.txtNoSocAlExDeb.Text;
                request.Alias = this.txtAliasAlExDeb.Text;
                request.MontoMaximo = Convert.ToDecimal(this.txtMontoAlExDeb.Text);
                request.Correo = this.txtCorreoAlExDeb.Text;
                request.Beneficiario = this.txtBeneficiarioAlExDeb.Text;
                request.NumeroTarjeta = this.txtNumeroTarjetaAlExDeb.Text;
                request.CURP = this.txtCURPAlExDeb.Text;
                request.OTP = this.txtOTPAlExDeb.Text;
                TransferenciaClient obj = new TransferenciaClient();
                ResponseAltaCuentaExternaDebito response = obj.AltaCuentaExternaDebito(request);
                this.lblRespuesta.Text = SerializerManager<ResponseAltaCuentaExternaDebito>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionAltaCuentaExternaDebito> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionAltaCuentaExternaDebito>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }
        
        private void btnDesbloqueoTemporalDB_Click(object sender, EventArgs e)
        {
            try
            {
                RequestDesbloqueoTemporalDataBanking request = new RequestDesbloqueoTemporalDataBanking();
                request.NumeroSocio = this.tbNumeroSocioDesbloqueoTemporalDB.Text;
                BloqueoClient obj = new BloqueoClient();
                ResponseDesbloqueoTemporalDataBanking response = obj.DesbloqueoTemporalDataBanking(request);
                this.lblRespuesta.Text = SerializerManager<ResponseDesbloqueoTemporalDataBanking>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionDesbloqueoTemporalDataBanking> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionDesbloqueoTemporalDataBanking>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnObtenerBancos_Click(object sender, EventArgs e)
        {
            try
            {
                CatalogoClient obj = new CatalogoClient();
                List<ResponseObtenerBancos> response = obj.ObtenerBancos().ToList();
                this.lblRespuesta.Text = SerializerManager<List<ResponseObtenerBancos>>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionObtenerBancos> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionObtenerBancos>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnEliminaCuentaInterna_Click(object sender, EventArgs e)
        {
            try
            {
                RequestEliminarCuentaInterna request = new RequestEliminarCuentaInterna();
                request.NumeroSocio = this.tbNumeroSocioEliminaCuentaInterna.Text;
                request.IdCuentaInterna = this.tbIdCuentaEliminaCuentaInterna.Text;
                request.OTP = this.tbOTPEliminaCuentaInterna.Text;
                TransferenciaClient obj = new TransferenciaClient();
                ResponseEliminarCuentaInterna response = obj.EliminaCuentaInterna(request);
                this.lblRespuesta.Text = SerializerManager<ResponseEliminarCuentaInterna>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionEliminarCuentaInterna> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionEliminarCuentaInterna>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnBloqueoTemporalDB1_Click(object sender, EventArgs e)
        {
            try
            {
                RequestBloqueoTemporalDataBanking request = new RequestBloqueoTemporalDataBanking();
                request.NumeroSocio = this.tbNumeroSocioBloqueoTemporalDB.Text;
                BloqueoClient obj = new BloqueoClient();
                ResponseBloqueoTemporalDataBanking response = obj.BloqueoTemporalDataBanking(request);
                this.lblRespuesta.Text = SerializerManager<ResponseBloqueoTemporalDataBanking>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionBloqueoTemporalDataBanking> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionBloqueoTemporalDataBanking>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnEliminaCuentaClabe_Click(object sender, EventArgs e)
        {
            try
            {
                RequestEliminaCuentaExterna request = new RequestEliminaCuentaExterna();
                request.NumeroSocio = this.tbNumeroSocioEliminaCuentaClabe.Text;
                request.IdCuentaExterna = this.tbIdCuentaEliminaCuentaClabe.Text;
                request.OTP = this.tbOTPEliminaCuentaClabe.Text;
                TransferenciaClient obj = new TransferenciaClient();
                ResponseEliminaCuentaExterna response = obj.EliminaCuentaExterna(request);
                this.lblRespuesta.Text = SerializerManager<ResponseEliminaCuentaExterna>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionEliminaCuentaExterna> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionEliminaCuentaExterna>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnObtenerCuentasRetiroInternas_Click(object sender, EventArgs e)
        {
            try
            {
                RequestObtenerCuentasRetiro request = new RequestObtenerCuentasRetiro();
                request.NumeroSocio = this.tbNumeroSocioObtenerCuentasRetiroInternas.Text;
                TransferenciaClient obj = new TransferenciaClient();
                List<ResponseObtenerCuentasRetiro> response = obj.ObtenerCuentasRetiro(request).ToList();
                this.lblRespuesta.Text = SerializerManager<List<ResponseObtenerCuentasRetiro>>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionObtenerCuentasRetiro> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionObtenerCuentasRetiro>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnObtenerCuentasDepositoInternas_Click(object sender, EventArgs e)
        {
            try
            {
                string tipoCuenta = string.Empty;
                RequestObtenerCuentasDepositoInterna request = new RequestObtenerCuentasDepositoInterna();
                request.NumeroSocio = this.tbNumeroSocioObtenerCuentasDepositoInternas.Text;
                tipoCuenta = this.cbTipoCuentaObtenerCuentasDepositoInternas.Text;
                switch (tipoCuenta)
                {
                    case "Todas":
                        request.TipoCuenta = 0;
                        break;
                    case "Credito":
                        request.TipoCuenta = 1;
                        break;
                    case "Haberes":
                        request.TipoCuenta = 2;
                        break;
                    default:
                        request.TipoCuenta = 0;
                        break;
                }
                TransferenciaClient obj = new TransferenciaClient();
                List<ResponseObtenerCuentasDepositoInterna> response = obj.ObtenerCuentasDepositoInterna(request).ToList();
                this.lblRespuesta.Text = SerializerManager<List<ResponseObtenerCuentasDepositoInterna>>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionObtenerCuentasDepositoInterna> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionObtenerCuentasDepositoInterna>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }

        }

        private void btnObtenerCuentasDepositoExternas_Click(object sender, EventArgs e)
        {
            try
            {
                RequestObtenerCuentasDepositoExternas request = new RequestObtenerCuentasDepositoExternas();
                request.NumeroSocio = this.tbNumeroSocioObtenerCuentasDepositoExternas.Text;
                TransferenciaClient obj = new TransferenciaClient();
                List<ResponseObtenerCuentasDepositoExternas> response = obj.ObtenerCuentasDepositoExternas(request).ToList();
                this.lblRespuesta.Text = SerializerManager<List<ResponseObtenerCuentasDepositoExternas>>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionObtenerCuentasDepositoExternas> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionObtenerCuentasDepositoExternas>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnObtenerCategorias_Click(object sender, EventArgs e)
        {
            try
            {
                RequestObtenerCategoriasServicios request = new RequestObtenerCategoriasServicios();
                CatalogoClient obj = new CatalogoClient();
                ResponseObtenerCategoriasServicios response = obj.ObtenerCategoriasServicios(request);
                this.lblRespuesta.Text = SerializerManager<ResponseObtenerCategoriasServicios>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionObtenerCategoriasServicios> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionObtenerCategoriasServicios>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnObtenerServicios_Click(object sender, EventArgs e)
        {
            try
            {
                RequestObtenerServicios request = new RequestObtenerServicios();
                CatalogoClient obj = new CatalogoClient();
                request.IdCategoria = Convert.ToInt32(this.tbObtenerServicio.Text);
                ResponseObtenerServicios response = obj.ObtenerServicios(request);
                this.lblRespuesta.Text = SerializerManager<ResponseObtenerServicios>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionObtenerServicios> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionObtenerServicios>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnObtenerProductos_Click(object sender, EventArgs e)
        {
            try
            {
                RequestObtenerProductos request = new RequestObtenerProductos();
                CatalogoClient obj = new CatalogoClient();
                request.IdServicio = Convert.ToInt32(this.tbObtenerProductos.Text);
                ResponseObtenerProductos response = obj.ObtenerProductos(request);
                this.lblRespuesta.Text = SerializerManager<ResponseObtenerProductos>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionObtenerProductos> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionObtenerProductos>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }


        private void btnRegistrarServicio_Click(object sender, EventArgs e)
        {
            try
            {
                RequestRegistrarServicio request = new RequestRegistrarServicio();
                PagoServicioClient obj = new PagoServicioClient();
                request.IdProducto = Convert.ToInt32(this.tbIdProductoRegistrarServicio1.Text);
                request.IdServicio = Convert.ToInt32(this.tbIdServicioRegistrarServicio1.Text);
                request.Telefono = this.tbTelefonoRegistrarServicio1.Text;
                request.NumeroReferencia = this.tbNumeroReferenciaRegistrarServicio1.Text;
                request.TipoFront = Convert.ToInt32(this.tbTipoFrontRegistrarServicio1.Text);
                request.Precio = Convert.ToDecimal(this.tbPrecioRegistrarServicio1.Text);
                request.NumeroSocio = this.tbNumeroSocioRegistrarServicio1.Text;
                ResponseRegistrarServicio response = obj.RegistrarServicio(request);
                this.lblRespuesta.Text = SerializerManager<ResponseRegistrarServicio>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionRegistrarServicio> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionRegistrarServicio>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnEliminarServicio_Click(object sender, EventArgs e)
        {
            try
            {
                RequestEliminarServicioSocio request = new RequestEliminarServicioSocio();
                SocioClient obj = new SocioClient();
                request.NumeroSocio = this.tbNumeroSocioEliminarServicio.Text;
                request.IdServicioSocio = Convert.ToInt32(this.tbIdServicioEliminarServicio.Text);
                ResponseEliminarServicioSocio response = obj.EliminarServicioSocio(request);
                this.lblRespuesta.Text = SerializerManager<ResponseEliminarServicioSocio>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ResponseEliminarServicioSocio> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ResponseEliminarServicioSocio>.SerealizarObjtecToString(ex.Detail);
            }
        }
        private void btnObtenerPreguntaSecreta_Click(object sender, EventArgs e)
        {
            try
            {
                RequestObtenerPreguntaSecreta request = new RequestObtenerPreguntaSecreta();
                request.NumeroSocio = this.txtNumeroSocioPreguntaSecreta1.Text;
                SocioClient obj = new SocioClient();
                ResponseObtenerPreguntaSecreta response = obj.ObtenerPreguntaSecreta(request);
                this.lblRespuesta.Text = SerializerManager<ResponseObtenerPreguntaSecreta>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionObtenerPreguntaSecreta> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionObtenerPreguntaSecreta>.SerealizarObjtecToString(ex.Detail);

            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void btnObtenerServiciosRecurrentes_Click(object sender, EventArgs e)
        {
            try
            {
                CatalogoClient obj = new CatalogoClient();
                ResponseObtenerServiciosRecurrentes response = obj.ObtenerServiciosRecurrentes();
                this.lblRespuesta.Text = SerializerManager<ResponseObtenerServiciosRecurrentes>.SerealizarObjtecToString(response);
            }
            catch (FaultException<ExceptionObtenerServiciosRecurrentes> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionObtenerServiciosRecurrentes>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {

                MessageBox.Show(ex1.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                cbCategoria.DataSource = gDAO.ObtenerCategorias();
                cbCategoria.DisplayMember = "Descripcion";
                cbCategoria.ValueMember = "IdCategoria";

            }
            catch (Exception)
            {

                throw;
            }

        }

        private void btnPagarServicio_Click(object sender, EventArgs e)
        {
            try
            {
                ServiceServicios.PagoServicioClient pagoServicioClient = new PagoServicioClient();
                RequestPagarServicios requestPagarServicios = new RequestPagarServicios();
                requestPagarServicios.IdCuentaRetiro = 100;
                requestPagarServicios.IdProducto = Convert.ToInt16(this.cbProductos.SelectedValue);
                requestPagarServicios.IdServicio = Convert.ToInt16(this.cbServicios.SelectedValue);
                requestPagarServicios.Monto = string.IsNullOrEmpty(this.txtMonto.Text) ? 0 : Convert.ToDecimal(this.txtMonto.Text);
                requestPagarServicios.NumeroReferencia = string.IsNullOrEmpty(this.txtReferencia.ToString()) ? "" : this.txtReferencia.Text.ToString();
                requestPagarServicios.Telefono = this.txtTelefono.Text.ToString();
                requestPagarServicios.TipoFront = (this.cbProductos.SelectedItem as Entidades.Producto).TipoFront;
                requestPagarServicios.NumeroSocio = this.txtNumeroSocioPagoServicio.Text;
                requestPagarServicios.IdOrigen =  ServiceServicios.TipoOrigen.BANCA_WEB_;
                
                requestPagarServicios.OTP = "12345";
                ResponsePagarServicios responsePagarServicios = pagoServicioClient.PagarServicio(requestPagarServicios);
                this.lblRespuesta.Text = SerializerManager<ResponsePagarServicios>.SerealizarObjtecToString(responsePagarServicios);

            }
            catch (FaultException<ExceptionPagarServicios> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionPagarServicios>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }

        private void cbCategoria_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                cbServicios.DataSource = gDAO.ObtenerServicios(Convert.ToInt16(this.cbCategoria.SelectedValue));
                cbServicios.DisplayMember = "Descripcion";
                cbServicios.ValueMember = "IdServicio";
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cbServicios_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                cbProductos.DataSource = gDAO.ObtenerProductos(Convert.ToInt16(this.cbServicios.SelectedValue));
                cbProductos.DisplayMember = "Descripcion";
                cbProductos.ValueMember = "IdProducto";

            }
            catch (Exception ex)
            {
                Errores(ex);
            }
        }
        public void Errores(Exception ex)
        {
            MessageBox.Show("Error: " + ex.Message + "\n" + ex.StackTrace);

        }

        private void cbProductos_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                this.txtMonto.Enabled = this.txtReferencia.Enabled = this.txtTelefono.Enabled = true;
                if (Convert.ToInt16(this.cbProductos.SelectedValue) > -1)
                {
                    Entidades.Producto p = (Entidades.Producto)this.cbProductos.SelectedItem;
                    switch (p.TipoFront)
                    {
                        case 1:
                            this.txtMonto.Enabled = this.txtReferencia.Enabled = false;
                            this.txtMonto.Text = p.Precio.ToString();
                            break;
                        case 2:
                            this.txtTelefono.Enabled = false;
                            break;
                        case 4:
                            this.txtMonto.Enabled = this.txtTelefono.Enabled = false;
                            break;

                        default:
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Errores(ex);
            }
        }

        private void btnBloqueoTemporalDB_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (this.TabPrincipal.TabPages[TabPrincipal.SelectedIndex].Name == "tabImagenes")
            {
                this.pictureBox1.Visible = true;
            }else
            {
                this.pictureBox1.Visible = false;
            }
        }

        private void btnRealizarInversion_Click(object sender, EventArgs e)
        {
            try
            {
              
                ServiceInversiones.InversionesClient inversionesClient = new ServiceInversiones.InversionesClient();
                ServiceInversiones.RequestRealizarInversion requestRealizarInversion = new ServiceInversiones.RequestRealizarInversion();

                List<CuentaInversion> cuentas = new List<CuentaInversion>();
                cuentas.Add(new CuentaInversion() { IdCuenta = 100, Monto = 200 });
                cuentas.Add(new CuentaInversion() { IdCuenta = 103, Monto = 100 });
                cuentas.Add(new CuentaInversion() { IdCuenta = 112, Monto = 50 });
                requestRealizarInversion.CuentasRetiro = cuentas.ToArray();
                requestRealizarInversion.NumeroSocio = this.txtNumeroInversion.Text;
                requestRealizarInversion.OTP = this.txtOTPInver.Text;
                requestRealizarInversion.Dias =Convert.ToInt16(this.txtDiasInversion.Text);
                requestRealizarInversion.TipoOrigen = ServiceInversiones.TipoOrigen.BANCA_WEB_;
                requestRealizarInversion.Tasa = Convert.ToDecimal(this.txtTasaInversion.Text);
                this.lblRespuesta.Text = SerializerManager<ResponseRealizarInversion>.SerealizarObjtecToString(inversionesClient.RealizarInversion(requestRealizarInversion));
            }
            catch (FaultException<ExceptionRealizarInversion> ex)
            {
                this.lblRespuesta.Text = SerializerManager<ExceptionRealizarInversion>.SerealizarObjtecToString(ex.Detail);
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }
    }
}
