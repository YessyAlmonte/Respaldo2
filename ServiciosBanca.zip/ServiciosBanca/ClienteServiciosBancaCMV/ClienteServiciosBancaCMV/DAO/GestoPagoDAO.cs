﻿using AccesoDatos;
using ClienteServiciosBancaCMV.Entidades;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClienteServiciosBancaCMV.DAO
{
    public class GestoPagoDAO
    {
        private DBManager db = null;
        public GestoPagoDAO()
        {

        }
        public bool InsertaServiciosProductosGestoPago(string xml)
        {
            try
            {
                string headerXml = "<?xml version='1.0' encoding='UTF-8'?>";
                xml = xml.Substring(headerXml.Length);
                xml = xml.Replace("'", @"""");
                using (db = new DBManager(ConfigurationManager.ConnectionStrings["cmv8009"].ConnectionString))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@var_xml", xml);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_INSERTA_SERVICIOS_PRODUCTOS_GESTO_PAGO");
                    while (db.DataReader.Read())
                    {
                        Console.WriteLine(db.DataReader["mensaje"].ToString());
                        if (string.Compare(db.DataReader["estatus"].ToString(), "1") == 0)
                            return true;
                        else
                            return false;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public List<Categoria> ObtenerCategorias()
        {

            List<Categoria>  categorias = new List<Categoria>();
            try
            {
                using (db = new DBManager(ConfigurationManager.ConnectionStrings["cmv8009"].ConnectionString))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@idGrupo", DBNull.Value);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_CATEGORIAS_PAGO_SERVICIOS");
                    while (db.DataReader.Read())
                    {
                        Categoria c = new Categoria();
                        c.IdCategoria = Convert.ToInt32(db.DataReader["id_categoria_servicios_pago"].ToString());
                        c.Descripcion = String.IsNullOrEmpty(db.DataReader["descripcion"].ToString()) ? "" : db.DataReader["descripcion"].ToString();
                        categorias.Add(c);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            categorias.Insert(0, new Categoria() { IdCategoria = -1, Descripcion = "-- Selecciona --" });
            return categorias;
        }
        public List<Servicio> ObtenerServicios(int idCategoria)
        {
            List<Servicio> servicios = new List<Servicio>();
            try
            {
                using (db = new DBManager(ConfigurationManager.ConnectionStrings["cmv8009"].ConnectionString))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@IdCategoria", idCategoria);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_SERVICIOS_PAGO_SERVICIOS");
                    while (db.DataReader.Read())
                    {
                        Servicio s = new Servicio();
                        s.IdServicio = string.IsNullOrEmpty(db.DataReader["id_servicios_pago"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_servicios_pago"].ToString());
                        s.Descripcion = String.IsNullOrEmpty(db.DataReader["descripcion"].ToString()) ? "" : db.DataReader["descripcion"].ToString();
                        servicios.Add(s);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            servicios.Insert(0, new Servicio() { IdServicio = -1, Descripcion = "-- Selecciona --" });
            return servicios;
        }
        public List<Producto> ObtenerProductos(int idServicio)
        {
            List<Producto> productos = new List<Producto>();
            try
            {
                using (db = new DBManager(ConfigurationManager.ConnectionStrings["cmv8009"].ConnectionString))
                {
                    db.Open();
                    db.CreateParameters(1);
                    db.AddParameters(0, "@IdServicio", idServicio);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_OBTENER_PRODUCTOS_PAGO_SERVICIOS");
                    while (db.DataReader.Read())
                    {
                        Producto p = new Producto();
                        p.IdProducto = string.IsNullOrEmpty(db.DataReader["id_producto"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["id_producto"].ToString());
                        p.Descripcion = String.IsNullOrEmpty(db.DataReader["descripcion"].ToString()) ? "" : db.DataReader["descripcion"].ToString();
                        p.Precio = string.IsNullOrEmpty(db.DataReader["precio"].ToString()) ? 0 : Convert.ToDecimal(db.DataReader["precio"].ToString());
                        p.TipoFront = string.IsNullOrEmpty(db.DataReader["tipo_front"].ToString()) ? 0 : Convert.ToInt32(db.DataReader["tipo_front"].ToString());
                        p.TipoReferencia = String.IsNullOrEmpty(db.DataReader["tipo_referencia"].ToString()) ? "" : db.DataReader["tipo_referencia"].ToString();
                        productos.Add(p);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            productos.Insert(0, new Producto() { IdProducto = -1, Descripcion = "-- Selecciona --" });
            return productos;
        }
    }
}
