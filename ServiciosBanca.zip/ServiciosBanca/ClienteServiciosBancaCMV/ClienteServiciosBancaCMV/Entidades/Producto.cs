﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ClienteServiciosBancaCMV.Entidades
{
    [DataContract]
    public class Producto
    {
        [DataMember]
        public int IdProducto { get; set; }
        [DataMember]
        public string Descripcion { get; set; }
        [DataMember]
        public int TipoFront { get; set; }
        [DataMember]
        public Decimal Precio { get; set; }
        [DataMember]
        public string TipoReferencia { get; set; }
    }
}
