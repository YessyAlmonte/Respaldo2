USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_REVOLVENTE_REALIZA_PAGO]    Script Date: 15/10/2018 11:34:28 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Mar Mej�a Murillo
UsuarioRed		memm373565
Fecha			20170807
Objetivo		Realiza el pago de un cr�dito revolvente de acuerdo a la prelaci�n establecida y al monto indicado
Proyecto		Cr�dito Revolvente
Ticket			204020

*/

ALTER proc

	[dbo].[SP_REVOLVENTE_REALIZA_PAGO]
	
		-- par�metros
		
		@id_linea			bigint,
		@numero				int,
		@pago_total			money,
		@numusuario			int,
		@num_poliza			int,
		@folio				int,
		@contador_provision	int,
		@titular			varchar(1) = null,
		@ahorro				money = null,
		@inverdinamica		money = null,
		@debito				money = null,
		@efectivo			money = null,
		@id_tipo_persona	int = null,
		@fecha				datetime = null,
		@gastos_cobranza	money = null,
		@id_origen			int = null
		
as

	begin -- procedimiento

		begin try -- try principal
		
			begin -- inicio

				begin -- declaraciones

					declare	@status int = 1,
							@error_message varchar(255) = '',
							@error_line varchar(255) = '',
							@error_severity varchar(255) = '',
							@error_procedure varchar(255) = ''
						
					declare	@tran_name varchar(32) = 'REALIZA_PAGO',
							@tran_count int = @@trancount,
							@tran_scope bit = 0

					select @gastos_cobranza = coalesce(@gastos_cobranza, 0)

					select @id_origen = coalesce(@id_origen, 1)

					declare @mensaje varchar(255),
							@pago_minimo money = 0,
							@moratorios_mas_iva money = 0,
							@moratorios money = 0,
							@iva_moratorios money = 0,
							@moratorios_saldados money = 0,
							@iva_moratorios_saldados money = 0,
							@aux_moratorios money = 0,
							@aux_iva_moratorios money = 0,
							@ordinarios_ven_mas_iva money = 0,
							@aux_ordinarios_ven money = 0,
							@aux_iva_ordinarios_ven money = 0,
							@ordinarios_corte_mas_iva money = 0,
							@aux_ordinarios_corte money = 0,
							@aux_iva_ordinarios_corte money = 0,
							@ordinarios money = 0,
							@iva_ordinarios money = 0,
							@ordinarios_saldados money = 0,
							@iva_ordinarios_saldados money = 0,
							@ordinarios_minimo_saldados money = 0,
							@iva_ordinarios_minimo_saldados money = 0,
							@ordinarios_adelanto_saldados money = 0,
							@iva_ordinarios_adelanto_saldados money = 0,
							@capital money = 0,
							@capital_saldado money = 0,
							@capital_minimo_saldado money = 0,
							@capital_adelanto_saldado money = 0,
							@aux_capital money = 0,
							@ordinarios_desde_corte_mas_iva money = 0,
							@aux_ordinarios_desde_corte money = 0,
							@aux_iva_ordinarios_desde_corte money = 0,
							@capital_adelanto money = 0,
							@aux_capital_adelanto money = 0,
							@restante money = @pago_total - @gastos_cobranza,
							@tolerancia money = .01,
							@gastos_cobranza_neto money = 0,
							@gastos_cobranza_iva money = 0,
							@planx varchar(1),
							@tasa_ord float = 0,
							@tasa_mor float = 0,
							@num_ptmo varchar(14),
							@cv_diaria int,
							@numemp int,
							@id_rol int,
							@id_de_sucursal int,
							@id_accion bigint,
							@saldo_anterior_100 money,
							@fecha_anterior_100 datetime,
							@saldo_anterior_103 money,
							@fecha_anterior_103 datetime,
							@saldo_anterior_112 money,
							@fecha_anterior_112 datetime,
							@cuenta_orden_debe varchar(14) = '60800200000000',
							@cuenta_orden_haber varchar(14) = '70800200000000'

					declare @iva float = (select tasa / cast(100 as float) from tasas where contador = (select max(contador) from tasas where id_mov = 111))

					select @iva = coalesce(@iva, 16 / cast(100 as float))

				end -- declaraciones

				begin -- estructuras necesarias

					select	*
					into	#datos_linea
					from	vw_revolvente_lineas
					where	id_linea = @id_linea

					create table
						#pago_minimo
							(
							id_									bigint identity(1, 1) primary key clustered not null,
							id_linea							bigint null,
							id_disposicion						bigint null,
							num_ciclo							int null,
							fecha_al_corriente_int_ord			datetime null,
							fecha_al_corriente_int_mor			datetime null,
							int_mor								money not null,
							iva_mor								money not null,
							int_ord								money not null,
							iva_ord								money not null,
							int_ord_ven							money null,
							iva_ord_ven							money null,
							int_ord_corte						money null,
							iva_ord_corte						money null,
							capital								money not null,
							pago_minimo							money not null,
							fecha_corte							datetime null,
							int_mor_saldado						money null,
							iva_mor_saldado						money null,
							int_ord_ven_saldado					money null,
							iva_ord_ven_saldado					money null,
							int_ord_corte_saldado				money null,
							iva_ord_corte_saldado				money null,
							capital_saldado						money null,
							fecha_al_corriente_int_ord_saldado	datetime null,
							fecha_al_corriente_int_mor_saldado	datetime null,
							fecha_ultimo_abono_ordinarios		datetime null,
							fecha_ultimo_abono_moratorios		datetime null,
							fecha_ultimo_abono_capital			datetime null,
							)

					select	identity(int, 1, 1) contador, id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov,
							cuenta, concepto, fecha_mov, monto, neto, id_mov, banco, clave_local, linea, num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1,
							desc2, planx, aval1_socio, aval1_numero, aval2_socio, aval2_numero, desc3, desc4, fecha_dpf_final, num_dpf, tasa, interes, dias, debe_haber,
							numusuario, procesado, fecha_alta, numero_fin, numero_fin2, plazo, interes_ord, interes_mor, monto2, plazo2, interes_ord2, interes_mor2,
							aval1_avalados, aval2_avalados, fec_inicio, fec_prog, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario,
							porcentaje_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, porcentaje_beneficiario2, id_sol, numero_fin_lacp, reestructura,
							id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, ent_federativa, cve_municipio, cve_localidad, identificador, transferencia,
							fecha_pago, bimestre, referencia, cve_archivo, impreso, folio_impresion, documentacion, dpf_en_garantia, titular, id_nomina, id_esquema_nomina,
							id_leyenda, num_ptmo, id_renovado, ahorro_base, tasa_pasiva, id_fondeador, numero_fondeo
					into	#captura
					from	captura
					where	1 = 0

					select	identity(int, 1, 1) contador, id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov,
							cuenta, concepto, fecha_mov, monto, neto, id_mov, banco, clave_local, linea, num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1,
							desc2, planx, aval1_socio, aval1_numero, aval2_socio, aval2_numero, desc3, desc4, fecha_dpf_final, num_dpf, tasa, interes, dias, debe_haber,
							numusuario, procesado, fecha_alta, numero_fin, numero_fin2, plazo, interes_ord, interes_mor, monto2, plazo2, interes_ord2, interes_mor2,
							aval1_avalados, aval2_avalados, fec_inicio, fec_prog, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario,
							porcentaje_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, porcentaje_beneficiario2, id_sol, numero_fin_lacp, reestructura,
							id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, ent_federativa, cve_municipio, cve_localidad, identificador, transferencia,
							fecha_pago, bimestre, referencia, cve_archivo, impreso, folio_impresion, documentacion, dpf_en_garantia, titular, id_nomina, id_esquema_nomina,
							id_leyenda, num_ptmo, id_renovado, ahorro_base, tasa_pasiva, id_fondeador, numero_fondeo
					into	#captura_lacp
					from	captura
					where	1 = 0

					select	num_cuenta,
							concepto,
							ac_deud,
							estatus_cartera cv_diaria,
							clasificacion_cuenta tipo
					into	#cuentas_contables
					from	cuentas_contables
					where	numero_fin_lacp = 2
							and tipo_reconocimiento = 1

					select	num_cuenta,
							concepto,
							ac_deud,
							1 tipo
					into	#cuentas_contables_iva
					from	cuentas_contables
					where	concepto like 'i.v.a.%trasladado%'

					select	num_cuenta,
							concepto,
							ac_deud,
							1 tipo
					into	#cuentas_contables_gastos_cobranza
					from	cuentas_contables
					where	concepto like 'por gastos de cobranza'

					select	num_cuenta,
							concepto,
							ac_deud,
							case when concepto like '%debito%' then 3 when concepto like '%vista%' then 2 else 1 end tipo
					into	#cuentas_contables_haberes
					from	CUENTAS_CONTABLES
					where	num_cuenta like '21100000000000'
							or num_cuenta like '21200000000000'
							or Num_cuenta like '21600000000000'
					order by
							tipo

					--select * from #cuentas_contables_haberes--------------

					select	id_mov, saldo_actual, fecha, cast(null as money) saldo_posterior
					into	#saldos_edo_de_cuenta
					from	edo_de_cuenta
					where	numero = @numero
							and id_mov in (100, 103, 112)
							and 1 = 0

				end -- estructuras necesarias
						
				begin -- valores por defecto

					select	@ahorro = coalesce(@ahorro, 0),
							@inverdinamica = coalesce(@inverdinamica, 0),
							@debito = coalesce(@debito, 0),
							@efectivo = coalesce(@efectivo, 0),
							@cv_diaria = coalesce((select cv_diaria from #datos_linea), 0),
							@id_tipo_persona = coalesce(@id_tipo_persona, 1),
							@titular = coalesce(@titular, 'T'),
							@fecha = coalesce(@fecha, getdate())

					select	@gastos_cobranza = coalesce(round(@gastos_cobranza, 2), 0),
							@gastos_cobranza_neto = @gastos_cobranza / (1 + @iva),
							@gastos_cobranza_iva = round(@gastos_cobranza_neto * @iva, 2),
							@gastos_cobranza_neto = @gastos_cobranza - @gastos_cobranza_iva

--					select @id_tipo_persona, @fecha, @gastos_cobranza


					select	@tasa_ord = tasa_ord,
							@tasa_mor = tasa_mor,
							@num_ptmo = num_ptmo
					from	#datos_linea

					select	@numemp = numemp,
							@id_rol = id_rol,
							@id_de_sucursal = id_de_sucursal
					from	claves
					where	numusuario = @numusuario

				end -- valores por defecto

				begin -- tabla de resultados

					declare @standalone bit = 1, @sql nvarchar(4000) = 'delete #procedimiento_pago_credito'

					begin try -- revisar si existe tabla de resultados

						exec (@sql)

						select @standalone = 0

					end try -- revisar si existe tabla de resultados

					begin catch -- si no existe tabla de resultados

						create table
							#procedimiento_pago_credito
								(
								status			int null,
								error_procedure	varchar(255) null,
								error_line		varchar(255) null,
								error_severity	varchar(255) null,
								error_message	varchar(255) null,
								)

					end catch -- si no existe tabla de resultados

				end -- tabla de resultados

			end -- inicio
			
			begin -- validaciones
			
				-- comprobaci�n de flujo de efectivo
				if (@pago_total + (@ahorro + @inverdinamica + @debito + @efectivo)) != 0

					begin

					select @mensaje = 'La distribuci�n de entradas [' + cast(-(@ahorro + @inverdinamica + @debito + @efectivo) as varchar) + '] no se puede cuadrar con el monto total a pagar [' + cast(@pago_total as varchar) + ']'
					raiserror(@mensaje, 11, 0)

					end

				if (@gastos_cobranza > @pago_total)

					begin

						select @mensaje = 'El monto a retener por gastos de cobranza [' + cast(@gastos_cobranza as varchar) + '] excede al monto del pago total [' + cast(@pago_total as varchar) + ']'
						raiserror(@mensaje, 11, 0)

					end

			end -- validaciones

			begin -- preparaci�n

				begin -- preparar saldado

					begin try -- saldar pago m�nimo

						exec SP_REVOLVENTE_OBTIENE_PAGO_MINIMO @numero, @id_linea, 0, @fecha

						update	pm
						set		pm.fecha_corte = c.fecha_corte
						from	#pago_minimo pm
								join VW_REVOLVENTE_CICLOS c
									on c.id_linea = pm.id_linea
									and c.id_disposicion = pm.id_disposicion-----------se adecua pm x incidencia de liquidaci�n de revolvente
									and c.num_ciclo = pm.num_ciclo

						update	pm
						set		pm.int_ord_ven = d.int_ord_ven_acum,
								pm.iva_ord_ven = round(d.int_ord_ven_acum * @iva, 2),
								pm.int_ord_corte = d.int_ord_corte_acum,
								pm.iva_ord_corte = round(d.int_ord_corte_acum * @iva, 2)
						from	#pago_minimo pm
									join vw_revolvente_disposiciones d
										on d.id_disposicion = pm.id_disposicion
										and d.id_linea = pm.id_linea
										and int_ord > 0

						update	#pago_minimo
						set		int_ord_ven = coalesce(int_ord_ven, 0),
								iva_ord_ven = coalesce(iva_ord_ven, 0),
								int_ord_corte = coalesce(int_ord_corte, 0),
								iva_ord_corte = coalesce(iva_ord_corte, 0)

						select	@pago_minimo = sum(pago_minimo),
								@moratorios_mas_iva = sum(int_mor + iva_mor),
								@ordinarios_ven_mas_iva = sum(int_ord_ven + iva_ord_ven),
								@ordinarios_corte_mas_iva = sum(int_ord_corte + iva_ord_corte),
								@capital = sum(capital)
						from	#pago_minimo

						select @capital = coalesce(@capital, 0)

						if @pago_minimo > 0

							begin -- si hay pago m�nimo 

								if (@restante !< @pago_minimo)

									begin -- el restante alcanza para saldar pago m�nimo completo

										update	#pago_minimo
										set		int_mor_saldado = int_mor,
												iva_mor_saldado = iva_mor,
												int_ord_ven_saldado = int_ord_ven,
												iva_ord_ven_saldado = iva_ord_ven,
												int_ord_corte_saldado = int_ord_corte,
												iva_ord_corte_saldado = iva_ord_corte,
												capital_saldado = capital,
												fecha_al_corriente_int_ord_saldado = @fecha,
												fecha_al_corriente_int_mor_saldado = @fecha,
												fecha_ultimo_abono_capital = @fecha,
												fecha_ultimo_abono_ordinarios = @fecha,
												fecha_ultimo_abono_moratorios = case when int_mor > 0 then @fecha else null end

										select @restante = @restante - @pago_minimo

									end -- el restante alcanza para saldar pago m�nimo completo

								else

									begin -- el restante no alcanza para saldar pago m�nimo completo

										begin -- saldar moratorios

											if @moratorios_mas_iva > 0

												begin -- si hay moratorios

													if @restante !< @moratorios_mas_iva

														begin -- el restante alcanza para saldar el moratorios completo

															update	#pago_minimo
															set		int_mor_saldado = int_mor,
																	iva_mor_saldado = iva_mor,
																	fecha_al_corriente_int_mor_saldado = case when int_mor > 0 then @fecha else null end,
																	fecha_ultimo_abono_moratorios = case when int_mor > 0 then @fecha else null end

															update	#pago_minimo
															set		int_mor_saldado = coalesce(int_mor_saldado, 0),
																	iva_mor_saldado = coalesce(iva_mor_saldado, 0)

															select @restante = @restante - @moratorios_mas_iva

														end -- el restante alcanza para saldar el moratorios completo

													else

														begin -- el restante no alcanza para saldar el moratorios completo

															while @restante > 0 and exists (select * from #pago_minimo where iva_mor_saldado is null)

																begin -- mientras haya algo por saldar y dispongamos de restante

																	select	@aux_moratorios = int_mor,
																			@aux_iva_moratorios = iva_mor
																	from	#pago_minimo
																	where	id_ =
																				(
																				select	min(id_)
																				from	#pago_minimo
																				where	iva_mor_saldado is null
																				)

																	if @restante !< @aux_moratorios + @aux_iva_moratorios

																		begin -- el restante alcanza para saldar moratorios e iva de la iteraci�n

																			update	#pago_minimo
																			set		int_mor_saldado = int_mor,
																					iva_mor_saldado = iva_mor,
																					fecha_al_corriente_int_mor_saldado = case when int_mor > 0 then @fecha else null end,
																					fecha_ultimo_abono_moratorios = case when int_mor > 0 then @fecha else null end
																			where	id_ =
																						(
																						select	min(id_)
																						from	#pago_minimo
																						where	iva_mor_saldado is null
																						)

																			select @restante = @restante - (@aux_moratorios + @aux_iva_moratorios)

																		end -- el restante alcanza para saldar moratorios e iva de la iteraci�n

																	else if @restante > 0

																		begin -- el restante se redistribuye para saldar lo que alcance

																			select	@aux_moratorios = @restante / 1.16,
																					@aux_iva_moratorios = round(@aux_moratorios * .16, 2),
																					@aux_moratorios = @restante - @aux_iva_moratorios

																			update	#pago_minimo
																			set		int_mor_saldado = @aux_moratorios,
																					iva_mor_saldado = @aux_iva_moratorios,
																					--fecha_al_corriente_int_mor_saldado = case when int_mor > 0 then @fecha else null end,
																					fecha_ultimo_abono_moratorios = case when int_mor > 0 then @fecha else null end
																			where	id_ =
																						(
																						select	min(id_)
																						from	#pago_minimo
																						where	iva_mor_saldado is null
																						)

																			select @restante = 0

																		end -- el restante se redistribuye para saldar lo que alcance

																end -- mientras haya algo por saldar y dispongamos de restante

															--update	#pago_minimo
															--set		int_mor_saldado = coalesce(int_mor_saldado, 0),
															--		iva_mor_saldado = coalesce(iva_mor_saldado, 0)

														end -- el restante no alcanza para saldar el moratorios completo

												end -- si hay moratorios

											update	#pago_minimo
											set		int_mor_saldado = coalesce(int_mor_saldado, 0),
													iva_mor_saldado = coalesce(iva_mor_saldado, 0)

										end -- saldar moratorios

										begin -- saldar ordinarios

											if @ordinarios_ven_mas_iva + @ordinarios_corte_mas_iva > 0

												begin -- hay ordinarios

													if @restante !< @ordinarios_ven_mas_iva + @ordinarios_corte_mas_iva

														begin -- el restante alcanza para saldar ordinarios por completo

															update	#pago_minimo
															set		int_ord_ven_saldado = int_ord_ven,
																	iva_ord_ven_saldado = iva_ord_ven,
																	int_ord_corte_saldado = int_ord_corte,
																	iva_ord_corte_saldado = iva_ord_corte,
																	fecha_al_corriente_int_ord_saldado = case when int_ord_ven + int_ord_corte > 0 then @fecha else null end,
																	fecha_ultimo_abono_ordinarios = case when int_ord_ven + int_ord_corte > 0 then @fecha else null end

															select @restante = @restante - (@ordinarios_ven_mas_iva + @ordinarios_corte_mas_iva)

														end -- el restante alcanza para saldar ordinarios por completo

													else

														begin -- el restante no alcanza para saldar ordinarios por completo

--															print 'saldar ordinarios vencidos'

--															select 'rev 1', * from #pago_minimo

															while @restante > 0 and exists (select * from #pago_minimo where iva_ord_ven_saldado is null)

																begin -- mientras haya algo por saldar y dispongamos de restante

																	select	@aux_ordinarios_ven = int_ord_ven,
																			@aux_iva_ordinarios_ven = iva_ord_ven
																	from	#pago_minimo
																	where	id_ =
																				(
																				select	min(id_)
																				from	#pago_minimo
																				where	iva_ord_ven_saldado is null
																				)

																	--select @aux_ordinarios_ven, @aux_iva_ordinarios_ven

																	if @restante !< @aux_ordinarios_ven + @aux_iva_ordinarios_ven

																		begin -- el restante alcanza para saldar moratorios e iva de la iteraci�n

																			update	#pago_minimo
																			set		int_ord_ven_saldado = int_ord_ven,
																					iva_ord_ven_saldado = iva_ord_ven,
																					fecha_al_corriente_int_ord_saldado = case when int_ord_ven > 0 then @fecha else null end,
																					fecha_ultimo_abono_ordinarios = case when int_ord_ven > 0 then @fecha else null end
																			where	id_ =
																						(
																						select	min(id_)
																						from	#pago_minimo
																						where	iva_ord_ven_saldado is null
																						)

																			select @restante = @restante - (@aux_ordinarios_ven + @aux_iva_ordinarios_ven)

																			--print 'restante [1]: ' + cast(@restante as varchar(255))

																		end -- el restante alcanza para saldar moratorios e iva de la iteraci�n

																	else if @restante > 0

																		begin -- el restante se redistribuye para saldar lo que alcance

																			select	@aux_ordinarios_ven = @restante / 1.16,
																					@aux_iva_ordinarios_ven = round(@aux_ordinarios_ven * .16, 2),
																					@aux_ordinarios_ven = @restante - @aux_iva_ordinarios_ven

																			update	#pago_minimo
																			set		int_ord_ven_saldado = @aux_ordinarios_ven,
																					iva_ord_ven_saldado = @aux_iva_ordinarios_ven,
																					--fecha_al_corriente_int_mor_saldado = case when int_mor > 0 then @fecha else null end,
																					fecha_ultimo_abono_ordinarios = case when int_ord_ven > 0 then @fecha else null end
																			where	id_ =
																						(
																						select	min(id_)
																						from	#pago_minimo
																						where	iva_ord_ven_saldado is null
																						)

																			select @restante = 0

																		end -- el restante se redistribuye para saldar lo que alcance

																end -- mientras haya algo por saldar y dispongamos de restante

															update	#pago_minimo
															set		int_ord_ven_saldado = coalesce(int_ord_ven_saldado, 0),
																	iva_ord_ven_saldado = coalesce(iva_ord_ven_saldado, 0)

															while @restante > 0 and exists (select * from #pago_minimo where iva_ord_corte_saldado is null)

																begin -- mientras haya algo por saldar y dispongamos de restante

																	select @aux_ordinarios_corte = int_ord_corte, @aux_iva_ordinarios_corte = iva_ord_corte from #pago_minimo where id_ = (select min(id_) from #pago_minimo where iva_ord_corte_saldado is null)

																	--select @aux_ordinarios_corte, @aux_iva_ordinarios_corte

																	if @restante !< @aux_ordinarios_corte + @aux_iva_ordinarios_corte

																		begin -- el restante alcanza para saldar moratorios e iva de la iteraci�n

																			update	#pago_minimo
																			set		int_ord_corte_saldado = int_ord_corte,
																					iva_ord_corte_saldado = iva_ord_corte,
																					fecha_al_corriente_int_ord_saldado = case when int_ord_corte > 0 then @fecha else null end,
																					fecha_ultimo_abono_ordinarios = case when int_ord_corte > 0 then @fecha else null end
																			where	id_ =
																						(
																						select	min(id_)
																						from	#pago_minimo
																						where	iva_ord_corte_saldado is null
																						)

																			select @restante = @restante - (@aux_ordinarios_corte + @aux_iva_ordinarios_corte)

																			--print 'restante [1]: ' + cast(@restante as varchar(255))

																		end -- el restante alcanza para saldar moratorios e iva de la iteraci�n

																	else if @restante > 0

																		begin -- el restante se redistribuye para saldar lo que alcance

																			select	@aux_ordinarios_corte = @restante / 1.16,
																					@aux_iva_ordinarios_corte = round(@aux_ordinarios_corte * .16, 2),
																					@aux_ordinarios_corte = @restante - @aux_iva_ordinarios_corte

																			update	#pago_minimo
																			set		int_ord_corte_saldado = @aux_ordinarios_corte,
																					iva_ord_corte_saldado = @aux_iva_ordinarios_corte,
																					--fecha_al_corriente_int_mor_saldado = case when int_mor > 0 then @fecha else null end,
																					fecha_ultimo_abono_ordinarios = case when int_ord_corte > 0 then @fecha else null end
																			where	id_ =
																						(
																						select	min(id_)
																						from	#pago_minimo
																						where	iva_ord_corte_saldado is null
																						)

																			select @restante = 0

																		end -- el restante se redistribuye para saldar lo que alcance

																end -- mientras haya algo por saldar y dispongamos de restante

														end -- el restante no alcanza para saldar ordinarios por completo

												end -- hay ordinarios

											update	#pago_minimo
											set		int_ord_corte_saldado = coalesce(int_ord_corte_saldado, 0),
													iva_ord_corte_saldado = coalesce(iva_ord_corte_saldado, 0)

										end -- saldar ordinarios

										begin -- saldar capital

											if @capital > 0

												begin -- hay capital

													if @restante !< @capital

														begin -- el restante alcanza para saldar el capital completo

															update	#pago_minimo
															set		capital_saldado = capital,
																	fecha_ultimo_abono_capital = @fecha

															select @restante = @restante - @capital

														end -- el restante alcanza para saldar el capital completo

													else

														begin -- el restante no alcanza para saldar el capital completo

															while @restante > 0 and exists (select * from #pago_minimo where capital_saldado is null)

																begin -- mientras haya algo por saldar y dispongamos de restante

																	select	@aux_capital = capital
																	from	#pago_minimo
																	where	id_ =
																				(
																				select	min(id_)
																				from	#pago_minimo
																				where	capital_saldado is null
																				)

																	if @restante !< @aux_capital

																		begin -- el restante alcanza para saldar capital de la iteraci�n

																			update	#pago_minimo
																			set		capital_saldado = capital,
																					fecha_ultimo_abono_capital = @fecha
																			where	id_ =
																						(
																						select	min(id_)
																						from	#pago_minimo
																						where	capital_saldado is null
																						)

																			select @restante = @restante - @aux_capital

																		end -- el restante alcanza para saldar capital de la iteraci�n

																	else if @restante > 0

																		begin -- el restante se ajusta para saldar lo que alcance

																			select	@aux_capital = @restante

																			update	#pago_minimo
																			set		capital_saldado = @aux_capital,
																					fecha_ultimo_abono_capital = @fecha
																			where	id_ =
																						(
																						select	min(id_)
																						from	#pago_minimo
																						where	capital_saldado is null
																						)

																			select @restante = 0

																		end -- el restante se ajusta para saldar lo que alcance

																end -- mientras haya algo por saldar y dispongamos de restante

															update	#pago_minimo
															set		capital_saldado = coalesce(capital_saldado, 0)

														end -- el restante no alcanza para saldar el capital completo

												end -- hay capital

										end -- saldar capital

									end -- el restante no alcanza para saldar pago m�nimo completo

							end -- si hay pago m�nimo

--							select 'rev 04', * from #pago_minimo

					end try -- saldar pago m�nimo

					begin catch

						raiserror ('Error al preparar saldado de pago m�nimo', 11, 0)

					end catch

					begin try -- saldar inter�s ordinarios desde el corte

						select	id_disposicion,
								coalesce(int_ord_vig_acum, 0) int_ord_vig_acum,
								round(cast(coalesce(int_ord_vig_acum, 0) * @iva as money), 2) iva_ord_vig_acum,
								cast(null as money) int_ord_vig_acum_saldado,
								cast(null as money) iva_ord_vig_acum_saldado,
								cast(null as datetime) fecha_al_corriente_int_ord_saldado,
								cast(null as datetime) fecha_ultimo_abono_ordinarios_saldado
						into	#intereses_desde_corte
						from	VW_REVOLVENTE_DISPOSICIONES
						where	id_linea = @id_linea
								and disposicion_activa = 1

						select	@ordinarios_desde_corte_mas_iva = sum(int_ord_vig_acum + iva_ord_vig_acum)
						from	#intereses_desde_corte

						--select	@ordinarios_desde_corte_mas_iva, @restante

						if @ordinarios_desde_corte_mas_iva > 0

							begin -- hay ordinarios desde corte

								if @restante !< @ordinarios_desde_corte_mas_iva

									begin -- el restante alcanza para saldar ordinarios desde corte

										update	#intereses_desde_corte
										set		int_ord_vig_acum_saldado = int_ord_vig_acum,
												iva_ord_vig_acum_saldado = iva_ord_vig_acum,
												fecha_al_corriente_int_ord_saldado = @fecha,
												fecha_ultimo_abono_ordinarios_saldado = @fecha

										select @restante = @restante - @ordinarios_desde_corte_mas_iva

									end -- el restante alcanza para saldar ordinarios desde corte

								else

									begin -- el restante no alcanza para saldar ordinarios desde corte

										while @restante > 0 and exists (select * from #intereses_desde_corte where iva_ord_vig_acum_saldado is null)

											begin -- mientras haya algo por saldar y dispongamos de restante

												select	@aux_ordinarios_desde_corte = int_ord_vig_acum,
														@aux_iva_ordinarios_desde_corte = iva_ord_vig_acum
												from	#intereses_desde_corte
												where	id_disposicion =
															(
															select	min(id_disposicion)
															from	#intereses_desde_corte
															where	iva_ord_vig_acum_saldado is null
															)

												if @restante !< @aux_ordinarios_desde_corte + @aux_iva_ordinarios_desde_corte

													begin -- el restante alcanza para saldar inter�s ordinarios e iva de la iteraci�n

														update	#intereses_desde_corte
														set		int_ord_vig_acum_saldado = int_ord_vig_acum,
																iva_ord_vig_acum_saldado = iva_ord_vig_acum,
																fecha_al_corriente_int_ord_saldado = case when int_ord_vig_acum > 0 then @fecha else null end,
																fecha_ultimo_abono_ordinarios_saldado = case when int_ord_vig_acum > 0 then @fecha else null end
														where	id_disposicion = (select min(id_disposicion) from #intereses_desde_corte where iva_ord_vig_acum_saldado is null)

														select @restante = @restante - (@aux_ordinarios_desde_corte + @aux_iva_ordinarios_desde_corte)

													end -- el restante alcanza para saldar capital de la iteraci�n

												else if @restante > 0

													begin -- el restante se redistribuye para saldar lo que alcance

														select	@aux_ordinarios_desde_corte = @restante / 1.16,
																@aux_iva_ordinarios_desde_corte = round(@aux_ordinarios_desde_corte * .16, 2),
																@aux_ordinarios_desde_corte = @restante - @aux_iva_ordinarios_desde_corte

														update	#intereses_desde_corte
														set		int_ord_vig_acum_saldado = @aux_ordinarios_desde_corte,
																iva_ord_vig_acum_saldado = @aux_iva_ordinarios_desde_corte,
																fecha_ultimo_abono_ordinarios_saldado = case when @aux_ordinarios_desde_corte > 0 then @fecha else null end
														where	id_disposicion =
																	(
																	select	min(id_disposicion)
																	from	#intereses_desde_corte
																	where	iva_ord_vig_acum_saldado is null
																	)

														select @restante = 0

													end -- el restante se redistribuye para saldar lo que alcance

											end -- mientras haya algo por saldar y dispongamos de restante

										update	#intereses_desde_corte
										set		int_ord_vig_acum_saldado = coalesce(int_ord_vig_acum_saldado, 0),
												iva_ord_vig_acum_saldado = coalesce(iva_ord_vig_acum_saldado, 0)

									end -- el restante no alcanza para saldar ordinarios desde corte

							end -- hay ordinarios desde corte

						-- if @restante

					end try -- saldar inter�s ordinarios desde el corte

					begin catch

						raiserror ('Error al preparar saldado de inter�s ordinarios desde el corte', 11, 0)

					end catch

					begin try -- saldar capital de adelanto

						select	identity(bigint, 1, 1) id_,
								id_linea,
								id_disposicion,
								num_ciclo,
								capital,
								fecha_corte,
								cast(null as money) capital_saldado,
								cast(null as datetime) fecha_ultimo_abono_capital_saldado,
								cast(0 as bit) pago_minimo
						into	#capital_adelanto
						from	VW_REVOLVENTE_CICLOS c
						where	id_linea = @id_linea
								and c.ciclo_activo = 1
								and c.disposicion_activa = 1
						order by
								id_disposicion,
								fecha_corte desc

						update	ca
						set		ca.capital_saldado = pm.capital_saldado,
								ca.fecha_ultimo_abono_capital_saldado = pm.fecha_ultimo_abono_capital,
								ca.pago_minimo = 1
						from	#capital_adelanto ca
								join #pago_minimo pm
									on pm.id_linea = ca.id_linea
									and pm.id_disposicion = ca.id_disposicion
									and pm.num_ciclo = ca.num_ciclo
									and pm.capital_saldado=ca.capital--Se agrega x incidencia de liquidaci�n de revolvente


						--update	#capital_adelanto
						--set		capital_saldado = coalesce(capital_saldado, 0)

						select	@capital_adelanto = sum(coalesce(capital, 0) - coalesce(capital_saldado, 0))
						from	#capital_adelanto

						select  @capital_adelanto = coalesce(@capital_adelanto, 0)

						if @capital_adelanto > 0

							begin -- hay capital de adelanto

								if @restante !< @capital_adelanto

									begin -- el restante alcanza para saldar capital de adelanto

										update	#capital_adelanto
										set		capital_saldado = capital,
												fecha_ultimo_abono_capital_saldado = coalesce(fecha_ultimo_abono_capital_saldado, @fecha)
										where	capital > 0

										select @restante = @restante - @capital_adelanto
										
									end -- el restante alcanza para saldar capital de adelanto

								else

									begin -- el restante no alcanza para saldar capital de adelanto


										while @restante > 0 and exists (select * from #capital_adelanto where capital_saldado is null or capital - capital_saldado > 0)

											begin -- mientras haya algo por saldar y dispongamos de restante

												select	@aux_capital_adelanto = capital
												from	#capital_adelanto
												where	id_ =
															(
															select	min(id_)
															from	#capital_adelanto
															where	capital_saldado is null
															)

												if @restante !< @aux_capital_adelanto

													begin -- el restante alcanza para saldar capital de la iteraci�n

														update	#capital_adelanto
														set		capital_saldado = capital,
																fecha_ultimo_abono_capital_saldado = @fecha
														where	id_ =
																	(
																	select	min(id_)
																	from	#capital_adelanto
																	where	capital_saldado is null
																	)

														select @restante = @restante - @aux_capital_adelanto

													end -- el restante alcanza para saldar capital de la iteraci�n

												else if @restante > 0

													begin -- el restante se ajusta para saldar lo que alcance

														select	@aux_capital_adelanto = @restante

														update	#capital_adelanto
														set		capital_saldado = @aux_capital_adelanto,
																fecha_ultimo_abono_capital_saldado = @fecha
														where	id_ =
																	(
																	select	min(id_)
																	from	#capital_adelanto
																	where	capital_saldado is null
																	)

														select @restante = 0

													end -- el restante se ajusta para saldar lo que alcance

											end -- mientras haya algo por saldar y dispongamos de restante

										update	#capital_adelanto
										set		capital_saldado = coalesce(capital_saldado, 0)

									end -- el restante no alcanza para saldar capital de adelanto

							end -- hay capital de adelanto

					end try -- saldar capital de adelanto

					begin catch

						raiserror ('Error al preparar saldado de capital de adelanto', 11, 0)

					end catch

					--select * from #pago_minimo

					--select * from #intereses_desde_corte

					--select * from #capital_adelanto

					--select	@pago_total - @gastos_cobranza para_pago,
					--		@moratorios_mas_iva mora_mas_iva,
					--		@ordinarios_ven_mas_iva ordinarios_ven_mas_iva,
					--		@ordinarios_corte_mas_iva ordinarios_corte_mas_iva,
					--		@capital capital,
					--		@pago_minimo minimo_total,
					--		@ordinarios_desde_corte_mas_iva ordinarios_desde_corte_mas_iva,
					--		@capital_adelanto capital_adelanto,
					--		@restante restante

					--select	'SALDADO PAGO MINIMO' [ ],
					--		sum(int_mor_saldado + iva_mor_saldado) mora_mas_iva_saldado,
					--		sum(int_ord_ven_saldado + iva_ord_ven_saldado) ordinarios_ven_mas_iva,
					--		sum(int_ord_corte_saldado + iva_ord_corte_saldado) ordinarios_corte_mas_iva,
					--		sum(capital_saldado) capital
					--from	#pago_minimo

					--select	'SALDADO INTERESES ordinarios DESDE EL CORTE' [ ],
					--		sum(int_ord_vig_acum_saldado + iva_ord_vig_acum_saldado) ordinarios_desde_corte_mas_iva
					--from	#intereses_desde_corte

					--select	'SALDADO CAPITAL ADELANTO' [ ],
					--		sum(capital_saldado) capital_adelanto
					--from	#capital_adelanto
					--where	pago_minimo = 0

				end -- preparar saldado

				begin -- validaci�n de restante

					if @restante > @tolerancia

						begin -- el restante excede los par�metros de tolerancia

							select @mensaje = 'Un excedente [' + cast(@restante as varchar) + '] no ha sido asignado adecuadamente; monto m�ximo permisible [' + cast(@pago_total - @gastos_cobranza - @restante as varchar) + ']; monto ingresado [' + cast(@pago_total - @gastos_cobranza as varchar) + ']'

							raiserror(@mensaje, 11, 0)

						end -- el restante excede los par�metros de tolerancia

				end -- validaci�n de restante

				begin -- preparar afectaci�n en Hape

					begin try

						begin -- preparar gastos de cobranza y su iva

							begin try

								if coalesce(@gastos_cobranza_neto, 0) > 0

									begin -- si hay gastos de cobranza

										insert	#captura
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
										        --Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes  1140 id_tipomov, 
												cc.num_cuenta,
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto, -- Antes 'Gastos de Cobranza' concepto, 
												@fecha fecha_mov, @gastos_cobranza_neto monto, 10 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_gastos_cobranza cc
													on cc.tipo = 1
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento
												join TIPO_MOV tm
												on tm.Id_tipomov = 1140
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes  1140 id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto, -- Antes 'Gastos de Cobranza' concepto,  
												@fecha fecha_mov, @gastos_cobranza_neto monto, 10 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_gastos_cobranza cc
													on cc.tipo = 1
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = 1140
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										--select * from #captura

										--select * from #captura_lacp

									end -- si hay gastos de cobranza

								if @gastos_cobranza_iva > 0

									begin -- si hay iva por gastos de cobranza

										insert	#captura
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes 1141 id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes  'I.V.A. por Gastos de Cobranza' concepto, 
												@fecha fecha_mov, @gastos_cobranza_iva monto, 10 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_iva cc
													on cc.tipo = 1
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = 1141
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes 1141 id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes  'I.V.A. por Gastos de Cobranza' concepto, 
												@fecha fecha_mov, @gastos_cobranza_iva monto, 10 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_iva cc
													on cc.tipo = 1
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = 1141
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

									end -- si hay iva por gastos de cobranza

							end try

							begin catch

								raiserror ('Gastos de cobranza', 11, 0)

							end catch

						end -- preparar gastos de cobranza y su iva

						begin -- preparar moratorios y su iva

							begin try

								if @moratorios_mas_iva > 0

									begin -- si hay algo por afectar

										select	@moratorios_saldados = sum(int_mor_saldado),
												@iva_moratorios_saldados = sum(iva_mor_saldado)
										from	#pago_minimo

										select	@moratorios_saldados = coalesce(@moratorios_saldados, 0),
												@iva_moratorios_saldados = coalesce(@iva_moratorios_saldados, 0)

										insert	#captura
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes 1130 id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes  'Pago de Intereses Moratorios de Cr�dito Revolvente' concepto, 
												@fecha fecha_mov, @moratorios_saldados monto, 10 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables cc
													on cc.tipo = 3
													and cc.cv_diaria = @cv_diaria
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = 1130
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes 1130 id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes  'Pago de Intereses Moratorios de Cr�dito Revolvente' concepto, 
												@fecha fecha_mov, @moratorios_saldados monto, 10 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables cc
													on cc.tipo = 3
													and cc.cv_diaria = @cv_diaria
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = 1130
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										if @iva_moratorios_saldados > 0

											begin -- si hay iva por inter�s moratorios

												insert	#captura
														(
														id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
														num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
														numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
														)
												select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
														--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
														tm.Id_tipomov id_tipomov,  -- Antes 1131 id_tipomov, 
														cc.num_cuenta, 
														--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
														tm.Descripcion concepto,  -- Antes  'Pago de I.V.A. de Intereses Moratorios de Cr�dito Revolvente' concepto, 
														@fecha fecha_mov, @iva_moratorios_saldados monto, 10 id_mov,
														@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
														0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
												from	persona per
														join sucursales suc
															on suc.id_de_sucursal = per.id_de_sucursal
														join #cuentas_contables_iva cc
															on cc.tipo = 1
														--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
														join TIPO_MOV tm
														on tm.Id_tipomov = 1131
												where	numero = @numero
														and id_tipo_persona = @id_tipo_persona

												insert	#captura_lacp
														(
														id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
														num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
														numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
														)
												select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
														--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
														tm.Id_tipomov id_tipomov,  -- Antes 1131 id_tipomov, 
														cc.num_cuenta, 
														--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
														tm.Descripcion concepto,  -- Antes 'Pago de I.V.A. de Intereses Moratorios de Cr�dito Revolvente' concepto, 
														@fecha fecha_mov, @iva_moratorios_saldados monto, 10 id_mov,
														@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
														0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
												from	persona per
														join sucursales suc
															on suc.id_de_sucursal = per.id_de_sucursal
														join #cuentas_contables_iva cc
															on cc.tipo = 1
														--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
														join TIPO_MOV tm
														on tm.Id_tipomov = 1131
												where	numero = @numero
														and id_tipo_persona = @id_tipo_persona

											end -- si hay iva por inter�s moratorios

									end -- si hay algo por afectar

							end try

							begin catch

								raiserror ('Moratorios', 11, 0)

							end catch

						end -- preparar moratorios y su iva

						begin -- preparar ordinarios y su iva

							begin try

								if coalesce(@ordinarios_ven_mas_iva, 0) + coalesce(@ordinarios_corte_mas_iva, 0) + coalesce(@ordinarios_desde_corte_mas_iva, 0) > 0

									begin -- si hay algo por afectar

										select	@ordinarios_saldados = sum(coalesce(int_ord_ven_saldado, 0) + coalesce(int_ord_corte_saldado, 0)),
												@ordinarios_minimo_saldados = sum(coalesce(int_ord_ven_saldado, 0) + coalesce(int_ord_corte_saldado, 0)),
												@iva_ordinarios_saldados = sum(coalesce(iva_ord_ven_saldado, 0) + coalesce(iva_ord_corte_saldado, 0)),
												@iva_ordinarios_minimo_saldados = sum(coalesce(iva_ord_ven_saldado, 0) + coalesce(iva_ord_corte_saldado, 0))
										from	#pago_minimo

										select	@ordinarios_saldados = coalesce(@ordinarios_saldados, 0),
												@ordinarios_minimo_saldados = coalesce(@ordinarios_minimo_saldados, 0),
												@iva_ordinarios_saldados = coalesce(@iva_ordinarios_saldados, 0),
												@iva_ordinarios_minimo_saldados = coalesce(@iva_ordinarios_minimo_saldados, 0)

										select	@ordinarios_saldados = @ordinarios_saldados + coalesce(sum(int_ord_vig_acum_saldado), 0),
												@ordinarios_adelanto_saldados = coalesce(sum(int_ord_vig_acum_saldado), 0),
												@iva_ordinarios_saldados = @iva_ordinarios_saldados + coalesce(sum(iva_ord_vig_acum_saldado), 0),
												@iva_ordinarios_adelanto_saldados = coalesce(sum(iva_ord_vig_acum_saldado), 0)
										from	#intereses_desde_corte

										insert	#captura
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes 1120 id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes 'Pago de Intereses Ordinarios de Cr�dito Revolvente' concepto, 
												@fecha fecha_mov, @ordinarios_saldados monto, 10 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables cc
													on cc.tipo = 2
													and cc.cv_diaria = @cv_diaria
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = 1120
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes 1120 id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes 'Pago de Intereses Ordinarios de Cr�dito Revolvente' concepto, 
												@fecha fecha_mov, @ordinarios_saldados monto, 10 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables cc
													on cc.tipo = 2
													and cc.cv_diaria = @cv_diaria
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = 1120
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona


										insert	#captura
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes 1121 id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes 'Pago de I.V.A. de Intereses Ordinarios de Cr�dito Revolvente' concepto,
												@fecha fecha_mov, @iva_ordinarios_saldados monto, 10 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_iva cc
													on cc.tipo = 1
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = 1121
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes 1121 id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes 'Pago de I.V.A. de Intereses Ordinarios de Cr�dito Revolvente' concepto, 
												@fecha fecha_mov, @iva_ordinarios_saldados monto, 10 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_iva cc
													on cc.tipo = 1
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = 1121
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona


									end -- si hay algo por afectar

							end try

							begin catch

								raiserror ('Ordinarios', 11, 0)

							end catch

						end -- preparar ordinarios y su iva

						begin -- preparar pago a capital

							begin try

								--select @capital, @capital_adelanto

								if @capital + @capital_adelanto > 0

									begin -- si hay algo por afectar

										select	@capital_saldado = coalesce(sum(capital_saldado), 0),
												@capital_minimo_saldado = coalesce(sum(capital_saldado), 0)
										from	#pago_minimo

										select	@capital_saldado = @capital_saldado + coalesce(sum(capital_saldado), 0),
												@capital_adelanto_saldado = coalesce(sum(capital_saldado), 0)
										from	#capital_adelanto
										where	pago_minimo = 0

										insert	#captura
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes 1111 id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes 'Pago a Capital de Cr�dito Revolvente' concepto, 
												@fecha fecha_mov, @capital_saldado monto, 10 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables cc
													on cc.tipo = 1
													and cc.cv_diaria = @cv_diaria
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = 1111
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes 1111 id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes 'Pago a Capital de Cr�dito Revolvente' concepto, 
												@fecha fecha_mov, @capital_saldado monto, 10 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables cc
													on cc.tipo = 1
													and cc.cv_diaria = @cv_diaria
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = 1111
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 1111 id_tipomov, @cuenta_orden_debe, 'CREDITOS AL CONSUMO' concepto, @fecha fecha_mov, @capital_saldado monto, 10 id_mov,
												@num_poliza num_poliza, 'O' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'D' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables cc
													on cc.tipo = 1
													and cc.cv_diaria = @cv_diaria
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, numero_fin_lacp, num_ptmo
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 1111 id_tipomov, @cuenta_orden_haber, 'CREDITOS AL CONSUMO' concepto, @fecha fecha_mov, @capital_saldado monto, 10 id_mov,
												@num_poliza num_poliza, 'O' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, 'H' debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular, 2 numero_fin_lacp, @num_ptmo num_ptmo
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables cc
													on cc.tipo = 1
													and cc.cv_diaria = @cv_diaria
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona


									end -- si hay algo por afectar

							end try

							begin catch

								raiserror ('Capital', 11, 0)

							end catch

						end -- preparar pago a capital

						begin -- preparar movimientos sobre haberes

							begin try

								if @ahorro < 0
					
									begin -- si hay alg�n retiro del ahorro
						
										insert	#captura
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes case when @ahorro > 0 then 10 else 310 end id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes case when @ahorro > 0 then 'Dep�sito al ' else 'Retiro del ' end + 'Ahorro' concepto, 
												@fecha fecha_mov, abs(@ahorro) monto, 100 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @ahorro > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_haberes cc
													on cc.tipo = 1
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = case when @ahorro > 0 then 10 else 310 end
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes case when @ahorro > 0 then 10 else 310 end id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes case when @ahorro > 0 then 'Dep�sito al ' else 'Retiro del ' end + 'Ahorro' concepto, 
												@fecha fecha_mov, abs(@ahorro) monto, 100 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @ahorro > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_haberes cc
													on cc.tipo = 1
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = case when @ahorro > 0 then 10 else 310 end
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

									end  -- si hay alg�n retiro del ahorro

								if @inverdinamica < 0
					
									begin -- si hay alg�n retiro de inverdin�mica

										insert	#captura
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes case when @inverdinamica > 0 then 50 else 350 end id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes case when @inverdinamica > 0 then 'Dep�sito a ' else 'Retiro de ' end + 'Inverdin�mica' concepto, 
												@fecha fecha_mov, abs(@inverdinamica) monto, 103 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @inverdinamica > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_haberes cc
													on cc.tipo = 2
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = case when @inverdinamica > 0 then 50 else 350 end
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes case when @inverdinamica > 0 then 50 else 350 end id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes case when @inverdinamica > 0 then 'Dep�sito a ' else 'Retiro de ' end + 'Inverdin�mica' concepto, 
												@fecha fecha_mov, abs(@inverdinamica) monto, 103 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @inverdinamica > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_haberes cc
													on cc.tipo = 2
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = case when @inverdinamica > 0 then 50 else 350 end
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

									end  -- si hay alg�n retiro de inverdin�mica

								if @debito < 0
					
									begin -- si hay alg�n retiro de d�bito
						
										insert	#captura
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes case when @debito > 0 then 1002 else 1001 end id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes case when @debito > 0 then 'Dep�sito a ' else 'Retiro de ' end + 'Tarjeta de D�bito' concepto,
												@fecha fecha_mov, abs(@debito) monto, 112 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @debito > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_haberes cc
													on cc.tipo = 3
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = case when @debito > 0 then 1002 else 1001 end
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes case when @debito > 0 then 1002 else 1001 end id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes case when @debito > 0 then 'Dep�sito a ' else 'Retiro de ' end + 'Tarjeta de D�bito' concepto, 
												@fecha fecha_mov, abs(@debito) monto, 112 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @debito > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_haberes cc
													on cc.tipo = 3
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = case when @debito > 0 then 1002 else 1001 end
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

									end  -- si hay alg�n retiro de d�bito

								if @ahorro > 0
					
									begin -- si hay alg�n dep�sito al ahorro
						
										insert	#captura
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes case when @ahorro > 0 then 10 else 310 end id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes case when @ahorro > 0 then 'Dep�sito al ' else 'Retiro del ' end + 'Ahorro' concepto, 
												@fecha fecha_mov, abs(@ahorro) monto, 100 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @ahorro > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_haberes cc
													on cc.tipo = 1
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = case when @ahorro > 0 then 10 else 310 end
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes case when @ahorro > 0 then 10 else 310 end id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes case when @ahorro > 0 then 'Dep�sito al ' else 'Retiro del ' end + 'Ahorro' concepto, 
												@fecha fecha_mov, abs(@ahorro) monto, 100 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @ahorro > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_haberes cc
													on cc.tipo = 1
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = case when @ahorro > 0 then 10 else 310 end
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

									end  -- si hay alg�n dep�sito al ahorro

								if @inverdinamica > 0
					
									begin -- si hay alg�n dep�sito a inverdin�mica

										insert	#captura
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes case when @inverdinamica > 0 then 50 else 350 end id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes case when @inverdinamica > 0 then 'Dep�sito a ' else 'Retiro de ' end + 'Inverdin�mica' concepto, 
												@fecha fecha_mov, abs(@inverdinamica) monto, 103 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @inverdinamica > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_haberes cc
													on cc.tipo = 2
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = case when @inverdinamica > 0 then 50 else 350 end
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes case when @inverdinamica > 0 then 50 else 350 end id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes case when @inverdinamica > 0 then 'Dep�sito a ' else 'Retiro de ' end + 'Inverdin�mica' concepto, 
												@fecha fecha_mov, abs(@inverdinamica) monto, 103 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @inverdinamica > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_haberes cc
													on cc.tipo = 2
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = case when @inverdinamica > 0 then 50 else 350 end
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

									end  -- si hay alg�n dep�sito a inverdin�mica

								if @debito > 0
					
									begin -- si hay alg�n dep�sito a d�bito
						
										insert	#captura
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes case when @debito > 0 then 1002 else 1001 end id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes case when @debito > 0 then 'Dep�sito a ' else 'Retiro de ' end + 'Tarjeta de D�bito' concepto, 
												@fecha fecha_mov, abs(@debito) monto, 112 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @debito > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_haberes cc
													on cc.tipo = 3
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = case when @debito > 0 then 1002 else 1001 end
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

										insert	#captura_lacp
												(
												id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
												num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
												numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
												)
										select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312
												tm.Id_tipomov id_tipomov,  -- Antes case when @debito > 0 then 1002 else 1001 end id_tipomov, 
												cc.num_cuenta, 
												--Se obtiene la informacion del catalogo de los movimientos --modificado disy596217 20190312 
												tm.Descripcion concepto,  -- Antes case when @debito > 0 then 'Dep�sito a ' else 'Retiro de ' end + 'Tarjeta de D�bito' concepto, 
												@fecha fecha_mov, abs(@debito) monto, 112 id_mov,
												@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @debito > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
												0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
										from	persona per
												join sucursales suc
													on suc.id_de_sucursal = per.id_de_sucursal
												join #cuentas_contables_haberes cc
													on cc.tipo = 3
												--Se agrega join con tipo mov para obtiener la descripcion del movimiento --modificado disy596217 20190312 
												join TIPO_MOV tm
												on tm.Id_tipomov = case when @debito > 0 then 1002 else 1001 end
										where	numero = @numero
												and id_tipo_persona = @id_tipo_persona

									end  -- si hay alg�n dep�sito a d�bito

							end try

							begin catch

								raiserror ('Haberes', 11, 0)

							end catch

						end -- preparar movimientos sobre haberes

						begin -- preparar movimiento de cajas, depuraci�n y conteo

							begin try

								insert	#captura
										(
										id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
										num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
										numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
										)
								select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 961 id_tipomov, '11100100000000' num_cuenta, 'Cajas' concepto, @fecha fecha_mov, abs(@efectivo) monto, 0 id_mov,
										@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @efectivo > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
										0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
								from	persona per
										join sucursales suc
											on suc.id_de_sucursal = per.id_de_sucursal
								where	numero = @numero
										and id_tipo_persona = @id_tipo_persona

								insert	#captura_lacp
										(
										id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
										num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
										numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular
										)
								select	id_persona, 'T' activo, numero, nombre_s, apellido_paterno, apellido_materno, 0 total_movs, abs(@efectivo) total_ficha, 961 id_tipomov, '11100100000000' num_cuenta, 'Cajas' concepto, @fecha fecha_mov, abs(@efectivo) monto, 0 id_mov,
										@num_poliza num_poliza, 'M' tipo_poliza, @folio folio, @id_tipo_persona id_tipo_persona, 0 num_cheq, '' desc1, convert(varchar, @fecha, 112) fecha_dpf_final, '' desc2, @planx planx, '' desc3, 0 num_dpf, 0 tasa, 0 interes, 0 dias, case when @efectivo > 0 then 'H' else 'D' end debe_haber, @numusuario numusuario, @fecha fecha_alta,
										0 numero_fin, 0 plazo, @tasa_ord interes_ord, @tasa_mor interes_mor, @contador_provision contador_provision, suc.ccostos ccostos, '' nombre_beneficiario, '' parentesco_beneficiario, '' nombre_beneficiario2, '' parentesco_beneficiario2, 0 id_convenio, @titular titular
								from	persona per
										join sucursales suc
											on suc.id_de_sucursal = per.id_de_sucursal
								where	numero = @numero
										and id_tipo_persona = @id_tipo_persona

								delete	#captura
								where	monto = 0
								and		id_tipomov != 961------------------------

								delete	#captura_lacp
								where	monto = 0
								and		id_tipomov != 961------------------------

								update	#captura
								set		total_movs = (select count(1) from #captura)

								update	#captura_lacp
								set		total_movs = (select count(1) from #captura_lacp)

							end try

							begin catch

								raiserror ('Cajas', 11, 0)

							end catch

						end -- preparar movimiento de cajas, depuraci�n y conteo

						--select * from #captura-----------------------------

						--select * from #captura_lacp-----------------------

					end try

					begin catch

						select @mensaje = 'Error al preparar afectaci�n en Hape [' + error_message() + ']'

						raiserror (@mensaje, 11, 0)

					end catch


				end -- preparar afectaci�n en Hape
			
			end -- preparaci�n
			
			begin -- transacci�n

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio

				begin -- insertar acci�n

					begin try

						insert	tbl_revolvente_log_acciones
								(
								id_linea,
								id_disposicion,
								numero,
								id_tipo_persona,
								id_tipo_accion,
								numusuario,
								numemp,
								id_rol,
								id_de_sucursal,
								folio,
								num_poliza,
								fecha,
								activa
								)
						values
								(
								@id_linea,
								null,
								@numero,
								@id_tipo_persona,
								5,
								@numusuario,
								@numemp,
								@id_rol,
								@id_de_sucursal,
								@folio,
								@num_poliza,
								@fecha,
								1
								)

						select @id_accion = scope_identity()

					end try

					begin catch

						raiserror ('Error al insertar la acci�n', 13, 0)

					end catch

				end -- insertar acci�n
				
				begin -- respaldar estatus de l�neas, disposiciones y ciclos de facturaci�n

					begin try

--						select @moratorios_saldados + @ordinarios_saldados + @capital_saldado

						if @moratorios_saldados + @ordinarios_saldados + @capital_saldado > 0

							begin -- si hay algo por afectar

								begin -- respaldar ciclos

									insert	tbl_revolvente_ciclos_facturacion_resguardo_cancelacion
											(
											id_accion,
											id_ciclo,
											num_ciclo,
											id_disposicion,
											capital,
											fecha_corte,
											fecha_limite,
											fecha_al_corriente_int_mor,
											int_mor_acum,
											int_mor_acum_precision,
											fecha_acum_int_mor,
											resguardo_activo,
											fecha_limite_original
											)
									select	@id_accion,
											id_ciclo,
											num_ciclo,
											id_disposicion,
											capital,
											fecha_corte,
											fecha_limite,
											fecha_al_corriente_int_mor,
											int_mor_acum,
											int_mor_acum_precision,
											fecha_acum_int_mor,
											activo,
											fecha_limite_original
									from	tbl_revolvente_ciclos_facturacion
									where	id_disposicion in
												(
												select	id_disposicion
												from	tbl_revolvente_disposiciones
												where	id_linea = @id_linea
														and activa = 1
												)
											and activo = 1

								end -- respaldar ciclos

								begin -- respaldar disposiciones

									insert	tbl_revolvente_disposiciones_resguardo_cancelacion
											(
											id_accion,
											id_disposicion,
											id_linea,
											monto_disposicion,
											saldo_actual,
											fecha_disposicion,
											tasa_ord,
											tasa_mor,
											pago_minimo,
											dias_vencidos,
											max_dias_vencidos,
											dias_vencidos_interes,
											max_dias_vencidos_interes,
											fecha_ultimo_abono,
											fecha_ultimo_int_ord,
											fecha_ultimo_int_mor,
											fecha_al_corriente_int_ord,
											int_ord_vig_acum,
											int_ord_vig_acum_precision,
											int_ord_corte_acum,
											int_ord_ven_acum,
											fecha_acum_int_ord,
											autorizo,
											resguardo_activo
											)
									select	@id_accion,
											id_disposicion,
											id_linea,
											monto_disposicion,
											saldo_actual,
											fecha_disposicion,
											tasa_ord,
											tasa_mor,
											pago_minimo,
											dias_vencidos,
											max_dias_vencidos,
											dias_vencidos_interes,
											max_dias_vencidos_interes,
											fecha_ultimo_abono,
											fecha_ultimo_int_ord,
											fecha_ultimo_int_mor,
											fecha_al_corriente_int_ord,
											int_ord_vig_acum,
											int_ord_vig_acum_precision,
											int_ord_corte_acum,
											int_ord_ven_acum,
											fecha_acum_int_ord,
											autorizo,
											activa
									from	tbl_revolvente_disposiciones
									where	id_linea = @id_linea
											and activa = 1

								end -- respaldar disposiciones

								begin -- respaldar l�neas

									insert	TBL_REVOLVENTE_LINEAS_CREDITO_RESGUARDO_CANCELACION
											(
											id_accion,
											id_linea,
											numero,
											id_tipo_persona,
											num_ptmo,
											planx,
											id_de_sucursal,
											saldo_actual,
											limite_credito,
											tasa_ord,
											tasa_mor,
											CAT,
											fecha_autorizacion,
											fecha_ultimo_incremento,
											dia_corte,
											dia_limite,
											id_estado,
											CV_diaria,
											fecha_traspaso_CV,
											fecha_primer_incumplimiento,
											fecha_primer_incumplimiento_interes
											)
									select	@id_accion,
											id_linea,
											numero,
											id_tipo_persona,
											num_ptmo,
											planx,
											id_de_sucursal,
											saldo_actual,
											limite_credito,
											tasa_ord,
											tasa_mor,
											CAT,
											fecha_autorizacion,
											fecha_ultimo_incremento,
											dia_corte,
											dia_limite,
											id_estado,
											CV_diaria,
											fecha_traspaso_CV,
											fecha_primer_incumplimiento,
											fecha_primer_incumplimiento_interes
									from	TBL_REVOLVENTE_LINEAS_CREDITO
									where	id_linea = @id_linea
											--and id_estado = 1

								end -- respaldar l�neas

							end -- si hay algo por afectar

					end try

					begin catch

						raiserror ('Error al respaldar estatus de la l�nea de cr�dito', 13, 0)

					end catch

				end -- respaldar estatus de l�neas, disposiciones y ciclos de facturaci�n

				begin -- saldar pago m�nimo

					begin try

						begin -- intereses moratorios y capital en ciclos de facturaci�n

							if @moratorios_saldados + @capital_minimo_saldado > 0

								begin -- si hubo algo por afectar

									update	cf
									set		cf.fecha_al_corriente_int_mor = coalesce(pm.fecha_al_corriente_int_mor_saldado, cf.fecha_al_corriente_int_mor),											
											cf.int_mor_acum = pm.int_mor - pm.int_mor_saldado,
											cf.capital = pm.capital - pm.capital_saldado
									from	TBL_REVOLVENTE_CICLOS_FACTURACION cf
											join #pago_minimo pm
												on pm.id_disposicion = cf.id_disposicion
												and pm.num_ciclo = cf.num_ciclo
												and pm.int_mor_saldado + pm.capital_saldado > 0

								end -- si hubo algo por afectar

						end -- intereses moratorios y capital en ciclos de facturaci�n

						begin -- intereses ordinarios en disposiciones

							if @ordinarios_minimo_saldados > 0

								begin -- si hay algo por afectar

									update	d
									set		d.fecha_al_corriente_int_ord = pm.fecha_al_corriente_int_ord_saldado,
											d.int_ord_ven_acum = pm.int_ord_ven - pm.int_ord_ven_saldado,
											d.int_ord_corte_acum = pm.int_ord_corte - pm.int_ord_corte_saldado,
											d.fecha_ultimo_int_ord = coalesce(pm.fecha_ultimo_abono_ordinarios, d.fecha_ultimo_int_ord),
											d.fecha_ultimo_int_mor = coalesce(pm.fecha_ultimo_abono_moratorios, d.fecha_ultimo_int_mor)
									from	#pago_minimo pm
											join TBL_REVOLVENTE_DISPOSICIONES d
												on d.id_disposicion = pm.id_disposicion
									where	pm.int_ord_ven_saldado + pm.int_ord_corte_saldado > 0

								end -- si hay algo por afectar

						end -- intereses ordinarios en disposiciones

						begin -- decrementar capital

							if @capital_minimo_saldado > 0

								begin -- si hay algo por afectar

									begin -- decrementar capital en l�nea

										update	TBL_REVOLVENTE_LINEAS_CREDITO
										set		saldo_actual = saldo_actual - @capital_minimo_saldado
										where	id_linea = @id_linea
												and numero = @numero
												and @capital_minimo_saldado > 0

									end -- decrementar capital en l�nea

									begin -- decrementar capital en disposiciones

										update	d
										set		d.saldo_actual = d.saldo_actual - _.capital_saldado,
												d.fecha_ultimo_abono = @fecha
										from	(
												select	id_disposicion, sum(capital_saldado) capital_saldado
												from	#pago_minimo
												group by
														id_disposicion
														) _
												join TBL_REVOLVENTE_DISPOSICIONES d
													on d.id_disposicion = _.id_disposicion
													and d.id_linea = @id_linea
										where	_.capital_saldado > 0

									end -- decrementar capital en disposiciones

								end -- si hay algo por afectar

						end -- decrementar capital

					end try

					begin catch

						raiserror('Error al saldar pago m�nimo en la l�nea de cr�dito', 13, 0)

					end catch

				end -- saldar pago m�nimo

				begin -- saldar intereses desde corte

					begin try

						--select @ordinarios_desde_corte_mas_iva

						if @ordinarios_desde_corte_mas_iva > 0

							begin -- si hay algo por afectar

								update	d
								set		d.fecha_al_corriente_int_ord = coalesce(dc.fecha_al_corriente_int_ord_saldado, d.fecha_al_corriente_int_ord),
										d.int_ord_vig_acum = d.int_ord_vig_acum - dc.int_ord_vig_acum_saldado,
										d.fecha_ultimo_int_ord = coalesce(dc.fecha_ultimo_abono_ordinarios_saldado, d.fecha_ultimo_int_ord)
								from	#intereses_desde_corte dc
										join TBL_REVOLVENTE_DISPOSICIONES d
											on d.id_disposicion = dc.id_disposicion
											and dc.int_ord_vig_acum_saldado > 0

								--select 'rev 01', * from TBL_REVOLVENTE_DISPOSICIONES where id_disposicion in (3, 9)

							end -- si hay algo por afectar

					end try

					begin catch

						raiserror ('Error al saldar intereses desde el corte en la l�nea de cr�dito', 13, 0)

					end catch

				end -- saldar intereses desde corte

				begin -- saldar capital de adelanto

					begin try

						if @capital_adelanto_saldado > 0

							begin -- si hay algo por afectar

								begin -- saldar ciclos

									update	cf
									set		cf.capital = c.capital - capital_saldado
									from	#capital_adelanto c
											join TBL_REVOLVENTE_CICLOS_FACTURACION cf
												on cf.num_ciclo = c.num_ciclo
												and cf.id_disposicion = c.id_disposicion
									where	capital_saldado > 0

								end -- saldar ciclos

								begin -- saldar disposiciones

									update	d
									set		d.saldo_actual = d.saldo_actual - _.capital_saldado,
											d.fecha_ultimo_abono = @fecha
									from	(
											select	c.id_disposicion, sum(capital_saldado) capital_saldado
											from	#capital_adelanto c
													join TBL_REVOLVENTE_DISPOSICIONES d_
														on d_.id_disposicion = c.id_disposicion
											where	d_.id_linea = @id_linea
													and capital_saldado > 0
													and c.pago_minimo = 0
											group by
													c.id_disposicion
											) _
											join TBL_REVOLVENTE_DISPOSICIONES d
												on d.id_disposicion = _.id_disposicion

								end -- saldar disposiciones

								begin -- saldar linea

									update	TBL_REVOLVENTE_LINEAS_CREDITO
									set		saldo_actual = saldo_actual - @capital_adelanto_saldado
									from	TBL_REVOLVENTE_LINEAS_CREDITO
									where	id_linea = @id_linea
											and @capital_adelanto_saldado > 0

								end -- saldar linea

							end -- si hay algo por afectar

					end try

					begin catch

						raiserror ('Error al saldar el capital de adelanto en la l�nea de cr�dito', 13, 0)

					end catch

				end -- saldar capital de adelanto

				begin -- respaldar saldos en haberes

					begin try

					if @ahorro != 0 or @inverdinamica != 0 or @debito != 0

						begin -- si hay algo por afectar en cuentas de haberes

							insert	#saldos_edo_de_cuenta
									(id_mov, saldo_actual, fecha)
							select	id_mov, saldo_actual, fecha
							from	edo_de_cuenta
							where	numero = @numero
									and id_mov in (100, 103, 112)

							select	@saldo_anterior_100 = saldo_actual,
									@fecha_anterior_100 = fecha
							from	#saldos_edo_de_cuenta
							where	id_mov = 100

							select	@saldo_anterior_103 = saldo_actual,
									@fecha_anterior_103 = fecha
							from	#saldos_edo_de_cuenta
							where	id_mov = 103

							select	@saldo_anterior_112 = saldo_actual,
									@fecha_anterior_112 = fecha
							from	#saldos_edo_de_cuenta
							where	id_mov = 112

							insert	TBL_REVOLVENTE_EDO_DE_CUENTA_RESGUARDO_CANCELACION
									(
									id_accion,
									numero,
									id_tipo_persona,
									saldo_100,
									fecha_100,
									saldo_103,
									fecha_103,
									saldo_112,
									fecha_112,
									resguardo_activo
									)
							values	(
									@id_accion,
									@numero,
									@id_tipo_persona,
									case when @ahorro != 0 then @saldo_anterior_100 else null end,
									case when @ahorro != 0 then @fecha_anterior_100 else null end,
									case when @inverdinamica != 0 then @saldo_anterior_103 else null end,
									case when @inverdinamica != 0 then @fecha_anterior_103 else null end,
									case when @debito != 0 then @saldo_anterior_112 else null end,
									case when @debito != 0 then @fecha_anterior_112 else null end,
									1
									)

						end -- si hay algo por afectar en cuentas de haberes

					end try

					begin catch

						raiserror('Error al respaldar saldos en haberes', 13, 0)

					end catch

				end -- respaldar saldos en haberes

				begin -- afectar movimientos en hape

					begin try

						insert	CAPTURA
								(
								id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov,
								cuenta, concepto, fecha_mov, monto, neto, id_mov, banco, clave_local, linea, num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1,
								desc2, planx, aval1_socio, aval1_numero, aval2_socio, aval2_numero, desc3, desc4, fecha_dpf_final, num_dpf, tasa, interes, dias, debe_haber,
								numusuario, procesado, fecha_alta, numero_fin, numero_fin2, plazo, interes_ord, interes_mor, monto2, plazo2, interes_ord2, interes_mor2,
								aval1_avalados, aval2_avalados, fec_inicio, fec_prog, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario,
								porcentaje_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, porcentaje_beneficiario2, id_sol, numero_fin_lacp, reestructura,
								id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, ent_federativa, cve_municipio, cve_localidad, identificador, transferencia,
								fecha_pago, bimestre, referencia, cve_archivo, impreso, folio_impresion, documentacion, dpf_en_garantia, titular, id_nomina, id_esquema_nomina,
								id_leyenda, num_ptmo, id_renovado, ahorro_base, tasa_pasiva, id_fondeador, numero_fondeo, id_origen
								)
						select	id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov,
								cuenta, concepto, fecha_mov, monto, neto, id_mov, banco, clave_local, linea, num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1,
								desc2, planx, aval1_socio, aval1_numero, aval2_socio, aval2_numero, desc3, desc4, fecha_dpf_final, num_dpf, tasa, interes, dias, debe_haber,
								numusuario, procesado, fecha_alta, numero_fin, numero_fin2, plazo, interes_ord, interes_mor, monto2, plazo2, interes_ord2, interes_mor2,
								aval1_avalados, aval2_avalados, fec_inicio, fec_prog, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario,
								porcentaje_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, porcentaje_beneficiario2, id_sol, numero_fin_lacp, reestructura,
								id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, ent_federativa, cve_municipio, cve_localidad, identificador, transferencia,
								fecha_pago, bimestre, referencia, cve_archivo, impreso, folio_impresion, documentacion, dpf_en_garantia, titular, id_nomina, id_esquema_nomina,
								id_leyenda, num_ptmo, id_renovado, ahorro_base, tasa_pasiva, id_fondeador, numero_fondeo, @id_origen
						from	#captura
						order by
								contador

						insert	CAPTURA_LACP
								(
								id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov,
								cuenta, concepto, fecha_mov, monto, neto, id_mov, banco, clave_local, linea, num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1,
								desc2, planx, aval1_socio, aval1_numero, aval2_socio, aval2_numero, desc3, desc4, fecha_dpf_final, num_dpf, tasa, interes, dias, debe_haber,
								numusuario, procesado, fecha_alta, numero_fin, numero_fin2, plazo, interes_ord, interes_mor, monto2, plazo2, interes_ord2, interes_mor2,
								aval1_avalados, aval2_avalados, fec_inicio, fec_prog, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario,
								porcentaje_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, porcentaje_beneficiario2, id_sol, numero_fin_lacp, reestructura,
								id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, ent_federativa, cve_municipio, cve_localidad, identificador, transferencia,
								fecha_pago, bimestre, referencia, cve_archivo, impreso, folio_impresion, documentacion, dpf_en_garantia, titular, id_nomina, id_esquema_nomina,
								id_leyenda, num_ptmo, id_renovado, ahorro_base, tasa_pasiva, id_fondeador, numero_fondeo, id_origen
								)
						select	id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov,
								cuenta, concepto, fecha_mov, monto, neto, id_mov, banco, clave_local, linea, num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1,
								desc2, planx, aval1_socio, aval1_numero, aval2_socio, aval2_numero, desc3, desc4, fecha_dpf_final, num_dpf, tasa, interes, dias, debe_haber,
								numusuario, procesado, fecha_alta, numero_fin, numero_fin2, plazo, interes_ord, interes_mor, monto2, plazo2, interes_ord2, interes_mor2,
								aval1_avalados, aval2_avalados, fec_inicio, fec_prog, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario,
								porcentaje_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, porcentaje_beneficiario2, id_sol, numero_fin_lacp, reestructura,
								id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, ent_federativa, cve_municipio, cve_localidad, identificador, transferencia,
								fecha_pago, bimestre, referencia, cve_archivo, impreso, folio_impresion, documentacion, dpf_en_garantia, titular, id_nomina, id_esquema_nomina,
								id_leyenda, num_ptmo, id_renovado, ahorro_base, tasa_pasiva, id_fondeador, numero_fondeo, @id_origen
						from	#captura_lacp
						order by
								contador

						---- agregar a movimientos los gastos de cobranza, intereses moratorios, e intereses ordinarios
						--insert	movimientos
						--		(
						--		numero, activo, fecha_mov, monto, saldo, tipo_poliza, num_poliza, folio, interes_ord, interes_mor, plazo, numero_fin,
						--		id_persona, numusuario, id_tipomov, fecha_dpf_final, num_dpf, tasa_dpf, interes_dpf, dias, id_mov, id_tipo_persona, numero_fin_lacp, fecha_alta,
						--		reestructura, id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, titular, planx, num_ptmo, id_nomina, id_esquema_nomina, id_renovado
						--		)
						--select	c.numero, activo, fecha_mov, monto, 0 saldo, 'M' tipo_poliza, num_poliza, folio, interes_ord, interes_mor, null plazo, null numero_fin,
						--		id_persona, @numusuario numusuario, id_tipomov, fecha_dpf_final, num_dpf, 0 tasa_dpf, 0 interes_dpf, 0 dias, c.id_mov, c.id_tipo_persona, numero_fin_lacp, fecha_alta,
						--		reestructura, id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, titular, c.planx, c.num_ptmo, id_nomina, id_esquema_nomina, id_renovado
						--from	#captura c
						--		left join TBL_REVOLVENTE_LINEAS_CREDITO lc
						--			on lc.id_linea = @id_linea
						--			and c.id_tipomov != 1111
						--		left join #saldos_edo_de_cuenta cta
						--			on cta.id_mov = c.id_mov
						--where	c.id_mov = 10
						--order by
						--		contador

						-- agregar a movimientos los pagos a capital
						insert	movimientos
								(
								numero, activo, fecha_mov, monto, saldo, tipo_poliza, num_poliza, folio, interes_ord, interes_mor, plazo, numero_fin,
								id_persona, numusuario, id_tipomov, fecha_dpf_final, num_dpf, tasa_dpf, interes_dpf, dias, id_mov, id_tipo_persona, numero_fin_lacp, fecha_alta,
								reestructura, id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, titular, planx, num_ptmo, id_nomina, id_esquema_nomina, id_renovado, id_origen
								)
						select	c.numero, activo, fecha_mov, monto, coalesce(lc.saldo_actual, cta.saldo_actual + case c.id_mov when 100 then @ahorro when 103 then @inverdinamica when 112 then @debito end, 0) saldo, 'M' tipo_poliza, num_poliza, folio, interes_ord, interes_mor, null plazo, null numero_fin,
								id_persona, @numusuario numusuario, id_tipomov, fecha_dpf_final, num_dpf, 0 tasa_dpf, 0 interes_dpf, 0 dias, c.id_mov, c.id_tipo_persona, numero_fin_lacp, fecha_alta,
								reestructura, id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, titular, c.planx, c.num_ptmo, id_nomina, id_esquema_nomina, id_renovado, @id_origen
						from	#captura c
								left join TBL_REVOLVENTE_LINEAS_CREDITO lc
									on lc.id_linea = @id_linea
									and c.id_tipomov = 1111
								left join #saldos_edo_de_cuenta cta
									on cta.id_mov = c.id_mov
						where	c.id_mov != 0
						order by
								contador

						if @ahorro != 0

							update	#saldos_edo_de_cuenta
							set		saldo_posterior = saldo_actual + @ahorro
							where	id_mov = 100

						if @inverdinamica != 0

							update	#saldos_edo_de_cuenta
							set		saldo_posterior = saldo_actual + @inverdinamica
							where	id_mov = 103

						if @debito != 0

							update	#saldos_edo_de_cuenta
							set		saldo_posterior = saldo_actual + @debito
							where	id_mov = 112
					
						update	cta
						set		cta.saldo_actual = _.saldo_posterior,
								cta.fecha = @fecha
						from	edo_de_cuenta cta
								join
									(
									select	*
									from	#saldos_edo_de_cuenta
									where	saldo_posterior is not null
									) _
									on cta.numero = @numero
									and _.id_mov = cta.id_mov
						where	cta.numero = @numero

						if @id_origen != 3

							update	folios
							set		folio = folio + 1,
									fecha = @fecha
							where	numero = @numusuario

					end try

					begin catch

						raiserror('Error al afectar movimientos en hape', 13, 0)

					end catch
					
				end -- afectar movimientos en hape
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal

			begin -- tratamiento del error
		
				-- captura del error
				select	@status = -error_state(),
						@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
						@error_line = error_line(),
						@error_procedure = case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end,
						@error_message = error_message()

				select @status = coalesce(@status, 0)
						
				-- revertir transacci�n si es necesario
				if @tran_scope = 1
					rollback tran @tran_name

			end -- tratamiento del error
		
		end catch -- catch principal
		
		begin -- reporte de status

			insert	#procedimiento_pago_credito
					(
					status,
					error_procedure,
					error_line,
					error_severity,
					error_message
					)
			select	@status,
					@error_procedure,
					@error_line,
					@error_severity,
					@error_message

			if @standalone = 1

				select	*
				from	#procedimiento_pago_credito
				
		end -- reporte de status
		
	end -- procedimiento

go
