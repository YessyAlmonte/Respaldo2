USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_INTERES_DIARIO_OBTIENE_SALDOS_BANCA_NIVELADOS]    Script Date: 12/03/2020 04:16:38 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Adrian Coria
UsuarioRed		cofa616206
Fecha			2018/01/04
Objetivo		Obtener los saldos pendientes del socio
Proyecto		Interes diario
Ticket			ticket

*/
ALTER proc
	[dbo].[SP_INTERES_DIARIO_OBTIENE_SALDOS_BANCA_NIVELADOS]

	@numero int,
	@id_mov int,
	@fecha datetime = null,
	@tipoConsulta int = null  -- null o 0 --> default para consulta de cajas al mostrar lo adeudado,
							  -- 1 --> para los resumenes de saldo, mostrar todo lo adeudado

as
	begin
	
		begin try

		--SE AGREGAN VARIABLES PARA AGREGAR ANIDACION DE TABLAS TEMPORALES
		declare	@sql nvarchar(4000) = 'delete #datos',@standalone	bit = 1

		declare @saldo_actual money=0.0		
		declare @tasa_mor float=3.0				
		declare @saldo_adelanto money=0.0
		declare @id_esquema int 
		declare @today datetime
		/*Se agrega para distinguir credinomina*/
		declare @plan varchar(1),
		@montoCapAmort money,
		@numPtmo varchar(15)
		--Se agrega para determinar si aplica o no IVA
		,@aplicaIVA bit
		,@tasaIVA money
		-- para quitas
		,@int_mor_quita money = 0.0
		,@iva_int_mor_quita money = 0.0
		,@int_ord_quita money = 0.0
		,@iva_int_ord_quita money = 0.0
		,@reserva_capital money = 0.0
		,@reserva_interes money = 0.0
		-------------------------------------------
		,@intMorDespuesVencimiento money = 0.0
		,@ivaMorDespuesVencimiento money = 0.0
		,@intMor money = 0.0
		,@ivaMor money = 0.0
		,@intOrdVen money = 0.0
		,@ivaOrdVen money = 0.0
		,@intOrd money = 0.0
		,@ivaOrd money = 0.0
		,@capitalVencido money = 0.0
		,@capitalVigente money = 0.0
		,@capitalNoDevengado money = 0.0
		,@verCalenda int = 0
		,@tasaIntOrd float = 0.0
		,@ultimoAbono datetime
		,@fechaPtmo datetime
		,@ultimoAbonoConTiempo datetime
		,@intOrdPagadoPostUltAbono money = 0.0
		,@intMorPagadoPostUltAbono money = 0.0
		,@numCorteVigenteCurso int = 0
		,@plazo int = 1
		--Se agrega por dias inhabiles
		, @primer_corte_vigente money = 0
		, @numCorteVig int = 0
		, @numCorteTras int = 0
		--Se agrega para banca electronica
		, @idTipoBloqueo int = 0
		, @monto_a_pagar_amortizacion money
		, @tasa_gastos_cobranza float


		select @today = coalesce(@fecha, cast(getdate() as date)),
		@tipoConsulta = coalesce(@tipoConsulta, 0)
		 
		select @today = cast(@today as date)
		
		if not exists(select numero from PERSONA where Numero=@numero  and Id_Tipo_Persona=1)
			raiserror('El numero de socio ingresado no existe',11,0)

		create table
			#SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR
				(
				status					int null,
				error_procedure			varchar(255) null,
				error_line				varchar(255) null,
				error_severity			varchar(255) null,
				error_message			varchar(255) null,
				seguro_vida				money null,
				seguro_da�os			money null,
				int_mor					money null,
				iva_int_mor				money null,
				int_ord_ven				money null,
				iva_int_ord_ven			money null,
				int_ord_vig				money null,
				iva_int_ord_vig			money null,
				cap_ven					money null,
				cap_vig					money null,
				int_ord_hoy				money null,
				iva_int_ord_hoy			money null,
				cap_no_dev				money null,
				gastos_cobranza			money null,
				iva_gastos_cobranza		money null,
				tasa_gastos_cobranza	float null,
				monto_a_pagar			money null,
				no_asignado				money null,
				saldo_actual			money null,
				saldo_ahorro			money null,
				saldo_inver				money null,
				saldo_debito			money null,
				)
		
		select @tasaIVA = tasa / 100.00
		from tasas 
		where contador = (select max(contador) from tasas where id_mov = 111)

		select @saldo_actual=coalesce(saldo_actual,0),@id_esquema=Id_Esquema,@saldo_adelanto=coalesce(saldo_adelanto,0),@tasa_mor=Int_Mor,
		@plan = PlanX, @numPtmo = Num_ptmo
		--Se agrega para determinar si aplica IVA
		,@aplicaIVA = aplica_IVA
		,@tasaIntOrd = Int_Ord
		,@ultimoAbono = CAST(Ultimo_Abono as date), @fechaPtmo = Fecha_Ptmo
		,@ultimoAbonoConTiempo = Ultimo_Abono, @plazo = Plazo
		from EDO_DE_CUENTA
		where Numero=@numero and Id_mov=@id_mov and Saldo_Actual>0		
		
		-------------------------------------------------------------------------------------------
		-- para quitas
			--moratorio que debe pagar
			select	@int_mor_quita = TOTAL_PAGAR,
					@iva_int_mor_quita = round((coalesce(TOTAL_PAGAR, 0) )*@tasaIVA * CAST(@aplicaIVA as int),2,0)
			from	TBL_QUITAS_CREDITOS_MOVIMIENTOS 
			where	ID_QUITA = (select top 1 ID_QUITA from TBL_QUITAS_CREDITOS where NUM_PTMO = @numPtmo and ID_ESTATUS_QUITA = 2)
				and ID_TIPOMOV like '86_'
			--ordinario que debe pagar
			select	@int_ord_quita = TOTAL_PAGAR,
					@iva_int_ord_quita = round((coalesce(TOTAL_PAGAR, 0) )*@tasaIVA * CAST(@aplicaIVA as int),2,0)
			from	TBL_QUITAS_CREDITOS_MOVIMIENTOS 
			where	ID_QUITA = (select top 1 ID_QUITA from TBL_QUITAS_CREDITOS where NUM_PTMO = @numPtmo and ID_ESTATUS_QUITA = 2)
				and ID_TIPOMOV like '84_'
		-------------------------------------------------------------------------------------------


		if (@saldo_actual is null) or (@saldo_actual = 0)
			raiserror('El cr�dito especificado no tiene saldo pendiente',11,0)
			
				
		select @reserva_capital = Reserva_Capital, @reserva_interes = Reserva_Interes_Vigente 
		from TBL_DECLARACION_CARTERA
		where numero = @numero and Id_mov = @id_mov
				
		begin	
				
			begin try -- revisar tabla de resultados

				exec (@sql)
				select @standalone = 0

			end try -- revisar tabla de resultados
			begin catch -- revisar tabla de resultados

				CREATE TABLE #datos (status int null,
				saldo_actual money null,
				interes_moratorio money null,
				interes_ord_vencido money null, 
				interes_ordinario_vigente money null
				,capital_vencido money null,
				capital_corte money null,
				seguro_vida money null,
				seguro_danos money null,
				saldo_adelanto money null,
				pago_al_corriente money null,
				capital_no_devengado_fin money null, 
				capitalAmort money null
				,ivaIntMoratorio money null
				,ivaIntOrdinarioVencido money null
				,ivaIntOrdinarioVigente money null
				,int_moratorio_quitas money null
				,int_moratorio_quitas_iva money null
				,int_ordinario_quitas money null
				,int_ordinario_quitas_iva money null
				,reserva_capital money null
				,reserva_interes money null
				--Se agregan por gastos de cobranza
				,gastos_cobranza			money null,
				iva_gastos_cobranza		money null,
				tasa_gastos_cobranza	float null
				, primer_corte_vigente money null
				)

			end catch -- revisar tabla de resultados
			
			begin
				if (@id_mov = 1) and (@plan = 'E')	
				begin
					if exists(select numero from TBL_CREDINOMINA_PTMOS_CAJAS where Numero = @numero and id_mov = @id_mov)
					begin
						
						SELECT @numCorteTras = MIN(Num_pago)
						FROM TBL_CREDINOMINA_PTMOS_CAJAS 
						WHERE Numero = @numero 
						and Id_mov = @id_mov 
						and Num_ptmo = @numPtmo
						and Id_status = 1 
						and cast(Fecha_pago as date) >= CAST(@today as date)
						and DAY(Fecha_pago) != DAY(fecha_fin_original)

						begin -- bloque para determinar fecha inicio devengo

							select	id = row_number() over (order by contador),
									*,
									fecha_inicio = cast(null as datetime)
							into	#calendario_credinomina_cajas
							from	tbl_credinomina_ptmos_cajas
							where	numero = @numero
									and id_mov = @id_mov
									and num_ptmo = @numptmo
									and id_status != 4
							order by
									contador

							update	c2
							set		fecha_inicio = c1.Fecha_pago
							from	#calendario_credinomina_cajas c1
									join #calendario_credinomina_cajas c2
										on c2.id = c1.id + 1

							update	#calendario_credinomina_cajas
							set		fecha_inicio = @fechaPtmo
							where	fecha_inicio is null

							delete #calendario_credinomina_cajas where id_status not in (1)

							select	@numcortevig = num_pago
							from	#calendario_credinomina_cajas
							where	fecha_inicio < @today
									and @today <= fecha_pago

						end -- bloque para determinar fecha inicio devengo

						--SELECT @numCorteVig = MIN(Num_pago) 
						--FROM TBL_CREDINOMINA_PTMOS_CAJAS 
						--WHERE Numero = @numero 
						--and Id_mov = @id_mov 
						--and Num_ptmo = @numPtmo
						--and Id_status = 1 
						--and cast(Fecha_pago as date) >= CAST(@today as date)
						--and DAY(Fecha_pago) = DAY(fecha_fin_original)

						insert #datos ( status, capital_corte, interes_ordinario_vigente, ivaIntOrdinarioVigente, 
						seguro_vida, seguro_danos,
						capital_no_devengado_fin, saldo_actual, saldo_adelanto, pago_al_corriente, capitalAmort, int_moratorio_quitas,
						int_moratorio_quitas_iva, int_ordinario_quitas, int_ordinario_quitas_iva, reserva_capital, reserva_interes
						, primer_corte_vigente)
						select  
							1 estatus,
							SUM(Capital) capital_corte,
							SUM(Interes) interes_ordinario_vigente,
							SUM(IVA) ivaIntOrdinarioVigente,							
							0 AS SEGURO_VIDA,
							0 AS Seguro_danos,
							0 capital_no_devengado_fin,
							@saldo_actual as saldo_Actual,
							@saldo_adelanto saldoAdelanto,
							0 pago_al_corriente,
							SUM(vig.Total) Total
							-- para quitas
							,@int_mor_quita as int_moratorio_quitas
							,@iva_int_mor_quita as int_moratorio_quitas_iva
							,@int_ord_quita as int_ordinario_quitas
							,@iva_int_ord_quita as int_ordinario_quitas_iva
							,@reserva_capital reserva_capital,
							@reserva_interes reserva_interes
							, 0 primer_corte_vigente				 
							from TBL_CREDINOMINA_PTMOS_CAJAS vig	
							where vig.Numero = @numero 
							and vig.Id_mov = @id_mov
							and vig.Num_ptmo = @numPtmo
							and vig.Num_pago in (@numCorteTras, @numCorteVig)
							and vig.Id_status = 1

						if not exists (select * from #datos)
						begin
							insert into #datos
								(
								status,
								saldo_actual,
								interes_moratorio,
								interes_ord_vencido,
								interes_ordinario_vigente,
								capital_vencido,
								capital_corte,
								seguro_vida,
								seguro_danos,
								saldo_adelanto,
								pago_al_corriente,
								capital_no_devengado_fin,
								capitalAmort,
								ivaIntMoratorio,
								ivaIntOrdinarioVencido,
								ivaIntOrdinarioVigente,
								int_moratorio_quitas,
								int_moratorio_quitas_iva,
								int_ordinario_quitas,
								int_ordinario_quitas_iva,
								reserva_capital,
								reserva_interes
								,primer_corte_vigente
								) 
								SELECT 1,@saldo_actual,0,0,0,0,0,0,0,0,0,@saldo_actual,0,0,0,0,0,0,0,0,0,0, 0
						end
						
						--Vencido
						update #datos 
						set 
						--capital_corte = (@saldo_actual - cal.capital_vencido), 
						capital_vencido = cal.capital_vencido, 
						interes_ord_vencido = cal.interes_ord_vencido, 
						ivaIntOrdinarioVencido = cal.ivaIntOrdinarioVencido,
						interes_moratorio = cal.interes_moratorio, 
						ivaIntMoratorio = cal.ivaIntMoratorio
						from (select numero, id_mov, Num_ptmo,
							SUM(Capital) capital_vencido,
							SUM(Interes) interes_ord_vencido,
							SUM(IVA) ivaIntOrdinarioVencido,
							SUM(round(((case when cast(fecha_pago as date) < CAST(@today as date) 
												then DATEDIFF(dd,fecha_pago, @today) 
												else 0 
												end
										) * (@tasa_mor / 3000.00) * Capital), 2, 0)) interes_moratorio,

							SUM(ROUND((round(((case when cast(fecha_pago as date) < CAST(@today as date) 
													then DATEDIFF(dd,fecha_pago, @today) 
													else 0 
													end
												) * (@tasa_mor / 3000.00) * Capital), 2, 0)) * @tasaIVA * CAST(@aplicaIVA as int), 2, 0)) ivaIntMoratorio
							from TBL_CREDINOMINA_PTMOS_CAJAS
							WHERE Numero = @numero 
							and Id_mov = @id_mov 
							and Fecha_pago < CAST(@today as date)
							and Id_status = 1
							group by numero, id_mov, Num_ptmo	
						)Cal		
					end
					else
					begin

						SELECT @numCorteTras = MIN(Num_pago)
						FROM TBL_CREDINOMINA_PTMOS 
						WHERE Numero = @numero 
						and Id_mov = @id_mov 
						and Num_ptmo = @numPtmo
						and Id_status = 1 
						and cast(Fecha_pago as date) >= CAST(@today as date)
						and DAY(Fecha_pago) != DAY(fecha_fin_original)

						begin -- bloque para determinar fecha inicio devengo

							select	id = row_number() over (order by contador),
									*,
									fecha_inicio = cast(null as datetime)
							into	#calendario_credinomina
							from	tbl_credinomina_ptmos
							where	numero = @numero
									and id_mov = @id_mov
									and num_ptmo = @numptmo
									and id_status != 4
							order by
									contador

							update	c2
							set		fecha_inicio = c1.Fecha_pago
							from	#calendario_credinomina c1
									join #calendario_credinomina c2
										on c2.id = c1.id + 1

							update	#calendario_credinomina
							set		fecha_inicio = @fechaPtmo
							where	fecha_inicio is null

							delete #calendario_credinomina where id_status not in (1)

							select	@numcortevig = num_pago
							from	#calendario_credinomina
							where	fecha_inicio < @today
									and @today <= fecha_pago

						end -- bloque para determinar fecha inicio devengo

						--SELECT @numCorteVig = MIN(Num_pago) 
						--FROM TBL_CREDINOMINA_PTMOS 
						--WHERE Numero = @numero 
						--and Id_mov = @id_mov 
						--and Num_ptmo = @numPtmo
						--and Id_status = 1 
						--and cast(Fecha_pago as date) >= CAST(@today as date)
						--and DAY(Fecha_pago) = DAY(fecha_fin_original)

						insert #datos ( status, capital_corte, interes_ordinario_vigente, ivaIntOrdinarioVigente, 
						seguro_vida, seguro_danos,
						capital_no_devengado_fin, saldo_actual, saldo_adelanto, pago_al_corriente, capitalAmort, int_moratorio_quitas,
						int_moratorio_quitas_iva, int_ordinario_quitas, int_ordinario_quitas_iva, reserva_capital, reserva_interes
						, primer_corte_vigente)
						select  
							1 estatus,
							SUM(capital) capital_corte,
							SUM(Interes) interes_ordinario_vigente,
							SUM(IVA) ivaIntOrdinarioVigente,							
							0 AS SEGURO_VIDA,
							0 AS Seguro_danos,
							0 capital_no_devengado_fin,
							@saldo_actual as saldo_Actual,
							@saldo_adelanto saldoAdelanto,
							0 pago_al_corriente,
							SUM(vig.Total) Total
							-- para quitas
							,@int_mor_quita as int_moratorio_quitas
							,@iva_int_mor_quita as int_moratorio_quitas_iva
							,@int_ord_quita as int_ordinario_quitas
							,@iva_int_ord_quita as int_ordinario_quitas_iva
							,@reserva_capital reserva_capital,
							@reserva_interes reserva_interes
							, 0 primer_corte_vigente				 
							from TBL_CREDINOMINA_PTMOS vig	
							where vig.Numero = @numero 
							and vig.Id_mov = @id_mov
							and vig.Num_ptmo = @numPtmo
							and vig.Num_pago in (@numCorteTras, @numCorteVig)
							and vig.Id_status = 1

						if not exists (select * from #datos)
						begin
							insert into #datos
							(
								status,
								saldo_actual,
								interes_moratorio,
								interes_ord_vencido,
								interes_ordinario_vigente,
								capital_vencido,
								capital_corte,
								seguro_vida,
								seguro_danos,
								saldo_adelanto,
								pago_al_corriente,
								capital_no_devengado_fin,
								capitalAmort,
								ivaIntMoratorio,
								ivaIntOrdinarioVencido,
								ivaIntOrdinarioVigente,
								int_moratorio_quitas,
								int_moratorio_quitas_iva,
								int_ordinario_quitas,
								int_ordinario_quitas_iva,
								reserva_capital,
								reserva_interes
								,primer_corte_vigente
								)  
								SELECT 1,@saldo_actual,0,0,0,0,0,0,0,0,0,@saldo_actual,0,0,0,0,0,0,0,0,0,0, 0
						end
						
						--Vencido
						update #datos 
						set
						-- capital_corte = (@saldo_actual - cal.capital_vencido), 
						capital_vencido = cal.capital_vencido, 
						interes_ord_vencido = cal.interes_ord_vencido, 
						ivaIntOrdinarioVencido = cal.ivaIntOrdinarioVencido,
						interes_moratorio = cal.interes_moratorio, 
						ivaIntMoratorio = cal.ivaIntMoratorio
						from (select numero, id_mov, Num_ptmo,
							SUM(Capital) capital_vencido,
							SUM(Interes) interes_ord_vencido,
							SUM(IVA) ivaIntOrdinarioVencido,
							SUM(round(((case when cast(fecha_pago as date) < CAST(@today as date) 
												then DATEDIFF(dd,fecha_pago, @today) 
												else 0 
												end
										) * (@tasa_mor / 3000.00) * Capital), 2, 0)) interes_moratorio,
							SUM(ROUND((round(((case when cast(fecha_pago as date) < CAST(@today as date) 
													then DATEDIFF(dd,fecha_pago, @today) 
													else 0 
													end
												) * (@tasa_mor / 3000.00) * Capital), 2, 0)) * @tasaIVA * CAST(@aplicaIVA as int), 2, 0)) ivaIntMoratorio
							from TBL_CREDINOMINA_PTMOS
							WHERE Numero = @numero 
							and Id_mov = @id_mov 
							and Fecha_pago < CAST(@today as date)
							and Id_status = 1
							group by numero, id_mov, Num_ptmo	
						)Cal		
					end
				end
				else if @id_mov=5
						begin					
							
							SELECT @numCorteTras = MIN(Num_pago)
							FROM TBL_HIPOTECARIO_PTMOS 
							WHERE Numero = @numero 
							and Id_mov = @id_mov 
							and Num_ptmo = @numPtmo
							and Id_status = 1 
							and cast(Fecha_pago as date) >= CAST(@today as date)
							and DAY(Fecha_pago) != DAY(fecha_fin_original)

							begin -- bloque para determinar fecha inicio devengo

								select	id = row_number() over (order by contador),
										*,
										fecha_inicio = cast(null as datetime)
								into	#calendario_hipotecarios
								from	tbl_hipotecario_ptmos
								where	numero = @numero
										and id_mov = @id_mov
										and num_ptmo = @numptmo
										and id_status != 4
								order by
										contador

								update	c2
								set		fecha_inicio = c1.Fecha_pago
								from	#calendario_hipotecarios c1
										join #calendario_hipotecarios c2
											on c2.id = c1.id + 1

								update	#calendario_hipotecarios
								set		fecha_inicio = @fechaPtmo
								where	fecha_inicio is null

								delete #calendario_hipotecarios where id_status not in (1)

								select	@numcortevig = num_pago
								from	#calendario_hipotecarios
								where	fecha_inicio < @today
										and @today <= fecha_pago

							end -- bloque para determinar fecha inicio devengo

							--SELECT @numCorteVig = MIN(Num_pago)
							--FROM TBL_HIPOTECARIO_PTMOS 
							--WHERE Numero = @numero 
							--and Id_mov = @id_mov 
							--and Num_ptmo = @numPtmo
							--and Id_status = 1 
							--and cast(Fecha_pago as date) < CAST(@today as date)
							--and DAY(Fecha_pago) != DAY(fecha_fin_original)

							insert #datos ( status, capital_corte, interes_ordinario_vigente, ivaIntOrdinarioVigente, 
							seguro_vida, seguro_danos,
							capital_no_devengado_fin, saldo_actual, saldo_adelanto, pago_al_corriente, capitalAmort, int_moratorio_quitas,
							int_moratorio_quitas_iva, int_ordinario_quitas, int_ordinario_quitas_iva, reserva_capital, reserva_interes
							, primer_corte_vigente)
							select 
								1 estatus,
								SUM(capital) capital_corte,
								SUM(Interes) interes_ordinario_vigente,
								0 ivaIntOrdinarioVigente,							
								SUM(vig.Seguro_vida) AS SEGURO_VIDA,
								SUM(vig.Seguro_danos) AS Seguro_danos,
								0 capital_no_devengado_fin,
								@saldo_actual as saldo_Actual,
								@saldo_adelanto saldoAdelanto,
								0 pago_al_corriente,
								SUM(vig.Total) Total
								-- para quitas
								,@int_mor_quita as int_moratorio_quitas
								,@iva_int_mor_quita as int_moratorio_quitas_iva
								,@int_ord_quita as int_ordinario_quitas
								,@iva_int_ord_quita as int_ordinario_quitas_iva
								,@reserva_capital reserva_capital,
								@reserva_interes reserva_interes
								, 0 primer_corte_vigente				 
								from TBL_HIPOTECARIO_PTMOS vig	
								where vig.Numero = @numero 
								and vig.Id_mov = @id_mov
								and vig.Num_ptmo = @numPtmo
								and vig.Num_pago in (@numCorteTras, @numCorteVig)		
								and vig.Id_status = 1	
								
								if not exists (select * from #datos)
								begin
									insert into #datos 
									(
									status,
									saldo_actual,
									interes_moratorio,
									interes_ord_vencido,
									interes_ordinario_vigente,
									capital_vencido,
									capital_corte,
									seguro_vida,
									seguro_danos,
									saldo_adelanto,
									pago_al_corriente,
									capital_no_devengado_fin,
									capitalAmort,
									ivaIntMoratorio,
									ivaIntOrdinarioVencido,
									ivaIntOrdinarioVigente,
									int_moratorio_quitas,
									int_moratorio_quitas_iva,
									int_ordinario_quitas,
									int_ordinario_quitas_iva,
									reserva_capital,
									reserva_interes
									, primer_corte_vigente
									) 
									SELECT 1,@saldo_actual,0,0,0,0,0,0,0,0,0,@saldo_actual,0,0,0,0,0,0,0,0,0,0, 0
								end
						
								--Vencido
								update #datos 
								set 
								--capital_corte = (@saldo_actual - cal.capital_vencido), 
								capital_vencido = cal.capital_vencido, 
								interes_ord_vencido = cal.interes_ord_vencido, 
								ivaIntOrdinarioVencido = cal.ivaIntOrdinarioVencido,
								interes_moratorio = cal.interes_moratorio, 
								ivaIntMoratorio = cal.ivaIntMoratorio,
								seguro_vida = seguro_vida + coalesce(Cal.Seguro_vida_ven, 0),
								seguro_danos = seguro_danos + coalesce(Cal.Seguro_danos_ven, 0)
								from (select numero, id_mov, Num_ptmo,
									SUM(Capital) capital_vencido,
									SUM(Interes) interes_ord_vencido,
									0 ivaIntOrdinarioVencido,
									SUM(round(((case when cast(fecha_pago as date) < CAST(@today as date) 
													 then DATEDIFF(dd,fecha_pago, @today) 
													 else 0 
													 end
												) * (@tasa_mor / 3000.00) * Capital), 2, 0)) interes_moratorio,
									SUM(ROUND((round(((case when cast(fecha_pago as date) < CAST(@today as date) 
															then DATEDIFF(dd,fecha_pago, @today) 
															else 0 
															end
														) * (@tasa_mor / 3000.00) * Capital), 2, 0)) * @tasaIVA * CAST(@aplicaIVA as int), 2, 0)) ivaIntMoratorio,
									SUM(Seguro_vida) Seguro_vida_ven,
									SUM(Seguro_danos) Seguro_danos_ven
									from TBL_HIPOTECARIO_PTMOS
									WHERE Numero = @numero 
									and Id_mov = @id_mov 
									and Fecha_pago < CAST(@today as date)
									and Id_status = 1
									group by numero, id_mov, Num_ptmo
								)Cal		
							end						
				else if @id_mov = 9	
						begin
							
							SELECT @numCorteTras = MIN(Num_pago)
							FROM TBL_AUTOMOTRIZ_PTMOS 
							WHERE Numero = @numero 
							and Id_mov = @id_mov 
							and Num_ptmo = @numPtmo
							and Id_status = 1 
							and cast(Fecha_pago as date) >= CAST(@today as date)
							and DAY(Fecha_pago) != DAY(fecha_fin_original)

							begin -- bloque para determinar fecha inicio devengo

								select	id = row_number() over (order by contador),
										*,
										fecha_inicio = cast(null as datetime)
								into	#calendario_automotriz
								from	TBL_AUTOMOTRIZ_PTMOS
								where	numero = @numero
										and id_mov = @id_mov
										and num_ptmo = @numptmo
										and id_status != 4
								order by
										contador

								update	c2
								set		fecha_inicio = c1.Fecha_pago
								from	#calendario_automotriz c1
										join #calendario_automotriz c2
											on c2.id = c1.id + 1

								update	#calendario_automotriz
								set		fecha_inicio = @fechaPtmo
								where	fecha_inicio is null

								delete #calendario_automotriz where id_status not in (1)

								select	@numcortevig = num_pago
								from	#calendario_automotriz
								where	fecha_inicio < @today
										and @today <= fecha_pago

							end -- bloque para determinar fecha inicio devengo

							--SELECT @numCorteVig = MIN(Num_pago) 
							--FROM TBL_AUTOMOTRIZ_PTMOS 
							--WHERE Numero = @numero 
							--and Id_mov = @id_mov 
							--and Num_ptmo = @numPtmo
							--and Id_status = 1 
							--and cast(Fecha_pago as date) >= CAST(@today as date)
							--and DAY(Fecha_pago) = DAY(fecha_fin_original)
							
							insert #datos ( status, capital_corte, interes_ordinario_vigente, ivaIntOrdinarioVigente, 
							seguro_vida, seguro_danos,
							capital_no_devengado_fin, saldo_actual, saldo_adelanto, pago_al_corriente, capitalAmort, int_moratorio_quitas,
							int_moratorio_quitas_iva, int_ordinario_quitas, int_ordinario_quitas_iva, reserva_capital, reserva_interes
							, primer_corte_vigente)
							select 
								1 estatus,
								SUM(capital) capital_corte,
								SUM(Interes) interes_ordinario_vigente,
								SUM(IVA) ivaIntOrdinarioVigente,
								0 AS SEGURO_VIDA,
								0 AS Seguro_danos,
								0 capital_no_devengado_fin,
								@saldo_actual as saldo_Actual,
								@saldo_adelanto saldoAdelanto,
								0 pago_al_corriente,
								SUM(vig.Total) Total
								-- para quitas
								,@int_mor_quita as int_moratorio_quitas
								,@iva_int_mor_quita as int_moratorio_quitas_iva
								,@int_ord_quita as int_ordinario_quitas
								,@iva_int_ord_quita as int_ordinario_quitas_iva
								,@reserva_capital reserva_capital,
								@reserva_interes reserva_interes
								, 0 primer_corte_vigente				 
								from TBL_AUTOMOTRIZ_PTMOS vig									
								where vig.Numero = @numero 
								and vig.Id_mov = @id_mov
								and vig.Num_ptmo = @numPtmo
								and vig.Num_pago in (@numCorteTras, @numCorteVig)	
								and vig.Id_status = 1

								if not exists (select * from #datos)
								begin
									insert into #datos
									(
									status,
									saldo_actual,
									interes_moratorio,
									interes_ord_vencido,
									interes_ordinario_vigente,
									capital_vencido,
									capital_corte,
									seguro_vida,
									seguro_danos,
									saldo_adelanto,
									pago_al_corriente,
									capital_no_devengado_fin,
									capitalAmort,
									ivaIntMoratorio,
									ivaIntOrdinarioVencido,
									ivaIntOrdinarioVigente,
									int_moratorio_quitas,
									int_moratorio_quitas_iva,
									int_ordinario_quitas,
									int_ordinario_quitas_iva,
									reserva_capital,
									reserva_interes
									, primer_corte_vigente
									)  
									SELECT 1,@saldo_actual,0,0,0,0,0,0,0,0,0,@saldo_actual,0,0,0,0,0,0,0,0,0,0, 0
								end
						
								--Vencido
								update #datos 
								set 
								--capital_corte = (@saldo_actual - coalesce(cal.capital_vencido, 0)), 
								capital_vencido = cal.capital_vencido, 
								interes_ord_vencido = cal.interes_ord_vencido, 
								ivaIntOrdinarioVencido = cal.ivaIntOrdinarioVencido,
								interes_moratorio = cal.interes_moratorio, 
								ivaIntMoratorio = cal.ivaIntMoratorio
								from (select numero, id_mov, Num_ptmo,
									SUM(Capital) capital_vencido,
									SUM(Interes) interes_ord_vencido,
									SUM(IVA) ivaIntOrdinarioVencido,
									SUM(round(((case when cast(fecha_pago as date) < CAST(@today as date) 
													 then DATEDIFF(dd,fecha_pago, @today) 
													 else 0 
													 end
												) * (@tasa_mor / 3000.00) * Capital), 2, 0)) interes_moratorio,
									SUM(ROUND((round(((case when cast(fecha_pago as date) < CAST(@today as date) 
															then DATEDIFF(dd,fecha_pago, @today) 
															else 0 
															end
														) * (@tasa_mor / 3000.00) * Capital), 2, 0)) * @tasaIVA * CAST(@aplicaIVA as int), 2, 0)) ivaIntMoratorio
									from TBL_AUTOMOTRIZ_PTMOS
									WHERE Numero = @numero 
									and Id_mov = @id_mov 
									and Fecha_pago < CAST(@today as date)
									and Id_status = 1
									group by numero, id_mov, Num_ptmo
								)Cal								
						end
					else 
					begin

						SELECT @numCorteTras = MIN(Num_pago)
						FROM TBL_NIVELADOS_PTMOS 
						WHERE Numero = @numero 
						and Id_mov = @id_mov 
						and Num_ptmo = @numPtmo
						and Id_status = 1 
						and cast(Fecha_pago as date) >= CAST(@today as date)
						and DAY(Fecha_pago) != DAY(fecha_fin_original)


						begin -- bloque para determinar fecha inicio devengo

							select	id = row_number() over (order by contador),
									*,
									fecha_inicio = cast(null as datetime)
							into	#calendario_nivelados
							from	TBL_NIVELADOS_PTMOS
							where	numero = @numero
									and id_mov = @id_mov
									and num_ptmo = @numptmo
									and id_status != 4
							order by
									contador

							update	c2
							set		fecha_inicio = c1.Fecha_pago
							from	#calendario_nivelados c1
									join #calendario_nivelados c2
										on c2.id = c1.id + 1

							update	#calendario_nivelados
							set		fecha_inicio = @fechaPtmo
							where	fecha_inicio is null

							delete #calendario_nivelados where id_status not in (1)

							select	@numcortevig = num_pago
							from	#calendario_nivelados
							where	fecha_inicio < @today
									and @today <= fecha_pago

						end -- bloque para determinar fecha inicio devengo

						--SELECT @numCorteVig = MIN(Num_pago) 
						--FROM TBL_NIVELADOS_PTMOS 
						--WHERE Numero = @numero 
						--and Id_mov = @id_mov 
						--and Num_ptmo = @numPtmo
						--and Id_status = 1 
						--and cast(Fecha_pago as date) >= CAST(@today as date)
						--and DAY(Fecha_pago) = DAY(fecha_fin_original)

						insert #datos ( status, capital_corte, interes_ordinario_vigente, ivaIntOrdinarioVigente, 
						seguro_vida, seguro_danos,
						capital_no_devengado_fin, saldo_actual, saldo_adelanto, pago_al_corriente, capitalAmort, int_moratorio_quitas,
						int_moratorio_quitas_iva, int_ordinario_quitas, int_ordinario_quitas_iva, reserva_capital, reserva_interes
						, primer_corte_vigente)
						select  
							1 estatus,
							SUM(capital) capital_corte,
							SUM(Interes) interes_ordinario_vigente,
							SUM(Iva) ivaIntOrdinarioVigente,
							SUM(vig.Seguro_vida) AS SEGURO_VIDA,
							SUM(vig.Seguro_danos) AS Seguro_danos,
							0 capital_no_devengado_fin,
							@saldo_actual as saldo_Actual,
							@saldo_adelanto saldoAdelanto,
							0 pago_al_corriente,
							SUM(vig.Total) Total
							-- para quitas
							,@int_mor_quita as int_moratorio_quitas
							,@iva_int_mor_quita as int_moratorio_quitas_iva
							,@int_ord_quita as int_ordinario_quitas
							,@iva_int_ord_quita as int_ordinario_quitas_iva
							,@reserva_capital reserva_capital,
							@reserva_interes reserva_interes	
							, 0 primer_corte_vigente			 
							from TBL_NIVELADOS_PTMOS vig	
							where vig.Numero = @numero 
							and vig.Id_mov = @id_mov
							and vig.Num_ptmo = @numPtmo
							and vig.Num_pago in (@numCorteTras, @numCorteVig)
							and vig.Id_status = 1
															

							if not exists (select * from #datos)
							begin
								insert into #datos 
								(
								status,
								saldo_actual,
								interes_moratorio,
								interes_ord_vencido,
								interes_ordinario_vigente,
								capital_vencido,
								capital_corte,
								seguro_vida,
								seguro_danos,
								saldo_adelanto,
								pago_al_corriente,
								capital_no_devengado_fin,
								capitalAmort,
								ivaIntMoratorio,
								ivaIntOrdinarioVencido,
								ivaIntOrdinarioVigente,
								int_moratorio_quitas,
								int_moratorio_quitas_iva,
								int_ordinario_quitas,
								int_ordinario_quitas_iva,
								reserva_capital,
								reserva_interes
								, primer_corte_vigente
								) 
								SELECT 1,@saldo_actual,0,0,0,0,0,0,0,0,0,@saldo_actual,0,0,0,0,0,0,0,0,0,0, 0
							end
						
							--Vencido
							update #datos 
							set 
							--capital_corte = (@saldo_actual - cal.capital_vencido), 
							capital_vencido = cal.capital_vencido, 
							interes_ord_vencido = cal.interes_ord_vencido, 
							ivaIntOrdinarioVencido = cal.ivaIntOrdinarioVencido,
							interes_moratorio = cal.interes_moratorio, 
							ivaIntMoratorio = cal.ivaIntMoratorio,
							seguro_vida = seguro_vida + coalesce(Cal.Seguro_vida_ven, 0),
							seguro_danos = seguro_danos + coalesce(Cal.Seguro_danos_ven, 0)
							from (select numero, id_mov, Num_ptmo,
								SUM(Capital) capital_vencido,
								SUM(Interes) interes_ord_vencido,
								SUM(Iva) ivaIntOrdinarioVencido,
								SUM(round(((case when cast(fecha_pago as date) < CAST(@today as date) 
													then DATEDIFF(dd,fecha_pago, @today) 
													else 0 
													end
											) * (@tasa_mor / 3000.00) * Capital), 2, 0)) interes_moratorio,
								SUM(ROUND((round(((case when cast(fecha_pago as date) < CAST(@today as date) 
														then DATEDIFF(dd,fecha_pago, @today) 
														else 0 
														end
													) * (@tasa_mor / 3000.00) * Capital), 2, 0)) * @tasaIVA * CAST(@aplicaIVA as int), 2, 0)) ivaIntMoratorio,
								SUM(Seguro_vida) Seguro_vida_ven,
								SUM(Seguro_danos) Seguro_danos_ven
								from TBL_NIVELADOS_PTMOS
								WHERE Numero = @numero 
								and Id_mov = @id_mov 
								and Fecha_pago < CAST(@today as date)
								and Id_status = 1
								group by numero, id_mov, Num_ptmo
							)Cal							
						end
			end

		   UPDATE #datos
		   SET interes_moratorio = 0,
		   ivaIntMoratorio = 0
		   WHERE interes_moratorio < 0

		   UPDATE #datos
		   SET capital_no_devengado_fin = coalesce(@saldo_actual, 0) - (coalesce(capital_vencido, 0) + coalesce(capital_corte, 0))
		   

			
			if not exists(select * from #datos)
			begin
				-- o esta al corriente o no tiene un calendario de pagos
				if exists(select * from TBL_HIPOTECARIO_PTMOS where Numero=@numero and Id_status=1) OR
					exists(select * from TBL_NIVELADOS_PTMOS where Numero=@numero and Id_status=1) OR
					exists(select * from TBL_AUTOMOTRIZ_PTMOS where Numero=@numero and Id_status=1) OR
					exists(select * from TBL_CREDINOMINA_PTMOS_CAJAS where Numero=@numero and Id_status=1) OR
					exists(select * from TBL_CREDINOMINA_PTMOS where Numero=@numero and Id_status=1)
					begin
						-- esta al corriente	
						
						insert	#datos
								(
								status,
								saldo_actual,
								interes_moratorio,
								interes_ord_vencido,
								interes_ordinario_vigente,
								capital_vencido,
								capital_corte,
								seguro_vida,
								seguro_danos,
								saldo_adelanto,
								pago_al_corriente,
								capital_no_devengado_fin,
								capitalAmort,
								ivaIntMoratorio,
								ivaIntOrdinarioVencido,
								ivaIntOrdinarioVigente,
								int_moratorio_quitas,
								int_moratorio_quitas_iva,
								int_ordinario_quitas,
								int_ordinario_quitas_iva,
								reserva_capital,
								reserva_interes
								, primer_corte_vigente
								)
						SELECT 1,@saldo_actual,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, 0
						if @standalone = 1
							select * from #datos
					end
					else
						raiserror('No se encontro calendario de pagos',11,0)
			end
			else -- tiene pago pendiente
			begin
				

				declare	@_seguro_vida		money = null,
						@_seguro_da�os		money = null,
						@_int_mor			money = null,
						@_iva_int_mor		money = null,
						@_int_ord_ven		money = null,
						@_iva_int_ord_ven	money = null,
						@_int_ord_vig		money = null,
						@_iva_int_ord_vig	money = null,
						@_cap_ven			money = null,
						@_cap_vig			money = null,
						@_cap_no_dev		money = null

				select	@_seguro_vida = coalesce(seguro_vida, 0),
						@_seguro_da�os = coalesce(seguro_danos, 0),
						@_int_mor = coalesce(interes_moratorio, 0),
						@_iva_int_mor = coalesce(ivaIntMoratorio, 0),
						@_int_ord_ven = coalesce(interes_ord_vencido, 0),
						@_iva_int_ord_ven = coalesce(ivaIntOrdinarioVencido, 0),
						@_int_ord_vig = coalesce(interes_ordinario_vigente, 0),
						@_iva_int_ord_vig = coalesce(ivaIntOrdinarioVigente, 0),
						@_cap_ven = coalesce(capital_vencido, 0),
						@_cap_vig = coalesce(capital_corte, 0),
						@_cap_no_dev = coalesce(capital_no_devengado_fin, 0)
				from	#datos

				begin -- llamada para determinar tasa de gastos de cobranza, resultados otros que la tasa se descartan

					exec sp_cred_obtiene_desglose_monto_a_pagar_nivelados

						@numero = @numero,
						@id_mov = @id_mov,
						@num_ptmo = @numPtmo,
						@monto_a_pagar = null,
						@seguro_vida = @_seguro_vida,
						@seguro_da�os = @_seguro_da�os,
						@fecha = @today

					select	@tasa_gastos_cobranza = tasa_gastos_cobranza
					from	#SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR

					delete	#SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR

				end -- llamada para determinar tasa de gastos de cobranza, resultados otros que la tasa se descartan

				select	@monto_a_pagar_amortizacion =
							+ @_seguro_vida
							+ @_seguro_da�os
							+ @_int_mor
							+ @_iva_int_mor
							+ @_int_ord_ven
							+ @_iva_int_ord_ven
							+ @_int_ord_vig
							+ @_iva_int_ord_vig
							+ @_cap_ven
							+ @_cap_vig
							+ round((@_int_mor + @_int_ord_ven + @_cap_ven) * @tasa_gastos_cobranza * (1 + @tasaIVA), 2)

                exec sp_cred_obtiene_desglose_monto_a_pagar_nivelados

                    @numero = @numero,
                    @id_mov = @id_mov,
                    @num_ptmo = @numPtmo,
                    @monto_a_pagar = @monto_a_pagar_amortizacion,
                    @seguro_vida = @_seguro_vida,
                    @seguro_da�os = @_seguro_da�os,
                    @fecha = @today

				declare @pago_al_correinte money = 0

				--select @_cap_vig

				set @pago_al_correinte = 
				coalesce(@_int_mor, 0) +
				coalesce(@_iva_int_mor, 0) +
				coalesce(@_int_ord_ven, 0) +
				coalesce(@_iva_int_ord_ven, 0) +
				coalesce(@_int_ord_vig, 0) +
				coalesce(@_iva_int_ord_vig, 0) +
				coalesce(@_cap_ven, 0) +
				coalesce(@_cap_vig, 0) +
				coalesce(@_seguro_vida, 0)+ 
				coalesce(@_seguro_da�os, 0) 

				update	da
				set		gastos_cobranza = d.gastos_cobranza,
						iva_gastos_cobranza = d.iva_gastos_cobranza,
						tasa_gastos_cobranza = d.tasa_gastos_cobranza,
						pago_al_corriente = (d.gastos_cobranza + d.iva_gastos_cobranza+@pago_al_correinte)
				from	#datos da
						cross join #SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR d
				
				--Se agrega para interpretar la informacion de acuerdo a donde se realiza la consulta
				select @idTipoBloqueo = id_tipo_bloqueo	 
				from dbo.FN_COB_OBTIENE_BLOQUEOS_PTMO (@numero , @id_mov)
				 
				if @idTipoBloqueo = 3 --el prestamo se encuentra en Cobro Legal y cualquier pago es liquidacion
				begin
					update #datos
					set capital_corte = capital_corte + capital_no_devengado_fin,
					pago_al_corriente = pago_al_corriente + capital_no_devengado_fin
				end
				
				if @standalone = 1
					select * from #datos
			end
			
					
		end
	
		
		end try
		begin catch
				select 0 status ,  ERROR_MESSAGE() error_desc 
		end catch
		
	end
go
