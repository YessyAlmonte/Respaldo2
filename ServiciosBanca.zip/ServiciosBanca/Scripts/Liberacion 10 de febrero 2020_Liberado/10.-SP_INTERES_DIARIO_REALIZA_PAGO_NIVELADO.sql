USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_INTERES_DIARIO_REALIZA_PAGO_NIVELADO]    Script Date: 12/03/2020 02:39:47 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*

Autor			Mar Mej�a Murillo
UsuarioRed		memm373565
Fecha			20180122
Objetivo		Ejecuta el pago de un cr�dito nivelado
Proyecto		Inter�s diario
Ticket			______

*/

ALTER proc

	[dbo].[SP_INTERES_DIARIO_REALIZA_PAGO_NIVELADO]
	
		@numero					int,
		@id_mov					int,
		@pago_total				money,
		@numusuario				int,
		@num_poliza				int,
		@folio					int,
		@tipo_poliza			varchar(1) = null,
		@contador_provision		int = null,
		@titular				varchar(1) = null,
		@ahorro					money = null,
		@inverdinamica			money = null,
		@debito					money = null,
		@saldo_adelanto			money = null,
		@saldo_cuenta_contable	money = null,
		@cuenta_contable		varchar(14) = null,
		@efectivo				money = null,
		@gastos_cobranza		money = null,
		@id_origen				int = null,
		@id_tipo_persona		int = null,
		@fecha					datetime = null,
		@id_tipo_pago_prestamo	int = null,
		@moratorios_e_iva		money = null

as

	begin -- procedimiento

		begin try -- try principal
		
			begin -- inicio

				set nocount on

				begin -- salvar saldos en cuentas al inicio

					select	numero,
							id_mov,
							saldo_actual,
							saldo_adelanto,
							fecha,
							ultimo_abono,
							ultimo_int_ord,
							ultimo_int_mor
					into	#saldos_inicio
					from	edo_de_cuenta
					where	numero = @numero
							and id_mov in (100, 103, 112, @id_mov)

				end -- salvar saldos en cuentas al inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				declare	@tran_name varchar(32) = 'REALIZA_PAGO_NIVELADO',
						@tran_count int = @@trancount,
						@tran_scope bit = 0

				select	@moratorios_e_iva = coalesce(@moratorios_e_iva, 0)

				declare	@pago_liquidacion money,
						@message varchar(255),
						@amortizacion money,
						@disponible_neto money = @pago_total - (@gastos_cobranza + @moratorios_e_iva),
						@max_id int,
						@pago_minimo money = 0,
						@pago_excedente money = 0,
						@moratorios money = 0,
						@iva_moratorios money = 0,
						@ordinarios_vencidos money = 0,
						@iva_ordinarios_vencidos money = 0,
						@ordinarios_vigentes money = 0,
						@iva_ordinarios_vigentes money = 0,
						@capital_vencido money = 0,
						@capital_vigente money = 0,
						@capital_no_devengado money = 0,
						@sobrante money = 0,
						@gastos_cobranza_neto money = 0,
						@iva_gastos_cobranza money = 0,
						@tasa_iva float = 1e-2 * coalesce((select tasa from tasas where contador in (select max(contador) from tasas where id_mov = 111)), 16),
						@num_ptmo varchar(14),
						@liquidado bit = 0,
						@saldo_credito money = 0,
						@saldo_vencido money = 0,
						@tabla varchar(255),
						@seguro_vida money = 0,
						@seguro_da�os money = 0,
						@aplica_iva bit = 1,
						@id_esquema int = 2


				declare	@num_pago							int = 0
						,@cv_diaria							int 
						,@ccostos_cajero					varchar(15)
						,@ccostos_socio						varchar(15)
						,@cta_compensacion_origen			varchar(50)
						,@cta_compensacion_destino			varchar(50)
						,@concepto_compensacion_origen		varchar(150)
						,@concepto_compensacion_destino		varchar(150)
						,@int_mor_ficha_saldado				money
						,@int_ord_ficha_saldado				money
						,@capital_vigente_ficha_saldado		money
						,@capital_vencido_ficha_saldado		money
						,@fecha_traspaso_cv					datetime
						,@fecha_ini							datetime
						,@fecha_fin							datetime
						,@int_ordinario_amortizacion		money = 0
						,@dias_del_periodo					int = 0
						,@int_ord_dia						money
						,@int_mor_dia						money
						,@dias_devengados					int
						,@dias_despues_de_traspaso_cv1		int
						,@int_ord_orden_saldado				money = 0
						,@int_mor_orden_saldado				money = 0
						,@int_ord_ingresos					money
						,@int_ord_provision					money
						,@int_mor_ingresos					money
						,@int_mor_provision					money
						--,@son_ingresos_ord_de_orden			bit = cast(0 as bit)
						--,@son_ingresos_mor_de_orden			bit = cast(0 as bit)
						,@capital_adelanto					money
						,@es_adelanto						bit = cast(0 as bit)
						,@cta_prosa_corresponsalias			varchar(14) = ''
						,@desc_prosa_corresponsalias		varchar(250) = ''
						,@ccostos_medpa						varchar (10) = 'MEDPA'
						,@tot_depositos						money = 0
						,@cta_adelanto						varchar (50)
						,@Numero_Fin_LACP					int = 0
						,@total_moratorio_adeudado_orden	money = 0
						,@total_moratorio_adeudado_balance	money = 0
						,@total_ordinario_adeudado_orden	money = 0
						,@total_ordinario_adeudado_balance	money = 0
						,@int_mor_balance_saldado			money = 0
						,@int_ord_balance_saldado			money = 0
						,@iva_int_mor_balance_saldado		money = 0
						,@iva_int_ord_balance_saldado		money = 0
						,@int_mor_ficha_restante			money = 0
						,@int_ord_ficha_restante			money = 0
						,@diferencia_redondeo_				money = 0
						,@dias_faltantes					int = 0
						,@tipo_cta_ingresos_ordinarios		int = 19 --19 cuando es por ordinarios de orden / 6 cuando paga anticipadamente sus int ordinarios en la amort. vigente en curso
						--Se agregan por gastos de cobranza
						,@ptmoConCobroLegal					bit = 0
						,@ptmoConCondonacionGastosCob		bit = 0
						,@int_ord_edo_cta					money
						,@int_mor_edo_cta					money
						,@fecha_ini_calendario_saldado		datetime
						,@fecha_fin_calendario_saldado		datetime
						
				select	@fecha = coalesce(@fecha, getdate())

				select	@cta_adelanto =	num_cuenta  
				from	tbl_cuentas_contables_interes_diario 
				where	tipo_cuenta = 9
						and estatus_catera = 0

				select	@num_ptmo = num_ptmo,
						@id_esquema = id_esquema,
						@int_ord_edo_cta = (cast(Int_Ord as decimal) / cast(3000 as decimal)), --Int_Ord
						@int_mor_edo_cta = (cast(Int_Mor as decimal) / cast(3000 as decimal)) --Int_Mor
				from	edo_de_cuenta
				where	numero = @numero
						and id_mov = @id_mov
						
				create table
					#calendario
						(
						id					int identity(1, 1) primary key clustered not null,
						contador			int not null,
						numero				int not null,
						id_mov				int not null,
						num_ptmo			varchar(14) not null,
						planx				varchar(2) not null,
						numero_fin			int null,
						numero_fin_lacp		int null,
						plazo				int null,
						tasa_ord			float null,
						tasa_mor			float null,
						id_amortizacion		int null,
						id_renovado			int null,
						reestructura		varchar(1) null,
						cv_diaria			bit null,
						fecha_traspaso_CV	datetime null,
						aplica_iva			bit null,
						fecha_ptmo			datetime not null,
						id_esquema			int not null,
						monto_inicial		money not null,
						saldo_actual		money not null,
						num_pago			int not null,
						fecha_inicio_corte	datetime null,
						fecha_fin_corte		datetime not null,
						fecha_fin_original	datetime null,
						id_status			int not null,
						capital				money not null,
						interes				money not null,
						iva					money not null,
						seguro_vida			money default 0 not null,
						seguro_da�os		money default 0 not null,
						total				money not null,
						devengado			bit default 0 not null,
						fecha_pago_cajas	datetime null,
						numusuario			int null,
						folio				int null,
						total_acum			money default 0 not null,
						total_saldado		money default 0 not null,
						total_disponible	money default 0 not null,
						actualizado			int default 0 not null,
						tabla				varchar(255) not null
						)

				select	id_persona,
						numero,
						nombre_s,
						apellido_paterno,
						apellido_materno,
						s.id_de_sucursal,
						s.ccostos
				into	#persona
				from	persona p
							join sucursales s
								on s.id_de_sucursal = p.id_de_sucursal
				where	numero = @numero
						and id_tipo_persona = 1

				select	identity (int, 1, 1) contador,
						id_persona,
						activo,
						numero,
						nombre_s,
						apellido_paterno,
						apellido_materno,
						total_movs,
						total_ficha,
						id_tipomov,
						cuenta,
						concepto,
						fecha_mov,
						monto,
						id_mov,
						num_poliza,
						tipo_poliza,
						folio,
						id_tipo_persona,
						num_cheq,
						desc1,
						desc2,
						planx,
						desc3,
						fecha_dpf_final,
						num_dpf,
						tasa,
						interes,
						dias,
						debe_haber,
						numusuario,
						numero_fin,
						plazo,
						interes_ord,
						interes_mor,
						contador_provision,
						ccostos,
						nombre_beneficiario,
						parentesco_beneficiario,
						porcentaje_beneficiario,
						nombre_beneficiario2,
						parentesco_beneficiario2,
						porcentaje_beneficiario2,
						numero_fin_lacp,
						id_esquema,
						titular,
						num_ptmo,
						id_amortizacion,
						id_renovado,
						reestructura,
						id_origen,
						id_tipo_pago_prestamo
				into	#captura
				from	captura
				where	1 = 0

				select	numero,
						id_mov,
						num_ptmo,
						planx,
						numero_fin,
						numero_fin_lacp,
						plazo,
						tasa_ord = int_ord,
						tasa_mor = int_mor,
						id_amortizacion,
						id_renovado,
						reestructura = reestructurado,
						cv_diaria,
						Fecha_Traspaso_CV,
						aplica_IVA
				into	#datos_credito
				from	edo_de_cuenta
				where	numero = @numero
						and id_mov = @id_mov

				select	@cv_diaria			=	cv_diaria,
						@fecha_traspaso_cv	=	fecha_traspaso_cv,
						@aplica_iva			=	aplica_iva,
						@numero_fin_lacp	=	numero_fin_lacp
				from	#datos_credito

				select	top 1
						@seguro_vida = seguro_vida,
						@seguro_da�os = seguro_da�os
				from	#calendario
				--where	@id_tipo_pago_prestamo not in (1, 2, 3)

				create table
					#distribucion_saldado
						(
						disp_neto				money null,
						moratorios_e_iva		money null,
						moratorios				money null,
						iva_moratorios			money null,
						ord_ven					money null,
						iva_ord_ven				money null,
						cap_ven					money null,
						ord_vig					money null,
						iva_ord_vig				money null,
						cap_vig					money null,
						cap_no_dev				money null,
						sobrante				money null,
						excedente				money null,
						gastos_cobranza_neto	money null,
						iva_gastos_cobranza		money null,
						gastos_cobranza			money null,
						)

				create table
					#sp_cred_genera_calendario_pagos
						(
						id				int primary key clustered not null,
						num_ptmo		varchar(14) null,
						fecha_ptmo		datetime null,
						tasa_ord_mes	decimal(15, 14) null,
						fecha			datetime null,
						saldo_actual	money null,
						capital			money null,
						interes			money null,
						seguro_vida		money null,
						seguro_da�os	money null,
						iva				money null,
						total			money null
						)

				create table
					#sp_interes_diario_obtiene_calendario_nivelado_actualizado
						(
						status			int null,
						error_message	varchar(255) null,
						error_line		varchar(255) null,
						error_severity	varchar(255) null,
						error_procedure varchar(255) null,
						)

				create table
					#actualiza_edo_de_cuenta_haberes
						(
						numero			int null,
						id_mov			int null,
						saldo_anterior	money null,
						diferencia		money null,
						saldo_posterior	money null,
						fecha			datetime null,
						)

					CREATE TABLE #tbl_interes_diario_captura_lacp_aux(
						Id_persona	int null,
						Activo	char(1) null,
						Numero	int null,
						Nombre_s	varchar(40) null,
						Apellido_paterno	varchar(40) null,
						Apellido_materno	varchar(40) null,
						Total_movs	smallint null,
						Total_ficha	float null,
						Id_Tipomov	smallint null,
						Cuenta	varchar(14) null,
						Concepto	varchar(80) null,
						Fecha_mov	datetime null,
						Monto	float null,
						Neto	float null,
						ID_mov	int null,
						Banco	varchar(20) null,
						clave_Local	char(1) null,
						Linea	char(1) null,
						Num_Poliza	int null,
						Tipo_poliza	varchar(1) null,
						Folio	int null,
						Id_Tipo_persona	smallint null,
						Num_cheq	bigint null,
						Desc1	varchar(80) null,
						Desc2	varchar(80) null,
						planx	varchar(1) null,
						Aval1_socio	char(10) null,
						Aval1_numero	int null,
						Aval2_socio	char(10) null,
						Aval2_numero	int null,
						Desc3	varchar(200) null,
						Desc4	varchar(80) null,
						FECHA_DPF_final	datetime null,
						NUM_DPF	int null,
						TASA	float null,
						INTERES	float null,
						DIAS	smallint null,
						DEBE_HABER	char(1) null,
						NUMUSUARIO	smallint null,
						PROCESADO	char(10) null,
						FECHA_ALTA	datetime null,
						numero_Fin	smallint null,
						numero_fin2	varchar(200) null,
						Plazo	smallint null,
						Interes_ord	float null,
						Interes_mor	float null,
						Monto2	float null,
						Plazo2	smallint null,
						Interes_ord2	float null,
						Interes_mor2	float null,
						Aval1_avalados	smallint null,
						Aval2_avalados	smallint null,
						Fec_inicio	datetime null,
						Fec_prog	datetime null,
						Contador_provision	int null,
						Ccostos	varchar(50) null,
						NOMBRE_BENEFICIARIO	varchar(100) null,
						PARENTESCO_BENEFICIARIO	varchar(20) null,
						PORCENTAJE_BENEFICIARIO	int null,
						NOMBRE_BENEFICIARIO2	varchar(100) null,
						PARENTESCO_BENEFICIARIO2	varchar(20) null,
						PORCENTAJE_BENEFICIARIO2	int null,
						Id_Sol	varchar(14) null,
						Numero_Fin_LACP	smallint null,
						Reestructura	char(1) null,
						Id_Motivo_Reestructura	smallint null,
						Id_Esquema	smallint null,
						Id_Convenio	int null,
						Id_Amortizacion	int null,
						Ent_Federativa	char(5) null,
						Cve_Municipio	char(5) null,
						Cve_Localidad	char(5) null,
						Identificador	char(10) null,
						Transferencia	char(10) null,
						Fecha_Pago	datetime null,
						Bimestre	char(14) null,
						Referencia	char(45) null,
						Cve_Archivo	int null,
						Impreso	char(1) null,
						Folio_Impresion	char(16) null,
						Documentacion	char(19) null,
						dpf_en_garantia	varchar(50) null,
						Titular	char(1) null,
						Id_Nomina	int null,
						Id_Esquema_Nomina	smallint null,
						Id_Leyenda	int null,
						Num_ptmo	varchar(14) null,
						Id_Renovado	int null,
						Ahorro_Base	float null,
						Tasa_Pasiva	float null,
						Id_Fondeador	int null,
						Numero_Fondeo	int null,
						id_origen int null,
						id_tipo_pago_prestamo int null
					)

				begin -- valores por defecto

					select	@tipo_poliza = coalesce(@tipo_poliza, 'M'),
							@ahorro = coalesce(@ahorro, 0),
							@inverdinamica = coalesce(@inverdinamica, 0),
							@debito = coalesce(@debito, 0),
							@saldo_adelanto = coalesce(@saldo_adelanto, 0),
                            @saldo_cuenta_contable = coalesce(@saldo_cuenta_contable, 0),
							@efectivo = coalesce(@efectivo, 0),
							@gastos_cobranza = coalesce(@gastos_cobranza, 0),
							@id_origen = coalesce(@id_origen, 1),
							@id_tipo_persona = coalesce(@id_tipo_persona, 1),
							@fecha = coalesce(@fecha, getdate())

				end -- valores por defecto

				begin -- tabla de resultados

					declare @standalone bit = 1, @sql nvarchar(4000) = 'delete #procedimiento_pago_credito'

					begin try -- revisar si existe tabla de resultados

						exec (@sql)

						select @standalone = 0

					end try -- revisar si existe tabla de resultados

					begin catch -- si no existe tabla de resultados

						create table
							#procedimiento_pago_credito
								(
								status			int null,
								error_procedure	varchar(255) null,
								error_line		varchar(255) null,
								error_severity	varchar(255) null,
								error_message	varchar(255) null,
								)

					end catch -- si no existe tabla de resultados

				end -- tabla de resultados

				set nocount on

				-------------- { -- comentar bloque si ya todo est� en tbl_nivelados_ptmos

				/*

										create table
							#calendario
								(
								id					int identity(1, 1) primary key clustered not null,
								contador			int not null,
								numero				int not null,
								id_mov				int not null,
								num_ptmo			varchar(14) not null,
								planx				varchar(2) not null,
								numero_fin			int null,
								numero_fin_lacp		int null,
								plazo				int null,
								tasa_ord			float null,
								tasa_mor			float null,
								id_amortizacion		int null,
								id_renovado			int null,
								reestructura		varchar(1) null,
								cv_diaria			bit null,
								fecha_ptmo			datetime not null,
								id_esquema			int not null,
								monto_inicial		money not null,
								saldo_actual		money not null,
								num_pago			int not null,
								fecha_inicio_corte	datetime null,
								fecha_fin_corte		datetime not null,
								id_status			int not null,
								capital				money not null,
								interes				money not null,
								iva					money not null,
								seguro_vida			money default 0 not null,
								seguro_da�os		money default 0 not null,
								total				money not null,
								devengado			bit default 0 not null,
								fecha_pago_cajas	datetime null,
								numusuario			int null,
								folio				int null,
								total_acum			money default 0 not null,
								total_saldado		money default 0 not null,
								total_disponible	money default 0 not null,
								actualizado			int default 0 not null,
								tabla				varchar(255) not null,
								)

				*/


				begin -- importar calendario fuera de tbl_nivelados_ptmos

					insert	#calendario
							(
							contador,
							numero,
							id_mov,
							num_ptmo,
							planx,
							numero_fin,
							numero_fin_lacp,
							plazo,
							tasa_ord,
							tasa_mor,
							id_amortizacion,
							id_renovado,
							reestructura,
							cv_diaria,
							fecha_traspaso_CV,
							aplica_iva,
							fecha_ptmo,
							id_esquema,
							monto_inicial,
							saldo_actual,
							num_pago,
							fecha_inicio_corte,
							fecha_fin_corte,
							fecha_fin_original,
							id_status,
							capital,
							interes,
							iva,
							seguro_vida,
							seguro_da�os,
							total,
							fecha_pago_cajas,
							numusuario,
							folio,
							tabla
							)
					select	
							p.contador,
							dc.*,
							p.fecha_ptmo,
							p.id_esquema,
							p.monto_inicial,
							p.saldo_actual,
							p.num_pago,
							fecha_inicio_corte = cast(null as datetime),
							fecha_fin_corte = p.fecha_pago,
							fecha_fin = p.fecha_fin_original,
							p.id_status,
							p.capital,
							p.interes,
							p.iva,
							seguro_vida = 0,
							seguro_da�os = 0,
							p.total,
							p.fecha_pago_cajas,
							p.numusuario,
							p.folio,
							tabla = 'tbl_automotriz_ptmos'
					from	#datos_credito dc
							join tbl_automotriz_ptmos p
								on p.numero = dc.numero
								and p.id_mov = dc.id_mov
								and p.num_ptmo = dc.num_ptmo
								and p.id_status in (1, 2, 3)

					union

					select	
							p.contador,
							dc.*,
							p.fecha_ptmo,
							p.id_esquema,
							p.monto_inicial,
							p.saldo_actual,
							p.num_pago,
							fecha_inicio_corte = cast(null as datetime),
							fecha_fin_corte = p.fecha_pago,
							fecha_fin_original = p.fecha_fin_original,
							p.id_status,
							p.capital,
							p.interes,
							cast(0 as money) iva,
							p.seguro_vida,
							p.seguro_danos,
							p.total,
							p.fecha_pago_cajas,
							p.numusuario,
							p.folio,
							tabla = 'tbl_hipotecario_ptmos'
					from	#datos_credito dc
							join tbl_hipotecario_ptmos p
								on p.numero = dc.numero
								and p.id_mov = dc.id_mov
								and p.num_ptmo = dc.num_ptmo
								and p.Id_status in (1, 2, 3)

					union

					select	
							p.contador,
							dc.*,
							p.fecha_ptmo,
							p.id_esquema,
							p.monto_inicial,
							p.saldo_actual,
							p.num_pago,
							fecha_inicio_corte = cast(null as datetime),
							fecha_fin_corte = p.fecha_pago,
							fecha_fin_original = p.fecha_fin_original,
							p.id_status,
							p.capital,
							p.interes,
							p.iva,
							seguro_vida = 0,
							seguro_da�os = 0,
							p.total,
							p.fecha_pago_cajas,
							p.numusuario,
							p.folio,
							tabla = 'tbl_credinomina_ptmos_cajas'
					from	#datos_credito dc
							join tbl_credinomina_ptmos_cajas p
								on p.numero = dc.numero
								and p.id_mov = dc.id_mov
								and p.num_ptmo = dc.num_ptmo
								and p.Id_status in (1, 2, 3, 4)

					union

					select	
							p.contador,
							dc.*,
							p.fecha_ptmo,
							p.id_esquema,
							p.monto_inicial,
							p.saldo_actual,
							p.num_pago,
							fecha_inicio_corte = cast(null as datetime),
							fecha_fin_corte = p.fecha_pago,
							fecha_fin_original = p.fecha_fin_original,
							p.id_status,
							p.capital,
							p.interes,
							p.iva,
							seguro_vida = 0,
							seguro_da�os = 0,
							p.total,
							p.fecha_dispersion,
							p.numusuario,
							folio = 0,
							tabla = 'tbl_credinomina_ptmos'
					from	#datos_credito dc
							join tbl_credinomina_ptmos p
								on p.numero = dc.numero
								and p.id_mov = dc.id_mov
								and p.num_ptmo = dc.num_ptmo
								and p.Id_status in (1, 2, 3, 4)

					order by
							num_pago


				end -- importar calendario fuera de tbl_nivelados_ptmos

--									exec tempdb.dbo.sp_help '#calendario'


				if not exists (select 1 from #calendario)

				-------------- } -- comentar bloque si ya todo est� en tbl_nivelados_ptmos

					begin -- importar calendario desde tbl_nivelados_ptmos

						insert	#calendario
								(
								contador,
								numero,
								id_mov,
								num_ptmo,
								planx,
								numero_fin,
								numero_fin_lacp,
								plazo,
								tasa_ord,
								tasa_mor,
								id_amortizacion,
								id_renovado,
								reestructura,
								cv_diaria,
								fecha_traspaso_CV,
								aplica_iva,
								fecha_ptmo,
								id_esquema,
								monto_inicial,
								saldo_actual,
								num_pago,
								fecha_inicio_corte,
								fecha_fin_corte,
								fecha_fin_original,
								id_status,
								capital,
								interes,
								iva,
								seguro_vida,
								seguro_da�os,
								total,
								fecha_pago_cajas,
								numusuario,
								folio,
								tabla
								)
						select	
								p.contador,
								dc.*,
								p.fecha_ptmo,
								p.id_esquema,
								p.monto_inicial,
								p.saldo_actual,
								p.num_pago,
								fecha_inicio_corte = cast(null as datetime),
								fecha_fin_corte = p.fecha_pago,
								fecha_fin_original = p.fecha_fin_original,
								p.id_status,
								p.capital,
								p.interes,
								p.iva,
								p.seguro_vida,
								p.seguro_danos,
								p.total,
								p.fecha_pago_cajas,
								p.numusuario,
								p.folio,
								tabla = 'tbl_nivelados_ptmos'
						from	#datos_credito dc
								join tbl_nivelados_ptmos p
									on p.numero = dc.numero
									and p.id_mov = dc.id_mov
									and p.num_ptmo = dc.num_ptmo
									and p.id_status in (1, 2, 3)

						order by
								num_pago

					end -- importar calendario desde tbl_nivelados_ptmos

				begin -- actualizaciones iniciales del calendario

					update	#calendario
					set		total = capital + interes + iva + seguro_vida + seguro_da�os

					update	c2
					set		fecha_inicio_corte = c1.fecha_fin_original
					from	#calendario c1
							join #calendario c2
								on c2.id = c1.id + 1

					update	#calendario
					set		fecha_inicio_corte = cast(fecha_ptmo as date)
					where	num_pago = 1


--					select '' debug24, * from #calendario

					update	#calendario
					set		devengado = 1
					--where	fecha_inicio_corte !> @fecha
					where	fecha_inicio_corte < cast(@fecha as date)

					select	@pago_liquidacion = sum(total)
					from	#calendario
					where	id_status = 1

					select	@pago_minimo = sum(total)
					from	#calendario
					where	id_status = 1
							and devengado = 1

					select	@pago_minimo = coalesce(@pago_minimo, 0)

					declare @max_ int = (select max(id) from #calendario)

					select @max_ = coalesce(@max_, 0)

					;

					with acumulado as

						(

						select	id,
								total = case
									when id_status = 1
										then total
									else 0
								end,
								total_acum =
									case
										when id_status = 1
											then total
										else 0
									end
						from	#calendario
						where	id = 1

						union all

						select	id = a.id + 1,
								total = case
									when id_status = 1
										then c.total
									else 0
								end,
								total_acum = a.total_acum +
									case
										when id_status = 1
											then c.total
										else 0
									end
						from	acumulado a
								join #calendario c
									on a.id + 1 = c.id

						where	a.id < @max_

						)

					update	c
					set		c.total_acum = a.total_acum
					from	acumulado a
							join #calendario c
								on c.id = a.id
					option	(maxrecursion 1000)

				end -- actualizaciones iniciales del calendario

			end -- inicio
			
			begin -- validaciones
			
				begin -- validaciones de par�metros

					if @titular is null

						begin -- si @titular no se indic�

							select @message = 'Debe indicar el titular'

							raiserror (@message, 11, 0)

						end -- si @titular no se indic�

				if @pago_total !> 0 and coalesce(@id_tipo_pago_prestamo, 0) != 3

					begin -- si no se especific� un monto de pago y no es orden de adelanto

						select @message = 'El monto del pago debe ser mayor a 0.00'

						raiserror (@message, 11, 0)

					end -- si no se especific� un monto de pago y no es orden de adelanto
			
				if @pago_total + @ahorro + @inverdinamica + @debito + @saldo_adelanto + @saldo_cuenta_contable + @efectivo != 0

					begin -- si no cuadran los flujos de dinero

						select @message = 'Los flujos de efectivo y cuentas de haberes [' + cast(abs(@ahorro + @inverdinamica + @debito + @saldo_adelanto + @saldo_cuenta_contable + @efectivo) as varchar) + '] no se pueden cuadrar con el monto pagado [' + cast(@pago_total as varchar) + ']'

						raiserror (@message, 11, 0)

					end -- si no cuadran los flujos de dinero
				
				end -- validaciones de par�metros

				if not exists (select 1 from #calendario)

					begin -- si no se encontr� el calendario

						select @message = 'No se encontr� el calendario de pagos correspondiente al socio [' + cast(@numero as varchar) + '] y n�mero de pr�stamo [' + coalesce((select num_ptmo from #datos_credito), 'null') + '] indicados.'

						raiserror (@message, 11, 0)

					end -- si no se encontr� el calendario
				
			end -- validaciones

			begin -- preparaci�n

				--select	@id_esquema = id_esquema
				--from	edo_de_cuenta
				--where	numero = @numero
				--		and id_mov = @id_mov

				select	@max_id = max(id) from #calendario where total_acum !> @disponible_neto

				--select @disponible_neto, @max_id

				update	#calendario
				set		total_saldado = total
				where	id !> @max_id
						and id_status = 1

				update	#calendario
				set		total_disponible = @disponible_neto -
							(
							select	sum(total_saldado)
							from	#calendario
							where	id !> @max_id
							)
				where	id = @max_id

				select	@pago_excedente = sum(total_saldado + total_disponible)
				from	#calendario
				where	devengado = 0
						and id_status = 1

						--select '' debug24, * from #calendario

				select @pago_excedente = coalesce(@pago_excedente, 0)

				select	@pago_excedente = @pago_excedente + sum(total_disponible)
				from	#calendario
				where	devengado = 1

				select @aplica_iva = aplica_IVA from #datos_credito

				--select @tasa_iva * @aplica_iva

				select	@moratorios = round(@moratorios_e_iva / (1 + @tasa_iva * @aplica_iva), 2),
						@iva_moratorios = @moratorios_e_iva - @moratorios

				select	@ordinarios_vencidos = sum(interes),
						@iva_ordinarios_vencidos = sum(iva),
						@capital_vencido = sum(capital)
				from	#calendario
				where	id_status = 1
						and devengado = 1
						and fecha_fin_corte < cast(@fecha as date)
						and id !> @max_id

				--select @max_id = @max_id + 2 -------------

--				select	'' debug26, @max_id max_id, * from #calendario

				select	@ordinarios_vencidos = coalesce(@ordinarios_vencidos, 0),
						@iva_ordinarios_vencidos = coalesce(@iva_ordinarios_vencidos, 0),
						@capital_vencido = coalesce(@capital_vencido, 0)

				select	@ordinarios_vigentes = sum(interes),
						@iva_ordinarios_vigentes = sum(iva),
						@capital_vigente = sum(capital)
				from	#calendario
				where	id_status = 1
						and devengado = 1
						and fecha_fin_corte !< cast(@fecha as date)
						and id !> @max_id

				select	@capital_no_devengado = sum(capital)
				from	#calendario
				where	id_status = 1
						and devengado = 0
						--and fecha_fin_corte !< @fecha
						and id !> @max_id

				select	@ordinarios_vigentes = coalesce(@ordinarios_vigentes, 0),
						@iva_ordinarios_vigentes = coalesce(@iva_ordinarios_vigentes, 0),
						@capital_vigente = coalesce(@capital_vigente, 0),
						@capital_no_devengado = coalesce(@capital_no_devengado, 0)

				if @gastos_cobranza > 0

					begin

						select	@gastos_cobranza_neto = round(@gastos_cobranza / (1 + @tasa_iva * 1e-0), 2),
								@iva_gastos_cobranza = @gastos_cobranza - @gastos_cobranza_neto

						select	@gastos_cobranza_neto = coalesce(@gastos_cobranza_neto, 0),
								@iva_gastos_cobranza = coalesce(@iva_gastos_cobranza, 0)

					end
				---Se agrega para liquidacion de creditos con seguros adeudados de mas de 1 amortizacion
				-- Se revisa si el ptmo en cuestion esta en cobro legal ya que este caso es para liquidar 
				if exists (select numero from TBL_COB_BLOQUEOS_PRESTAMO
							where numero = @numero
							and id_mov = @id_mov
							and num_ptmo = @num_ptmo
							and id_Bloqueo_Ptmo = 3 --bloqueo en cobro legal
							)
					set @ptmoConCobroLegal = 1

				-- Se revisa si el ptmo en cuestion esta en condonacion de gastos de cobranza ya que este caso es para liquidar 
				if exists (select numero from TBL_COBRANZA_CONDONACION_GASTOS_COBRANZA
							where numero = @numero
							and id_mov = @id_mov
							and num_ptmo = @num_ptmo
							and id_status = 1 --estatus Por procesar
							)
					set @ptmoConCondonacionGastosCob = 1
				-- Si se encuentra en este caso se suman todos los adeudados al momento ya que es liquidacion
				if (@ptmoConCobroLegal = 1) or
				   (@ptmoConCondonacionGastosCob = 1)
				begin
					select	@seguro_vida = coalesce(SUM(seguro_vida), 0),
							@seguro_da�os = coalesce(SUM(seguro_da�os), 0)
					from	#calendario
					where devengado = 1
					and id_status = 1
				end
				else
				begin
				----------------------------------------------------------------------------------------

					--select	top 1
					--		@seguro_vida = seguro_vida,
					--		@seguro_da�os = seguro_da�os
					--from	#calendario

					if @id_origen in (1, 5)

						select	top 1
								@seguro_vida = seguro_vida,
								@seguro_da�os = seguro_da�os
						from	#calendario

					else if @id_origen in (2, 3, 4)

						select	@seguro_vida = sum(seguro_vida),
								@seguro_da�os = sum(seguro_da�os)
						from	#calendario
						where	id_status = 1 and devengado = 1 and total_saldado != 0

				end

				--select '' debug27, @seguro_vida, @seguro_da�os, * from #calendario order by contador

				--select * from tbl_hipotecario_ptmos where numero = @numero order by contador


				select @sobrante = @disponible_neto - (@ordinarios_vencidos + @iva_ordinarios_vencidos + @ordinarios_vigentes + @iva_ordinarios_vigentes + @capital_vencido + @capital_vigente + @capital_no_devengado)

				insert	#distribucion_saldado
						(
						disp_neto,
						moratorios_e_iva,
						moratorios,
						iva_moratorios,
						ord_ven,
						iva_ord_ven,
						cap_ven,
						ord_vig,
						iva_ord_vig,
						cap_vig,
						cap_no_dev,
						sobrante,
						excedente,
						gastos_cobranza_neto,
						iva_gastos_cobranza,
						gastos_cobranza
						)

				select	disp_neto = @disponible_neto,
						moratorios_e_iva = @moratorios_e_iva,
						moratorios = @moratorios,
						iva_moratorios = @iva_moratorios,
						ord_ven = @ordinarios_vencidos,
						iva_ord_ven = @iva_ordinarios_vencidos,
						cap_ven = @capital_vencido,
						ord_vig = @ordinarios_vigentes,
						iva_ord_vig = @iva_ordinarios_vigentes,
						cap_vig = @capital_vigente,
						cap_no_dev = @capital_no_devengado,
						sobrante = @sobrante,
						excedente = @pago_excedente,
						gastos_cobranza_neto = @gastos_cobranza_neto,
						iva_gastos_cobranza = @iva_gastos_cobranza,
						gastos_cobranza = @gastos_cobranza

				begin -- preparar captura

					--if (@seguro_vida + @seguro_da�os > 0) and @id_tipo_pago_prestamo is null or @id_tipo_pago_prestamo not in (1, 2, 3)
					if (@seguro_vida + @seguro_da�os > 0)
						and (
							(@id_tipo_pago_prestamo is null or @id_tipo_pago_prestamo not in (1, 2, 3))
							or (@capital_vencido + @capital_vigente > 0 and @pago_excedente > 0)
							)

						begin -- seguros de vida y da�os

							if @seguro_vida > 0

								insert	#captura
										(
										id_persona,
										activo,
										numero,
										nombre_s,
										apellido_paterno,
										apellido_materno,
										total_movs,
										total_ficha,
										id_tipomov,
										cuenta,
										concepto,
										fecha_mov,
										monto,
										id_mov,
										num_poliza,
										tipo_poliza,
										folio,
										id_tipo_persona,
										num_cheq,
										desc1,
										desc2,
										planx,
										desc3,
										fecha_dpf_final,
										num_dpf,
										tasa,
										interes,
										dias,
										debe_haber,
										numusuario,
										numero_fin,
										plazo,
										interes_ord,
										interes_mor,
										contador_provision,
										ccostos,
										nombre_beneficiario,
										parentesco_beneficiario,
										porcentaje_beneficiario,
										nombre_beneficiario2,
										parentesco_beneficiario2,
										porcentaje_beneficiario2,
										numero_fin_lacp,
										id_esquema,
										titular,
										num_ptmo,
										id_amortizacion,
										id_renovado,
										reestructura,
										id_origen
										)

								select	id_persona,
										'T',
										p.numero,
										nombre_s,
										apellido_paterno,
										apellido_materno,
										total_movs = 0,
										total_ficha = 0,
										tm.id_tipomov,
										cuenta = cc.num_cuenta,
										concepto = tm.descripcion,
										fecha_mov = @fecha,
										monto = @seguro_vida,
										dc.id_mov,
										num_poliza = @num_poliza,
										tipo_poliza = @tipo_poliza,
										folio = @folio,
										id_tipo_persona = 1,
										num_cheq = 0,
										desc1 = 0,
										desc2 = 0,
										dc.planx,
										desc3 = 0,
										fecha_dpf_final = cast(@fecha as date),
										num_dpf = 0,
										tasa = 0,
										interes = 0,
										dias = 0,
										debe_haber = 'H',
										numusuario = @numusuario,
										dc.numero_fin,
										dc.plazo,
										interes_ord = dc.tasa_ord,
										interes_mor = dc.tasa_mor,
										contador_provision = @contador_provision,
										p.ccostos,
										nombre_beneficiario = '',
										parentesco_beneficiario = '',
										porcentaje_beneficiario = 0,
										nombre_beneficiario2 = '',
										parentesco_beneficiario2 = '',
										porcentaje_beneficiario2 = 0,
										numero_fin_lacp = dc.numero_fin_lacp,
										id_esquema = @id_esquema,
										titular = @titular,
										num_ptmo,
										id_amortizacion,
										id_renovado,
										reestructura,
										id_origen = @id_origen
								from	#persona p
										cross join #datos_credito dc
										join tipo_mov tm
											on tm.id_mov = dc.id_mov
											and tm.id_tipomov like '9_'
										join cuentas_contables cc
											on cc.concepto like '%vida%cred%'
											and cc.num_cuenta like '232011%'

							if @seguro_da�os > 0

								insert	#captura
										(
										id_persona,
										activo,
										numero,
										nombre_s,
										apellido_paterno,
										apellido_materno,
										total_movs,
										total_ficha,
										id_tipomov,
										cuenta,
										concepto,
										fecha_mov,
										monto,
										id_mov,
										num_poliza,
										tipo_poliza,
										folio,
										id_tipo_persona,
										num_cheq,
										desc1,
										desc2,
										planx,
										desc3,
										fecha_dpf_final,
										num_dpf,
										tasa,
										interes,
										dias,
										debe_haber,
										numusuario,
										numero_fin,
										plazo,
										interes_ord,
										interes_mor,
										contador_provision,
										ccostos,
										nombre_beneficiario,
										parentesco_beneficiario,
										porcentaje_beneficiario,
										nombre_beneficiario2,
										parentesco_beneficiario2,
										porcentaje_beneficiario2,
										numero_fin_lacp,
										id_esquema,
										titular,
										num_ptmo,
										id_amortizacion,
										id_renovado,
										reestructura,
										id_origen
										)

								select	id_persona,
										'T',
										p.numero,
										nombre_s,
										apellido_paterno,
										apellido_materno,
										total_movs = 0,
										total_ficha = 0,
										tm.id_tipomov,
										cuenta = cc.num_cuenta,
										concepto = tm.descripcion,
										fecha_mov = @fecha,
										monto = @seguro_da�os,
										dc.id_mov,
										num_poliza = @num_poliza,
										tipo_poliza = @tipo_poliza,
										folio = @folio,
										id_tipo_persona = 1,
										num_cheq = 0,
										desc1 = 0,
										desc2 = 0,
										dc.planx,
										desc3 = 0,
										fecha_dpf_final = cast(@fecha as date),
										num_dpf = 0,
										tasa = 0,
										interes = 0,
										dias = 0,
										debe_haber = 'H',
										numusuario = @numusuario,
										dc.numero_fin,
										dc.plazo,
										interes_ord = dc.tasa_ord,
										interes_mor = dc.tasa_mor,
										contador_provision = @contador_provision,
										p.ccostos,
										nombre_beneficiario = '',
										parentesco_beneficiario = '',
										porcentaje_beneficiario = 0,
										nombre_beneficiario2 = '',
										parentesco_beneficiario2 = '',
										porcentaje_beneficiario2 = 0,
										numero_fin_lacp = dc.numero_fin_lacp,
										id_esquema = @id_esquema,
										titular = @titular,
										num_ptmo,
										id_amortizacion,
										id_renovado,
										reestructura,
										id_origen = @id_origen
								from	#persona p
										cross join #datos_credito dc
										join tipo_mov tm
											on tm.id_mov = dc.id_mov
											and tm.id_tipomov like '8_'
										join cuentas_contables cc
											on cc.concepto like '%da�os%cred%'
											and cc.num_cuenta like '232011%'

						end -- seguros de vida y da�os


					if @moratorios + @iva_moratorios > 0

						begin -- moratorios

							insert	#captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	id_persona,
									'T',
									p.numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion,
									fecha_mov = @fecha,
									monto = @moratorios,
									dc.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									dc.planx,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'H',
									numusuario = @numusuario,
									dc.numero_fin,
									dc.plazo,
									interes_ord = dc.tasa_ord,
									interes_mor = dc.tasa_mor,
									contador_provision = @contador_provision,
									p.ccostos,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = dc.numero_fin_lacp,
									id_esquema = @id_esquema,
									titular = @titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen = @id_origen
							from	#persona p
									cross join #datos_credito dc
									join tipo_mov tm
										on tm.id_mov = dc.id_mov
										and tm.id_tipomov like '7_'
									join cuentas_contables cc
										on cc.numero_fin_lacp = dc.numero_fin_lacp
										and cc.estatus_cartera = dc.cv_diaria
										and cc.clasificacion_cuenta = 3
										and cc.tipo_reconocimiento = 1

							if @iva_moratorios > 0

								insert	#captura
										(
										id_persona,
										activo,
										numero,
										nombre_s,
										apellido_paterno,
										apellido_materno,
										total_movs,
										total_ficha,
										id_tipomov,
										cuenta,
										concepto,
										fecha_mov,
										monto,
										id_mov,
										num_poliza,
										tipo_poliza,
										folio,
										id_tipo_persona,
										num_cheq,
										desc1,
										desc2,
										planx,
										desc3,
										fecha_dpf_final,
										num_dpf,
										tasa,
										interes,
										dias,
										debe_haber,
										numusuario,
										numero_fin,
										plazo,
										interes_ord,
										interes_mor,
										contador_provision,
										ccostos,
										nombre_beneficiario,
										parentesco_beneficiario,
										porcentaje_beneficiario,
										nombre_beneficiario2,
										parentesco_beneficiario2,
										porcentaje_beneficiario2,
										numero_fin_lacp,
										id_esquema,
										titular,
										num_ptmo,
										id_amortizacion,
										id_renovado,
										reestructura,
										id_origen
										)

								select	id_persona,
										'T',
										p.numero,
										nombre_s,
										apellido_paterno,
										apellido_materno,
										total_movs = 0,
										total_ficha = 0,
										tm.id_tipomov,
										cuenta = cc.num_cuenta,
										concepto = tm.descripcion,
										fecha_mov = @fecha,
										monto = @iva_moratorios,
										dc.id_mov,
										num_poliza = @num_poliza,
										tipo_poliza = @tipo_poliza,
										folio = @folio,
										id_tipo_persona = 1,
										num_cheq = 0,
										desc1 = 0,
										desc2 = 0,
										dc.planx,
										desc3 = 0,
										fecha_dpf_final = cast(@fecha as date),
										num_dpf = 0,
										tasa = 0,
										interes = 0,
										dias = 0,
										debe_haber = 'H',
										numusuario = @numusuario,
										dc.numero_fin,
										dc.plazo,
										interes_ord = dc.tasa_ord,
										interes_mor = dc.tasa_mor,
										contador_provision = @contador_provision,
										p.ccostos,
										nombre_beneficiario = '',
										parentesco_beneficiario = '',
										porcentaje_beneficiario = 0,
										nombre_beneficiario2 = '',
										parentesco_beneficiario2 = '',
										porcentaje_beneficiario2 = 0,
										numero_fin_lacp = dc.numero_fin_lacp,
										id_esquema = @id_esquema,
										titular = @titular,
										num_ptmo,
										id_amortizacion,
										id_renovado,
										reestructura,
										id_origen = @id_origen
								from	#persona p
										cross join #datos_credito dc
										join tipo_mov tm
											on tm.id_mov = dc.id_mov
											and tm.id_tipomov like '81_'
										join cuentas_contables cc
											on cc.Concepto like '%i.v.a.%trasladado%'

						end -- moratorios

					if @ordinarios_vencidos + @iva_ordinarios_vencidos > 0

						begin -- ordinarios vencidos

							insert	#captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	id_persona,
									'T',
									p.numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion,
									fecha_mov = @fecha,
									monto = @ordinarios_vencidos,
									dc.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									dc.planx,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'H',
									numusuario = @numusuario,
									dc.numero_fin,
									dc.plazo,
									interes_ord = dc.tasa_ord,
									interes_mor = dc.tasa_mor,
									contador_provision = @contador_provision,
									p.ccostos,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = dc.numero_fin_lacp,
									id_esquema = @id_esquema,
									titular = @titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen = @id_origen
							from	#persona p
									cross join #datos_credito dc
									join tipo_mov tm
										on tm.id_mov = dc.id_mov
										and tm.id_tipomov like '6_'
									join cuentas_contables cc
										on cc.numero_fin_lacp = dc.numero_fin_lacp
										and cc.estatus_cartera = dc.cv_diaria
										and cc.clasificacion_cuenta = 2
										and cc.tipo_reconocimiento = 1

							if @iva_ordinarios_vencidos > 0

								insert	#captura
										(
										id_persona,
										activo,
										numero,
										nombre_s,
										apellido_paterno,
										apellido_materno,
										total_movs,
										total_ficha,
										id_tipomov,
										cuenta,
										concepto,
										fecha_mov,
										monto,
										id_mov,
										num_poliza,
										tipo_poliza,
										folio,
										id_tipo_persona,
										num_cheq,
										desc1,
										desc2,
										planx,
										desc3,
										fecha_dpf_final,
										num_dpf,
										tasa,
										interes,
										dias,
										debe_haber,
										numusuario,
										numero_fin,
										plazo,
										interes_ord,
										interes_mor,
										contador_provision,
										ccostos,
										nombre_beneficiario,
										parentesco_beneficiario,
										porcentaje_beneficiario,
										nombre_beneficiario2,
										parentesco_beneficiario2,
										porcentaje_beneficiario2,
										numero_fin_lacp,
										id_esquema,
										titular,
										num_ptmo,
										id_amortizacion,
										id_renovado,
										reestructura,
										id_origen
										)

								select	id_persona,
										'T',
										p.numero,
										nombre_s,
										apellido_paterno,
										apellido_materno,
										total_movs = 0,
										total_ficha = 0,
										tm.id_tipomov,
										cuenta = cc.num_cuenta,
										concepto = tm.descripcion,
										fecha_mov = @fecha,
										monto = @iva_ordinarios_vencidos,
										dc.id_mov,
										num_poliza = @num_poliza,
										tipo_poliza = @tipo_poliza,
										folio = @folio,
										id_tipo_persona = 1,
										num_cheq = 0,
										desc1 = 0,
										desc2 = 0,
										dc.planx,
										desc3 = 0,
										fecha_dpf_final = cast(@fecha as date),
										num_dpf = 0,
										tasa = 0,
										interes = 0,
										dias = 0,
										debe_haber = 'H',
										numusuario = @numusuario,
										dc.numero_fin,
										dc.plazo,
										interes_ord = dc.tasa_ord,
										interes_mor = dc.tasa_mor,
										contador_provision = @contador_provision,
										p.ccostos,
										nombre_beneficiario = '',
										parentesco_beneficiario = '',
										porcentaje_beneficiario = 0,
										nombre_beneficiario2 = '',
										parentesco_beneficiario2 = '',
										porcentaje_beneficiario2 = 0,
										numero_fin_lacp = dc.numero_fin_lacp,
										id_esquema = @id_esquema,
										titular = @titular,
										num_ptmo,
										id_amortizacion,
										id_renovado,
										reestructura,
										id_origen = @id_origen
								from	#persona p
										cross join #datos_credito dc
										join tipo_mov tm
											on tm.id_mov = dc.id_mov
											and tm.id_tipomov like '80_'
										join cuentas_contables cc
											on cc.Concepto like '%i.v.a.%trasladado%'

						end -- ordinarios vencidos

					if @ordinarios_vigentes + @iva_ordinarios_vigentes > 0

						begin -- ordinarios vigentes

							insert	#captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	id_persona,
									'T',
									p.numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion,
									fecha_mov = @fecha,
									monto = @ordinarios_vigentes,
									dc.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									dc.planx,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'H',
									numusuario = @numusuario,
									dc.numero_fin,
									dc.plazo,
									interes_ord = dc.tasa_ord,
									interes_mor = dc.tasa_mor,
									contador_provision = @contador_provision,
									p.ccostos,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = dc.numero_fin_lacp,
									id_esquema = @id_esquema,
									titular = @titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen = @id_origen
							from	#persona p
									cross join #datos_credito dc
									join tipo_mov tm
										on tm.id_mov = dc.id_mov
										and tm.id_tipomov like '6_'
									join cuentas_contables cc
										on cc.numero_fin_lacp = dc.numero_fin_lacp
										and cc.estatus_cartera = dc.cv_diaria
										and cc.clasificacion_cuenta = 2
										and cc.tipo_reconocimiento = 1

							if @iva_ordinarios_vigentes > 0

								insert	#captura
										(
										id_persona,
										activo,
										numero,
										nombre_s,
										apellido_paterno,
										apellido_materno,
										total_movs,
										total_ficha,
										id_tipomov,
										cuenta,
										concepto,
										fecha_mov,
										monto,
										id_mov,
										num_poliza,
										tipo_poliza,
										folio,
										id_tipo_persona,
										num_cheq,
										desc1,
										desc2,
										planx,
										desc3,
										fecha_dpf_final,
										num_dpf,
										tasa,
										interes,
										dias,
										debe_haber,
										numusuario,
										numero_fin,
										plazo,
										interes_ord,
										interes_mor,
										contador_provision,
										ccostos,
										nombre_beneficiario,
										parentesco_beneficiario,
										porcentaje_beneficiario,
										nombre_beneficiario2,
										parentesco_beneficiario2,
										porcentaje_beneficiario2,
										numero_fin_lacp,
										id_esquema,
										titular,
										num_ptmo,
										id_amortizacion,
										id_renovado,
										reestructura,
										id_origen
										)

								select	id_persona,
										'T',
										p.numero,
										nombre_s,
										apellido_paterno,
										apellido_materno,
										total_movs = 0,
										total_ficha = 0,
										tm.id_tipomov,
										cuenta = cc.num_cuenta,
										concepto = tm.descripcion,
										fecha_mov = @fecha,
										monto = @iva_ordinarios_vigentes,
										dc.id_mov,
										num_poliza = @num_poliza,
										tipo_poliza = @tipo_poliza,
										folio = @folio,
										id_tipo_persona = 1,
										num_cheq = 0,
										desc1 = 0,
										desc2 = 0,
										dc.planx,
										desc3 = 0,
										fecha_dpf_final = cast(@fecha as date),
										num_dpf = 0,
										tasa = 0,
										interes = 0,
										dias = 0,
										debe_haber = 'H',
										numusuario = @numusuario,
										dc.numero_fin,
										dc.plazo,
										interes_ord = dc.tasa_ord,
										interes_mor = dc.tasa_mor,
										contador_provision = @contador_provision,
										p.ccostos,
										nombre_beneficiario = '',
										parentesco_beneficiario = '',
										porcentaje_beneficiario = 0,
										nombre_beneficiario2 = '',
										parentesco_beneficiario2 = '',
										porcentaje_beneficiario2 = 0,
										numero_fin_lacp = dc.numero_fin_lacp,
										id_esquema = @id_esquema,
										titular = @titular,
										num_ptmo,
										id_amortizacion,
										id_renovado,
										reestructura,
										id_origen = @id_origen
								from	#persona p
										cross join #datos_credito dc
										join tipo_mov tm
											on tm.id_mov = dc.id_mov
											and tm.id_tipomov like '80_'
										join cuentas_contables cc
											on cc.Concepto like '%i.v.a.%trasladado%'

						end -- ordinarios vigentes

					if @capital_vencido > 0

						begin -- capital vencido

							insert	#captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	id_persona,
									'T',
									p.numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion,
									fecha_mov = @fecha,
									monto = @capital_vencido,
									dc.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									dc.planx,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'H',
									numusuario = @numusuario,
									dc.numero_fin,
									dc.plazo,
									interes_ord = dc.tasa_ord,
									interes_mor = dc.tasa_mor,
									contador_provision = @contador_provision,
									p.ccostos,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = dc.numero_fin_lacp,
									id_esquema = @id_esquema,
									titular = @titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen = @id_origen
							from	#persona p
									cross join #datos_credito dc
									join tipo_mov tm
										on tm.id_mov = dc.id_mov
										and tm.id_tipomov like '13_'
									join cuentas_contables cc
										on cc.numero_fin_lacp = dc.numero_fin_lacp
										and cc.estatus_cartera = dc.cv_diaria
										and cc.clasificacion_cuenta = 1
										and cc.tipo_reconocimiento = 1

						end -- capital vencido

					if @capital_vigente > 0

						begin -- capital vigente

							insert	#captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	id_persona,
									'T',
									p.numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion,
									fecha_mov = @fecha,
									monto = @capital_vigente,
									dc.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									dc.planx,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'H',
									numusuario = @numusuario,
									dc.numero_fin,
									dc.plazo,
									interes_ord = dc.tasa_ord,
									interes_mor = dc.tasa_mor,
									contador_provision = @contador_provision,
									p.ccostos,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = dc.numero_fin_lacp,
									id_esquema = @id_esquema,
									titular = @titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen = @id_origen
							from	#persona p
									cross join #datos_credito dc
									join tipo_mov tm
										on tm.id_mov = dc.id_mov
										and tm.id_tipomov like '3_'
									join cuentas_contables cc
										on cc.numero_fin_lacp = dc.numero_fin_lacp
										and cc.estatus_cartera = dc.cv_diaria
										and cc.clasificacion_cuenta = 1
										and cc.tipo_reconocimiento = 1

						end -- capital vigente

					-- entra en este caso si no afecta el pago completo

--					select @pago_excedente db06

					if @pago_excedente > 0.01 and exists (select * from #calendario where devengado = 1 and id_status = 1) and coalesce(@id_tipo_pago_prestamo, 0) = 0

						begin

							select @message = 'Hubo un error al tratar de afectar un pago pendiente'

							raiserror (@message, 11, 0)

						end

					if @pago_excedente > 0

						begin -- capital no devengado

							insert	#captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen,
									id_tipo_pago_prestamo
									)

							select	id_persona,
									'T',
									p.numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion + case when @id_tipo_pago_prestamo in (1, 2) then ' (Anticipo ' + case when @id_tipo_pago_prestamo = 1 then 'con reducci�n de amortizaci�n' else 'con reducci�n de plazo' end + ')' else ' (Adelanto)' end,
									fecha_mov = @fecha,
									monto = @pago_excedente,
									dc.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									dc.planx,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'H',
									numusuario = @numusuario,
									dc.numero_fin,
									dc.plazo,
									interes_ord = dc.tasa_ord,
									interes_mor = dc.tasa_mor,
									contador_provision = @contador_provision,
									p.ccostos,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = dc.numero_fin_lacp,
									id_esquema = @id_esquema,
									titular = @titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen = @id_origen,
									id_tipo_pago_prestamo = @id_tipo_pago_prestamo
							from	#persona p
									cross join #datos_credito dc
									join tipo_mov tm
										on tm.id_mov = dc.id_mov
										and tm.id_tipomov like '3_'
									join cuentas_contables cc
										on cc.numero_fin_lacp = dc.numero_fin_lacp
										and cc.estatus_cartera = dc.cv_diaria
										and cc.clasificacion_cuenta = 1
										and cc.tipo_reconocimiento = 1

						end -- capital no devengado

					--if @seguro_vida + @seguro_da�os > 0

					--	begin -- seguros de vida y da�os

					--		if @seguro_vida > 0

					--			insert	#captura
					--					(
					--					id_persona,
					--					activo,
					--					numero,
					--					nombre_s,
					--					apellido_paterno,
					--					apellido_materno,
					--					total_movs,
					--					total_ficha,
					--					id_tipomov,
					--					cuenta,
					--					concepto,
					--					fecha_mov,
					--					monto,
					--					id_mov,
					--					num_poliza,
					--					tipo_poliza,
					--					folio,
					--					id_tipo_persona,
					--					num_cheq,
					--					desc1,
					--					desc2,
					--					planx,
					--					desc3,
					--					fecha_dpf_final,
					--					num_dpf,
					--					tasa,
					--					interes,
					--					dias,
					--					debe_haber,
					--					numusuario,
					--					numero_fin,
					--					plazo,
					--					interes_ord,
					--					interes_mor,
					--					contador_provision,
					--					ccostos,
					--					nombre_beneficiario,
					--					parentesco_beneficiario,
					--					porcentaje_beneficiario,
					--					nombre_beneficiario2,
					--					parentesco_beneficiario2,
					--					porcentaje_beneficiario2,
					--					numero_fin_lacp,
					--					id_esquema,
					--					titular,
					--					num_ptmo,
					--					id_amortizacion,
					--					id_renovado,
					--					reestructura,
					--					id_origen
					--					)

					--			select	id_persona,
					--					'T',
					--					p.numero,
					--					nombre_s,
					--					apellido_paterno,
					--					apellido_materno,
					--					total_movs = 0,
					--					total_ficha = 0,
					--					tm.id_tipomov,
					--					cuenta = cc.num_cuenta,
					--					concepto = tm.descripcion,
					--					fecha_mov = @fecha,
					--					monto = @seguro_vida,
					--					dc.id_mov,
					--					num_poliza = @num_poliza,
					--					tipo_poliza = @tipo_poliza,
					--					folio = @folio,
					--					id_tipo_persona = 1,
					--					num_cheq = 0,
					--					desc1 = 0,
					--					desc2 = 0,
					--					dc.planx,
					--					desc3 = 0,
					--					fecha_dpf_final = cast(@fecha as date),
					--					num_dpf = 0,
					--					tasa = 0,
					--					interes = 0,
					--					dias = 0,
					--					debe_haber = 'H',
					--					numusuario = @numusuario,
					--					dc.numero_fin,
					--					dc.plazo,
					--					interes_ord = dc.tasa_ord,
					--					interes_mor = dc.tasa_mor,
					--					contador_provision = @contador_provision,
					--					p.ccostos,
					--					nombre_beneficiario = '',
					--					parentesco_beneficiario = '',
					--					porcentaje_beneficiario = 0,
					--					nombre_beneficiario2 = '',
					--					parentesco_beneficiario2 = '',
					--					porcentaje_beneficiario2 = 0,
					--					numero_fin_lacp = dc.numero_fin_lacp,
					--					id_esquema = @id_esquema,
					--					titular = @titular,
					--					num_ptmo,
					--					id_amortizacion,
					--					id_renovado,
					--					reestructura,
					--					id_origen = @id_origen
					--			from	#persona p
					--					cross join #datos_credito dc
					--					join tipo_mov tm
					--						on tm.id_mov = dc.id_mov
					--						and tm.id_tipomov like '9_'
					--					join cuentas_contables cc
					--						on cc.concepto like '%vida%cred%'
					--						and cc.num_cuenta like '232011%'

					--		if @seguro_da�os > 0

					--			insert	#captura
					--					(
					--					id_persona,
					--					activo,
					--					numero,
					--					nombre_s,
					--					apellido_paterno,
					--					apellido_materno,
					--					total_movs,
					--					total_ficha,
					--					id_tipomov,
					--					cuenta,
					--					concepto,
					--					fecha_mov,
					--					monto,
					--					id_mov,
					--					num_poliza,
					--					tipo_poliza,
					--					folio,
					--					id_tipo_persona,
					--					num_cheq,
					--					desc1,
					--					desc2,
					--					planx,
					--					desc3,
					--					fecha_dpf_final,
					--					num_dpf,
					--					tasa,
					--					interes,
					--					dias,
					--					debe_haber,
					--					numusuario,
					--					numero_fin,
					--					plazo,
					--					interes_ord,
					--					interes_mor,
					--					contador_provision,
					--					ccostos,
					--					nombre_beneficiario,
					--					parentesco_beneficiario,
					--					porcentaje_beneficiario,
					--					nombre_beneficiario2,
					--					parentesco_beneficiario2,
					--					porcentaje_beneficiario2,
					--					numero_fin_lacp,
					--					id_esquema,
					--					titular,
					--					num_ptmo,
					--					id_amortizacion,
					--					id_renovado,
					--					reestructura,
					--					id_origen
					--					)

					--			select	id_persona,
					--					'T',
					--					p.numero,
					--					nombre_s,
					--					apellido_paterno,
					--					apellido_materno,
					--					total_movs = 0,
					--					total_ficha = 0,
					--					tm.id_tipomov,
					--					cuenta = cc.num_cuenta,
					--					concepto = tm.descripcion,
					--					fecha_mov = @fecha,
					--					monto = @seguro_da�os,
					--					dc.id_mov,
					--					num_poliza = @num_poliza,
					--					tipo_poliza = @tipo_poliza,
					--					folio = @folio,
					--					id_tipo_persona = 1,
					--					num_cheq = 0,
					--					desc1 = 0,
					--					desc2 = 0,
					--					dc.planx,
					--					desc3 = 0,
					--					fecha_dpf_final = cast(@fecha as date),
					--					num_dpf = 0,
					--					tasa = 0,
					--					interes = 0,
					--					dias = 0,
					--					debe_haber = 'H',
					--					numusuario = @numusuario,
					--					dc.numero_fin,
					--					dc.plazo,
					--					interes_ord = dc.tasa_ord,
					--					interes_mor = dc.tasa_mor,
					--					contador_provision = @contador_provision,
					--					p.ccostos,
					--					nombre_beneficiario = '',
					--					parentesco_beneficiario = '',
					--					porcentaje_beneficiario = 0,
					--					nombre_beneficiario2 = '',
					--					parentesco_beneficiario2 = '',
					--					porcentaje_beneficiario2 = 0,
					--					numero_fin_lacp = dc.numero_fin_lacp,
					--					id_esquema = @id_esquema,
					--					titular = @titular,
					--					num_ptmo,
					--					id_amortizacion,
					--					id_renovado,
					--					reestructura,
					--					id_origen = @id_origen
					--			from	#persona p
					--					cross join #datos_credito dc
					--					join tipo_mov tm
					--						on tm.id_mov = dc.id_mov
					--						and tm.id_tipomov like '8_'
					--					join cuentas_contables cc
					--						on cc.concepto like '%da�os%cred%'
					--						and cc.num_cuenta like '232011%'

					--	end -- seguros de vida y da�os


					if @gastos_cobranza > 0

						begin -- gastos de cobranza

							insert	#captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	id_persona,
									'T',
									p.numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion,
									fecha_mov = @fecha,
									monto = @gastos_cobranza_neto,
									dc.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									dc.planx,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'H',
									numusuario = @numusuario,
									dc.numero_fin,
									dc.plazo,
									interes_ord = dc.tasa_ord,
									interes_mor = dc.tasa_mor,
									contador_provision = @contador_provision,
									p.ccostos,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = dc.numero_fin_lacp,
									id_esquema = @id_esquema,
									titular = @titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen = @id_origen
							from	#persona p
									cross join #datos_credito dc
									join tipo_mov tm
										on tm.id_mov = dc.id_mov
										and tm.id_tipomov like '20_'
									join cuentas_contables cc
										on cc.Concepto like 'por%gastos%cobranza'
										and cc.Num_cuenta like '405%'

							insert	#captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	id_persona,
									'T',
									p.numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion,
									fecha_mov = @fecha,
									monto = @iva_gastos_cobranza,
									dc.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									dc.planx,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'H',
									numusuario = @numusuario,
									dc.numero_fin,
									dc.plazo,
									interes_ord = dc.tasa_ord,
									interes_mor = dc.tasa_mor,
									contador_provision = @contador_provision,
									p.ccostos,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = dc.numero_fin_lacp,
									id_esquema = @id_esquema,
									titular = @titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen = @id_origen
							from	#persona p
									cross join #datos_credito dc
									join tipo_mov tm
										on tm.id_mov = dc.id_mov
										and tm.id_tipomov like '21_'
									join cuentas_contables cc
										on cc.Concepto like '%i.v.a.%trasladado%'

						end -- gastos de cobranza


					if @ahorro != 0

						begin -- ahorro

							insert	#captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	id_persona,
									'T',
									p.numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion,
									fecha_mov = @fecha,
									monto = abs(@ahorro),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									dc.planx,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber =
										case
											when @ahorro < 0 then 'D'
										else
											'H'
										end,
									numusuario = @numusuario,
									dc.numero_fin,
									dc.plazo,
									interes_ord = dc.tasa_ord,
									interes_mor = dc.tasa_mor,
									contador_provision = @contador_provision,
									p.ccostos,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = dc.numero_fin_lacp,
									id_esquema = @id_esquema,
									titular = @titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen = @id_origen
							from	#persona p
									cross join #datos_credito dc
									join tipo_mov tm
										on tm.id_mov = 100
										and tm.id_tipomov like
											case
												when @ahorro < 0 then 310
											else
												10
											end
									join cuentas_contables cc
										on cc.Concepto like '%ahorro%socios'
										and cc.Num_cuenta like '212%'

						end -- ahorro

					if @inverdinamica != 0

						begin -- inverdin�mica

							insert	#captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	id_persona,
									'T',
									p.numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion,
									fecha_mov = @fecha,
									monto = abs(@inverdinamica),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									dc.planx,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber =
										case
											when @inverdinamica < 0 then 'D'
										else
											'H'
										end,
									numusuario = @numusuario,
									dc.numero_fin,
									dc.plazo,
									interes_ord = dc.tasa_ord,
									interes_mor = dc.tasa_mor,
									contador_provision = @contador_provision,
									p.ccostos,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = dc.numero_fin_lacp,
									id_esquema = @id_esquema,
									titular = @titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen = @id_origen
							from	#persona p
									cross join #datos_credito dc
									join tipo_mov tm
										on tm.id_mov = 103
										and tm.id_tipomov like
											case
												when @inverdinamica < 0 then 350
											else
												50
											end
									join cuentas_contables cc
										on cc.Concepto like '%vista'
										and cc.Num_cuenta like '211%'

						end -- inverdin�mica

					if @debito != 0

						begin -- d�bito

							insert	#captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	id_persona,
									'T',
									p.numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion,
									fecha_mov = @fecha,
									monto = abs(@debito),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									dc.planx,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber =
										case
											when @debito < 0 then 'D'
										else
											'H'
										end,
									numusuario = @numusuario,
									dc.numero_fin,
									dc.plazo,
									interes_ord = dc.tasa_ord,
									interes_mor = dc.tasa_mor,
									contador_provision = @contador_provision,
									p.ccostos,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = dc.numero_fin_lacp,
									id_esquema = @id_esquema,
									titular = @titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen = @id_origen
							from	#persona p
									cross join #datos_credito dc
									join tipo_mov tm
										on tm.id_mov = 112
										and tm.id_tipomov like
											case
												when @debito < 0 then 1001
											else
												1002
											end
									join cuentas_contables cc
										on cc.Concepto like 'debito%'
										and cc.Num_cuenta like '216%'

						end -- d�bito

					if @saldo_adelanto != 0

						begin -- saldo de adelanto

							insert	#captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen,
									id_tipo_pago_prestamo
									)

							select	id_persona,
									'T',
									p.numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion,
									fecha_mov = @fecha,
									monto = abs(@saldo_adelanto),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									dc.planx,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber =
										case
											when @saldo_adelanto < 0 then 'D'
										else
											'H'
										end,
									numusuario = @numusuario,
									dc.numero_fin,
									dc.plazo,
									interes_ord = dc.tasa_ord,
									interes_mor = dc.tasa_mor,
									contador_provision = @contador_provision,
									p.ccostos,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = dc.numero_fin_lacp,
									id_esquema = @id_esquema,
									titular = @titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen = @id_origen,
									id_tipo_pago_prestamo = @id_tipo_pago_prestamo
							from	#persona p
									cross join #datos_credito dc
									join tipo_mov tm
										on tm.id_mov = dc.id_mov
										and tm.id_tipomov like
											case
												when @saldo_adelanto < 0 then '15' + cast(tm.id_mov as varchar)
												when @saldo_adelanto > 0 then '14' + cast(tm.id_mov as varchar)
											end
									join cuentas_contables cc
										on cc.numero_fin_lacp = dc.numero_fin_lacp
										and cc.estatus_cartera = dc.cv_diaria
										and cc.clasificacion_cuenta = 2
										and cc.tipo_reconocimiento = 1

						end -- saldo de adelanto

					if @saldo_cuenta_contable != 0

						begin -- cuentas contables

							insert	#captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	id_persona,
									activo = 'T',
									p.numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = @cuenta_contable,
									concepto = tm.descripcion + '  ' + @cuenta_contable + '  ' + cc2.concepto,
									fecha_mov = @fecha,
									monto = abs(@saldo_cuenta_contable),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									dc.planx,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber =
										case
											when @saldo_cuenta_contable < 0 then 'D'
										else
											'H'
										end,
									numusuario = @numusuario,
									dc.numero_fin,
									dc.plazo,
									dc.tasa_ord,
									dc.tasa_mor,
									contador_provision = @contador_provision,
									p.ccostos,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = @numero_fin_lacp,
									id_esquema = @id_esquema,
									titular = @titular,
									num_ptmo = @num_ptmo,
									dc.id_amortizacion,
									dc.id_renovado,
									dc.reestructura,
									id_origen = @id_origen
							from	#persona p
									join tipo_mov tm
										on tm.id_mov = 108
										and tm.id_tipomov like
											case
												when @saldo_cuenta_contable < 0 then 702
											else
												701
											end
									join cuentas_contables cc
										on cc.Concepto like '%ahorro%socios'
										and cc.Num_cuenta like '212%'
									join cuentas_contables cc2
										on cc2.num_cuenta = @cuenta_contable
									cross join #datos_credito dc

						end -- cuentas contables



--					select '' dbg05, * from #captura

					begin -- cajas

						if not exists (select * from #captura)

							begin

								select @message = 'Hubo un error con la aplicaci�n del pago, trate de realizar la operaci�n nuevamente'

								raiserror (@message, 11, 0)

							end

						insert	#captura
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	id_persona,
								'T',
								p.numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs = 0,
								total_ficha = 0,
								id_tipomov = 961,
								cuenta = cc.num_cuenta,
								concepto = 'Cajas',
								fecha_mov = @fecha,
								monto = abs(@efectivo),
								id_mov = null,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @folio,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								dc.planx,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber =
									case
										when @efectivo < 0 then 'D'
									else
										'H'
									end,
								numusuario = @numusuario,
								dc.numero_fin,
								dc.plazo,
								interes_ord = dc.tasa_ord,
								interes_mor = dc.tasa_mor,
								contador_provision = @contador_provision,
								p.ccostos,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = dc.numero_fin_lacp,
								id_esquema = @id_esquema,
								titular = @titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen = @id_origen
						from	#persona p
								cross join #datos_credito dc
								join cuentas_contables cc
									on concepto like 'caja'
									and num_cuenta like '111%'

					end -- cajas

					begin -- actualizar totales

						update	c
						set		c.total_movs = _.count_,
								c.total_ficha = abs(@efectivo)
						from	(
								select	count(1) count_
								from	#captura
								) _
								cross join #captura c

					end -- actualizar totales

				end -- preparar captura

				begin -- preparar calendario

					exec SP_INTERES_DIARIO_OBTIENE_CALENDARIO_NIVELADO_ACTUALIZADO @numusuario, @folio, @id_tipo_pago_prestamo, @seguro_vida, @seguro_da�os, @aplica_IVA, @fecha

				end -- preparar calendario
			
			end -- preparaci�n

			begin -- validaciones de la preparaci�n

				if @id_tipo_pago_prestamo in (1, 2, 3) and not exists (select * from #calendario where devengado = 0)

					begin -- validar que haya amortizaciones por devengar para anticipar o adelantar

						select @message = 'Todas las amortizaciones ya se han devengado, no es posible anticipar o adelantar'

						raiserror (@message, 11, 0)

					end -- validar que haya amortizaciones por devengar para anticipar o adelantar


				--select '' debug19, @pago_excedente excedente, @sobrante sobrante

				if (@pago_excedente !> 0 and @sobrante !> 0) and @id_tipo_pago_prestamo in (1, 2) and exists (select * from #calendario where devengado = 0)
				or exists (select * from #calendario where devengado = 1 and actualizado = 2)

					begin -- validar que haya un excedente para anticipar

						select @message = 'Se indic� un anticipo, pero no hay un excedente para tratar'

						raiserror (@message, 11, 0)

					end -- validar que haya un excedente para anticipar

					

				if (@disponible_neto !> 0 and coalesce(@id_tipo_pago_prestamo, 0) != 3)

					begin -- disponible neto no suficiente

						select @message = 'El disponible neto [' + cast(@disponible_neto as varchar) + '] no es suficiente'

						raiserror (@message, 11, 0)

					end -- disponible neto no suficiente

				if @pago_total > 0 and @id_tipo_pago_prestamo = 3

					begin -- se envi� monto a pago directo del cr�dito en un adelanto

						select @message = 'No se puede afectar un monto [' + cast(@pago_total as varchar) + '] directamente en el pr�stamo si es un adelanto. Todo se debe enviar a cuenta de adelantos'

						raiserror (@message, 11, 0)

					end -- se envi� monto a pago directo del cr�dito en un adelanto

				if @disponible_neto > @pago_liquidacion

					begin -- disponible neto excede del pago de liquidaci�n

						select @message = 'El disponible neto [' + cast(@disponible_neto as varchar) +'] a pagar excede del pago de liquidaci�n [' + cast(@pago_liquidacion as varchar) + ']'

						raiserror (@message, 11, 0)

					end -- disponible neto excede del pago de liquidaci�n

				if (@pago_minimo + @moratorios_e_iva > 0 and @id_tipo_pago_prestamo = 3)

					begin -- para proceder con un adelanto, es necesario estar al corriente

						select @message = 'Para proceder con un adelanto, es necesario pagar el saldo pendiente para estar al corriente [' + cast(@pago_minimo + @moratorios_e_iva as varchar) + '].'

						raiserror (@message, 11, 0)

					end -- para proceder con un adelanto, es necesario estar al corriente

				if (@gastos_cobranza > 0 and @id_tipo_pago_prestamo = 3)

					begin -- no es v�lido un adelanto si hay gastos de cobranza

						select @message = 'No es v�lido un adelanto si existen gastos de cobranza [' + cast(@gastos_cobranza as varchar) + ']'

						raiserror(@message, 11, 0)

					end -- no es v�lido un adelanto si hay gastos de cobranza

				--if exists (select * from #calendario where id = @max_id and devengado = 0 and id_status = 1) and coalesce(@id_tipo_pago_prestamo, 0) not in (1, 2, 3)

--				select @pago_excedente, @sobrante, @id_tipo_pago_prestamo dbg03

				

				if @pago_excedente > 0.01 and coalesce(@id_tipo_pago_prestamo, 0) not in (1, 2, 3) and exists (select * from #calendario where actualizado = 1)

					begin -- existe un excedente cuyo tratamiento no ha sido indicado

						select @message = 'Hay un excedente [' + cast(@pago_excedente as varchar) + '] cuyo tratamiento no fue indicado'

						raiserror(@message, 11, 0)

					end -- existe un excedente cuyo tratamiento no ha sido indicado

				--select	'' debug15, *
				--from	#calendario

			end -- validaciones de la preparaci�n
			
			begin -- transacci�n

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio

				begin -- revisar que no hayan sido modificados los saldos en las cuentas

					select	numero,
							id_mov,
							saldo_actual,
							saldo_adelanto,
							fecha,
							ultimo_abono,
							ultimo_int_ord,
							ultimo_int_mor
					into	#saldos_transaccion
					from	edo_de_cuenta
					where	numero = @numero
							and id_mov in (100, 103, 112, @id_mov)

					--select	*
					--from	#saldos_transaccion t
					--		join #saldos_inicio i
					--			on i.numero = t.numero
					--			and i.id_mov = t.id_mov
					--			and
					--				(
					--				i.Fecha != t.fecha
					--				or i.saldo_actual != t.saldo_actual
					--				or i.saldo_adelanto != t.saldo_adelanto
					--				or i.ultimo_abono != t.ultimo_abono
					--				or i.ultimo_int_ord != t.ultimo_int_ord
					--				or i.ultimo_int_mor != t.ultimo_int_mor
					--				)
				
					if exists
						(
						select	*
						from	#saldos_transaccion t
								join #saldos_inicio i
									on i.numero = t.numero
									and i.id_mov = t.id_mov
									and
										(
										i.Fecha != t.fecha
										or i.saldo_actual != t.saldo_actual
										or i.saldo_adelanto != t.saldo_adelanto
										or i.ultimo_abono != t.ultimo_abono
										or i.ultimo_int_ord != t.ultimo_int_ord
										or i.ultimo_int_mor != t.ultimo_int_mor
										)
						)

						begin -- levantar error por cambio en saldos

							select @message = 'No se puede completar la transacci�n porque se detect� la afectaci�n de una transacci�n previa; revise los saldos del cr�dito y en caso necesario, aplique nuevamente la transacci�n'

							raiserror (@message, 13, 0)

						end -- levantar error por cambio en saldos
				
				end -- revisar que no hayan sido modificados los saldos en las cuentas

				begin -- revisar folio

					if not exists (select * from folios where numero = @numusuario and folio = @folio) and @numusuario not in (143) and @id_origen != 3

						begin

							select @message = 'El folio indicado [' + cast(@folio as varchar(16)) + '] para el usuario indicado [' + cast(@numusuario as varchar(16)) + '] no est� disponible; Es necesario que revise los saldos del cr�dito y el folio en cuesti�n, y en caso necesario, aplique nuevamente la transacci�n'

							raiserror (@message, 13, 0)

						end

				end -- revisar folio

				begin -- respaldar estatus anterior

					insert	tbl_interes_diario_edo_de_cuenta_resguardo
							(
							numero,
							id_mov,
							num_ptmo,
							numusuario,
							num_poliza,
							folio,
							fecha,
							saldo_ahorro_antes,
							saldo_ahorro_despues,
							fecha_ahorro,
							saldo_inverdinamica_antes,
							saldo_inverdinamica_despues,
							fecha_inverdinamica,
							saldo_debito_antes,
							saldo_debito_despues,
							fecha_debito,
							saldo_adelanto_antes,
							saldo_adelanto_despues,
							fecha_adelanto,
							saldo_credito_antes,
							saldo_credito_despues,
							fecha_ultimo_abono,
							fecha_ultimo_interes_ordinario,
							fecha_ultimo_interes_moratorio,
							int_ord_balance,
							int_ord_orden,
							int_mor_balance,
							int_mor_orden
							)
					select	aho.numero,
							@id_mov,
							@num_ptmo,
							@numusuario,
							@num_poliza,
							@folio,
							@fecha,
							aho.saldo_actual,
							aho.saldo_actual + @ahorro,
							aho.fecha,
							inver.saldo_actual,
							inver.saldo_actual + @inverdinamica,
							inver.fecha,
							deb.saldo_actual,
							deb.saldo_actual + @debito,
							deb.fecha,
							coalesce(ptmo.saldo_adelanto, 0),
							coalesce(ptmo.saldo_adelanto, 0) + @saldo_adelanto,
							ptmo.fecha_actualiza_adelanto,
							ptmo.saldo_actual,
							ptmo.saldo_actual - (select @capital_vencido + @capital_vigente + @capital_no_devengado),
							ptmo.ultimo_abono,
							ptmo.ultimo_int_ord,
							ptmo.ultimo_int_mor,
							tdc.int_ord_balance,
							tdc.int_ord_orden,
							tdc.int_mor_balance,
							tdc.int_mor_orden
					from	edo_de_cuenta aho
							join edo_de_cuenta inver
								on inver.numero = @numero
								and inver.id_mov = 103
							join edo_de_cuenta deb
								on deb.numero = @numero
								and deb.id_mov = 112
							join edo_de_cuenta ptmo
								on ptmo.numero = @numero
								and ptmo.id_mov = @id_mov
							join tbl_declaracion_cartera tdc
								on tdc.numero = ptmo.numero
								and tdc.id_mov = ptmo.id_mov
					where	aho.numero = @numero
							and aho.id_mov = 100

				end -- respaldar estatus anterior


				begin -- insertar en captura

					insert	captura
							(
							id_persona,
							activo,
							numero,
							nombre_s,
							apellido_paterno,
							apellido_materno,
							total_movs,
							total_ficha,
							id_tipomov,
							cuenta,
							concepto,
							fecha_mov,
							monto,
							id_mov,
							num_poliza,
							tipo_poliza,
							folio,
							id_tipo_persona,
							num_cheq,
							desc1,
							desc2,
							planx,
							desc3,
							fecha_dpf_final,
							num_dpf,
							tasa,
							interes,
							dias,
							debe_haber,
							numusuario,
							numero_fin,
							plazo,
							interes_ord,
							interes_mor,
							contador_provision,
							ccostos,
							nombre_beneficiario,
							parentesco_beneficiario,
							porcentaje_beneficiario,
							nombre_beneficiario2,
							parentesco_beneficiario2,
							porcentaje_beneficiario2,
							numero_fin_lacp,
							id_esquema,
							titular,
							num_ptmo,
							id_amortizacion,
							id_renovado,
							reestructura,
							id_origen,
							id_tipo_pago_prestamo
							)
					select	id_persona,
							activo,
							numero,
							nombre_s,
							apellido_paterno,
							apellido_materno,
							total_movs,
							total_ficha,
							id_tipomov,
							cuenta,
							concepto,
							fecha_mov,
							monto,
							id_mov,
							num_poliza,
							tipo_poliza,
							folio,
							id_tipo_persona,
							num_cheq,
							desc1,
							desc2,
							planx,
							desc3,
							fecha_dpf_final,
							num_dpf,
							tasa,
							interes,
							dias,
							debe_haber,
							numusuario,
							numero_fin,
							plazo,
							interes_ord,
							interes_mor,
							contador_provision,
							ccostos,
							nombre_beneficiario,
							parentesco_beneficiario,
							porcentaje_beneficiario,
							nombre_beneficiario2,
							parentesco_beneficiario2,
							porcentaje_beneficiario2,
							numero_fin_lacp,
							id_esquema,
							titular,
							num_ptmo,
							id_amortizacion,
							id_renovado,
							reestructura,
							id_origen,
							id_tipo_pago_prestamo
					from	#captura
					order by
							contador

				end -- insertar en captura

				begin -- insertar en movimientos

					insert	movimientos
							(
							numero,
							activo,
							fecha_mov,
							monto,
							saldo,
							tipo_poliza,
							num_poliza,
							folio,
							fecha_alta,
							interes_ord,
							interes_mor,
							plazo,
							numero_fin,
							id_persona,
							numusuario,
							id_tipomov,
							fecha_dpf_final,
							num_dpf,
							tasa_dpf,
							interes_dpf,
							dias,
							id_mov,
							id_tipo_persona,
							numero_fin_lacp,
							reestructura,
							id_motivo_reestructura,
							id_esquema,
							id_convenio,
							id_amortizacion,
							titular,
							planx,
							num_ptmo,
							id_nomina,
							id_esquema_nomina,
							id_renovado,
							id_origen,
							id_tipo_pago_prestamo
							)
					select	c.numero,
							c.activo,
							fecha_mov,
							monto,
							saldo = 0,
							tipo_poliza,
							num_poliza,
							folio,
							fecha_alta = @fecha,
							interes_ord,
							interes_mor,
							c.plazo,
							c.numero_fin,
							c.id_persona,
							numusuario,
							id_tipomov,
							fecha_dpf_final,
							num_dpf,
							tasa_dpf = 0,
							interes_dpf = 0,
							dias,
							c.id_mov,
							c.id_tipo_persona,
							c.numero_fin_lacp,
							reestructura,
							id_motivo_reestructura = null,
							c.id_esquema,
							id_convenio = null,
							c.id_amortizacion,
							titular,
							c.planx,
							c.num_ptmo,
							null id_nomina,
							null id_esquema_nomina,
							c.id_renovado,
							id_origen,
							id_tipo_pago_prestamo
					from	#captura c
					where	id_tipomov not in (961, 701, 702)

				end -- insertar en movimientos

				begin -- actualizar saldo en movimientos

					select	identity(int, 1, 1) id,
							cast(m.contador as int) contador,
							m.numero,
							m.id_mov,
							monto,
							saldo_antes = cast(null as money),
							saldo_despues = cast(null as money),
							case
								when
									id_mov = 100 and @ahorro > 0
									or id_mov = 103 and @inverdinamica > 0
									or id_mov = 112 and @debito > 0
									then 1
								else -1
							end operacion
					into	#saldos_movimientos
					from	movimientos m
					where	numusuario = @numusuario
							and folio = @folio
							and cast(fecha_mov as date) = cast(@fecha as date)
							and num_poliza = @num_poliza
							and (m.id_mov !< 100 or (m.id_mov < 100 and (id_tipomov like '3_' or id_tipomov like '[12]3_')))
							and activo = 'T'

					update	u
					set		saldo_antes = __.saldo,
							saldo_despues = __.saldo + operacion * monto
					from	(
							select	_.*, cta.saldo_actual saldo
							from	edo_de_cuenta cta
									join
										(							
										select	min(sm.contador) contador, sm.numero, sm.id_mov
										from	#saldos_movimientos sm
										group by sm.numero, sm.id_mov
										) _
										on _.numero = cta.numero
										and _.id_mov = cta.id_mov
							) __
							join #saldos_movimientos u
								on u.contador = __.contador

					while exists
						(
						select	1
						from	#saldos_movimientos sm1
								join #saldos_movimientos sm2
									on sm2.id = sm1.id + 1
									and sm2.numero = sm1.numero
									and sm2.id_mov = sm1.id_mov
									and sm2.saldo_antes is null
						)

					update	sm2
					set		saldo_antes = sm1.saldo_despues,
							saldo_despues = sm1.saldo_despues + sm2.operacion * sm2.monto
					from	#saldos_movimientos sm1
							join #saldos_movimientos sm2
								on sm2.id = sm1.id + 1
								and sm2.numero = sm1.numero
								and sm2.id_mov = sm1.id_mov
								and sm2.saldo_antes is null

					update	m
					set		saldo = sm.saldo_despues
					from	movimientos m
							join #saldos_movimientos sm
								on sm.numero = m.numero
								and sm.contador = m.contador

				end -- actualizar saldo en movimientos

				begin -- actualizar edo_de_cuenta

					begin -- pr�stamo

						select	@saldo_credito = sum(capital)
						from	#calendario
						where	id_status = 1

						select @saldo_credito = coalesce(@saldo_credito, 0)

						select	@saldo_vencido = SUM(capital)
						from	#calendario
						where	id_status = 1
								and cast(fecha_fin_corte as date) < CAST(@fecha as date)

						select @saldo_vencido = coalesce(@saldo_vencido, 0)

						select	*
						into	#actualiza_edo_de_cuenta_ptmo
						from	(
						select	@numero numero,
								@id_mov id_mov,
								@saldo_credito saldo_credito,
								@saldo_vencido saldo_vencido,
								cast(
									case
										when @capital_vencido + @capital_vigente + @capital_no_devengado != 0
											then @fecha
										else null
									end as datetime
									) ultimo_abono,
								cast(
									case
										when @ordinarios_vigentes + @ordinarios_vencidos != 0
											then @fecha
										else null
									end as datetime
									) ultimo_int_ord,
								cast(
									case
										when @moratorios != 0
											then @fecha
										else null
									end as datetime
									) ultimo_int_mor
								) _

						update	cta
						set		saldo_actual = ae.saldo_credito,
								saldo_vencido = ae.saldo_vencido,
								ultimo_abono = coalesce(ae.ultimo_abono, cta.ultimo_abono),
								ultimo_int_ord = coalesce(ae.ultimo_int_ord, cta.ultimo_int_ord),
								ultimo_int_mor = coalesce(ae.ultimo_int_mor, cta.ultimo_int_mor),
								saldo_adelanto = coalesce(saldo_adelanto, 0) + @saldo_adelanto,
								fecha_actualiza_adelanto =
									case
										when @saldo_adelanto != 0
											then @fecha
										else fecha_actualiza_adelanto
									end
						from	#actualiza_edo_de_cuenta_ptmo ae
								join edo_de_cuenta cta
									on ae.numero = cta.numero
									and ae.id_mov = cta.id_mov

					end -- pr�stamo

					begin -- haberes

						insert	#actualiza_edo_de_cuenta_haberes
								(numero, id_mov, saldo_anterior, diferencia, saldo_posterior, fecha)
						select	numero, id_mov, saldo_anterior = saldo_actual, diferencia = @ahorro, saldo_posterior = saldo_actual + @ahorro, fecha = @fecha
						from	edo_de_cuenta cta
						where	numero = @numero
								and id_mov = 100
								and @ahorro != 0

						insert	#actualiza_edo_de_cuenta_haberes
								(numero, id_mov, saldo_anterior, diferencia, saldo_posterior, fecha)
						select	numero, id_mov, saldo_anterior = saldo_actual, diferencia = @inverdinamica, saldo_posterior = saldo_actual + @inverdinamica, fecha = @fecha
						from	edo_de_cuenta cta
						where	numero = @numero
								and id_mov = 103
								and @inverdinamica != 0

						insert	#actualiza_edo_de_cuenta_haberes
								(numero, id_mov, saldo_anterior, diferencia, saldo_posterior, fecha)
						select	numero, id_mov, saldo_anterior = saldo_actual, diferencia = @debito, saldo_posterior = saldo_actual + @debito, fecha = @fecha
						from	edo_de_cuenta cta
						where	numero = @numero
								and id_mov = 112
								and @debito != 0

						update	cta
						set		saldo_actual = ae.saldo_posterior,
								fecha = ae.fecha
						from	#actualiza_edo_de_cuenta_haberes ae
								join edo_de_cuenta cta
									on cta.numero = ae.numero
									and cta.id_mov = ae.id_mov
									and ae.diferencia != 0

					end -- haberes

				end -- actualizar edo_de_cuenta

				begin -- folios

					if @id_origen != 3

						update	folios
						set		folio = folio + 1,
								fecha = @fecha
						where	numero = @numusuario

				end -- folios

				begin -- actualizar calendario

					select	@tabla =
								(
								select	distinct tabla
								from	#calendario
								)

					if @tabla = 'tbl_automotriz_ptmos'

						begin -- actualiza tbl_automotriz_ptmos

							update	t
							set		id_status = c.id_status,
									fecha_pago_cajas = c.fecha_pago_cajas,
									numusuario = c.numusuario,
									folio = c.folio
							from	#calendario c
									join tbl_automotriz_ptmos t
										on t.Numero = c.numero
										and t.Id_mov = c.id_mov
										and t.Contador = c.contador
							where	actualizado = 1

							update	t
							set		id_status = 4,
									folio = @folio
							from	#calendario c
									join tbl_automotriz_ptmos t
										on t.numero = c.numero
										and t.id_mov = c.id_mov
										and t.contador = c.contador
							where	actualizado in (2, 3)

							insert	tbl_automotriz_ptmos
									(
									numero,
									id_mov,
									id_esquema,
									monto_inicial,
									saldo_actual,
									int_ord,
									plazo,
									planx,
									fecha_pago,
									capital,
									interes,
									iva,
									total,
									fecha_pago_cajas,
									numusuario,
									id_status,
									fecha_alta,
									num_ptmo,
									num_pago,
									folio,
									fecha_ptmo,
									fecha_fin_original
									)
							select	numero,
									id_mov,
									id_esquema,
									monto_inicial,
									saldo_actual,
									int_ord = tasa_ord,
									plazo,
									planx,
									fecha_pago = fecha_fin_corte,
									capital,
									interes,
									iva,
									total,
									fecha_pago_cajas,
									numusuario,
									id_status,
									fecha_alta = @fecha,
									num_ptmo,
									num_pago,
									folio,
									fecha_ptmo,
									fecha_fin_original
							from	#calendario
							where	actualizado = 2
							order by
									num_pago

						end -- actualiza tbl_automotriz_ptmos

					else if @tabla = 'tbl_hipotecario_ptmos'

						begin -- actualiza tbl_hipotecario_ptmos

							update	t
							set		id_status = c.id_status,
									fecha_pago_cajas = c.fecha_pago_cajas,
									numusuario = c.numusuario,
									folio = c.folio
							from	#calendario c
									join tbl_hipotecario_ptmos t
										on t.Numero = c.numero
										and t.Id_mov = c.id_mov
										and t.Contador = c.contador
							where	actualizado = 1

							update	t
							set		id_status = 4,
									folio = @folio
							from	#calendario c
									join tbl_hipotecario_ptmos t
										on t.numero = c.numero
										and t.id_mov = c.id_mov
										and t.contador = c.contador
							where	actualizado in (2, 3)

							insert	tbl_hipotecario_ptmos
									(
									numero,
									id_mov,
									id_esquema,
									monto_inicial,
									saldo_actual,
									int_ord,
									plazo,
									planx,
									fecha_pago,
									capital,
									interes,
									seguro_vida,
									seguro_danos,
									total,
									fecha_pago_cajas,
									numusuario,
									id_status,
									fecha_alta,
									num_ptmo,
									num_pago,
									folio,
									fecha_ptmo,
									fecha_fin_original
									)
							select	numero,
									id_mov,
									id_esquema,
									monto_inicial,
									saldo_actual,
									int_ord = tasa_ord,
									plazo,
									planx,
									fecha_pago = fecha_fin_corte,
									capital,
									interes,
									seguro_vida,
									seguro_da�os,
									total,
									fecha_pago_cajas,
									numusuario,
									id_status,
									fecha_alta = @fecha,
									num_ptmo,
									num_pago,
									folio,
									fecha_ptmo,
									fecha_fin_original
							from	#calendario
							where	actualizado = 2
							order by
									num_pago

						end -- actualiza tbl_hipotecario_ptmos

					else if @tabla = 'tbl_credinomina_ptmos_cajas'

						begin -- actualiza tbl_credinomina_ptmos_cajas

							update	t
							set		id_status = c.id_status,
									fecha_pago_cajas = c.fecha_pago_cajas,
									numusuario = c.numusuario,
									folio = c.folio
							from	#calendario c
									join tbl_credinomina_ptmos_cajas t
										on t.Numero = c.numero
										and t.Id_mov = c.id_mov
										and t.Contador = c.contador
							where	actualizado = 1

							update	t
							set		id_status = 4,
									folio = @folio
							from	#calendario c
									join tbl_credinomina_ptmos_cajas t
										on t.numero = c.numero
										and t.id_mov = c.id_mov
										and t.contador = c.contador
							where	actualizado in (2, 3)

							insert	tbl_credinomina_ptmos_cajas
									(
									numero,
									id_mov,
									id_esquema,
									monto_inicial,
									saldo_actual,
									int_ord,
									plazo,
									planx,
									fecha_pago,
									capital,
									interes,
									iva,
									total,
									fecha_pago_cajas,
									numusuario,
									id_status,
									fecha_alta,
									num_ptmo,
									num_pago,
									folio,
									fecha_ptmo,
									fecha_fin_original
									)
							select	numero,
									id_mov,
									id_esquema,
									monto_inicial,
									saldo_actual,
									int_ord = tasa_ord,
									plazo,
									planx,
									fecha_pago = fecha_fin_corte,
									capital,
									interes,
									iva,
									total,
									fecha_pago_cajas,
									numusuario,
									id_status,
									fecha_alta = @fecha,
									num_ptmo,
									num_pago,
									folio,
									fecha_ptmo,
									fecha_fin_original
							from	#calendario
							where	actualizado = 2
							order by
									num_pago

						end -- actualiza tbl_credinomina_ptmos_cajas

					else if @tabla = 'tbl_nivelados_ptmos'

						begin -- actualiza tbl_nivelados_ptmos

							update	t
							set		id_status = c.id_status,
									fecha_pago_cajas = c.fecha_pago_cajas,
									numusuario = c.numusuario,
									folio = c.folio
							from	#calendario c
									join tbl_nivelados_ptmos t
										on t.Numero = c.numero
										and t.Id_mov = c.id_mov
										and t.Contador = c.contador
							where	actualizado = 1

							update	t
							set		id_status = 4,
									folio = @folio
							from	#calendario c
									join tbl_nivelados_ptmos t
										on t.numero = c.numero
										and t.id_mov = c.id_mov
										and t.contador = c.contador
							where	actualizado in (2, 3)

							insert	tbl_nivelados_ptmos
									(
									numero,
									id_mov,
									id_esquema,
									monto_inicial,
									saldo_actual,
									int_ord,
									plazo,
									planx,
									fecha_pago,
									capital,
									interes,
									seguro_vida,
									seguro_danos,
									iva,
									total,
									fecha_pago_cajas,
									numusuario,
									id_status,
									fecha_alta,
									num_ptmo,
									num_pago,
									folio,
									fecha_ptmo,
									fecha_fin_original
									)
							select	numero,
									id_mov,
									id_esquema,
									monto_inicial,
									saldo_actual,
									int_ord = tasa_ord,
									plazo,
									planx,
									fecha_pago = fecha_fin_corte,
									capital,
									interes,
									seguro_vida,
									seguro_da�os,
									iva,
									total,
									fecha_pago_cajas,
									numusuario,
									id_status,
									fecha_alta = @fecha,
									num_ptmo,
									num_pago,
									folio,
									fecha_ptmo,
									fecha_fin_original
							from	#calendario
							where	actualizado = 2
							order by
									num_pago

						end -- actualiza tbl_nivelados_ptmos

				end -- actualizar calendario

				if not exists (select * from #calendario where id_status = 1)

					begin -- migrar si fue liquidaci�n

						select	@liquidado = 1

						begin -- migrar a scoring

							insert	scoring_credito
									(
									numero,
									id_mov,
									num_ptmo,
									fecha_alta,
									id_status,
									max_dias_vencidos,
									max_periodos_atrasados,
									tasa_anual,
									cat,
									folio,
									num_poliza,
									numusuario,
									fecha_incumplimiento,
									max_dias_vencidos_interes,
									max_periodos_atrasados_interes
									)
							select	cta.numero,
									cta.id_mov,
									cta.num_ptmo,
									fecha_alta = @fecha,
									id_status = 1,
									cta.max_dias_vencidos,
									cta.max_periodos_atrasados,
									tasa_anual = cta.int_ord * 12,
									cta.cat,
									folio = @folio,
									num_poliza = @num_poliza,
									numusuario = @numusuario,
									cta.fecha_incumplimiento,
									cta.max_dias_vencidos_interes,
									cta.max_periodos_atrasados_interes
							from	--#resumen_pago rp
									edo_de_cuenta cta
							where	cta.numero = @numero
									and cta.id_mov = @id_mov

						end -- migrar a scoring

					end -- migrar si fue liquidaci�n

				----------begin -- insertar en TBL_INTERES_DIARIO_FOLIOS

				----------	insert	TBL_INTERES_DIARIO_FOLIOS
				----------			(
				----------			procesado,
				----------			id_de_sucursal,
				----------			num_poliza,
				----------			ccostos,
				----------			numusuario,
				----------			numero,
				----------			id_mov,
				----------			num_ptmo,
				----------			folio,
				----------			id_esquema,
				----------			numero_fin_lacp,
				----------			fecha_mov,
				----------			ptmo_liquidado,
				----------			id_origen,
				----------			total_ficha,
				----------			CV_diaria,
				----------			fecha_traspaso_CV,
				----------			aplica_IVA
				----------			)

				----------	select	procesado = 0,------------------- cambiar default!
				----------			id_de_sucursal = id_de_sucursal,
				----------			num_poliza = @num_poliza,
				----------			ccostos = ccostos,
				----------			numusuario = @numusuario,
				----------			numero = @numero,
				----------			id_mov = @id_mov,
				----------			num_ptmo = @num_ptmo,
				----------			folio = @folio,
				----------			id_esquema = @id_esquema,
				----------			numero_fin_lacp = numero_fin_lacp,
				----------			fecha_mov = @fecha,
				----------			ptmo_liquidado = @liquidado,
				----------			id_origen = @id_origen,
				----------			total_ficha = abs(@efectivo),
				----------			CV_Diaria,
				----------			fecha_traspaso_CV,
				----------			aplica_IVA
				----------	from	#persona p
				----------			join #datos_credito dc
				----------				on dc.Numero = p.numero
								
				----------end -- insertar en TBL_INTERES_DIARIO_FOLIOS


				begin -- saldado captura lacp
				
					-- obtenemos la ultima amortizacion saldada
					if ( @tabla = 'tbl_credinomina_ptmos_cajas' )
						begin
								select	@num_pago = Num_pago
								from	tbl_credinomina_ptmos_cajas 
								where	Num_ptmo = @num_ptmo
									and Id_status = 3
									and Folio = @folio
			
							-- obtenemos las fechas de inicio y fin del pago que esta realizando
								select @fecha_ini = case 
														when @num_pago = 1 then ( select top 1 fecha_ptmo from tbl_credinomina_ptmos_cajas where numero = @numero and Num_ptmo = @num_ptmo  and Id_status = 3)
														else (select top 1 Fecha_pago from tbl_credinomina_ptmos_cajas where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago-1 and Id_status = 3)
													end
								select @fecha_fin = ( select fecha_fin_original from tbl_credinomina_ptmos_cajas where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago  and Id_status = 3) 

								select @int_ord_dia = (@int_ord_edo_cta * Saldo_actual) from tbl_credinomina_ptmos_cajas where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago  and Id_status = 3 -- interes por dia de la amortizacion que se va a pagar
								select @int_mor_dia = (@int_mor_edo_cta * Capital) from tbl_credinomina_ptmos_cajas where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago  and Id_status = 3 -- interes por dia de la amortizacion que se va a pagar

							-- obtenemos el interes ordinario de ese periodo
								select @int_ordinario_amortizacion = Interes from tbl_credinomina_ptmos_cajas where Num_ptmo = @num_ptmo and numero = @numero and Num_pago = @num_pago and Id_status = 3

						end
	
					if ( @tabla = 'tbl_automotriz_ptmos' )
						begin
								select	@num_pago = Num_pago
								from	tbl_automotriz_ptmos 
								where	Num_ptmo = @num_ptmo
									and Id_status = 3
									and Folio = @folio
				
							-- obtenemos las fechas de inicio y fin del pago que esta realizando
								select @fecha_ini = case 
														when @num_pago = 1 then ( select top 1 fecha_ptmo from TBL_AUTOMOTRIZ_PTMOS where numero = @numero and Num_ptmo = @num_ptmo  and Id_status = 3)
														else (select top 1 Fecha_pago from TBL_AUTOMOTRIZ_PTMOS where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago-1 and Id_status = 3)
													end
								select @fecha_fin = ( select fecha_fin_original from TBL_AUTOMOTRIZ_PTMOS where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago  and Id_status = 3) 

								select @int_ord_dia = (@int_ord_edo_cta * Saldo_actual) from TBL_AUTOMOTRIZ_PTMOS where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago  and Id_status = 3 -- interes por dia de la amortizacion que se va a pagar
								select @int_mor_dia = (@int_mor_edo_cta * Capital) from TBL_AUTOMOTRIZ_PTMOS where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago  and Id_status = 3 -- interes por dia de la amortizacion que se va a pagar

							-- obtenemos el interes ordinario de ese periodo
								select @int_ordinario_amortizacion = Interes from TBL_AUTOMOTRIZ_PTMOS where Num_ptmo = @num_ptmo and numero = @numero and Num_pago = @num_pago and Id_status = 3
				
						end 

					if ( @tabla = 'tbl_hipotecario_ptmos' )
						begin
								select	@num_pago = Num_pago
								from	tbl_hipotecario_ptmos 
								where	Num_ptmo = @num_ptmo
									and Id_status = 3
									and Folio = @folio
			
							-- obtenemos las fechas de inicio y fin del pago que esta realizando
								select @fecha_ini = case 
														when @num_pago = 1 then ( select top 1 fecha_ptmo from tbl_hipotecario_ptmos where numero = @numero and Num_ptmo = @num_ptmo and Id_status = 3)
														else (select top 1 Fecha_pago from tbl_hipotecario_ptmos where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago-1 and Id_status = 3)
													end
								select @fecha_fin = ( select fecha_fin_original from tbl_hipotecario_ptmos where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago  and Id_status = 3) 

								select @int_ord_dia = (@int_ord_edo_cta * Saldo_actual) from tbl_hipotecario_ptmos where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago  and Id_status = 3 -- interes por dia de la amortizacion que se va a pagar
								select @int_mor_dia = (@int_mor_edo_cta * Capital) from tbl_hipotecario_ptmos where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago  and Id_status = 3 -- interes por dia de la amortizacion que se va a pagar

							-- obtenemos el interes ordinario de ese periodo
								select @int_ordinario_amortizacion = Interes from tbl_hipotecario_ptmos where Num_ptmo = @num_ptmo and numero = @numero and Num_pago = @num_pago and Id_status = 3
						end 

					if ( @tabla = 'tbl_nivelados_ptmos' )
						begin
								select	@num_pago = Num_pago
								from	tbl_nivelados_ptmos 
								where	Num_ptmo = @num_ptmo
									and Id_status = 3
									and Folio = @folio
			
							-- obtenemos las fechas de inicio y fin del pago que esta realizando
								select @fecha_ini = case 
														when @num_pago = 1 then ( select top 1 fecha_ptmo from tbl_nivelados_ptmos where numero = @numero and Num_ptmo = @num_ptmo  and Id_status = 3)
														else (select top 1 Fecha_pago from tbl_nivelados_ptmos where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago-1 and Id_status = 3)
													end
								select @fecha_fin = ( select fecha_fin_original from tbl_nivelados_ptmos where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago  and Id_status = 3) 

								select @int_ord_dia = (@int_ord_edo_cta * Saldo_actual) from tbl_nivelados_ptmos where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago  and Id_status = 3 -- interes por dia de la amortizacion que se va a pagar
								select @int_mor_dia = (@int_mor_edo_cta * Capital) from tbl_nivelados_ptmos where numero = @numero and Num_ptmo = @num_ptmo and Num_pago = @num_pago  and Id_status = 3 -- interes por dia de la amortizacion que se va a pagar

							-- obtenemos el interes ordinario de ese periodo
								select @int_ordinario_amortizacion = Interes from tbl_nivelados_ptmos where Num_ptmo = @num_ptmo and numero = @numero and Num_pago = @num_pago and Id_status = 3
						end 

					-- obtenemos los dias del periodo
						select @dias_del_periodo = DATEDIFF(day,@fecha_ini,@fecha_fin)

					---- obtenemos el interes ordinario del dia 
					--	select	@int_ord_dia =	case
					--								when @cv_diaria = 1 then int_ord_dia_orden
					--								else int_ord_dia_balance
					--							end
					--	from	tbl_declaracion_cartera 
					--	where	num_ptmo = @num_ptmo

					---- obtenemos el interes moratorio  del dia 
					--	select	@int_mor_dia =	case
					--								when @cv_diaria = 1 then int_mor_dia_orden
					--								else int_mor_dia_balance
					--							end
					--	from	tbl_declaracion_cartera 
					--	where	num_ptmo = @num_ptmo

					-- se insertan los registros que no son de pagos a prestamos
					insert  #tbl_interes_diario_captura_lacp_aux
					select	Id_persona,Activo,Numero,Nombre_s,Apellido_paterno,Apellido_materno,Total_movs,Total_ficha,Id_Tipomov,Cuenta,upper(Concepto),
							@fecha as Fecha_mov,Monto,Neto,ID_mov,Banco,clave_Local,Linea,Num_Poliza,Tipo_poliza,Folio,Id_Tipo_persona,Num_cheq,Desc1,Desc2,
							planx,Aval1_socio,Aval1_numero,Aval2_socio,Aval2_numero,Desc3,Desc4,FECHA_DPF_final,NUM_DPF,TASA,INTERES,DIAS,DEBE_HABER,
							NUMUSUARIO,PROCESADO, @fecha as FECHA_ALTA,numero_Fin,numero_fin2,Plazo,Interes_ord,Interes_mor,Monto2,Plazo2,Interes_ord2,
							Interes_mor2,Aval1_avalados,Aval2_avalados,Fec_inicio,Fec_prog,Contador_provision,Ccostos,NOMBRE_BENEFICIARIO,
							PARENTESCO_BENEFICIARIO,PORCENTAJE_BENEFICIARIO,NOMBRE_BENEFICIARIO2,PARENTESCO_BENEFICIARIO2,PORCENTAJE_BENEFICIARIO2,
							Id_Sol,Numero_Fin_LACP,Reestructura,Id_Motivo_Reestructura,Id_Esquema,Id_Convenio,Id_Amortizacion,Ent_Federativa,
							Cve_Municipio,Cve_Localidad,Identificador,Transferencia,Fecha_Pago,Bimestre,Referencia,Cve_Archivo,Impreso,Folio_Impresion,
							Documentacion,dpf_en_garantia,Titular,Id_Nomina,Id_Esquema_Nomina,Id_Leyenda,Num_ptmo,Id_Renovado,Ahorro_Base,
							Tasa_Pasiva,Id_Fondeador,Numero_Fondeo,id_origen,id_tipo_pago_prestamo 
					from	captura 
					where	Numero = @numero and Folio = @folio and Num_Poliza = @num_poliza and Activo = 'T' and Fecha_mov >= cast(@fecha as date)

							AND (
									Id_Tipomov NOT LIKE '3_' and -- CAPITAL
									Id_Tipomov NOT LIKE '6_' and -- INTERES ORDINARIO
									Id_Tipomov NOT LIKE '7_' and -- INTERES MORATORIO
									Id_Tipomov NOT LIKE '13_' and -- ABONO VENCIDO
									Id_Tipomov NOT LIKE '23_' and -- PAGO CARTERA VENCIDA
									Id_Tipomov NOT LIKE '53_' and -- QUITAS 
									Id_Tipomov NOT LIKE '80_' and -- IVA POR INTERES ORDINARIO
									Id_Tipomov NOT LIKE '81_'  -- IVA POR INTERES MORATORIO
								)


					-- obtenemos centros de costos de cajero y socio
					select  @ccostos_socio					= s.ccostos,
							@cta_compensacion_destino		= n.Num_Cuenta_Compensacion,
							@concepto_compensacion_destino  = n.concepto
															from	persona p
																	inner join sucursales s on p.id_de_sucursal = s.id_de_sucursal
																	inner join num_sucursal n on n.num_sucursal = s.num_sucursal
															where	p.numero = @numero and p.id_tipo_persona = 1

					select  @ccostos_cajero				  =	s.ccostos,
							@cta_compensacion_origen	  = n.Num_Cuenta_Compensacion,
							@concepto_compensacion_origen = n.concepto
															from	CLAVES c 
																	inner join SUCURSALES s on s.Id_de_Sucursal = c.Id_de_sucursal
																	inner join num_sucursal n on n.num_sucursal = s.num_sucursal
															where	c.numusuario = @numusuario

				--------------------------------------------------------------------------------------------------------------------------------------------------------
					-- obtenemos los montos pagados de intereses y capital en la ficha
						select  @int_mor_ficha_saldado = coalesce( @moratorios, 0)

						select  @int_ord_ficha_saldado = coalesce( @ordinarios_vigentes + @ordinarios_vencidos ,0)

						--select @capital_vigente_ficha_saldado =  @capital_vigente + @capital_no_devengado -- no devengado

						--select @capital_vencido_ficha_saldado =  @capital_vencido

						select	@capital_vigente_ficha_saldado =  (select  coalesce( sum(monto), 0) --as capital_vigente
						from	captura where numero = @numero and folio = @folio and num_poliza = @num_poliza and id_tipomov like '3_' and activo = 'T' and fecha_mov >= cast(@fecha as date)) 

						select	@capital_vencido_ficha_saldado =  (select  coalesce( sum(monto), 0) --as capital_vencido
						from	captura where numero = @numero and folio = @folio and num_poliza = @num_poliza and id_tipomov like '13_' and activo = 'T' and fecha_mov >= cast(@fecha as date)) 


						select	@capital_adelanto =	(select  coalesce( sum(monto), 0) -- AS CAP_ADELANTO
													 from	CAPTURA where	numero = @numero and Folio = @folio and Num_Poliza = @num_poliza and Id_Tipomov like '14_' and Activo = 'T' and Fecha_mov >= cast(@fecha as date)) 

						select	@total_moratorio_adeudado_balance	= int_mor_balance,
								@total_moratorio_adeudado_orden		= int_mor_orden,
								@total_ordinario_adeudado_balance	= Int_ord_balance,
								@total_ordinario_adeudado_orden		= Int_ord_orden
						from	TBL_DECLARACION_CARTERA 
						where	Numero = @numero 
							and	Id_mov = @id_mov
							and Num_ptmo = @num_ptmo

						select @int_mor_ficha_restante = @int_mor_ficha_saldado
						select @int_ord_ficha_restante = @int_ord_ficha_saldado

						-- se salda balance de moratorio 
						if ( @total_moratorio_adeudado_balance > 0 and @int_mor_ficha_restante > 0 )
						begin

							select @int_mor_balance_saldado =	case
																	when @int_mor_ficha_restante >= @total_moratorio_adeudado_balance then @total_moratorio_adeudado_balance
																	else @int_mor_ficha_restante
																end
												
							update	dc
							set		int_mor_balance =	int_mor_balance - @int_mor_balance_saldado
							from	tbl_declaracion_cartera dc
							where	numero = @numero 
								and	id_mov = @id_mov
								and num_ptmo = @num_ptmo
				
							select @int_mor_ficha_restante = @int_mor_ficha_restante - @int_mor_balance_saldado
			
						end --if ( @total_moratorio_adeudado_balance > 0 )

						-- se salda orden de moratorio
						if ( @total_moratorio_adeudado_orden > 0 and @int_mor_ficha_restante >0 )
						begin

							select @int_mor_orden_saldado =	case
																when @int_mor_ficha_restante >= @total_moratorio_adeudado_orden then @total_moratorio_adeudado_orden
																else @int_mor_ficha_restante
															end

							update	dc
							set		Int_mor_orden =	Int_mor_orden - @int_mor_orden_saldado
							from	TBL_DECLARACION_CARTERA dc
							where	Numero = @numero 
								and	Id_mov = @id_mov
								and Num_ptmo = @num_ptmo

							select @int_mor_ficha_restante = @int_mor_ficha_restante - @int_mor_orden_saldado
			
						end	 -- if ( @total_moratorio_adeudado_orden > 0 )	

						-- se salda balance ordinario 
						if ( @total_ordinario_adeudado_balance > 0 )
						begin

							select @int_ord_balance_saldado =	case
																	when @int_ord_ficha_restante >= @total_ordinario_adeudado_balance then @total_ordinario_adeudado_balance
																	else @int_ord_ficha_restante
																end

							update	dc
							set		Int_ord_balance =	Int_ord_balance - @int_ord_balance_saldado
							from	TBL_DECLARACION_CARTERA dc
							where	Numero = @numero 
								and	Id_mov = @id_mov
								and Num_ptmo = @num_ptmo
				
							select @int_ord_ficha_restante = @int_ord_ficha_restante - @int_ord_balance_saldado
			
						end -- if ( @total_ordinario_adeudado_balance > 0 )

						-- se salda orden ordinario 
						if ( @total_ordinario_adeudado_orden > 0 )
						begin

							select @int_ord_orden_saldado =	case
																when @int_ord_ficha_restante >= @total_ordinario_adeudado_orden then @total_ordinario_adeudado_orden
																else @int_ord_ficha_restante
															end

							update	dc
							set		Int_ord_orden =	Int_ord_orden - @int_ord_orden_saldado
							from	TBL_DECLARACION_CARTERA dc
							where	Numero = @numero 
								and	Id_mov = @id_mov
								and Num_ptmo = @num_ptmo

							select @int_ord_ficha_restante = @int_ord_ficha_restante - @int_ord_orden_saldado
			
						end	 
				---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					-- si es un capital de anticipo
					select top 1 @es_adelanto = case
													when id_tipo_pago_prestamo is null then cast(0 as bit)
													else cast(1 as bit)
												end				
												from	CAPTURA  
												where	numero = @numero 
													and Folio = @folio 
													and Num_Poliza = @num_poliza 
													and (Id_Tipomov like '13_' or Id_Tipomov like '3_')
													and Activo = 'T'
													and Fecha_mov >= cast(@fecha as date)


					---------------------------------------------------------------------------------------------------------------------------
					-- montos que iran en la malla
					---------------------------------------------------------------------------------------------------------------------------
					-- si el credito esta vencido
					--select @cv_diaria cv_diaria
					if ( @cv_diaria = 1 )
						begin
						
							-- fechas de inicio y fin de todas las amortizaciones que se estan pagando
								select	@fecha_ini_calendario_saldado = fecha_inicio_corte 
								from	#calendario 
								where	total_saldado > 0.0 
									and	num_pago = ( select min(num_pago) from #calendario where	total_saldado > 0.0  )

								select	@fecha_fin_calendario_saldado = fecha_fin_corte 
								from	#calendario 
								where	total_saldado > 0.0 
									and	num_pago = ( select max(num_pago) from #calendario where	total_saldado > 0.0  )
						
							-- si las amortizaciones que va a pagar estan todas antes del traspaso de cartera todo va a balance
							if	( 
									(cast(@fecha_ini_calendario_saldado as date) ) <  cast(@fecha_traspaso_cv as date )  and 
									(cast(@fecha_fin_calendario_saldado as date) ) <  cast(@fecha_traspaso_cv as date )   
								)
								begin
									select	@int_ord_ingresos = 0,
											@int_ord_provision = @int_ord_ficha_saldado,
											@int_mor_ingresos = 0,
											@int_mor_provision = @int_mor_ficha_saldado
								end
							else
								begin
									-- si las amortizaciones que va a pagar estan todas despues del traspaso de cartera todo va a orden		
									if	( 
											(cast(@fecha_ini_calendario_saldado as date) ) >  cast(@fecha_traspaso_cv as date )  and 
											(cast(@fecha_fin_calendario_saldado as date) ) >  cast(@fecha_traspaso_cv as date )   
										)
										begin
											select	@int_ord_ingresos = @int_ord_ficha_saldado,
													@int_ord_provision = 0,
													@int_mor_ingresos = @int_mor_ficha_saldado,
													@int_mor_provision = 0
										end
									-- si esta pagando en un periodo donde hubo traspaso a cartera vencida
									else
										begin
											-- monto que va a cuentas de ingresos
											select	@int_ord_ingresos = coalesce( sum(ordinarios_a_ingresos), 0) , 
													@int_mor_ingresos = coalesce( sum(moratorios_a_ingresos), 0) 
											from	
													(
														select	case
																	when DATEDIFF(day, @fecha_traspaso_cv, fecha_fin_corte) <= 0 then 0
																	else ( DATEDIFF(day, @fecha_traspaso_cv, fecha_fin_corte) ) * (@int_ord_edo_cta * saldo_actual)
																end as ordinarios_a_ingresos,
																case
																	when DATEDIFF(day, @fecha_traspaso_cv, fecha_fin_corte) <= 0 then 0
																	else ( DATEDIFF(day, @fecha_traspaso_cv, fecha_fin_corte) ) * (@int_mor_edo_cta * Capital)
																end as moratorios_a_ingresos
														from	#calendario 
														where	total_saldado > 0.0			
													) calendario_saldado
										
											--montos x diferencia a balance
											select	@int_ord_provision = @int_ord_ficha_saldado - @int_ord_ingresos,
													@int_mor_provision = @int_mor_ficha_saldado - @int_mor_ingresos

										end -- si esta pagando en un periodo donde hubo traspaso a cartera vencida
							
								end  -- else -- si las amortizaciones que va a pagar estan todas antes del traspaso de cartera todo va a balance
				
						end -- if ( @cv_diaria = 1 )

					-- si el credito esta vigente
					else -- cv_diaria = 0
						begin
							-- si esta en cartera vigente no deberia haber acumulacion en orden

							-- si paga antes del corte y esta al corriente
							if	( 
									(convert(datetime,CONVERT(varchar(10), @fecha_fin, 103),103)) >= -- fecha de pago de amortizacion
									(convert(datetime,CONVERT(varchar(10), @fecha, 103),103))  -- fecha de pago en cajas
								) 
								begin
								-- obtenemos el monto que va a ingresos (paga antes de su fecha de corte)
									select @dias_faltantes = DATEDIFF(day,cast(@fecha as date),@fecha_fin) 
		  							select @dias_devengados = @dias_del_periodo - @dias_faltantes
									
									-- ordinarios
										if ( @total_ordinario_adeudado_balance >= @int_ord_ficha_saldado )
											begin -- si lo provisionado es mayor a lo que pago en la ficha todo el saldo va a la cuenta 13xxx
												select @int_ord_provision = @int_ord_ficha_saldado 
												select @int_ord_ingresos  = 0
											end
										else   
											begin
												select @int_ord_provision = @total_ordinario_adeudado_balance 
												select @int_ord_ingresos  = @int_ord_ficha_saldado - @int_ord_provision
											end
									
									-- moratorios
										select	@int_mor_provision = @int_mor_ficha_saldado, --pq se supone q no hay intereses moratorios pagados x anticipado
												@int_mor_ingresos = 0

									-- si esta al corriente se actualizan los saldos a 0 de los intereses de orden y balance en la declaracion cartera
										update	dc
										set		int_mor_balance =	0,
												Int_mor_orden	=	0,
												Int_ord_balance	=	0,
												Int_ord_orden	=	0
										from	tbl_declaracion_cartera dc
										where	numero = @numero 
											and	id_mov = @id_mov
											and num_ptmo = @num_ptmo

									select @tipo_cta_ingresos_ordinarios = 6 

								end
							-- si paga en su fecha de corte o despues todo va  a provision
							else
								begin
									select	@int_ord_provision = @int_ord_ficha_saldado,
											@int_ord_ingresos = 0
									select	@int_mor_provision = @int_mor_ficha_saldado,
											@int_mor_ingresos = 0
								end

						end --else -- cv_diaria = 0

					-------------------------------------------------------------------------------------------------------------------------------------
					-------------------------------------------------------------------------------------------------------------------------------------
					-------------------------------------------------------------------------------------------------------------------------------------
					-- INSERCION CAPTURA_LACP
					-------------------------------------------------------------------------------------------------------------------------------------
					-------------------------------------------------------------------------------------------------------------------------------------
					-------------------------------------------------------------------------------------------------------------------------------------

					-- se obtiene el iva de todos los montos segun la malla, si no cuadra con el monto de la ficha
					-- la diferencia se aplica a la cantidad que tenga mas monto en iva 
					declare  @iva_int_ord_ingresos money,@iva_int_ord_provision money,@iva_int_mor_ingresos money,@iva_int_mor_provision money
							,@iva_ficha money = 0, @iva_malla money = 0, @diferencia_iva money, @id int = 0

							select @iva_int_ord_ingresos = coalesce( (cast(round(@int_ord_ingresos * @tasa_iva ,2) as numeric(36,2))), 0)
							select @iva_int_ord_provision = coalesce( (cast(round(@int_ord_provision * @tasa_iva ,2) as numeric(36,2))), 0)
							select @iva_int_mor_ingresos = coalesce( (cast(round(@int_mor_ingresos * @tasa_iva ,2) as numeric(36,2))), 0)
							select @iva_int_mor_provision = coalesce( (cast(round(@int_mor_provision * @tasa_iva ,2) as numeric(36,2))), 0)
							select @iva_ficha = (
													select  coalesce( sum(monto), 0) --
													from	CAPTURA where	numero = @numero and Folio = @folio and Num_Poliza = @num_poliza 
														and DEBE_HABER = 'H' and Activo = 'T'
														and (Id_Tipomov like '80_' or Id_Tipomov like '81_')  
														and Fecha_mov >= cast(@fecha as date) 
												) 

							select @iva_malla = @iva_int_ord_ingresos + @iva_int_ord_provision + @iva_int_mor_ingresos + @iva_int_mor_provision
	
							select @diferencia_iva = @iva_malla - @iva_ficha
	
							create table #temp_max(id int, monto money)
							insert into  #temp_max (id, monto) values  (1, @iva_int_ord_ingresos )
							insert into  #temp_max (id, monto) values  (2, @iva_int_ord_provision )
							insert into  #temp_max (id, monto) values  (3, @iva_int_mor_ingresos )
							insert into  #temp_max (id, monto) values  (4, @iva_int_mor_provision )
	
							select top 1 @id = id from #temp_max where monto = ( select max(monto) from #temp_max )
							update #temp_max set monto = monto - @diferencia_iva where id = @id

							select @iva_int_ord_ingresos	= coalesce(monto,0) from #temp_max where id = 1
							select @iva_int_ord_provision	= coalesce(monto,0) from #temp_max where id = 2
							select @iva_int_mor_ingresos	= coalesce(monto,0) from #temp_max where id = 3
							select @iva_int_mor_provision	= coalesce(monto,0) from #temp_max where id = 4
		
							drop table #temp_max

					-------------------------------------------------------------------------------------------------------------------------------------
					-- ORDINARIOS
					-------------------------------------------------------------------------------------------------------------------------------------
						-- si hay cancelacion de intereses ordinarios de orden
							if ( @int_ord_ingresos > 0 )
							begin
								-- asiento de ingresos moratorios
									insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
									select	top 1 0 as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, 
											@int_ord_ingresos as monto, @id_mov, 'H' as debe_haber, @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
											0 as id_convenio, @fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
									from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
									where	Numero_Fin_LACP = @Numero_Fin_LACP 
										and tipo_cuenta = @tipo_cta_ingresos_ordinarios --19--6 -- ingresos intereses ordinarios
										--and estatus_catera = 0 -- @estatus_cartera
				

									if  (@aplica_IVA = 1 and @iva_int_ord_ingresos > 0)
									begin
										insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
										select	top 1 800 as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, @iva_int_ord_ingresos  as monto, 
													@id_mov, 'H' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
													0 as id_convenio, @fecha as Fecha_mov , @fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
									from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
									where	Numero_Fin_LACP = 0 
										and tipo_cuenta = 4 -- iva por pagar
					
									end -- IF (@aplica_IVA  = 1)

							end -- if ( @int_ord_ingresos > 0 )
							
							if (@cv_diaria = 1)
							begin
								-- si son ingresos de un credito vencido hay cancelacion en cuentas de orden
								--if ( @son_ingresos_ord_de_orden = 1 )
								--	begin
									-- cancelacion de intereses de orden en ordinarios
									-- 606-xxx-xxxx INTERESES MORATORIO CONSUMO 
									if ( @int_ord_ingresos > 0 )
										begin
											insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
											select	top 1 0 as  id_tipomov, num_cuenta as cuenta, descripcion as concepto,
													@int_ord_ingresos as monto, @id_mov, 'H' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
													0 as id_convenio, @fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
											from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
											where	Numero_Fin_LACP = @Numero_Fin_LACP 
												and tipo_cuenta = 7 -- intereses moratorios
												and estatus_catera = 0 --@estatus_cartera

										-- 706-xxx-xxxx INTERESES MORATORIO CONSUMO 
											insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
											select	top 1 0 as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, 
													@int_ord_ingresos as monto, @id_mov, 'D' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
													0 as id_convenio, @fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
											from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
											where	Numero_Fin_LACP = @Numero_Fin_LACP 
												and tipo_cuenta = 8 -- intereses moratorios
												and estatus_catera = 0 --@estatus_cartera
										end  -- if ( @int_ord_ingresos > 0 )

									--end -- if ( @son_ingresos_de_orden = 1 )
							end  -- if (@cv_diaria = 1)

						-- si hay pago de intereses ordinarios que saldan cuentas de provision
							if ( @int_ord_provision > 0 ) 
							begin
								insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
								select	top 1	60+@id_mov as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, @int_ord_provision as monto, 
												@id_mov, 'H' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
												0 as id_convenio,@fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
								from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
								where	Numero_Fin_LACP = @Numero_Fin_LACP 
									and tipo_cuenta = 2 -- intereses ordinarios 
									and estatus_catera = @cv_diaria
			
							end -- if ( @int_ord_provision > 0 ) 

							if  (@aplica_IVA = 1 and @iva_int_ord_provision > 0)
							begin
								insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
								select	top 1 800 as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, @iva_int_ord_provision   as monto, 
											@id_mov, 'H' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
											0 as id_convenio,@fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
									from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
									where	Numero_Fin_LACP = 0 
											and tipo_cuenta = 4 -- iva por pagar
			
							end -- IF (@aplica_IVA  = 1)

					-------------------------------------------------------------------------------------------------------------------------------------
					-- MORATORIOS
					-------------------------------------------------------------------------------------------------------------------------------------
						-- si hay movimientos de cancelacion de orden moratorios
						if ( @int_mor_ingresos > 0 )
						begin 
							-- asiento de ingresos moratorios
								insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
								select	top 1 0 as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, 
										@int_mor_ingresos as monto, @id_mov, 'H' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
										0 as id_convenio, @fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
									from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
									where	Numero_Fin_LACP = @Numero_Fin_LACP 
										and tipo_cuenta = 20--5 -- ingresos intereses moratorios
										--and estatus_catera = 1 -- @estatus_cartera
			

								if  (@aplica_IVA = 1 and @iva_int_mor_ingresos > 0)
								begin

									insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
									select	top 1 810 as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, @iva_int_mor_ingresos    as monto, 
												@id_mov, 'H' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
												0 as id_convenio,@fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
									from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
									where	Numero_Fin_LACP = 0 
												and tipo_cuenta = 4 -- iva por pagar
				
								end -- IF (@aplica_IVA  = 1)

						end -- if ( @int_mor_ingresos > 0 )

						if (@cv_diaria = 1)
						begin
							--if ( @son_ingresos_mor_de_orden = 1 ) 
							--	begin
								-- asientos de cancelacion de intereses de orden moratorios
								if (@int_mor_ingresos > 0)
								-- 606-xxx-xxxx INTERESES MORATORIO CONSUMO 
									begin
										insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
										select	top 1 0 as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, 
												@int_mor_ingresos as monto, @id_mov, 'H' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
												0 as id_convenio, @fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
										from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
										where	Numero_Fin_LACP = @Numero_Fin_LACP 
											and tipo_cuenta = 7 -- intereses moratorios
											and estatus_catera = 1 --@estatus_cartera

								-- 706-xxx-xxxx INTERESES MORATORIO CONSUMO 
										insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
										select	top 1 0 as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, 
												@int_mor_ingresos as monto, @id_mov, 'D' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
												0 as id_convenio, @fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
										from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
										where	Numero_Fin_LACP = @Numero_Fin_LACP 
											and tipo_cuenta = 8 -- intereses moratorios
											and estatus_catera = 1 --@estatus_cartera
									end  -- if (@int_mor_ingresos > 0)
								--end -- if ( @son_ingresos_mor_de_orden = 1 ) 
						end  -- if (@cv_diaria = 1)

						-- si hay intereses moratorios que deben saldar cuentas de provision
						if ( @int_mor_provision > 0 )
						begin
							--print 'hay moratorio de provision'
						-- se inserta el movimiento de interes moratorio
							insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
							select	top 1 70+@id_mov as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, 
									@int_mor_provision as monto, @id_mov, 'H' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
									0 as id_convenio, @fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
									from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
									where	Numero_Fin_LACP = @Numero_Fin_LACP 
										and tipo_cuenta = 3 -- intereses moratorios
										and estatus_catera = @cv_diaria
		
							--select @iva_int_mor_provision iva_int_mor_provision, @aplica_IVA aplica_IVA
							if  (@aplica_IVA = 1 and @iva_int_mor_provision > 0)
							begin
								insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
								select	top 1 800 as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, @iva_int_mor_provision     as monto, 
											@id_mov, 'H' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
											0 as id_convenio,@fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
									from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
									where	Numero_Fin_LACP = 0 
											and tipo_cuenta = 4 -- iva por pagar
			
							end -- IF (@aplica_IVA  = 1)


						end --if ( @int_mor_provision > 0 )


					-------------------------------------------------------------------------------------------------------------------------------------
					-- CAPITAL
					-------------------------------------------------------------------------------------------------------------------------------------
						if ( @capital_vigente_ficha_saldado > 0)
						begin
							print 'hay cap vigente'
							insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
							select	top 1	30+@id_mov as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, @capital_vigente_ficha_saldado as monto, 
											@id_mov, 'H' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
											0 as id_convenio,@fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
							from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
							where	Numero_Fin_LACP =	case
															when @capital_adelanto > 0 then 0 -- 9 - Capital de adelanto
															else @Numero_Fin_LACP   --1  --f.Numero_Fin_LACP 
				 										end							
									and tipo_cuenta =		case
																when @capital_adelanto > 0 then 9 -- 9 - Capital de adelanto
																else 1  --1 -- cta de capital
															end							
									and estatus_catera =	case
																when @capital_adelanto > 0 then 0
																else @cv_diaria  --1 -- cta de capital
															end		
				
						end -- if ( @capital_vigente_ficha_saldado > 0)

						if ( @capital_vencido_ficha_saldado > 0)
						begin
							--print 'hay cap vencido'
							insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
							select	top 1	130+@id_mov as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, @capital_vencido_ficha_saldado as monto, 
											@id_mov, 'H' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA, 
											0 as id_convenio,@fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
									from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
									where	Numero_Fin_LACP = @Numero_Fin_LACP 
										and tipo_cuenta = 1 -- cta de capital
										and estatus_catera = case
																when @es_adelanto = 1 then 0
																else @cv_diaria
															 end
		
						end -- if ( @capital_vencido_ficha_saldado > 0)

						--------------------------------------------------------------------------------------------------------------------
						--	Corresponsalias 	
						--------------------------------------------------------------------------------------------------------------------
						-- si es un folio que viene de corresponsalias
						--select @id_origen id_origen
						if ( @id_origen = 2 )
						begin
							select top 1 @cta_prosa_corresponsalias = num_cuenta, 
										 @desc_prosa_corresponsalias = descripcion 
							from		 TBL_CUENTAS_CONTABLES_INTERES_DIARIO 
							where		 tipo_cuenta = 15
			
							-- se cambia cuenta, concepto y ccostos segun malla proporcionada
							update	#tbl_interes_diario_captura_lacp_aux 
							set		Cuenta = @cta_prosa_corresponsalias,
									Concepto = @desc_prosa_corresponsalias,
									Ccostos = @ccostos_medpa
							where	id_tipomov = 961
								and	Numero		= @numero 
								and Num_ptmo	= @num_ptmo
								and	Num_Poliza	= @num_poliza
								and Num_ptmo	= @num_ptmo
								and cast(Fecha_mov as date) = CAST(@fecha as date)


							-- obtenemos el monto de la ficha 
							select  top 1	@tot_depositos = Total_ficha
							from			captura 
							where			Numero = @numero and Folio = @folio and Num_Poliza = @num_poliza and Activo = 'T'
											and convert(datetime,CONVERT(varchar(10), FECHA_MOV, 103),103) >= cast(@fecha as date)  

							-- se insertan los registros de compensaciones del ccostos de MEDPA
							---- 141-010-0007-	'H'
							insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
							select	top 1 0 as  id_tipomov, @cta_compensacion_destino as cuenta, @concepto_compensacion_destino as concepto, 
									@tot_depositos as monto, @id_mov, 'H' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA,  
									0 as id_convenio, @fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
									from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
									where	Numero_Fin_LACP = 0 
										and tipo_cuenta = 15 -- 14100601770000 DEUDORES DEBITO PROSA
										and estatus_catera = 0 -- @estatus_cartera
		
							---- 141-010-0099-	MEDIOS DE PAGO - 'D'
							insert into #tbl_interes_diario_captura_lacp_aux ( id_tipomov,cuenta,concepto,monto,id_mov,debe_haber,numero_fin_lacp,ccostos,id_esquema,id_convenio,Fecha_mov,FECHA_ALTA,Numero,Num_ptmo,Num_Poliza,Folio )		
							select	top 1 0 as  id_tipomov, num_cuenta as cuenta, descripcion as concepto, 
									@tot_depositos as monto, @id_mov, 'D' as debe_haber,  @Numero_Fin_LACP as numero_fin_lacp, @ccostos_socio as CCOSTOS, @id_esquema as ID_ESQUEMA,  
									0 as id_convenio, @fecha as Fecha_mov ,@fecha as FECHA_ALTA,@Numero,@Num_ptmo,@Num_Poliza,@Folio
									from	TBL_CUENTAS_CONTABLES_INTERES_DIARIO
									where	Numero_Fin_LACP = 0 
										and tipo_cuenta = 16 -- 141-010-0099-	MEDIOS DE PAGO
										and estatus_catera = 0 -- @estatus_cartera
		

						end -- if ( @id_origen = 2 )
						--------------------------------------------------------------------------------------------------------------------

					------------------------------------------------------------------------------------------
					-- se actualizan los datos q son genericos para la caida contable de interes diario
					------------------------------------------------------------------------------------------
						update	#tbl_interes_diario_captura_lacp_aux
						set		Id_persona = a.Id_persona, Activo = a.Activo, Numero = a.Numero, Nombre_s= a.Nombre_s,
								Apellido_paterno = a.Apellido_paterno,Apellido_materno = a.Apellido_materno,
								Total_ficha = a.Total_ficha, Neto = a.Neto, Banco = a.Banco,clave_Local = a.clave_Local,
								Linea = a.Linea,Num_Poliza = a.Num_Poliza,Tipo_poliza = a.Tipo_poliza,Folio = a.Folio,
								Id_Tipo_persona = a.Id_Tipo_persona,Num_cheq = a.Num_cheq,Desc1 = a.Desc1,Desc2 = a.Desc2,
								planx = a.planx,Aval1_socio = a.Aval1_socio,Aval1_numero = a.Aval1_numero,
								Aval2_socio = a.Aval2_socio,Aval2_numero = a.Aval2_numero,Desc3 = a.Desc3,Desc4 = a.Desc4,
								FECHA_DPF_final = a.FECHA_DPF_final,NUM_DPF = a.NUM_DPF,TASA = a.TASA,INTERES = a.INTERES,
								DIAS = a.DIAS,NUMUSUARIO = a.NUMUSUARIO,PROCESADO = a.PROCESADO,numero_Fin = a.numero_Fin,
								numero_fin2 = a.numero_fin2,Plazo = a.Plazo,Interes_ord = a.Interes_ord,
								Interes_mor = a.Interes_mor,Monto2 = a.Monto2,Plazo2 = a.Plazo2,Interes_ord2 = a.Interes_ord2,
								Interes_mor2 = a.Interes_mor2,Aval1_avalados = a.Aval1_avalados,Aval2_avalados = a.Aval2_avalados,
								Fec_inicio = a.Fec_inicio,Fec_prog = a.Fec_prog,Contador_provision = a.Contador_provision,
								NOMBRE_BENEFICIARIO = a.NOMBRE_BENEFICIARIO,
								PARENTESCO_BENEFICIARIO = a.PARENTESCO_BENEFICIARIO,PORCENTAJE_BENEFICIARIO = a.PORCENTAJE_BENEFICIARIO,
								NOMBRE_BENEFICIARIO2 = a.NOMBRE_BENEFICIARIO2,PARENTESCO_BENEFICIARIO2 = a.PARENTESCO_BENEFICIARIO2,
								PORCENTAJE_BENEFICIARIO2 = a.PORCENTAJE_BENEFICIARIO2,Id_Sol = a.Id_Sol,Numero_Fin_LACP = a.Numero_Fin_LACP,
								Reestructura = a.Reestructura,Id_Motivo_Reestructura = a.Id_Motivo_Reestructura,Id_Esquema = a.Id_Esquema,
								Id_Convenio = a.Id_Convenio,Id_Amortizacion = a.Id_Amortizacion,Ent_Federativa = a.Ent_Federativa,
								Cve_Municipio = a.Cve_Municipio,Cve_Localidad = a.Cve_Localidad,Identificador = a.Identificador,
								Transferencia = a.Transferencia,Fecha_Pago = a.Fecha_Pago,Bimestre = a.Bimestre,Referencia = a.Referencia,
								Cve_Archivo = a.Cve_Archivo,Impreso = a.Impreso,Folio_Impresion = a.Folio_Impresion,
								Documentacion = a.Documentacion,dpf_en_garantia = a.dpf_en_garantia,Titular = a.Titular,
								Id_Nomina = a.Id_Nomina,Id_Esquema_Nomina = a.Id_Esquema_Nomina,Id_Leyenda = a.Id_Leyenda,
								Num_ptmo = @num_ptmo,Id_Renovado = a.Id_Renovado,Ahorro_Base = a.Ahorro_Base,
								Tasa_Pasiva = a.Tasa_Pasiva,Id_Fondeador = a.Id_Fondeador,Numero_Fondeo = a.Numero_Fondeo,
								id_origen = a.id_origen, id_tipo_pago_prestamo = a.id_tipo_pago_prestamo
						from	(
									select top 1	Id_persona,Activo,Numero,Nombre_s,Apellido_paterno,Apellido_materno,Total_movs,Total_ficha,Id_Tipomov,Cuenta,Concepto,
											Fecha_mov,Monto,Neto,ID_mov,Banco,clave_Local,Linea,Num_Poliza,Tipo_poliza,Folio,Id_Tipo_persona,Num_cheq,Desc1,Desc2,
											planx,Aval1_socio,Aval1_numero,Aval2_socio,Aval2_numero,Desc3,Desc4,FECHA_DPF_final,NUM_DPF,TASA,INTERES,DIAS,DEBE_HABER,
											NUMUSUARIO,PROCESADO,FECHA_ALTA,numero_Fin,numero_fin2,Plazo,Interes_ord,Interes_mor,Monto2,Plazo2,Interes_ord2,
											Interes_mor2,Aval1_avalados,Aval2_avalados,Fec_inicio,Fec_prog,Contador_provision,NOMBRE_BENEFICIARIO,
											PARENTESCO_BENEFICIARIO,PORCENTAJE_BENEFICIARIO,NOMBRE_BENEFICIARIO2,PARENTESCO_BENEFICIARIO2,PORCENTAJE_BENEFICIARIO2,
											Id_Sol,Numero_Fin_LACP,Reestructura,Id_Motivo_Reestructura,Id_Esquema,Id_Convenio,Id_Amortizacion,Ent_Federativa,
											Cve_Municipio,Cve_Localidad,Identificador,Transferencia,Fecha_Pago,Bimestre,Referencia,Cve_Archivo,Impreso,Folio_Impresion,
											Documentacion,dpf_en_garantia,Titular,Id_Nomina,Id_Esquema_Nomina,Id_Leyenda,Num_ptmo,Id_Renovado,Ahorro_Base,
											Tasa_Pasiva,Id_Fondeador,Numero_Fondeo,id_origen,id_tipo_pago_prestamo 
									from	captura 
									where	Numero = @numero and Folio = @folio and Num_Poliza = @num_poliza and Activo = 'T' and Fecha_mov >= cast(@fecha as date)
											AND (
												Id_Tipomov NOT LIKE '3_' OR -- CAPITAL
												Id_Tipomov NOT LIKE '6_' OR -- INTERES ORDINARIO
												Id_Tipomov NOT LIKE '7_' OR -- INTERES MORATORIO
												Id_Tipomov NOT LIKE '13_' OR -- ABONO VENCIDO
												Id_Tipomov NOT LIKE '23_' OR -- PAGO CARTERA VENCIDA
												Id_Tipomov NOT LIKE '53_' OR -- QUITAS ??ESTO SI VA???
												Id_Tipomov NOT LIKE '80_' OR -- IVA POR INTERES ORDINARIO
												Id_Tipomov NOT LIKE '81_'  -- IVA POR INTERES MORATORIO
											)
								)A
						where	#tbl_interes_diario_captura_lacp_aux.Numero		= @numero 
							and #tbl_interes_diario_captura_lacp_aux.Num_ptmo	= @num_ptmo
							and	#tbl_interes_diario_captura_lacp_aux.Num_Poliza	= @num_poliza
							and #tbl_interes_diario_captura_lacp_aux.Num_ptmo	= @num_ptmo
							and cast(#tbl_interes_diario_captura_lacp_aux.Fecha_mov as date) = CAST(@fecha as date)


						-- se actualiza el tipo de poliza para cuando son caidas de orden
							update	#tbl_interes_diario_captura_lacp_aux
							set		Tipo_poliza = 'O'
							where	cuenta like '6%' or Cuenta like '7%'
								and	Numero		= @numero 
								and Num_ptmo	= @num_ptmo
								and	Num_Poliza	= @num_poliza
								and Num_ptmo	= @num_ptmo
								and cast(Fecha_mov as date) = CAST(@fecha as date)

						-- se actualiza cuenta contable para cuando es adelanto
							update	#tbl_interes_diario_captura_lacp_aux
							set		cuenta = @cta_adelanto
							where	(Id_Tipomov like '14_' or Id_Tipomov like '15_')
								and Numero		= @numero 
								and Num_ptmo	= @num_ptmo
								and	Num_Poliza	= @num_poliza
								and Num_ptmo	= @num_ptmo
								and cast(Fecha_mov as date) = CAST(@fecha as date)

						-- se actualizan el numero de movimientos en captura lacp
							update	#tbl_interes_diario_captura_lacp_aux
							set		total_movs = ( select count(1) from #tbl_interes_diario_captura_lacp_aux 					
													where	Numero		= @numero 
														and Num_ptmo	= @num_ptmo
														and	Num_Poliza	= @num_poliza
														and Num_ptmo	= @num_ptmo
														and cast(Fecha_mov as date) = CAST(@fecha as date)
												 )
							where	Numero		= @numero 
								and Num_ptmo	= @num_ptmo
								and	Num_Poliza	= @num_poliza
								and Num_ptmo	= @num_ptmo
								and cast(Fecha_mov as date) = CAST(@fecha as date)

							select @diferencia_redondeo_  = (cast((select sum(monto) from #tbl_interes_diario_captura_lacp_aux where debe_haber = 'H') as decimal(30,2)))
												- (cast((select sum(monto) from #tbl_interes_diario_captura_lacp_aux where debe_haber = 'D') as decimal(30,2)))
                                        
							if
								(  
								(cast((select sum(monto) from #tbl_interes_diario_captura_lacp_aux where debe_haber = 'H') as decimal(30,2))
								!= cast((select sum(monto) from #tbl_interes_diario_captura_lacp_aux where debe_haber = 'D') as decimal(30,2)))
								and ABS(@diferencia_redondeo_) > 0.01
								)

								begin -- no cuadran cargos y abonos

									raiserror('Los montos totales de cargos y abonos son diferentes.', 11, 0)

								end -- no cuadran cargos y abonos


							insert into  CAPTURA_lacp (	Id_persona,Activo,Numero,Nombre_s,Apellido_paterno,Apellido_materno,Total_movs,Total_ficha,
														Id_Tipomov,Cuenta,Concepto,Fecha_mov,Monto,Neto,ID_mov,Banco,clave_Local,Linea,Num_Poliza,Tipo_poliza,
														Folio,Id_Tipo_persona,Num_cheq,Desc1,Desc2,planx,Aval1_socio,Aval1_numero,Aval2_socio,Aval2_numero,
														Desc3,Desc4,FECHA_DPF_final,NUM_DPF,TASA,INTERES,DIAS,DEBE_HABER,NUMUSUARIO,PROCESADO,FECHA_ALTA,
														numero_Fin,numero_fin2,Plazo,Interes_ord,Interes_mor,Monto2,Plazo2,Interes_ord2,Interes_mor2,Aval1_avalados,
														Aval2_avalados,Fec_inicio,Fec_prog,Contador_provision,Ccostos,NOMBRE_BENEFICIARIO,PARENTESCO_BENEFICIARIO,
														PORCENTAJE_BENEFICIARIO,NOMBRE_BENEFICIARIO2,PARENTESCO_BENEFICIARIO2,PORCENTAJE_BENEFICIARIO2,Id_Sol,
														Numero_Fin_LACP,Reestructura,Id_Motivo_Reestructura,Id_Esquema,Id_Convenio,Id_Amortizacion,Ent_Federativa,
														Cve_Municipio,Cve_Localidad,Identificador,Transferencia,Fecha_Pago,Bimestre,Referencia,Cve_Archivo,Impreso,
														Folio_Impresion,Documentacion,dpf_en_garantia,Titular,Id_Nomina,Id_Esquema_Nomina,Id_Leyenda,Num_ptmo,
														Id_Renovado,Ahorro_Base,Tasa_Pasiva,Id_Fondeador,Numero_Fondeo,id_origen,id_tipo_pago_prestamo
														)
							select	Id_persona,Activo,Numero,Nombre_s,Apellido_paterno,Apellido_materno,Total_movs,Total_ficha,
									Id_Tipomov,Cuenta,Concepto,Fecha_mov,Monto,Neto,ID_mov,Banco,clave_Local,Linea,Num_Poliza,Tipo_poliza,
									Folio,Id_Tipo_persona,Num_cheq,Desc1,Desc2,planx,Aval1_socio,Aval1_numero,Aval2_socio,Aval2_numero,
									Desc3,Desc4,FECHA_DPF_final,NUM_DPF,TASA,INTERES,DIAS,DEBE_HABER,NUMUSUARIO,PROCESADO,FECHA_ALTA,
									numero_Fin,numero_fin2,Plazo,Interes_ord,Interes_mor,Monto2,Plazo2,Interes_ord2,Interes_mor2,Aval1_avalados,
									Aval2_avalados,Fec_inicio,Fec_prog,Contador_provision,Ccostos,NOMBRE_BENEFICIARIO,PARENTESCO_BENEFICIARIO,
									PORCENTAJE_BENEFICIARIO,NOMBRE_BENEFICIARIO2,PARENTESCO_BENEFICIARIO2,PORCENTAJE_BENEFICIARIO2,Id_Sol,
									Numero_Fin_LACP,Reestructura,Id_Motivo_Reestructura,Id_Esquema,Id_Convenio,Id_Amortizacion,Ent_Federativa,
									Cve_Municipio,Cve_Localidad,Identificador,Transferencia,Fecha_Pago,Bimestre,Referencia,Cve_Archivo,Impreso,
									Folio_Impresion,Documentacion,dpf_en_garantia,Titular,Id_Nomina,Id_Esquema_Nomina,Id_Leyenda,Num_ptmo,
									Id_Renovado,Ahorro_Base,Tasa_Pasiva,Id_Fondeador,Numero_Fondeo,id_origen,id_tipo_pago_prestamo
							from	#tbl_interes_diario_captura_lacp_aux
							where	Numero		= @numero 
								and Num_ptmo	= @num_ptmo
								and	Num_Poliza	= @num_poliza
								and Num_ptmo	= @num_ptmo
								and cast(Fecha_mov as date) = CAST(@fecha as date)

							drop table #tbl_interes_diario_captura_lacp_aux

				end -- saldado captura lacp

				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end

			select @status = coalesce(@status, 0)
						
			-- revertir transacci�n si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status

			set nocount off

			insert	#procedimiento_pago_credito
					(
					status,
					error_procedure,
					error_line,
					error_severity,
					error_message
					)
			select	@status,
					@error_procedure,
					@error_line,
					@error_severity,
					@error_message

			if @standalone = 1
		
				select	*
				from	#procedimiento_pago_credito

		end -- reporte de status
		
	end -- procedimiento


go