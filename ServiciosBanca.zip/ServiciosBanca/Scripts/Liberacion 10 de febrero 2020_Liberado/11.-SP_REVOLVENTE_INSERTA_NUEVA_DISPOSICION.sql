USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_REVOLVENTE_INSERTA_NUEVA_DISPOSICION]    Script Date: 12/03/2020 02:41:39 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Mar Mej�a Murillo
UsuarioRed		memm373565
Fecha			20170106
Objetivo		Insertar una nueva disposici�n de la l�nea de cr�dito indicada
Proyecto		Cr�dito revolvente
Ticket			204020

*/

ALTER proc

	[dbo].[SP_REVOLVENTE_INSERTA_NUEVA_DISPOSICION]
	
		-- par�metros
		@id_linea				bigint,
		@numero					int,
		@monto					money,
		@numusuario				int,
		@folio					int,
		@num_poliza				int,
		@contador_provision		int,
		@id_tipo_persona		int = null,
		@fecha					datetime = null,
		@autorizo				int = null,
		@id_origen				int = null

as

	begin -- procedimiento

		-- bloque principal
		begin try
		
			-- declaraciones internas
			declare	@status int = 1,
					@error_message varchar(255) = '',
					@error_line varchar(255) = '',
					@error_severity varchar(255) = '',
					@error_procedure varchar(255) = ''
					
			-- declaraciones transaccionales
			declare	@tran_name varchar(32) = 'INSERTA_NUEVA_DISPOSICION',
					@tran_count int = @@trancount,
					@tran_scope bit = 0,
					@porcentaje_disposicion float=0

			-- valores por defecto
			select	@id_tipo_persona = coalesce(@id_tipo_persona, 1),
					@fecha = coalesce(@fecha, getdate()),
					@id_origen = coalesce(@id_origen, 1)
			
			select @porcentaje_disposicion=coalesce(porcentaje_disposicion,0) from TBL_REVOLVENTE_LINEAS_CREDITO
				where id_linea=@id_linea
				
			if @porcentaje_disposicion<=0 
			begin
				raiserror('El porcentaje de la disposicion no puede ser cero',11,0)
			end	

			IF EXISTS(SELECT 1 FROM MOVIMIENTOS WHERE Numero=@numero AND Folio=@folio AND Numusuario=@numusuario AND CAST(Fecha_Mov AS date)=CAST(@fecha AS DATE))
			begin
				raiserror('Error Movimiento duplicado',11,0)
			end

			-- declaraciones auxiliares

			declare @disponible				money,
					@capital_disponible		money,
					@tasa_ord				decimal(7, 2),
					@pago_minimo			money = ceiling(@monto * @porcentaje_disposicion) / 100.00,
					@numemp					int,
					@id_rol					int,
					@id_de_sucursal			int,
					@num_ptmo				varchar(14),
					@dia_corte				int,
					@dia_limite				int,
					@fecha_corte			datetime,
					@fecha_limite			datetime,
					@errors_3				int = 0,
					@planx					varchar(1),
					@tasa_mor				decimal(7, 2),
					@cuenta_revolvente		varchar(14) = '13100300010000',
					@cuenta_orden_debe		varchar(14) = '70800200000000',
					@cuenta_orden_haber		varchar(14) = '60800200000000',
					@cuenta_inverdinamica	varchar(14) = '21100000000000',
					@cuenta_cajas			varchar(14) = '11100100000000',
					@id_disposicion			bigint,
					@pago_minimo_completo	money = 0,
					@count					int = 0,
					@avalado				int,
					@pago_liquidacion		money = 0
					--@cadena_avalado			varchar(255)

			begin -- tabla de resultados

				declare @standalone bit = 1, @sql nvarchar(4000) = 'delete #sp_revolvente_inserta_nueva_disposicion'

				begin try -- revisar si existe tabla de resultados

					exec (@sql)

					select @standalone = 0

				end try -- revisar si existe tabla de resultados

				begin catch -- si no existe tabla de resultados

					create table
						#sp_revolvente_inserta_nueva_disposicion
							(
							status			int null,
							error_procedure	varchar(255) null,
							error_line		varchar(255) null,
							error_severity	varchar(255) null,
							error_message	varchar(255) null,
							id_disposicion	int null,
							)

				end catch -- si no existe tabla de resultados

			end -- tabla de resultados

			create table
				#obtiene_limites
					(
					id_linea			bigint null,
					id_estado			bit null,
					pago_minimo			money null,
					pago_liquidacion	money null,
					)

			exec sp_revolvente_obtiene_limites @numero, @id_tipo_persona, @fecha

			select	@pago_liquidacion = pago_liquidacion,
					@pago_minimo_completo = pago_minimo
			from	#obtiene_limites

			select	@tasa_ord = tasa_ord,
					@tasa_mor = tasa_mor,
					@num_ptmo = num_ptmo,
					@dia_corte = dia_corte,
					@dia_limite = dia_limite,
					@planx = planx,
					/* Modificaci�n - 20171005 - memm373565 - ticket 204020 - Se pide que el disponible se conforme por la diferencia de l�mite de cr�dito menos saldo actual */
--					@disponible = round(limite_credito - @pago_liquidacion, -2, 1),
					@disponible = round(limite_credito - saldo_actual, -2, 1),
					@capital_disponible = limite_credito - saldo_actual
			from	TBL_REVOLVENTE_LINEAS_CREDITO
			where	id_linea = @id_linea
					and numero = @numero
					and id_tipo_persona = @id_tipo_persona

			select	@fecha_corte = cast(year(@fecha) as varchar) + right('00' + cast(month(@fecha) as varchar), 2) + right('00' + cast(@dia_corte as varchar), 2)

			if @fecha_corte < cast(@fecha as date) ------------------------------ pendiente checar comportamiento @fecha_corte = @fecha
				select @fecha_corte = dateadd(mm, 1, @fecha_corte)

			select	@fecha_limite = cast(year(@fecha_corte) as varchar) + right('00' + cast(month(@fecha_corte) as varchar), 2) + right('00' + cast(@dia_limite as varchar), 2)

			if @fecha_limite < @fecha_corte
				select @fecha_limite = dateadd(mm, 1, @fecha_limite)

			select	@numemp = numemp,
					@id_rol = id_rol,
					@id_de_sucursal = id_de_sucursal
			from	claves
			where	numusuario = @numusuario

			declare	@mensaje_1 varchar(255) = 'No existe el @id_linea indicado [ ' + cast(@id_linea as varchar(50)) + ' ] para el @numero de '
						+ case when @id_tipo_persona = 7 then 'persona moral' when @id_tipo_persona = 1 then 'socio' end
						+ ' indicado [ ' + cast(@numero as varchar(50)) + ' ]',
					@mensaje_2 varchar(255) = 'El monto indicado [ ' + cast(@monto as varchar(50)) + ' ] excede el monto disponible [ ' + cast(@disponible as varchar(50)) + ' ]',
					@mensaje_3 varchar(255) = 'El [@contador_provision|@num_poliza|@folio] indicados no ',
					@mensaje_4 varchar(255) = 'Error al insertar la disposici�n',
					@mensaje_5 varchar(255) = 'Error al actualizar la l�nea de cr�dito',
					@mensaje_6 varchar(255) = 'Error al insertar la acci�n',
					@mensaje_7 varchar(255) = 'Error al insertar el resguardo de la l�nea de cr�dito',
					@mensaje_8 varchar(255) = 'Error al insertar en CAPTURA y/o CAPTURA_LACP',
					@mensaje_9 varchar(255) = 'Error al insertar en MOVIMIENTOS',
					@mensaje_10 varchar(255) = 'Error al actualizar en EDO_DE_CUENTA',
					@mensaje_11 varchar(255) = 'Error al insertar el nuevo ciclo de facturaci�n',
					@mensaje_12 varchar(255) = 'Error al actualizar en FOLIOS',
					@mensaje_13 varchar(255) = 'El monto indicado [ ' + cast(@monto as varchar(50)) + ' ] no es m�ltiplo de 100.00;
sugerencias:
	' + cast(round(@monto, -2, 1) as varchar(50)) + '
	' + cast(round(@monto, -2, 1) + 100 as varchar(50)),
					@mensaje_14 varchar(255) = 'No se cumplen pol�ticas para nueva disposici�n ['
			
			-- validaci�n de par�metros

			-- validar la existencia de la l�nea
			if not exists (select * from tbl_revolvente_lineas_credito where id_linea = @id_linea and numero = @numero and id_tipo_persona = @id_tipo_persona)
				raiserror (@mensaje_1, 11, 0)

			-- validar que el monto a disponer se encuentre disponible
			if @monto > @disponible
				raiserror (@mensaje_2, 11, 0)

			-- validar que sea multiplo de 100
			if cast(@monto * cast(100 as money) as int) % 10000 != 0
				raiserror (@mensaje_13, 11, 0)

			-- validar contador_provision, num_poliza, folio
			if @num_poliza is null or @num_poliza = 0
				select @errors_3 = @errors_3 + 1

			if @folio is null or @folio = 0
				select @errors_3 = @errors_3 + 1

			if (@contador_provision is null or @contador_provision = 0) and @id_origen = 1
				select @errors_3 = @errors_3 + 1

			-- validar que no tenga pago m�nimo pendiente------------------------------------------------------------- se comenta por ahora!!!!!!

			--select	@pago_minimo_completo = 0--pago_minimo------------------------------------------------------------- se comenta por ahora!!!!!!
			--from	#obtiene_limites

			if coalesce(@pago_minimo_completo, 0) > 0 and exists (select 1 from VW_REVOLVENTE_CICLOS where id_linea = @id_linea and fecha_limite < cast(@fecha as date) and capital > 0)
			--if coalesce(@pago_minimo_completo, 0) > 0 and exists (select 1 from VW_REVOLVENTE_CICLOS where id_linea = @id_linea and fecha_corte !> @fecha and capital > 0)

				begin

					select @mensaje_14 = @mensaje_14 + 'No se ha saldado el pago m�nimo]'
					raiserror (@mensaje_14, 11, 0)

				end

			---- validar que la l�nea no est� suspendida o cancelada
			--if not exists (select * from tbl_revolvente_lineas_credito where id_linea = @id_linea and numero = @numero and id_tipo_persona = @id_tipo_persona and id_estado = 1)

			--	begin

			--		select @mensaje_14 = @mensaje_14 + 'La l�nea se encuentra suspendida o cancelada]'
			--		raiserror (@mensaje_14, 11, 0)

			--	end

			---- validar que el socio no tenga mora en sus otros cr�ditos vigentes

			--if coalesce((select sum(saldo_actual) from edo_de_cuenta where numero = @numero and id_mov < 10 and dias_vencidos > 0), 0) > 0

			--	begin

			--		select @mensaje_14 = @mensaje_14 + 'El socio presenta mora en otros cr�ditos]'
			--		raiserror (@mensaje_14, 11, 0)

			--	end

			---- validar que los cr�ditos avalados por el socio no est�n en mora ---------------------------- revisar con Roberto

			--select	*
			--into	#avalados_
			--from	edo_de_cuenta
			--where	aval1 like 's' + cast(@numero as varchar(10))
			--		or aval2 like 's' + cast(@numero as varchar(10))

			--select	distinct numero, id_tipo_persona, cast(null as varchar(100)) nombre, null dias_vencidos, null ptmos_vencidos
			--into	#avalados
			--from	#avalados_

			--update	a
			--set		a.nombre = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(coalesce(p.Nombre_s, ''))) + ' ' + ltrim(rtrim(coalesce(p.apellido_paterno, ''))))) + ' ' + ltrim(rtrim(coalesce(p.apellido_materno, ''))))),
			--		a.dias_vencidos = coalesce(_.dias_vencidos, 0),
			--		a.ptmos_vencidos = coalesce(_.ptmos_vencidos, 0)
			--from	#avalados a
			--		join persona p
			--			on p.numero = a.numero
			--			and p.id_tipo_persona = a.id_tipo_persona
			--		left join
			--			(
			--			select	numero,
			--					id_tipo_persona,
			--					count(1) ptmos_vencidos,
			--					sum(coalesce(dias_vencidos, 0)) dias_vencidos
			--			from	edo_de_cuenta
			--			where	numero in
			--						(
			--						select	numero
			--						from	#avalados
			--						)
			--					and Id_Tipo_persona = @id_tipo_persona
			--					and id_mov < 100
			--					and Dias_Vencidos > 0
			--			group by
			--					numero,
			--					Id_Tipo_persona
			--			) _
			--			on _.numero = a.numero
			--			and _.Id_Tipo_persona = a.Id_Tipo_persona

			--select @count = count(1) from #avalados where dias_vencidos > 0

			--if @count > 0

			--	begin

			--		if @count = 1

			--			begin

			--				select @avalado = min(numero) from #avalados

			--				select @mensaje_14 = @mensaje_14 + 'Avalado se encuentra en atraso: '

			--				select @mensaje_14 = @mensaje_14 + (select cast(numero as varchar(10)) + ' ' + nombre + '' from #avalados where numero = @avalado)

			--				select @mensaje_14 = substring(@mensaje_14, 1, len(@mensaje_14) - 1) + ']'

			--				raiserror (@mensaje_14, 11, 0)

			--			end

			--		else

			--			begin

			--				select @avalado = min(numero) from #avalados

			--				select @mensaje_14 = @mensaje_14 + 'Avalados se encuentran en atraso: '

			--				while @avalado is not null

			--					begin

			--						select @mensaje_14 = @mensaje_14 +(select cast(numero as varchar(10)) + ' ' + nombre + '; ' from #avalados where numero = @avalado)

			--						select @avalado = min(numero) from #avalados where numero > @avalado

			--					end

			--				select @mensaje_14 = substring(@mensaje_14, 1, len(@mensaje_14) - 1) + ']'

			--				raiserror (@mensaje_14, 11, 0)

			--			end

			--	end

			if @errors_3 > 0

				begin

				select @mensaje_3 = @mensaje_3 + case when @errors_3 = 1 then 'es correcto' else 'son correctos' end
				raiserror (@mensaje_3, 11, 0)

				end

			-- inicia preparaci�n

			-- se crea tabla de mapeo de captura
			select	cast(contador as int) contador, id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov,
					cuenta, concepto, fecha_mov, monto, neto, id_mov, banco, clave_local, linea, num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1,
					desc2, planx, aval1_socio, aval1_numero, aval2_socio, aval2_numero, desc3, desc4, fecha_dpf_final, num_dpf, tasa, interes, dias, debe_haber,
					numusuario, procesado, fecha_alta, numero_fin, numero_fin2, plazo, interes_ord, interes_mor, monto2, plazo2, interes_ord2, interes_mor2,
					aval1_avalados, aval2_avalados, fec_inicio, fec_prog, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario,
					porcentaje_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, porcentaje_beneficiario2, id_sol, numero_fin_lacp, reestructura,
					id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, ent_federativa, cve_municipio, cve_localidad, identificador, transferencia,
					fecha_pago, bimestre, referencia, cve_archivo, impreso, folio_impresion, documentacion, dpf_en_garantia, titular, id_nomina, id_esquema_nomina,
					id_leyenda, num_ptmo, id_renovado, ahorro_base, tasa_pasiva, id_fondeador, numero_fondeo, id_origen, id_tipo_pago_prestamo
			into	#captura
			from	captura
			where	1 = 0

			-- contraparte revolvente
			insert	#captura
					(
					contador, id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
					num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
					numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, id_origen
					)
			select	1, id_persona, 'T', numero, nombre_s, apellido_paterno, apellido_materno, 3, 0, 1100, @cuenta_revolvente, 'Disposici�n de Cr�dito Revolvente', @fecha, @monto, 10,
					@num_poliza, 'M', @folio, @id_tipo_persona, 0, '', convert(varchar, @fecha, 112), '', @planx, '', 0, 0, 0, 0, 'D', @numusuario, @fecha,
					0, 0, @tasa_ord, @tasa_mor, @contador_provision, suc.ccostos, '', '', '', '', 0, 'T', @id_origen
			from	persona per
					join sucursales suc
						on suc.id_de_sucursal = per.id_de_sucursal
			where	numero = @numero
					and id_tipo_persona = @id_tipo_persona

			-- contraparte inverdin�mica
			insert	#captura
					(
					contador, id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
					num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
					numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, id_origen
					)
			select	2, id_persona, 'T', numero, nombre_s, apellido_paterno, apellido_materno, 3, 0, 1151, @cuenta_inverdinamica, 'Dep�sito por disposici�n LCR', @fecha, @monto, 103,
					@num_poliza, 'M', @folio, @id_tipo_persona, 0, '', convert(varchar, @fecha, 112), '', @planx, '', 0, 0, 0, 0, 'H', @numusuario, @fecha,
					0, 0, 0, 0, @contador_provision, suc.ccostos, '', '', '', '', 0, 'T', @id_origen
			from	persona per
					join sucursales suc
						on suc.id_de_sucursal = per.id_de_sucursal
			where	numero = @numero
					and id_tipo_persona = @id_tipo_persona

			-- contraparte cajas
			insert	#captura
					(
					contador, id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
					num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
					numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, id_origen
					)
			select	3, id_persona, 'T', numero, nombre_s, apellido_paterno, apellido_materno, 3, 0, 961, @cuenta_cajas, 'Cajas', @fecha, 0, 0,
					@num_poliza, 'M', @folio, @id_tipo_persona, 0, '', convert(varchar, @fecha, 112), '', @planx, '', 0, 0, 0, 0, 'H', @numusuario, @fecha,
					0, 0, 0, 0, @contador_provision, suc.ccostos, '', '', '', '', 0, 'T', @id_origen
			from	persona per
					join sucursales suc
						on suc.id_de_sucursal = per.id_de_sucursal
			where	numero = @numero
					and id_tipo_persona = @id_tipo_persona

			-- crear tabla de ciclos de facturaci�n
			create table
				#ciclos_facturacion
					(
					num_ciclo					int identity(1, 1) primary key,
					id_disposicion				bigint null,
					capital						money null,
					fecha_corte					datetime null,
					fecha_limite				datetime null,
					int_mor_acum				money null,
					int_mor_acum_precision		money null,
					fecha_acum_int_mor			datetime null,
					activo						bit null,
					)


			declare @ix int = ceiling(@monto/@pago_minimo)--20
			declare @respClicosint int=@ix

			while @ix > 0

				begin

				insert	#ciclos_facturacion
						(id_disposicion, capital, fecha_corte, fecha_limite, int_mor_acum, int_mor_acum_precision, activo)
				values
						(@id_disposicion, @pago_minimo, @fecha_corte, @fecha_limite, 0, 0, 1)

				select @ix = @ix - 1

				end

			update	#ciclos_facturacion
			set		fecha_corte = dateadd(mm, num_ciclo - 1, fecha_corte),
					fecha_limite = dateadd(mm, num_ciclo - 1, fecha_limite)

			update	#ciclos_facturacion
			set		capital = (select @monto - sum(capital) from #ciclos_facturacion where num_ciclo != 20)
			where	num_ciclo = @respClicosint--20

			

			-- inicia transacci�n
			if @tran_count = 0 begin tran @tran_name
			else save tran @tran_name
			
				begin
				
				select @tran_scope = 1
				
				-- salvar estado anterior de la l�nea
				select	*
				into	#linea_antes
				from	TBL_REVOLVENTE_LINEAS_CREDITO
				where	id_linea = @id_linea
						and numero = @numero
						and id_tipo_persona = @id_tipo_persona 

				-- insertar en TBL_REVOLVENTE_DISPOSICIONES
				begin try
	
				insert	TBL_REVOLVENTE_DISPOSICIONES
						(
						id_linea,
						monto_disposicion,
						saldo_actual,
						fecha_disposicion,
						tasa_ord,
						tasa_mor,
						int_ord_vig_acum,
						int_ord_vig_acum_precision,
						int_ord_corte_acum,
						int_ord_ven_acum,
						fecha_acum_int_ord,
						pago_minimo,
						Autorizo
						)
				values
						(
						@id_linea,
						@monto,
						@monto,
						convert(varchar, @fecha, 112),
						@tasa_ord,
						@tasa_mor,
						0,
						0,
						0,
						0,
						convert(varchar, @fecha, 112),
						@pago_minimo,
						@autorizo
						)
	
				end try
				begin catch
	
					raiserror(@mensaje_4, 12, 0)
	
				end catch



				select @id_disposicion = scope_identity()

				-- actualizar en TBL_REVOLVENTE_LINEAS_CREDITO
				begin try
	
					update	TBL_REVOLVENTE_LINEAS_CREDITO
					set		saldo_actual = saldo_actual + @monto
					where	id_linea = @id_linea
							and numero = @numero
							and id_tipo_persona = @id_tipo_persona
	
				end try
				begin catch
	
					raiserror(@mensaje_5, 12, 0)
	
				end catch



				-- insertar en TBL_REVOLVENTE_LOG_ACCIONES
				begin try
	
					insert	TBL_REVOLVENTE_LOG_ACCIONES
							(
							id_linea,
							id_disposicion,
							numero,
							id_tipo_persona,
							id_tipo_accion,
							numusuario,
							numemp,
							id_rol,
							id_de_sucursal,
							folio,
							num_poliza,
							fecha
							)
					values
							(
							@id_linea,
							@id_disposicion,
							@numero,
							@id_tipo_persona,
							3,
							@numusuario,
							@numemp,
							@id_rol,
							@id_de_sucursal,
							@folio,
							@num_poliza,
							@fecha
							)
	
				end try
				begin catch
	
					raiserror(@mensaje_6, 12, 0)
	
				end catch



				declare @id_accion bigint = scope_identity()

				-- resguardar estado anterior de la l�nea
				begin try
	
					insert	TBL_REVOLVENTE_LINEAS_CREDITO_RESGUARDO_CANCELACION
							(
							id_accion,
							id_linea,
							numero,
							id_tipo_persona,
							num_ptmo,
							planx,
							id_de_sucursal,
							saldo_actual,
							limite_credito,
							tasa_ord,
							tasa_mor,
							CAT,
							fecha_autorizacion,
							fecha_ultimo_incremento,
							dia_corte,
							dia_limite,
							id_estado
							)
					select	@id_accion,
							id_linea,
							numero,
							id_tipo_persona,
							num_ptmo,
							planx,
							id_de_sucursal,
							saldo_actual,
							limite_credito,
							tasa_ord,
							tasa_mor,
							CAT,
							fecha_autorizacion,
							fecha_ultimo_incremento,
							dia_corte,
							dia_limite,
							1
					from	#linea_antes
	
				end try
				begin catch
	
					raiserror(@mensaje_7, 12, 0)
	
				end catch


				-- resguardar estado anterior de inverdin�mica
				begin try

					declare	@saldo_actual_103 money =
							(
							select	saldo_actual
							from	edo_de_cuenta
							where	numero = @numero
									and id_mov = 103
									and id_tipo_persona = @id_tipo_persona
							)
	
					insert	TBL_REVOLVENTE_EDO_DE_CUENTA_RESGUARDO_CANCELACION
							(
							id_accion,
							numero,
							id_tipo_persona,
							saldo_103,
							fecha_103,
							resguardo_activo
							)
					select	@id_accion,
							@numero,
							@id_tipo_persona,
							@saldo_actual_103,
							@fecha,
							1
	
				end try
				begin catch
	
					raiserror(@mensaje_7, 12, 0)
	
				end catch



				-- se inserta en CAPTURA y CAPTURA_LACP
				begin try
	
					insert	CAPTURA
							(
							id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov,
							cuenta, concepto, fecha_mov, monto, neto, id_mov, banco, clave_local, linea, num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1,
							desc2, planx, aval1_socio, aval1_numero, aval2_socio, aval2_numero, desc3, desc4, fecha_dpf_final, num_dpf, tasa, interes, dias, debe_haber,
							numusuario, procesado, fecha_alta, numero_fin, numero_fin2, plazo, interes_ord, interes_mor, monto2, plazo2, interes_ord2, interes_mor2,
							aval1_avalados, aval2_avalados, fec_inicio, fec_prog, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario,
							porcentaje_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, porcentaje_beneficiario2, id_sol, numero_fin_lacp, reestructura,
							id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, ent_federativa, cve_municipio, cve_localidad, identificador, transferencia,
							fecha_pago, bimestre, referencia, cve_archivo, impreso, folio_impresion, documentacion, dpf_en_garantia, titular, id_nomina, id_esquema_nomina,
							id_leyenda, num_ptmo, id_renovado, ahorro_base, tasa_pasiva, id_fondeador, numero_fondeo, id_origen
							)
					select	id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov,
							cuenta, concepto, fecha_mov, monto, neto, id_mov, banco, clave_local, linea, num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1,
							desc2, planx, aval1_socio, aval1_numero, aval2_socio, aval2_numero, desc3, desc4, fecha_dpf_final, num_dpf, tasa, interes, dias, debe_haber,
							numusuario, procesado, fecha_alta, numero_fin, numero_fin2, plazo, interes_ord, interes_mor, monto2, plazo2, interes_ord2, interes_mor2,
							aval1_avalados, aval2_avalados, fec_inicio, fec_prog, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario,
							porcentaje_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, porcentaje_beneficiario2, id_sol, numero_fin_lacp, reestructura,
							id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, ent_federativa, cve_municipio, cve_localidad, identificador, transferencia,
							fecha_pago, bimestre, referencia, cve_archivo, impreso, folio_impresion, documentacion, dpf_en_garantia, titular, id_nomina, id_esquema_nomina,
							id_leyenda, num_ptmo, id_renovado, ahorro_base, tasa_pasiva, id_fondeador, numero_fondeo, id_origen
					from	#captura
					order by
							contador

					insert	CAPTURA_LACP
							(
							id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov,
							cuenta, concepto, fecha_mov, monto, neto, id_mov, banco, clave_local, linea, num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1,
							desc2, planx, aval1_socio, aval1_numero, aval2_socio, aval2_numero, desc3, desc4, fecha_dpf_final, num_dpf, tasa, interes, dias, debe_haber,
							numusuario, procesado, fecha_alta, numero_fin, numero_fin2, plazo, interes_ord, interes_mor, monto2, plazo2, interes_ord2, interes_mor2,
							aval1_avalados, aval2_avalados, fec_inicio, fec_prog, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario,
							porcentaje_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, porcentaje_beneficiario2, id_sol, numero_fin_lacp, reestructura,
							id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, ent_federativa, cve_municipio, cve_localidad, identificador, transferencia,
							fecha_pago, bimestre, referencia, cve_archivo, impreso, folio_impresion, documentacion, dpf_en_garantia, titular, id_nomina, id_esquema_nomina,
							id_leyenda, num_ptmo, id_renovado, ahorro_base, tasa_pasiva, id_fondeador, numero_fondeo, id_origen
							)
					select	id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov,
							cuenta, concepto, fecha_mov, monto, neto, id_mov, banco, clave_local, linea, num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1,
							desc2, planx, aval1_socio, aval1_numero, aval2_socio, aval2_numero, desc3, desc4, fecha_dpf_final, num_dpf, tasa, interes, dias, debe_haber,
							numusuario, procesado, fecha_alta, numero_fin, numero_fin2, plazo, interes_ord, interes_mor, monto2, plazo2, interes_ord2, interes_mor2,
							aval1_avalados, aval2_avalados, fec_inicio, fec_prog, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario,
							porcentaje_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, porcentaje_beneficiario2, id_sol, numero_fin_lacp, reestructura,
							id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, ent_federativa, cve_municipio, cve_localidad, identificador, transferencia,
							fecha_pago, bimestre, referencia, cve_archivo, impreso, folio_impresion, documentacion, dpf_en_garantia, titular, id_nomina, id_esquema_nomina,
							id_leyenda, num_ptmo, id_renovado, ahorro_base, tasa_pasiva, id_fondeador, numero_fondeo, id_origen
					from	#captura
					order by
							contador

					insert	CAPTURA_LACP
							(
							id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
							num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
							numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, id_origen
							)
					select	id_persona, 'T', numero, nombre_s, apellido_paterno, apellido_materno, 3, 0, 1100, @cuenta_orden_debe, 'CREDITOS AL CONSUMO', @fecha, @monto, 10,
							@num_poliza, 'O', @folio, @id_tipo_persona, 0, '', convert(varchar, @fecha, 112), '', @planx, '', 0, 0, 0, 0, 'D', @numusuario, @fecha,
							0, 0, @tasa_ord, @tasa_mor, @contador_provision, suc.ccostos, '', '', '', '', 0, 'T', @id_origen
					from	persona per
							join sucursales suc
								on suc.id_de_sucursal = per.id_de_sucursal
					where	numero = @numero
							and id_tipo_persona = @id_tipo_persona
	
					insert	CAPTURA_LACP
							(
							id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov, cuenta, concepto, fecha_mov, monto, id_mov,
							num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1, fecha_dpf_final, desc2, planx, desc3, num_dpf, tasa, interes, dias, debe_haber, numusuario, fecha_alta,
							numero_fin, plazo, interes_ord, interes_mor, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, id_convenio, titular, id_origen
							)
					select	id_persona, 'T', numero, nombre_s, apellido_paterno, apellido_materno, 3, 0, 1100, @cuenta_orden_haber, 'CREDITOS AL CONSUMO', @fecha, @monto, 10,
							@num_poliza, 'O', @folio, @id_tipo_persona, 0, '', convert(varchar, @fecha, 112), '', @planx, '', 0, 0, 0, 0, 'H', @numusuario, @fecha,
							0, 0, @tasa_ord, @tasa_mor, @contador_provision, suc.ccostos, '', '', '', '', 0, 'T', @id_origen
					from	persona per
							join sucursales suc
								on suc.id_de_sucursal = per.id_de_sucursal
					where	numero = @numero
							and id_tipo_persona = @id_tipo_persona

				end try
				begin catch
	
					raiserror(@mensaje_8, 12, 0)
	
				end catch

				-- se inserta en MOVIMIENTOS
				declare @saldo_actual_10 money =
							(
							select	saldo_actual
							from	TBL_REVOLVENTE_LINEAS_CREDITO
							where	id_linea = @id_linea
									and numero = @numero
									and id_tipo_persona = @id_tipo_persona
							)

				begin try

					insert	movimientos
							(
							numero, activo, fecha_mov, monto, saldo, tipo_poliza, num_poliza, folio, interes_ord, interes_mor, plazo, numero_fin,
							id_persona, numusuario, id_tipomov, fecha_dpf_final, num_dpf, tasa_dpf, interes_dpf, dias, id_mov, id_tipo_persona, numero_fin_lacp, fecha_alta,
							reestructura, id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, titular, planx, num_ptmo, id_nomina, id_esquema_nomina, id_renovado, id_origen
							)
					select	numero, activo, fecha_mov, monto, case when id_mov = 10 then @saldo_actual_10 else @saldo_actual_103 + @monto end, 'M', num_poliza, folio, interes_ord, interes_mor, null, null,
							id_persona, @numusuario, id_tipomov, fecha_dpf_final, num_dpf, 0, 0, 0, id_mov, id_tipo_persona, numero_fin_lacp, fecha_alta,
							reestructura, id_motivo_reestructura, id_esquema, id_convenio, id_amortizacion, titular, planx, num_ptmo, id_nomina, id_esquema_nomina, id_renovado, id_origen
					from	#captura
					where	id_mov in (103, 10)
					order by
							contador
	
				end try
				begin catch
	
					raiserror(@mensaje_9, 12, 0)
	
				end catch

				-- actualizar edo_de_cuenta (inverdin�mica)
				begin try

					update	cta
					set		cta.saldo_actual = cap.Monto + @saldo_actual_103,
							fecha = @fecha
					from	edo_de_cuenta cta
							join #captura cap
								on cap.numero = cta.numero
								and cap.id_mov = cta.id_mov
								and cap.id_tipo_persona = cta.id_tipo_persona
					where	cta.numero = @numero
							and cta.id_mov = 103
							and cta.id_tipo_persona = @id_tipo_persona
	
				end try
				begin catch
	
					raiserror(@mensaje_10, 12, 0)
	
				end catch



				-- insertar ciclo de facturaci�n
				begin try
	
					update #ciclos_facturacion set id_disposicion = @id_disposicion

					insert	TBL_REVOLVENTE_CICLOS_FACTURACION
							(
							num_ciclo,
							id_disposicion,
							capital,
							fecha_corte,
							fecha_limite,
							int_mor_acum,
							int_mor_acum_precision,
							fecha_acum_int_mor,
							activo
							)
					select	*
					from	#ciclos_facturacion

				end try
				begin catch
	
					raiserror(@mensaje_11, 12, 0)
	
				end catch

				-- actualizar folios
				begin try

					if @id_origen != 3
	
						update	folios
						set		folio = folio + 1,
								fecha = getdate()
						where	numero = @numusuario
	
				end try
				begin catch
	
					raiserror(@mensaje_12, 12, 0)
	
				end catch


				-- si todo est� bien, se hace commit
				if @tran_count = 0
				
					begin
					
					commit tran @tran_name
					select @tran_scope = 0
					
					end
				
				end
		
		end try
		
		-- en caso de error en bloque principal
		begin catch
		
			-- captura del error
			select	@status = 0,---error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),				  
					@error_severity = case error_severity()
						when 11 then 'Error en validaci�n'
						when 12 then 'Error en consulta'
						when 13 then 'Error en actualizaci�n'
						else 'Error general'
					end,
					@error_message = error_message()

			select @status = coalesce(@status, 0)
						
			-- revertir transacci�n si es necesario
			if @tran_scope = 1 rollback tran @tran_name

			-- eliminar de tirasuma el contador que ya no sirve
			delete	provision
			where	contador = @contador_provision
		
		end catch
		
		begin -- reporte de status

			insert	#sp_revolvente_inserta_nueva_disposicion
					(
					status,
					error_procedure,
					error_line,
					error_severity,
					error_message,
					id_disposicion
					)
			select	@status,
					@error_procedure,
					@error_line,
					@error_severity,
					@error_message,
					@id_disposicion

			if @standalone = 1

				select	*
				from	#sp_revolvente_inserta_nueva_disposicion
				
		end -- reporte de status

	end -- procedimiento


