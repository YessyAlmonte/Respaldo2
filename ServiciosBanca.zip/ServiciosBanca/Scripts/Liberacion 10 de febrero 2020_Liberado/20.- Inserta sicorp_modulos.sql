USE HAPE
GO

declare @id_Modulo int

if not exists(select * from sicorp_modulos where Nom_Modulo like 'Bit�cora de Eventos')
begin
		insert sicorp_modulos(
				Nom_Modulo,
				Nom_Ejecutable,
				Id_proceso,
				PARAMETROS,
				CUENTA_EMISOR,
				SERVIDOR
		)
		values
		(
				'Bit�cora de Eventos',
				'AdminEventosBanca',
				1,
				1,
				'ROBOTCMV@CMV.MX',
				'CMV5003.CMV.MX'
		)

		select @id_Modulo=max(id_modulo) from sicorp_modulos



		insert SICORP_Permisos
				(
						Id_Rol,
						Id_Modulo,
						Usuario_Alta,
						Fecha_Alta,
						Usuario_Modifica,
						Fecha_Modifica
				)
				select Id_Rol,@id_Modulo,930,GETDATE(),0,null 
				from claves where Id_Rol in (15,219,199,205,238,275)group by Id_Rol
				--values
				--(
				--	223, 
				--	103, 
				--	930,
				--	getdate(),
				--	0,
				--	null
				--)
end
go

USE HAPE
GO

declare @id_Modulo int

if not exists(select * from sicorp_modulos where Nom_Modulo like 'CMV Finazas Devoluciones')
begin
		insert sicorp_modulos(
				Nom_Modulo,
				Nom_Ejecutable,
				Id_proceso,
				PARAMETROS,
				CUENTA_EMISOR,
				SERVIDOR
		)
		values
		(
				'CMV Finazas Devoluciones',
				'PolizaDiario',
				1,
				1,
				'ROBOTCMV@CMV.MX',
				'CMV5003.CMV.MX'
		)

		select @id_Modulo=max(id_modulo) from sicorp_modulos

		insert SICORP_Permisos
				(
						Id_Rol,
						Id_Modulo,
						Usuario_Alta,
						Fecha_Alta,
						Usuario_Modifica,
						Fecha_Modifica
				)
				select Id_Rol,@id_Modulo,930,GETDATE(),0,null 
				from claves where Id_Rol in (15, 219, 238)group by Id_Rol
end