use hape
go

if exists (select * from sysobjects where name like 'tmp_edo_de_cuenta_descuadre_decrecientes' and xtype = 'u')
	drop table tmp_edo_de_cuenta_descuadre_decrecientes
go

if exists (select * from sysobjects where name like 'tmp_calendario_descuadre_decrecientes' and xtype = 'u')
	drop table tmp_calendario_descuadre_decrecientes
go

if exists (select * from sysobjects where name like 'tmp_diferencias_descuadre_decrecientes' and xtype = 'u')
	drop table tmp_diferencias_descuadre_decrecientes
go

select	numero,
		id_mov,
		num_ptmo,
		id_esquema,
		saldo_actual saldo_edo_de_cuenta
into	tmp_edo_de_cuenta_descuadre_decrecientes
from	edo_de_cuenta
where	saldo_actual > 0
		and id_mov < 100
		and id_esquema = 1

create clustered index ix_tmp_edo_de_cuenta_descuadre_decrecientes on tmp_edo_de_cuenta_descuadre_decrecientes (numero, id_mov, num_ptmo)

select	numero, id_mov, num_ptmo, sum(capital_actual) saldo_calendario
into	tmp_calendario_descuadre_decrecientes
from	tbl_interes_diario_calendarios_decrecientes
where	capital_actual > 0
		and activo = 1
group by
		numero, id_mov, num_ptmo

create clustered index ix_tmp_calendario_descuadre_decrecientes on tmp_calendario_descuadre_decrecientes (numero, id_mov, num_ptmo)

select	cal.numero,
		cal.id_mov,
		cal.num_ptmo,
		cta.saldo_edo_de_cuenta,
		cal.saldo_calendario,
		cta.saldo_edo_de_cuenta - cal.saldo_calendario diferencia,
		cast(null as int) max_version_calendario,
		cast(null as int) max_num_corte
into	tmp_diferencias_descuadre_decrecientes
from	tmp_calendario_descuadre_decrecientes cal
		join tmp_edo_de_cuenta_descuadre_decrecientes cta
			on cta.numero = cal.numero
			and cta.id_mov = cal.id_mov
			and cta.num_ptmo = cal.num_ptmo
where	saldo_calendario != saldo_edo_de_cuenta
order by
		cal.numero

create clustered index ix_tmp_diferencias_descuadre_decrecientes on tmp_diferencias_descuadre_decrecientes (numero, id_mov, num_ptmo)

update	dif
set		max_version_calendario = _.max_version_calendario,
		max_num_corte = _.max_num_corte
from	(
		select	dif.numero,
				dif.id_mov,
				dif.num_ptmo,
				max_version_calendario = max(version_calendario),
				max_num_corte = max(num_corte)
		from	tmp_diferencias_descuadre_decrecientes dif
				join tbl_interes_diario_calendarios_decrecientes cal
					on cal.numero = dif.numero
					and cal.id_mov = dif.id_mov
					and cal.num_ptmo = dif.num_ptmo
					and cal.capital_actual > 0
		where	cal.capital_actual > 0
		group by
				dif.numero,
				dif.id_mov,
				dif.num_ptmo
		) _
		join tmp_diferencias_descuadre_decrecientes dif
			on dif.numero = _.numero
			and dif.id_mov = _.id_mov
			and dif.num_ptmo = _.num_ptmo

select	cal.*, migrar = 1
from	tmp_calendario_descuadre_decrecientes cal
		left join tmp_edo_de_cuenta_descuadre_decrecientes cta
			on cta.numero = cal.numero
			and cta.id_mov = cal.id_mov
			and cta.num_ptmo = cal.num_ptmo
			
where	cta.numero is null
order by
		cta.numero

select	*
from	tmp_diferencias_descuadre_decrecientes

update	cal
set		capital_actual += dif.diferencia
from	tmp_diferencias_descuadre_decrecientes dif
		join TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES cal
			on cal.numero = dif.numero
			and cal.id_mov = dif.id_mov
			and cal.num_ptmo = dif.num_ptmo
			and cal.num_corte = dif.max_num_corte
			and cal.version_calendario = dif.max_version_calendario

drop table tmp_edo_de_cuenta_descuadre_decrecientes

drop table tmp_calendario_descuadre_decrecientes

-- drop table tmp_diferencias_descuadre_decrecientes

