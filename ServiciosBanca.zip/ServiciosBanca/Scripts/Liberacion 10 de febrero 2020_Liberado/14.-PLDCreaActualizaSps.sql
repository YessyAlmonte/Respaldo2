﻿use LAVADO_DINERO
go

-- se crea procedimiento SP_LAVADO_DINERO_CONSULTA_TRANF_BANCA
if exists (select * from sysobjects where name like 'SP_LAVADO_DINERO_CONSULTA_TRANF_BANCA' and xtype = 'p' and db_name() = 'LAVADO_DINERO')
	drop proc SP_LAVADO_DINERO_CONSULTA_TRANF_BANCA
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20181213
Objetivo		Consultar las transferencias realizadas a traves de banca en linea
Proyecto		Banca
Ticket			ticket

*/

create proc

	SP_LAVADO_DINERO_CONSULTA_TRANF_BANCA

	@FECHA_INI DATE,
    @FECHA_FIN DATE
	
as

	begin -- procedimiento
	
		select	
			id_banca_folio,
			movs.numero_socio,
			cast(fecha_transferencia_realizada as date) fecha_movimiento,
			monto
			--coalesce(per.nombre_s,'') + ' ' + coalesce(per.Apellido_Paterno,'') + ' ' + coalesce(per.apellido_materno,'') Nombre
		from 
			LAVADO_DINERO.DBO.TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA movs
		join HAPE..PERSONA per on movs.numero_socio=per.Numero and per.Id_Tipo_Persona=1
		where 
					cast(fecha_transferencia_realizada as date) between CAST(@FECHA_INI as date) and cast(@fecha_fin as date)
					AND id_estatus_transferencia=2
		group by id_banca_folio,movs.numero_socio,cast(fecha_transferencia_realizada as date),monto--,per.Nombre_s,per.Apellido_Paterno,per.Apellido_Materno
		order by id_banca_folio
		
	end -- procedimiento
go

grant exec on SP_LAVADO_DINERO_CONSULTA_TRANF_BANCA to public

go

USE [LAVADO_DINERO]
GO
/****** Object:  StoredProcedure [dbo].[SP_LAVADO_CALCULA_FLUJO_EFECTIVO]    Script Date: 18/03/2020 10:10:42 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20160616
Objetivo		Generar monto total de flujo de efectivo 
Proyecto		PLD
Ticket			ticket
*/

ALTER proc [dbo].[SP_LAVADO_CALCULA_FLUJO_EFECTIVO]
	
	@id_alerta int,
	@TipoOperacion int=1, -- 1 relevantes y 2 inusuales
	@desglose bit=0

as

	begin
	
		begin try

			-- declaraciones internas
					declare @status int = 1,
							@error_message varchar(255) = '',
							@tipo_operacion int=0

					declare @id_tipo_alerta int,@fecha_ini date,@fecha_fin date,@numero int 
					select @id_tipo_alerta=id_tipo_alerta,@fecha_ini = DATEADD(mm,-1,fecha_alta),@fecha_fin = EOMONTH(@fecha_ini),@numero= numero 
					from lavado_alertas where ID_ALERTA=@id_alerta


			begin try
	
				IF OBJECT_ID('tempdb..##FOLIOS') IS NOT NULL
					DROP TABLE ##FOLIOS;

				create table ##FOLIOS(
						folio int NULL,
						suma_depositos money null,
						suma_retiros money null,
						suma_cheques money null,
						monto_total MONEY null,
						tipo_operacion int null, --1 deposito --2 retiro	
						id_origen int null					 
						)
	
			end try
			begin catch
	
				raiserror('Error al crear tablas temporales', 12, 0)
	
			end catch

			begin try
				--EIHG856318 21 Ene 2020. Se agregó para conocer el tipo de moneda que se utilizo en los movimientos
				if object_id('tempdb..#captura') is not null drop table #captura

				select * 
				into #captura
				from historico..CAPTURA with (nolock)
				where convert(date,fecha_mov) between @fecha_ini and @fecha_fin
				and numero=@numero and num_cheq <>0 and num_cheq is not null
				
				
				INSERT INTO #captura
				select * 
				from HAPE..CAPTURA with (nolock)
				where convert(date,fecha_mov) between @fecha_ini and @fecha_fin
				and numero=@numero and num_cheq <>0 and num_cheq is not null


			--	select *From #captura
	
				select	 
						mov.id_tipomov,
						mov.monto,
						mov.FOLIO,
						mov.TIPO_POLIZA,
						case when mov.ID_TIPOMOV=-1 then 'Cheque' else  t.Descripcion end Descripcion,
						mov.FECHA_MOV,
						coalesce(t.id_operacion_pld,0) id_operacion_pld,
						case when C.Num_cheq IS NULL OR C.Num_cheq = 0 then cast('EFECTIVO' as varchar(100)) else cast('CHEQUE' as varchar(100)) end instrumento_monetario,
						suc.Descripcion sucursal_operacion,
						isnull(id_origen,1) id_origen
						into #operaciones
						from Lavado_dinero.dbo.lavado_alertas a 
						left outer join Lavado_dinero.dbo.lavado_alertas_detalle d  on d.id_alerta=a.id_alerta
						left outer join lavado_dinero.dbo.lavado_movimientos mov on d.contador=mov.contador
						left outer join HAPE..TIPO_MOV t with (nolock) on mov.ID_TIPOMOV=t.Id_tipomov
						left outer join HAPE..CLAVES cl with (nolock) on cl.Numusuario=mov.NUMUSUARIO
						left outer join HAPE..SUCURSALES suc with (nolock) on cl.Id_de_sucursal=suc.Id_de_Sucursal
						--EIHG856318 17Ene2020. Se detecto que se mostraban  movimientos de CHEQUES como efectivo
						left JOIN #captura C ON MOV.Num_Poliza = C.Num_Poliza AND MOV.FOLIO = C.FOLIO AND MOV.id_mov = C.ID_mov  and mov.monto = c.monto 
						where 
						a.id_alerta=@id_alerta AND 
						(mov.TIPO_POLIZA='M' 
						OR mov.TIPO_POLIZA=CASE WHEN @TipoOperacion=1 THEN 'M' ELSE 'E' END 
						or mov.TIPO_POLIZA=CASE WHEN @id_tipo_alerta in (8,10) THEN 'D' ELSE 'M' end)
				
			--	select *from #operaciones

				--Eliminamos las transferencias para que no se consideren en el calculo del flujo de efectivo		
				if(@TipoOperacion=2) 
				begin
				  
				  update op set
				  instrumento_monetario='TRANSFERENCIA'
				  from #operaciones op
				  join
				  (SELECT folio FROM #operaciones where id_tipomov in (701,702)
				  group by folio) transferencia on op.folio=transferencia.folio

				  update op set
				  instrumento_monetario='CHEQUE'
				  from #operaciones op
				  join
				  (SELECT folio FROM #operaciones where id_tipomov in (-1)
				  group by folio) transferencia on op.folio=transferencia.folio

				  update op set
				  instrumento_monetario='TRANSFERENCIA'
				  from #operaciones op where id_origen in (3,4)

				  --EIHG856318 16 Ene 2020. se quitan Deposito de Interés Inverplus CMV, # 
				  --¡¡¡IMPORTANTE!!! FALTA MODIFICAR EL ROBOT PARA NO ALERTAR ESTOS MOVIMIETNOS
				  --delete #operaciones where ID_TIPOMOV in (512,88) 
	
					
				  if (@id_tipo_alerta != 10 )
						delete #operaciones where ID_TIPOMOV in (331,332,333,334,335,336,337,338,339,702,1100,701,-1)
				end

				--Si son relevantes excluimos las operaciones con id_tipo_origen 3,4 banca electronica ya que no es flujo de efectivo
				if(@TipoOperacion=1)
					delete #operaciones where id_origen in (3,4)
				
				insert into ##FOLIOS (folio,suma_depositos,suma_retiros,suma_cheques,tipo_operacion,id_origen)
				select 
						FOLIO,
						/*********original:(select SUM(MONTO) from #operaciones where FOLIO=o.FOLIO and id_operacion_pld=1), 
						          EIHG856318, se incluyó el id_tipomov=300 SOLO por un caso de un deposito de nómina el 06 Septiembre 2019,
						          en realidad no es necesario.******************/
						(select SUM(MONTO) from #operaciones where FOLIO=o.FOLIO and id_origen=o.id_origen and (id_operacion_pld=1 or id_tipomov=300)),
						(select SUM(MONTO) from #operaciones where FOLIO=o.FOLIO AND id_operacion_pld=2 and id_origen=o.id_origen ),
						(select SUM(MONTO) from #operaciones where FOLIO=o.FOLIO and id_tipomov=-1 and id_origen=o.id_origen),
						---Si existen movimientos de prestamo el tipo de operacion es 9
						case 
							when exists(select 1 from #operaciones where FOLIO=o.FOLIO and TIPO_POLIZA='M' AND id_tipomov in (31,32,33,34,35,36,37,38,39,61,62,63,64,65,66,67,68,69,                             
							71,72,73,74,75,76,77,78,79,131,132,133,134,135,136,137,138,139,231,232,233,234,235,236,237,238,239)) then 9
							---Si existen movimientos de otorgamiento de prestamo el tipo de operacion es 8
							when exists(select 1 from #operaciones where FOLIO=o.FOLIO and TIPO_POLIZA='M' AND id_tipomov in (331,332,333,334,335,336,337,338,339)) then 8
						    else 0
						end,
						id_origen						
						from #operaciones o
						group by FOLIO,id_origen	

			end try
			begin catch
	           select ERROR_MESSAGE()
				raiserror('Error al insertar en tablas temporales', 12, 0)
	
			end catch

			begin try
	
				UPDATE ##FOLIOS SET suma_depositos = 0 WHERE suma_depositos IS NULL
				UPDATE ##FOLIOS SET suma_cheques = 0 WHERE suma_cheques IS NULL
				UPDATE ##FOLIOS SET suma_retiros = 0 WHERE suma_retiros IS NULL	
				
				 			

				UPDATE ##FOLIOS  
					set	monto_total = b.monto_total,
					    tipo_operacion=b.tipo
					From    (
								SELECT 
								--case when suma_depositos>=suma_retiros then 
								--case when (suma_depositos-suma_retiros)>=suma_cheques then 
								--	(suma_depositos-suma_retiros)-suma_cheques else  suma_depositos-suma_retiros end
								--else abs(suma_depositos-suma_retiros) end monto_total,
								case when suma_depositos>=suma_retiros then 
                                               case when suma_cheques>0 and (suma_depositos-suma_retiros)>0 then 
											         abs((suma_depositos-suma_retiros)-suma_cheques)
											   else  suma_depositos-suma_retiros end
                                            else abs(suma_depositos-suma_retiros) end monto_total, 
								folio,
								case when coalesce(tipo_operacion,0)>0 then tipo_operacion 
								else
									case when suma_depositos>=suma_retiros then 1								
									else 2 end  
								end tipo,
								id_origen
								FROM ##FOLIOS 
							) b
					where ##FOLIOS.folio = B.folio and ##FOLIOS.id_origen=b.id_origen

					DELETE FROM ##FOLIOS WHERE monto_total IS NULL


	
			end try
			begin catch
	
				raiserror('Error al realizar el calculo del flujo en efectivo', 12, 0)
	
			end catch
		
		end try
		begin catch
		
			select @status=0 ,@error_message=ERROR_MESSAGE()
		
		end catch

		--Dejamos la operacion del monto mas alto
		select @tipo_operacion=(select top 1 tipo_operacion from ##FOLIOS
								group by tipo_operacion
								order by SUM(monto_total) desc)



        --Eliminamos las operaciones que no tuvieron flujo de efectivo
		--if(@id_tipo_alerta=10 OR @id_tipo_alerta = 8)
		if(@id_tipo_alerta=10)
		    delete #operaciones where id_tipomov in (19, 40, 91, 92, 93, 94, 95, 610, 611, 620, 621)
		else 		 
		   delete #operaciones where FOLIO in (select folio from ##FOLIOS where monto_total=0)
		  
		   delete ##FOLIOS	where monto_total=0	
		   
		   
		   
		  -- delete #operaciones where FOLIO in (select folio from ##FOLIOS where monto_total=0)
		   --delete ##FOLIOS	where monto_total=0			   
		

		IF(@desglose=0)
			select 
			@status status,
			@error_message error,
			case when @id_tipo_alerta IN (10) then
			(select SUM(monto)
			from #operaciones)
			else (select SUM(monto_total)
			from ##FOLIOS) end flujo_efectivo,
			@tipo_operacion tipo_operacion,
			ID_TIPOMOV,
			MONTO monto_operacion,
			Descripcion,
			instrumento_monetario,
			FECHA_MOV,
			sucursal_operacion
			from #operaciones
		ELSE
		   SELECT f.*,sucursal_operacion,FECHA_MOV 
		   FROM ##FOLIOS f
		   join (select FOLIO,cast(FECHA_MOV as date) FECHA_MOV,sucursal_operacion from #operaciones group by FOLIO,cast(FECHA_MOV as date),sucursal_operacion) movs on f.folio=movs.FOLIO
		   where f.monto_total>0
		
		--group by tipo_operacion
		
	end

go

USE [LAVADO_DINERO]
GO
/****** Object:  StoredProcedure [dbo].[SP_LAVADO_CONSULTA_BENEFICIARIOS]    Script Date: 04/03/2019 05:07:42 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Jessica Almonte Acosta>
-- Create date: <18 de Diciembre del 2015>
-- Description:	<sp para consultar los beneficiarios de un socio>
-- =============================================
ALTER PROCEDURE [dbo].[SP_LAVADO_CONSULTA_BENEFICIARIOS] 
	@NUMERO INT,
	@ID_TIPO_PERSONA INT
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @ID_PERSONA INT

	SET @ID_PERSONA=(SELECT ID_PERSONA FROM HAPE.DBO.PERSONA WHERE Numero=@NUMERO AND Id_Tipo_Persona=@ID_TIPO_PERSONA)

	---Si esta en hape
	if(@ID_PERSONA>0) 
	begin

		select R.ID_REFERENCIA,R.NOMBRE_REFERENCIA + ' ' + R.Apellido_Paterno_Referencia + ' ' + R.Apellido_Materno_Referencia NOMBRE,
		R.Fecha_de_Nacimiento,R.Parentesco,R.Porcentaje,R.Calle_Referencia + ' #' + R.Numero_Exterior_Referencia + ' ' + R.Numero_Interior_Referencia,
		 + ' Col. ' + M.Nombre_Colonia  + ' C.P ' + CONVERT(VARCHAR(20),M.Codigo_Postal) Domicilio,M.CNBV_Municipio,E.DESCRIPCION ENTIDAD
		from HAPE.DBO.REFERENCIAS R
		LEFT OUTER JOIN HAPE.DBO.CNBV_MNPIO_COL M ON R.Id_Colonia_CNBV=M.Id_Colonia_CNBV 
		LEFT OUTER JOIN HAPE.DBO.ENTIDAD_FEDERATIVA E ON M.Id_Entidad_Federativa=E.ID_ENTIDAD_FEDERATIVA
		WHERE ID_PERSONA=@ID_PERSONA AND R.Id_de_Referencia IN (1,7,8,9)

	end
	else
	begin
		SET @ID_PERSONA=(SELECT max(ID_PERSONA) FROM EXSOCIOS.DBO.PERSONA WHERE Numero=@NUMERO AND Id_Tipo_Persona=@ID_TIPO_PERSONA)

		select R.ID_REFERENCIA,R.NOMBRE_REFERENCIA + ' ' + R.Apellido_Paterno_Referencia + ' ' + R.Apellido_Materno_Referencia NOMBRE,
		R.Fecha_de_Nacimiento,R.Parentesco,R.Porcentaje,R.Calle_Referencia + ' #' + R.Numero_Exterior_Referencia + ' ' + R.Numero_Interior_Referencia,
		 + ' Col. ' + M.Nombre_Colonia  + ' C.P ' + CONVERT(VARCHAR(20),M.Codigo_Postal) Domicilio,M.CNBV_Municipio,E.DESCRIPCION ENTIDAD
		from EXSOCIOS.DBO.REFERENCIAS R
		LEFT OUTER JOIN HAPE.DBO.CNBV_MNPIO_COL M ON R.Id_Colonia_CNBV=M.Id_Colonia_CNBV 
		LEFT OUTER JOIN HAPE.DBO.ENTIDAD_FEDERATIVA E ON M.Id_Entidad_Federativa=E.ID_ENTIDAD_FEDERATIVA
		WHERE ID_PERSONA=@ID_PERSONA AND R.Id_de_Referencia IN (1,7,8,9)

	end

END

GO

USE [LAVADO_DINERO]
GO
/****** Object:  StoredProcedure [dbo].[SP_LAVADO_CONSULTA_RELEVANTE_LAYOUT_TRIMESTRE]    Script Date: 11/03/2019 09:10:05 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


		/*-------------------SP_LAVADO_CONSULTA_RELEVANTE_LAYOUT_TRIMESTRE-----------------------
		Autor:		Gustavo Negrete
		fecha:		05/07/2010
		Descripcion:	Consulta de las alertas por trimestre
		-----------------------------------------------------------------------------------------*/

	    /*-------------------MODIFICACION-----------------------
		Autor:		Jessica Almonte Acosta
		fecha:		07/10/2015
		Descripcion:No contemplar socios utilitarios.	
		-----------------------------------------------------------------------------------------*/


		ALTER  procedure [dbo].[SP_LAVADO_CONSULTA_RELEVANTE_LAYOUT_TRIMESTRE]

		@trimestre int,
		@annio int 

		as


		if @trimestre >4 or @trimestre <=0 or (@annio<= year (getdate())-2) or (@annio= year (getdate())-1 and @trimestre< month(getdate())/3+1) or (@annio= year (getdate()) and @trimestre> month(getdate())/3+1)
			begin
				select 1 as status
				return 1
			end

		declare @mes1 int , @mes2 int , @mes3 int

		set @mes3=3*@trimestre
		set @mes2=@mes3-1
		set @mes1=@mes2-1

		select 	ID_ALERTA,
			alertas.numero,
			--Nombre_s + ' ' + Apellido_Paterno + ' ' + Apellido_Materno as nombre,
			suc.descripcion as sucursal,
			lavado_dinero.dbo.lavado_tipo_alerta.descripcion as descripcion,
			alertas.fecha_alta as fecha_deteccion,
			alertas.id_tipo_persona,
			0 as status
		from 	lavado_dinero.dbo.lavado_alertas alertas inner join lavado_dinero.dbo.lavado_tipo_operacion on 
			alertas.id_tipo_operacion=1 and
			alertas.id_tipo_operacion=lavado_dinero.dbo.lavado_tipo_operacion.id_tipo_operacion 
			left join hape.dbo.persona per on alertas.numero=per.numero  and alertas.id_tipo_persona=per.id_tipo_persona 
			left join (select max(id_persona) id_persona,numero,id_tipo_persona from exsocios..persona group by numero,id_tipo_persona) maxExsocio on maxExsocio.Numero=alertas.NUMERO and maxExsocio.Id_Tipo_Persona=alertas.ID_TIPO_PERSONA
			left join EXSOCIOS..PERSONA perExsocio on maxExsocio.id_persona=perExsocio.Id_Persona
			left join hape.dbo.sucursales suc on suc.id_de_sucursal=case when per.Numero is not null then per.Id_de_Sucursal else perExsocio.Id_de_Sucursal end 
			inner join lavado_dinero.dbo.lavado_tipo_alerta on lavado_dinero.dbo.lavado_tipo_alerta.id_tipo_alerta=alertas.id_tipo_alerta
		where 	month(alertas.fecha_alta) in (@mes1, @mes2, @mes3) and 
			@annio= year (alertas.fecha_alta) and alertas.fecha_alta>=dateadd(year, -1, convert(varchar, getdate(), 112))
			and alertas.numero not in (SELECT socioutilitario FROM [HAPE].[dbo].[SUCURSALES])
			order by alertas.fecha_alta asc

GO

USE [LAVADO_DINERO]
GO
/****** Object:  StoredProcedure [dbo].[SP_LAVADO_CONSULTA_SOCIO_LISTA_OFAC]    Script Date: 20/03/2019 04:23:30 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Jessica Almonte Acosta>
-- Create date: <17/12/2015>
-- Description:	<SP QUE CONSULTA LA LISTA OFAC PARA DETERMINAR SI EL SOCIO APARECE EN DICHA LISTA>
-- =============================================
ALTER PROCEDURE [dbo].[SP_LAVADO_CONSULTA_SOCIO_LISTA_OFAC]
	@Numero int,
	@id_tipo_persona int
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @NombreSocio varchar(100),
	        @NombreApellidos varchar(100),
			@fecha_nacimiento date

	create table #tmp(conteo int)

	if(exists(select 1 from hape.dbo.persona where Numero=@Numero and Id_Tipo_Persona=@id_tipo_persona))
	begin

		select 
			  @NombreSocio=Nombre_s + ' ' + isnull(rtrim(Apellido_Paterno),'') + ' '  + isnull(rtrim(Apellido_Materno),''), 
			  @NombreApellidos=isnull(rtrim(Apellido_Paterno),'') + ' ' + isnull(rtrim(Apellido_Materno),'') + ' '  + isnull(rtrim(Nombre_s),''),
		      @fecha_nacimiento=fecha_de_nacimiento
		from hape.dbo.persona
		where Numero=@Numero and Id_Tipo_Persona=@id_tipo_persona



		SELECT ID_OFAC,NOMBRE,o.ID_LISTA_OFAC,@NombreSocio NombreSocio,0 Id_referencia 
		FROM LAVADO_DINERO.DBO.LAVADO_OFAC o
		left join LAVADO_DINERO..TBL_LAVADO_FECHA_NAC_OFAC nac on o.ID_LISTA_OFAC=nac.id_lista_ofac and nac.activo='T'
        WHERE 
		((NOMBRE LIKE ''+RTRIM (@NombreSocio)+'') or
		(NOMBRE LIKE ''+RTRIM (@NombreApellidos)+'')) and
		(
			(@fecha_nacimiento=case when nac.id_lista_ofac IS NULL THEN @fecha_nacimiento ELSE fecha_nac END) OR
			(YEAR(@fecha_nacimiento)=case when nac.id_lista_ofac IS NULL THEN YEAR(@fecha_nacimiento) ELSE anio_nac END)
		)
		and O.ACTIVO='T'
		--WHERE 
		--((NOMBRE LIKE '%'+RTRIM (@NombreSocio)+'%') or
		--(NOMBRE LIKE '%'+RTRIM (@NombreaApellido)+'%')) 
		--and ACTIVO='T'


		--Se realiza la busquedad de los propietarios y proveedor de recursos en la lista OFAC
		union

		SELECT ID_OFAC,NOMBRE,ofac.ID_LISTA_OFAC,@NombreSocio NombreSocio,Id_Referencia Id_referencia 
		FROM 
		LAVADO_DINERO.DBO.LAVADO_OFAC ofac
		JOIN HAPE.DBO.PERSONA  per on per.Numero=@Numero and per.Id_Tipo_Persona=@id_tipo_persona
		JOIN HAPE.DBO.REFERENCIAS ref on per.Id_Persona=ref.Id_Persona
		LEFT join LAVADO_DINERO..TBL_LAVADO_FECHA_NAC_OFAC nac on ofac.ID_LISTA_OFAC=nac.id_lista_ofac and nac.activo='T' 
		WHERE
		Id_de_Referencia in (16,21) 
		and 
		((NOMBRE collate Traditional_Spanish_CI_AS LIKE ''+RTRIM (ref.Nombre_Referencia + ' ' + isnull(rtrim(ref.Apellido_Paterno_Referencia),'') + ' '  + isnull(rtrim(ref.Apellido_Materno_Referencia),''))+'') or
		 (NOMBRE collate Traditional_Spanish_CI_AS LIKE ''+RTRIM (ref.Apellido_Paterno_Referencia + ' ' + isnull(rtrim(ref.Apellido_Materno_Referencia),'') + ' '  + isnull(rtrim(ref.Nombre_Referencia),''))+'')
		) and
		(
			(ref.fecha_de_nacimiento=case when nac.id_lista_ofac IS NULL THEN ref.fecha_de_nacimiento ELSE fecha_nac END) OR
			(YEAR(ref.fecha_de_nacimiento)=case when nac.id_lista_ofac IS NULL THEN YEAR(ref.fecha_de_nacimiento) ELSE anio_nac END)
		)	
		and ofac.ACTIVO='T';

	end
	else
		select * from #tmp


	drop table #tmp

END

GO

USE [LAVADO_DINERO]
GO
/****** Object:  StoredProcedure [dbo].[SP_LAVADO_INUSUAL_FILTROS]    Script Date: 06/03/2019 04:15:25 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
		/*-------------------SP_LAVADO_INUSUAL_FILTROS------------------------------------------
		Autor:		Gustavo Negrete
		fecha:		11/10/2010
		Descripcion:	Consulta de las alertas inusuales PLD 
						Modificaci�n 24 de Septiembre de 2015 
		Se agrega el id_tipo_alerta 16 de acuerdo al ticket #158368
		-----------------------------------------------------------------------------------------*/

	    /*-------------------MODIFICACION-----------------------
		Autor:		Jessica Almonte Acosta
		fecha:		07/10/2015
		Descripcion:No contemplar socios utilitarios	
		-----------------------------------------------------------------------------------------*/

		ALTER	procedure [dbo].[SP_LAVADO_INUSUAL_FILTROS]

		@numero int null,
		@id_tipo_persona int null,
		@fecha_ini datetime null,
		@fecha_fin datetime null,
		@id_de_sucursal int null,
		@id_tipo_alerta int null,
		@id_solicitud int null


		as
	
		declare @query nvarchar(4000)
		--MODIFICO AOAJ720209 T167364 2da Etapa
	    --MODIFICACION: SE AGREGA QUE SOLO CONTEMPLE SOCIOS UTILITARIOS CON ID TIPO PERSONA 1
		set @query='select 
		ID_ALERTA,
		alertas.numero,
		case when alertas.id_tipo_persona=7 then 
		(select razon_social from HAPE.DBO.TBL_PM_PERSONAS_MORALES where id_persona=per.Id_Persona) 
		else 
			case when per.Numero IS NOT NULL then per.Nombre_s + char(32) + per.apellido_paterno + char(32) + per.apellido_materno
			ELSE  perExsocio.Nombre_s + char(32) + perExsocio.apellido_paterno + char(32) + perExsocio.apellido_materno END
		end  Nombre,
		suc.descripcion as sucursal,
		tipo_alerta.descripcion as descripcion,
		alertas.fecha_alta as fecha_denuncia,
		alertas.fecha_modifica as fecha_dictamen,
		alertas.id_tipo_persona,
		estatus.descripcion as status
	from 	
		lavado_dinero.dbo.lavado_alertas alertas 			
		left join hape.dbo.persona per on alertas.numero=per.numero and alertas.id_tipo_persona=per.id_tipo_persona 
		left join (select max(id_persona) id_persona,numero,id_tipo_persona from exsocios..persona group by numero,id_tipo_persona) maxExsocio on maxExsocio.Numero=alertas.NUMERO and maxExsocio.Id_Tipo_Persona=alertas.ID_TIPO_PERSONA
		left join EXSOCIOS..PERSONA perExsocio on maxExsocio.id_persona=perExsocio.Id_Persona			
		inner join hape.dbo.sucursales suc on suc.id_de_sucursal=case when per.Numero is not null then per.Id_de_Sucursal else perExsocio.Id_de_Sucursal end 
		inner join lavado_dinero.dbo.lavado_tipo_alerta tipo_alerta on tipo_alerta.id_tipo_alerta=alertas.id_tipo_alerta
		inner join lavado_dinero.dbo.CAT_LAVADO_SOLICITUDES_ESTATUS estatus on alertas.Id_solicitud=estatus.Id_solicitud
	where   alertas.id_tipo_operacion=2 and alertas.Id_tipo_alerta IN (6,7,8,9,10,11,16) 
	and alertas.numero not in (SELECT socioutilitario FROM [HAPE].[dbo].[SUCURSALES] where alertas.ID_TIPO_PERSONA=1)' 

		if @numero is not null 
			set @query=@query + ' and alertas.numero=' + convert (varchar, @numero, 1)

		if @id_tipo_persona is not null 
			set @query=@query + ' and alertas.id_tipo_persona=' + convert (varchar, @id_tipo_persona, 1)

		if @fecha_ini is not null
			set @query=@query + ' and alertas.fecha_alta >=''' + convert (varchar, @fecha_ini, 112) +''''

		if @fecha_fin is not null
			set @query=@query + ' and alertas.fecha_alta <=''' + convert (varchar, @fecha_fin, 112) +''''

		if @id_de_sucursal is not null 
			set @query=@query + ' and suc.id_dE_sucursal=' + convert (varchar, @id_de_sucursal, 1)

		if @id_tipo_alerta is not null 
			set @query=@query + ' and alertas.Id_tipo_alerta=' + convert (varchar, @id_tipo_alerta, 1)

		if @id_solicitud is not null 
			set @query=@query + ' and alertas.Id_solicitud=' + convert (varchar, @id_solicitud, 1)

		set @query=@query + ' order by alertas.fecha_alta asc'

		exec sp_executesql @query

GO

USE [LAVADO_DINERO]
GO
/****** Object:  StoredProcedure [dbo].[SP_LAVADO_INUSUAL_REPORTE_DATOS_PERSONALES]    Script Date: 06/03/2019 04:35:08 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


		/*-------------------SP_LAVADO_REPORTE_RELEVANTE_DATOS_PERSONALES-----------------------
		Autor:		Gustavo Negrete
		fecha:		05/07/2010
		Descripcion:	Reporte de alertas del socio dado
		-----------------------------------------------------------------------------------------*/

		ALTER  procedure [dbo].[SP_LAVADO_INUSUAL_REPORTE_DATOS_PERSONALES]


		@numero int,
		@id_tipo_persona int, 
		@id_alerta int 

		as

		declare @id_persona bigint=0

		CREATE TABLE #DATOS_SOCIO(
			id_persona bigint,
			numero bigint,
			id_tipo_persona int,
			Nombre_s	varchar(40) NULL,
			Apellido_Paterno	varchar(40) NULL,
			Apellido_Materno	varchar(40) NULL,
			Calle	varchar	(60) NULL,
			Numero_Exterior	varchar(10) NULL,
			Numero_Interior	varchar(10) NULL,
			Telefono varchar(15) NULL,
			Tel_Trabajo	varchar(15) NULL,
			Tel_Celular	varchar(15) NULL,
			Telefono_adicional	varchar(15) NULL,
			Ingreso_mensual	float NULL,
			Curp varchar(18) NULL,
			Rfc	varchar(15) NULL,
			Id_Nacionalidad	smallint NULL,
			Id_Colonia_CNBV INT NULL,
			Id_Ocupacion_CNBV INT NULL,
			id_de_sucursal INT NULL,
			Fecha_de_nacimiento DATETIME NULL
					
		)

		select @id_persona=id_persona from hape..persona where numero=@numero and id_tipo_persona=@id_tipo_persona

		if(@id_persona>0)
		begin
		 
		  INSERT INTO #DATOS_SOCIO(id_persona,
			numero,id_tipo_persona,Nombre_s,Apellido_Paterno,
			Apellido_Materno,Calle,Numero_Exterior,Numero_Interior,
			Telefono,Tel_Trabajo,Tel_Celular,Telefono_adicional,
			Ingreso_mensual,Curp,Rfc,Id_Nacionalidad,
			Id_Colonia_CNBV,Id_Ocupacion_CNBV,id_de_sucursal,Fecha_de_nacimiento)
		  select P.id_persona,
			numero,id_tipo_persona,Nombre_s,Apellido_Paterno,
			Apellido_Materno,Calle,Numero_Exterior,Numero_Interior,
			Telefono,Tel_Trabajo,Tel_Celular,Telefono_adicional,
			Ingreso_mensual,Curp,Rfc,Id_Nacionalidad,
			Id_Colonia_CNBV,Id_Ocupacion_CNBV,id_de_sucursal,Fecha_de_nacimiento 
		  from HAPE..PERSONA P 
		  JOIN HAPE..TEXTOS T ON P.ID_PERSONA=T.ID_PERSONA 
		  WHERE P.ID_PERSONA=@ID_PERSONA
		end
		else
		begin
		  SET @ID_PERSONA=(SELECT max(ID_PERSONA) FROM EXSOCIOS.DBO.PERSONA WHERE Numero=@NUMERO AND Id_Tipo_Persona=@ID_TIPO_PERSONA)

		  INSERT INTO #DATOS_SOCIO(id_persona,
			numero,id_tipo_persona,Nombre_s,Apellido_Paterno,
			Apellido_Materno,Calle,Numero_Exterior,Numero_Interior,
			Telefono,Tel_Trabajo,Tel_Celular,Telefono_adicional,
			Ingreso_mensual,Curp,Rfc,Id_Nacionalidad,
			Id_Colonia_CNBV,Id_Ocupacion_CNBV,id_de_sucursal,Fecha_de_nacimiento)
		  select P.id_persona,
			numero,id_tipo_persona,Nombre_s,Apellido_Paterno,
			Apellido_Materno,Calle,Numero_Exterior,Numero_Interior,
			Telefono,Tel_Trabajo,Tel_Celular,Telefono_adicional,
			Ingreso_mensual,Curp,Rfc,Id_Nacionalidad,
			Id_Colonia_CNBV,Id_Ocupacion_CNBV,id_de_sucursal,Fecha_de_nacimiento 
		  from EXSOCIOS..PERSONA P 
		  JOIN EXSOCIOS..TEXTOS T ON P.ID_PERSONA=T.ID_PERSONA 
		  WHERE P.ID_PERSONA=@ID_PERSONA

		end







		--MODIFICO AOAJ720209 T167364 2da Etapa
	    --MODIFICACION: SI ES TIPO DE PERSONA 7 CONSULTA RAZON SOCIAL Y FECHA DE CONSTITUCI�N 


		select 	
			case when @id_tipo_persona=7 then hape.dbo.TBL_PM_PERSONAS_MORALES.razon_social else Nombre_s collate Traditional_Spanish_CI_AS end Nombre_s, 
			Apellido_Paterno, 
			Apellido_Materno ,
			per.Calle,
			per.Numero_Exterior,
			per.Numero_Interior,
			per.Id_Colonia_CNBV,
			Nombre_Colonia,
			Codigo_Postal,
			hape.dbo.cnbv_localidades.Clave_CNBV as localidad_cnvb,
			CNBV_Municipio,
			hape.dbo.entidad_federativa.descripcion as Estado,
			per.Telefono,
			Tel_Celular,
			Tel_Trabajo,
			Telefono_adicional,
			case when @id_tipo_persona=7 then hape.dbo.TBL_PM_PERSONAS_MORALES.fecha_constitucion else Fecha_de_nacimiento end Fecha_de_nacimiento,
			Curp,
			per.Rfc,
			suc.id_de_sucursal,
			suc.descripcion as Sucursal,
			suc.Clave_CNBV as sucursal_cnbv,
			suc.clave_sucursal_pld,
			case when @id_tipo_persona=7 then 
            case when hape.dbo.TBL_PM_PERSONAS_MORALES.id_nacionalidad IS NULL THEN 0 when hape.dbo.TBL_PM_PERSONAS_MORALES.id_nacionalidad=154 then 1 else 2 end
			else
				case when hape.dbo.nacionalidad.id_nacionalidad IS NULL then 0 when hape.dbo.nacionalidad.id_nacionalidad=154 then 1 else 2 end
			end id_nacionalidad,
			case when @id_tipo_persona=7 then 
			case when hape.dbo.TBL_PM_PERSONAS_MORALES.id_nacionalidad IS NULL THEN 'NINGUNA' when hape.dbo.TBL_PM_PERSONAS_MORALES.id_nacionalidad=154 then 'MEXICANA' else 'EXTRANJERA' end
            else
				case when hape.dbo.nacionalidad.id_nacionalidad IS NULL then 'NINGUNA' when hape.dbo.nacionalidad.id_nacionalidad=154 then 'MEXICANA' else 'EXTRANJERA' end
            end nacionalidad,
			hape.dbo.nacionalidad.codigo clvNac,
			ocup.Id_Ocupacion_CNBV,
			ocup.descripcion as ocupacion,
			case when ocup.Clave_CNBV is null or ocup.Clave_CNBV=0 then 9999999 else ocup.Clave_CNBV end Clave_CNBV,
			hape.dbo.cnbv_clasif_ocupaciones.Descripcion as sector,
			per.ingreso_mensual as sueldo,
			Lavado_dinero.dbo.lavado_alertas_detalle.contador,
			case when lavado_movimientos.id_tipomov=-1 then 'Cheque' else 'Efectivo' end as instrumento_monetario,
			lavado_dinero.dbo.lavado_movimientos.fecha_mov as fecha_movimiento,
			lavado_dinero.dbo.lavado_movimientos.id_tipomov,
			hape.dbo.tipo_mov.descripcion as tipo_operacion,
			lavado_dinero.dbo.lavado_movimientos.monto,
			NOTAS_OFICIAL_CUMPLIMIENTO1 + ' ' + NOTAS_OFICIAL_CUMPLIMIENTO2 + ' ' +	NOTAS_OFICIAL_CUMPLIMIENTO3 as notas_Dictamen,
			lavado_dinero.dbo.lavado_alertas.fecha_modifica as fecha_dictamen,
			hape.dbo.TBL_PM_PERSONAS_MORALES.nombre_comercial
		from 	#DATOS_SOCIO per  
			left outer join hape.dbo.cnbv_mnpio_col on hape.dbo.cnbv_mnpio_col.Id_Colonia_CNBV=per.Id_Colonia_CNBV 
			left outer join hape.dbo.entidad_federativa on hape.dbo.entidad_federativa.id_entidad_federativa=hape.dbo.cnbv_mnpio_col.id_entidad_federativa
			left outer join  hape.dbo.cnbv_ocupaciones ocup on ocup.Id_Ocupacion_CNBV=per.Id_Ocupacion_CNBV
			left outer join hape.dbo.cnbv_clasif_ocupaciones on hape.dbo.cnbv_clasif_ocupaciones.Id_Clasif_Ocupacion=ocup.Id_Clasif_Ocupacion
			left outer join lavado_dinero.dbo.lavado_alertas on lavado_dinero.dbo.lavado_alertas.id_alerta=@id_alerta  
			left outer join Lavado_dinero.dbo.lavado_alertas_detalle on Lavado_dinero.dbo.lavado_alertas_detalle.id_alerta=lavado_dinero.dbo.lavado_alertas.id_alerta
			left outer join lavado_dinero.dbo.Lavado_instrumento_monetario on lavado_dinero.dbo.Lavado_alertas.id_instrumento_monetario=lavado_dinero.dbo.Lavado_instrumento_monetario.id_instrumento_monetario 
			left outer join lavado_dinero.dbo.lavado_movimientos on Lavado_dinero.dbo.lavado_alertas_detalle.contador=lavado_dinero.dbo.lavado_movimientos.contador
			left outer join hape.dbo.tipo_mov on lavado_dinero.dbo.lavado_movimientos.id_tipomov = hape.dbo.tipo_mov.id_tipomov 
			left outer join hape.dbo.nacionalidad on hape.dbo.nacionalidad.id_nacionalidad=per.id_nacionalidad
			left outer join hape.dbo.cnbv_localidades on hape.dbo.cnbv_localidades.Id_Localidad_CNBV=hape.dbo.cnbv_mnpio_col.Id_Localidad_CNBV and hape.dbo.cnbv_localidades.Id_Entidad_Federativa=hape.dbo.cnbv_mnpio_col.Id_Entidad_Federativa
			left outer  join hape.dbo.sucursales suc on per.id_de_sucursal=suc.id_de_sucursal
			left outer join HAPE.dbo.TBL_PM_PERSONAS_MORALES on per.Id_Persona=HAPE.dbo.TBL_PM_PERSONAS_MORALES.id_persona
		where 	per.numero=@numero and per.id_tipo_persona=@id_tipo_persona

GO

USE [LAVADO_DINERO]
GO
/****** Object:  StoredProcedure [dbo].[SP_LAVADO_OPERACIONES_TRANSACCIONES]    Script Date: 04/03/2019 04:59:11 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*-------------------SP_LAVADO_OPERACIONES_TRANSACCIONES----------------------------------
Autor:		Gustavo Negrete
fecha:		13/07/2010
Descripcion:	Consulta transacciones del socio
-----------------------------------------------------------------------------------------*/

ALTER procedure [dbo].[SP_LAVADO_OPERACIONES_TRANSACCIONES]

@numero int,
@id_tipo_persona int 

as
--MODIFICO AOAJ720209 T167364 2da Etapa
--MODIFICACION: VALIDAR TIPO DE PERSONA , EN CASO DE QUE SEA 7 SE OBTIENE SU PERFIL TRANSACCIONAL DE LA TABLA TBL_PM_PLD 
if (@id_tipo_persona=7)
	select 
	CASE WHEN retiros_transaccionales_0_50=1 then 1 else 2 end Id_Retiro_Cant,
	CASE WHEN retiros_importe_0_50=1 then 1 
		 when retiros_importe_50_100=1 then 2
		 when retiros_importe_100_mas=1 then 3
		 end id_retiro_monto,
	CASE WHEN depositos_transaccionales_0_50=1 then 1 else 2 end Id_Deposito_Cant,
	CASE WHEN depositos_importe_0_50=1 then 1
		 WHEN depositos_importe_50_100=1 then 2
		 WHEN depositos_importe_100_mas=1 then 3 END Id_Deposito_Monto,
	CASE WHEN remesas_transaccionales_0_50=1 then 1 else 2 END Id_Remesas_Cant,
	CASE WHEN remesas_importe_0_50=1 then 1
		 WHEN remesas_importe_50_100=1 then 2
		 WHEN remesas_importe_100_mas=1 then 3 END Id_Remesas_Monto,
	utilizara id_tipo_moneda 
	from HAPE.DBO.TBL_PM_PERSONAS_MORALES PM
	INNER JOIN HAPE.DBO.TBL_PM_PLD PLD
	ON PM.id_moral=PLD.id_moral
	WHERE PM.numero=@numero

else
begin
   if exists(select 1 from HAPE..PERSONA where Numero=@numero and Id_Tipo_Persona=@id_tipo_persona)
		select 	Id_Retiro_Cant,
			Id_Retiro_Monto,
			Id_Deposito_Cant,
			Id_Deposito_Monto,
			Id_Remesas_Cant,
			Id_Remesas_Monto,
			id_tipo_moneda

		from 	hape.dbo.persona inner join hape.dbo.textos on hape.dbo.persona.numero=@numero and 
			hape.dbo.persona.id_tipo_persona=@id_tipo_persona and hape.dbo.persona.id_persona=hape.dbo.textos.id_persona
	else
	begin	  

	  select top 1
	        Id_Retiro_Cant,
			Id_Retiro_Monto,
			Id_Deposito_Cant,
			Id_Deposito_Monto,
			Id_Remesas_Cant,
			Id_Remesas_Monto,
			id_tipo_moneda

		from 
		   EXSOCIOS.dbo.persona perExsocio 
		inner join 
			EXSOCIOS.dbo.textos txtExsocios on  perExsocio.id_persona=txtExsocios.id_persona
		where Numero=@numero and Id_Tipo_Persona=@id_tipo_persona
		order by perExsocio.Id_persona desc
	end

end

GO

USE [LAVADO_DINERO]
GO
/****** Object:  StoredProcedure [dbo].[SP_LAVADO_RELEVANTE_FILTROS]    Script Date: 04/03/2019 03:12:24 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



		/*-------------------SP_LAVADO_RELEVANTE_FILTROS-----------------------------------------
		Autor:		Gustavo Negrete
		fecha:		09/10/2010
		Descripcion:	Consulta de las alertas PLD RELEVANTES
		-----------------------------------------------------------------------------------------*/

	    /*-------------------MODIFICACION-----------------------
		Autor:		Jessica Almonte Acosta
		fecha:		07/10/2015
		Descripcion:No contemplar socios utilitarios	
		-----------------------------------------------------------------------------------------*/

		ALTER   procedure [dbo].[SP_LAVADO_RELEVANTE_FILTROS]

		@numero int,
		@id_tipo_persona int,
		@fecha_ini datetime,
		@fecha_fin datetime,
		@sucursal int

		as

		declare @query nvarchar(2000)
		--MODIFICO AOAJ720209 T167364 2da Etapa
	    --MODIFICACION: SE AGREGA QUE SOLO CONTEMPLE SOCIOS UTILITARIOS CON ID TIPO PERSONA 1 
		set @query='select 
		    ID_ALERTA,
			alertas.numero,
			suc.descripcion as sucursal,
			tipo_alerta.descripcion as descripcion,
			alertas.fecha_alta as fecha_deteccion,
			alertas.id_tipo_persona
		from 	
		    lavado_dinero.dbo.lavado_alertas alertas
			inner join 	lavado_dinero.dbo.lavado_tipo_operacion tipo_op on  alertas.id_tipo_operacion=tipo_op.id_tipo_operacion 
		    join lavado_dinero.dbo.lavado_tipo_alerta tipo_alerta on tipo_alerta.id_tipo_alerta=alertas.id_tipo_alerta
			left join hape.dbo.persona per on alertas.numero=per.numero and alertas.id_tipo_persona=per.id_tipo_persona 
			left join (select max(id_persona) id_persona,numero,id_tipo_persona from exsocios..persona group by numero,id_tipo_persona) maxExsocio on maxExsocio.Numero=alertas.NUMERO and maxExsocio.Id_Tipo_Persona=alertas.ID_TIPO_PERSONA
			left join EXSOCIOS..PERSONA perExsocio on maxExsocio.id_persona=perExsocio.Id_Persona
			left join hape.dbo.sucursales suc on suc.id_de_sucursal=case when per.Numero is not null then per.Id_de_Sucursal else perExsocio.Id_de_Sucursal end 
			where   
			alertas.id_tipo_operacion=1 and 
			alertas.numero not in (SELECT socioutilitario FROM [HAPE].[dbo].[SUCURSALES] where alertas.id_tipo_persona=1)'

		if @numero is not null 
			set @query=@query + ' and alertas.NUMERO=' + convert (varchar, @numero, 1) 

		if @id_tipo_persona is not null
			set @query=@query + ' and alertas.id_tipo_persona=' +convert (varchar, @id_tipo_persona, 1)

		if @fecha_ini is not null
			set @query=@query + ' and alertas.fecha_alta >=''' + convert (varchar, @fecha_ini, 112) +''''

		if @fecha_fin is not null
			set @query=@query + ' and alertas.fecha_alta <=''' + convert (varchar, @fecha_fin, 112) +''''

		if @sucursal is not null 
			set @query=@query + ' and suc.id_dE_sucursal=' + convert (varchar, @sucursal, 1)

		set @query=@query + ' order by  alertas.fecha_alta asc'

		print @query

		exec sp_executesql @query

GO

USE [LAVADO_DINERO]
GO
/****** Object:  StoredProcedure [dbo].[SP_LAVADO_REPORTE_RELEVANTE_DATOS_PERSONALES]    Script Date: 04/03/2019 05:12:15 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


		/*-------------------SP_LAVADO_REPORTE_RELEVANTE_DATOS_PERSONALES-----------------------
		Autor:		Gustavo Negrete
		fecha:		05/07/2010
		Descripcion:	Reporte de alertas del socio dado
		-----------------------------------------------------------------------------------------*/
				
	    /*-------------------MODIFICACION-----------------------
		Autor:		Jessica Almonte Acosta
		fecha:		07/10/2015
		Descripcion:Si la clave de actividad econ�mica colocar la clave �9999999�	
		-----------------------------------------------------------------------------------------*/

		ALTER     procedure [dbo].[SP_LAVADO_REPORTE_RELEVANTE_DATOS_PERSONALES]

		@numero int,
		@id_tipo_persona int, 
		@id_alerta int 

		as

		declare @id_persona bigint=0

		CREATE TABLE #DATOS_SOCIO(
			id_persona bigint,
			numero bigint,
			id_tipo_persona int,
			Nombre_s	varchar(40) NULL,
			Apellido_Paterno	varchar(40) NULL,
			Apellido_Materno	varchar(40) NULL,
			Calle	varchar	(60) NULL,
			Numero_Exterior	varchar(10) NULL,
			Numero_Interior	varchar(10) NULL,
			Telefono varchar(15) NULL,
			Tel_Trabajo	varchar(15) NULL,
			Tel_Celular	varchar(15) NULL,
			Telefono_adicional	varchar(15) NULL,
			Ingreso_mensual	float NULL,
			Curp varchar(18) NULL,
			Rfc	varchar(15) NULL,
			Id_Nacionalidad	smallint NULL,
			Id_Colonia_CNBV INT NULL,
			Id_Ocupacion_CNBV INT NULL,
			id_de_sucursal INT NULL,
			Fecha_de_nacimiento DATETIME NULL
					
		)

		select @id_persona=id_persona from hape..persona where numero=@numero and id_tipo_persona=@id_tipo_persona

		if(@id_persona>0)
		begin
		 
		  INSERT INTO #DATOS_SOCIO(id_persona,
			numero,id_tipo_persona,Nombre_s,Apellido_Paterno,
			Apellido_Materno,Calle,Numero_Exterior,Numero_Interior,
			Telefono,Tel_Trabajo,Tel_Celular,Telefono_adicional,
			Ingreso_mensual,Curp,Rfc,Id_Nacionalidad,
			Id_Colonia_CNBV,Id_Ocupacion_CNBV,id_de_sucursal,Fecha_de_nacimiento)
		  select P.id_persona,
			numero,id_tipo_persona,Nombre_s,Apellido_Paterno,
			Apellido_Materno,Calle,Numero_Exterior,Numero_Interior,
			Telefono,Tel_Trabajo,Tel_Celular,Telefono_adicional,
			Ingreso_mensual,Curp,Rfc,Id_Nacionalidad,
			Id_Colonia_CNBV,Id_Ocupacion_CNBV,id_de_sucursal,Fecha_de_nacimiento 
		  from HAPE..PERSONA P 
		  JOIN HAPE..TEXTOS T ON P.ID_PERSONA=T.ID_PERSONA 
		  WHERE P.ID_PERSONA=@ID_PERSONA
		end
		else
		begin
		  SET @ID_PERSONA=(SELECT max(ID_PERSONA) FROM EXSOCIOS.DBO.PERSONA WHERE Numero=@NUMERO AND Id_Tipo_Persona=@ID_TIPO_PERSONA)

		  INSERT INTO #DATOS_SOCIO(id_persona,
			numero,id_tipo_persona,Nombre_s,Apellido_Paterno,
			Apellido_Materno,Calle,Numero_Exterior,Numero_Interior,
			Telefono,Tel_Trabajo,Tel_Celular,Telefono_adicional,
			Ingreso_mensual,Curp,Rfc,Id_Nacionalidad,
			Id_Colonia_CNBV,Id_Ocupacion_CNBV,id_de_sucursal,Fecha_de_nacimiento)
		  select P.id_persona,
			numero,id_tipo_persona,Nombre_s,Apellido_Paterno,
			Apellido_Materno,Calle,Numero_Exterior,Numero_Interior,
			Telefono,Tel_Trabajo,Tel_Celular,Telefono_adicional,
			Ingreso_mensual,Curp,Rfc,Id_Nacionalidad,
			Id_Colonia_CNBV,Id_Ocupacion_CNBV,id_de_sucursal,Fecha_de_nacimiento 
		  from EXSOCIOS..PERSONA P 
		  JOIN EXSOCIOS..TEXTOS T ON P.ID_PERSONA=T.ID_PERSONA 
		  WHERE P.ID_PERSONA=@ID_PERSONA

		end

		--MODIFICO AOAJ720209 T167364 2da Etapa
	    --MODIFICACION: SI ES TIPO DE PERSONA 7 CONSULTA RAZON SOCIAL Y FECHA DE CONSTITUCI�N 
			select
				case when  @id_tipo_persona=7 then PM.razon_social else P.Nombre_s COLLATE Traditional_Spanish_CI_AS end Nombre_s , 
				Apellido_Paterno, 
				Apellido_Materno ,
				P.Calle,
				P.Numero_Exterior,
				P.Numero_Interior,
				P.Id_Colonia_CNBV,
				Nombre_Colonia,
				Codigo_Postal,
				loc.Clave_CNBV as localidad_cnvb,
				CNBV_Municipio,
				edo.descripcion as Estado,
				P.Telefono,
				Tel_Celular,
				Tel_Trabajo,
				Telefono_adicional,
				case when  @id_tipo_persona=7 then PM.fecha_constitucion else Fecha_de_nacimiento end Fecha_de_nacimiento,
				Curp,
				P.Rfc,	
				suc.id_de_sucursal id_de_sucursal,
				suc.clave_sucursal_pld,--Modifico aoaj720209 27/06/2018 Se consulta clave de sucursal 	
				suc.Clave_CNBV as sucursal_cnbv,
				case when @id_tipo_persona=7 then 
				     case when PM.id_nacionalidad IS null then 0 when PM.id_nacionalidad=154 then 1 else 2 end
				else
					case when nac.id_nacionalidad IS null then 0 when nac.id_nacionalidad=154 then 1 else 2 end
				end id_nacionalidad,
				case when @id_tipo_persona=7 then 
				     case when PM.id_nacionalidad IS null then 'NINGUNA' when PM.id_nacionalidad=154 then 'MEXICANA' else 'EXTRANJERA' end
				else
			    	case when nac.id_nacionalidad IS NULL THEN 'NINGUNA' when nac.id_nacionalidad=154 then 'MEXICANA' else 'EXTRANJERA' end
				end nacionalidad,
				nac.codigo clvNac,
				ocup.Id_Ocupacion_CNBV,
				case when ocup.Clave_CNBV is null or ocup.Clave_CNBV=0 then 9999999 else ocup.Clave_CNBV end Clave_CNBV,
				ocup.descripcion as ocupacion,
				sector.Descripcion as sector,
				P.ingreso_mensual as sueldo,
				Lavado_dinero.dbo.lavado_alertas_detalle.contador,
				case when movs.id_tipomov=-1 then 'Cheque' else 'Efectivo' end as instrumento_monetario,
				movs.fecha_mov as fecha_movimiento,
				movs.id_tipomov,
				case when movs.ID_TIPOMOV=-1 then 'Cheque' else  hape.dbo.tipo_mov.descripcion end as tipo_operacion,
				movs.monto,
			    PM.nombre_comercial 
			from 	#DATOS_SOCIO P
			    left outer join HAPE.dbo.TBL_PM_PERSONAS_MORALES PM on P.Id_Persona=PM.id_persona 
				left outer  join hape.dbo.cnbv_mnpio_col col on col.Id_Colonia_CNBV=P.Id_Colonia_CNBV
				left outer join hape.dbo.entidad_federativa edo on edo.id_entidad_federativa=col.id_entidad_federativa
				left outer join  hape.dbo.cnbv_ocupaciones ocup on ocup.Id_Ocupacion_CNBV=P.Id_Ocupacion_CNBV
				left outer join hape.dbo.cnbv_clasif_ocupaciones sector on sector.Id_Clasif_Ocupacion=ocup.Id_Clasif_Ocupacion
				Left outer join lavado_dinero.dbo.lavado_alertas alertas on alertas.id_alerta=@id_alerta 
				left outer join Lavado_dinero.dbo.lavado_alertas_detalle on Lavado_dinero.dbo.lavado_alertas_detalle.id_alerta=alertas.id_alerta
				left outer join lavado_dinero.dbo.lavado_movimientos movs on Lavado_dinero.dbo.lavado_alertas_detalle.contador=movs.contador
				left outer join hape.dbo.tipo_mov on movs.id_tipomov = hape.dbo.tipo_mov.id_tipomov 
				left outer join hape.dbo.nacionalidad nac on nac.id_nacionalidad=P.id_nacionalidad
				left outer join hape.dbo.cnbv_localidades loc on loc.Id_Localidad_CNBV=col.Id_Localidad_CNBV and loc.Id_Entidad_Federativa=edo.Id_Entidad_Federativa
				left outer  join hape.dbo.sucursales suc on P.id_de_sucursal=suc.id_de_sucursal
			where 	P.numero=@numero and P.id_tipo_persona=@id_tipo_persona

GO

use LAVADO_DINERO
go

-- se crea procedimiento SP_LAVADO_DINERO_OBTENER_DETALLE_TRANSFERENCIA
if exists (select * from sysobjects where name like 'SP_LAVADO_DINERO_OBTENER_DETALLE_TRANSFERENCIA' and xtype = 'p' and db_name() = 'LAVADO_DINERO')
	drop proc SP_LAVADO_DINERO_OBTENER_DETALLE_TRANSFERENCIA
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20180121
Objetivo		Obtener detalle de la transferencia
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_LAVADO_DINERO_OBTENER_DETALLE_TRANSFERENCIA
	
	@folio bigint
	
as

	begin -- procedimiento

			-- ORIGEN
			select 
				1 orden,
				origen.NUMERO,
				origen.CUENTA,
				op.Desc_prestamo NOMBRE_CUENTA,
				'Env�o de dinero por transferencia' DESCRIPCION,
				transf.MONTO			
			from 
			[dbo].[TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA] transf 
			inner join hape..tbl_corresponsalias_cuentas origen on 
			transf.clave_corresponsalias_origen collate Traditional_Spanish_CI_AS=origen.cuenta collate Traditional_Spanish_CI_AS
			inner join HAPE..TIPOS_DE_OPERACIONES op on origen.ID_MOV=op.Id_mov
			where id_banca_folio=@folio 

			-- DESTINO
			UNION 
			select 
				2 orden,
				dest.NUMERO,
				dest.CUENTA,
				op.Desc_prestamo NOMBRE_CUENTA,
				'Recepci�n de dinero por transferencia' DESCRIPCION,
				transf.MONTO
			from [dbo].[TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA] transf 
			inner join hape..tbl_corresponsalias_cuentas dest on transf.clave_corresponsalias_DESTINO collate Traditional_Spanish_CI_AS=dest.cuenta collate Traditional_Spanish_CI_AS
			inner join HAPE..TIPOS_DE_OPERACIONES op on dest.ID_MOV=op.Id_mov
			where id_banca_folio=@folio 
			order by orden

				
	end -- procedimiento
go

grant exec on SP_LAVADO_DINERO_OBTENER_DETALLE_TRANSFERENCIA to public

use LAVADO_DINERO
go

-- se crea procedimiento SP_LAVADO_DINERO_OBTENER_INFORMACI�N_SOCIO
if exists (select * from sysobjects where name like 'SP_LAVADO_DINERO_OBTENER_INFORMACIÓN_SOCIO' and xtype = 'p' and db_name() = 'LAVADO_DINERO')
	drop proc SP_LAVADO_DINERO_OBTENER_INFORMACIÓN_SOCIO
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20190117
Objetivo		Obtener informaci�n del socio
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_LAVADO_DINERO_OBTENER_INFORMACIÓN_SOCIO
	
	@numero int,
	@id_tipo_persona int
	
as

	begin -- procedimiento
	
		begin try -- try principal
		
		  select 
		  per.nombre_s,
		  per.apellido_paterno,
		  per.apellido_materno,
		  per.calle,
		  per.numero_exterior,
		  per.numero_interior,
		  nombre_colonia,
		  codigo_postal,
		  cnbv_municipio,
		  ent.descripcion as estado,
		  per.Telefono,
		  per.Fecha_de_nacimiento,
		  nac.DESCRIPCION nacionalidad,
		  paisNac.Descripcion NomPaisNac,
		  per.rfc,
		  per.curp,
		  ocu.descripcion ocupacion,
		  clasif.Descripcion sector
		  --a.id_persona,a.id_colonia_cnbv,a.id_de_sucursal,a.id_ocupacion_cnbv,a.nombre_s,a.apellido_paterno,
          --a.apellido_materno,a.calle,a.numero_exterior,a.numero_interior,a.fecha_de_nacimiento,a.telefono,a.rfc,a.curp,case when b.id_nacionalidad Is null then 0 when b.id_nacionalidad=154 then 1 else 2 end id_nacionalidad
          from HAPE..persona per 
		  inner join HAPE..textos txt on per.id_persona=txt.id_persona
		  left join
			HAPE..CNBV_MNPIO_COL col on per.Id_Colonia_CNBV = col.Id_Colonia_CNBV
		  LEFT join
			HAPE..CNBV_LOCALIDADES loc on col.Id_Localidad_CNBV = loc.Id_Localidad_CNBV and col.Id_Entidad_Federativa = loc.Id_Entidad_Federativa
		  LEFT join
			HAPE..ENTIDAD_FEDERATIVA ent on loc.Id_Entidad_Federativa = ent.ID_ENTIDAD_FEDERATIVA
		  LEFT JOIN 
			HAPE..cnbv_ocupaciones ocu on ocu.Id_Ocupacion_CNBV=per.Id_Ocupacion_CNBV
          LEFT join 
			HAPE..cnbv_clasif_ocupaciones clasif on ocu.id_clasif_ocupacion=clasif.id_clasif_ocupacion
		  left join
			HAPE..NACIONALIDAD nac on txt.Id_Nacionalidad = nac.ID_NACIONALIDAD
		  left join 
			HAPE..ENTIDAD_FEDERATIVA entNac on txt.ID_ENTIDAD_FEDERATIVA_DE_NACIMIENTO=entNac.ID_ENTIDAD_FEDERATIVA
		  left join 
			HAPE..CAT_PAISES paisNac on paisNac.Id_Pais= case when txt.id_pais_de_nacimiento=1 then entNac.id_pais else txt.id_pais_de_nacimiento end
          where per.numero=@numero and per.id_tipo_persona=@id_tipo_persona

			
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- [selecci�n en caso de que el select del try falle]
		
		end catch -- catch principal
		
	end -- procedimiento
go

grant exec on SP_LAVADO_DINERO_OBTENER_INFORMACIÓN_SOCIO to public

USE [LAVADO_DINERO]
GO
/****** Object:  StoredProcedure [dbo].[SP_OBTENER_SUMA_DE_MOVIMIENTOS_EN_EFECTIVO]    Script Date: 18/12/2019 03:00:34 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:        <Jessica Almonte Acosta>
-- Create date: <9 de Noviembre de 2015>
-- Description:   <Jessica Almonte Acosta>
-- =============================================
ALTER PROCEDURE [dbo].[SP_OBTENER_SUMA_DE_MOVIMIENTOS_EN_EFECTIVO] 
   @FechaInicio DATE,
   @FechaFin DATE,
  -- @TipoOperacion int, -- 1 relevantes y 2 inusuales
   @id_tipo_alerta int
AS
BEGIN

      SET NOCOUNT ON;

	  declare  @dolar money,@monto_limite_dolares money=0
     
       IF OBJECT_ID('tempdb..#TEMPFOLIOS') IS NOT NULL
         DROP TABLE #TEMPFOLIOS;

        create table #TEMPFOLIOS(
            folio int default 0,
            suma_depositos money null,
            suma_retiros money null,
            suma_cheques money null,
            numero int,
            id_tipo_persona int,
            MONTO1 MONEY null,
			id_origen int null

     )

		select @monto_limite_dolares=monto from CAT_LAVADO_TIPO_PARAMETRO where id=1
		select @dolar = valor from LAVADO_TIPO_CAMBIO_DOLAR where contador = (select max(contador) from LAVADO_TIPO_CAMBIO_DOLAR where fecha_alta < @FechaFin)

	 	select
		    mov.NUMERO,
			mov.ID_TIPO_PERSONA,	 
			mov.id_tipomov,
			mov.monto,
			mov.FOLIO,
			mov.TIPO_POLIZA,	
			coalesce(t.id_operacion_pld,0) id_operacion_pld,
			isnull(id_origen,1) id_origen						
			into #operaciones
			from lavado_dinero.dbo.lavado_movimientos mov 
			left outer join HAPE..TIPO_MOV t on mov.ID_TIPOMOV=t.Id_tipomov
			where ((numero not in (SELECT socioutilitario FROM [HAPE].[dbo].[SUCURSALES] where ID_TIPO_PERSONA=1)) AND (id_tipo_persona IN (1,2,7))) AND 
                  ((fecha_mov>=@FECHAINICIO) AND (fecha_mov<@FECHAFIN)) AND (TIPO_POLIZA='M' OR TIPO_POLIZA=CASE WHEN @id_tipo_alerta in (5,17) THEN 'M' ELSE 'E' END)
            
			--Obtenemos todos los socios que tuvieron movimientos en ese mes
			select
		    NUMERO,
			ID_TIPO_PERSONA		
			into #socios
			from #operaciones
            group by NUMERO,ID_TIPO_PERSONA

			--Eliminamos las transferencias para que no se consideren en el calculo del flujo de efectivo		
			if(@id_tipo_alerta=8) 
			begin	
				delete #operaciones where ID_TIPOMOV in (331,332,333,334,335,336,337,338,339,702,1100,701,-1)
			end

		  --Si son relevantes excluimos las operacion con id_tipo_origen 3,4 banca electronica ya que no es flujo de efectivo
			  if(@id_tipo_alerta in (5,17))
				delete #operaciones where id_origen in (3,4)


 
      insert into #TEMPFOLIOS (numero, id_tipo_persona,folio,suma_depositos,suma_retiros,suma_cheques,id_origen)
      SELECT numero, 
			id_tipo_persona,
			folio,
			(SELECT Sum(Monto) From #operaciones op Where op.NUMERO=R.NUMERO and op.ID_TIPO_PERSONA = R.ID_TIPO_PERSONA and op.Folio=R.FOLIO and op.id_origen=r.id_origen and id_operacion_pld=1),
            (SELECT Sum(Monto) From #operaciones op Where op.NUMERO=R.NUMERO and op.ID_TIPO_PERSONA = R.ID_TIPO_PERSONA and op.Folio=R.FOLIO and op.id_origen=r.id_origen and id_operacion_pld=2),
            (SELECT Sum(Monto) From #operaciones op Where op.NUMERO=R.NUMERO and op.ID_TIPO_PERSONA = R.ID_TIPO_PERSONA and op.Folio=R.FOLIO and op.id_origen=r.id_origen and ID_TIPOMOV=-1),
			id_origen
      FROM #operaciones R
    group by numero,id_tipo_persona,folio,id_origen
    ORDER BY numero

      UPDATE #TEMPFOLIOS SET suma_depositos = 0 WHERE suma_depositos IS NULL
      UPDATE #TEMPFOLIOS SET suma_cheques = 0 WHERE suma_cheques IS NULL
      UPDATE #TEMPFOLIOS SET suma_retiros = 0 WHERE suma_retiros IS NULL

      UPDATE #TEMPFOLIOS  
            
            set         #TEMPFOLIOS.MONTO1 = b.MONTO1
                        
            From    (
                       --Modifico aoaj720209 T181317 
                             --SELECT suma_depositos - suma_retiros MONTO1, folio, numero, id_tipo_persona
                             SELECT         --case when suma_depositos>=suma_retiros then 
                                            --   case when (suma_depositos-suma_retiros)>=suma_cheques then 
                                            --         (suma_depositos-suma_retiros)-suma_cheques else  suma_depositos-suma_retiros end
                                            --   else abs(suma_depositos-suma_retiros) end MONTO1, 
											case when suma_depositos>=suma_retiros then 
                                               case when suma_cheques>0 and (suma_depositos-suma_retiros)>0 then 
											         abs((suma_depositos-suma_retiros)-suma_cheques)
											   else  suma_depositos-suma_retiros end
                                            else abs(suma_depositos-suma_retiros) end MONTO1,
											folio, numero, id_tipo_persona,id_origen
                             FROM #TEMPFOLIOS --WHERE suma_depositos > suma_retiros
                        ) b
            where       #TEMPFOLIOS.folio = B.folio AND #TEMPFOLIOS.numero = B.numero
                    AND #TEMPFOLIOS.id_tipo_persona = B.id_tipo_persona
					and #TEMPFOLIOS.id_origen=B.id_origen

        DELETE FROM #TEMPFOLIOS WHERE MONTO1 IS NULL

		if (@id_tipo_alerta=5)
				select numero,id_tipo_persona,folio,id_origen,SUM(MONTO1) SumaEfectivo
				from #TEMPFOLIOS		
				group by numero ,id_tipo_persona,folio,id_origen
				having SUM(Monto1)>90000 		
				order by numero

		if (@id_tipo_alerta=8)
		begin
	
			insert into #TEMPFOLIOS (MONTO1,numero, id_tipo_persona)
			exec SP_ATM_LAVADO_TOTAL_EFECTIVO null,@FECHAINICIO,@fechafin

			select 
			numero,
			id_tipo_persona,
			sum(MONTO1) SumaEfectivo
			from #TEMPFOLIOS f 
			group by numero ,id_tipo_persona
			having SUM(Monto1)>= @monto_limite_dolares * @dolar
			order by numero
		end

		if (@id_tipo_alerta=17)
			select numero,id_tipo_persona,SUM(MONTO1) SumaEfectivo
			from #TEMPFOLIOS		
			group by numero ,id_tipo_persona
			having SUM(Monto1)>1000000 		
			order by numero

END

GO

USE [LAVADO_DINERO]
GO
/****** Object:  StoredProcedure [dbo].[SP_LAVADO_RECONSTRUYE_MOVIMIENTOS]    Script Date: 04/12/2019 10:11:20 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Gabriela Espinoza Huitrón
UsuarioRed		eihg856318
Fecha			20190705
Objetivo		Automatizar la migración de tablas
Proyecto		Proyecto Robot PLD Diario
Ticket			------------------

*/

ALTER proc

	[dbo].[SP_LAVADO_RECONSTRUYE_MOVIMIENTOS]

		-- parámetros
		-- @fecha datetime = null
			@fecha datetime 
		

as

	begin -- procedimiento

		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				declare	@tran_name varchar(32) = 'NOMBRE_TRANSACCION',
						@tran_count int = @@trancount,
						@tran_scope bit = 0
						
				-- select @fecha = coalesce(@fecha, getdate())
			
			end -- inicio


			begin

			if object_id('tempdb..#movimientos') is not null drop table #movimientos
			if object_id('tempdb..#captura') is not null drop table #captura
			if object_id('tempdb..#captura_lacp') is not null drop table #captura_lacp
			if object_id('tempdb..#TBL_HIPOTECARIO_PAGOS_REALIZADOS') is not null drop table #TBL_HIPOTECARIO_PAGOS_REALIZADOS
			if object_id('tempdb..#TMP') is not null drop table #TMP

			end
			
			begin -- transacción	



				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
/*******************SCRIPT RECONSTRUYE MOVIMIENTOS *****************/
			--declare @fecha datetime='20190601'
			
			DELETE FROM LAVADO_MOVIMIENTOS WHERE CONVERT(DATE,FECHA_MOV)=convert(DATE,@fecha)
			DELETE FROM LAVADO_DINERO.DBO.LAVADO_NOMBRES WHERE convert(DATE,FECHA_ALTA)=convert(DATE,@fecha)
			DELETE  LAVADO_DINERO.DBO.TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA WHERE cast(fecha_transferencia_realizada as date)=convert(DATE,@fecha)


			select * 
			into #movimientos
			from ARCHIVO_HISTORICO.dbo.movimientos_haberes
			where convert(date,fecha_mov)=convert(DATE,@fecha)



			insert #movimientos
			select * 
			from ARCHIVO_HISTORICO.dbo.MOVIMIENTOS_PTMOS_LIQUIDADOS
			where convert(date,fecha_mov)=convert(DATE,@fecha)

			insert #movimientos
			select * 
			from HISTORICO.dbo.movimientos_haberes
			where convert(date,fecha_mov)=convert(DATE,@fecha)

			insert #movimientos
			select * 
			from hape.dbo.movimientos
			where convert(date,fecha_mov)=convert(DATE,@fecha)

			select * 
			into #captura
			from historico..CAPTURA
			where convert(date,fecha_mov)=convert(DATE,@fecha)
 
			 select * 
			into #captura_lacp
			from historico..CAPTURA_LACP
			where convert(date,fecha_mov)=convert(DATE,@fecha)

			select * 
			into #TBL_HIPOTECARIO_PAGOS_REALIZADOS
			from HAPE.DBO.TBL_HIPOTECARIO_PAGOS_REALIZADOS
			where convert(date,fecha_alta)=convert(DATE,@fecha)

			--------------LAVADO MIGRACION NOMBRES

			INSERT INTO LAVADO_DINERO.DBO.LAVADO_NOMBRES
			(NUMERO, ID_TIPO_PERSONA,NOMBRE_S, APELLIDO_PATERNO, 
			APELLIDO_MATERNO, FECHA_ALTA)
			SELECT DISTINCT NUMERO,ID_TIPO_PERSONA,
			CAST(
			case when ID_TIPO_PERSONA=7 THEN (SELECT RAZON_SOCIAL FROM HAPE.dbo.TBL_PM_PERSONAS_MORALES WHERE id_persona=P.Id_Persona) ELSE NOMBRE_S END
			AS CHAR(30)) NOMBRE_S ,
			APELLIDO_PATERNO, APELLIDO_MATERNO, FECHA_ALTA
			FROM HAPE.DBO.PERSONA P
			WHERE ID_TIPO_PERSONA IN (1,7) AND 
			NUMERO IS NOT NULL AND convert(DATE,FECHA_ALTA)=convert(DATE,@fecha)
			ORDER BY NUMERO

 
			-- LAVADO MIGRACION 2 MOVIMIENTOS
	
				-- PASO 1

			INSERT INTO LAVADO_DINERO.DBO.LAVADO_MOVIMIENTOS
			(NUMERO, FECHA_MOV, FECHA_ALTA, FECHA_DPF_FINAL, 
			MONTO, SALDO, TIPO_POLIZA, NUM_POLIZA, FOLIO, 
			NUMUSUARIO, ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA,
			NUM_DPF, DIAS,TRANFERENCIA,ID_ORIGEN)
			SELECT NUMERO, FECHA_MOV, FECHA_ALTA, FECHA_DPF_FINAL, MONTO, SALDO, TIPO_POLIZA, NUM_POLIZA, FOLIO, 
			NUMUSUARIO, ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, NUM_DPF, DIAS,
			CASE WHEN transf.contador>0 then 1 else 0 end Transferencia,ID_ORIGEN
			FROM #movimientos movs
			left join (SELECT MOV.Contador FROM #movimientos MOV INNER JOIN
				(
					select folio,NUMUSUARIO,Num_Poliza,Numero,Id_Tipo_persona,Id_Tipomov,Cuenta,Monto,ID_mov from #captura_lacp where DEBE_HABER = 'd' and monto > 0 AND cast(FECHA_ALTA as date)=convert(DATE,@fecha) and numero not in (select socioutilitario from HAPE.DBO.SOCIO_UTILITARIO)  AND cuenta = '11100700000000'
					UNION 
					select folio,NUMUSUARIO,Num_Poliza,Numero,Id_Tipo_persona,Id_Tipomov,Cuenta,Monto,ID_mov from #captura_lacp where DEBE_HABER = 'h' and monto > 0 AND cast(FECHA_ALTA as date)=convert(DATE,@fecha) and numero not in (select socioutilitario from HAPE.DBO.SOCIO_UTILITARIO) AND cuenta = '11100700000000'
				)C
				ON mov.Numero = c.Numero and mov.Folio = c.Folio and mov.Num_Poliza = c.Num_Poliza and mov.Monto = c.Monto
				WHERE mov.ACTIVO='T' AND cast(FECHA_ALTA as date)=convert(DATE,@fecha)) transf on movs.contador=transf.contador
			WHERE 
			ACTIVO='T' AND 
			id_origen not in (3,4) AND--excluimos los movimientos de banca
			cast(FECHA_ALTA as date)=convert(DATE,@fecha) AND 
			ID_TIPOMOV NOT IN (610, 620, 1004, 1005, 1006, 1007, 1008, 1009, 1013, 1014, 1015,
			1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1028, 1029, 1030, 1031, 1036, 1037,1100, 1150, 1151, 250,150,331,332,333,334,335,336,337,338,339) AND 
			NUMUSUARIO <> 1024 
			ORDER BY movs.CONTADOR

			--Migramos los movimientos de banca
			INSERT INTO LAVADO_DINERO.DBO.LAVADO_MOVIMIENTOS
			(NUMERO, FECHA_MOV, FECHA_ALTA, FECHA_DPF_FINAL, 
			MONTO, SALDO, TIPO_POLIZA, NUM_POLIZA, FOLIO, 
			NUMUSUARIO, ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA,
			NUM_DPF, DIAS,TRANFERENCIA,ID_ORIGEN)
			SELECT NUMERO, FECHA_MOV, FECHA_ALTA, FECHA_DPF_FINAL, MONTO, SALDO, TIPO_POLIZA, NUM_POLIZA, FOLIO, 
			NUMUSUARIO, ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, NUM_DPF, DIAS,
			1 Transferencia,ID_ORIGEN
			FROM #movimientos movs
			where ACTIVO='T' AND 
			id_origen in (3,4) AND
			cast(FECHA_ALTA as date)=convert(DATE,@fecha) 
			ORDER BY movs.CONTADOR 

			--Migramos las transferencias
			INSERT INTO LAVADO_DINERO.DBO.TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA(id_transferencia,
			id_cuenta_interna,
			monto,
			fecha_alta_transferencia,
			fecha_transferencia_realizada,
			id_estatus_transferencia,
			numero_socio,
			fecha_programada,
			id_banca_folio,
			clave_corresponsalias_origen,
			clave_corresponsalias_destino,
			programada)
			SELECT id_transferencia,
			id_cuenta_interna,
			monto,
			fecha_alta_transferencia,
			fecha_transferencia_realizada,
			id_estatus_transferencia,
			numero_socio,
			fecha_programada,
			id_banca_folio,
			clave_corresponsalias_origen,
			clave_corresponsalias_destino,
			programada
			FROM banca.[dbo].[TBL_BANCA_TRANSFERENCIAS_INTERNAS] 
			WHERE 
			id_estatus_transferencia=2 
			AND cast(fecha_transferencia_realizada as date)=convert(DATE,@fecha) 

				-- PASO 2

			INSERT LAVADO_MOVIMIENTOS(NUMERO,FECHA_MOV,FECHA_ALTA,FECHA_DPF_FINAL,MONTO,SALDO,TIPO_POLIZA,NUM_POLIZA,FOLIO,NUMUSUARIO,ID_TIPOMOV,ID_MOV,ID_TIPO_PERSONA,NUM_CHEQ,DESC1,BANCO,NUM_DPF,DIAS,tranferencia,ID_ORIGEN)		
			SELECT H.numero,H.Fecha_alta, H.Fecha_alta,NULL,H.monto_pago, hd.saldo_vigente,
			c.tipo_poliza, c.num_poliza, 
			H.folio,H.numusuario, 
			C.id_tipomov, C.id_mov,c.id_tipo_persona,NULL,NULL,NULL,NULL,NULL,NULL,c.ID_ORIGEN
			FROM #TBL_HIPOTECARIO_PAGOS_REALIZADOS H
			INNER JOIN #captura C ON  H.FOLIO=C.FOLIO  and h.activo=c.activo
			left join HAPE.DBO.TBL_HIPOTECARIO_DEUDORES  HD ON H.NUMERO=HD.NUMERO
			WHERE id_tipomov=1034 and H.activo='T' and   cast(h.FECHA_ALTA as date)=convert(DATE,@fecha)

			-- JOB  LAVADO MIGRACION 2 SERVICIOS

			INSERT INTO LAVADO_MOVIMIENTOS(NUMERO, FECHA_MOV, FECHA_ALTA, MONTO, TIPO_POLIZA, NUM_POLIZA, FOLIO, NUMUSUARIO, ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, NUM_CHEQ,tranferencia,ID_ORIGEN)
			SELECT NUMERO, FECHA_MOV, FECHA_ALTA, MONTO, 
			TIPO_POLIZA, NUM_POLIZA, FOLIO, NUMUSUARIO, 
			ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, NUM_CHEQ,
			case when cuenta like '11100700000000' then 1 else 0 end transferencia,ID_ORIGEN
			FROM #captura
			WHERE ACTIVO='T' AND cast(FECHA_ALTA as date)=convert(DATE,@fecha)
			AND ID_TIPOMOV IN 
			(701,702,901,902,903,904,905,906,907,908,909,910,911,912)
			ORDER BY CONTADOR

			-- JOB LAVADO MIGRACION 4 CHEQUES

			CREATE TABLE #TMP
			(
				CONTADOR INT IDENTITY (1,1),
				NUMUSUARIO INT,
				BUSCADO CHAR(1)
			)
			DECLARE @MIN_NUMUSUARIO INT
			DECLARE @MAX_NUMUSUARIO INT
			BEGIN
				INSERT INTO #TMP (NUMUSUARIO, BUSCADO)
				SELECT DISTINCT(NUMUSUARIO), 'F'
				FROM #captura
				WHERE ACTIVO='T' AND cast(FECHA_ALTA as date)=convert(DATE,@fecha)
				AND ID_TIPOMOV=-1
	
				SELECT @MIN_NUMUSUARIO=MIN(NUMUSUARIO) FROM #TMP
				SELECT @MAX_NUMUSUARIO=MAX(NUMUSUARIO) FROM #TMP
			
				WHILE @MIN_NUMUSUARIO<=@MAX_NUMUSUARIO
				BEGIN
					INSERT LAVADO_MOVIMIENTOS(NUMERO, FECHA_MOV, FECHA_ALTA, MONTO,TIPO_POLIZA, NUM_POLIZA,FOLIO, NUMUSUARIO, ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, NUM_CHEQ, BANCO)
					SELECT NUMERO, FECHA_MOV, FECHA_ALTA, MONTO,TIPO_POLIZA, NUM_POLIZA,
					FOLIO, NUMUSUARIO, ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, NUM_CHEQ, BANCO
					FROM #captura
					WHERE NUMUSUARIO=@MIN_NUMUSUARIO
					AND cast(FECHA_ALTA as date)=convert(DATE,@fecha)
					AND FOLIO IN (
						SELECT DISTINCT(FOLIO) FROM #captura
						WHERE NUMUSUARIO=@MIN_NUMUSUARIO
						AND cast(FECHA_ALTA as date)=convert(DATE,@fecha)
						AND ID_TIPOMOV =-1
					) AND ID_TIPOMOV=-1
					UPDATE #TMP SET BUSCADO='T' WHERE NUMUSUARIO=@MIN_NUMUSUARIO
					SELECT @MIN_NUMUSUARIO=MIN(NUMUSUARIO) 	FROM #TMP WHERE BUSCADO='F';
				END
			END

	
/*******************SCRIPT RECONSTRUYE MOVIMIENTOS *****************/
					
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacción se inició dentro de este ámbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacción se inició dentro de este ámbito
				
				end -- commit

				
				end -- inicio
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = 0,
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
						
			-- revertir transacción si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
		--Se inserta la operación en LOG_JOBS
		insert into TBL_LOG_JOBS(nombre_job,fecha_alta,total_registros,id_estatus, error_mensaje)
		values('RECONSTRUIR_MOVIMIENTOS', @fecha, (select count(*) from LAVADO_MOVIMIENTOS where cast(FECHA_MOV as date)=cast( @fecha as date)) ,@status, @error_message)

			select	@status estatus,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento

go

use LAVADO_DINERO
go

-- se crea procedimiento SP_LAVADO_DINERO_OBTIENE_ESTATUS_JOB
if exists (select * from sysobjects where name like 'SP_LAVADO_DINERO_OBTIENE_ESTATUS_JOB' and xtype = 'p' and db_name() = 'LAVADO_DINERO')
	drop proc SP_LAVADO_DINERO_OBTIENE_ESTATUS_JOB
go

/*

Autor			Gabriela Espinoza Huitrón
UsuarioRed		eihg856318
Fecha			20191010
Objetivo		Validar que se haya ejecutado el job RECONSTRUYE_MOVIMIENTOS, antes de la ejecución del RobotPLDDiario
Proyecto		PLD
Ticket			--------

*/

create proc

	SP_LAVADO_DINERO_OBTIENE_ESTATUS_JOB
	
		-- parámetros
		
		 @fecha_robot date 

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
                declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@total_registros int
				
			
			end -- inicio
		
		if not exists ( select id_estatus from lavado_dinero.dbo.TBL_LOG_JOBS where id_estatus = 1 and cast(fecha_alta as date)= cast(@fecha_robot as date) and total_registros>0   and nombre_job = 'RECONSTRUIR_MOVIMIENTOS')
			raiserror('No se ha ejecutado el proceso de reconstrucción de movimientos', 11, 0)

		-- eihg8563. SE HACE ASÍ PORQUE LA CONFIGURACIÓN DEL USUARIO ROBOT_PLD ES DISTINTA A LA DE SA_TEMP
		-- SELECT @@DATEFIRST; -- VALIDAR EN AMBOS USUARIOS 
		-- select  DATEPART(dw, '20200107')
		--SET DATEFIRST 3; NO SE UTILIZA DATEFIRST PARA QUE ALTERAR LOS DEMÁS PROCESOS
		IF ( DATEPART(dw, @fecha_robot) in (2,3,4,5,6) ) 
		  IF NOT EXISTS (select 1 from HAPE.[dbo].[TBL_DIAS_INHABILES_CALENDARIO] where inhabil = 1 AND CONVERT(DATE,@fecha_robot) = CONVERT(DATE,fecha))
				IF NOT EXISTS (select  top 1 * from LAVADO_TIPO_CAMBIO_DOLAR where CONVERT (DATE,fecha_alta) = CONVERT(DATE,@fecha_robot))
					raiserror('No se encuentra el tipo de cambio del dolar en el día', 11, 0)


		select @status=id_estatus, @total_registros= total_registros, @error_message= error_mensaje
			  from lavado_dinero.dbo.TBL_LOG_JOBS 
			  where  cast(fecha_alta as date)= cast(@fecha_robot as date) 
			  and nombre_job = 'RECONSTRUIR_MOVIMIENTOS'
			  order by id_log desc


		 if(@total_registros = 0 )
			raiserror('No existen movimientos', 11, 0)

		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
						
			
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_LAVADO_DINERO_OBTIENE_ESTATUS_JOB to public


