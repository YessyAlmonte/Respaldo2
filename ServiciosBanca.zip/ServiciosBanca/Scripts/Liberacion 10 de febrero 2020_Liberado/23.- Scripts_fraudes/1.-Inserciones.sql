use BANCA

--- Llaves foraneas
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_TBL_BANCA_FRAUDE_ALERTA_numero_socio' AND object_id = OBJECT_ID('TBL_BANCA_FRAUDE_ALERTA'))
	create nonclustered index IX_TBL_BANCA_FRAUDE_ALERTA_numero_socio on TBL_BANCA_FRAUDE_ALERTA (numero_socio asc)
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO_numero_socio' AND object_id = OBJECT_ID('TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO'))
	create nonclustered index IX_TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO_numero_socio on TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO (numero_socio asc)
--alter table TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES add constraint FK_TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES_CAT_BANCA_FRAUDE_MOTIVO_CIERRE foreign key () references tabla(campo)

--- Catalogos
--inserta en la tabla TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR
/*insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (670813)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (842985)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (29853)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (857139)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (857164)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (857208)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (857209)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (649408)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (108245)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (555558)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (572264)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (572651)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (655932)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (204742)
insert into TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR values (167484)*/

/*Catalogo de los tipos de las  alertas */

if not exists (select * from CAT_BANCA_FRAUDE_TIPO_ALERTA where DESCRIPCION = 'RETIROS RECURRENTES')
  INSERT INTO CAT_BANCA_FRAUDE_TIPO_ALERTA VALUES('RETIROS RECURRENTES')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPO_ALERTA where DESCRIPCION = 'ANZUELO')
  INSERT INTO CAT_BANCA_FRAUDE_TIPO_ALERTA VALUES('ANZUELO')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPO_ALERTA where DESCRIPCION = 'SIN MOVIMIENTO')
  INSERT INTO CAT_BANCA_FRAUDE_TIPO_ALERTA VALUES('SIN MOVIMIENTO')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPO_ALERTA where DESCRIPCION = 'ALERTA POR EDAD')
  INSERT INTO CAT_BANCA_FRAUDE_TIPO_ALERTA VALUES('ALERTA POR EDAD')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPO_ALERTA where DESCRIPCION = 'TIEMPO MINIMO')
  INSERT INTO CAT_BANCA_FRAUDE_TIPO_ALERTA VALUES('TIEMPO MINIMO')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPO_ALERTA where DESCRIPCION = 'CICLICA')
  INSERT INTO CAT_BANCA_FRAUDE_TIPO_ALERTA VALUES('CICLICA')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPO_ALERTA where DESCRIPCION = 'CORREO DUPLICADO')
  INSERT INTO CAT_BANCA_FRAUDE_TIPO_ALERTA VALUES('CORREO DUPLICADO')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPO_ALERTA where DESCRIPCION = 'CELULAR DUPLICADO')
  INSERT INTO CAT_BANCA_FRAUDE_TIPO_ALERTA VALUES('CELULAR DUPLICADO')
GO

/*Tipo de alerta en  recurrencia  Deposito o Retiro */
if not exists (select * from CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE where DESCRIPCION = 'N/A')
  INSERT INTO CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE VALUES('N/A')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE where DESCRIPCION = 'DIARIO')
  INSERT INTO CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE VALUES('DIARIO')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE where DESCRIPCION = 'SEMANAL')
  INSERT INTO CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE VALUES('SEMANAL')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE where DESCRIPCION = 'QUINCENAL')
  INSERT INTO CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE VALUES('QUINCENAL')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE where DESCRIPCION = 'MENSUAL')
  INSERT INTO CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE VALUES('MENSUAL')
GO


/*CAT_BANCA_FRAUDE_ESTATUS*/
if not exists (select * from CAT_BANCA_FRAUDES_ESTATUS where DESCRIPCION = 'ALERTADO')
  INSERT INTO CAT_BANCA_FRAUDES_ESTATUS VALUES('ALERTADO')
GO
if not exists (select * from CAT_BANCA_FRAUDES_ESTATUS where DESCRIPCION = 'CANALIZADO')
  INSERT INTO CAT_BANCA_FRAUDES_ESTATUS VALUES('CANALIZADO')
GO
if not exists (select * from CAT_BANCA_FRAUDES_ESTATUS where DESCRIPCION = 'CERRADO')
  INSERT INTO CAT_BANCA_FRAUDES_ESTATUS VALUES('CERRADO')
GO

/*Motivos de Cierre */
if not exists (select * from CAT_BANCA_FRAUDE_MOTIVO_CIERRE where Motivos = 'PENDIENTE POR TERCEROS')
  insert into CAT_BANCA_FRAUDE_MOTIVO_CIERRE (Motivos) values('PENDIENTE POR TERCEROS')
GO
if not exists (select * from CAT_BANCA_FRAUDE_MOTIVO_CIERRE where Motivos = 'REPORTE ATENDIDO')
  insert into CAT_BANCA_FRAUDE_MOTIVO_CIERRE (Motivos) values('REPORTE ATENDIDO')
GO
if not exists (select * from CAT_BANCA_FRAUDE_MOTIVO_CIERRE where Motivos = 'SOLUCIONADO')
  insert into CAT_BANCA_FRAUDE_MOTIVO_CIERRE (Motivos) values('SOLUCIONADO')
GO

/*Inserci�n de los datos para el  robot de env�o de correo para las  alertas canalizadas*/
if not exists(select * from HAPE..CAT_ROBOTS_SERVICIOS where NOM_EXE like '%BancaFraudeCanalizado%')
	insert into HAPE..CAT_ROBOTS_SERVICIOS(NOM_EXE,CUENTA_EMISOR,SERVIDOR) values('BancaFraudeCanalizado','ROBOTCMV@CMV.MX','CMV5003.CMV.MX')

/*CAT_BANCA_FRAUDES_ALERTAS_CANALIZADOS_CERRADOS*/
if not exists (select * from CAT_BANCA_FRAUDE_ALERTAS_CANALIZADOS_CERRADOS where estatus_canalizaci�n = 'SIN ATENCI�N')
  insert into CAT_BANCA_FRAUDE_ALERTAS_CANALIZADOS_CERRADOS values('SIN ATENCI�N')
GO
if not exists (select * from CAT_BANCA_FRAUDE_ALERTAS_CANALIZADOS_CERRADOS where estatus_canalizaci�n = 'CANALIZADA')
  insert into CAT_BANCA_FRAUDE_ALERTAS_CANALIZADOS_CERRADOS values('CANALIZADA')
GO
if not exists (select * from CAT_BANCA_FRAUDE_ALERTAS_CANALIZADOS_CERRADOS where estatus_canalizaci�n = 'CERRADA')
  insert into CAT_BANCA_FRAUDE_ALERTAS_CANALIZADOS_CERRADOS values('CERRADA')
GO

--- Inserciones para  el catalogo de tipos de bitacora 
if not exists (select * from CAT_BANCA_TIPOS_BITACORAS_FRAUDES where Descripci�n_Bitacora_Fraude = 'Bloqueo de Cuenta por Fraude')
  insert into CAT_BANCA_TIPOS_BITACORAS_FRAUDES(Descripci�n_Bitacora_Fraude) values('Bloqueo de Cuenta por Fraude')
GO
if not exists (select * from CAT_BANCA_TIPOS_BITACORAS_FRAUDES where Descripci�n_Bitacora_Fraude = 'Desbloqueo de Cuenta por Fraude')
  insert into CAT_BANCA_TIPOS_BITACORAS_FRAUDES(Descripci�n_Bitacora_Fraude) values('Desbloqueo de Cuenta por Fraude')
GO

--- Catalogo de estatus de notificacion
if not exists (select * from CAT_BANCA_FRAUDE_ESTATUS_NOTIFICACION where descripcion = 'Notificaci�n de Bloqueo al Socio')
  insert into CAT_BANCA_FRAUDE_ESTATUS_NOTIFICACION values('Notificaci�n de Bloqueo al Socio')
GO
if not exists (select * from CAT_BANCA_FRAUDE_ESTATUS_NOTIFICACION where descripcion = 'Notificaci�n de Desbloqueo al Socio')
  insert into CAT_BANCA_FRAUDE_ESTATUS_NOTIFICACION values('Notificaci�n de Desbloqueo al Socio')
GO
if not exists (select * from CAT_BANCA_FRAUDE_ESTATUS_NOTIFICACION where descripcion = 'Error al Notificar al Socio')
  insert into CAT_BANCA_FRAUDE_ESTATUS_NOTIFICACION values('Error al Notificar al Socio')
GO

--- Cat�logo tipos de la  bitacora de fraudes
if not exists (select * from CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE where Descripcion_Bitacoras_Fraudes = 'Bloqueo de cuenta|Anomal�as en movimientos')
  insert into CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE(Descripcion_Bitacoras_Fraudes) values('Bloqueo de cuenta|Anomal�as en movimientos')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE where Descripcion_Bitacoras_Fraudes = 'Desbloqueo de cuenta')
  insert into CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE(Descripcion_Bitacoras_Fraudes) values('Desbloqueo de cuenta')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE where Descripcion_Bitacoras_Fraudes = 'Bloqueo de Alerta | Retiro')
  insert into CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE(Descripcion_Bitacoras_Fraudes) values('Bloqueo de Alerta | Retiro')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE where Descripcion_Bitacoras_Fraudes = 'Bloqueo de Alerta | Tiempo M�nimo')
  insert into CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE(Descripcion_Bitacoras_Fraudes) values('Bloqueo de Alerta | Tiempo M�nimo')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE where Descripcion_Bitacoras_Fraudes = 'Bloqueo de Alerta | Anzuelo')
  insert into CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE(Descripcion_Bitacoras_Fraudes) values('Bloqueo de Alerta | Anzuelo')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE where Descripcion_Bitacoras_Fraudes = 'Bloqueo de Alerta | C�clica')
  insert into CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE(Descripcion_Bitacoras_Fraudes) values('Bloqueo de Alerta | C�clica')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE where Descripcion_Bitacoras_Fraudes = 'Registro de Alerta | Por Edad')
  insert into CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE(Descripcion_Bitacoras_Fraudes) values('Registro de Alerta | Por Edad')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE where Descripcion_Bitacoras_Fraudes = 'Registro de Alerta | Correo Duplicado')
  insert into CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE(Descripcion_Bitacoras_Fraudes) values('Registro de Alerta | Correo Duplicado')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE where Descripcion_Bitacoras_Fraudes = 'Registro de Alerta | Tel�fono Duplicado')
  insert into CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE(Descripcion_Bitacoras_Fraudes) values('Registro de Alerta | Tel�fono Duplicado')
GO
if not exists (select * from CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE where Descripcion_Bitacoras_Fraudes = 'Registro de Baja del Servicio')
  insert into CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE(Descripcion_Bitacoras_Fraudes) values('Registro de Baja del Servicio')
GO


--- Tablas

/*Tabla de Acceso para el modulo de Fraudes tbl_banca_FRAUDES_ACCESO_USUARIO*/
if not exists (select * from tbl_banca_FRAUDES_ACCESO_USUARIO where id_rol = 219)
  INSERT INTO tbl_banca_FRAUDES_ACCESO_USUARIO (Id_Rol,Activo,FechaAlta,numusuario_alta) VALUES(219,1,GETDATE(),676) --Usuario de Guillermo Li�an
GO
if not exists (select * from tbl_banca_FRAUDES_ACCESO_USUARIO where id_rol = 15)
  INSERT INTO tbl_banca_FRAUDES_ACCESO_USUARIO (Id_Rol,Activo,FechaAlta,numusuario_alta) VALUES(15,1,GETDATE(),676) --Usuario de Omar Jazael
GO
if not exists (select * from tbl_banca_FRAUDES_ACCESO_USUARIO where id_rol = 39)
  INSERT INTO tbl_banca_FRAUDES_ACCESO_USUARIO (Id_Rol,Activo,FechaAlta,numusuario_alta)	Values(39,1,GETDATE(),676) --Usuario de Isabel y Veronica
GO

/*Tabla de Adminsitraci�n de parametros para las alertas */
if not exists (select * from tbl_banca_fraude_administrador_parametros where nombre_parametro = 'Tiempo Ciclico')
  insert into tbl_banca_fraude_administrador_parametros(Valor,Tipo,Nombre_parametro) values(cast(0.00 as money),'Entero','Tiempo Ciclico')
GO
if not exists (select * from tbl_banca_fraude_administrador_parametros where nombre_parametro = 'Alerta por Edad')
  insert into tbl_banca_fraude_administrador_parametros(Valor,Tipo,Nombre_parametro) values(cast(60.00 as money),'Entero','Alerta por Edad')
GO
if not exists (select * from tbl_banca_fraude_administrador_parametros where nombre_parametro = 'Alerta de Anzuelo primer valor')
  insert into tbl_banca_fraude_administrador_parametros(Valor,Tipo,Nombre_parametro) values(cast(1.00 as money),'Entero','Alerta de Anzuelo primer valor')
GO
if not exists (select * from tbl_banca_fraude_administrador_parametros where nombre_parametro = 'Alerta de Anzuelo segundo valor')
  insert into tbl_banca_fraude_administrador_parametros(Valor,Tipo,Nombre_parametro) values(cast(100.00 as money),'Entero','Alerta de Anzuelo segundo valor')
GO
if not exists (select * from tbl_banca_fraude_administrador_parametros where nombre_parametro = 'Alerta de Anzuelo tercer valor')
  insert into tbl_banca_fraude_administrador_parametros(Valor,Tipo,Nombre_parametro) values(cast(10000.00 as money),'Entero','Alerta de Anzuelo tercer valor')  
GO
if not exists (select * from tbl_banca_fraude_administrador_parametros where nombre_parametro = 'Alerta Sin Movimientos')
  insert into tbl_banca_fraude_administrador_parametros(Valor,Tipo,Nombre_parametro) values(cast(1.00 as money),'Entero','Alerta Sin Movimientos')
GO
if not exists (select * from tbl_banca_fraude_administrador_parametros where nombre_parametro = 'Movimientos extra')
  insert into tbl_banca_fraude_administrador_parametros(Valor,Tipo,Nombre_parametro) values(cast(2.00 as money),'Entero','Movimientos extra')
GO



--- Inserci�n en tablas de BANCA
--insert into CAT_BANCA_ORIGEN_OPERACION VALUES ('Modulo de Fraudes',1)
--insert into CAT_BANCA_TIPOS_BITACORA (descripcion) values('Bloqueo autom�tico por intento de fraude o/y por fraude a la  cuenta')
--insert into CAT_BANCA_MOTIVOS_BLOQUEO(motivo_bloqueo,activo) values ('Bloqueo Autom�tico por Motivos de Fraudes',1)


if not exists(select * from TBL_BANCA_FRAUDE_NOTIFICACION_CORREO where asunto like '%Bloqueo de cuenta|Anomalias transaccionales%')
	insert into TBL_BANCA_FRAUDE_NOTIFICACION_CORREO(Id_Tipo_Bitacoras_Fraudes,asunto,cuerpo,Fecha_Alta,activo)
	values(1,'Bloqueo de cuenta|Anomalias transaccionales',
						'<html>
										<head>
											<style>

											.md-100{
												width: 100%;
												margin: auto;
											}

											.md-80{
												width: 80%;
												margin: auto;
											}

											.md-70{
												width: 70%;
												margin: auto;
											}

											.md-20{
												width: 20%;
												margin: auto;
											}


											/*------------------------------------*/
											#content-principal{
												width:800px; 
												margin: auto;
											}
											/*------------------------------------*/
											#content-header{
												border-bottom: 20px solid #89BA27;
											}

											#content-header img{
												margin: 0;
											}

											/*------------------------------------*/
											#content-nombre{
												margin-top: 10px; 
												font-size: 25px; 
												color:#89BA27;
											}
											/*------------------------------------*/
											#content-operacion{
												margin-top: 10px; 
												text-align: center;
											}

											#content-operacion p{
												color:#595959;
												font-size: 25px;
												padding: 0;
												margin: 5px;
												display: inline-table;
    											width: 100%;
											}

											#operacion{
												font-weight:900 !important;
											}

											#operacion span{
												height: 25px;
												display: inline-block; 
											}

											#operacion img{
												height: 100%;
											}

											#operacion-icono {
												margin-top: 15px;
												margin-bottom: 10px;
												text-align: center;
											}

											/*------------------------------------*/
											#content-transferencia{
												margin-top: 10px; 
												font-size: 20px; 
												color:#595959;
												text-align: center;
											}

											/*------------------------------------*/
											#content-detalle{
												margin: auto;
												margin-top: 30px;
												background-color: #e4e4e4; 	
												text-align:center;
												padding: 5px;
											}
											#content-detalle p{
												font-size: 23px;
												color:#595959;
												margin: 10px;
											}
											/*------------------------------------*/
											#content-aclaracion{
												margin-top: 20px;
												text-align: center;
												font-size: 25px; 
												color:#595959;
											}
											/*------------------------------------*/
											#footer{
												background-color:#e4e4e4;
											}

											#footer-content-tips{
												display: inline-flex;
											}

											#tips-content-img{
												text-align: center;
											}

											#tips-content-tips{
												font-size: 30px; 
												color:#595959;
											}

											#tips-content-tips ul{
												font-size: 20px;
											}

											@media only screen and (max-width: 600px) {

												p, span, li
												{
	  											  font-size: 15px !important;
	  											}

												#content-header,
												#content-nombre,
												#content-operacion,
												#content-detalle,
												#content-aclaracion,
												#footer{
													width: 90%;
													margin: auto;
												}

	  											/*------------------------------------*/
	  											#content-principal{
													width:100%; 
													margin: auto;
												}

												/*------------------------------------*/
												#content-header{
													border-bottom: 10px solid #89BA27;			
												}

												/*------------------------------------*/
												#operacion{
													font-size: 15px;	
													font-weight:900 !important;
												}

												#operacion span{
													height: 15px;
												}

												#operacion-icono img{
													width: 40px;
													height: 50px;
												}

												/*------------------------------------*/
												#content-transferencia p:last-child{
													border-bottom: 2px solid #89BA27 !important;
												}
												/*------------------------------------*/
												#footer-content-tips{
													display: block;
													padding: 10px 10px 0px 0px;
												}

												#tips-content-img,
												#tips-content-tips{
													width: 95%;
													text-align: center;
												}

												#tips-content-img img{
													width: 40px;
													height: 50px;
												}

											}
										</style>
										</head>
										<body>
											<div id="content-principal">

												<div id="content-header" class="md-100">
													<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
												</div>

												<div id="content-nombre" class="md-100">
													<p style="font-weight:900; ">@Nombre</p>
												</div>

												<div id="content-operacion" class="md-100">
													<p>La operaci�n de</p>
													<p id="operacion">
														<span>
															<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
															&nbsp;@operacion&nbsp;
															<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
														</span>
													</p>
													<p>se realiz�  exitosamente</p>
												</div>

												<!--
												<div id="operacion-icono">
													@imagen
												</div>
												-->

												<div id="content-detalle" class="md-70">
													<p>
														<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
														<span>@fecha_hora_operacion</span>
													</p>
													
													<p>
														<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
														<span>@folio</span>
													</p>
												
												</div>

												<div id="content-aclaracion" class="md-100">
													<p>
														<span style="font-weight:900; ">Si t� no realizaste esta operaci�n</span> 
														<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
														<span style="font-weight:900; ">01 800 3000 268 opci�n "5"</span>
														<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
													</p>
												</div>

												<!-- FOOTER -->
												<div id="footer" class="md-100">
													<div id="footer-content-tips" class="md-100">
														<div id="tips-content-img" class="md-20">
	        												<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        											</div>
														<div id="tips-content-tips" class="md-80">
		        											<p style="font-weight:900;">Tips de Seguridad:</p> 
															<ul>
																<li>Caja Morelia Valladolid nunca te pedir� informaci�n adicional de tus cuentas</li>
																<li>No Compartas tu contrase�a de acceso y c�mbiala peri�dicamente</li>
															</ul>
														</div>
													</div>
	        
													<div class="md-100">
														<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
															<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
														</a>
													</div>
												</div>
											</div>
										</body>
										</html>',GETDATE(),1)

/************************************************************************************************************************************************************/
	
	/*inserci�n de la notificacion v�a correo electronico  de desbloqueo del socio*/
	if not exists(select * from TBL_BANCA_FRAUDE_NOTIFICACION_CORREO where asunto like '%Desbloqueo de Cuenta|Reactivacion Cuenta%')
	insert into TBL_BANCA_FRAUDE_NOTIFICACION_CORREO(Id_Tipo_Bitacoras_Fraudes,asunto,cuerpo,Fecha_Alta,activo)
	values(2,'Desbloqueo de Cuenta|Reactivacion Cuenta','<html>
										<head>
											<style>

											.md-100{
												width: 100%;
												margin: auto;
											}

											.md-80{
												width: 80%;
												margin: auto;
											}

											.md-70{
												width: 70%;
												margin: auto;
											}

											.md-20{
												width: 20%;
												margin: auto;
											}


											/*------------------------------------*/
											#content-principal{
												width:800px; 
												margin: auto;
											}
											/*------------------------------------*/
											#content-header{
												border-bottom: 20px solid #89BA27;
											}

											#content-header img{
												margin: 0;
											}

											/*------------------------------------*/
											#content-nombre{
												margin-top: 10px; 
												font-size: 25px; 
												color:#89BA27;
											}
											/*------------------------------------*/
											#content-operacion{
												margin-top: 10px; 
												text-align: center;
											}

											#content-operacion p{
												color:#595959;
												font-size: 25px;
												padding: 0;
												margin: 5px;
												display: inline-table;
    											width: 100%;
											}

											#operacion{
												font-weight:900 !important;
											}

											#operacion span{
												height: 25px;
												display: inline-block; 
											}

											#operacion img{
												height: 100%;
											}

											#operacion-icono {
												margin-top: 15px;
												margin-bottom: 10px;
												text-align: center;
											}

											/*------------------------------------*/
											#content-transferencia{
												margin-top: 10px; 
												font-size: 20px; 
												color:#595959;
												text-align: center;
											}

											/*------------------------------------*/
											#content-detalle{
												margin: auto;
												margin-top: 30px;
												background-color: #e4e4e4; 	
												text-align:center;
												padding: 5px;
											}
											#content-detalle p{
												font-size: 23px;
												color:#595959;
												margin: 10px;
											}
											/*------------------------------------*/
											#content-aclaracion{
												margin-top: 20px;
												text-align: center;
												font-size: 25px; 
												color:#595959;
											}
											/*------------------------------------*/
											#footer{
												background-color:#e4e4e4;
											}

											#footer-content-tips{
												display: inline-flex;
											}

											#tips-content-img{
												text-align: center;
											}

											#tips-content-tips{
												font-size: 30px; 
												color:#595959;
											}

											#tips-content-tips ul{
												font-size: 20px;
											}

											@media only screen and (max-width: 600px) {

												p, span, li
												{
	  											  font-size: 15px !important;
	  											}

												#content-header,
												#content-nombre,
												#content-operacion,
												#content-detalle,
												#content-aclaracion,
												#footer{
													width: 90%;
													margin: auto;
												}

	  											/*------------------------------------*/
	  											#content-principal{
													width:100%; 
													margin: auto;
												}

												/*------------------------------------*/
												#content-header{
													border-bottom: 10px solid #89BA27;			
												}

												/*------------------------------------*/
												#operacion{
													font-size: 15px;	
													font-weight:900 !important;
												}

												#operacion span{
													height: 15px;
												}

												#operacion-icono img{
													width: 40px;
													height: 50px;
												}

												/*------------------------------------*/
												#content-transferencia p:last-child{
													border-bottom: 2px solid #89BA27 !important;
												}
												/*------------------------------------*/
												#footer-content-tips{
													display: block;
													padding: 10px 10px 0px 0px;
												}

												#tips-content-img,
												#tips-content-tips{
													width: 95%;
													text-align: center;
												}

												#tips-content-img img{
													width: 40px;
													height: 50px;
												}
											}
										</style>
										</head>
										<body>
											<div id="content-principal">

												<div id="content-header" class="md-100">
													<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
												</div>

												<div id="content-nombre" class="md-100">
													<p style="font-weight:900; ">@Nombre</p>
												</div>

												<div id="content-operacion" class="md-100">
													<p>La operaci�n de</p>
													<p id="operacion">
														<span>
															<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
															&nbsp;@operacion&nbsp;
															<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
														</span>
													</p>
													<p>se realiz�  exitosamente</p>
												</div>

												<!--
												<div id="operacion-icono">
													@imagen
												</div>
												-->

												<div id="content-detalle" class="md-70">
													<p>
														<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
														<span>@fecha_hora_operacion</span>
													</p>
													
													<p>
														<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
														<span>@folio</span>
													</p>
												
												</div>

												<div id="content-aclaracion" class="md-100">
													<p>
														<span style="font-weight:900; ">Si t� no realizaste esta operaci�n</span> 
														<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
														<span style="font-weight:900; ">01 800 3000 268 opci�n "5"</span>
														<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
													</p>
												</div>

												<!-- FOOTER -->
												<div id="footer" class="md-100">
													<div id="footer-content-tips" class="md-100">
														<div id="tips-content-img" class="md-20">
	        												<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        											</div>
														<div id="tips-content-tips" class="md-80">
		        											<p style="font-weight:900;">Tips de Seguridad:</p> 
															<ul>
																<li>Caja Morelia Valladolid nunca te pedir� informaci�n adicional de tus cuentas</li>
																<li>No Compartas tu contrase�a de acceso y c�mbiala peri�dicamente</li>
															</ul>
														</div>
													</div>
	        
													<div class="md-100">
														<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
															<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
														</a>
													</div>
												</div>
											</div>
										</body>
										</html>',GETDATE(),1)

