USE BANCA
GO
-- se crea procedimiento SP_BANCA_FRAUDE_ACTUALIZAICION_PERFIL_TRANSACCIONAL
IF EXISTS (SELECT * FROM sysobjects WHERE NAME LIKE 'SP_BANCA_FRAUDE_ACTUALIZACION_PERFIL_TRANSACCIONAL' AND xtype = 'p' AND db_name() = 'BANCA')
    DROP PROC SP_BANCA_FRAUDE_ACTUALIZACION_PERFIL_TRANSACCIONAL
GO
/*
Autor           Sabdi Abraham Pantoja Orozco
UsuarioRed      paos845568
Fecha           04/Diciembre/2019
Objetivo        Actualizar perfil transaccional de un socio
Proyecto        Banca/Fraudes
Ticket          ticket
*/
CREATE PROC
    SP_BANCA_FRAUDE_ACTUALIZACION_PERFIL_TRANSACCIONAL
    @numero_socio int,
    @folio_alerta int,
    --@numero_operacion int,
    @numero_usuario int
AS
    BEGIN -- procedimiento  
        BEGIN TRY -- try principal
            BEGIN -- inicio
                DECLARE 
                    @status INT = 1,
                    @error_message VARCHAR(255) = '',
                    @error_line VARCHAR(255) = '',
                    @error_severity VARCHAR(255) = '',
                    @error_procedure VARCHAR(255) = '',
					@tipo_recurrente int,
					@monto_max money,
					@numero_movs int,
					@monto money
                        
                DECLARE 
                    @tran_name VARCHAR(32) = 'ACTUALIZACION_PERFIL_TRANSACCIONAL',
                    @tran_count INT = @@trancount,
                    @tran_scope BIT = 0,
                    @Fecha_Actualizacion DATETIME = GETDATE()
            END -- inicio
            
            BEGIN -- transacción
                BEGIN -- inicio
                    IF @tran_count = 0
                        BEGIN tran @tran_name
                    ELSE
                        SAVE tran @tran_name
                
                    SELECT @tran_scope = 1
                END -- inicio
                
                BEGIN -- componente de la transacción

					set @tipo_recurrente = (select tipo_recurrente from TBL_BANCA_FRAUDE_ALERTA where folio_alerta = @folio_alerta and numero_socio = @numero_socio)
					if(@tipo_recurrente = 1)
						begin
							set @numero_movs = (select Numero_Operaciones from TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL where Numero_Socio = @numero_socio) + (select valor from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where id_parametro = 7 )
							set @monto_max = (select Monto_Acumulado from TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL where Numero_Socio = @numero_socio)
						end
					else if(@tipo_recurrente = 2)
						begin
							set @numero_movs = (select Numero_Operaciones from TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL where Numero_Socio = @numero_socio)
							set @monto_max = (SELECT SUM(CAST(monto AS money)) FROM (
																SELECT externas.monto FROM TBL_BANCA_FRAUDE_MOVIMIENTOS mov
																INNER JOIN  TBL_BANCA_TRANSFERENCIAS_EXTERNAS  externas ON externas.id_banca_folio = mov.folio_movimiento
																WHERE mov.id_ALERTA = @folio_alerta
																UNION ALL
																SELECT internas.monto FROM TBL_BANCA_FRAUDE_MOVIMIENTOS mov
																INNER JOIN  TBL_BANCA_TRANSFERENCIAS_INTERNAS  internas ON internas.id_banca_folio = mov.folio_movimiento
																WHERE mov.id_ALERTA = @folio_alerta
															) AS monto)
						end
					else
						begin
							set @numero_movs = (select Numero_Operaciones from TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL where Numero_Socio = @numero_socio) + (select valor from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where id_parametro = 7 )
							set @monto_max = (SELECT SUM(CAST(monto AS DECIMAL)) FROM (
																SELECT externas.monto FROM TBL_BANCA_FRAUDE_MOVIMIENTOS mov
																INNER JOIN  TBL_BANCA_TRANSFERENCIAS_EXTERNAS  externas ON externas.id_banca_folio = mov.folio_movimiento
																WHERE mov.id_ALERTA = @folio_alerta
																UNION ALL
																SELECT internas.monto FROM TBL_BANCA_FRAUDE_MOVIMIENTOS mov
																INNER JOIN  TBL_BANCA_TRANSFERENCIAS_INTERNAS  internas ON internas.id_banca_folio = mov.folio_movimiento
																WHERE mov.id_ALERTA = @folio_alerta
															) AS monto)
						end
                
                    UPDATE banca..TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL 
                    SET 
                        Monto_Acumulado = @monto_max, 
                        Numero_Operaciones = @numero_movs, 
                        Fecha_Actulizacion = @Fecha_Actualizacion
                    FROM TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL 
                    WHERE 
                        Numero_Socio = @numero_socio
                
                END -- componente de la transacción
                
                BEGIN -- commit             
                    IF @tran_count = 0
                        BEGIN -- si la transacción se inició dentro de este ámbito
                            COMMIT TRAN @tran_name
                            SELECT @tran_scope = 0
                        END -- si la transacción se inició dentro de este ámbito
                END -- commit
            END
        END TRY -- try principal
    
        BEGIN catch -- catch principal      
            -- captura del error
            SELECT  @status = -error_state(),
                    @error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
                    @error_line = error_line(),
                    @error_message = error_message(),
                    @error_severity =
                        CASE error_severity()
                            WHEN 11 THEN 'Error en validación'
                            WHEN 12 THEN 'Error en consulta'
                            WHEN 13 THEN 'Error en actualización'
                            ELSE 'Error general'
                        END
            -- revertir transacción si es necesario
            IF @tran_scope = 1
                ROLLBACK TRAN @tran_name
        END CATCH -- catch principal
        
        BEGIN -- reporte de status
            SELECT  @status STATUS,
                    @error_procedure error_procedure,
                    @error_line error_line,
                    @error_severity error_severity,
                    @error_message error_message
        END -- reporte de status
    END -- procedimiento
GO
GRANT EXEC ON SP_BANCA_FRAUDE_ACTUALIZACION_PERFIL_TRANSACCIONAL TO PUBLIC

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_ALERTA_ANZUELO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_ALERTA_ANZUELO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_ALERTA_ANZUELO
go

/*

Autor			Claudia Alejandra Arredondo Rodríguez
UsuarioRed	AERC864420
Fecha			20191115
Objetivo	    Generar alertas anzuelo
Proyecto		Banca Móvil, módulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_ALERTA_ANZUELO

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				declare	@tran_name varchar(32) = 'ALERTA_ANZUELO',
						@tran_count int = @@trancount,
						@tran_scope bit = 0
						
				declare
					@valor1 int,
					@valor2 int,
					@valor3 int,
					@tipo_origen_operacion int,
					@id_tipo_bitacora int,
					@motivobloqueo varchar(255),
					@id_motivo_bloqueo int,
					@id_tipo_alerta_bloqueo	int,
					@descripcion_bloqueo varchar(255),
					@idtipo_bitacora_fraude int,
					@Descripcion_Bitacoras_Fraudes varchar(900),
					@idtipo_bitacora_fraude_bloqueo int ,
					@Descripcion_Bitacoras_Fraudes_bloqueo varchar(900),
					@id_tipo_alerta int,
					@Fecha_inicio datetime

			--	select @fecha_analisis  = cast(coalesce(@fecha_analisis, getdate())as date)
				--select @FechaInicio  = cast( getdate()as date)
			--	select @FechaFin = cast( getdate() as date)

				create table #bloqueo_socio(
					Numero_socio int
				)

				create table #retiroAnzuelo (
					id_transferencia int,
					numero_socio int,
					MontodelMovimiento money,
					fecha_transferencia datetime,
					tipo_transferencia varchar(1)
				)
				
				create table #retiroMayor(
					id_transferencia int,
					numero_socio int,
					MontodelMovimiento money,
					fecha_transferencia datetime,
					tipo_transferencia varchar(1)
				)

				create table #movs(
					id_banca_folio int,
					numero_socio int,
					fecha_transferencia_realizada datetime,
				)
			end -- inicio

			begin -- preparación
			
				select  @valor1 = Valor 
				from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS 
				where Id_parametro = 3 
				
				select @valor2= Valor 
				from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS
				where Id_parametro = 4

				select @valor3= Valor 
				from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS 
				where Id_parametro = 5

				set  @id_motivo_bloqueo = 13 --- Bloqueo automático por motivos de fraudes
				set @tipo_origen_operacion = 7 --- Módulo de Fraudes
				set @id_tipo_bitacora = 87 --- Bloqueo automático por intento o por  fraude a la  cuenta
				set @id_tipo_alerta_bloqueo = 2 --- Alerta tipo Anzuelo  2
 
				select @idtipo_bitacora_fraude_bloqueo = id_Tipo_Bitacoras_fraudes,
						  @Descripcion_Bitacoras_Fraudes_bloqueo =Descripcion_Bitacoras_Fraudes
				from CAT_banca_fraude_tipos_bitacora_fraude
				where id_Tipo_Bitacoras_fraudes = 5 --- Bloqueo por alerta anzuelo 

			end -- preparación
			
			begin -- transacción

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio

				begin --componentes de la transacción

					--- Insertar transferencias internas, externas y pago de servicios cuyo monto se encuentra entre los 2 primeros parametros de la alerta
					insert into #retiroAnzuelo --TBL_BANCAFRAUDE_VERIFICACIONCENTAVOACIEN
					select id_transferencia, trans.numero_socio, monto, fecha_transferencia_realizada, 'i'
					from tbl_banca_transferencias_internas trans
						inner join TBL_BANCA_SOCIOS socio on trans.numero_socio = socio.numero_socio and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1 and socio.id_motivo_bloqueo = 1
					where id_estatus_transferencia = 2
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and CAST(monto AS MONEY) between @valor1 and @valor2
						and CAST(fecha_transferencia_realizada as date) = CAST(GETDATE() as date)						
					union
					select id_transferencia, trans.numero_socio, monto, fecha_transferencia_realizada, 'e'
					from tbl_banca_transferencias_externas trans
						inner join TBL_BANCA_SOCIOS socio on trans.numero_socio = socio.numero_socio and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1 and socio.id_motivo_bloqueo = 1
					where id_estatus_transferencia = 2
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and CAST(monto AS MONEY) between @valor1 and @valor2
						and CAST(fecha_transferencia_realizada as date) = CAST(GETDATE() as date)
					
						
					--- Insertar transferencias internas, externas y pago de servicios cuyo monto se encuentra entre los 2 primeros parametros de la alerta
					insert into #retiroMayor --tbl_banca_fraude_cien_diezmil
					select id_transferencia, trans.numero_socio, monto, fecha_transferencia_realizada, 'i'
					from tbl_banca_transferencias_internas trans
						inner join TBL_BANCA_SOCIOS socio on trans.numero_socio = socio.numero_socio and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1  and socio.id_motivo_bloqueo = 1
					where id_estatus_transferencia = 2
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and CAST(monto AS MONEY) > @valor3
						and CAST(fecha_transferencia_realizada as date) = CAST(GETDATE() as date)
					union
					select id_transferencia, trans.numero_socio, monto, fecha_transferencia_realizada, 'e'
					from tbl_banca_transferencias_externas trans
						inner join TBL_BANCA_SOCIOS socio on trans.numero_socio = socio.numero_socio and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1 and socio.id_motivo_bloqueo = 1
					where id_estatus_transferencia = 2
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and CAST(monto AS MONEY) > @valor3
						and CAST(fecha_transferencia_realizada as date) = CAST(GETDATE() as date)

					--- Obtener los socios que caen en la alerta y se bloquearan
					insert into #bloqueo_socio --socios a alertar y bloquear
					select distinct  a.numero_socio
					from #retiroMayor a
					inner join #retiroAnzuelo b on a.numero_socio = b.numero_socio
					where a.numero_socio not in  (select numero_socio from TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR)

					--- Obtener los movimientos que están generando la alerta
					insert into #movs
					select distinct 
						trans.id_banca_folio,
						socio.NUMERO_SOCIO,
						trans.fecha_transferencia_realizada
					from TBL_BANCA_TRANSFERENCIAS_INTERNAS trans
						inner join TBL_BANCA_SOCIOS socio on trans.numero_socio = socio.numero_socio and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1
						inner join #bloqueo_socio b on b.Numero_socio = socio.numero_socio
					where
						CAST(fecha_transferencia_realizada as date) = CAST(GETDATE() as date)
						--and (CAST(trans.monto AS MONEY) between @valor1 and @valor2 or  CAST(trans.monto AS MONEY) > @valor3)
						and CAST(substring(trans.clave_corresponsalias_origen,10,7) as int) <> CAST(substring(trans.clave_corresponsalias_destino,10,7) as int)
						--and (trans.id_transferencia in (select id_transferencia from #retiroAnzuelo) or id_transferencia in (select id_transferencia from #retiroMayor))
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and trans.id_estatus_transferencia=2 
						and trans.programada = 0						
					
					union 

					select distinct 
								trans.id_banca_folio, 
								socio.numero_socio,
								trans.fecha_transferencia_realizada
					from TBL_BANCA_TRANSFERENCIAS_EXTERNAS trans
						inner join TBL_BANCA_SOCIOS socio on trans.numero_socio = socio.numero_socio and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1
						inner join #bloqueo_socio bs on bs.numero_socio = socio.numero_socio
					where 
						CAST( trans.fecha_transferencia_realizada as date) = CAST(GETDATE() as date)
					--	and (CAST(trans.monto AS MONEY) between @valor1 and @valor2 or  CAST(trans.monto AS MONEY) > @valor3)
						--and (trans.id_transferencia in (select id_transferencia from #retiroAnzuelo) or id_transferencia in (select id_transferencia from #retiroMayor))
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and id_estatus_transferencia = 2
						and trans.programado = 0
											
					--- Crear alerta
					insert into TBL_BANCA_FRAUDE_ALERTA(NUMERO_SOCIO, Fecha_Alerta, ID_TIPO_ALERTA, ID_ALERTA_RECURRENTE, ID_ESTATUS, id_notificacion)
					select distinct Numero_socio, GETDATE(), @id_tipo_alerta_bloqueo, 1, 1, 0
					from #bloqueo_socio

					--- Insertar en TBL_BANCA_FRAUDE_MOVIMIENTOS los movimientos que generaron la alerta
					insert into TBL_BANCA_FRAUDE_MOVIMIENTOS(Folio_movimiento, Numero, Fecha_movimiento, Id_tipo_alerta, Id_alerta)
					select *, @id_tipo_alerta_bloqueo, (select MAX(folio_alerta) from TBL_BANCA_FRAUDE_ALERTA)
					from #movs
					
				   --Insertar en la tabla de Bitacoras 
					insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus)
					select socio.NUMERO_SOCIO, @idtipo_bitacora_fraude_bloqueo as Id_Tipo_Bitacoras_Fraudes, GETDATE(), @Descripcion_Bitacoras_Fraudes_bloqueo as Evento, 1
					from #bloqueo_socio socio
					
					--- Bloqueo de la cuenta CMV Finanzas del socio 
					update banca..TBL_BANCA_SOCIOS 
						set 
							id_motivo_bloqueo=@id_motivo_bloqueo,
							fecha_motivo_bloqueo = getdate(),
							viene_de_bloqueo = 1,
							descripcion_bloqueo=@motivobloqueo
						from 
							banca..TBL_BANCA_SOCIOS bancaSocios, #bloqueo_socio bancaSociosTemp
						where 
							bancaSocios.numero_socio = bancaSociosTemp.numero_socio

					--- Actualización o inserción en la tabla TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO para notificar al socio
					if((select COUNT(id) from TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO a, #bloqueo_socio b where a.Numero_Socio = b.Numero_socio ) > 0)
						begin
							update TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO 
								set Notificacion_Email = 0, Notificacion_sms = 0
								where Numero_Socio in  (select numero_socio from #bloqueo_socio)
						end
					else
						insert into  TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO (Numero_Socio,Nombre_Socio,Tel_Celular,Email,Id_Tipo_Bitacoras_Fraudes,id_tipo_notificacion)
						select distinct
							bs.Numero_socio,
							P.Nombre_s+' '+P.Apellido_Paterno+' '+Apellido_Materno as Nombre_Socio,
							P.Tel_celular,
							P.Mail,
							1,
							contrato.id_tipo_notificacion
						from Tbl_banca_fraude_alerta alerta
							inner join hape..PERSONA P on P.numero=alerta.numero_Socio  and p.id_tipo_persona = 1
							inner join BANCA..TBL_BANCA_SOCIOS bsocios on bsocios.numero_socio = alerta.NUMERO_SOCIO
							inner join HAPE..TBL_CONTRATOS_HABERES contrato on alerta.numero_socio = contrato.numero
							inner join #bloqueo_socio bs on bs.Numero_socio = P.Numero
						where bsocios.banca_activa = 1
							and bsocios.id_motivo_bloqueo = 13
							and contrato.id_tipo_contrato = 3 			
					
					drop table #bloqueo_socio, #retiroAnzuelo, #retiroMayor, #movs

				end -- componentes de la transacción
				
			
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacción se inició dentro de este ámbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacción se inició dentro de este ámbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
						
			-- revertir transacción si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDE_ALERTA_ANZUELO to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_ALERTA_CICLICA
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_ALERTA_CICLICA' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_ALERTA_CICLICA
go

/*

Autor			Blanca Estela González Soto
UsuarioRed		GOSB811264
Fecha			20191203
Objetivo		Detección de alerta cíclica: En donde si hay movimientos
Proyecto		BANCA FRAUDES
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_ALERTA_CICLICA
	
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',

						@fecha date=getdate()
			
			end -- inicio
			
			begin -- ámbito de la actualización
			
				--Seleccionamos todos aquellos socios que tienen 3 o más movimientos al dia
				select * 
				   into #sociosConMasMov
				from 
					(select 
						numero_socio 
						from banca..TBL_BANCA_TRANSFERENCIAS_INTERNAS 
						where 
						CAST(substring(clave_corresponsalias_origen,10,7) as int) <> CAST(substring(clave_corresponsalias_destino,10,7) as int) and 
						CAST(fecha_transferencia_realizada as date)=cast(@fecha as date) 
						and id_estatus_transferencia=2
						group by numero_socio
						having count(numero_socio) >=3
				union
					 select 
						numero_socio 
						from banca..TBL_BANCA_TRANSFERENCIAS_EXTERNAS
						where 
						cast(fecha_transferencia_realizada as date)=cast(@fecha as date) 
						and id_estatus_transferencia=2
						group by numero_socio
						having count(numero_socio) >=3
				) socios

				--select * from #sociosConMasMov

				--Guardamos en tabla temporal para realizar la comparación entre los registros.
				select 
					ROW_NUMBER() OVER(order by transferencia.numero_socio,transferencia.fecha_transferencia_realizada asc) id,
					transferencia.id_transferencia,
					transferencia.Folio,
					transferencia.numero_socio,
					transferencia.fecha_transferencia_realizada,
					transferencia.tipotranferencia
				into #transferencia1
				from (
					  select
						 trans1.id_transferencia,
						 trans1.id_banca_folio Folio,
						 socios.numero_socio,
						 trans1.fecha_transferencia_realizada,
						 'I' tipotranferencia
						 from #sociosConMasMov socios 
						 inner join banca..TBL_BANCA_TRANSFERENCIAS_INTERNAS trans1 on trans1.numero_socio=socios.numero_socio
						 where 
						 CAST(substring(trans1.clave_corresponsalias_origen,10,7) as int) <> CAST(substring(trans1.clave_corresponsalias_destino,10,7) as int) and 
						 CAST(trans1.fecha_transferencia_realizada as date)=cast(@fecha as date) 
						 and trans1.id_estatus_transferencia=2
					  union
					  select 
						 trans2.id_transferencia,
						 trans2.id_banca_folio Folio,
						 socios.numero_socio,
						 trans2.fecha_transferencia_realizada,
						 'E' tipotranferencia
						 from #sociosConMasMov socios 
						 inner join banca..TBL_BANCA_TRANSFERENCIAS_EXTERNAS trans2 on trans2.numero_socio=socios.numero_socio 
						 where 	
						 cast(trans2.fecha_transferencia_realizada as date)=cast(@fecha as date) 
						 and trans2.id_estatus_transferencia=2
				) transferencia
				where transferencia.Folio not in(select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS group by Folio_movimiento)
				order by transferencia.numero_socio, transferencia.fecha_transferencia_realizada asc		

				--select * from #transferencia1
	
			-----Comparamos los registros para obtener la diferencia del tiempo
					select
					trans1.id,
					trans1.Folio,
					trans1.id_transferencia id_transferencia_origen,
					trans1.numero_socio,
					trans1.fecha_transferencia_realizada,
					trans1.tipotranferencia,
					trans2.id id_2,
					trans2.Folio folio_2,
					trans2.id_transferencia id_transferencia_origen_2,
					trans2.numero_socio numero_socio2,
					trans2.fecha_transferencia_realizada fecha_transferencia_realizada2,
					trans2.tipotranferencia tipotranferencia_2,
					datediff (MINUTE, trans1.fecha_transferencia_realizada, trans2.fecha_transferencia_realizada) tiempo 
					into #tiempos
					from #transferencia1 trans1 
					inner join #transferencia1 trans2 on trans2.numero_socio=trans1.numero_socio and trans1.id=trans2.id-1
					inner join BANCA.dbo.TBL_BANCA_SOCIOS socios on socios.numero_socio=trans1.numero_socio and socios.banca_activa=1 and socios.id_motivo_bloqueo=1
					--where 
					--trans1.Folio not in(select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
		
					--select * from #tiempos

			---------Socios que fueron identificados por Alerta Cíclica
					 select 
						 count(*) numvecesRepetidos,
						 numero_socio,
						 tiempo
					 into #SociosAlertados
					 from #tiempos	 
					 where	 
					 ---------------------------Validacion temporal-----------------------------------
					 numero_socio not in(select numero_socio from banca..TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR)
					 -----------------------------------------------------------------------------------
					 group by numero_socio,tiempo
					 having count(tiempo) >=2
					 order by numero_socio asc

			---------Se registran en la tabla de TBL_BANCA_FRAUDE_ALERTA a los socios que no cumplieron con el perfil transaccional
				   insert into banca.dbo.TBL_BANCA_FRAUDE_ALERTA(Fecha_Alerta,NUMERO_SOCIO,ID_TIPO_ALERTA,ID_ALERTA_RECURRENTE,ID_ESTATUS)
				   select distinct
					   GETDATE() Fecha,
					   numero_socio,
					   6 Tipo_alerta,
					   1 Alerta_recurrente,
					   1 Idstatus
					 from #SociosAlertados 

			--------Obtenemos los movimientos  de los socios alertados en la tabla #movimientosfraudes

					select distinct * 
					into #movimientosfraudes from(
						select id,id_transferencia_origen,Folio,numero_socio,fecha_transferencia_realizada,tipotranferencia 
						from #tiempos where tiempo in(
								select tiempo from #SociosAlertados
						)
						union
						select id_2,id_transferencia_origen_2,folio_2,numero_socio2,fecha_transferencia_realizada2,tipotranferencia_2 
						from #tiempos where tiempo in(
							select tiempo from #SociosAlertados
						)
					)movimientos

			--------Se actualiza el tipo de bloqueo en TBL_BANCA_SOCIO
					update TBL_BANCA_SOCIOS set id_motivo_bloqueo = 13
					where numero_socio in (select numero_socio from #SociosAlertados) and id_motivo_bloqueo = 1

			--------Se insertan los movimientos fraudulentos correspondientes a la en la tabla TBL_BANCA_FRAUDE_MOVIMIENTOS
					Insert into TBL_BANCA_FRAUDE_MOVIMIENTOS(folio_movimiento,Id_alerta,Numero,Fecha_movimiento,id_tipo_alerta)
					select distinct
						movimientos.Folio,
						alerta.Folio_alerta,
						alerta.NUMERO_SOCIO,
						movimientos.fecha_transferencia_realizada,
						alerta.ID_TIPO_ALERTA
					from #movimientosfraudes movimientos
					inner join banca..TBL_BANCA_FRAUDE_ALERTA alerta on alerta.NUMERO_SOCIO=movimientos.numero_socio
					where alerta.ID_TIPO_ALERTA=6 and cast(alerta.Fecha_Alerta as date)=cast(@fecha as date) 
					and alerta.ID_ESTATUS = 1 


				 -- select * from #SociosAlertados
			--------Se inserta en la bitácora de operaciones
					insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus)						
					select distinct
						socios.numero_socio,
						6 Id_Tipo_Bitacoras_Fraudes,
						GETDATE() Fecha,
						(select Descripcion_Bitacoras_Fraudes from banca.dbo.CAT_banca_fraude_tipos_bitacora_fraude where id_Tipo_Bitacoras_fraudes = 6)Evento,
						alerta.ID_ESTATUS
					from #SociosAlertados socios 
					inner join banca.dbo.TBL_BANCA_FRAUDE_ALERTA alerta on alerta.NUMERO_SOCIO=socios.numero_socio 
					where alerta.ID_TIPO_ALERTA = 6 and alerta.ID_ESTATUS = 1 

			--------Obtenemos el idBitacora de la bitacora de operaciones 
					select 
					max(bitacora.Id_Bitacora_Fraude)IdBitacoraFraude,
					socios.numero_socio 
					into #idBitacoraFraude
					from #SociosAlertados socios
					inner join banca..TBL_BANCA_FRAUDE_BITACORA_OPERACIONES bitacora on bitacora.Numero_Socio=socios.numero_socio 
					and bitacora.Id_Tipo_Bitacoras_Fraudes=6 and bitacora.Estatus=1
					group by socios.numero_socio
	 
			--    select * from #idBitacoraFraude
			--------insertar notificaciones TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO
				   insert into TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO (Numero_Socio,Nombre_Socio,Tel_Celular,Email,id_tipo_notificacion,Id_Tipo_Bitacoras_Fraudes,Id_bitacora_fraude) 
				   select distinct
						alerta.Numero_socio,
						pers.Nombre as Nombre_Socio,
						pers.Tel_celular,
						pers.Mail,
						contrato.id_tipo_notificacion,
						6 IdTipoBitacora,--Id_Tipo_Bitacoras_Fraudes Bloqueo alerta recurrente
						bitacora.IdBitacoraFraude
					from #SociosAlertados socios
						inner join banca.dbo.TBL_BANCA_FRAUDE_ALERTA alerta on alerta.NUMERO_SOCIO=socios.numero_socio
						inner join (select Numero,(Nombre_s+' '+Apellido_Paterno+' '+Apellido_Materno)Nombre,Tel_celular,Mail from HAPE.dbo.PERSONA where Id_Tipo_Persona=1) pers on pers.numero=alerta.numero_Socio  
						inner join #idBitacoraFraude bitacora on bitacora.numero_socio=alerta.NUMERO_SOCIO
						inner join HAPE.dbo.TBL_CONTRATOS_HABERES contrato on alerta.numero_socio = contrato.numero and contrato.id_tipo_contrato = 3 and contrato.id_tipo_persona = 1 and contrato.id_tipo_notificacion is not null
					where alerta.id_tipo_alerta=6 and alerta.ID_ESTATUS = 1 
					and socios.numero_socio not in(select Numero_Socio from banca..TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO)

			--------Actualizamos el id_tipo_de_bitacora_fraudes y La notificacion_sms y la notificacion_Email
					update notificacion set 
						notificacion.Id_Tipo_Bitacoras_Fraudes=6,
						notificacion.Id_bitacora_fraude=bitacora.IdBitacoraFraude,
						notificacion.Notificacion_sms=0,
						notificacion.Notificacion_Email=0 
					from banca..TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO notificacion 
					inner join #SociosAlertados socios on socios.numero_socio=notificacion.Numero_Socio
					inner join #idBitacoraFraude bitacora on bitacora.numero_socio=socios.numero_socio

			--	--Actualizamos la fecha de en que se ejecutó el sp 
			--	update CAT_BANCA_FRAUDES_LOG_JOBS set fecha_ultima_ejecucion=GETDATE() where id=2

				Drop table #sociosConMasMov
				Drop table #transferencia1
				Drop table #tiempos
				Drop table #SociosAlertados
				Drop table #movimientosfraudes
				Drop table #idBitacoraFraude
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_ALERTA_CICLICA to public

use banca
go

-- se crea procedimiento SP_BANCA_FRAUDE_ALERTA_EDAD
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_ALERTA_EDAD' and xtype = 'p' and db_name() = 'banca')
	drop proc SP_BANCA_FRAUDE_ALERTA_EDAD
go

/*

Autor			Claudia Alejandra Arredondo Rodríguez
UsuarioRed		AERC864420
Fecha			20191201
Objetivo		Generar alertas al momento de que se crea una cuenta de CMV Finanzas por una persona mayor de N edad
Proyecto		Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_ALERTA_EDAD
	@Numero_socio int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@edadLimite int,
						@edadSocio int,
						@id_motivo_bloqueo int,
						@tipo_origen_operacion int,
						@id_tipo_bitacora int,
						@id_tipo_alerta_bloqueo int,
						@idtipo_bitacora_fraude_bloqueo int,
						@Descripcion_Bitacoras_Fraudes_bloqueo varchar(255)
												
				-- valores por defecto
				set @edadLimite = (select Valor from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where Id_parametro = 2)
				set @edadSocio =  datediff(YEAR, (select fecha_de_nacimiento from hape..persona where Numero = @Numero_socio and Id_tipo_persona = 1), GETDATE())

				set  @id_motivo_bloqueo = 13 --- Bloqueo automático por motivos de fraudes
				set @tipo_origen_operacion = 7 --- Módulo de Fraudes
				set @id_tipo_bitacora = 87 --- Bloqueo automático por intento o por  fraude a la  cuenta
				set @id_tipo_alerta_bloqueo = 4 --- Alerta tipo Edad 4

				select @idtipo_bitacora_fraude_bloqueo = id_Tipo_Bitacoras_fraudes,
						  @Descripcion_Bitacoras_Fraudes_bloqueo =Descripcion_Bitacoras_Fraudes
				from CAT_banca_fraude_tipos_bitacora_fraude
				where id_Tipo_Bitacoras_fraudes = 7 --- Bloqueo por alerta edad 

			end -- inicio
					
			begin -- ámbito de la actualización
			
				if(@edadSocio >= @edadLimite)
					begin
						--- Crear alerta
						insert into TBL_BANCA_FRAUDE_ALERTA(NUMERO_SOCIO, Fecha_Alerta, ID_TIPO_ALERTA, ID_ALERTA_RECURRENTE, ID_ESTATUS)
						values (@Numero_socio, GETDATE(), @id_tipo_alerta_bloqueo, 1, 1)

					   --Insertar en la tabla de Bitacoras 
						insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus)
						values (@Numero_socio, @idtipo_bitacora_fraude_bloqueo, GETDATE(), @Descripcion_Bitacoras_Fraudes_bloqueo, 1)
					end
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_ALERTA_EDAD to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_ALERTA_NOTIFICACIONES
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_ALERTA_NOTIFICACIONES' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_ALERTA_NOTIFICACIONES
go

/*

Autor			Luis Arturo Gálvez Macias
UsuarioRed		GAML841262
Fecha			2019/06/25
Objetivo		Mostrar las  nuevas alertas generadas que requieren ser atentidas 
Proyecto		Banca Electrónica División de Fruades Electrónicos
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_ALERTA_NOTIFICACIONES
	@Id_tipo_alerta int,
	@id_alerta_recurrente int = 0

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				declare	@tran_name varchar(32) = 'Alerta_Notificacion',
						@tran_count int = @@trancount,
						@tran_scope bit = 0
					
							
			end -- inicio
						
			begin -- transacción

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio
				
				begin -- componente de la transacción
				
					update TBL_BANCA_FRAUDE_ALERTA 
						set Id_Notificacion = 1
						where ID_TIPO_ALERTA =@Id_tipo_alerta
						and ID_ALERTA_RECURRENTE  =@id_alerta_recurrente 
				
				end -- componente de la transacción
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacción se inició dentro de este ámbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacción se inició dentro de este ámbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
						
			-- revertir transacción si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDE_ALERTA_NOTIFICACIONES to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_ALERTA_RECURRENTE
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_ALERTA_RECURRENTE' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_ALERTA_RECURRENTE
go

/*

Autor			Blanca Estela González Soto
UsuarioRed		GOSB811264
Fecha			20191110
Objetivo		Levantar las alertas recurrentes, es decir, por exceso de movimientos o por exceso de monto,dependiendo de su perfil transaccional
Proyecto		BANCA FRAUDES
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_ALERTA_RECURRENTE

@NumeroSocio int

as

	begin -- procedimiento
		
		--begin try -- try principal
		
		--	begin -- inicio

		--		-- declaraciones
				declare --@status int = 1,
		--				@error_message varchar(255) = '',
		--				@error_line varchar(255) = '',
		--				@error_severity varchar(255) = '',
		--				@error_procedure varchar(255) = '',
						@fecha date=getdate()

			
		--	end -- inicio
			
		--	begin -- ámbito de la actualización
				
				 -------------------------------Se obtienen todos los movimientos de haberes y de SPEI por socio------------------------------------------
				  select *
					 into #mov
					 from (     
							select distinct 
								trans.numero_socio NumSocio, 
								trans.id_banca_folio,
								trans.monto,
								trans.fecha_transferencia_realizada
							from 
								banca.dbo.TBL_BANCA_TRANSFERENCIAS_INTERNAS trans
							where 
								CAST(SUBSTRING(trans.clave_corresponsalias_destino,10,7) as float)<>CAST(SUBSTRING(trans.clave_corresponsalias_origen,10,7) as float)
								and CAST(trans.fecha_transferencia_realizada as date) = CAST(@fecha as date) 
								and trans.id_estatus_transferencia=2
						union--Movimientos por SPEI
							select distinct 
								trans_ext.numero_socio NumSocio, 
								trans_ext.id_banca_folio,
								trans_ext.monto,
								trans_ext.fecha_transferencia_realizada
							from 
								banca.dbo.TBL_BANCA_TRANSFERENCIAS_EXTERNAS trans_ext
							where CAST(trans_ext.fecha_transferencia_realizada as date) = CAST(@fecha as date) 
								and trans_ext.id_estatus_transferencia=2
						)movimientos
					where movimientos.id_banca_folio not in(select Folio_movimiento from banca..TBL_BANCA_FRAUDE_MOVIMIENTOS)
					and movimientos.NumSocio=@NumeroSocio


					--select * from #mov

				------------------------Obtiene número de movimientos y monto total de movimientos por socio---------------------------------------------
					select 
						NumMovimientos.NumSocio, 
						count(*) NumMovimientos,
						sum(cast(NumMovimientos.monto as money)) montototal
						into #RepMov
						from #mov NumMovimientos
					group by NumMovimientos.NumSocio

					--select * from #RepMov

				-----------Validamos con el perfil transaccional registrado por socio en la tabla TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL

					select 
						RepMov_.NumSocio,
						RepMov_.montototal,
						RepMov_.NumMovimientos, 
						case 
							when (RepMov_.montototal > perfil.Monto_Acumulado and RepMov_.NumMovimientos <= perfil.Numero_Operaciones ) 
								then 2
							when (RepMov_.montototal <= perfil.Monto_Acumulado and RepMov_.NumMovimientos > perfil.Numero_Operaciones ) 
								then 1
							when (RepMov_.montototal > perfil.Monto_Acumulado and RepMov_.NumMovimientos > perfil.Numero_Operaciones ) 
								then 3
						end as tipo_recurrente
					into #SociosAlertados
					from #RepMov RepMov_
					inner join banca.dbo.TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL perfil on RepMov_.NumSocio = perfil.Numero_Socio 
					and (RepMov_.montototal > perfil.Monto_Acumulado  
					or RepMov_.NumMovimientos > perfil.Numero_Operaciones)
					inner join banca..TBL_BANCA_SOCIOS socios on socios.numero_socio=RepMov_.NumSocio and socios.banca_activa=1 and socios.id_motivo_bloqueo=1	
					---------------------------Validación temporal-----------------------------------
					and RepMov_.NumSocio not in (select numero_socio from banca..TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR)  
				--	-----------------------------------------------------------------------------------

					--select * from #SociosAlertados

				----------Se registran en la tabla de TBL_BANCA_FRAUDE_ALERTA a los socios que no cumplieron con el perfil transaccional
				   insert into banca.dbo.TBL_BANCA_FRAUDE_ALERTA(Fecha_Alerta,NUMERO_SOCIO,ID_TIPO_ALERTA,ID_ALERTA_RECURRENTE,ID_ESTATUS, tipo_recurrente)
				   select 
					   @fecha fecha,
					   NumSocio,
					   1 Tipo_alerta,
					   1 Alerta_recurrente,
					   1 Idstatus,
					   tipo_recurrente
					from #SociosAlertados 
	 
					 --select NumSocio from #SociosAlertados

				----------Se actualiza el tipo de bloqueo en TBL_BANCA_SOCIO
					update TBL_BANCA_SOCIOS set id_motivo_bloqueo = 13, fecha_motivo_bloqueo=getdate()
					where id_motivo_bloqueo = 1 and banca_activa=1 and numero_socio in (select NumSocio from #SociosAlertados)

				----------Se insertan los posibles movimientos fraudulentos en la tabla TBL_BANCA_FRAUDE_MOVIMIENTOS
					Insert into TBL_BANCA_FRAUDE_MOVIMIENTOS(folio_movimiento,Id_alerta,Numero,Fecha_movimiento,id_tipo_alerta)
					select distinct
						mov.id_banca_folio,	
						(select max(Folio_alerta) from TBL_BANCA_FRAUDE_ALERTA where NUMERO_SOCIO=socios.NumSocio and ID_TIPO_ALERTA=1 and cast(Fecha_Alerta as date)=cast(@fecha as date)) Folio_alerta,
						socios.NumSocio,
						mov.fecha_transferencia_realizada,--debe ser la fecha de movimiento _tbl_interna o tbl_externa
						alerta.ID_TIPO_ALERTA
					from #SociosAlertados socios
					inner join banca..TBL_BANCA_FRAUDE_ALERTA alerta on alerta.NUMERO_SOCIO=socios.NumSocio
					inner join #mov mov on mov.NumSocio=alerta.NUMERO_SOCIO and mov.NumSocio=socios.NumSocio and mov.id_banca_folio not in(select Folio_movimiento from banca..TBL_BANCA_FRAUDE_MOVIMIENTOS)
					where alerta.ID_TIPO_ALERTA=1 and cast(alerta.Fecha_Alerta as date)=cast(@fecha as date) and alerta.ID_ESTATUS = 1


				----------Se inserta en la bitácora de operaciones
					insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus)						
					select distinct
						socios.NumSocio,
						3 Id_Tipo_Bitacoras_Fraudes,
						@fecha Fecha,
						(select Descripcion_Bitacoras_Fraudes from banca.dbo.CAT_banca_fraude_tipos_bitacora_fraude where id_Tipo_Bitacoras_fraudes = 3)Evento,
						alerta.ID_ESTATUS
					from #SociosAlertados socios 
					inner join banca.dbo.TBL_BANCA_FRAUDE_ALERTA alerta on alerta.NUMERO_SOCIO=socios.NumSocio 
					where alerta.ID_TIPO_ALERTA = 1 and alerta.ID_ESTATUS = 1 and socios.NumSocio not in(select Numero_Socio from TBL_BANCA_FRAUDE_BITACORA_OPERACIONES where Cast(Fecha_alta as date)=Cast(@fecha as date))

				----------Obtenemos el idBitacora de la bitacora de operaciones 
					select 
						max(bitacora.Id_Bitacora_Fraude)IdBitacoraFraude,
						socios.NumSocio 
					into #idBitacoraFraude
					from #SociosAlertados socios
					inner join banca..TBL_BANCA_FRAUDE_BITACORA_OPERACIONES bitacora on bitacora.Numero_Socio=socios.NumSocio 
					and bitacora.Id_Tipo_Bitacoras_Fraudes=3 and bitacora.Estatus=1
					group by socios.NumSocio
	 
				--	--select * from #idBitacoraFraude
				----------insertar notificaciones TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO

				   insert into TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO (Numero_Socio,Nombre_Socio,Tel_Celular,Email,id_tipo_notificacion,Id_Tipo_Bitacoras_Fraudes,Id_bitacora_fraude) 
				   select distinct
						alerta.Numero_socio,
						pers.Nombre as Nombre_Socio,
						pers.Tel_celular,
						pers.Mail,
						contrato.id_tipo_notificacion,
						3 IdTipoBitacora,--Id_Tipo_Bitacoras_Fraudes Bloqueo alerta recurrente
						bitacora.IdBitacoraFraude
					from #SociosAlertados socios
						inner join banca.dbo.TBL_BANCA_FRAUDE_ALERTA alerta on alerta.NUMERO_SOCIO=socios.NumSocio
						inner join (select Numero,(Nombre_s+' '+Apellido_Paterno+' '+Apellido_Materno)Nombre,Tel_celular,Mail from HAPE.dbo.PERSONA where Id_Tipo_Persona=1) pers on pers.numero=alerta.numero_Socio  
						inner join #idBitacoraFraude bitacora on bitacora.NumSocio=alerta.NUMERO_SOCIO
						inner join HAPE.dbo.TBL_CONTRATOS_HABERES contrato on alerta.numero_socio = contrato.numero and contrato.id_tipo_contrato = 3 and contrato.id_tipo_persona = 1 and contrato.id_tipo_notificacion is not null
					where alerta.ID_ESTATUS = 1 and alerta.id_tipo_alerta=1 
					and socios.NumSocio not in(select Numero_Socio from banca..TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO)

			        --Actualizamos el id_tipo_de_bitacora_fraudes y La notificacion_sms y la notificacion_Email
					update notificacion set 
						notificacion.Id_Tipo_Bitacoras_Fraudes=3,
						notificacion.Id_bitacora_fraude=bitacora.IdBitacoraFraude,
						notificacion.Notificacion_sms=0,
						notificacion.Notificacion_Email=0 
					from banca..TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO notificacion 
					inner join #SociosAlertados socios on socios.NumSocio=notificacion.Numero_Socio
					inner join #idBitacoraFraude bitacora on bitacora.NumSocio=socios.NumSocio


					--Eliminamos tablas temporales
					Drop table #mov
					Drop table #RepMov 
					Drop table #SociosAlertados
					Drop table #idBitacoraFraude
					

	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_ALERTA_RECURRENTE to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_ALERTA_TIEMPO_MINIMO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_ALERTA_TIEMPO_MINIMO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_ALERTA_TIEMPO_MINIMO
go

/*

Autor			Luis Arturo Gálvez Macias - Claudia Alejandra Arredondo Rodríguez - Blanca Estela 
UsuarioRed	GAML841262 - AERC864420 - 
Fecha			20190320
Objetivo		Consultar las alertas  que esten levantadas por socios que tengan  movimientos en un tiempo meno a unsegundo
Proyecto		Banca ElectrÑnica DvisiÑn de Fraudes Electronicos
Ticket			ticket

*/



create proc

	SP_BANCA_FRAUDE_ALERTA_TIEMPO_MINIMO

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				declare	@tran_name varchar(32) = 'ALERTA_TIEMPO_MINIMO',
						@tran_count int = @@trancount,
						@tran_scope bit = 0,
						@id_tipo_bitacora int,
						@tipo_origen_operacion int,
						@motivobloqueo varchar(255),
						@XML XML,
						@tiempo int,
						@id_motivo_bloqueo int,
						@descripcion_bloqueo varchar(255),
						@id_tipo_alerta_bloqueo int,
						@idtipo_bitacora_fraude int,
						@Descripcion_Bitacoras_Fraudes varchar(900),
						@idtipo_bitacora_fraude_bloqueo int,
						@Descripcion_Bitacoras_Fraudes_bloqueo varchar(900),
						@Fecha_inicio datetime
					
				create table #tiempo_minimo (
					id_transferencia bigint,
					id_estatus_transferencia int,
					numero_origen int,
					consecutivo int,
					numero_destino int,
					fecha_transferencia_realizada datetime,
					monto money,
					diferencia decimal(16,3),
					programada bit
				)

				create table #bloqueo_socio(
					numero_socio int
				)

				create table #movs(
					id_banca_folio int,
					numero_socio int,
					fecha_transferencia_realizada datetime
				)

			end -- inicio

			begin -- preparación

				/* Inicialización de variables con consulta */
				set @id_tipo_alerta_bloqueo =  5 --- Alerta de Tiempo M ínimo
				set @id_motivo_bloqueo = 13  --- Bloqueo automático por motivos de fraudes
				set @tipo_origen_operacion = 7--- Módulo de Fraudes
				set @id_tipo_bitacora= 87 --- Bloqueo automático por intento o por  fraude a la  cuenta
				
				select @idtipo_bitacora_fraude_bloqueo= id_Tipo_Bitacoras_fraudes,
					      @Descripcion_Bitacoras_Fraudes_bloqueo = Descripcion_Bitacoras_Fraudes
				from CAT_banca_fraude_tipos_bitacora_fraude
				where id_Tipo_Bitacoras_fraudes = 4 --- Bloqueo por alerta de tiempo mínimo
			end -- preparación
									
			begin -- transacción

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio
				
				begin -- componente de la transacción
					
					--- Obtener los movimientos del socio que ha realizado desde la última ejecución del script al momento
					insert into #tiempo_minimo
					select	id_transferencia,
								id_estatus_transferencia,
								numero_origen = co.numero,
								row_number() over (partition by co.numero order by co.numero, fecha_transferencia_realizada, id_transferencia),
								numero_destino = cd.NUMERO,
								fecha_transferencia_realizada,
								monto,
								null,
								programada				
					from	banca.dbo.TBL_BANCA_TRANSFERENCIAS_INTERNAS t
						inner join TBL_BANCA_SOCIOS socio on t.numero_socio = socio.numero_socio and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1 and socio.id_motivo_bloqueo = 1
						inner join hape.dbo.TBL_CORRESPONSALIAS_CUENTAS co on co.CUENTA = t.clave_corresponsalias_origen
						inner join hape.dbo.TBL_CORRESPONSALIAS_CUENTAS cd on cd.CUENTA = t.clave_corresponsalias_destino
					where	id_estatus_transferencia = 2
						and t.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and cast(fecha_transferencia_realizada as date)  = cast(GETDATE() as date)	
						and CAST(substring(t.clave_corresponsalias_origen,10,7)as int) <> CAST(SUBSTRING(t.clave_corresponsalias_destino,10,7)as int)

					insert into #tiempo_minimo
					select trans.id_transferencia, 
								id_estatus_transferencia, 
								socio.numero_socio, 
								ROW_NUMBER() over(partition by clabes.numero_socio order by clabes.numero_socio, id_transferencia),
								0, 
								fecha_transferencia_realizada, 
								monto, 
								null,
								programado						
					from TBL_BANCA_TRANSFERENCIAS_EXTERNAS trans
						inner join TBL_BANCA_SOCIOS socio on socio.numero_socio = trans.numero_socio and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1 and socio.id_motivo_bloqueo = 1
						inner join TBL_BANCA_CUENTAS_INTERBANCARIAS clabes on clabes.numero_socio = socio.numero_socio 
					where id_estatus_transferencia = 2
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and CAST(fecha_transferencia_realizada as date) = CAST(GETDATE() as date)			
			

					--- Actualizar la diferencia entre dos movimientos
					update	m2
					set		m2.diferencia = (datediff(ms, m1.fecha_transferencia_realizada, m2.fecha_transferencia_realizada) /1e3)
					from	#tiempo_minimo m1
						join #tiempo_minimo m2 on m2.numero_origen = m1.numero_origen and m2.consecutivo = m1.consecutivo + 1

					--- Generar tabla de usuario a bloquear
					insert into #bloqueo_socio
					select distinct numero_origen
					from #tiempo_minimo
					where numero_origen not in  (select numero_socio from TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR)
						and diferencia < 1 and diferencia is not null

					--- Obtener los movimientos que generaron la alerta
					insert into #movs
					select distinct 
						trans.id_banca_folio,
						socio.numero_socio,
						trans.fecha_transferencia_realizada
					from tbl_banca_transferencias_internas trans 
						inner join TBL_BANCA_SOCIOS socio on trans.numero_socio = socio.numero_socio and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1
						inner join #bloqueo_socio bs on bs.numero_socio = socio.numero_socio
					where  CAST( trans.fecha_transferencia_realizada as date) = CAST(GETDATE() as date)
						and (trans.id_transferencia in (select id_transferencia from #tiempo_minimo))
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and cast(substring(trans.clave_corresponsalias_origen,10,7)as int) = socio.NUMERO_SOCIO
						and CAST(substring(trans.clave_corresponsalias_origen,10,7)as int) <> CAST(SUBSTRING(trans.clave_corresponsalias_destino,10,7)as int)
						and trans.id_estatus_transferencia=2 
						and trans.programada = 0
						  
					union 

					select distinct 
						trans.id_banca_folio, 
						socio.numero_socio,
						trans.fecha_transferencia_realizada
					from TBL_BANCA_TRANSFERENCIAS_EXTERNAS trans
						inner join TBL_BANCA_SOCIOS socio on trans.numero_socio = socio.numero_socio and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1
						inner join #bloqueo_socio bs on bs.numero_socio = socio.numero_socio			
					where  CAST( trans.fecha_transferencia_realizada as date) = CAST(GETDATE() as date)
						and (trans.id_transferencia in (select id_transferencia from #tiempo_minimo))
						and id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and id_estatus_transferencia = 2
						and trans.programado = 0

					--- Generar la alerta
					insert into TBL_BANCA_FRAUDE_ALERTA(NUMERO_SOCIO, Fecha_Alerta, ID_TIPO_ALERTA, ID_ALERTA_RECURRENTE, ID_ESTATUS, id_notificacion)
					select distinct Numero_socio, GETDATE(), @id_tipo_alerta_bloqueo, 1, 1, 0
					from #bloqueo_socio				

					--- Insertar en la tabla de movimiento s
					insert into TBL_BANCA_FRAUDE_MOVIMIENTOS(Folio_movimiento, Numero, Fecha_movimiento, Id_tipo_alerta, Id_alerta)
					select *, @id_tipo_alerta_bloqueo, (select MAX(folio_alerta) from TBL_BANCA_FRAUDE_ALERTA)
					from #movs

					--- Insertar en la bitacora de fraudes
					insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus)
					select socio.NUMERO_SOCIO, @idtipo_bitacora_fraude_bloqueo as Id_Tipo_Bitacoras_Fraudes, GETDATE(), @Descripcion_Bitacoras_Fraudes_bloqueo as Evento, 1
					from #bloqueo_socio socio

					--- Actualizar los socios a bloquear
					update banca..TBL_BANCA_SOCIOS 
					set  id_motivo_bloqueo=@id_motivo_bloqueo,
						fecha_motivo_bloqueo = getdate(),
						viene_de_bloqueo = 1,
						descripcion_bloqueo=@motivobloqueo
					from banca..TBL_BANCA_SOCIOS bancaSocios, #bloqueo_socio bancaSociosTemp
					where bancaSocios.numero_socio = bancaSociosTemp.numero_socio

					--- Actualización / inserción en la tabla para notificar
					if((select COUNT(id) from TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO a, #bloqueo_socio b where a.Numero_Socio = b.Numero_socio ) > 0)
						begin
							update TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO 
								set Notificacion_Email = 0, Notificacion_sms = 0
								where Numero_Socio in  (select numero_socio from #bloqueo_socio)
						end
					else
						insert into  TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO (Numero_Socio,Nombre_Socio,Tel_Celular,Email,Id_Tipo_Bitacoras_Fraudes,id_tipo_notificacion)
						select distinct
							bs.Numero_socio,
							P.Nombre_s+' '+P.Apellido_Paterno+' '+Apellido_Materno as Nombre_Socio,
							P.Tel_celular,
							P.Mail,
							1,
							contrato.id_tipo_notificacion
						from Tbl_banca_fraude_alerta alerta
							inner join hape..PERSONA P on P.numero=alerta.numero_Socio and P.id_tipo_persona = 1
							inner join BANCA..TBL_BANCA_SOCIOS bsocios on bsocios.numero_socio = alerta.NUMERO_SOCIO
							inner join HAPE..TBL_CONTRATOS_HABERES contrato on alerta.numero_socio = contrato.numero
							inner join #bloqueo_socio bs on bs.Numero_socio = P.Numero
						where bsocios.banca_activa = 1
							and bsocios.id_motivo_bloqueo = 13
							and contrato.id_tipo_contrato = 3 			
					
					drop table #tiempo_minimo, #bloqueo_socio, #movs
					 
				end -- componente de la transacción
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacción se inició dentro de este ámbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacción se inició dentro de este ámbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
						
			-- revertir transacción si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDE_ALERTA_TIEMPO_MINIMO to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_BITACORA_ACCION_USUARIO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_BITACORA_ACCION_USUARIO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_BITACORA_ACCION_USUARIO
go

/*

Autor			Claudia Alejandra Arredondo Rodríguez
UsuarioRed		AERC864420
Fecha			20191129
Objetivo		Obtener la bitacora de las acciones del usuario
Proyecto		Banca Electrónica / Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_BITACORA_ACCION_USUARIO
	@FechaInicio datetime = null,
	@FechaFin datetime = null
		-- parametros
		-- [aquí van los parámetros]

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
                        @error_message varchar(255) = '''''',
                        @error_line varchar(255) = '''''',
                        @error_severity varchar(255) = '''''',
                        @error_procedure varchar(255) = '''''',
                        @cadena  NVARCHAR(MAX)
						
				-- valores por defecto
				--set @FechaInicio = coalesce(@FechaInicio,cast(getdate()as date))
				--set @FechaFin = coalesce(@FechaFin,cast(getdate() as date))

			end -- inicio
			
			begin -- ámbito de la actualización

				 set @cadena = 
					'SELECT '+
						cast(@status as varchar) + ' status, ' +
						@error_procedure + ' error_procedure, ' +
						@error_line + ' error_line, ' +
						@error_severity + ' error_severity, ' +
						@error_message + ' error_message,
						id_banca_folio AS Folio_Movimiento, 
						numero_socio, fecha_alta as Fecha_Evento, 
						btb.descripcion as Evento, 
						boo.descripcion as Origen,
						usuario 
					FROM banca..TBL_BANCA_BITACORA_OPERACIONES bbo
					INNER JOIN banca..cat_banca_origen_operacion boo ON bbo.id_origen_operacion=boo.id_origen_operacion
					INNER JOIN banca..CAT_BANCA_TIPOS_BITACORA btb ON bbo.id_tipo_bitacora=btb.id_tipo_bitacora
					WHERE numero_socio IN (SELECT numero_socio FROM banca..tbl_banca_fraude_alerta WHERE id_estatus=1)' 
					if @FechaInicio IS NOT NULL AND @FechaFin IS NOT NULL
						set @cadena +=  ' AND CONVERT(varchar(24),fecha_alta,112) BETWEEN ' + CONVERT(varchar(24),@FechaInicio,112) + ' AND ' + CONVERT(varchar(24),@FechaFin,112)
					else if @FechaInicio is not null and @FechaFin is null
						set @cadena += ' AND CONVERT(varchar(24),fecha_alta,112) > ' +  CONVERT(varchar(24),@FechaInicio,112) 
					else if @FechaInicio is null and @FechaFin is not null
						set @cadena += ' AND CONVERT(varchar(24),fecha_alta,112) < ' +  CONVERT(varchar(24),@FechaFin,112)
					set @cadena += ' ORDER BY fecha_alta DESC'
                    
                    --select @cadena
					EXEC(@cadena)

				
					

				
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_BITACORA_ACCION_USUARIO to public


use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_CONSULTA_ADMINISTRACION_REPORTES
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_CONSULTA_ADMINISTRACION_REPORTES' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_CONSULTA_ADMINISTRACION_REPORTES
go

/*

Autor			Luis Arturo GÑlvez Macias
UsuarioRed		GAML841262
Fecha			20190308
Objetivo		Consultar la tabla de AdministraciÑn de  Reportes  
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_CONSULTA_ADMINISTRACION_REPORTES
	@FechaInicio datetime= null,
	@FechaFin	 datetime = null

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				-- valores por defecto
				set @FechaInicio = CAST(coalesce(@FechaInicio,GETDATE()) as date)
				set @FechaFin  = CAST(coalesce(@FechaFin,GETDATE()+1) as date)
			end -- inicio

			begin -- ámbito de la actualización
			
				select	
					@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,
					AdminRepos.Numero_Socio,
					AdminRepos.Nombre_Socio,
					canalizados.Estatus_Canalizacion,
					AdminRepos.Anotaciones,
					AdminRepos.Fecha_Atencion
					from TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES AdminRepos
					inner join CAT_BANCA_FRAUDES_ALERTAS_CANALIZADOS_CERRADOS canalizados on AdminRepos.Id_Canalizacion = canalizados.Id_Canalizacion
					inner join CAT_BANCA_FRAUDE_MOTIVO_CIERRE cierreMot on cierreMot.Id_Motivo = AdminRepos.Motivo
						where cast( AdminRepos.Fecha_Atencion as date) >= cast(@FechaInicio	as date)
						and  cast( AdminRepos.Fecha_Atencion as date) <=cast(@FechaFin	as date)
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_CONSULTA_ADMINISTRACION_REPORTES to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_CORREOS_DUPLICADOS
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_CORREOS_DUPLICADOS' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_CORREOS_DUPLICADOS
go

/*

Autor			Luis Arturo Gálvez Macias
UsuarioRed		GAML841262
Fecha			20190611
Objetivo		Obtener los correo duplicados
Proyecto		FRAUDES BANCA
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_CORREOS_DUPLICADOS
	
		-- parametros
		-- [aquí van los parámetros]

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
			end -- inicio
			
			begin -- ámbito de la actualización
				--------Se obtienen los correos de socios repetidos 
				select 
					bsocios.numero_socio,
					pers.Mail
				into #CorreosDuplicados
				from banca.dbo.TBL_BANCA_SOCIOS as bsocios
				inner join HAPE.dbo.PERSONA as pers 
				on pers.Numero=bsocios.numero_socio
				inner join(select count(1) conteo, Mail from hape.dbo.persona
					where Id_Tipo_Persona = 1
					group by Mail
					having count(1)>1)correos
				on pers.Mail = correos.Mail
				where 
				bsocios.banca_activa=1 
				and pers.Mail is not null		
				and pers.Id_Tipo_Persona = 1
				order by bsocios.numero_socio, pers.Mail 		
			
		--------Se inserta en la tabla de TBL_BANCA_FRAUDE_ALERTA
				insert into TBL_BANCA_FRAUDE_ALERTA(Fecha_Alerta,NUMERO_SOCIO,Id_tipo_Alerta,Id_alerta_recurrente,id_estatus)
				SELECT 
					GETDATE() fecha, 
					numero_socio, 
					7 tipoalerta,
					0 alertarecurrente, 
					1 estatus
				from #CorreosDuplicados
				WHERE 
				numero_socio not in (select numero_socio from TBL_BANCA_FRAUDE_ALERTA where ID_TIPO_ALERTA=7 and cast(Fecha_Alerta as date)=cast(DATEADD(DAY,-1,GETDATE()) as date))
				group by numero_socio

		--------Se inserta en la bitácora de operaciones
				insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus)
				select distinct
					alerta.NUMERO_SOCIO,
					8 Id_Tipo_Bitacoras_Fraudes,
					GETDATE() Fecha,
					(select Descripcion_Bitacoras_Fraudes from CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE where id_Tipo_Bitacoras_fraudes=8) Descripcion_Bitacoras_Fraudes,
					alerta.ID_ESTATUS
				from TBL_BANCA_FRAUDE_ALERTA alerta
				where
				alerta.NUMERO_SOCIO not in(select NUMERO_SOCIO from TBL_BANCA_FRAUDE_BITACORA_OPERACIONES where Id_Tipo_Bitacoras_Fraudes=8 and cast(Fecha_alta as date)=cast(DATEADD(DAY,-1,GETDATE()) as date))
				and alerta.ID_TIPO_ALERTA = 7
				and alerta.ID_ESTATUS = 1 

		--------Eliminamos tabla temporal
				Drop table #CorreosDuplicados
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_CORREOS_DUPLICADOS to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_CREACION_PERFIL_TRANSACCIONAL_SOCIO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_CREACION_PERFIL_TRANSACCIONAL_SOCIO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_CREACION_PERFIL_TRANSACCIONAL_SOCIO
go

/*

Autor			Eduardo Villagomez Mata
UsuarioRed		VIME770170
Fecha			20190909
Objetivo		Actualizar el perfil transaccional de los usuarios que utilizan banca
Proyecto		Banca Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_CREACION_PERFIL_TRANSACCIONAL_SOCIO
	
	@numero_socio int,
	@numero_usuario int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@fecha_proceso datetime = getdate(),
						@fecha_max datetime ,
						@maxmonto float=2000
			
			end -- inicio
			
			begin -- ámbito de la actualización
			    
				select @fecha_proceso = isnull(@fecha_proceso,getdate())
					/*Query para obtener la fecha del último movimiento*/
				select    
						@fecha_max = cast(max(perfil.Fecha) as datetime)
				from
				(select                           
						max(Fecha_Alta) Fecha
				from 
						hape..movimientos 
				where 
						numero=@numero_socio 
						and Id_tipomov IN (310,350,1001)
						group by Numero,id_tipomov
				union

				select                        
						max(Fecha_Alta) Fecha
				from 
						HISTORICO..MOVIMIENTOS_HABERES
				where 
						numero=@numero_socio
						and Id_tipomov IN (310,350,1001)
						and Fecha_Alta between DATEADD(month,-3,(select max(fecha_alta) from historico..movimientos_haberes where numero=@numero_socio and id_tipo_persona=1)) 
						and (select max(fecha_alta) from historico..movimientos_haberes where numero=@numero_socio and id_tipo_persona=1)
						group by Numero,id_tipomov
				)perfil 

 
					/*Validamos si la fecha no es null*/
					if(CONVERT(varchar,@fecha_max,112) != ' ')
					begin
				 
						if not exists( select * from BANCA..TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL where Numero_Socio= @numero_socio )
							begin
								insert into BANCA..TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL (Numero_Socio,Monto_Acumulado,Fecha_Actulizacion,Numero_Operaciones,Numero_Usuario)
								(select            
										perfil.socio,
										max(perfil.monto) as [Monto Maximo],
										@fecha_proceso as [Fecha Alta],
										4 as [Numero Operaciones],
										@numero_usuario        
								from
								(select           
										numero socio,       
										max(monto) monto,
										max(Fecha_Alta) Fecha
								from 
										hape..movimientos 
								where 
										numero=@numero_socio 
										and Id_tipomov IN (310,350,1001)
										group by Numero,id_tipomov
								union

								select        
										numero socio,        
										max(monto) monto,
										max(Fecha_Alta) Fecha
								from 
										HISTORICO..MOVIMIENTOS_HABERES
								where 
										numero=@numero_socio
										and Id_tipomov IN (310,350,1001)
										and Fecha_Alta between DATEADD(month,-3,(select max(fecha_alta) from historico..movimientos_haberes where numero=@numero_socio and id_tipo_persona=1)) 
										and (select max(fecha_alta) from historico..movimientos_haberes where numero=@numero_socio and id_tipo_persona=1)
										group by Numero,id_tipomov
								)perfil 
								group by perfil.socio)
						   end
						   
					 end
					 else
					  begin 
					  	if not exists( select * from BANCA..TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL where Numero_Socio= @numero_socio )
							insert into BANCA..TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL (Numero_Socio,Monto_Acumulado,Fecha_Actulizacion,Numero_Operaciones,Numero_Usuario)
							values (@numero_socio,@maxmonto,@fecha_proceso,4,@numero_usuario)
					  end
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_CREACION_PERFIL_TRANSACCIONAL_SOCIO to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_DESBLOQUEO_SOCIOS_ALERTADOS
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_DESBLOQUEO_SOCIOS_ALERTADOS' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_DESBLOQUEO_SOCIOS_ALERTADOS
go

/*

Autor			Luis Arturo Gálvez Macias
UsuarioRed		GAML841262
Fecha			20190919
Objetivo		Desbloquear a los socios que  fueron alertados por posibles movimientos fraudulentos
Proyecto		Modulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_DESBLOQUEO_SOCIOS_ALERTADOS
	@Numero_Socio int,
	@numerousuario int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				declare	@tran_name varchar(32) = 'NOMBRE_TRANSACCION',
						@tran_count int = @@trancount,
						@tran_scope bit = 0,
						@idtipo_bitacora_fraude_desbloqueo int,
						@Descripcion_Bitacoras_Fraudes_desbloqueo varchar(900)
						
			end -- inicio
								
			begin -- transacción

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio
				
				begin -- componente de la transacción
							
					update 
						TBL_BANCA_SOCIOS
					set 
						id_motivo_bloqueo = 1,
						fecha_motivo_bloqueo = getdate()
					from 
						TBL_BANCA_FRAUDE_ALERTA  alerta 
						inner join TBL_BANCA_SOCIOS bsocios  on bsocios.numero_socio= alerta.NUMERO_SOCIO and bsocios.banca_activa =1 and bsocios.id_estatus_banca in (6,8)
					where 
						id_tipo_alerta in (1,2,5,6) 
						and alerta.NUMERO_SOCIO = @Numero_Socio
						and alerta.ID_ESTATUS in (3)

					update tbl_banca_fraudes_notificacion_SMS_EMAIL_SOCIO_ALERTADO
					set Id_Tipo_Bitacoras_Fraudes = 2
					from tbl_banca_fraudes_notificacion_SMS_EMAIL_SOCIO_ALERTADO where Numero_Socio = @Numero_Socio

					/*Registro notificacion de bitacora de fraudes */

					select @idtipo_bitacora_fraude_desbloqueo =id_Tipo_Bitacoras_fraudes,
					@Descripcion_Bitacoras_Fraudes_desbloqueo =	Descripcion_Bitacoras_Fraudes
					from
					 cAT_banca_fraude_tipos_bitacora_fraude
					 where id_Tipo_bitacoras_fraudes = 2
		
					insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus,usuario)
					select 
						alerta.NUMERO_SOCIO,
						@idtipo_bitacora_fraude_desbloqueo as Id_Tipo_Bitacoras_Fraudes,
						GETDATE(),
						@Descripcion_Bitacoras_Fraudes_desbloqueo as Evento,
						alerta.ID_ESTATUS,
						@numerousuario
					from TBL_BANCA_FRAUDE_ALERTA alerta 
					inner join CAT_BANCA_FRAUDE_TIPO_ALERTA tipoAlerta on tipoAlerta.ID_TIPO_ALERTA=alerta.ID_TIPO_ALERTA
					where 
						alerta.NUMERO_SOCIO =@Numero_Socio 
						and ID_ESTATUS in(3) 
				
				end -- componente de la transacción
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacción se inició dentro de este ámbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacción se inició dentro de este ámbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
						
			-- revertir transacción si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDE_DESBLOQUEO_SOCIOS_ALERTADOS to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_DETALLE_ALERTA
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_DETALLE_ALERTA' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_DETALLE_ALERTA
go

/*

Autor			Luis Arturo Galvez Macias
UsuarioRed		GAML841262
Fecha			20190820
Objetivo		Obtener la descripción de las alertas por las cuales esta alertado el socio
Proyecto		Proyecto
Ticket			ticket

*/

CREATE PROC SP_BANCA_FRAUDE_DETALLE_ALERTA 
  @numero_socio INT
AS
  BEGIN -- procedimiento

    BEGIN TRY -- try principal

      BEGIN -- inicio
        -- declaraciones
        DECLARE 
          @status          INT          = 1, 
          @error_message   VARCHAR(255) = '', 
          @error_line      VARCHAR(255) = '', 
          @error_severity  VARCHAR(255) = '', 
          @error_procedure VARCHAR(255) = '';
      END; -- inicio

      BEGIN -- ámbito de la actualización

        SELECT 
          @status STATUS, 
          @error_procedure error_procedure, 
          @error_line error_line, 
          @error_severity error_severity, 
          @error_message error_message, 
		  alerta.folio_alerta,
          alerta.NUMERO_SOCIO, 
          alerta.ID_TIPO_ALERTA, 
          cat_alerta.DESCRIPCION AS Descripcion_Tipo_Alerta
        FROM tbl_banca_fraude_alerta alerta
             JOIN CAT_BANCA_FRAUDE_TIPO_ALERTA cat_alerta ON alerta.id_tipo_alerta = cat_alerta.ID_TIPO_ALERTA
        WHERE NUMERO_SOCIO = @numero_socio AND alerta.id_estatus = 1;
      END; -- ámbito de la actualización

    END TRY -- try principal

    BEGIN CATCH -- catch principal
      -- captura del error
      SELECT 
        @status = -ERROR_STATE(), 
        @error_procedure = COALESCE(ERROR_PROCEDURE(), 'CONSULTA DINÁMICA'), 
        @error_line = ERROR_LINE(), 
        @error_message = ERROR_MESSAGE(), 
        @error_severity = CASE ERROR_SEVERITY()
                            WHEN 11
                              THEN 'Error en validación'
                            WHEN 12
                              THEN 'Error en consulta'
                            WHEN 13
                              THEN 'Error en actualización'
                          ELSE 'Error general'
                          END;
    END CATCH; -- catch principal

  END; -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_DETALLE_ALERTA to public

USE BANCA
GO

-- se crea procedimiento SP_BANCA_FRAUDE_GENERAR_ID_LLAMADA
IF EXISTS (SELECT * FROM sysobjects WHERE NAME LIKE 'SP_BANCA_FRAUDE_GENERAR_ID_LLAMADA' AND xtype = 'p' AND db_name() = 'BANCA')
	DROP PROC SP_BANCA_FRAUDE_GENERAR_ID_LLAMADA
GO
/*
Autor				Sabdi Abraham Pantoja Orozco
UsuarioRed	paos845568
Fecha				05/Diciembre/2019
Objetivo		Generar un nuevo ID para la realización de la llamada de presence
Proyecto		Banca/Fraude
Ticket			ticket
*/
CREATE PROC
	SP_BANCA_FRAUDE_GENERAR_ID_LLAMADA
AS
	BEGIN -- procedimiento
		BEGIN TRY -- try principal	
			BEGIN -- inicio
				-- declaraciones
				DECLARE 
					@status int = 1,
					@error_message VARCHAR(255) = '',
					@error_line VARCHAR(255) = '',
					@error_severity VARCHAR(255) = '',
					@error_procedure VARCHAR(255) = ''
			END -- inicio
			
			BEGIN 
				SELECT 
					@status status,
					@error_message error_message,
					@error_line error_line,
					@error_severity error_severity,
					@error_procedure error_procedure,
					MAX(CALL_ID) + 1 new_id
				FROM une..cmv_rec_data 
				WHERE CALL_ID IS NOT NULL
			END
		END TRY -- try principal
		
		BEGIN CATCH -- catch principal
			-- captura del error
			SELECT	
				@status = -error_state(),
				@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
				@error_line = error_line(),
				@error_message = error_message(),
				@error_severity =
					CASE error_severity()
						WHEN 11 THEN 'Error en validación'
						WHEN 12 THEN 'Error en consulta'
						WHEN 13 THEN 'Error en actualización'
						ELSE 'Error general'
					END
		END CATCH -- catch principal
	END -- procedimiento	
GO

GRANT EXEC ON SP_BANCA_FRAUDE_GENERAR_ID_LLAMADA TO PUBLIC

USE banca;
GO

-- se crea procedimiento SP_BANCA_FRAUDE_INSERCION_DATOS_REPORTE
IF EXISTS
(
    SELECT 
	 *
    FROM sysobjects
    WHERE name LIKE 'SP_BANCA_FRAUDE_INSERCION_DATOS_REPORTE'
		AND xtype = 'p'
		AND DB_NAME() = 'banca'
)
  BEGIN
    DROP PROC 
	 SP_BANCA_FRAUDE_INSERCION_DATOS_REPORTE;
END;
GO

/************************************************************************************************
Autor			Sabdi Abraham Pantoja Orozco
UsuarioRed		PAOS845568
Fecha			2019-12-26
Objetivo			Inserción de los datos  que son importantes en las  alertas  levantadas  anteriormente
Proyecto			Banca Electrónica División de Fruades Electrónicos
Ticket			ticket
************************************************************************************************/

CREATE PROC SP_BANCA_FRAUDE_INSERCION_DATOS_REPORTE 
  @Numero_Socio    INT, 
  @Nombre_Socio    VARCHAR(255), 
  @Anotaciones     TEXT, 
  @folio_alerta    INT, 
  @Id_Canalizacion INT          = NULL, 
  @Fecha_Atencion  DATETIME     = NULL, 
  @Motivo          INT          = NULL, 
  @numerousuario   INT
AS
  BEGIN -- procedimiento

    BEGIN TRY -- try principal

	 BEGIN -- inicio
	   -- declaraciones
	   DECLARE @status          INT          = 1, 
			 @error_message   VARCHAR(255) = '', 
			 @error_line      VARCHAR(255) = '', 
			 @error_severity  VARCHAR(255) = '', 
			 @error_procedure VARCHAR(255) = '';
	   DECLARE @tran_name  VARCHAR(32) = 'NOMBRE_TRANSACCION', 
			 @tran_count INT         = @@trancount, 
			 @tran_scope BIT         = 0;

	   -- valores por defecto
	   SET @Fecha_Atencion = CAST(COALESCE(@Fecha_Atencion, GETDATE()) AS DATE);
	   SET @Id_Canalizacion = COALESCE(@Id_Canalizacion, 1);
	   SET @Fecha_Atencion = CAST(GETDATE() AS DATE);
	 END; -- inicio

	 BEGIN -- transacción

	   BEGIN -- inicio

		IF @tran_count = 0
		  BEGIN
		    BEGIN TRAN @tran_name;
		END;
		  ELSE
		  BEGIN
		    SAVE TRAN @tran_name;
		END;
		SELECT 
		  @tran_scope = 1;
	   END; -- inicio

	   BEGIN -- componente de la transacción

		UPDATE TBL_BANCA_FRAUDE_ALERTA
		  SET 
		    ID_ESTATUS = @Id_Canalizacion
		WHERE 
		  folio_alerta = @folio_alerta;
		UPDATE TBL_BANCA_SOCIOS
		  SET 
		    id_motivo_bloqueo = 14
		WHERE 
		  numero_socio = @Numero_Socio
		IF
		(
		    SELECT 
			 COUNT(1)
		    FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
		    WHERE folio_alerta = @folio_alerta
		) > 0
		  BEGIN
		    UPDATE TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
			 SET 
			   Anotaciones = @Anotaciones, 
			   Id_Canalizacion = @Id_Canalizacion, 
			   Fecha_Atencion = @Fecha_Atencion
		    WHERE 
			 folio_alerta = @folio_alerta;
		END;
		  ELSE
		  BEGIN
		    INSERT INTO TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES(
			 Numero_Socio, 
			 Nombre_Socio, 
			 Anotaciones, 
			 Id_Canalizacion, 
			 Fecha_Atencion, 
			 Motivo, 
			 Numero_Usuario, 
			 folio_alerta
		    )
		    VALUES
		    (
			 @Numero_Socio, 
			 @Nombre_Socio, 
			 @Anotaciones, 
			 @Id_Canalizacion, 
			 @Fecha_Atencion, 
			 @Motivo, 
			 @numerousuario, 
			 @folio_alerta
		    );
		END;
	   END; -- componente de la transacción

	   BEGIN -- commit

		IF @tran_count = 0
		  BEGIN -- si la transacción se inició dentro de este ámbito

		    COMMIT TRAN @tran_name;
		    SELECT 
			 @tran_scope = 0;
		END; -- si la transacción se inició dentro de este ámbito

	   END; -- commit

	 END;
    END TRY -- try principal

    BEGIN CATCH -- catch principal
	 -- captura del error
	 SELECT 
	   @status = -ERROR_STATE(), 
	   @error_procedure = COALESCE(ERROR_PROCEDURE(), 'CONSULTA DINÁMICA'), 
	   @error_line = ERROR_LINE(), 
	   @error_message = ERROR_MESSAGE(), 
	   @error_severity = CASE ERROR_SEVERITY()
					   WHEN 11
						THEN 'Error en validación'
					   WHEN 12
						THEN 'Error en consulta'
					   WHEN 13
						THEN 'Error en actualización'
					   ELSE 'Error general'
					 END;

	 -- revertir transacción si es necesario
	 IF @tran_scope = 1
	   BEGIN
		ROLLBACK TRAN @tran_name;
	 END;
    END CATCH; -- catch principal

    BEGIN -- reporte de status

	 SELECT 
	   @status          STATUS, 
	   @error_procedure error_procedure, 
	   @error_line      error_line, 
	   @error_severity  error_severity, 
	   @error_message   error_message;
    END; -- reporte de status

  END; -- procedimiento
GO
GRANT EXEC ON SP_BANCA_FRAUDE_INSERCION_DATOS_REPORTE TO public;

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_NOTIFICACION_CUERPO_DATOS_CORREO_SMS
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_NOTIFICACION_CUERPO_DATOS_CORREO_SMS' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_NOTIFICACION_CUERPO_DATOS_CORREO_SMS
go

/*

Autor			Luis Arturo Gálvez Macias
UsuarioRed		GAML841262
Fecha			20191007
Objetivo		Ver los datos del cuerpo de la notificacion del usuario
Proyecto		Modulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_NOTIFICACION_CUERPO_DATOS_CORREO_SMS
	@numero_socio int,
	@id_tipo_notificacion int,
	@Id_Tipo_Bitacoras_Fraudes int = null

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				-- valores por defecto
				set @Id_Tipo_Bitacoras_Fraudes = coalesce(@Id_Tipo_Bitacoras_Fraudes,1)	
			
			end -- inicio
			
			begin -- ámbito de la actualización
			
				if(@id_tipo_notificacion = 1)
					select	
						@status status,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message,
				 		socio_alerta.Id_Tipo_Bitacoras_Fraudes,
						socio_alerta.id_tipo_notificacion,
						socio_alerta.Tel_Celular,
						nSMS.cuerpo as  CuerpoSMS
					FROM  tbl_banca_fraudes_notificacion_SMS_EMAIL_SOCIO_ALERTADO socio_alerta
				    inner join TBL_BANCA_FRAUDES_NOTIFICACIONES_SMS nSMS on nSMS.Id_Tipo_Bitacoras_Fraudes = socio_alerta.id_tipo_bitacoras_fraudes
					where  Numero_Socio = @numero_socio
					and nSMS.Id_Tipo_Bitacoras_Fraudes =@Id_Tipo_Bitacoras_Fraudes
				
				if(@id_tipo_notificacion=2)
					select	
						@status status,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message,
				 		socio_alerta.Id_Tipo_Bitacoras_Fraudes,
						socio_alerta.id_tipo_notificacion,socio_alerta.Tel_Celular,
						socio_alerta.Email,
						ncorreo.asunto as Asunto,
						ncorreo.cuerpo  CuerpoCorreo
					FROM  tbl_banca_fraudes_notificacion_SMS_EMAIL_SOCIO_ALERTADO socio_alerta
					inner join TBL_BANCA_FRAUDE_NOTIFICACION_CORREO ncorreo on ncorreo.Id_Tipo_Bitacoras_Fraudes = socio_alerta.id_tipo_bitacoras_fraudes
					where 
						 Numero_Socio = @numero_socio
						and ncorreo.Id_Tipo_Bitacoras_Fraudes =@Id_Tipo_Bitacoras_Fraudes
				
				if(@id_tipo_notificacion = 3)
					select	
						@status status,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message,
				 		socio_alerta.Id_Tipo_Bitacoras_Fraudes,
						socio_alerta.id_tipo_notificacion,
						socio_alerta.Tel_Celular,
						socio_alerta.Email,
						ncorreo.asunto as Asunto,
						ncorreo.cuerpo CuerpoCorreo,
						nSMS.cuerpo as CuerpoSMS
					FROM  tbl_banca_fraudes_notificacion_SMS_EMAIL_SOCIO_ALERTADO socio_alerta
						inner join TBL_BANCA_FRAUDE_NOTIFICACION_CORREO ncorreo on ncorreo.Id_Tipo_Bitacoras_Fraudes = socio_alerta.id_tipo_bitacoras_fraudes
						INNER JOIN TBL_BANCA_FRAUDES_NOTIFICACIONES_SMS nSMS on nSMS.Id_Tipo_Bitacoras_Fraudes =socio_alerta.id_tipo_bitacoras_fraudes
					where Numero_Socio = @numero_socio
						and nSMS.Id_Tipo_Bitacoras_Fraudes =@Id_Tipo_Bitacoras_Fraudes
						and ncorreo.Id_Tipo_Bitacoras_Fraudes =@Id_Tipo_Bitacoras_Fraudes
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_NOTIFICACION_CUERPO_DATOS_CORREO_SMS to public

USE BANCA
GO

-- se crea procedimiento SP_BANCA_FRAUDE_NVA_ALERTA
IF EXISTS (SELECT * FROM sysobjects WHERE NAME LIKE 'SP_BANCA_FRAUDE_NVA_ALERTA' AND xtype = 'p' AND db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_NVA_ALERTA
go

/*

Autor				Sabdi Abraham Pantoja Orozco
UsuarioRed	paos845568
Fecha				2/Diciembre/2019
Objetivo		Obtener a los socios que estan alertados por una  o más alertas 
Proyecto		Modulo de fraudes
Ticket			ticket

*/

CREATE PROC SP_BANCA_FRAUDE_NVA_ALERTA 
  @FechaInicio DATETIME = NULL, 
  @FechaFin    DATETIME = NULL
AS
  BEGIN -- procedimiento

    BEGIN TRY -- try principal

      BEGIN -- inicio
        -- declaraciones
        DECLARE 
          @status          INT           = 1, 
          @error_message   VARCHAR(255)  = '''''', 
          @error_line      VARCHAR(255)  = '''''', 
          @error_severity  VARCHAR(255)  = '''''', 
          @error_procedure VARCHAR(255)  = '''''', 
          @cadena          NVARCHAR(MAX);
      END; -- inicio

      BEGIN -- ámbito de la actualización

        SET @cadena = 'SELECT 
							' + CAST(@status AS VARCHAR) + ' status, 
							' + @error_procedure + ' error_procedure, 
							' + @error_line + ' error_line, 
							' + @error_severity + ' error_severity, 
							' + @error_message + ' error_message, 
							 socios.NUMERO_SOCIO, 
							 socios.Nombre_Socio, 
							 socios.Tel_Celular,
							 No_alertas alertas
						FROM (
							SELECT	
								count(*) AS No_alertas,
								numero_socio, 
								concat(p.nombre_s+'' '',p.apellido_paterno+''  '',p.apellido_materno) AS Nombre_Socio, 
								p.Tel_Celular
							FROM 
								banca..TBL_BANCA_FRAUDE_ALERTA alerta
								INNER JOIN
								hape..persona p
								ON alerta.NUMERO_SOCIO=p.Numero
							WHERE
								p.Id_Tipo_Persona=1
								AND ID_ESTATUS = 1
							GROUP BY numero_socio,p.Tel_Celular,p.Nombre_s,p.Apellido_Paterno,p.Apellido_Materno
							)	AS socios';
        IF @FechaInicio IS NOT NULL
           AND @FechaFin IS NOT NULL
          BEGIN
            SET @cadena+=' WHERE 
							cast(socios.Fecha_Alerta as date) >= cast(' + @FechaInicio + '  AS date) AND 
							cast(socios.Fecha_Alerta AS date) <= cast(' + @FechaFin + ' as date)';
        END;
        ELSE
          IF @FechaInicio IS NULL
             AND @FechaFin IS NOT NULL
            BEGIN
              SET @cadena+=' WHERE 
							cast(socios.Fecha_Alerta AS date) <= cast(' + @FechaFin + ' as date)';
          END;
          ELSE
            IF @FechaInicio IS NOT NULL
               AND @FechaFin IS NULL
              BEGIN
                SET @cadena+=' WHERE 
							cast(socios.Fecha_Alerta as date) >= cast(' + @FechaInicio + '  AS date)';
            END;
		--SET @cadena+= ' GROUP BY socios.NUMERO_SOCIO';
		--SELECT @cadena;
        EXEC (@cadena);
      END; -- ámbito de la actualización

    END TRY -- try principal

    BEGIN CATCH -- catch principal
      -- captura del error
      SELECT 
        @status = -ERROR_STATE(), 
        @error_procedure = COALESCE(ERROR_PROCEDURE(), 'CONSULTA DINÁMICA'), 
        @error_line = ERROR_LINE(), 
        @error_message = ERROR_MESSAGE(), 
        @error_severity = CASE ERROR_SEVERITY()
                            WHEN 11
                              THEN 'Error en validación'
                            WHEN 12
                              THEN 'Error en consulta'
                            WHEN 13
                              THEN 'Error en actualización'
                          ELSE 'Error general'
                          END;
    END CATCH; -- catch principal

  END; -- procedimiento
	
GO

grant exec on SP_BANCA_FRAUDE_NVA_ALERTA to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_OBTENER_DATOS_SOCIO_DESBLOQUEO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_OBTENER_DATOS_SOCIO_DESBLOQUEO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_OBTENER_DATOS_SOCIO_DESBLOQUEO
go

/*

Autor			Luis Arturo Gálvez Macias
	UsuarioRed		GAML841262
	Fecha			20191008
	Objetivo		Obtener  los datos para notificar al socio que ya fue desbloqueado 
	Proyecto		Proyecto
	Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_OBTENER_DATOS_SOCIO_DESBLOQUEO
	 @Numero_Socio int 

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
				
			end -- inicio
			
			begin -- ámbito de la actualización
			
				select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,
				    socioAlertado.Numero_Socio,
					socioAlertado.Nombre_Socio,
					socioAlertado.Tel_Celular,
					Email,
					Id_tipo_notificacion,
					2 as Id_Tipo_Bitacoras_Fraudes,
					bitaope.Id_bitacora_fraude,
					socioAlertado.Notificacion_sms,
					socioAlertado.Notificacion_Email
				from  
					TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO socioAlertado
					inner join TBL_BANCA_FRAUDE_BITACORA_OPERACIONES bitaope on bitaope.Numero_Socio = socioAlertado.Numero_Socio 
				where 
					bitaope.Numero_Socio= @Numero_Socio
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_OBTENER_DATOS_SOCIO_DESBLOQUEO to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_OBTENER_MOTIVOS_CIERRE
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_OBTENER_MOTIVOS_CIERRE' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_OBTENER_MOTIVOS_CIERRE
go

/*

Autor			Luis Arturo GÑlvez Macias
UsuarioRed		GAML841262
Fecha			20190401
Objetivo		Obtener los motivos por los cuales  se puede  cerrar  un  reporte
Proyecto		Banca Electronica DivisiÑn de Fruades ElectrÑnicos
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_OBTENER_MOTIVOS_CIERRE
	
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
				
			end -- inicio
						
			begin -- ámbito de la actualización
			
				select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message, *
					from CAT_BANCA_FRAUDE_MOTIVO_CIERRE
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
				
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_OBTENER_MOTIVOS_CIERRE to public

use banca
go

-- se crea procedimiento SP_BANCA_FRAUDE_OBTENER_SOCIOS_ALERTADOS_ATENDIDOS_CAMBIO_PERIL
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_OBTENER_SOCIOS_ALERTADOS_ATENDIDOS_CAMBIO_PERIL' and xtype = 'p' and db_name() = 'banca')
	drop proc SP_BANCA_FRAUDE_OBTENER_SOCIOS_ALERTADOS_ATENDIDOS_CAMBIO_PERIL
go

/*

Autor			LAGM
UsuarioRed		GAML841262
Fecha			20190923
Objetivo		Ver los socios alertados que 
Proyecto		Modulo Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_OBTENER_SOCIOS_ALERTADOS_ATENDIDOS_CAMBIO_PERIL
	
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
				
			end -- inicio
									
			begin -- ámbito de la actualización
			
				select	
					@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,
					alerta.NUMERO_SOCIO,
					P.Nombre_s+' '+P.Apellido_Paterno+' '+P.Apellido_Materno as Nombre_Socio,
					P.Tel_Celular
				from 
					TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL perfil_tran
					inner join TBL_BANCA_FRAUDE_ALERTA alerta  on alerta.NUMERO_SOCIO = perfil_tran.Numero_Socio
					inner join HAPE..Persona P on P.numero = perfil_tran.Numero_socio
					inner join  TBL_BANCA_SOCIOS bsocios on bsocios.numero_socio = perfil_tran.Numero_Socio
				where id_motivo_bloqueo = 13
					and	ID_TIPO_ALERTA in (2,3,7)
					and ID_ESTATUS in (2,3)
					and id_tipo_persona = 1 

			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_OBTENER_SOCIOS_ALERTADOS_ATENDIDOS_CAMBIO_PERIL to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_REPORTE_ALERTA_TIPO1
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_REPORTE_ALERTA_TIPO1' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_REPORTE_ALERTA_TIPO1
go

/*

Autor			Claudia Alejandra Arredondo Rodríguez
UsuarioRed		AERC864420
Fecha			20191108
Objetivo		Objetivo
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_REPORTE_ALERTA_TIPO1
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
				
			end -- inicio
						
			begin -- ámbito de la actualización
			
				select @status, Folio_alerta,Fecha_alerta,NUMERO_SOCIO,ID_TIPO_ALERTA 
				from TBL_BANCA_FRAUDE_ALERTA 
				where ID_TIPO_ALERTA = 1 and ID_ESTATUS = 1
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_REPORTE_ALERTA_TIPO1 to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_SIN_MOVS_ANIO_TST
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_SIN_MOVS_ANIO_TST' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_SIN_MOVS_ANIO_TST
go

/* Recopilación de script por aerc864420 en 20191108

Autor			Autor
UsuarioRed		aaaa111111
Fecha			yyyymmdd
Objetivo		Objetivo
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_SIN_MOVS_ANIO_TST
	@numerosocio  int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@anios int,
						@fecha_max datetime,
						@fecha_proceso datetime
				
			end -- inicio
						
			begin -- ámbito de la actualización
			
				set @fecha_proceso = getdate()
				/*Asignacion de los años por el valor que se tenga en el parametrizador*/
				select @anios  = cast(valor as int)  *-1
					from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS 
				where id_parametro= 6

				select @fecha_max = max(movimientos.fecha_mov)
				from(
							select max(fecha_mov) fecha_mov
							from historicos..movimientos_haberes 
							where numero = @numerosocio and id_tipo_persona = 1 and id_tipomov not in (91,92,93,94,95,511,512,610,620,1005) and activo = 'T'

							union 

							select max(fecha_mov) fecha_mov
							from archivo_historico..movimientos_ptmos_liquidados 
							where numero=@numerosocio  and id_tipo_persona=1 and id_tipomov NOT IN (91,92,93,94,95,511,512,610,620,1005) and activo='t'

							union

							select max(fecha_mov) fecha_mov 
							from archivo_historico..movimientos_haberes 
							where numero=@numerosocio and id_tipo_persona=1 and id_tipomov NOT IN (91,92,93,94,95,511,512,610,620,1005) and activo='t'
						
							union

							select max(fecha_mov) fecha_mov
							from hape..movimientos mov
							where numero=@numerosocio and id_tipo_persona=1	and id_tipomov NOT IN (91,92,93,94,95,511,512,610,620,1005) and activo='t'
						) movimientos
						
				--Validación para detectar si la última fecha tiene más de 1 año y generar alerta																								
				if(convert(varchar,@fecha_max,112)<=dateadd(yy,@anios,@fecha_proceso) and convert(varchar,@fecha_max,12) is not null)
					begin
						--- Crear alerta
						insert into TBL_BANCA_FRAUDE_ALERTA(NUMERO_SOCIO, Fecha_Alerta, ID_TIPO_ALERTA, ID_ALERTA_RECURRENTE, ID_ESTATUS)
						values (@numerosocio, GETDATE(), 3, 0, 1)

					   --Insertar en la tabla de Bitacoras 
						insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus)
						values (@numerosocio, 11, GETDATE(), 'Registro de Alerta | Sin movimientos', 1)
					end
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
						@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
						@error_line = error_line(),
						@error_message = error_message(),
						@error_severity =
							case error_severity()
								when 11 then 'Error en validación'
								when 12 then 'Error en consulta'
								when 13 then 'Error en actualización'
								else 'Error general'
							end
		
		end catch -- catch principal
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_SIN_MOVS_ANIO_TST to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_TELEFONO_DUPLICADO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_TELEFONO_DUPLICADO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_TELEFONO_DUPLICADO
go

/*

Autor			Luis Arturo Gálvez Macias
UsuarioRed		GAML841262
Fecha			20190903
Objetivo		Detección de numero de celular  duplicados entre los socios con el servicio activo de CMV finanazas
Proyecto		Modulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_TELEFONO_DUPLICADO
	
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
			end -- inicio
			
			begin -- ámbito de la actualización
		 ----------------Se obtienen los números de socios que tienen el mismo numero de teléfono
						select 
							pers.Numero,
							substring(pers.Tel_Celular,1,10) as Num_Celular
						into #TelefonoDuplicado
						from HAPE.dbo.PERSONA pers 
						inner join BANCA.dbo.TBL_BANCA_SOCIOS bsocios on pers.Numero = bsocios.numero_socio and pers.Id_Tipo_Persona = 1 and pers.Tel_Celular is not null and bsocios.banca_activa=1		
						inner join(select count(1) conteo ,Tel_Celular from HAPE.dbo.persona
							where Id_Tipo_Persona = 1
							group by Tel_Celular
							having count(1)>1)tel_celular
						on pers.Tel_Celular = tel_celular.Tel_Celular						
						order by pers.Tel_Celular

		----------------select * from #TelefonoDuplicado
		----------------Se insertan los números que cumplen con la alerta
						insert into TBL_BANCA_FRAUDE_ALERTA (Fecha_Alerta,NUMERO_SOCIO,Id_tipo_Alerta,Id_alerta_recurrente,id_estatus)
						SELECT cast(GETDATE()as date), Numero,8,0,1
							from #TelefonoDuplicado
						WHERE	
						Numero not in (select numero_socio from banca..TBL_BANCA_FRAUDE_ALERTA where ID_TIPO_ALERTA=8 and Cast(Fecha_Alerta as date)= cast(DATEADD(DAY,-1,GETDATE()) as date))
						group by Numero

		----------------Se inserta en la bitácora de operaciones
						insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus)
						select distinct
							alerta.NUMERO_SOCIO,
							9 Id_Tipo_Bitacoras_Fraudes,
							GETDATE(),
							(select Descripcion_Bitacoras_Fraudes from banca..CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE where id_Tipo_Bitacoras_fraudes=9)Descripcion_Bitacoras_Fraudes,
							alerta.ID_ESTATUS
						from banca..TBL_BANCA_FRAUDE_ALERTA alerta 
						where 
						alerta.ID_TIPO_ALERTA = 8
						and alerta.ID_ESTATUS = 1 

		----------------Se eliminan tabla temporales
		  				Drop table #TelefonoDuplicado
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_TELEFONO_DUPLICADO to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_VER_DATOS_PARA_MODAL
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_VER_DATOS_PARA_MODAL' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_VER_DATOS_PARA_MODAL
go

/*

Autor			Luis Arturo Gálvez Macias
UsuarioRed		GAML841262
Fecha			20191022
Objetivo		Ver las alertas de que tiene el socio donde se pueda  obtener  el folio de la  alerta y el tipo 
Proyecto		Modulo de Fraudes
Ticket			ticket

*/

CREATE PROC SP_BANCA_FRAUDE_VER_DATOS_PARA_MODAL 
  @Numero_Socio INT, 
  @folioAlerta  INT
AS
  BEGIN -- procedimiento

    BEGIN TRY -- try principal

      BEGIN -- inicio
        -- declaraciones
        DECLARE 
          @status          INT          = 1, 
          @error_message   VARCHAR(255) = '', 
          @error_line      VARCHAR(255) = '', 
          @error_severity  VARCHAR(255) = '', 
          @error_procedure VARCHAR(255) = '';
      END; -- inicio

      BEGIN -- ámbito de la actualización

        SELECT 
          @status STATUS, 
          @error_procedure error_procedure, 
          @error_line error_line, 
          @error_severity error_severity, 
          @error_message error_message, 
          *
        FROM TBL_BANCA_FRAUDE_ALERTA
        WHERE numero_socio = @Numero_Socio
              AND folio_alerta = @folioAlerta
              AND ID_ESTATUS = 1;
      END; -- ámbito de la actualización

    END TRY -- try principal

    BEGIN CATCH -- catch principal
      -- captura del error
      SELECT 
        @status = -ERROR_STATE(), 
        @error_procedure = COALESCE(ERROR_PROCEDURE(), 'CONSULTA DINÁMICA'), 
        @error_line = ERROR_LINE(), 
        @error_message = ERROR_MESSAGE(), 
        @error_severity = CASE ERROR_SEVERITY()
                            WHEN 11
                              THEN 'Error en validación'
                            WHEN 12
                              THEN 'Error en consulta'
                            WHEN 13
                              THEN 'Error en actualización'
                          ELSE 'Error general'
                          END;
    END CATCH; -- catch principal

  END; -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_VER_DATOS_PARA_MODAL to public

use banca
go

-- se crea procedimiento SP_BANCA_FRAUDE_VER_SOCIOS_BLOQUEADOS
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_VER_SOCIOS_BLOQUEADOS' and xtype = 'p' and db_name() = 'banca')
	drop proc SP_BANCA_FRAUDE_VER_SOCIOS_BLOQUEADOS
go

/*

Autor			Luis Arturo Gálvez Macias
UsuarioRed		GAML841262
Fecha			20190919
Objetivo		Desbloquear a los socios que  fueron alertados por posibles movimientos fraudulentos
Proyecto		Modulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_VER_SOCIOS_BLOQUEADOS

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
					
			end -- inicio
			
			begin -- transacción

				begin -- componente de la transacción
				
					--if exists(select * from TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS )
					--	delete socio_desbloqueados
					--	from  TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS socio_desbloqueados
					--	inner join TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO socio_alertado on socio_alertado.Numero_Socio = socio_desbloqueados.Numero_Socio

					if not exists (select * from TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS)
						insert into TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS(
							Id_Motivo_Bloqueo,Numero_Socio,Nombre_Socio,Tel_Celular,Mail,Id_tipo_notificacion)
						select distinct 
							bsocios.id_motivo_bloqueo,
							bsocios.numero_socio,
							P.Nombre_s+' '+P.Apellido_Paterno +' '+P.Apellido_Materno as Nombre_Socio,
							P.Tel_Celular,
							P.Mail,
							socio_alertado.id_tipo_notificacion					
						from TBL_BANCA_SOCIOS bsocios
						inner join HAPE..PERSONA P on bsocios.numero_socio =P.Numero
						inner join TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO socio_alertado on socio_alertado.Numero_Socio = bsocios.numero_socio
						where 
							bsocios.banca_activa =1
							and bsocios.id_motivo_bloqueo=13
							and P.Id_Tipo_Persona =1 
				
				end -- componente de la transacción
				
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
								
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,
					  bsocios.numero_socio as Numero_Socio,
					P.Nombre_s+''+P.Apellido_Paterno+'' +P.Apellido_Materno AS Nombre_Socio,
					P.Tel_celular
					from TBL_BANCA_SOCIOS bsocios
					inner join TBL_BANCA_FRAUDE_ALERTA alerta on alerta.NUMERO_SOCIO = bsocios.numero_socio
					inner join HAPE..PERSONA P on P.Numero = bsocios.numero_socio 
					where 
						 bsocios.banca_activa=1
						and bsocios.id_motivo_bloqueo = 13
						and ID_ESTATUS in (3)
						and alerta.id_tipo_alerta in (1,2,5,6)
						and Id_Tipo_Persona = 1 
					group by bsocios.numero_socio,P.Tel_Celular, P.Nombre_s+''+P.Apellido_Paterno+'' +P.Apellido_Materno
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDE_VER_SOCIOS_BLOQUEADOS to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDES_ACCESO_USUARIO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_ACCESO_USUARIO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_ACCESO_USUARIO
go

/*

Autor			Luis Arturo GÑlvez Macias
UsuarioRed		GAML841262
Fecha			20190405
Objetivo		Dar acceso a los  usuarios que estente  con los siguietes  roles  para  poder manejar   el sistema de Fraudes
Proyecto		Banca ElectrÑnica DivisiÑn de Fraudes Electronicos
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_ACCESO_USUARIO
	@numusuario	int,
	@contrasena	varchar(40)

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@contrasena_claves varchar(40)

			end -- inicio
			
			begin -- ámbito de la actualización
			
				select /*@contrasena_claves = contrasena */ * from hape..CLAVES  cls
				inner join BANCA.dbo.TBL_BANCA_FRAUDES_ACCESO_USUARIO accesousuario on cls.Id_Rol = accesousuario.Id_Rol
				where numusuario = @numusuario

				if @@error <> 0

					begin
					select activo = 0
					print 'Error al leer claves'
					goto exit_proc
					end
				if @contrasena_claves = @contrasena
					select activo = 1
				else
				select @status = 0
				exit_proc:
				--	select Activo activo
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDES_ACCESO_USUARIO to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDES_ACTUALIZACION_PARAMETROS
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_ACTUALIZACION_PARAMETROS' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_ACTUALIZACION_PARAMETROS
go

/*

Autor			Claudia Alejandra Arredondo Rodríguez
UsuarioRed		AERC864420
Fecha			20191105
Objetivo		Actualización de los parámetros deL módulo: alerta anzuelo, sin movimiento, edad y ciclica
Proyecto		Módulo Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_ACTUALIZACION_PARAMETROS
	@Id_parametro int, --Recibe un 0 cuando se actualizara uno o más parámetros para los valores anzuelos
	@valor money,
	@Numusuario int,
	@valor2 money = null,
	@valor3 money = null

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@descripcion1 varchar(100),
						@descripcion2 varchar(100),
						@descripcion3 varchar(100),
						@val money = 0,
						@val2 money = 0,
						@val3 money = 0
						
				declare	@tran_name varchar(32) = 'NOMBRE_TRANSACCION',
						@tran_count int = @@trancount,
						@tran_scope bit = 0
						
			
			end -- inicio

			begin -- preparación

				if(@Id_parametro = -1)
					begin
						set @descripcion1 = (select Nombre_parametro from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where Id_parametro = 3)
						set @val = (select Valor from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where Id_parametro = 3)

						set @descripcion2 = (select Nombre_parametro from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where Id_parametro = 4)
						set @val2 = (select Valor from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where Id_parametro = 4)

						set @descripcion3 = (select Nombre_parametro from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where Id_parametro = 5)
						set @val3 = (select Valor from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where Id_parametro = 5)

					end
				else
					begin
						set @descripcion1 = (select Nombre_parametro from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where Id_parametro = @Id_parametro)
						set @val = (select Valor from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where Id_parametro = @Id_parametro)
					end
			end -- preparación
			
			begin -- transacción

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio
				
				begin -- componente de la transacción
					if(@Id_parametro = -1)
						begin
							if(@valor is not null and @valor != @val)
								begin
									update TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS
										set Valor = @valor
										where Id_parametro = 3

									insert into TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PARAMETROS(Valor,Nombre_Parametro,Fecha_Actualizacion,numero_usuario)
									values (@valor, @descripcion1, GETDATE(), @Numusuario)	

								end

								
					
							if(@valor2 is not null and @valor2 != @val2)
								begin
									update TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS
										set Valor = @valor2
										where Id_parametro = 4

									insert into TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PARAMETROS(Valor,Nombre_Parametro,Fecha_Actualizacion,numero_usuario)
									values (@valor2, @descripcion2, GETDATE(), @Numusuario)	
								end

							if(@valor3 is not null and @valor3 != @val3)
								begin
									update TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS
										set Valor = @valor3
										where Id_parametro = 5

									insert into TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PARAMETROS(Valor,Nombre_Parametro,Fecha_Actualizacion,numero_usuario)
									values (@valor3, @descripcion3, GETDATE(), @Numusuario)	
								end

						end
					else
						if(@valor is not null and @valor != @val)
							begin
								update TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS
									set Valor = @valor
									where Id_parametro = @Id_parametro

								insert into TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PARAMETROS(Valor,Nombre_Parametro,Fecha_Actualizacion,numero_usuario)
								values (@valor,@descripcion1,GETDATE(),@Numusuario)	
							end
						
				
				end -- componente de la transacción
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacción se inició dentro de este ámbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacción se inició dentro de este ámbito
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
						
			-- revertir transacción si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDES_ACTUALIZACION_PARAMETROS to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDES_ACTULIZACION_ESTATUS_NOTIFICACION_SMS_EMAIL
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_ACTULIZACION_ESTATUS_NOTIFICACION_SMS_EMAIL' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_ACTULIZACION_ESTATUS_NOTIFICACION_SMS_EMAIL
go

/*

Autor			Luis Arturo Gálvez Macias
UsuarioRed		GAML841262
Fecha			20191003
Objetivo		Actualizar el estatude notificación  de los socios alertados 
Proyecto		Modulo de Fraudes 
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_ACTULIZACION_ESTATUS_NOTIFICACION_SMS_EMAIL
	@numero_socio int ,
	@Valor_Notificacion int,
	@notificacionSMS int,
	@notificacion_Email int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				declare	@tran_name varchar(32) = 'Actulizacion_Estatus_Notificacion',
						@tran_count int = @@trancount,
						@tran_scope bit = 0

			end -- inicio
						
			begin -- transacción

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio
				
				begin -- componente de la transacción
				
					/*
						CAT_BANCA_TIPO_NOTIFICACION
						1	SMS
						2	Correo electrónico
						3	Ambos medios
					*/
	
					if(@Valor_Notificacion = 1)
					begin 
						update TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO
						set Notificacion_sms = @notificacionSMS
						from TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO  
						where Notificacion_sms = 0 and numero_socio = @numero_socio
					end
				
					if(@Valor_Notificacion = 2)
					begin 
						update 
							TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO
						set 
							Notificacion_Email = 1
						from 
							TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO  
							where Notificacion_Email = 0 
							and numero_socio = @numero_socio
					end
				 
					/*Caso de que sea notificar a los dos medios*/
					if(@Valor_Notificacion = 3)
						begin 
							/* SMS */
							update 
								TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO
							set 
								Notificacion_sms =  @notificacionSMS
							from 
								TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO  
							where Notificacion_sms = 0 
								and numero_socio = @numero_socio
							/* Email */
							update 
								TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO
							set 	
								Notificacion_Email = @notificacion_Email
							from 
								TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO 
							where Notificacion_Email = 0 
								and numero_socio = @numero_socio
						end
								
				end -- componente de la transacción
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacción se inició dentro de este ámbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacción se inició dentro de este ámbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
						
			-- revertir transacción si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDES_ACTULIZACION_ESTATUS_NOTIFICACION_SMS_EMAIL to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDES_BITACORA_ACCION_USUARIO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_BITACORA_ACCION_USUARIO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_BITACORA_ACCION_USUARIO
go

/*

Autor			Claudia Alejandra Arredondo Rodríguez
UsuarioRed		aerc864420
Fecha			20191106
Objetivo		Objetivo
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_BITACORA_ACCION_USUARIO
	@FechaInicio datetime = null,
	@FechaFin datetime = null

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@cadena  NVARCHAR(MAX)
						
				-- valores por defecto
				--set @FechaInicio = coalesce(@FechaInicio,cast(getdate()as date))
				--set @FechaFin = coalesce(@FechaFin,cast(getdate() as date))

			end -- inicio
			
			begin -- ámbito de la actualización

				if @FechaInicio is not null and @FechaFin is not null
					begin
						 select	@status status,  	
									@error_procedure error_procedure, 	
									@error_line error_line, 
									@error_severity error_severity, 	
									@error_message error_message,
									id_banca_folio as Folio_Movimiento,  		
									numero_socio, 	
									fecha_alta as Fecha_Evento, 	
									btb.descripcion as Evento, 		
									boo.descripcion as Origen, 	usuario
											from 
												banca..TBL_BANCA_BITACORA_OPERACIONES bbo
												inner join  banca..cat_banca_origen_operacion boo
												on bbo.id_origen_operacion=boo.id_origen_operacion
												inner join
												banca..CAT_BANCA_TIPOS_BITACORA btb
												on bbo.id_tipo_bitacora=btb.id_tipo_bitacora
											where 
												numero_socio IN (select numero_socio from banca..tbl_banca_fraude_alerta where id_estatus=1) 
					end
				set @cadena = 'select	'  + 	cast(@status as varchar) + ' status,  	@error_procedure error_procedure, 	@error_line error_line, 	@error_severity error_severity, 	@error_message error_message,
												id_banca_folio as Folio_Movimiento,  		numero_socio, 	fecha_alta as Fecha_Evento, 	btb.descripcion as Evento, 		boo.descripcion as Origen, 	usuario
											from 
												banca..TBL_BANCA_BITACORA_OPERACIONES bbo
												inner join  banca..cat_banca_origen_operacion boo
												on bbo.id_origen_operacion=boo.id_origen_operacion
												inner join
												banca..CAT_BANCA_TIPOS_BITACORA btb
												on bbo.id_tipo_bitacora=btb.id_tipo_bitacora
											where 
												numero_socio IN (select numero_socio from banca..tbl_banca_fraude_alerta where id_estatus=1) ' 
					if @FechaInicio is not null and @FechaFin is not null
						set @cadena +=  ' and CONVERT(varchar(24),fecha_alta,112) between ' + CONVERT(varchar(24),@FechaInicio,112) + ' and ' + CONVERT(varchar(24),@FechaFin,112)
					else if @FechaInicio is not null and @FechaFin is null
						set @cadena += ' and CONVERT(varchar(24),fecha_alta,112) > ' +  CONVERT(varchar(24),@FechaInicio,112) 
					else if @FechaInicio is null and @FechaFin is not null
						set @cadena += ' and  CONVERT(varchar(24),fecha_alta,112) < ' +  CONVERT(varchar(24),@FechaFin,112)

					set @cadena += ' order by fecha_alta desc'
					
					--select @cadena
					exec(@cadena)
									
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDES_BITACORA_ACCION_USUARIO to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDES_CONSULTA_ALERTAS_ATENDIDAS
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_CONSULTA_ALERTAS_ATENDIDAS' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_CONSULTA_ALERTAS_ATENDIDAS
go

/*

Autor			Luis Arturo Gálvez Macias 
UsuarioRed		gaml841262
Fecha			20190319
Objetivo		Consultar las  alertas 
Proyecto		Banca ElectrÑnica DivisiÑn de Fraudes ElectrÑnicos
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_CONSULTA_ALERTAS_ATENDIDAS
	@FechaInicio datetime = null,
	@FechaFin datetime = null

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				
				-- valores por defecto
				set @FechaInicio  = CAST(coalesce(@FechaInicio,Getdate()) as date)
				set @FechaFin	  = CAST(coalesce(@FechaFin,Getdate())+1 as date) 
			
			end -- inicio

			begin -- ámbito de la actualización
			
				select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,* 
						from tbl_banca_Fraude_administracion_reportes repos
						join CAT_BANCA_FRAUDE_ESTATUS festatus
						on repos.Id_Canalizacion = festatus.ID_ESTATUS
							where Id_Canalizacion = 2 
							and Fecha_Atencion >= @FechaInicio 
							and Fecha_Atencion <= @FechaFin
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDES_CONSULTA_ALERTAS_ATENDIDAS to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDES_CONSULTA_REPORTES
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_CONSULTA_REPORTES' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_CONSULTA_REPORTES
go

/*

Autor			Claudia Alejandra Arredondo Rodríguez
UsuarioRed		AERC864420
Fecha			20191106
Objetivo		Obtener listas de reportes 
Proyecto		Banca Electrónica, División de Fraudes Electrónicos
Ticket			ticket

*/

CREATE PROC SP_BANCA_FRAUDES_CONSULTA_REPORTES 
  @Tipo        INT, -- 1 para administración de reportes, 2 para consulta de alertas atendidas, 3 reportes canalizados
  @FechaInicio DATETIME = NULL, 
  @FechaFin    DATETIME = NULL
-- parametros
-- [aquí van los parámetros]

AS
  BEGIN -- procedimiento

    BEGIN TRY -- try principal

      BEGIN -- inicio
        -- declaraciones
        DECLARE 
          @status          INT          = 1, 
          @error_message   VARCHAR(255) = '', 
          @error_line      VARCHAR(255) = '', 
          @error_severity  VARCHAR(255) = '', 
          @error_procedure VARCHAR(255) = '';
      END; -- inicio

      BEGIN -- ámbito de la actualización

        IF(@Tipo = 1)
          IF(@FechaInicio IS NULL
             AND @FechaFin IS NOT NULL)
            SELECT 
              *
            FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
            WHERE Fecha_Atencion <= @FechaFin;
          ELSE
            IF(@FechaFin IS NULL
               AND @FechaInicio IS NOT NULL)
              SELECT 
                *
              FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
              WHERE Fecha_Atencion >= @FechaInicio;
            ELSE
              IF(@FechaFin IS NULL
                 AND @FechaInicio IS NULL)
                SELECT 
                  *
                FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES;
              ELSE
                SELECT 
                  *
                FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                WHERE Fecha_Atencion BETWEEN @FechaInicio AND @FechaFin;
        ELSE
          IF(@Tipo = 2)
            IF(@FechaInicio IS NULL
               AND @FechaFin IS NOT NULL)
              SELECT 
                *
              FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
              WHERE Fecha_Atencion <= @FechaFin
                    AND Id_Canalizacion = 2;
            ELSE
              IF(@FechaFin IS NULL
                 AND @FechaInicio IS NOT NULL)
                SELECT 
                  *
                FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                WHERE Fecha_Atencion >= @FechaInicio
                      AND Id_Canalizacion = 2;
              ELSE
                IF(@FechaFin IS NULL
                   AND @FechaInicio IS NULL)
                  SELECT 
                    *
                  FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                  WHERE Id_Canalizacion = 2;
                ELSE
                  SELECT 
                    *
                  FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                  WHERE Fecha_Atencion BETWEEN @FechaInicio AND @FechaFin
                        AND Id_Canalizacion = 2;
          ELSE
            IF(@Tipo = 3)
              IF(@FechaInicio IS NULL
                 AND @FechaFin IS NOT NULL)
                SELECT 
                  *
                FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                WHERE Fecha_Atencion <= @FechaFin
                      AND Id_Canalizacion = 3;
              ELSE
                IF(@FechaFin IS NULL
                   AND @FechaInicio IS NOT NULL)
                  SELECT 
                    *
                  FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                  WHERE Fecha_Atencion >= @FechaInicio
                        AND Id_Canalizacion = 3;
                ELSE
                  IF(@FechaFin IS NULL
                     AND @FechaInicio IS NULL)
                    SELECT 
                      *
                    FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                    WHERE Id_Canalizacion = 3;
                  ELSE
                    SELECT 
                      *
                    FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                    WHERE Fecha_Atencion BETWEEN @FechaInicio AND @FechaFin
                          AND Id_Canalizacion = 3;
      END; -- ámbito de la actualización

    END TRY -- try principal

    BEGIN CATCH -- catch principal
      -- captura del error
      SELECT 
        @status = -ERROR_STATE(), 
        @error_procedure = COALESCE(ERROR_PROCEDURE(), 'CONSULTA DINÁMICA'), 
        @error_line = ERROR_LINE(), 
        @error_message = ERROR_MESSAGE(), 
        @error_severity = CASE ERROR_SEVERITY()
                            WHEN 11
                              THEN 'Error en validación'
                            WHEN 12
                              THEN 'Error en consulta'
                            WHEN 13
                              THEN 'Error en actualización'
                          ELSE 'Error general'
                          END;
    END CATCH; -- catch principal

    BEGIN -- reporte de estatus

      SELECT 
        @status STATUS, 
        @error_procedure error_procedure, 
        @error_line error_line, 
        @error_severity error_severity, 
        @error_message error_message;
    END; -- reporte de estatus

  END; -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDES_CONSULTA_REPORTES to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDES_CONTADOR_ALERTAS_ATENDIDAS_POR_ATENDER
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_CONTADOR_ALERTAS_ATENDIDAS_POR_ATENDER' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_CONTADOR_ALERTAS_ATENDIDAS_POR_ATENDER
go

/*
Autor			LAGM
UsuarioRed		GAML841262
Fecha			20190325
Objetivo		Obtener cuantas alertas  hacen falta por atender y cantas ya fueron atendidas 
Proyecto		Banca Eléctonica División de Fraudes Electrónicos
Ticket			ticket
*/

create proc	SP_BANCA_FRAUDES_CONTADOR_ALERTAS_ATENDIDAS_POR_ATENDER
		-- parámetros
		-- [aquí van los parámetros]
as
	begin -- procedimiento
		begin try -- try principal
		 begin -- inicio
			-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				declare
					@porAtender int=0,
					@Atendidas int =0,
					@Cerrdas int=0,
					@ValidacionErronea int = 0
				
			end -- inicio

			select @porAtender = COUNT (*) from  TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES WHERE Id_Canalizacion = 2
				 
                select @Atendidas = COUNT (*)  from  TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES WHERE Id_Canalizacion = 1
			
				select @Cerrdas= COUNT (*)   from  TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES WHERE Id_Canalizacion =  3

				select @ValidacionErronea = COUNT(*) from TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES WHERE Id_Canalizacion =  4
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
						
			
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,
					@porAtender as AlertasPorAtender,
					@Atendidas as AlertasAtendidas,
					@Cerrdas as cerradas,
					@ValidacionErronea as ValidacionErronea
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDES_CONTADOR_ALERTAS_ATENDIDAS_POR_ATENDER to public

use banca
go

-- se crea procedimiento SP_BANCA_FRAUDES_DEPURACION_ALERTAS_BAJA_SERVICIO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_DEPURACION_ALERTAS_BAJA_SERVICIO' and xtype = 'p' and db_name() = 'banca')
	drop proc SP_BANCA_FRAUDES_DEPURACION_ALERTAS_BAJA_SERVICIO
go

/*

Autor			LAGM
UsuarioRed		GAML841262
Fecha			20191011
Objetivo		Eliminar las alertas del socio cuando de baja el servicio de banca cuando son alertas no transaccionales
Proyecto		Modulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_DEPURACION_ALERTAS_BAJA_SERVICIO
	@Numero_Socio INT,
	@Num_usuario int 

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				declare	@tran_name varchar(32) = 'Elminar_alertas_No_Transaccionales',
						@tran_count int = @@trancount,
						@tran_scope bit = 0,
						@Id_cancelacion int,
						@descancelacion_Servico varchar(900)

			end -- inicio
						
			begin -- transacción

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio
				
				begin -- componente de la transacción
				
					delete  alerta		
					from TBL_BANCA_FRAUDE_ALERTA alerta 
					inner join TBL_BANCA_SOCIOS bsocios on bsocios.numero_socio = alerta.NUMERO_SOCIO
					where bsocios.banca_activa = 0
					and alerta.ID_TIPO_ALERTA in (3,4,7,8)
					and alerta.ID_ESTATUS = 1 
					and alerta.numero_socio = @Numero_Socio

					select @Id_cancelacion=id_Tipo_Bitacoras_fraudes, @descancelacion_Servico =Descripcion_Bitacoras_Fraudes
					from CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE
					where id_Tipo_Bitacoras_fraudes = 10
				
					insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES(Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus,usuario)
					select alerta.Numero_Socio,
						@Id_cancelacion,
						GETDATE(),
						@descancelacion_Servico,
						1,
						@Num_usuario
					from TBL_BANCA_FRAUDE_ALERTA alerta
					where alerta.NUMERO_SOCIO = @Numero_Socio
					group by Numero_Socio
				
				
				end -- componente de la transacción
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacción se inició dentro de este ámbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacción se inició dentro de este ámbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
						
			-- revertir transacción si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDES_DEPURACION_ALERTAS_BAJA_SERVICIO to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDES_LISTAR_ALERTAS_POR_TIPO_ALERTA
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_LISTAR_ALERTAS_POR_TIPO_ALERTA' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_LISTAR_ALERTAS_POR_TIPO_ALERTA
go

/*

Autor			Claudia Alejandra Arredondo Rodríguez
UsuarioRed		AERC864420
Fecha			20191106
Objetivo		Obtener la lista de las alertas de un determinado tipo de alerta, acorde al identificador
Proyecto		Banca Electrónica, División de Fraudes Electrónicos
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_LISTAR_ALERTAS_POR_TIPO_ALERTA
	@TipoAlerta int,
	@FechaInicio datetime = null,
	@FechaFin datetime = null


as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
									
				-- valores por defecto
				set @FechaInicio = CAST(coalesce(@FechaInicio,getdate())as date)
				set @FechaFin = CAST(coalesce(@FechaFin,getdate())+1 as date)
			
			end -- inicio
			
			begin -- ámbito de la actualización
			
				select * 
				from TBL_BANCA_FRAUDE_ALERTA alerta
					inner join CAT_BANCA_FRAUDE_TIPO_ALERTA talerta on alerta.ID_TIPO_ALERTA = talerta.ID_TIPO_ALERTA 
				where alerta.ID_TIPO_ALERTA = @TipoAlerta 
					and alerta.Fecha_Alerta between @FechaInicio and @FechaFin
					and alerta.ID_ESTATUS = 1
				
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDES_LISTAR_ALERTAS_POR_TIPO_ALERTA to public

USE BANCA
GO

-- se crea procedimiento SP_BANCA_FRAUDES_OBTENER_ALERTA_POR_NUMERO_SOCIO
/*IF EXISTS
(
    SELECT SP_BANCA_FRAUDES_OBTENER_ALERTA_POR_NUMERO_SOCIO
	 *
    FROM sysobjects
    WHERE NAME LIKE 'SP_BANCA_FRAUDES_OBTENER_ALERTA_POR_NUMERO_SOCIO'
		AND xtype = 'p'
		AND DB_NAME() = 'BANCA'
)
  BEGIN
    DROP PROC 
	 SP_BANCA_FRAUDES_OBTENER_ALERTA_POR_NUMERO_SOCIO
END
GO*/

if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_OBTENER_ALERTA_POR_NUMERO_SOCIO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_OBTENER_ALERTA_POR_NUMERO_SOCIO
go

/******************************************************
Autor			Sabdi Abraham Pantoja Orozco
UsuarioRed		paos845568
Fecha			3/Enero/2019
Objetivo		Obtener la alerta que bloquea a dicho usuario
Proyecto		Banca Fraudes
Ticket			ticket
******************************************************/

CREATE PROC SP_BANCA_FRAUDES_OBTENER_ALERTA_POR_NUMERO_SOCIO
-- parametros
  @numeroSocio INTEGER
-- [aquí van los parámetros]
AS
  BEGIN -- procedimiento
    BEGIN TRY -- try principal	
      BEGIN -- inicio
        -- declaraciones
        DECLARE 
          @status          INT          = 1, 
          @error_message   VARCHAR(255) = '', 
          @error_line      VARCHAR(255) = '', 
          @error_severity  VARCHAR(255) = '', 
          @error_procedure VARCHAR(255) = '';

        -- valores por defecto
      END; -- inicio

      BEGIN -- validaciones
        IF
        (
          SELECT 
            id_motivo_bloqueo
          FROM TBL_BANCA_SOCIOS
          WHERE numero_socio = @numeroSocio
        ) = 1
          BEGIN
            RAISERROR('Socio no se encuentra bloqueado', 11, 0);
        END;
      END; -- validaciones

      BEGIN -- ámbito de la actualización
        IF EXISTS
        (
          SELECT TOP 1 
            *
          FROM TBL_BANCA_FRAUDE_ALERTA AS alerta
               INNER JOIN hape..persona p ON alerta.numero_socio = p.Numero
          WHERE numero_socio = @numeroSocio
                AND id_tipo_alerta IN(1, 2, 5, 6)
               AND id_estatus = 1
        )
          SELECT TOP 1 
            *
          FROM TBL_BANCA_FRAUDE_ALERTA AS alerta
               INNER JOIN hape..persona p ON alerta.numero_socio = p.Numero
          WHERE numero_socio = @numeroSocio
                AND id_tipo_alerta IN(1, 2, 5, 6)
               AND id_estatus = 1;
        ELSE
          SELECT TOP 1 
            *
          FROM TBL_BANCA_FRAUDE_ALERTA AS alerta
               INNER JOIN hape..persona p ON alerta.numero_socio = p.Numero
          WHERE numero_socio = @numeroSocio
                AND id_estatus = 1;
      END; -- ámbito de la actualización
    END TRY -- try principal

    BEGIN CATCH -- catch principal
      -- captura del error
      SELECT 
        @status = -ERROR_STATE(), 
        @error_procedure = COALESCE(ERROR_PROCEDURE(), 'CONSULTA DINÁMICA'), 
        @error_line = ERROR_LINE(), 
        @error_message = ERROR_MESSAGE(), 
        @error_severity = CASE ERROR_SEVERITY()
                            WHEN 11
                              THEN 'Error en validación'
                            WHEN 12
                              THEN 'Error en consulta'
                            WHEN 13
                              THEN 'Error en actualización'
                          ELSE 'Error general'
                          END;
    END CATCH; -- catch principal
  END; -- procedimiento	
GO
GRANT EXEC ON SP_BANCA_FRAUDES_OBTENER_ALERTA_POR_NUMERO_SOCIO TO PUBLIC

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDES_OBTENER_MOVIMIENTOS_ALERTA
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_OBTENER_MOVIMIENTOS_ALERTA' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_OBTENER_MOVIMIENTOS_ALERTA
go

/*

Autor			Claudia Alejandra Arredondo Rodríguez
UsuarioRed		AERC864420
Fecha			20191122
Objetivo		Obtener los movimientos que generaron una alerta
Proyecto		Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_OBTENER_MOVIMIENTOS_ALERTA
	@numero_socio int,
	@folio_alerta int
	--@tipo_alerta int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						--@numero_socio int = 22910,
						--@folio_alerta int =  13851

				create table #trans (
					folio int,
					importe money,
					fecha_transaccion datetime,
					plataforma varchar(10),
					destino varchar(30),
					tipo_transferencia bit -- 0 internas, 1 externas
				)
							
			end -- inicio

			
			begin -- ámbito de la actualización 

				insert into #trans
				select movs.folio_movimiento, internas.monto, internas.fecha_transferencia_realizada, cat.descripcion,internas.clave_corresponsalias_destino, 0
				from tbl_banca_fraude_movimientos movs
					inner join tbl_banca_transferencias_internas internas on internas.id_banca_folio = movs.folio_movimiento
					inner join HAPE..MOVIMIENTOS hmov on hmov.Folio = internas.id_banca_folio and hmov.numero = @numero_socio
					inner join CAT_BANCA_ORIGEN_OPERACION cat on cat.id_origen_operacion = hmov.id_origen
				where internas.numero_socio = @numero_socio and movs.id_alerta = @folio_alerta

				union

				select movs.folio_movimiento, ext.monto, ext.fecha_transferencia_realizada, cat.descripcion, ext.clabe_spei_destino, 1
				from tbl_banca_fraude_movimientos movs
					inner join TBL_BANCA_TRANSFERENCIAS_EXTERNAS ext on ext.id_banca_folio = movs.folio_movimiento
					inner join HAPE..MOVIMIENTOS hmov on hmov.Folio = ext.id_banca_folio and hmov.numero = @numero_socio
					inner join CAT_BANCA_ORIGEN_OPERACION cat on cat.id_origen_operacion = hmov.id_origen
				where ext.numero_socio = @numero_socio and movs.id_alerta = @folio_alerta

				select @status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,
					@numero_socio numero_socio,
					* from #trans

				drop table #trans					
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
				
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDES_OBTENER_MOVIMIENTOS_ALERTA to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDES_OBTENER_PARAMETROS_ALERTAS
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_OBTENER_PARAMETROS_ALERTAS' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_OBTENER_PARAMETROS_ALERTAS
go

/*

Autor			Claudia Alejandra Arredondo Rodríguez
UsuarioRed		AERC864420
Fecha			20191108
Objetivo		Obtener los parámetros configurados para las alertas mediante un ID
Proyecto		Banca Electrónica, División Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_OBTENER_PARAMETROS_ALERTAS
	@Id_par int --ID_ alerta

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
				
			end -- inicio
			
			begin -- ámbito de la actualización
			
				if(@Id_par = -1)
					select	@status status,
					* from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS
					where Id_parametro in (3, 4, 5)
				else if ((select count(Id_parametro) from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where Id_parametro = @Id_par) > 0)
					select	@status status,
					* from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS
					where Id_parametro = @Id_par
				else
					select 0 status
				
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDES_OBTENER_PARAMETROS_ALERTAS to public

use hape
go

-- se crea procedimiento SP_BANCA_FRAUDES_REVISA_USUARIO_ACTIVO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_REVISA_USUARIO_ACTIVO' and xtype = 'p' and db_name() = 'hape')
	drop proc SP_BANCA_FRAUDES_REVISA_USUARIO_ACTIVO
go

/*

Autor			Luis Arturo Gálvez Macias 
UsuarioRed		GAML841262
Fecha			20190408
Objetivo		Revisar los usuario activos en el modulo de banca fraudes
Proyecto		Banca ElectrÑnica DivisiÑn de Fruades EletrÑnicos
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_REVISA_USUARIO_ACTIVO
	@numusuario int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
			
			end -- inicio
			
			begin -- ámbito de la actualización
			
				select	cls.Numusuario,coalesce(accesousuario.Activo,0) as Activo, @status status
				from	hape..CLAVES  cls
						left join BANCA.dbo.TBL_BANCA_FRAUDES_ACCESO_USUARIO accesousuario
							on cls.Id_Rol = accesousuario.Id_Rol and accesousuario.Activo = 1
				where	numusuario = @numusuario 
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDES_REVISA_USUARIO_ACTIVO to public

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDES_VER_SOCIOS_ALERTADOS_NOTIFICACION
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_VER_SOCIOS_ALERTADOS_NOTIFICACION' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_VER_SOCIOS_ALERTADOS_NOTIFICACION
go

/*

Autor			Luis Arturo Gálvez Macias
UsuarioRed		gaml841262
Fecha			20191004
Objetivo		ver los socios que necesitan ser notificados del bloqueo de sus cuentas
Proyecto		Modulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_VER_SOCIOS_ALERTADOS_NOTIFICACION
	
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''

			end -- inicio
			
			begin -- ámbito de la actualización
			
				select	distinct 
					@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,				 
					Alerta.Numero_socio,
					P.Nombre_s+''+P.Apellido_Paterno+''+Apellido_Materno as Nombre_Socio,
					P.Tel_celular,
					P.Mail,
					contrato.id_tipo_notificacion,
					1 as Id_Tipo_Bitacoras_Fraudes,
					bitaope.Id_Bitacora_Fraude
				from Tbl_banca_fraude_alerta alerta
					inner join hape..PERSONA P on P.numero=alerta.numero_Socio
					inner join BANCA..TBL_BANCA_SOCIOS bsocios on bsocios.numero_socio = alerta.NUMERO_SOCIO
					inner join HAPE..TBL_CONTRATOS_HABERES contrato on alerta.numero_socio = contrato.numero
					inner join BANCA..TBL_BANCA_FRAUDE_BITACORA_OPERACIONES bitaope on bitaope.Numero_Socio = alerta.NUMERO_SOCIO
				where contrato.id_tipo_contrato = 3 
					and contrato.id_tipo_persona = 1 
					and bsocios.banca_activa = 1
					and bsocios.id_motivo_bloqueo in (13,14)
					and alerta.id_estatus = 1
					and P.Id_Tipo_Persona = 1
					and id_tipo_notificacion is not null
					and bitaope.usuario is null
					and alerta.id_tipo_alerta in (1,2,5,6)	
				group by alerta.NUMERO_SOCIO,P.Nombre_s,P.Apellido_Paterno,Apellido_Materno,P.Tel_celular,P.Mail,contrato.id_tipo_notificacion,bitaope.Id_Bitacora_Fraude
	
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDES_VER_SOCIOS_ALERTADOS_NOTIFICACION to public



