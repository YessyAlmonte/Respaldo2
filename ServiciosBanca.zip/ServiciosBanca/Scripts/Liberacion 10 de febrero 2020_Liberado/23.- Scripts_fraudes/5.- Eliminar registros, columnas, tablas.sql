use BANCA
go

delete  CAT_BANCA_FRAUDE_MOTIVO_CIERRE where id_motivo = 1
go
