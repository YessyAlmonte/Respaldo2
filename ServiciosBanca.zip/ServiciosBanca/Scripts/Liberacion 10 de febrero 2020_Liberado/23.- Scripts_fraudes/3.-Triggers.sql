USE BANCA
GO

--Trigger Transferencia interna
CREATE TRIGGER AlertaRecurrente
    ON [BANCA].dbo.[TBL_BANCA_TRANSFERENCIAS_INTERNAS]
    AFTER INSERT
    AS
    BEGIN
    SET NOCOUNT ON

	    declare @numero_socio int

		select @numero_socio=numero_socio from BANCA.dbo.TBL_BANCA_TRANSFERENCIAS_INTERNAS 
        where id_transferencia=(select max(id_transferencia) from TBL_BANCA_TRANSFERENCIAS_INTERNAS)
		
		EXEC SP_BANCA_FRAUDE_ALERTA_RECURRENTE @numero_socio
    END

GO

--Trigger Transferencia externa
CREATE TRIGGER AlertaRecurrenteExterna
    ON [BANCA].dbo.[TBL_BANCA_TRANSFERENCIAS_EXTERNAS]
    AFTER INSERT
    AS
    BEGIN
    SET NOCOUNT ON

	    declare @numero_socio int

		select @numero_socio=numero_socio from BANCA.dbo.TBL_BANCA_TRANSFERENCIAS_EXTERNAS 
        where id_transferencia=(select max(id_transferencia) from TBL_BANCA_TRANSFERENCIAS_EXTERNAS)
		
		EXEC SP_BANCA_FRAUDE_ALERTA_RECURRENTE @numero_socio
    END
