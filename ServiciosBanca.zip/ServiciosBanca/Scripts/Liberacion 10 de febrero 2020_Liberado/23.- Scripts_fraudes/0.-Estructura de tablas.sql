use BANCA
go

-- se crea tabla TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR
if exists (select * from sysobjects where name like 'TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR

create table
	TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR
		(
		id	bigint identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR primary key clustered not null, -- llave primaria
		numero_socio int
		)

grant select, insert, update, delete on TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR to public

use BANCA
go

-- se crea tabla CAT_BANCA_TIPOS_BITACORAS_FRAUDES
if exists (select * from sysobjects where name like 'CAT_BANCA_TIPOS_BITACORAS_FRAUDES' and xtype = 'u' and db_name() = 'BANCA')
	drop table CAT_BANCA_TIPOS_BITACORAS_FRAUDES

create table
		CAT_BANCA_TIPOS_BITACORAS_FRAUDES
		(
		   Id_Tipo_Bitacoras_Fraudes int identity (1, 1) constraint PK_CAT_BANCA_TIPOS_BITACORAS_FRAUDES primary key clustered not null, -- llave primaria
		   Descripción_Bitacora_Fraude varchar(255)
		)
grant select, insert, update, delete on CAT_BANCA_TIPOS_BITACORAS_FRAUDES to public

use BANCA
go
-- se crea catálogo CAT_BANCA_FRAUDE_ESTATUS_NOTIFICACION
if exists (select * from sysobjects where name like 'CAT_BANCA_FRAUDE_ESTATUS_NOTIFICACION' and xtype = 'u' and db_name() = 'BANCA')
	drop table CAT_BANCA_FRAUDE_ESTATUS_NOTIFICACION

create table
		 CAT_BANCA_FRAUDE_ESTATUS_NOTIFICACION
		(
		IdEstatusNotificacion	int identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_ESTATUS_NOTIFICACION primary key clustered not null, -- llave primaria
		Descripcion varchar(500)
		)

grant select, insert, update, delete on CAT_BANCA_FRAUDE_ESTATUS_NOTIFICACION to public

use BANCA
go

-- se crea catálogo CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE
if exists (select * from sysobjects where name like 'CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE' and xtype = 'u' and db_name() = 'BANCA')
	drop table CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE

	create table
		CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE
		(
		id_Tipo_Bitacoras_fraudes	int identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE primary key clustered not null, -- llave primaria
		Descripcion_Bitacoras_Fraudes varchar(max)
		)

grant select, insert, update, delete on CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE to public

use banca
go

-- se crea catálogo CAT_BANCA_FRAUDES_ESTATUS
if exists (select * from sysobjects where name like 'CAT_BANCA_FRAUDES_ESTATUS' and xtype = 'u' and db_name() = 'banca')
	drop table CAT_BANCA_FRAUDES_ESTATUS

create table
	CAT_BANCA_FRAUDES_ESTATUS
		(
		id_estatus	int identity (1, 1) constraint PK_TBL_BANCA_FRAUDES_ESTATUS primary key clustered not null, -- llave primaria
		descripcion varchar(100)
		)

grant select, insert, update, delete on CAT_BANCA_FRAUDES_ESTATUS to public

use BANCA
go

-- se crea catálogo CAT_BANCA_FRAUDE_MOTIVO_CIERRE
if exists (select * from sysobjects where name like 'CAT_BANCA_FRAUDE_MOTIVO_CIERRE' and xtype = 'u' and db_name() = 'BANCA')
	drop table CAT_BANCA_FRAUDE_MOTIVO_CIERRE

create table
	CAT_BANCA_FRAUDE_MOTIVO_CIERRE
		(
		id_motivo	int identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_MOTIVO_CIERRE primary key clustered not null, -- llave primaria
		Motivos varchar(255)
		)

grant select, insert, update, delete on CAT_BANCA_FRAUDE_MOTIVO_CIERRE to public

use BANCA
go

-- se crea catálogo CAT_BANCA_FRAUDE_TIPO_ALERTA
if exists (select * from sysobjects where name like 'CAT_BANCA_FRAUDE_TIPO_ALERTA' and xtype = 'u' and db_name() = 'BANCA')
	drop table CAT_BANCA_FRAUDE_TIPO_ALERTA

create table
	CAT_BANCA_FRAUDE_TIPO_ALERTA
		(
		id_tipo_alerta	int identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_TIPO_ALERTA primary key clustered not null, -- llave primaria
		descripcion varchar(255)
		)

grant select, insert, update, delete on CAT_BANCA_FRAUDE_TIPO_ALERTA to public

use BANCA
go

-- se crea catálogo CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE
if exists (select * from sysobjects where name like 'CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE' and xtype = 'u' and db_name() = 'BANCA')
	drop table CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE

create table
	CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE
		(
		id_alerta_recurrente	int identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE primary key clustered not null, -- llave primaria
		descripcion varchar(255)
		)

grant select, insert, update, delete on CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE to public

use BANCA
go

-- se crea catálogo CAT_BANCA_FRAUDE_ALERTAS_CANALIZADOS_CERRADOS
if exists (select * from sysobjects where name like 'CAT_BANCA_FRAUDE_ALERTAS_CANALIZADOS_CERRADOS' and xtype = 'u' and db_name() = 'BANCA')
	drop table CAT_BANCA_FRAUDE_ALERTAS_CANALIZADOS_CERRADOS

create table
	CAT_BANCA_FRAUDE_ALERTAS_CANALIZADOS_CERRADOS
		(
		id_canalizacion	int identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_ALERTAS_CANALIZADOS_CERRADOS primary key clustered not null, -- llave primaria
		estatus_canalización varchar(50)
		)

grant select, insert, update, delete on CAT_BANCA_FRAUDE_ALERTAS_CANALIZADOS_CERRADOS to public

use BANCA
go

-- se crea tabla TBL_BANCA_FRAUDES_ACCESO_USUARIO
if exists (select * from sysobjects where name like 'TBL_BANCA_FRAUDES_ACCESO_USUARIO' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_FRAUDES_ACCESO_USUARIO

create table
	TBL_BANCA_FRAUDES_ACCESO_USUARIO
		(
		id_acceso_usuario	bigint identity (1, 1) constraint PK_TBL_BANCA_FRAUDES_ACCESO_USUARIO primary key clustered not null, -- llave primaria
		id_rol int,
		activo bit,
		fechaAlta	datetime,
		numUsuario_alta int
		)

grant select, insert, update, delete on TBL_BANCA_FRAUDES_ACCESO_USUARIO to public

use BANCA
go

-- se crea tabla TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS
if exists (select * from sysobjects where name like 'TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS

create table
	TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS
		(
		id_parametro	bigint identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS primary key clustered not null, -- llave primaria
		valor money,
		tipo varchar(200),
		nombre_parametro varchar(255)
		)

grant select, insert, update, delete on TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS to public

use BANCA
go
-- se crea tabla TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PARAMETROS
	if exists (select * from sysobjects where name like 'TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PARAMETROS' and xtype = 'u' and db_name() = 'BANCA')
		drop table TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PARAMETROS

	create table
		TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PARAMETROS
		(
			Id_Actualizacion bigint identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PARAMETROS primary key clustered not null, -- llave primaria
			Valor float not null,
			Nombre_Parametro varchar(255)not null,
			Fecha_Actualizacion datetime not null,
			numero_usuario int not null
		)
grant select, insert, update, delete on TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PARAMETROS to public

use BANCA
go

-- se crea tabla TBL_BANCA_FRAUDE_ALERTA
if exists (select * from sysobjects where name like 'TBL_BANCA_FRAUDE_ALERTA' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_FRAUDE_ALERTA

create table
	TBL_BANCA_FRAUDE_ALERTA
		(
		folio_alerta	bigint identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_ALERTA primary key clustered not null, -- llave primaria
		fecha_alerta datetime,
		numero_socio int,
		id_tipo_alerta int constraint FK_TBL_BANCA_FRAUDE_ALERTA_CAT_BANCA_FRAUDE_TIPO_ALERTA FOREIGN KEY (id_tipo_alerta) references CAT_BANCA_FRAUDE_TIPO_ALERTA(id_tipo_alerta),
		id_alerta_recurrente int constraint FK_TBL_BANCA_FRAUDE_ALERTA_CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE foreign key (id_alerta_recurrente) references CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE (id_alerta_recurrente),
		id_estatus int  constraint FK_TBL_BANCA_FRAUDE_ALERTA_CAT_BANCA_FRAUDES_ESTATUS foreign key (id_estatus) references CAT_BANCA_FRAUDES_ESTATUS (ID_ESTATUS),
		id_notificacion bit,
		tipo_recurrente int -- 1 excede numero de retiros, 2 excede monto, 3 ambos
		)

grant select, insert, update, delete on TBL_BANCA_FRAUDE_ALERTA to public

use BANCA
go

-- se crea tabla TBL_BANCA_FRAUDE_MOVIMIENTOS
if exists (select * from sysobjects where name like 'TBL_BANCA_FRAUDE_MOVIMIENTOS' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_FRAUDE_MOVIMIENTOS

create table
	TBL_BANCA_FRAUDE_MOVIMIENTOS
		(
		id_movimiento	bigint identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_MOVIMIENTOS primary key clustered not null, -- llave primaria
		folio_movimiento int,
		id_alerta int,
		numero int,
		fecha_movimiento datetime,
		--id_tipomov int,
		id_tipo_alerta int constraint FK_TBL_BANCA_FRAUDE_MOVIMIENTOS_CAT_BANCA_FRAUDE_TIPO_ALERTA foreign key (id_tipo_alerta) references CAT_BANCA_FRAUDE_TIPO_ALERTA (id_tipo_alerta)
		)

grant select, insert, update, delete on TBL_BANCA_FRAUDE_MOVIMIENTOS to public

use BANCA
go

-- se crea tabla TBL_BANCA_FRAUDE_BITACORA_OPERACIONES
if exists (select * from sysobjects where name like 'TBL_BANCA_FRAUDE_BITACORA_OPERACIONES' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_FRAUDE_BITACORA_OPERACIONES

create table
	TBL_BANCA_FRAUDE_BITACORA_OPERACIONES
		(
			Id_Bitacora_Fraude	bigint identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_BITACORA_OPERACIONES primary key clustered not null, -- llave primaria
			Numero_Socio int not null,
			Id_Tipo_Bitacoras_Fraudes int  constraint FK_TBL_BANCA_FRAUDE_BITACORA_OPERACIONES_CAT_banca_fraude_tipos_bitacora_fraude foreign key references CAT_banca_fraude_tipos_bitacora_fraude (id_Tipo_Bitacoras_fraudes),
			Fecha_alta datetime not null,
			Evento varchar (900) not null,
			Estatus int not null, 
			usuario int
		)

grant select, insert, update, delete on TBL_BANCA_FRAUDE_BITACORA_OPERACIONES to public

USE BANCA
go
-- se crea tabla TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
if exists (select * from sysobjects where name like 'TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES

create  table  TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
		(
		id_folio_reporte  int identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES primary key clustered not null, -- llave primaria,
		Folio_Alerta bigint constraint FK_TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES_TBL_BANCA_FRAUDE_ALERTA foreign key references TBL_BANCA_FRAUDE_ALERTA (folio_alerta),
		Numero_Socio int not null,
		Nombre_Socio varchar(255) not null,
		Id_Canalizacion	int constraint FK_TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES_CAT_BANCA_FRAUDES_ALERTAS_CANALIZADOS_CERRADOS foreign key references CAT_BANCA_FRAUDE_ALERTAS_CANALIZADOS_CERRADOS (Id_Canalizacion) null,
		Motivo	int constraint FK_TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES_CAT_BANCA_FRAUDE_MOTIVO_CIERRE foreign key references CAT_BANCA_FRAUDE_MOTIVO_CIERRE (Id_Motivo) null,
		Anotaciones varchar(8000)not null,
		Fecha_Atencion datetime,
		Numero_usuario int not null
		)
grant select, insert, update, delete on TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES to public

use BANCA
go

-- se crea tabla TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL
if exists (select * from sysobjects where name like 'TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL

create table
	TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL
		(
			Id_actulizacion_perfil	bigint identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL primary key clustered not null, -- llave primaria
			Numero_Socio varbinary(MAX) not null,
			Monto_Acumulado float not null,
			Numero_Operaciones int not null,
			Fecha_Actulizacion datetime not null,
			Numero_Usuario int 
		)

grant select, insert, update, delete on TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL to public


/*
 Tabla  para llevar control de los socios alertados  y por alertar
*/
use BANCA
go

-- se crea tabla TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO
if exists (select * from sysobjects where name like 'TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO

create table
	TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO
		(
		id	bigint identity (1, 1) constraint PK_TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO primary key clustered not null, -- llave primaria
		Numero_Socio int not null,
		Nombre_Socio varchar(255)  not null,
		Tel_Celular varchar(10)  not null,
		Email varchar(255) not null,
		Id_tipo_notificacion int not null,
		Id_Tipo_Bitacoras_Fraudes int constraint FK_TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO_CAT_banca_fraude_tipos_bitacora_fraude foreign key references CAT_banca_fraude_tipos_bitacora_fraude (Id_Tipo_Bitacoras_Fraudes),
		Id_bitacora_fraude int, --Modificación del 16 de Oct para ver  el folio de la  bitacora 
		Notificacion_sms int default 0,
		Notificacion_Email int default 0,
		)

grant select, insert, update, delete on TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO to public

use BANCA
go
-- se crea tabla TBL_BANCA_FRAUDES_NOTIFICACIONES_SMS
if exists (select * from sysobjects where name like 'TBL_BANCA_FRAUDES_NOTIFICACIONES_SMS' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_FRAUDES_NOTIFICACIONES_SMS

create table
	TBL_BANCA_FRAUDES_NOTIFICACIONES_SMS
		(
			id_Notificacion	bigint identity (1, 1) constraint PK_TBL_BANCA_FRAUDES_NOTIFICACIONES_SMS primary key clustered not null, -- llave primaria
			Id_Tipo_Bitacoras_Fraudes int constraint FK_TBL_BANCA_FRAUDES_NOTIFICACIONES_SMS_CAT_BANCA_TIPOS_BITACORAS_FRAUDES foreign key references CAT_BANCA_TIPOS_BITACORAS_FRAUDES (Id_Tipo_Bitacoras_Fraudes),
			cuerpo varchar(max) not null,
			Fecha_alta datetime not null,
			Activo int not null
		)

grant select, insert, update, delete on TBL_BANCA_FRAUDES_NOTIFICACIONES_SMS to public

use BANCA
go

-- se crea tabla TBL_BANCA_FRAUDE_NOTIFICACION_CORREO
if exists (select * from sysobjects where name like 'TBL_BANCA_FRAUDE_NOTIFICACION_CORREO' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_FRAUDE_NOTIFICACION_CORREO

create table
		TBL_BANCA_FRAUDE_NOTIFICACION_CORREO
			(
				Id_Notificacion	bigint identity (1, 1) constraint PK_TBL_BANCA_FRAUDE_NOTIFICACION_CORREO primary key clustered not null, -- llave primaria
				Id_Tipo_Bitacoras_Fraudes int constraint FK_TBL_BANCA_FRAUDE_NOTIFICACION_CORREO_CAT_BANCA_TIPOS_BITACORAS_FRAUDES foreign key references CAT_BANCA_TIPOS_BITACORAS_FRAUDES (Id_Tipo_Bitacoras_Fraudes),
				asunto varchar(255) not null,
				cuerpo varchar(max) not null,
				Fecha_Alta datetime not null,
				activo int not null
			)

grant select, insert, update, delete on TBL_BANCA_FRAUDE_NOTIFICACION_CORREO to public

use BANCA
go

-- se crea tabla TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS
if exists (select * from sysobjects where name like 'TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS

create table
	TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS
		(
			Id_Notificacion_Desbloqueo	bigint identity (1, 1) constraint PK_TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS primary key clustered not null, -- llave primaria
			Id_Motivo_Bloqueo INT NOT NULL,
			Numero_Socio int not null,
			Nombre_Socio varchar(500),
			Tel_Celular varchar(255),
			Mail varchar(500),
			Id_tipo_notificacion int constraint FK_TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS_CAT_BANCA_TIPO_NOTIFICACION foreign key references CAT_BANCA_TIPO_NOTIFICACION (Id_tipo_notificacion),
			Id_Tipo_Bitacoras_Fraudes int default 2 constraint FK_TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS_CAT_BANCA_TIPOS_BITACORAS_FRAUDES foreign key references CAT_BANCA_TIPOS_BITACORAS_FRAUDES (Id_Tipo_Bitacoras_Fraudes),
			NotificacionSMS int default 0,
			Notificacion_Email int default 0
		)

grant select, insert, update, delete on TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS to public


--Constraint de TABLAS

use BANCA
-------------------------------------------------
---Eliminar indices
-------------------------------------------------

if exists (select 1 from sysindexes where name = 'IX_TBL_BANCA_FRAUDE_ALERTA_numero_socio')
	   drop index TBL_BANCA_FRAUDE_ALERTA.IX_TBL_BANCA_FRAUDE_ALERTA_numero_socio

if exists (select 1 from sysindexes where name = 'IX_TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO_numero_socio')
   drop index TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO.IX_TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO_numero_socio

-------------------------------------------------
---Eliminar llaves foraneas
-------------------------------------------------

--- tabla TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
if exists (select * from sysobjects where name like 'FK_TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES_CAT_BANCA_FRAUDE_MOTIVO_CIERRE' and xtype = 'F')
	alter table TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES drop constraint FK_TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES_CAT_BANCA_FRAUDE_MOTIVO_CIERRE

if exists (select * from sysobjects where name like 'FK_TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES_CAT_BANCA_FRAUDES_ALERTAS_CANALIZADOS_CERRADOS' and xtype = 'F')
	alter table TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES drop constraint FK_TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES_CAT_BANCA_FRAUDES_ALERTAS_CANALIZADOS_CERRADOS

--- TBL_BANCA_FRAUDE_ALERTA
if exists (select * from sysobjects where name like 'FK_TBL_BANCA_FRAUDE_ALERTA_CAT_BANCA_FRAUDE_ESTATUS' and xtype = 'F')
	alter table TBL_BANCA_FRAUDE_ALERTA drop constraint FK_TBL_BANCA_FRAUDE_ALERTA_CAT_BANCA_FRAUDE_ESTATUS	

if exists (select * from sysobjects where name like 'FK_TBL_BANCA_FRAUDE_ALERTA_CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE' and xtype = 'F')
	alter table TBL_BANCA_FRAUDE_ALERTA drop constraint FK_TBL_BANCA_FRAUDE_ALERTA_CAT_BANCA_FRAUDE_TIPO_ALERTA_RECURRENTE

if exists (select * from sysobjects where name like 'FK_TBL_BANCA_FRAUDE_ALERTA_CAT_BANCA_FRAUDE_TIPO_ALERTA' and xtype = 'F') 
	alter table TBL_BANCA_FRAUDE_ALERTA drop constraint FK_TBL_BANCA_FRAUDE_ALERTA_CAT_BANCA_FRAUDE_TIPO_ALERTA

if exists (select * from sysobjects where name like 'FK_TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO_CAT_banca_fraude_tipos_bitacora_fraude' and xtype = 'F')
	alter table TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO drop constraint FK_TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO_CAT_banca_fraude_tipos_bitacora_fraude

if exists (select * from sysobjects where name like 'FK_TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS_CAT_BANCA_TIPOS_BITACORAS_FRAUDES' and xtype = 'F')
	alter table TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS drop constraint FK_TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS_CAT_BANCA_TIPOS_BITACORAS_FRAUDES

if exists (select * from sysobjects where name like 'FK_TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS_CAT_BANCA_TIPO_NOTIFICACION' and xtype = 'F')
	alter table TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS drop constraint FK_TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS_CAT_BANCA_TIPO_NOTIFICACION

if exists (select * from sysobjects where name like 'FK_TBL_BANCA_FRAUDE_BITACORA_OPERACIONES_CAT_banca_fraude_tipos_bitacora_fraude' and xtype = 'F')
	alter table TBL_BANCA_FRAUDE_BITACORA_OPERACIONES drop constraint FK_TBL_BANCA_FRAUDE_BITACORA_OPERACIONES_CAT_banca_fraude_tipos_bitacora_fraude

if exists (select * from sysobjects where name like 'FK_TBL_BANCA_FRAUDE_MOVIMIENTOS_CAT_BANCA_FRAUDE_TIPO_ALERTA' and xtype = 'F')
	alter table TBL_BANCA_FRAUDE_MOVIMIENTOS drop constraint FK_TBL_BANCA_FRAUDE_MOVIMIENTOS_CAT_BANCA_FRAUDE_TIPO_ALERTA

if exists (select * from sysobjects where name like 'FK_TBL_BANCA_FRAUDE_SOCIOS_CAT_BANCA_FRAUDE_TIPO_ALERTA' and xtype = 'F')
	alter table TBL_BANCA_FRAUDE_SOCIOS drop constraint FK_TBL_BANCA_FRAUDE_SOCIOS_CAT_BANCA_FRAUDE_TIPO_ALERTA

if exists (select * from sysobjects where name like 'FK_TBL_BANCA_FRAUDE_NOTIFICACION_CORREO_CAT_BANCA_TIPOS_BITACORAS_FRAUDES' and xtype = 'F')
	alter table TBL_BANCA_FRAUDE_NOTIFICACION_CORREO drop constraint FK_TBL_BANCA_FRAUDE_NOTIFICACION_CORREO_CAT_BANCA_TIPOS_BITACORAS_FRAUDES

if exists (select * from sysobjects where name like 'FK_TBL_BANCA_FRAUDES_NOTIFICACIONES_SMS_CAT_BANCA_TIPOS_BITACORAS_FRAUDES' and xtype = 'F')
	alter table TBL_BANCA_FRAUDES_NOTIFICACIONES_SMS drop constraint FK_TBL_BANCA_FRAUDES_NOTIFICACIONES_SMS_CAT_BANCA_TIPOS_BITACORAS_FRAUDES

