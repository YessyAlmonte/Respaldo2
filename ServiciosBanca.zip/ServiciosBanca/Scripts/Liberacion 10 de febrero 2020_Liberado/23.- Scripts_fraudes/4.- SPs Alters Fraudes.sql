USE BANCA
GO
-- se crea procedimiento SP_BANCA_FRAUDE_ACTUALIZAICION_PERFIL_TRANSACCIONAL
IF EXISTS (SELECT * FROM sysobjects WHERE NAME LIKE 'SP_BANCA_FRAUDE_ACTUALIZACION_PERFIL_TRANSACCIONAL' AND xtype = 'p' AND db_name() = 'BANCA')
    DROP PROC SP_BANCA_FRAUDE_ACTUALIZACION_PERFIL_TRANSACCIONAL
GO
/*
Autor           Sabdi Abraham Pantoja Orozco
UsuarioRed      paos845568
Fecha           04/Diciembre/2019
Objetivo        Actualizar perfil transaccional de un socio
Proyecto        Banca/Fraudes
Ticket          ticket
*/
CREATE PROC
    SP_BANCA_FRAUDE_ACTUALIZACION_PERFIL_TRANSACCIONAL
    @numero_socio int,
    @folio_alerta int,
    --@numero_operacion int,
    @numero_usuario int
AS
    BEGIN -- procedimiento  
        BEGIN TRY -- try principal
            BEGIN -- inicio
                DECLARE 
                    @status INT = 1,
                    @error_message VARCHAR(255) = '',
                    @error_line VARCHAR(255) = '',
                    @error_severity VARCHAR(255) = '',
                    @error_procedure VARCHAR(255) = '',
					@tipo_recurrente int,
					@monto_max money,
					@numero_movs int,
					@monto money
                        
                DECLARE 
                    @tran_name VARCHAR(32) = 'ACTUALIZACION_PERFIL_TRANSACCIONAL',
                    @tran_count INT = @@trancount,
                    @tran_scope BIT = 0,
                    @Fecha_Actualizacion DATETIME = GETDATE()
            END -- inicio
            
            BEGIN -- transacci�n
                BEGIN -- inicio
                    IF @tran_count = 0
                        BEGIN tran @tran_name
                    ELSE
                        SAVE tran @tran_name
                
                    SELECT @tran_scope = 1
                END -- inicio
                
                BEGIN -- componente de la transacci�n

					set @tipo_recurrente = (select tipo_recurrente from TBL_BANCA_FRAUDE_ALERTA where folio_alerta = @folio_alerta and numero_socio = @numero_socio)
					if(@tipo_recurrente = 1)
						begin
							set @numero_movs = (select Numero_Operaciones from TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL where BANCA.dbo.FN_BANCA_DESCIFRAR(Numero_Socio) = @numero_socio) + (select valor from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where id_parametro = 7 )
							set @monto_max = (select Monto_Acumulado from TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL where BANCA.dbo.FN_BANCA_DESCIFRAR(Numero_Socio) = @numero_socio)
						end
					else if(@tipo_recurrente = 2)
						begin
							set @numero_movs = (select Numero_Operaciones from TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL where BANCA.dbo.FN_BANCA_DESCIFRAR(Numero_Socio) = @numero_socio)
							set @monto_max = (SELECT SUM(CAST(monto AS money)) FROM (
																SELECT externas.monto FROM TBL_BANCA_FRAUDE_MOVIMIENTOS mov
																INNER JOIN  TBL_BANCA_TRANSFERENCIAS_EXTERNAS  externas ON externas.id_banca_folio = mov.folio_movimiento
																WHERE mov.id_ALERTA = @folio_alerta
																UNION ALL
																SELECT internas.monto FROM TBL_BANCA_FRAUDE_MOVIMIENTOS mov
																INNER JOIN  TBL_BANCA_TRANSFERENCIAS_INTERNAS  internas ON internas.id_banca_folio = mov.folio_movimiento
																WHERE mov.id_ALERTA = @folio_alerta
															) AS monto)
						end
					else
						begin
							set @numero_movs = (select Numero_Operaciones from TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL where BANCA.dbo.FN_BANCA_DESCIFRAR(Numero_Socio) = @numero_socio) + (select valor from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS where id_parametro = 7 )
							set @monto_max = (SELECT SUM(CAST(monto AS DECIMAL)) FROM (
																SELECT externas.monto FROM TBL_BANCA_FRAUDE_MOVIMIENTOS mov
																INNER JOIN  TBL_BANCA_TRANSFERENCIAS_EXTERNAS  externas ON externas.id_banca_folio = mov.folio_movimiento
																WHERE mov.id_ALERTA = @folio_alerta
																UNION ALL
																SELECT internas.monto FROM TBL_BANCA_FRAUDE_MOVIMIENTOS mov
																INNER JOIN  TBL_BANCA_TRANSFERENCIAS_INTERNAS  internas ON internas.id_banca_folio = mov.folio_movimiento
																WHERE mov.id_ALERTA = @folio_alerta
															) AS monto)
						end
                
                    UPDATE banca..TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL 
                    SET 
                        Monto_Acumulado = @monto_max, 
                        Numero_Operaciones = @numero_movs, 
                        Fecha_Actulizacion = @Fecha_Actualizacion
                    FROM TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL 
                    WHERE 
                        BANCA.dbo.FN_BANCA_DESCIFRAR(Numero_Socio) = @numero_socio
                
                END -- componente de la transacci�n
                
                BEGIN -- commit             
                    IF @tran_count = 0
                        BEGIN -- si la transacci�n se inici� dentro de este �mbito
                            COMMIT TRAN @tran_name
                            SELECT @tran_scope = 0
                        END -- si la transacci�n se inici� dentro de este �mbito
                END -- commit
            END
        END TRY -- try principal
    
        BEGIN catch -- catch principal      
            -- captura del error
            SELECT  @status = -error_state(),
                    @error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
                    @error_line = error_line(),
                    @error_message = error_message(),
                    @error_severity =
                        CASE error_severity()
                            WHEN 11 THEN 'Error en validaci�n'
                            WHEN 12 THEN 'Error en consulta'
                            WHEN 13 THEN 'Error en actualizaci�n'
                            ELSE 'Error general'
                        END
            -- revertir transacci�n si es necesario
            IF @tran_scope = 1
                ROLLBACK TRAN @tran_name
        END CATCH -- catch principal
        
        BEGIN -- reporte de status
            SELECT  @status STATUS,
                    @error_procedure error_procedure,
                    @error_line error_line,
                    @error_severity error_severity,
                    @error_message error_message
        END -- reporte de status
    END -- procedimiento
GO
GRANT EXEC ON SP_BANCA_FRAUDE_ACTUALIZACION_PERFIL_TRANSACCIONAL TO PUBLIC
go

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_ALERTA_ANZUELO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_ALERTA_ANZUELO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_ALERTA_ANZUELO
go

/*

Autor			Claudia Alejandra Arredondo Rodr�guez
UsuarioRed	AERC864420
Fecha			20191115
Objetivo	    Generar alertas anzuelo
Proyecto		Banca M�vil, m�dulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_ALERTA_ANZUELO

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				declare	@tran_name varchar(32) = 'ALERTA_ANZUELO',
						@tran_count int = @@trancount,
						@tran_scope bit = 0
						
				declare
					@valor1 int,
					@valor2 int,
					@valor3 int,
					@tipo_origen_operacion int,
					@id_tipo_bitacora int,
					@motivobloqueo varchar(255),
					@id_motivo_bloqueo int,
					@id_tipo_alerta_bloqueo	int,
					@descripcion_bloqueo varchar(255),
					@idtipo_bitacora_fraude int,
					@Descripcion_Bitacoras_Fraudes varchar(900),
					@idtipo_bitacora_fraude_bloqueo int ,
					@Descripcion_Bitacoras_Fraudes_bloqueo varchar(900),
					@id_tipo_alerta int,
					@Fecha_inicio datetime

			--	select @fecha_analisis  = cast(coalesce(@fecha_analisis, getdate())as date)
				--select @FechaInicio  = cast( getdate()as date)
			--	select @FechaFin = cast( getdate() as date)

				create table #bloqueo_socio(
					Numero_socio int
				)

				create table #retiroAnzuelo (
					id_transferencia int,
					numero_socio int,
					MontodelMovimiento money,
					fecha_transferencia datetime,
					tipo_transferencia varchar(1)
				)
				
				create table #retiroMayor(
					id_transferencia int,
					numero_socio int,
					MontodelMovimiento money,
					fecha_transferencia datetime,
					tipo_transferencia varchar(1)
				)

				create table #movs(
					id_banca_folio int,
					numero_socio int,
					fecha_transferencia_realizada datetime,
				)
			end -- inicio

			begin -- preparaci�n
			
				select  @valor1 = Valor 
				from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS 
				where Id_parametro = 3 
				
				select @valor2= Valor 
				from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS
				where Id_parametro = 4

				select @valor3= Valor 
				from TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS 
				where Id_parametro = 5

				set  @id_motivo_bloqueo = 13 --- Bloqueo autom�tico por motivos de fraudes
				set @tipo_origen_operacion = 7 --- M�dulo de Fraudes
				set @id_tipo_bitacora = 87 --- Bloqueo autom�tico por intento o por  fraude a la  cuenta
				set @id_tipo_alerta_bloqueo = 2 --- Alerta tipo Anzuelo  2
 
				select @idtipo_bitacora_fraude_bloqueo = id_Tipo_Bitacoras_fraudes,
						  @Descripcion_Bitacoras_Fraudes_bloqueo =Descripcion_Bitacoras_Fraudes
				from CAT_banca_fraude_tipos_bitacora_fraude
				where id_Tipo_Bitacoras_fraudes = 5 --- Bloqueo por alerta anzuelo 

			end -- preparaci�n
			
			begin -- transacci�n

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio

				begin --componentes de la transacci�n

					--- Insertar transferencias internas, externas y pago de servicios cuyo monto se encuentra entre los 2 primeros parametros de la alerta
					insert into #retiroAnzuelo --TBL_BANCAFRAUDE_VERIFICACIONCENTAVOACIEN
					select id_transferencia, BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio), monto, fecha_transferencia_realizada, 'i'
					from tbl_banca_transferencias_internas trans
						inner join TBL_BANCA_SOCIOS socio on BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio) and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1 and socio.id_motivo_bloqueo = 1
					where id_estatus_transferencia = 2
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and CAST(monto AS MONEY) between @valor1 and @valor2
						and CAST(fecha_transferencia_realizada as date) = CAST(GETDATE() as date)						
					union
					select id_transferencia, BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio), monto, fecha_transferencia_realizada, 'e'
					from tbl_banca_transferencias_externas trans
						inner join TBL_BANCA_SOCIOS socio on BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio) and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1 and socio.id_motivo_bloqueo = 1
					where id_estatus_transferencia = 2
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and CAST(monto AS MONEY) between @valor1 and @valor2
						and CAST(fecha_transferencia_realizada as date) = CAST(GETDATE() as date)
					
						
					--- Insertar transferencias internas, externas y pago de servicios cuyo monto se encuentra entre los 2 primeros parametros de la alerta
					insert into #retiroMayor --tbl_banca_fraude_cien_diezmil
					select id_transferencia, BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio), monto, fecha_transferencia_realizada, 'i'
					from tbl_banca_transferencias_internas trans
						inner join TBL_BANCA_SOCIOS socio on BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio) and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1  and socio.id_motivo_bloqueo = 1
					where id_estatus_transferencia = 2
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and CAST(monto AS MONEY) > @valor3
						and CAST(fecha_transferencia_realizada as date) = CAST(GETDATE() as date)
					union
					select id_transferencia, BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio), monto, fecha_transferencia_realizada, 'e'
					from tbl_banca_transferencias_externas trans
						inner join TBL_BANCA_SOCIOS socio on BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio) and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1 and socio.id_motivo_bloqueo = 1
					where id_estatus_transferencia = 2
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and CAST(monto AS MONEY) > @valor3
						and CAST(fecha_transferencia_realizada as date) = CAST(GETDATE() as date)

					--- Obtener los socios que caen en la alerta y se bloquearan
					insert into #bloqueo_socio --socios a alertar y bloquear
					select distinct  a.numero_socio
					from #retiroMayor a
					inner join #retiroAnzuelo b on a.numero_socio = b.numero_socio
					--where a.numero_socio not in  (select numero_socio from TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR)

					--- Obtener los movimientos que est�n generando la alerta
					insert into #movs
					select distinct 
						trans.id_banca_folio,
						BANCA.dbo.FN_BANCA_DESCIFRAR(socio.NUMERO_SOCIO),
						trans.fecha_transferencia_realizada
					from TBL_BANCA_TRANSFERENCIAS_INTERNAS trans
						inner join TBL_BANCA_SOCIOS socio on BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio) and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1
						inner join #bloqueo_socio b on b.Numero_socio = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio)
					where
						CAST(fecha_transferencia_realizada as date) = CAST(GETDATE() as date)
						--and (CAST(trans.monto AS MONEY) between @valor1 and @valor2 or  CAST(trans.monto AS MONEY) > @valor3)
						and CAST(substring(trans.clave_corresponsalias_origen,10,7) as int) <> CAST(substring(trans.clave_corresponsalias_destino,10,7) as int)
						--and (trans.id_transferencia in (select id_transferencia from #retiroAnzuelo) or id_transferencia in (select id_transferencia from #retiroMayor))
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and trans.id_estatus_transferencia=2 
						and trans.programada = 0						
					
					union 

					select distinct 
								trans.id_banca_folio, 
								BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio),
								trans.fecha_transferencia_realizada
					from TBL_BANCA_TRANSFERENCIAS_EXTERNAS trans
						inner join TBL_BANCA_SOCIOS socio on BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio) and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1
						inner join #bloqueo_socio bs on bs.numero_socio = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio)
					where 
						CAST( trans.fecha_transferencia_realizada as date) = CAST(GETDATE() as date)
					--	and (CAST(trans.monto AS MONEY) between @valor1 and @valor2 or  CAST(trans.monto AS MONEY) > @valor3)
						--and (trans.id_transferencia in (select id_transferencia from #retiroAnzuelo) or id_transferencia in (select id_transferencia from #retiroMayor))
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and id_estatus_transferencia = 2
						and trans.programado = 0
											
					--- Crear alerta
					insert into TBL_BANCA_FRAUDE_ALERTA(NUMERO_SOCIO, Fecha_Alerta, ID_TIPO_ALERTA, ID_ALERTA_RECURRENTE, ID_ESTATUS, id_notificacion)
					select distinct Numero_socio, GETDATE(), @id_tipo_alerta_bloqueo, 1, 1, 0
					from #bloqueo_socio

					--- Insertar en TBL_BANCA_FRAUDE_MOVIMIENTOS los movimientos que generaron la alerta
					insert into TBL_BANCA_FRAUDE_MOVIMIENTOS(Folio_movimiento, Numero, Fecha_movimiento, Id_tipo_alerta, Id_alerta)
					select *, @id_tipo_alerta_bloqueo, (select MAX(folio_alerta) from TBL_BANCA_FRAUDE_ALERTA)
					from #movs
					
				   --Insertar en la tabla de Bitacoras 
					insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus)
					select socio.NUMERO_SOCIO, @idtipo_bitacora_fraude_bloqueo as Id_Tipo_Bitacoras_Fraudes, GETDATE(), @Descripcion_Bitacoras_Fraudes_bloqueo as Evento, 1
					from #bloqueo_socio socio
					
					--- Bloqueo de la cuenta CMV Finanzas del socio 
					update banca..TBL_BANCA_SOCIOS 
						set 
							id_motivo_bloqueo=@id_motivo_bloqueo,
							fecha_motivo_bloqueo = getdate(),
							viene_de_bloqueo = 1,
							descripcion_bloqueo=@motivobloqueo
						from 
							banca..TBL_BANCA_SOCIOS bancaSocios, #bloqueo_socio bancaSociosTemp
						where 
							BANCA.dbo.FN_BANCA_DESCIFRAR(bancaSocios.numero_socio) = bancaSociosTemp.numero_socio

					--- Actualizaci�n o inserci�n en la tabla TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO para notificar al socio
					if((select COUNT(id) from TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO a, #bloqueo_socio b where a.Numero_Socio = b.Numero_socio ) > 0)
						begin
							update TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO 
								set Notificacion_Email = 0, Notificacion_sms = 0
								where Numero_Socio in  (select numero_socio from #bloqueo_socio)
						end
					else
						insert into  TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO (Numero_Socio,Nombre_Socio,Tel_Celular,Email,Id_Tipo_Bitacoras_Fraudes,id_tipo_notificacion)
						select distinct
							bs.Numero_socio,
							P.Nombre_s+' '+P.Apellido_Paterno+' '+Apellido_Materno as Nombre_Socio,
							P.Tel_celular,
							P.Mail,
							1,
							contrato.id_tipo_notificacion
						from Tbl_banca_fraude_alerta alerta
							inner join hape..PERSONA P on P.numero=alerta.numero_Socio  and p.id_tipo_persona = 1
							inner join BANCA..TBL_BANCA_SOCIOS bsocios on BANCA.dbo.FN_BANCA_DESCIFRAR(bsocios.numero_socio) = alerta.NUMERO_SOCIO
							inner join HAPE..TBL_CONTRATOS_HABERES contrato on alerta.numero_socio = contrato.numero
							inner join #bloqueo_socio bs on bs.Numero_socio = P.Numero
						where bsocios.banca_activa = 1
							and bsocios.id_motivo_bloqueo = 13
							and contrato.id_tipo_contrato = 3 			
					
					drop table #bloqueo_socio, #retiroAnzuelo, #retiroMayor, #movs

				end -- componentes de la transacci�n
				
			
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
						
			-- revertir transacci�n si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDE_ALERTA_ANZUELO to public
go

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_ALERTA_CICLICA
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_ALERTA_CICLICA' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_ALERTA_CICLICA
go

/*

Autor			Blanca Estela Gonz�lez Soto
UsuarioRed		GOSB811264
Fecha			20191203
Objetivo		Detecci�n de alerta c�clica: En donde si hay movimientos
Proyecto		BANCA FRAUDES
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_ALERTA_CICLICA
	
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',

						@fecha date=getdate()
			
			end -- inicio
			
			begin -- �mbito de la actualizaci�n
			
				--Seleccionamos todos aquellos socios que tienen 3 o m�s movimientos al dia
				select * 
				   into #sociosConMasMov
				from 
					(select 
						BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) numero_socio
						from banca..TBL_BANCA_TRANSFERENCIAS_INTERNAS 
						where 
						CAST(substring(clave_corresponsalias_origen,10,7) as int) <> CAST(substring(clave_corresponsalias_destino,10,7) as int) and 
						CAST(fecha_transferencia_realizada as date)=cast(@fecha as date) 
						and id_estatus_transferencia=2
						group by BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)
						having count(numero_socio) >=3
				union
					 select 
						BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) numero_socio
						from banca..TBL_BANCA_TRANSFERENCIAS_EXTERNAS
						where 
						cast(fecha_transferencia_realizada as date)=cast(@fecha as date) 
						and id_estatus_transferencia=2
						group by BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)
						having count(numero_socio) >=3
				) socios

				--select * from #sociosConMasMov

				--Guardamos en tabla temporal para realizar la comparaci�n entre los registros.
				select 
					ROW_NUMBER() OVER(order by transferencia.numero_socio,transferencia.fecha_transferencia_realizada asc) id,
					transferencia.id_transferencia,
					transferencia.Folio,
					transferencia.numero_socio,
					transferencia.fecha_transferencia_realizada,
					transferencia.tipotranferencia
				into #transferencia1
				from (
					  select
						 trans1.id_transferencia,
						 trans1.id_banca_folio Folio,
						 socios.numero_socio,
						 trans1.fecha_transferencia_realizada,
						 'I' tipotranferencia
						 from #sociosConMasMov socios 
						 inner join banca..TBL_BANCA_TRANSFERENCIAS_INTERNAS trans1 on BANCA.dbo.FN_BANCA_DESCIFRAR(trans1.numero_socio)=socios.numero_socio
						 where 
						 CAST(substring(trans1.clave_corresponsalias_origen,10,7) as int) <> CAST(substring(trans1.clave_corresponsalias_destino,10,7) as int) and 
						 CAST(trans1.fecha_transferencia_realizada as date)=cast(@fecha as date) 
						 and trans1.id_estatus_transferencia=2
					  union
					  select 
						 trans2.id_transferencia,
						 trans2.id_banca_folio Folio,
						 socios.numero_socio,
						 trans2.fecha_transferencia_realizada,
						 'E' tipotranferencia
						 from #sociosConMasMov socios 
						 inner join banca..TBL_BANCA_TRANSFERENCIAS_EXTERNAS trans2 on BANCA.dbo.FN_BANCA_DESCIFRAR(trans2.numero_socio)=socios.numero_socio
						 where 	
						 cast(trans2.fecha_transferencia_realizada as date)=cast(@fecha as date) 
						 and trans2.id_estatus_transferencia=2
				) transferencia
				where transferencia.Folio not in(select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS group by Folio_movimiento)
				order by transferencia.numero_socio, transferencia.fecha_transferencia_realizada asc		

				--select * from #transferencia1
	
			-----Comparamos los registros para obtener la diferencia del tiempo
					select
					trans1.id,
					trans1.Folio,
					trans1.id_transferencia id_transferencia_origen,
					trans1.numero_socio,
					trans1.fecha_transferencia_realizada,
					trans1.tipotranferencia,
					trans2.id id_2,
					trans2.Folio folio_2,
					trans2.id_transferencia id_transferencia_origen_2,
					trans2.numero_socio numero_socio2,
					trans2.fecha_transferencia_realizada fecha_transferencia_realizada2,
					trans2.tipotranferencia tipotranferencia_2,
					datediff (MINUTE, trans1.fecha_transferencia_realizada, trans2.fecha_transferencia_realizada) tiempo 
					into #tiempos
					from #transferencia1 trans1 
					inner join #transferencia1 trans2 on trans2.numero_socio=trans1.numero_socio and trans1.id=trans2.id-1
					inner join BANCA.dbo.TBL_BANCA_SOCIOS socios on BANCA.dbo.FN_BANCA_DESCIFRAR(socios.numero_socio)=trans1.numero_socio and socios.banca_activa=1 and socios.id_motivo_bloqueo=1
					--where 
					--trans1.Folio not in(select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
		
					--select * from #tiempos

			---------Socios que fueron identificados por Alerta C�clica
					 select 
						 count(*) numvecesRepetidos,
						 numero_socio,
						 tiempo
					 into #SociosAlertados
					 from #tiempos	 
					 --where	 
					 ---------------------------Validacion temporal-----------------------------------
					 --numero_socio not in(select numero_socio from banca..TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR)
					 -----------------------------------------------------------------------------------
					 group by numero_socio,tiempo
					 having count(tiempo) >=2
					 order by numero_socio asc

			---------Se registran en la tabla de TBL_BANCA_FRAUDE_ALERTA a los socios que no cumplieron con el perfil transaccional
				   insert into banca.dbo.TBL_BANCA_FRAUDE_ALERTA(Fecha_Alerta,NUMERO_SOCIO,ID_TIPO_ALERTA,ID_ALERTA_RECURRENTE,ID_ESTATUS)
				   select distinct
					   GETDATE() Fecha,
					   numero_socio,
					   6 Tipo_alerta,
					   1 Alerta_recurrente,
					   1 Idstatus
					 from #SociosAlertados 

			--------Obtenemos los movimientos  de los socios alertados en la tabla #movimientosfraudes

					select distinct * 
					into #movimientosfraudes from(
						select id,id_transferencia_origen,Folio,numero_socio,fecha_transferencia_realizada,tipotranferencia 
						from #tiempos where tiempo in(
								select tiempo from #SociosAlertados
						)
						union
						select id_2,id_transferencia_origen_2,folio_2,numero_socio2,fecha_transferencia_realizada2,tipotranferencia_2 
						from #tiempos where tiempo in(
							select tiempo from #SociosAlertados
						)
					)movimientos

			--------Se actualiza el tipo de bloqueo en TBL_BANCA_SOCIO
					update TBL_BANCA_SOCIOS set id_motivo_bloqueo = 13
					where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) in (select numero_socio from #SociosAlertados) and id_motivo_bloqueo = 1

			--------Se insertan los movimientos fraudulentos correspondientes a la en la tabla TBL_BANCA_FRAUDE_MOVIMIENTOS
					Insert into TBL_BANCA_FRAUDE_MOVIMIENTOS(folio_movimiento,Id_alerta,Numero,Fecha_movimiento,id_tipo_alerta)
					select distinct
						movimientos.Folio,
						alerta.Folio_alerta,
						alerta.NUMERO_SOCIO,
						movimientos.fecha_transferencia_realizada,
						alerta.ID_TIPO_ALERTA
					from #movimientosfraudes movimientos
					inner join banca..TBL_BANCA_FRAUDE_ALERTA alerta on alerta.NUMERO_SOCIO=movimientos.numero_socio
					where alerta.ID_TIPO_ALERTA=6 and cast(alerta.Fecha_Alerta as date)=cast(@fecha as date) 
					and alerta.ID_ESTATUS = 1 


				 -- select * from #SociosAlertados
			--------Se inserta en la bit�cora de operaciones
					insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus)						
					select distinct
						socios.numero_socio,
						6 Id_Tipo_Bitacoras_Fraudes,
						GETDATE() Fecha,
						(select Descripcion_Bitacoras_Fraudes from banca.dbo.CAT_banca_fraude_tipos_bitacora_fraude where id_Tipo_Bitacoras_fraudes = 6)Evento,
						alerta.ID_ESTATUS
					from #SociosAlertados socios 
					inner join banca.dbo.TBL_BANCA_FRAUDE_ALERTA alerta on alerta.NUMERO_SOCIO=socios.numero_socio 
					where alerta.ID_TIPO_ALERTA = 6 and alerta.ID_ESTATUS = 1 

			--------Obtenemos el idBitacora de la bitacora de operaciones 
					select 
					max(bitacora.Id_Bitacora_Fraude)IdBitacoraFraude,
					socios.numero_socio 
					into #idBitacoraFraude
					from #SociosAlertados socios
					inner join banca..TBL_BANCA_FRAUDE_BITACORA_OPERACIONES bitacora on bitacora.Numero_Socio=socios.numero_socio 
					and bitacora.Id_Tipo_Bitacoras_Fraudes=6 and bitacora.Estatus=1
					group by socios.numero_socio
	 
			--    select * from #idBitacoraFraude
			--------insertar notificaciones TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO
				   insert into TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO (Numero_Socio,Nombre_Socio,Tel_Celular,Email,id_tipo_notificacion,Id_Tipo_Bitacoras_Fraudes,Id_bitacora_fraude) 
				   select distinct
						alerta.Numero_socio,
						pers.Nombre as Nombre_Socio,
						pers.Tel_celular,
						pers.Mail,
						contrato.id_tipo_notificacion,
						6 IdTipoBitacora,--Id_Tipo_Bitacoras_Fraudes Bloqueo alerta recurrente
						bitacora.IdBitacoraFraude
					from #SociosAlertados socios
						inner join banca.dbo.TBL_BANCA_FRAUDE_ALERTA alerta on alerta.NUMERO_SOCIO=socios.numero_socio
						inner join (select Numero,(Nombre_s+' '+Apellido_Paterno+' '+Apellido_Materno)Nombre,Tel_celular,Mail from HAPE.dbo.PERSONA where Id_Tipo_Persona=1) pers on pers.numero=alerta.numero_Socio  
						inner join #idBitacoraFraude bitacora on bitacora.numero_socio=alerta.NUMERO_SOCIO
						inner join HAPE.dbo.TBL_CONTRATOS_HABERES contrato on alerta.numero_socio = contrato.numero and contrato.id_tipo_contrato = 3 and contrato.id_tipo_persona = 1 and contrato.id_tipo_notificacion is not null
					where alerta.id_tipo_alerta=6 and alerta.ID_ESTATUS = 1 
					and socios.numero_socio not in(select Numero_Socio from banca..TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO)

			--------Actualizamos el id_tipo_de_bitacora_fraudes y La notificacion_sms y la notificacion_Email
					update notificacion set 
						notificacion.Id_Tipo_Bitacoras_Fraudes=6,
						notificacion.Id_bitacora_fraude=bitacora.IdBitacoraFraude,
						notificacion.Notificacion_sms=0,
						notificacion.Notificacion_Email=0 
					from banca..TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO notificacion 
					inner join #SociosAlertados socios on socios.numero_socio=notificacion.Numero_Socio
					inner join #idBitacoraFraude bitacora on bitacora.numero_socio=socios.numero_socio

			--	--Actualizamos la fecha de en que se ejecut� el sp 
			--	update CAT_BANCA_FRAUDES_LOG_JOBS set fecha_ultima_ejecucion=GETDATE() where id=2

				Drop table #sociosConMasMov
				Drop table #transferencia1
				Drop table #tiempos
				Drop table #SociosAlertados
				Drop table #movimientosfraudes
				Drop table #idBitacoraFraude
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_ALERTA_CICLICA to public

go

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_ALERTA_TIEMPO_MINIMO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_ALERTA_TIEMPO_MINIMO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_ALERTA_TIEMPO_MINIMO
go

/*

Autor			Luis Arturo G�lvez Macias - Claudia Alejandra Arredondo Rodr�guez - Blanca Estela 
UsuarioRed	GAML841262 - AERC864420 - 
Fecha			20190320
Objetivo		Consultar las alertas  que esten levantadas por socios que tengan  movimientos en un tiempo meno a unsegundo
Proyecto		Banca Electr�nica Dvisi�n de Fraudes Electronicos
Ticket			ticket

*/



create proc

	SP_BANCA_FRAUDE_ALERTA_TIEMPO_MINIMO

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				declare	@tran_name varchar(32) = 'ALERTA_TIEMPO_MINIMO',
						@tran_count int = @@trancount,
						@tran_scope bit = 0,
						@id_tipo_bitacora int,
						@tipo_origen_operacion int,
						@motivobloqueo varchar(255),
						@XML XML,
						@tiempo int,
						@id_motivo_bloqueo int,
						@descripcion_bloqueo varchar(255),
						@id_tipo_alerta_bloqueo int,
						@idtipo_bitacora_fraude int,
						@Descripcion_Bitacoras_Fraudes varchar(900),
						@idtipo_bitacora_fraude_bloqueo int,
						@Descripcion_Bitacoras_Fraudes_bloqueo varchar(900),
						@Fecha_inicio datetime
					
				create table #tiempo_minimo (
					id_transferencia bigint,
					id_estatus_transferencia int,
					numero_origen int,
					consecutivo int,
					numero_destino int,
					fecha_transferencia_realizada datetime,
					monto money,
					diferencia decimal(16,3),
					programada bit
				)

				create table #bloqueo_socio(
					numero_socio int
				)

				create table #movs(
					id_banca_folio int,
					numero_socio int,
					fecha_transferencia_realizada datetime
				)

			end -- inicio

			begin -- preparaci�n

				/* Inicializaci�n de variables con consulta */
				set @id_tipo_alerta_bloqueo =  5 --- Alerta de Tiempo M �nimo
				set @id_motivo_bloqueo = 13  --- Bloqueo autom�tico por motivos de fraudes
				set @tipo_origen_operacion = 7--- M�dulo de Fraudes
				set @id_tipo_bitacora= 87 --- Bloqueo autom�tico por intento o por  fraude a la  cuenta
				
				select @idtipo_bitacora_fraude_bloqueo= id_Tipo_Bitacoras_fraudes,
					      @Descripcion_Bitacoras_Fraudes_bloqueo = Descripcion_Bitacoras_Fraudes
				from CAT_banca_fraude_tipos_bitacora_fraude
				where id_Tipo_Bitacoras_fraudes = 4 --- Bloqueo por alerta de tiempo m�nimo
			end -- preparaci�n
									
			begin -- transacci�n

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio
				
				begin -- componente de la transacci�n
					
					--- Obtener los movimientos del socio que ha realizado desde la �ltima ejecuci�n del script al momento
					insert into #tiempo_minimo
					select	id_transferencia,
								id_estatus_transferencia,
								numero_origen = co.numero,
								row_number() over (partition by co.numero order by co.numero, fecha_transferencia_realizada, id_transferencia),
								numero_destino = cd.NUMERO,
								fecha_transferencia_realizada,
								monto,
								null,
								programada				
					from	banca.dbo.TBL_BANCA_TRANSFERENCIAS_INTERNAS t
						inner join TBL_BANCA_SOCIOS socio on BANCA.dbo.FN_BANCA_DESCIFRAR(t.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio) and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1 and socio.id_motivo_bloqueo = 1
						inner join hape.dbo.TBL_CORRESPONSALIAS_CUENTAS co on co.CUENTA = t.clave_corresponsalias_origen
						inner join hape.dbo.TBL_CORRESPONSALIAS_CUENTAS cd on cd.CUENTA = t.clave_corresponsalias_destino
					where	id_estatus_transferencia = 2
						and t.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and cast(fecha_transferencia_realizada as date)  = cast(GETDATE() as date)	
						and CAST(substring(t.clave_corresponsalias_origen,10,7)as int) <> CAST(SUBSTRING(t.clave_corresponsalias_destino,10,7)as int)

					insert into #tiempo_minimo
					select trans.id_transferencia, 
								id_estatus_transferencia, 
								BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio), 
								ROW_NUMBER() over(partition by BANCA.dbo.FN_BANCA_DESCIFRAR(clabes.numero_socio) order by BANCA.dbo.FN_BANCA_DESCIFRAR(clabes.numero_socio), id_transferencia),
								0, 
								fecha_transferencia_realizada, 
								monto, 
								null,
								programado						
					from TBL_BANCA_TRANSFERENCIAS_EXTERNAS trans
						inner join TBL_BANCA_SOCIOS socio on BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio) and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1 and socio.id_motivo_bloqueo = 1
						inner join TBL_BANCA_CUENTAS_INTERBANCARIAS clabes on BANCA.dbo.FN_BANCA_DESCIFRAR(clabes.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio) 
					where id_estatus_transferencia = 2
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and CAST(fecha_transferencia_realizada as date) = CAST(GETDATE() as date)			
			

					--- Actualizar la diferencia entre dos movimientos
					update	m2
					set		m2.diferencia = (datediff(ms, m1.fecha_transferencia_realizada, m2.fecha_transferencia_realizada) /1e3)
					from	#tiempo_minimo m1
						join #tiempo_minimo m2 on m2.numero_origen = m1.numero_origen and m2.consecutivo = m1.consecutivo + 1

					--- Generar tabla de usuario a bloquear
					insert into #bloqueo_socio
					select distinct numero_origen
					from #tiempo_minimo
					where diferencia < 1 and diferencia is not null --and numero_origen not in  (select numero_socio from TBL_BANCA_FRAUDE_SOCIOS_EXCLUIR)
						

					--- Obtener los movimientos que generaron la alerta
					insert into #movs
					select distinct 
						trans.id_banca_folio,
						BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio),
						trans.fecha_transferencia_realizada
					from tbl_banca_transferencias_internas trans 
						inner join TBL_BANCA_SOCIOS socio on BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio) and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1
						inner join #bloqueo_socio bs on bs.numero_socio = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio)
					where  CAST( trans.fecha_transferencia_realizada as date) = CAST(GETDATE() as date)
						and (trans.id_transferencia in (select id_transferencia from #tiempo_minimo))
						and trans.id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and cast(substring(trans.clave_corresponsalias_origen,10,7)as int) = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.NUMERO_SOCIO)
						and CAST(substring(trans.clave_corresponsalias_origen,10,7)as int) <> CAST(SUBSTRING(trans.clave_corresponsalias_destino,10,7)as int)
						and trans.id_estatus_transferencia=2 
						and trans.programada = 0
						  
					union 

					select distinct 
						trans.id_banca_folio, 
						BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio),
						trans.fecha_transferencia_realizada
					from TBL_BANCA_TRANSFERENCIAS_EXTERNAS trans
						inner join TBL_BANCA_SOCIOS socio on BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio) and socio.id_estatus_banca in (6,8) and socio.banca_activa = 1
						inner join #bloqueo_socio bs on bs.numero_socio = BANCA.dbo.FN_BANCA_DESCIFRAR(socio.numero_socio)
					where  CAST( trans.fecha_transferencia_realizada as date) = CAST(GETDATE() as date)
						and (trans.id_transferencia in (select id_transferencia from #tiempo_minimo))
						and id_banca_folio not in (select Folio_movimiento from TBL_BANCA_FRAUDE_MOVIMIENTOS)
						and id_estatus_transferencia = 2
						and trans.programado = 0

					--- Generar la alerta
					insert into TBL_BANCA_FRAUDE_ALERTA(NUMERO_SOCIO, Fecha_Alerta, ID_TIPO_ALERTA, ID_ALERTA_RECURRENTE, ID_ESTATUS, id_notificacion)
					select distinct Numero_socio, GETDATE(), @id_tipo_alerta_bloqueo, 1, 1, 0
					from #bloqueo_socio				

					--- Insertar en la tabla de movimiento s
					insert into TBL_BANCA_FRAUDE_MOVIMIENTOS(Folio_movimiento, Numero, Fecha_movimiento, Id_tipo_alerta, Id_alerta)
					select *, @id_tipo_alerta_bloqueo, (select MAX(folio_alerta) from TBL_BANCA_FRAUDE_ALERTA)
					from #movs

					--- Insertar en la bitacora de fraudes
					insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus)
					select socio.NUMERO_SOCIO, @idtipo_bitacora_fraude_bloqueo as Id_Tipo_Bitacoras_Fraudes, GETDATE(), @Descripcion_Bitacoras_Fraudes_bloqueo as Evento, 1
					from #bloqueo_socio socio

					--- Actualizar los socios a bloquear
					update banca..TBL_BANCA_SOCIOS 
					set  id_motivo_bloqueo=@id_motivo_bloqueo,
						fecha_motivo_bloqueo = getdate(),
						viene_de_bloqueo = 1,
						descripcion_bloqueo=@motivobloqueo
					from banca..TBL_BANCA_SOCIOS bancaSocios, #bloqueo_socio bancaSociosTemp
					where BANCA.dbo.FN_BANCA_DESCIFRAR(bancaSocios.numero_socio) = bancaSociosTemp.numero_socio

					--- Actualizaci�n / inserci�n en la tabla para notificar
					if((select COUNT(id) from TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO a, #bloqueo_socio b where a.Numero_Socio = b.Numero_socio ) > 0)
						begin
							update TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO 
								set Notificacion_Email = 0, Notificacion_sms = 0
								where Numero_Socio in  (select numero_socio from #bloqueo_socio)
						end
					else
						insert into  TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO (Numero_Socio,Nombre_Socio,Tel_Celular,Email,Id_Tipo_Bitacoras_Fraudes,id_tipo_notificacion)
						select distinct
							bs.Numero_socio,
							P.Nombre_s+' '+P.Apellido_Paterno+' '+Apellido_Materno as Nombre_Socio,
							P.Tel_celular,
							P.Mail,
							1,
							contrato.id_tipo_notificacion
						from Tbl_banca_fraude_alerta alerta
							inner join hape..PERSONA P on P.numero=alerta.numero_Socio and P.id_tipo_persona = 1
							inner join BANCA..TBL_BANCA_SOCIOS bsocios on BANCA.dbo.FN_BANCA_DESCIFRAR(bsocios.numero_socio) = alerta.NUMERO_SOCIO
							inner join HAPE..TBL_CONTRATOS_HABERES contrato on alerta.numero_socio = contrato.numero
							inner join #bloqueo_socio bs on bs.Numero_socio = P.Numero
						where bsocios.banca_activa = 1
							and bsocios.id_motivo_bloqueo = 13
							and contrato.id_tipo_contrato = 3 			
					
					drop table #tiempo_minimo, #bloqueo_socio, #movs
					 
				end -- componente de la transacci�n
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
						
			-- revertir transacci�n si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDE_ALERTA_TIEMPO_MINIMO to public
go

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_CREACION_PERFIL_TRANSACCIONAL_SOCIO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_CREACION_PERFIL_TRANSACCIONAL_SOCIO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_CREACION_PERFIL_TRANSACCIONAL_SOCIO
go

/*

Autor			Eduardo Villagomez Mata
UsuarioRed		VIME770170
Fecha			20190909
Objetivo		Actualizar el perfil transaccional de los usuarios que utilizan banca
Proyecto		Banca Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_CREACION_PERFIL_TRANSACCIONAL_SOCIO
	
	@numero_socio int,
	@numero_usuario int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@fecha_proceso datetime = getdate(),
						@fecha_max datetime ,
						@monto_max float,
					    @fecha_ini datetime						
			
			end -- inicio
			
			begin -- �mbito de la actualizaci�n
			    
				select @fecha_proceso = isnull(@fecha_proceso,getdate())
				select @fecha_ini     =DATEADD(month,-6,@fecha_proceso)
      

					/*Query para obtener la fecha del �ltimo movimiento y monto maximo*/
					select             
					@fecha_max=cast(max(perfil.Fecha) as date),
					@monto_max=coalesce(max(perfil.monto_max),2000)					
					--perf.monto monto_ant
				from
				(
				select                           
								max(Fecha_Alta) Fecha,
								max(monto) monto_max
								from 
										hape..movimientos mov
								where 
										numero=@numero_socio 
										and id_tipo_persona=1 
										and Id_tipomov IN (310,350,1001)
										and activo='T'
										and cast(fecha_mov as date) >=@fecha_ini and cast(fecha_mov as date)<=@fecha_proceso						
										group by Numero,id_tipomov,id_tipo_persona
								union

								select                        
										max(Fecha_Alta) Fecha,
										max(monto) monto_max
								from 
										HISTORICO..MOVIMIENTOS_HABERES mov
								where 
										numero=@numero_socio 
										and id_tipo_persona=1
										and Id_tipomov IN (310,350,1001)
										and activo='T'
										and cast(fecha_mov as date) >=@fecha_ini and cast(fecha_mov as date)<=@fecha_proceso
										group by Numero,id_tipo_persona,id_tipomov
					)perfil                   

					if not exists( select * from BANCA..TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL where BANCA.dbo.FN_BANCA_DESCIFRAR(Numero_Socio)= @numero_socio )
						insert into BANCA..TBL_BANCA_FRAUDE_ACTUALIZACION_DATOS_PERFIL_TRANSACCIONAL (Numero_Socio,Monto_Acumulado,Fecha_Actulizacion,Numero_Operaciones,Numero_Usuario)
						values (BANCA.dbo.FN_BANCA_CIFRAR(@numero_socio),@monto_max,@fecha_proceso,4,@numero_usuario)
			
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_CREACION_PERFIL_TRANSACCIONAL_SOCIO to public

go

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_DESBLOQUEO_SOCIOS_ALERTADOS
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_DESBLOQUEO_SOCIOS_ALERTADOS' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_DESBLOQUEO_SOCIOS_ALERTADOS
go

/*

Autor			Luis Arturo G�lvez Macias
UsuarioRed		GAML841262
Fecha			20190919
Objetivo		Desbloquear a los socios que  fueron alertados por posibles movimientos fraudulentos
Proyecto		Modulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_DESBLOQUEO_SOCIOS_ALERTADOS
	@Numero_Socio int,
	@numerousuario int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				declare	@tran_name varchar(32) = 'NOMBRE_TRANSACCION',
						@tran_count int = @@trancount,
						@tran_scope bit = 0,
						@idtipo_bitacora_fraude_desbloqueo int,
						@Descripcion_Bitacoras_Fraudes_desbloqueo varchar(900)
						
			end -- inicio
								
			begin -- transacci�n

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio
				
				begin -- componente de la transacci�n
							
					update 
						TBL_BANCA_SOCIOS
					set 
						id_motivo_bloqueo = 1,
						fecha_motivo_bloqueo = getdate()
					from 
						TBL_BANCA_FRAUDE_ALERTA  alerta 
						inner join TBL_BANCA_SOCIOS bsocios  on BANCA.dbo.FN_BANCA_DESCIFRAR(bsocios.numero_socio)= alerta.NUMERO_SOCIO and bsocios.banca_activa =1 and bsocios.id_estatus_banca in (6,8)
					where 
						id_tipo_alerta in (1,2,5,6) 
						and alerta.NUMERO_SOCIO = @Numero_Socio
						and alerta.ID_ESTATUS in (3)

					update tbl_banca_fraudes_notificacion_SMS_EMAIL_SOCIO_ALERTADO
					set Id_Tipo_Bitacoras_Fraudes = 2
					from tbl_banca_fraudes_notificacion_SMS_EMAIL_SOCIO_ALERTADO where Numero_Socio = @Numero_Socio

					/*Registro notificacion de bitacora de fraudes */

					select @idtipo_bitacora_fraude_desbloqueo =id_Tipo_Bitacoras_fraudes,
					@Descripcion_Bitacoras_Fraudes_desbloqueo =	Descripcion_Bitacoras_Fraudes
					from
					 cAT_banca_fraude_tipos_bitacora_fraude
					 where id_Tipo_bitacoras_fraudes = 2
		
					insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus,usuario)
					select 
						alerta.NUMERO_SOCIO,
						@idtipo_bitacora_fraude_desbloqueo as Id_Tipo_Bitacoras_Fraudes,
						GETDATE(),
						@Descripcion_Bitacoras_Fraudes_desbloqueo as Evento,
						alerta.ID_ESTATUS,
						@numerousuario
					from TBL_BANCA_FRAUDE_ALERTA alerta 
					inner join CAT_BANCA_FRAUDE_TIPO_ALERTA tipoAlerta on tipoAlerta.ID_TIPO_ALERTA=alerta.ID_TIPO_ALERTA
					where 
						alerta.NUMERO_SOCIO =@Numero_Socio 
						and ID_ESTATUS in(3) 
				
				end -- componente de la transacci�n
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
						
			-- revertir transacci�n si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDE_DESBLOQUEO_SOCIOS_ALERTADOS to public

go

USE BANCA;
GO

-- se crea procedimiento SP_BANCA_FRAUDE_DETALLE_ALERTA
IF EXISTS
(
  SELECT 
    *
  FROM sysobjects
  WHERE name LIKE 'SP_BANCA_FRAUDE_DETALLE_ALERTA'
        AND xtype = 'p'
        AND DB_NAME() = 'BANCA'
)
  DROP PROC 
    SP_BANCA_FRAUDE_DETALLE_ALERTA;
GO

/************************************************************************************
Autor			Luis Arturo Galvez Macias
UsuarioRed		GAML841262
Fecha			20190820
Objetivo		Obtener la descripci�n de las alertas por las cuales esta alertado el socio
Proyecto		Proyecto
Ticket			ticket
************************************************************************************/

CREATE PROC SP_BANCA_FRAUDE_DETALLE_ALERTA 
  @numero_socio INT
AS
  BEGIN -- procedimiento

    BEGIN TRY -- try principal

      BEGIN -- inicio
        -- declaraciones
        DECLARE 
          @status          INT          = 1, 
          @error_message   VARCHAR(255) = '', 
          @error_line      VARCHAR(255) = '', 
          @error_severity  VARCHAR(255) = '', 
          @error_procedure VARCHAR(255) = '';
      END; -- inicio

      BEGIN -- �mbito de la actualizaci�n

        SELECT 
          @status STATUS, 
          @error_procedure error_procedure, 
          @error_line error_line, 
          @error_severity error_severity, 
          @error_message error_message, 
		  alerta.folio_alerta,
          alerta.NUMERO_SOCIO, 
          alerta.ID_TIPO_ALERTA, 
          cat_alerta.DESCRIPCION AS Descripcion_Tipo_Alerta
        FROM tbl_banca_fraude_alerta alerta
             JOIN CAT_BANCA_FRAUDE_TIPO_ALERTA cat_alerta ON alerta.id_tipo_alerta = cat_alerta.ID_TIPO_ALERTA
        WHERE NUMERO_SOCIO = @numero_socio AND alerta.id_estatus = 1;
      END; -- �mbito de la actualizaci�n

    END TRY -- try principal

    BEGIN CATCH -- catch principal
      -- captura del error
      SELECT 
        @status = -ERROR_STATE(), 
        @error_procedure = COALESCE(ERROR_PROCEDURE(), 'CONSULTA DIN�MICA'), 
        @error_line = ERROR_LINE(), 
        @error_message = ERROR_MESSAGE(), 
        @error_severity = CASE ERROR_SEVERITY()
                            WHEN 11
                              THEN 'Error en validaci�n'
                            WHEN 12
                              THEN 'Error en consulta'
                            WHEN 13
                              THEN 'Error en actualizaci�n'
                          ELSE 'Error general'
                          END;
    END CATCH; -- catch principal

  END; -- procedimiento

GO
GRANT EXEC ON SP_BANCA_FRAUDE_DETALLE_ALERTA TO public;
go

USE banca;
GO

-- se crea procedimiento SP_BANCA_FRAUDE_INSERCION_DATOS_REPORTE
IF EXISTS
(
    SELECT 
	 *
    FROM sysobjects
    WHERE name LIKE 'SP_BANCA_FRAUDE_INSERCION_DATOS_REPORTE'
		AND xtype = 'p'
		AND DB_NAME() = 'banca'
)
  BEGIN
    DROP PROC 
	 SP_BANCA_FRAUDE_INSERCION_DATOS_REPORTE;
END;
GO

/************************************************************************************************
Autor			Sabdi Abraham Pantoja Orozco
UsuarioRed		PAOS845568
Fecha			2019-12-26
Objetivo			Inserci�n de los datos  que son importantes en las  alertas  levantadas  anteriormente
Proyecto			Banca Electr�nica Divisi�n de Fruades Electr�nicos
Ticket			ticket
************************************************************************************************/

CREATE PROC SP_BANCA_FRAUDE_INSERCION_DATOS_REPORTE 
  @Numero_Socio    INT, 
  @Nombre_Socio    VARCHAR(255), 
  @Anotaciones     TEXT, 
  @folio_alerta    INT, 
  @Id_Canalizacion INT          = NULL, 
  @Fecha_Atencion  DATETIME     = NULL, 
  @Motivo          INT          = NULL, 
  @numerousuario   INT
AS
  BEGIN -- procedimiento

    BEGIN TRY -- try principal

	 BEGIN -- inicio
	   -- declaraciones
	   DECLARE @status          INT          = 1, 
			 @error_message   VARCHAR(255) = '', 
			 @error_line      VARCHAR(255) = '', 
			 @error_severity  VARCHAR(255) = '', 
			 @error_procedure VARCHAR(255) = '';
	   DECLARE @tran_name  VARCHAR(32) = 'NOMBRE_TRANSACCION', 
			 @tran_count INT         = @@trancount, 
			 @tran_scope BIT         = 0;

	   -- valores por defecto
	   SET @Fecha_Atencion = CAST(COALESCE(@Fecha_Atencion, GETDATE()) AS DATE);
	   SET @Id_Canalizacion = COALESCE(@Id_Canalizacion, 1);
	   SET @Fecha_Atencion = CAST(GETDATE() AS DATE);
	 END; -- inicio

	 BEGIN -- transacci�n

	   BEGIN -- inicio

		IF @tran_count = 0
		  BEGIN
		    BEGIN TRAN @tran_name;
		END;
		  ELSE
		  BEGIN
		    SAVE TRAN @tran_name;
		END;
		SELECT 
		  @tran_scope = 1;
	   END; -- inicio

	   BEGIN -- componente de la transacci�n

		UPDATE TBL_BANCA_FRAUDE_ALERTA
		  SET 
		    ID_ESTATUS = @Id_Canalizacion
		WHERE 
		  folio_alerta = @folio_alerta;
		UPDATE TBL_BANCA_SOCIOS
		  SET 
		    id_motivo_bloqueo = 14
		WHERE 
		  BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @Numero_Socio
		IF
		(
		    SELECT 
			 COUNT(1)
		    FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
		    WHERE folio_alerta = @folio_alerta
		) > 0
		  BEGIN
		    UPDATE TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
			 SET 
			   Anotaciones = @Anotaciones, 
			   Id_Canalizacion = @Id_Canalizacion, 
			   Fecha_Atencion = @Fecha_Atencion
		    WHERE 
			 folio_alerta = @folio_alerta;
		END;
		  ELSE
		  BEGIN
		    INSERT INTO TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES(
			 Numero_Socio, 
			 Nombre_Socio, 
			 Anotaciones, 
			 Id_Canalizacion, 
			 Fecha_Atencion, 
			 Motivo, 
			 Numero_Usuario, 
			 folio_alerta
		    )
		    VALUES
		    (
			 @Numero_Socio, 
			 @Nombre_Socio, 
			 @Anotaciones, 
			 @Id_Canalizacion, 
			 @Fecha_Atencion, 
			 @Motivo, 
			 @numerousuario, 
			 @folio_alerta
		    );
		END;
	   END; -- componente de la transacci�n

	   BEGIN -- commit

		IF @tran_count = 0
		  BEGIN -- si la transacci�n se inici� dentro de este �mbito

		    COMMIT TRAN @tran_name;
		    SELECT 
			 @tran_scope = 0;
		END; -- si la transacci�n se inici� dentro de este �mbito

	   END; -- commit

	 END;
    END TRY -- try principal

    BEGIN CATCH -- catch principal
	 -- captura del error
	 SELECT 
	   @status = -ERROR_STATE(), 
	   @error_procedure = COALESCE(ERROR_PROCEDURE(), 'CONSULTA DIN�MICA'), 
	   @error_line = ERROR_LINE(), 
	   @error_message = ERROR_MESSAGE(), 
	   @error_severity = CASE ERROR_SEVERITY()
					   WHEN 11
						THEN 'Error en validaci�n'
					   WHEN 12
						THEN 'Error en consulta'
					   WHEN 13
						THEN 'Error en actualizaci�n'
					   ELSE 'Error general'
					 END;

	 -- revertir transacci�n si es necesario
	 IF @tran_scope = 1
	   BEGIN
		ROLLBACK TRAN @tran_name;
	 END;
    END CATCH; -- catch principal

    BEGIN -- reporte de status

	 SELECT 
	   @status          STATUS, 
	   @error_procedure error_procedure, 
	   @error_line      error_line, 
	   @error_severity  error_severity, 
	   @error_message   error_message;
    END; -- reporte de status

  END; -- procedimiento
GO
GRANT EXEC ON SP_BANCA_FRAUDE_INSERCION_DATOS_REPORTE TO public;
go

USE BANCA;
GO

-- se crea procedimiento SP_BANCA_FRAUDE_NVA_ALERTA
IF EXISTS
(
  SELECT 
    *
  FROM sysobjects
  WHERE NAME LIKE 'SP_BANCA_FRAUDE_NVA_ALERTA'
        AND xtype = 'p'
        AND DB_NAME() = 'BANCA'
)
  DROP PROC 
    SP_BANCA_FRAUDE_NVA_ALERTA;
GO

/*************************************************************************
Autor				Sabdi Abraham Pantoja Orozco
UsuarioRed	paos845568
Fecha				2/Diciembre/2019
Objetivo		Obtener a los socios que estan alertados por una  o m�s alertas 
Proyecto		Modulo de fraudes
Ticket			ticket
*************************************************************************/

CREATE PROC SP_BANCA_FRAUDE_NVA_ALERTA 
  @FechaInicio DATETIME = NULL, 
  @FechaFin    DATETIME = NULL
AS
  BEGIN -- procedimiento

    BEGIN TRY -- try principal

      BEGIN -- inicio
        -- declaraciones
        DECLARE 
          @status          INT           = 1, 
          @error_message   VARCHAR(255)  = '''''', 
          @error_line      VARCHAR(255)  = '''''', 
          @error_severity  VARCHAR(255)  = '''''', 
          @error_procedure VARCHAR(255)  = '''''', 
          @cadena          NVARCHAR(MAX);
      END; -- inicio

      BEGIN -- �mbito de la actualizaci�n

        SET @cadena = 'SELECT 
							' + CAST(@status AS VARCHAR) + ' status, 
							' + @error_procedure + ' error_procedure, 
							' + @error_line + ' error_line, 
							' + @error_severity + ' error_severity, 
							' + @error_message + ' error_message, 
							 socios.NUMERO_SOCIO, 
							 socios.Nombre_Socio, 
							 socios.Tel_Celular,
							 No_alertas alertas
						FROM (
							SELECT	
								count(*) AS No_alertas,
								numero_socio, 
								concat(p.nombre_s+'' '',p.apellido_paterno+''  '',p.apellido_materno) AS Nombre_Socio, 
								p.Tel_Celular
							FROM 
								banca..TBL_BANCA_FRAUDE_ALERTA alerta
								INNER JOIN
								hape..persona p
								ON alerta.NUMERO_SOCIO=p.Numero
							WHERE
								p.Id_Tipo_Persona=1
								AND ID_ESTATUS = 1
							GROUP BY numero_socio,p.Tel_Celular,p.Nombre_s,p.Apellido_Paterno,p.Apellido_Materno
							)	AS socios';
        IF @FechaInicio IS NOT NULL
           AND @FechaFin IS NOT NULL
          BEGIN
            SET @cadena+=' WHERE 
							cast(socios.Fecha_Alerta as date) >= cast(' + @FechaInicio + '  AS date) AND 
							cast(socios.Fecha_Alerta AS date) <= cast(' + @FechaFin + ' as date)';
        END;
        ELSE
          IF @FechaInicio IS NULL
             AND @FechaFin IS NOT NULL
            BEGIN
              SET @cadena+=' WHERE 
							cast(socios.Fecha_Alerta AS date) <= cast(' + @FechaFin + ' as date)';
          END;
          ELSE
            IF @FechaInicio IS NOT NULL
               AND @FechaFin IS NULL
              BEGIN
                SET @cadena+=' WHERE 
							cast(socios.Fecha_Alerta as date) >= cast(' + @FechaInicio + '  AS date)';
            END;
		--SET @cadena+= ' GROUP BY socios.NUMERO_SOCIO';
		--SELECT @cadena;
        EXEC (@cadena);
      END; -- �mbito de la actualizaci�n

    END TRY -- try principal

    BEGIN CATCH -- catch principal
      -- captura del error
      SELECT 
        @status = -ERROR_STATE(), 
        @error_procedure = COALESCE(ERROR_PROCEDURE(), 'CONSULTA DIN�MICA'), 
        @error_line = ERROR_LINE(), 
        @error_message = ERROR_MESSAGE(), 
        @error_severity = CASE ERROR_SEVERITY()
                            WHEN 11
                              THEN 'Error en validaci�n'
                            WHEN 12
                              THEN 'Error en consulta'
                            WHEN 13
                              THEN 'Error en actualizaci�n'
                          ELSE 'Error general'
                          END;
    END CATCH; -- catch principal

  END; -- procedimiento

GO
GRANT EXEC ON SP_BANCA_FRAUDE_NVA_ALERTA TO public;
go

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_TELEFONO_DUPLICADO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_TELEFONO_DUPLICADO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_TELEFONO_DUPLICADO
go

/*

Autor			Luis Arturo G�lvez Macias
UsuarioRed		GAML841262
Fecha			20190903
Objetivo		Detecci�n de numero de celular  duplicados entre los socios con el servicio activo de CMV finanazas
Proyecto		Modulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_TELEFONO_DUPLICADO
	
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
			end -- inicio
			
			begin -- �mbito de la actualizaci�n
		 ----------------Se obtienen los n�meros de socios que tienen el mismo numero de tel�fono
						select 
							pers.Numero,
							substring(pers.Tel_Celular,1,10) as Num_Celular
						into #TelefonoDuplicado
						from HAPE.dbo.PERSONA pers 
						inner join BANCA.dbo.TBL_BANCA_SOCIOS bsocios on pers.Numero = BANCA.dbo.FN_BANCA_DESCIFRAR(bsocios.numero_socio) and pers.Id_Tipo_Persona = 1 and pers.Tel_Celular is not null and bsocios.banca_activa=1		
						inner join(select count(1) conteo ,Tel_Celular from HAPE.dbo.persona
							where Id_Tipo_Persona = 1
							group by Tel_Celular
							having count(1)>1)tel_celular
						on pers.Tel_Celular = tel_celular.Tel_Celular						
						order by pers.Tel_Celular

		----------------select * from #TelefonoDuplicado
		----------------Se insertan los n�meros que cumplen con la alerta
						insert into TBL_BANCA_FRAUDE_ALERTA (Fecha_Alerta,NUMERO_SOCIO,Id_tipo_Alerta,Id_alerta_recurrente,id_estatus)
						SELECT cast(GETDATE()as date), Numero,8,0,1
							from #TelefonoDuplicado
						WHERE	
						Numero not in (select numero_socio from banca..TBL_BANCA_FRAUDE_ALERTA where ID_TIPO_ALERTA=8 and Cast(Fecha_Alerta as date)= cast(DATEADD(DAY,-1,GETDATE()) as date))
						group by Numero

		----------------Se inserta en la bit�cora de operaciones
						insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES (Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus)
						select distinct
							alerta.NUMERO_SOCIO,
							9 Id_Tipo_Bitacoras_Fraudes,
							GETDATE(),
							(select Descripcion_Bitacoras_Fraudes from banca..CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE where id_Tipo_Bitacoras_fraudes=9)Descripcion_Bitacoras_Fraudes,
							alerta.ID_ESTATUS
						from banca..TBL_BANCA_FRAUDE_ALERTA alerta 
						where 
						alerta.ID_TIPO_ALERTA = 8
						and alerta.ID_ESTATUS = 1 

		----------------Se eliminan tabla temporales
		  				Drop table #TelefonoDuplicado
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_TELEFONO_DUPLICADO to public

go

USE BANCA;
GO

-- se crea procedimiento SP_BANCA_FRAUDE_VER_DATOS_PARA_MODAL
IF EXISTS
(
  SELECT 
    *
  FROM sysobjects
  WHERE name LIKE 'SP_BANCA_FRAUDE_VER_DATOS_PARA_MODAL'
        AND xtype = 'p'
        AND DB_NAME() = 'BANCA'
)
  DROP PROC 
    SP_BANCA_FRAUDE_VER_DATOS_PARA_MODAL;
GO

/*********************************************************************************************************
Autor			Luis Arturo G�lvez Macias
UsuarioRed		GAML841262
Fecha			20191022
Objetivo		Ver las alertas de que tiene el socio donde se pueda  obtener  el folio de la  alerta y el tipo 
Proyecto		Modulo de Fraudes
Ticket			ticket
*********************************************************************************************************/

CREATE PROC SP_BANCA_FRAUDE_VER_DATOS_PARA_MODAL 
  @Numero_Socio INT, 
  @folioAlerta  INT
AS
  BEGIN -- procedimiento

    BEGIN TRY -- try principal

      BEGIN -- inicio
        -- declaraciones
        DECLARE 
          @status          INT          = 1, 
          @error_message   VARCHAR(255) = '', 
          @error_line      VARCHAR(255) = '', 
          @error_severity  VARCHAR(255) = '', 
          @error_procedure VARCHAR(255) = '';
      END; -- inicio

      BEGIN -- �mbito de la actualizaci�n

        SELECT 
          @status STATUS, 
          @error_procedure error_procedure, 
          @error_line error_line, 
          @error_severity error_severity, 
          @error_message error_message, 
          *
        FROM TBL_BANCA_FRAUDE_ALERTA
        WHERE numero_socio = @Numero_Socio
              AND folio_alerta = @folioAlerta
              AND ID_ESTATUS = 1;
      END; -- �mbito de la actualizaci�n

    END TRY -- try principal

    BEGIN CATCH -- catch principal
      -- captura del error
      SELECT 
        @status = -ERROR_STATE(), 
        @error_procedure = COALESCE(ERROR_PROCEDURE(), 'CONSULTA DIN�MICA'), 
        @error_line = ERROR_LINE(), 
        @error_message = ERROR_MESSAGE(), 
        @error_severity = CASE ERROR_SEVERITY()
                            WHEN 11
                              THEN 'Error en validaci�n'
                            WHEN 12
                              THEN 'Error en consulta'
                            WHEN 13
                              THEN 'Error en actualizaci�n'
                          ELSE 'Error general'
                          END;
    END CATCH; -- catch principal

  END; -- procedimiento

GO
GRANT EXEC ON SP_BANCA_FRAUDE_VER_DATOS_PARA_MODAL TO public;
go

use banca
go

-- se crea procedimiento SP_BANCA_FRAUDE_VER_SOCIOS_BLOQUEADOS
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_VER_SOCIOS_BLOQUEADOS' and xtype = 'p' and db_name() = 'banca')
	drop proc SP_BANCA_FRAUDE_VER_SOCIOS_BLOQUEADOS
go

/*

Autor			Luis Arturo G�lvez Macias
UsuarioRed		GAML841262
Fecha			20190919
Objetivo		Desbloquear a los socios que  fueron alertados por posibles movimientos fraudulentos
Proyecto		Modulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_VER_SOCIOS_BLOQUEADOS

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
					
			end -- inicio
			
			begin -- transacci�n

				begin -- componente de la transacci�n
				
					--if exists(select * from TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS )
					--	delete socio_desbloqueados
					--	from  TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS socio_desbloqueados
					--	inner join TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO socio_alertado on socio_alertado.Numero_Socio = socio_desbloqueados.Numero_Socio

					if not exists (select * from TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS)
						insert into TBL_BANCA_FRAUDES_NOTIFICACION_SOCIOS_DESBLOQUEADOS(
							Id_Motivo_Bloqueo,Numero_Socio,Nombre_Socio,Tel_Celular,Mail,Id_tipo_notificacion)
						select distinct 
							bsocios.id_motivo_bloqueo,
							BANCA.dbo.FN_BANCA_DESCIFRAR(bsocios.numero_socio),
							P.Nombre_s+' '+P.Apellido_Paterno +' '+P.Apellido_Materno as Nombre_Socio,
							P.Tel_Celular,
							P.Mail,
							socio_alertado.id_tipo_notificacion					
						from TBL_BANCA_SOCIOS bsocios
						inner join HAPE..PERSONA P on BANCA.dbo.FN_BANCA_DESCIFRAR(bsocios.numero_socio) =P.Numero
						inner join TBL_BANCA_FRAUDES_NOTIFICACION_SMS_EMAIL_SOCIO_ALERTADO socio_alertado on socio_alertado.Numero_Socio = BANCA.dbo.FN_BANCA_DESCIFRAR(bsocios.numero_socio)
						where 
							bsocios.banca_activa =1
							and bsocios.id_motivo_bloqueo=13
							and P.Id_Tipo_Persona =1 
				
				end -- componente de la transacci�n
				
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
								
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,
					  BANCA.dbo.FN_BANCA_DESCIFRAR(bsocios.numero_socio) as Numero_Socio,
					P.Nombre_s+''+P.Apellido_Paterno+'' +P.Apellido_Materno AS Nombre_Socio,
					P.Tel_celular
					from TBL_BANCA_SOCIOS bsocios
					inner join TBL_BANCA_FRAUDE_ALERTA alerta on alerta.NUMERO_SOCIO = BANCA.dbo.FN_BANCA_DESCIFRAR(bsocios.numero_socio)
					inner join HAPE..PERSONA P on P.Numero = BANCA.dbo.FN_BANCA_DESCIFRAR(bsocios.numero_socio) 
					where 
						 bsocios.banca_activa=1
						and bsocios.id_motivo_bloqueo = 13
						and ID_ESTATUS in (3)
						and alerta.id_tipo_alerta in (1,2,5,6)
						and Id_Tipo_Persona = 1 
					group by BANCA.dbo.FN_BANCA_DESCIFRAR(bsocios.numero_socio),P.Tel_Celular, P.Nombre_s+''+P.Apellido_Paterno+'' +P.Apellido_Materno
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDE_VER_SOCIOS_BLOQUEADOS to public
go

USE BANCA;
GO

-- se crea procedimiento SP_BANCA_FRAUDES_CONSULTA_REPORTES
IF EXISTS
(
  SELECT 
    *
  FROM sysobjects
  WHERE name LIKE 'SP_BANCA_FRAUDES_CONSULTA_REPORTES'
        AND xtype = 'p'
        AND DB_NAME() = 'BANCA'
)
  DROP PROC 
    SP_BANCA_FRAUDES_CONSULTA_REPORTES;
GO

/************************************************************
Autor			Claudia Alejandra Arredondo Rodr�guez
UsuarioRed		AERC864420
Fecha			20191106
Objetivo		Obtener listas de reportes 
Proyecto		Banca Electr�nica, Divisi�n de Fraudes Electr�nicos
Ticket			ticket
************************************************************/

CREATE PROC SP_BANCA_FRAUDES_CONSULTA_REPORTES 
  @Tipo        INT, -- 1 para administraci�n de reportes, 2 para consulta de alertas atendidas, 3 reportes canalizados
  @FechaInicio DATETIME = NULL, 
  @FechaFin    DATETIME = NULL
-- parametros
-- [aqu� van los par�metros]

AS
  BEGIN -- procedimiento

    BEGIN TRY -- try principal

      BEGIN -- inicio
        -- declaraciones
        DECLARE 
          @status          INT          = 1, 
          @error_message   VARCHAR(255) = '', 
          @error_line      VARCHAR(255) = '', 
          @error_severity  VARCHAR(255) = '', 
          @error_procedure VARCHAR(255) = '';
      END; -- inicio

      BEGIN -- �mbito de la actualizaci�n

        IF(@Tipo = 1)
          IF(@FechaInicio IS NULL
             AND @FechaFin IS NOT NULL)
            SELECT 
              *
            FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
            WHERE Fecha_Atencion <= @FechaFin;
          ELSE
            IF(@FechaFin IS NULL
               AND @FechaInicio IS NOT NULL)
              SELECT 
                *
              FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
              WHERE Fecha_Atencion >= @FechaInicio;
            ELSE
              IF(@FechaFin IS NULL
                 AND @FechaInicio IS NULL)
                SELECT 
                  *
                FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES;
              ELSE
                SELECT 
                  *
                FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                WHERE Fecha_Atencion BETWEEN @FechaInicio AND @FechaFin;
        ELSE
          IF(@Tipo = 2)
            IF(@FechaInicio IS NULL
               AND @FechaFin IS NOT NULL)
              SELECT 
                *
              FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
              WHERE Fecha_Atencion <= @FechaFin
                    AND Id_Canalizacion = 2;
            ELSE
              IF(@FechaFin IS NULL
                 AND @FechaInicio IS NOT NULL)
                SELECT 
                  *
                FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                WHERE Fecha_Atencion >= @FechaInicio
                      AND Id_Canalizacion = 2;
              ELSE
                IF(@FechaFin IS NULL
                   AND @FechaInicio IS NULL)
                  SELECT 
                    *
                  FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                  WHERE Id_Canalizacion = 2;
                ELSE
                  SELECT 
                    *
                  FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                  WHERE Fecha_Atencion BETWEEN @FechaInicio AND @FechaFin
                        AND Id_Canalizacion = 2;
          ELSE
            IF(@Tipo = 3)
              IF(@FechaInicio IS NULL
                 AND @FechaFin IS NOT NULL)
                SELECT 
                  *
                FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                WHERE Fecha_Atencion <= @FechaFin
                      AND Id_Canalizacion = 3;
              ELSE
                IF(@FechaFin IS NULL
                   AND @FechaInicio IS NOT NULL)
                  SELECT 
                    *
                  FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                  WHERE Fecha_Atencion >= @FechaInicio
                        AND Id_Canalizacion = 3;
                ELSE
                  IF(@FechaFin IS NULL
                     AND @FechaInicio IS NULL)
                    SELECT 
                      *
                    FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                    WHERE Id_Canalizacion = 3;
                  ELSE
                    SELECT 
                      *
                    FROM TBL_BANCA_FRAUDE_ADMINISTRACION_REPORTES
                    WHERE Fecha_Atencion BETWEEN @FechaInicio AND @FechaFin
                          AND Id_Canalizacion = 3;
      END; -- �mbito de la actualizaci�n

    END TRY -- try principal

    BEGIN CATCH -- catch principal
      -- captura del error
      SELECT 
        @status = -ERROR_STATE(), 
        @error_procedure = COALESCE(ERROR_PROCEDURE(), 'CONSULTA DIN�MICA'), 
        @error_line = ERROR_LINE(), 
        @error_message = ERROR_MESSAGE(), 
        @error_severity = CASE ERROR_SEVERITY()
                            WHEN 11
                              THEN 'Error en validaci�n'
                            WHEN 12
                              THEN 'Error en consulta'
                            WHEN 13
                              THEN 'Error en actualizaci�n'
                          ELSE 'Error general'
                          END;
    END CATCH; -- catch principal

    BEGIN -- reporte de estatus

      SELECT 
        @status STATUS, 
        @error_procedure error_procedure, 
        @error_line error_line, 
        @error_severity error_severity, 
        @error_message error_message;
    END; -- reporte de estatus

  END; -- procedimiento

GO
GRANT EXEC ON SP_BANCA_FRAUDES_CONSULTA_REPORTES TO public;
go

use banca
go

-- se crea procedimiento SP_BANCA_FRAUDES_DEPURACION_ALERTAS_BAJA_SERVICIO
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_DEPURACION_ALERTAS_BAJA_SERVICIO' and xtype = 'p' and db_name() = 'banca')
	drop proc SP_BANCA_FRAUDES_DEPURACION_ALERTAS_BAJA_SERVICIO
go

/*

Autor			LAGM
UsuarioRed		GAML841262
Fecha			20191011
Objetivo		Eliminar las alertas del socio cuando de baja el servicio de banca cuando son alertas no transaccionales
Proyecto		Modulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_DEPURACION_ALERTAS_BAJA_SERVICIO
	@Numero_Socio INT,
	@Num_usuario int 

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
				declare	@tran_name varchar(32) = 'Elminar_alertas_No_Transaccionales',
						@tran_count int = @@trancount,
						@tran_scope bit = 0,
						@Id_cancelacion int,
						@descancelacion_Servico varchar(900)

			end -- inicio
						
			begin -- transacci�n

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio
				
				begin -- componente de la transacci�n
				
					delete  alerta		
					from TBL_BANCA_FRAUDE_ALERTA alerta 
					inner join TBL_BANCA_SOCIOS bsocios on BANCA.dbo.FN_BANCA_DESCIFRAR(bsocios.numero_socio) = alerta.NUMERO_SOCIO
					where bsocios.banca_activa = 0
					and alerta.ID_TIPO_ALERTA in (3,4,7,8)
					and alerta.ID_ESTATUS = 1 
					and alerta.numero_socio = @Numero_Socio

					select @Id_cancelacion=id_Tipo_Bitacoras_fraudes, @descancelacion_Servico =Descripcion_Bitacoras_Fraudes
					from CAT_BANCA_FRAUDE_TIPOS_BITACORA_FRAUDE
					where id_Tipo_Bitacoras_fraudes = 10
				
					insert into TBL_BANCA_FRAUDE_BITACORA_OPERACIONES(Numero_Socio,Id_Tipo_Bitacoras_Fraudes,Fecha_alta,Evento,Estatus,usuario)
					select alerta.Numero_Socio,
						@Id_cancelacion,
						GETDATE(),
						@descancelacion_Servico,
						1,
						@Num_usuario
					from TBL_BANCA_FRAUDE_ALERTA alerta
					where alerta.NUMERO_SOCIO = @Numero_Socio
					group by Numero_Socio
				
				
				end -- componente de la transacci�n
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
						
			-- revertir transacci�n si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_FRAUDES_DEPURACION_ALERTAS_BAJA_SERVICIO to public
go

USE BANCA;
GO

-- se crea procedimiento SP_BANCA_FRAUDES_OBTENER_ALERTA_POR_NUMERO_SOCIO
IF EXISTS
(
  SELECT 
    *
  FROM sysobjects
  WHERE NAME LIKE 'SP_BANCA_FRAUDES_OBTENER_ALERTA_POR_NUMERO_SOCIO'
        AND xtype = 'p'
        AND DB_NAME() = 'BANCA'
)
  BEGIN
    DROP PROC 
      SP_BANCA_FRAUDES_OBTENER_ALERTA_POR_NUMERO_SOCIO;
END;
GO

/******************************************************
Autor			Sabdi Abraham Pantoja Orozco
UsuarioRed		paos845568
Fecha			3/Enero/2019
Objetivo		Obtener la alerta que bloquea a dicho usuario
Proyecto		Banca Fraudes
Ticket			ticket
******************************************************/

CREATE PROC SP_BANCA_FRAUDES_OBTENER_ALERTA_POR_NUMERO_SOCIO
-- parametros
  @numeroSocio INTEGER
-- [aqu� van los par�metros]
AS
  BEGIN -- procedimiento
    BEGIN TRY -- try principal	
      BEGIN -- inicio
        -- declaraciones
        DECLARE 
          @status          INT          = 1, 
          @error_message   VARCHAR(255) = '', 
          @error_line      VARCHAR(255) = '', 
          @error_severity  VARCHAR(255) = '', 
          @error_procedure VARCHAR(255) = '';

        -- valores por defecto
      END; -- inicio

      BEGIN -- validaciones
        IF
        (
          SELECT 
            id_motivo_bloqueo
          FROM TBL_BANCA_SOCIOS
          WHERE banca.dbo.fn_banca_descifrar(numero_socio) = @numeroSocio
        ) = 1
          BEGIN
            RAISERROR('Socio no se encuentra bloqueado', 11, 0);
        END;
      END; -- validaciones

      BEGIN -- �mbito de la actualizaci�n
        IF EXISTS
        (
          SELECT TOP 1 
            *
          FROM TBL_BANCA_FRAUDE_ALERTA AS alerta
               INNER JOIN hape..persona p ON alerta.numero_socio = p.Numero
          WHERE numero_socio = @numeroSocio
                AND id_tipo_alerta IN(1, 2, 5, 6)
               AND id_estatus = 1
        )
          SELECT TOP 1 
            *
          FROM TBL_BANCA_FRAUDE_ALERTA AS alerta
               INNER JOIN hape..persona p ON alerta.numero_socio = p.Numero
          WHERE numero_socio = @numeroSocio
                AND id_tipo_alerta IN(1, 2, 5, 6)
               AND id_estatus = 1;
        ELSE
          SELECT TOP 1 
            *
          FROM TBL_BANCA_FRAUDE_ALERTA AS alerta
               INNER JOIN hape..persona p ON alerta.numero_socio = p.Numero
          WHERE numero_socio = @numeroSocio
                AND id_estatus = 1;
      END; -- �mbito de la actualizaci�n
    END TRY -- try principal

    BEGIN CATCH -- catch principal
      -- captura del error
      SELECT 
        @status = -ERROR_STATE(), 
        @error_procedure = COALESCE(ERROR_PROCEDURE(), 'CONSULTA DIN�MICA'), 
        @error_line = ERROR_LINE(), 
        @error_message = ERROR_MESSAGE(), 
        @error_severity = CASE ERROR_SEVERITY()
                            WHEN 11
                              THEN 'Error en validaci�n'
                            WHEN 12
                              THEN 'Error en consulta'
                            WHEN 13
                              THEN 'Error en actualizaci�n'
                          ELSE 'Error general'
                          END;
    END CATCH; -- catch principal
  END; -- procedimiento	
GO
GRANT EXEC ON SP_BANCA_FRAUDES_OBTENER_ALERTA_POR_NUMERO_SOCIO TO PUBLIC;
go

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDES_OBTENER_MOVIMIENTOS_ALERTA
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_OBTENER_MOVIMIENTOS_ALERTA' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_OBTENER_MOVIMIENTOS_ALERTA
go

/*

Autor			Claudia Alejandra Arredondo Rodr�guez
UsuarioRed		AERC864420
Fecha			20191122
Objetivo		Obtener los movimientos que generaron una alerta
Proyecto		Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_OBTENER_MOVIMIENTOS_ALERTA
	@numero_socio int,
	@folio_alerta int
	--@tipo_alerta int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						--@numero_socio int = 22910,
						--@folio_alerta int =  13851

				create table #trans (
					folio int,
					importe money,
					fecha_transaccion datetime,
					plataforma varchar(10),
					destino varchar(30),
					tipo_transferencia bit -- 0 internas, 1 externas
				)
							
			end -- inicio

			
			begin -- �mbito de la actualizaci�n 

				insert into #trans
				select movs.folio_movimiento, internas.monto, internas.fecha_transferencia_realizada, cat.descripcion,internas.clave_corresponsalias_destino, 0
				from tbl_banca_fraude_movimientos movs
					inner join tbl_banca_transferencias_internas internas on internas.id_banca_folio = movs.folio_movimiento
					inner join HAPE..MOVIMIENTOS hmov on hmov.Folio = internas.id_banca_folio and hmov.numero = @numero_socio
					inner join CAT_BANCA_ORIGEN_OPERACION cat on cat.id_origen_operacion = hmov.id_origen
				where BANCA.dbo.FN_BANCA_DESCIFRAR(internas.numero_socio) = @numero_socio and movs.id_alerta = @folio_alerta

				union

				select movs.folio_movimiento, ext.monto, ext.fecha_transferencia_realizada, cat.descripcion, ext.clabe_spei_destino, 1
				from tbl_banca_fraude_movimientos movs
					inner join TBL_BANCA_TRANSFERENCIAS_EXTERNAS ext on ext.id_banca_folio = movs.folio_movimiento
					inner join HAPE..MOVIMIENTOS hmov on hmov.Folio = ext.id_banca_folio and hmov.numero = @numero_socio
					inner join CAT_BANCA_ORIGEN_OPERACION cat on cat.id_origen_operacion = hmov.id_origen
				where BANCA.dbo.FN_BANCA_DESCIFRAR(ext.numero_socio) = @numero_socio and movs.id_alerta = @folio_alerta

				select @status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,
					@numero_socio numero_socio,
					* from #trans

				drop table #trans					
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
				
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDES_OBTENER_MOVIMIENTOS_ALERTA to public
go

use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDES_VER_SOCIOS_ALERTADOS_NOTIFICACION
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDES_VER_SOCIOS_ALERTADOS_NOTIFICACION' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDES_VER_SOCIOS_ALERTADOS_NOTIFICACION
go

/*

Autor			Luis Arturo G�lvez Macias
UsuarioRed		gaml841262
Fecha			20191004
Objetivo		ver los socios que necesitan ser notificados del bloqueo de sus cuentas
Proyecto		Modulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDES_VER_SOCIOS_ALERTADOS_NOTIFICACION
	
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''

			end -- inicio
			
			begin -- �mbito de la actualizaci�n
			
				select	distinct 
					@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,				 
					Alerta.Numero_socio,
					P.Nombre_s+''+P.Apellido_Paterno+''+Apellido_Materno as Nombre_Socio,
					P.Tel_celular,
					P.Mail,
					contrato.id_tipo_notificacion,
					1 as Id_Tipo_Bitacoras_Fraudes,
					bitaope.Id_Bitacora_Fraude
				from Tbl_banca_fraude_alerta alerta
					inner join hape..PERSONA P on P.numero=alerta.numero_Socio
					inner join BANCA..TBL_BANCA_SOCIOS bsocios on BANCA.dbo.FN_BANCA_DESCIFRAR(bsocios.numero_socio) = alerta.NUMERO_SOCIO
					inner join HAPE..TBL_CONTRATOS_HABERES contrato on alerta.numero_socio = contrato.numero
					inner join BANCA..TBL_BANCA_FRAUDE_BITACORA_OPERACIONES bitaope on bitaope.Numero_Socio = alerta.NUMERO_SOCIO
				where contrato.id_tipo_contrato = 3 
					and contrato.id_tipo_persona = 1 
					and bsocios.banca_activa = 1
					and bsocios.id_motivo_bloqueo in (13,14)
					and alerta.id_estatus = 1
					and P.Id_Tipo_Persona = 1
					and id_tipo_notificacion is not null
					and bitaope.usuario is null
					and alerta.id_tipo_alerta in (1,2,5,6)	
				group by alerta.NUMERO_SOCIO,P.Nombre_s,P.Apellido_Paterno,Apellido_Materno,P.Tel_celular,P.Mail,contrato.id_tipo_notificacion,bitaope.Id_Bitacora_Fraude
	
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDES_VER_SOCIOS_ALERTADOS_NOTIFICACION to public
go

/***Triggers de fraudes***/
USE BANCA
GO

--Trigger Transferencia interna
if exists(SELECT * FROM sys.triggers WHERE name = 'AlertaRecurrente')
begin
	drop trigger AlertaRecurrente
end
go

CREATE TRIGGER AlertaRecurrente
    ON [BANCA].dbo.[TBL_BANCA_TRANSFERENCIAS_INTERNAS]
    AFTER INSERT
    AS
    BEGIN
    SET NOCOUNT ON

	    declare @numero_socio int

		select @numero_socio=BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) from BANCA.dbo.TBL_BANCA_TRANSFERENCIAS_INTERNAS 
        where id_transferencia=(select max(id_transferencia) from TBL_BANCA_TRANSFERENCIAS_INTERNAS)
		
		EXEC SP_BANCA_FRAUDE_ALERTA_RECURRENTE @numero_socio
    END
GO


--Trigger Transferencia externa

if exists(SELECT * FROM sys.triggers WHERE name = 'AlertaRecurrenteExterna')
begin
	drop trigger AlertaRecurrenteExterna
end
go

CREATE TRIGGER AlertaRecurrenteExterna
    ON [BANCA].dbo.[TBL_BANCA_TRANSFERENCIAS_EXTERNAS]
    AFTER INSERT
    AS
    BEGIN
    SET NOCOUNT ON

	    declare @numero_socio int

		select @numero_socio=BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) from BANCA.dbo.TBL_BANCA_TRANSFERENCIAS_EXTERNAS 
        where id_transferencia=(select max(id_transferencia) from TBL_BANCA_TRANSFERENCIAS_EXTERNAS)
		
		EXEC SP_BANCA_FRAUDE_ALERTA_RECURRENTE @numero_socio
    END
