USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTIVAR_BANCA]    Script Date: 21/11/2019 11:17:32 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[SP_BANCA_ACTIVAR_BANCA]
@NUMERO AS VARCHAR(20),
@NuevaContrasena varchar(100),
@ContrasenaConfirmada varchar(100),
@IdPregunta int, 
@respuesta varchar(max),
@idImagenAntiphishing int,
@tipoOrigen int
AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int,
@numero_int int,
@Nombre_Completo varchar(250),
@id_tipo_bitacora int  = 3 --Activar Banca

select @mensaje_validacion =msj ,@estatus = estatus  from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,0)

  if(@mensaje_validacion is  null )
  BEGIN
  SET @numero_int = CAST(@NUMERO as int )
		-- VALIDACIONES --
			
			IF(@NuevaContrasena <> @ContrasenaConfirmada)
			BEGIN
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 308
				RETURN
			END
			IF NOT EXISTS (SELECT 1 FROM CAT_BANCA_PREGUNTAS_SECRETAS WHERE id_pregunta_secreta = @IdPregunta)
			BEGIN
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 307
				RETURN 
			END
			IF EXISTS (SELECT 1 FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int 
				and banca_activa = 1 
				AND id_estatus_banca not in(4)
				)
			BEGIN
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 309
				RETURN 
			END 
			IF EXISTS(
				SELECT * FROM(
				SELECT TOP 3 * FROM BANCA..TBL_BANCA_CONTRASENAS_SOCIO WHERE numero_socio = @numero_int
				ORDER BY fecha_alta DESC
				)CONTRA_ULTIMAS_3
				WHERE
					CONTRA_ULTIMAS_3.contrasena = @NuevaContrasena

			) or exists (select 1  from TBL_BANCA_SOCIOS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) =  @numero_int and contrasena = @NuevaContrasena)
			BEGIN
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 386
				RETURN
			END

		-- FIN DE VALIDACIONES --

		update TBL_BANCA_SOCIOS 
			set contrasena = @ContrasenaConfirmada,
			    id_estatus_banca = 6 ,
				banca_activa = 1,
				id_motivo_bloqueo = 1,
				fecha_alta_contrasena=getdate(),
				id_imagen_antiphishing = @idImagenAntiphishing,
				respuesta = @respuesta,
				id_pregunta_secreta = @IdPregunta
		where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int

		insert into BANCA..TBL_BANCA_CONTRASENAS_SOCIO (numero_socio, contrasena,fecha_alta) 
		values (@numero_int, @ContrasenaConfirmada, GETDATE());

		CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));
		INSERT INTO #Bitacora
		EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero, @id_tipo_bitacora, @tipoOrigen

		

		select @Nombre_Completo =
			ISNULL(Nombre_s,'')+' '+ISNULL(Apellido_Paterno,'')+' '+ISNULL(Apellido_Materno,'')
		from TBL_BANCA_SOCIOS S JOIN
			 HAPE..PERSONA P  ON BANCA.dbo.FN_BANCA_DESCIFRAR(S.numero_socio) = P.Numero AND P.Id_Tipo_Persona = 1
		 where Numero = @numero_int and Id_Tipo_Persona = 1

		 select *,@Nombre_Completo Nombre_Completo from #Bitacora


  END
  ELSE
	  SELECT 300 AS estatus , @mensaje_validacion mensaje



end try
begin catch
	select -1 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZA_BLOQUEO_OTP]    Script Date: 15/08/2019 04:45:07 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		EDSON
-- Create date: 2018-09-10
-- Description:	
--@Tipo_Bloqueo_OTP :	
--			Resetear la fecha de bloqueo de OTP = 1,
--			Colocar la fecha de bloqueo de OTP = 2
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_ACTUALIZA_BLOQUEO_OTP]
	@numero_socio varchar(20),
	@Tipo_Bloqueo_OTP int
AS
BEGIN

begin try

	DECLARE 
	@mensaje_validacion varchar(500),
	@estatus int , 
	@numero_int int,
	@id_tipo_bitacora int  = null,
	@fecha_bloqueo_OTP datetime = null,
	@minutos_restantes int =0

	select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@numero_socio,1)
	set @numero_int = CAST(@numero_socio as int )

	IF(@mensaje_validacion is null)
	BEGIN

			UPDATE TBL_BANCA_SOCIOS
			SET	
				fecha_bloqueo_OTP = 
					case 
						when @Tipo_Bloqueo_OTP = 1 then null 
						when @Tipo_Bloqueo_OTP = 2 and fecha_bloqueo_OTP is null then GETDATE() 
						when @Tipo_Bloqueo_OTP = 2 and fecha_bloqueo_OTP is not null then fecha_bloqueo_OTP 
					end
			WHERE 
				BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int

		select @fecha_bloqueo_OTP = fecha_bloqueo_OTP from TBL_BANCA_SOCIOS WHERE BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int
		select @minutos_restantes = (10-(DATEDIFF(SECOND,@fecha_bloqueo_OTP,getdate())/60))

		IF @minutos_restantes < 0 and @Tipo_Bloqueo_OTP = 2
		BEGIN
			UPDATE TBL_BANCA_SOCIOS
			SET	
				fecha_bloqueo_OTP = GETDATE() 
			WHERE 
				BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int

			select @minutos_restantes = 10
		END

		SELECT @estatus = 200, 
		@mensaje_validacion = 
			case
				when @Tipo_Bloqueo_OTP = 1 then 'Reseteo de bloqueo por OTP'
				when @Tipo_Bloqueo_OTP = 2 then (SELECT  descripcion+'|'+CAST( @minutos_restantes as varchar) +''
												FROM CAT_BANCA_EXCEPTIONS
												WHERE id_excepcion = 390)
			end

	END
	ELSE
		SELECT @estatus AS estatus , @mensaje_validacion mensaje

end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 	 		
end catch

	SELECT @estatus AS estatus , @mensaje_validacion mensaje
	
END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZA_ESTATUS]    Script Date: 15/08/2019 04:46:17 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			MAXIMILIANO GONZALEZ BETANCOURT
UsuarioRed		GOBM391548
Fecha			20180417
Objetivo		ACTUALIZA ESTATUS DEL SOCIO DE ACUERDO A CAT_BANCA_ESTATUS_BANCA
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_ACTUALIZA_ESTATUS]
	
		-- par�metros
		
		-- [aqu� van los par�metros]
    @Numero varchar(20),
	@Estatus int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@descripcion_estatus varchar(255),
						@validacion varchar(255)
			
			end -- inicio
			
			

				--VALIDACIONES
				select @status = estatus, @validacion = msj from dbo.FN_BANCA_VALIDA_SOCIO (@Numero,1)	
				IF @validacion is not null 
				begin
					select @error_message = @validacion
					GOTO SALIR;
					--select @error_message as error_message, @status as status
				end
				
				IF @Estatus NOT IN (SELECT id_estatus_banca FROM CAT_BANCA_ESTATUS_BANCA)
				BEGIN
					SELECT id_excepcion AS estatus , descripcion as mensaje 
					FROM CAT_BANCA_EXCEPTIONS
					WHERE id_excepcion = 306
					print 'estatus not in'
					GOTO SALIR;
					--select @error_message as error_message, @status as status
				END

				declare
				@estatusActualBanca int

				Select @estatusActualBanca = id_estatus_banca from TBL_BANCA_SOCIOS WHERE BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = CAST(@Numero AS int)
				
				IF @Estatus <> 8
				BEGIN
					IF @Estatus <= @estatusActualBanca
					BEGIN
						SELECT @status = id_excepcion , @error_message = descripcion 
						FROM CAT_BANCA_EXCEPTIONS
						WHERE id_excepcion = 306
						print 'estatus menor q estatus  actual'
						GOTO SALIR;
					END
				END

				UPDATE TBL_BANCA_SOCIOS SET id_estatus_banca = @Estatus WHERE BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = CAST(@Numero AS int)
				if @@ERROR = 0
				begin 
							
						select @error_message = 'Se actualizo el socio correctamente',@status = 200
						GOTO SALIR;
						--select @error_message as error_message, @status as status
				end
				else
				begin
						select @error_message = 'Error al actualizar el estatus del socio',@status = 1000
						GOTO SALIR;
						--select @error_message as error_message, @status as status
				end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@status=1000
			select @error_message as mensaje, @status as estatus
			return
		
		end catch -- catch principal
		
		SALIR:
			select @error_message as mensaje, @status as estatus
		return
		
	end -- procedimiento
	go

	USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZA_ESTATUS_DOMICILIACION]    Script Date: 15/08/2019 04:47:22 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_ACTUALIZA_ESTATUS_DOMICILIACION]
@numeroSocio AS VARCHAR(20),
@idDomiciliacion bigint,
@idOrigenOperacion int ,
@estatusDomi bit = 0

AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int,
@numero_int int,
@Folio bigint
select @mensaje_validacion =msj ,@estatus = estatus  from  dbo.FN_BANCA_VALIDA_SOCIO(@numeroSocio,0)

  if(@mensaje_validacion is  null )
  BEGIN
  SET @numero_int = CAST(@numeroSocio as int )
		-- VALIDACIONES --
		-- FIN DE VALIDACIONES -
	IF EXISTS (SELECT 1 FROM TBL_BANCA_DOMICILIACIONES  WHERE BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int and id_domiciliacion =  @idDomiciliacion and activo = 1)
	BEGIN

		    INSERT INTO TBL_BANCA_BITACORA_OPERACIONES(id_tipo_bitacora,numero_socio,fecha_alta,id_origen_operacion)
			values(28,@numero_int,getdate(),@idOrigenOperacion)

			SELECT @Folio  =  MAX(id_bitacora) FROM TBL_BANCA_BITACORA_OPERACIONES
			WHERE numero_socio = @numero_int AND id_tipo_bitacora = 28
			
			update TBL_BANCA_DOMICILIACIONES  set activo = @estatusDomi , folio_cancelacion = @Folio
			WHERE BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int and id_domiciliacion =  @idDomiciliacion
			SELECT 200 estatus,  'OK' mensaje
	END
	ELSE
	BEGIN
		SELECT id_excepcion AS estatus , descripcion as mensaje 
		FROM CAT_BANCA_EXCEPTIONS
		WHERE id_excepcion = 373

	END
  END
  ELSE
	  SELECT 300 AS estatus , @mensaje_validacion mensaje
end try
begin catch
	select -1 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
GO

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZA_ESTATUS_PAGO_SERVICIO]    Script Date: 23/01/2020 11:51:41 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Mar Mej�a Murillo
UsuarioRed		memm373565
Fecha			20180607
Objetivo		Actualiza el estatus de una transferencia interna dado su id_transferencia
Proyecto		Banca en l�nea
Ticket			______

*/

ALTER proc
	[dbo].[SP_BANCA_ACTUALIZA_ESTATUS_PAGO_SERVICIO]
	
		@idBancaFolio			bigint,
		@codigo		int,
		@folioAutorizacion		varchar(100),
		@mensaje		varchar(5000),
		@pin		varchar(50) = null,
		@monto money,
		@request varchar(max),
		@response varchar(max),
		@signed varchar(max) = null,
		@tipoOrigen int = null,
		@estatusTransferencia int = null
		
as

	begin -- procedimiento

		begin try -- try principal

			begin -- inicio

				begin -- declaraciones

					declare @status int = 200,
							@error_message varchar(255) = '',
							@error_line varchar(255) = '',
							@error_severity varchar(255) = '',
							@error_procedure varchar(255) = '',
							
								
							@tran_name varchar(32) = 'SP_BANCA_ACTUALIZA_ESTATUS_PAGO_SERVICIO',
							@tran_count int = @@trancount,
							@tran_scope bit = 0,
							@fecha_operacion datetime,
			
							@id_tipo_bitacora int,
							@id_origen_transaccion int = 3 --
					-- declare de variables
							declare
								@id_mov int,
								@num_poliza int,
								@saldo_actual money,
								--@id_persona bigint,
								@numero bigint,
								@id_tipo_persona int = 1,

								--- son muy necesarias para la poliza
								@ccostos_compensacion varchar(20),
								@ccostos_socio varchar(20),
								@NumPoliza bigint  = 0000,
								@TipoPoliza varchar(1) ='D',
								@NumUsuarioBanca int = 1012 ,
								@IdPersona int,
								@IdTipoMov int,							
								@CuentaContable varchar(14) =	'',
								@CuentaContableSucursal varchar(14) =	'',
								@NomreS varchar(50),
								@ApellidoPaterno varchar(50),
								@ApellidoMaterno varchar(50),
								@TotalMovs int = 1,
								@ConceptoCaptura  varchar(1000)='',
								@DebeHaber varchar(1)='H',
								@fechaTransaccion datetime =  getDate(),
								@idServicio int,
								@idProducto int 


					select @fecha_operacion = coalesce(@fecha_operacion, getdate())

				end -- declaraciones

			end -- inicio

			begin -- �mbito de la actualizaci�n

					select @estatusTransferencia = case when @codigo =1 then  2 else 3  end
					select @status = case when @codigo =1 then  200 else 410 /*Pago de servicio rechazado*/  end
					
					select @numero = banca.dbo.fn_banca_descifrar(numero_socio),  @id_mov = cc.id_mov from tbl_banca_transferencias_pago_servicios S
					join hape..tbl_corresponsalias_cuentas CC on S.clabe_corresponsalias_retiro = CC.cuenta
					where s.id_banca_folio = @idBancaFolio

					

					select @saldo_actual = Saldo_Actual 
					from 
						HAPE..EDO_DE_CUENTA 
					where 
						Numero = @numero 
						and Id_mov = @id_mov 
						and Id_Tipo_persona = @id_tipo_persona

					select 
						@idServicio = id_servicio, @idProducto = id_producto 
					from 
						BANCA..TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS
					where
						id_banca_folio= @idBancaFolio and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero

					update	TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS
					set		
		
						fecha_pago_realizado = @fecha_operacion,
						folio_autorizacion =  @folioAutorizacion,
						pin =@pin,
						mensaje_error = @mensaje,
						codigo = @codigo,
						id_estatus_transferencia = @estatusTransferencia,
						request =@request,
						response  = @response,
						signed = @signed
					where	
						id_banca_folio = @idBancaFolio
					
					if @codigo = 1 -- si el ws regresa 1 de operacion realizada exitosamente o 6 operacion confirma exitosamente
					begin 
						select @id_tipo_bitacora = 21 --Pago de servicios

						--select * from CAT_BANCA_TIPOS_BITACORA

						insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
						values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @tipoOrigen)

						---bitacora para indicar de donde se realizo el retiro de dinero
						select @id_tipo_bitacora = case
							when @id_mov = 100 then 52
							when @id_mov = 103 then 51
							when @id_mov = 112 then 53
						end

						insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
						values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @tipoOrigen)

						-- VALIDAMOS SI EL PAGO DE SERVICIO NECESITA CODIGO DE ACTIVACION						
						if exists(SELECT id_cat_tipo_servicio FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO WHERE id_producto = @IdProducto and id_servicios_pago = @idServicio  and id_cat_tipo_servicio in (10,11))
						BEGIN
							select @id_tipo_bitacora = 97 --Pago de Servicio + Codigo de Activacion
							insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @tipoOrigen)
						END

						--select * from CAT_BANCA_TIPOS_BITACORA ORDER BY id_tipo_bitacora DESC
					end

					-- proceso para  realizar la devolucion del monto del pago de serivicio cuando este es rechazado
					 if @codigo not in(1)  
					 begin
						begin-- se obtienes los datos para el proceso de devolucion  y la poliza
											  						
							  set @mensaje= case when @codigo = -1 then 'Espere un momento y vuelva a intentarlo' else @mensaje end
								--insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
								--values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @id_origen_transaccion)
										
								---Se obtiene el numero de poliza de banca
								select @num_poliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
								select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'BANCA ELECTRONICA')
								and dia = DAY(GETDATE())

								-- OBTENEMOS EL ID_TIPOMOV
								if @id_mov = 100   -- 1184	Dep�sito a AHORRO CMV por operaci�n rechazada de Pago de Servicio
									SET @IdTipoMov  = 1184
								else if @id_mov = 103-- 1187	Dep�sito a INVERDIN�MICA CMV por operaci�n rechazada de Pago de Servicio
									SET @IdTipoMov  = 1187
								else if @id_mov = 112 -- 1190	Dep�sito a DEBITO CMV por operaci�n rechazada de Pago de Servicio
									SET @IdTipoMov  = 1190

									--- se obtienen datos del socio 
								select 
									@IdPersona = p.Id_Persona,
									@NomreS = p.Nombre_s,
									@ApellidoPaterno = p.Apellido_Paterno,
									@ApellidoMaterno = p.Apellido_Materno,
									@ccostos_socio = s.Ccostos,
									@CuentaContableSucursal = nSuc.Num_Cuenta_Compensacion
								from HAPE..PERSONA p
								join HAPE.dbo.sucursales s
									on s.id_de_sucursal = p.id_de_sucursal
								join HAPE..NUM_SUCURSAL nSuc 
									on s.Num_Sucursal = nSuc.Num_Sucursal
								where Numero = @numero and Id_Tipo_Persona = @id_tipo_persona
								
								
								select @ccostos_compensacion = Ccostos from HAPE..NUM_SUCURSAL
								WHERE
									Num_Sucursal = 99 --'MEDIOS DE PAGO%'
						end


						begin -- Transaccionalidad

								print 'paso 03 (inicio de transacci�n)'
								if @tran_count = 0
									begin tran @tran_name
								else
									save tran @tran_name
				
								select @tran_scope = 1	
									/*========================================	ACTUALIZACI�N DE MOVIMIENTOS ==============================
									======================================================================================================*/
								
								print 'antes de MOVIMIENTOS'
								print '@numero:'+ cast(@numero as varchar )
								print '@id_tipo_persona:'+ cast(@id_tipo_persona as varchar )
								print '@id_persona:'+ cast(@idPersona as varchar )
								INSERT	HAPE..MOVIMIENTOS
									(
									NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
									NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
									ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR, id_origen
									)
								VALUES(
									@numero, 'T', @fecha_operacion, @monto,round((@saldo_actual + @monto),2), 'D',
									@num_poliza, @idBancaFolio, GETDATE(), @IdPersona, @NumUsuarioBanca,
									@IdTipoMov, @id_mov, 1, 'S', @id_origen_transaccion)

								print 'despues de MOVIMIENTOS'

								/*========================================	ACTUALIZACI�N DE ESTADO DE CUENTA	================================
								==============================================================================================================*/
								UPDATE	HAPE..EDO_DE_CUENTA
								SET	SALDO_ACTUAL = round(@saldo_actual + @monto,2),
									FECHA = @fecha_operacion
								WHERE	
									numero = @numero
									and id_mov = @id_mov
									AND Id_Tipo_persona = 1

							    print 'antes de CAPTURA'
								begin
								--******	INSERCI�N DEL MOVIMIENTO		******
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov
								select @CuentaContable =  Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like 
								case 
									when @id_mov = 100 then '2120000000%'
									when @id_mov = 103 then '2110000000%'
									when @id_mov = 112 then '2160000000%'
								end
								select @DebeHaber = 'H'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)
								--select top 1  * from hape..CAPTURA order by Contador desc
								
								
								
								--******	INSERCION SERVICIO DE BANCA	(DEBE - CARGO)	******
								--obtenemos la descripcion del  movimiento
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

								-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
								SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
								WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

								select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCION SERVICIO DE BANCA	(HABER - ABONO)	******
								--obtenemos la descripcion del  movimiento
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

								-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
								SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
								WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

								select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
								select @DebeHaber = 'H'
								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCI�N MEDIOS DE PAGO	CARGO	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14101000990000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCI�N SUCURSAL DEL SOCIO HABER	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta = @CuentaContableSucursal
								select @DebeHaber = 'H'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_compensacion
								)

								--******	INSERCI�N GESTO PAGO CARGO	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select 
									@CuentaContable =  Num_cuenta, 
									@ConceptoCaptura = 'GESTO PAGO'--Concepto (Se forzo a que diga gesto pago, ya que al darse de alta en productivo no la registraron como debia ser)
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14100611950000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_compensacion
								)

								print 'despues de CAPTURA'
								end
								--- FIN DEL INSERT DE CAPTURA  ---

								--============================ INSERT CAPTURA_lacp ============================
								print 'antes de CAPTURA_lacp'
								begin
								--******	INSERCI�N DEL MOVIMIENTO		******
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov
								select @CuentaContable =  Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like 
								case 
									when @id_mov = 100 then '2120000000%'
									when @id_mov = 103 then '2110000000%'
									when @id_mov = 112 then '2160000000%'
								end
								select @DebeHaber = 'H'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCION SERVICIO DE BANCA	(DEBE - CARGO)	******
								--obtenemos la descripcion del  movimiento
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

								-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
								SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
								WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

								select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCION SERVICIO DE BANCA	(HABER - ABONO)	******
								--obtenemos la descripcion del  movimiento
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

								-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
								SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
								WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

								select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
								select @DebeHaber = 'H'
								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCI�N MEDIOS DE PAGO	CARGO	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14101000990000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCI�N SUCURSAL DEL SOCIO HABER	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta = @CuentaContableSucursal
								select @DebeHaber = 'H'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_compensacion
								)

								--******	INSERCI�N GESTO PAGO CARGO	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select 
									@CuentaContable =  Num_cuenta, 
									@ConceptoCaptura = 'GESTO PAGO'--Concepto (Se forzo a que diga gesto pago, ya que al darse de alta en productivo no la registraron como debia ser)
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14100611950000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_compensacion
								)

								print 'despues de CAPTURA_lacp'
								end

								--============================ INSERT DE BITACORA ============================
								select @id_tipo_bitacora = 93 --Pago de servicio rechazado

								--select * from CAT_BANCA_TIPOS_BITACORA

								insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
								values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @id_origen_transaccion)

						end

						commit tran
					 end

			end -- �mbito de la actualizaci�n

		end try -- try principal

		begin catch -- catch principal

				select @status=coalesce(@status, 0)

				select	--@status=@status,
						--@status =error_state(),	
						@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
						@error_line = error_line(),
						@error_message = error_message(),
						@error_severity =
							case error_severity()
								when 11 then 'Error en validaci�n'
								when 12 then 'Error en consulta'
								when 13 then 'Error en actualizaci�n'
								else 'Error general'
							end

						--select @status=coalesce(@status, 0)
				-- revertir transacci�n si es necesario
				if @tran_scope = 1
				begin
					rollback tran @tran_name
				end

		end catch -- catch principal

		begin -- reporte de estatus
					select 
						@status as estatus , 
						@mensaje as mensaje,
						CONVERT(varchar , @fecha_operacion ,103) as fecha_transaccion, 
						FORMAT(CONVERT(datetime, @fecha_operacion),'hh:mm:ss tt') as hora_transaccion,
						* 
					from 
						TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS where id_banca_folio = @idBancaFolio

		end -- reporte de estatus

	end -- procedimiento
	go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZAR_ESTATUS_CUENTA_STP_SOCIO]    Script Date: 18/03/2020 04:02:14 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER proc

	[dbo].[SP_BANCA_ACTUALIZAR_ESTATUS_CUENTA_STP_SOCIO]
	
		-- parametros
		@numeroSocio int,
		@estatusSTP int,
		@mensajeSTP varchar (max),
		@idEstatusCuenta int
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = ''						

					
			end -- inicio
			
			begin -- �mbito de la actualizaci�n

				declare @ultimaCuentaSocio int
				select top 1 @ultimaCuentaSocio =id_cuenta from TBL_BANCA_CUENTAS_INTERBANCARIAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio order by fecha_alta desc
				

				if exists(select 1 from TBL_BANCA_CUENTAS_INTERBANCARIAS where id_cuenta = @ultimaCuentaSocio)
				begin					
					/***Estatus correcto del response STP que indica que la peticion fue exitosa***/
					if @estatusSTP = 0
					begin
						/***Se valida si la cuenta se dio de alta y se actualizan sus datos***/
						if @idEstatusCuenta = 2
						begin
							update 
								TBL_BANCA_CUENTAS_INTERBANCARIAS 
							set 
								activo = 1,
								estatus_STP = @estatusSTP, 
								mensaje_STP= @mensajeSTP, 
								fecha_estatus_STP = GETDATE(),
								id_estatus_cuenta = @idEstatusCuenta
							where
					 			id_cuenta = @ultimaCuentaSocio
						end

						/***Se valida si la cuenta se dio de baja y se actualizan sus datos***/
						else if @idEstatusCuenta = 4
						begin
							update 
								TBL_BANCA_CUENTAS_INTERBANCARIAS 
							set 
								activo = 0,
								estatus_STP = @estatusSTP, 
								mensaje_STP= @mensajeSTP, 
								fecha_estatus_STP = GETDATE(),
								id_estatus_cuenta = @idEstatusCuenta
							where
					 			id_cuenta = @ultimaCuentaSocio
						end							
					end

					/***Al moemnto en que STP genere un error en el response***/
					else
					begin						
						update 
							TBL_BANCA_CUENTAS_INTERBANCARIAS 
						set 
							activo = 0,
							estatus_STP = @estatusSTP, 
							mensaje_STP= @mensajeSTP, 
							fecha_estatus_STP = GETDATE(),
							id_estatus_cuenta = @idEstatusCuenta
						where
					 		id_cuenta = @ultimaCuentaSocio
					end
					
					select @estatus = 200;
					select @mensaje = 'Datos actualizados correctamente.'										
				end

				else
				begin
					select @error_message = 'El socio tiene su cuenta interbancaria inactiva o no cuenta con ella.'
					select @estatus = -1
				end			
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			else
			begin
				select
					 @estatus estatus, @mensaje as mensaje				
			end			
		end -- reporte de estatus
		
	end -- procedimiento
	grant exec on SP_BANCA_ACTUALIZAR_ESTATUS_CUENTA_STP_SOCIO to public
go

	USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZAR_IMAGEN_ANTIPHISHING]    Script Date: 27/01/2020 04:11:30 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		EDSON PE�A
-- Create date: 2018-09-04
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_ACTUALIZAR_IMAGEN_ANTIPHISHING]
@numero VARCHAR(20),
@id_imagen_antiphishing  int,
@tipo_origen int

AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int,
@numero_int int,
@id_tipo_bitacora int = 14 --Actualizaci�n de imagen antiphishing

select @mensaje_validacion =msj ,@estatus = estatus  from  dbo.FN_BANCA_VALIDA_SOCIO(@numero,0)

  if(@mensaje_validacion is  null )
  BEGIN
  SET @numero_int = CAST(@numero as int )


		if not exists(select * from CAT_BANCA_IMAGENES_ANTIPHISHING where id_imagen_antiphishing = @id_imagen_antiphishing)
		begin
			SELECT 1000, 'Datos incorrectos.'
		end
		else
		begin
			UPDATE TBL_BANCA_SOCIOS
			SET 
				id_imagen_antiphishing = @id_imagen_antiphishing
			WHERE
				BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int

			CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500))
			INSERT INTO #Bitacora
			EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_int, @id_tipo_bitacora, @tipo_origen

			SELECT 200 AS estatus
		end
  END
  ELSE
	  SELECT 300 AS estatus , @mensaje_validacion mensaje
end try
begin catch
	select -1 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZAR_PREGUNTA_RESPUESTA_SECRETA]    Script Date: 21/08/2019 08:58:49 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		VIC
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_ACTUALIZAR_PREGUNTA_RESPUESTA_SECRETA]
@numeroSocio varchar(20),
@idPreguntaSecreta int,
@respuesta varchar(max),
@idTipoOrigen int 
AS
BEGIN
Declare 

@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int,
@id_tipo_bitacora int  = 47 --Actualizaci�n de  pregunta y respuesta secreta

BEGIN TRY 

		SELECT @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@numeroSocio,1)
		SET @numero_int = CAST(@numeroSocio as int )
		IF(@mensaje_validacion is null) 
		BEGIN
			 --INICIO VALIDACIONES--
				IF NOT EXISTS (SELECT 1 FROM CAT_BANCA_PREGUNTAS_SECRETAS WHERE id_pregunta_secreta =@idPreguntaSecreta )
				BEGIN
					SELECT id_excepcion AS estatus , descripcion as mensaje 
					FROM CAT_BANCA_EXCEPTIONS
					WHERE id_excepcion = 307
					return
				END

			 --FIN DE VALIDACIONES --
			 UPDATE tbl_banca_socios SET id_pregunta_secreta = @idPreguntaSecreta , respuesta = @respuesta
			 WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int

			 INSERT INTO TBL_BANCA_BITACORA_OPERACIONES (id_banca_folio,id_tipo_bitacora,numero_socio,fecha_alta,id_origen_operacion)
			 VALUES (NULL,@id_tipo_bitacora , @numero_int , GETDATE() , @idTipoOrigen)
	 
			 SELECT top 1 200 ESTATUS ,CONVERT(VARCHAR, fecha_alta, 103) as fecha ,CONVERT(VARCHAR, fecha_alta, 108) as hora , * 
			 FROM TBL_BANCA_BITACORA_OPERACIONES
			 WHERE  numero_socio = @numero_int  AND id_tipo_bitacora  = @id_tipo_bitacora order by id_bitacora desc			
			
		END
		ELSE
		BEGIN
			SELECT @estatus AS estatus , @mensaje_validacion mensaje
		END

END TRY
BEGIN CATCH
	select -1 as estatus , ERROR_MESSAGE() AS mensaje 		
END catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ALTA_CUENTA_EXTERNA_CELULAR]    Script Date: 26/12/2019 09:52:42 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		EDSON
-- Create date: 2018-05-08
-- Description: Registra un cuenta de debito externa tipo de celular
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_ALTA_CUENTA_EXTERNA_CELULAR]
@NUMERO varchar(20),
@numero_celular varchar  (20),
@id_banco int,
@alias varchar(255),
@titular_cuenta varchar(255),
@monto_maximo money,
@correo varchar(255),
@idCuentaCelular int = null

AS
BEGIN

begin 
try
	Declare 
	@mensaje_validacion varchar(500),
	@estatus int , 
	@numero_int int,
	@FechaAlta datetime,
	@id_tipo_bitacora int

	select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)
	set @numero_int = CAST(@NUMERO as int )
	select @FechaAlta = getdate()
	
	IF OBJECT_ID('tempdb..#Bitacora') IS NOT NULL
				DROP TABLE #Bitacora
					
	CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));

  IF(@mensaje_validacion is null)
  BEGIN
		
		IF(@idCuentaCelular IS NULL OR @idCuentaCelular = 0)
		BEGIN
			IF NOT EXISTS(SELECT *  FROM TBL_BANCA_CUENTAS_EXTERNAS WHERE 
			BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int and clabe_interbancaria = @numero_celular)
			BEGIN
				INSERT INTO TBL_BANCA_CUENTAS_EXTERNAS 
					(numero_socio,clabe_interbancaria,id_banco, id_tipo_cuenta_externa,titular_cuenta,alias,monto_maximo,correo, fecha_alta,activa)
				VALUES
					(BANCA.dbo.FN_BANCA_CIFRAR(@numero_int),@numero_celular,@id_banco,1,@titular_cuenta,@alias,@monto_maximo,@correo, @FechaAlta,1)
				 
				 SELECT  @estatus = 200 , @mensaje_validacion= 'Registro de cuenta exitoso' , @id_tipo_bitacora  =  89
			END
			ELSE
			BEGIN
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 320
			END
		END
		ELSE
		BEGIN
			IF  EXISTS(SELECT *  FROM TBL_BANCA_CUENTAS_EXTERNAS WHERE 
			BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int and clabe_interbancaria = @numero_celular)
			BEGIN
				UPDATE TBL_BANCA_CUENTAS_EXTERNAS SET 
					numero_socio = BANCA.dbo.FN_BANCA_CIFRAR(@numero_int),
					id_banco = @id_banco, 
					titular_cuenta = @titular_cuenta,
					alias = @alias,
					monto_maximo = @monto_maximo,
					correo = @correo
				WHERE
					id_cuenta_externa = @idCuentaCelular

				SELECT  @estatus = 200 , @mensaje_validacion= 'Registro de cuenta exitoso' , @id_tipo_bitacora  =  91
			END
			ELSE
			BEGIN
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 320
			END
		END
		
		-- INSERT EN BITACORRA --
		IF @@ERROR = 0 AND @estatus = 200
		 BEGIN
					
					INSERT INTO #Bitacora
					EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero, @id_tipo_bitacora
					SELECT * FROM #Bitacora
		 END
		
  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje


end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ALTA_CUENTA_EXTERNA_CLABE]    Script Date: 26/12/2019 10:39:51 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_ALTA_CUENTA_EXTERNA_CLABE]
@NUMERO varchar(20),
@titular_cuenta varchar(255),
@clabe_spei varchar(20),
@alias varchar(255),
@monto_maximo money,
@correo varchar(255),
@id_cuenta_externa int,
@id_banco int 
AS
BEGIN

begin 
try
	Declare 
		@mensaje_validacion varchar(500),
		@estatus int , 
		@numero_int int,
		@FechaAlta datetime,
		@id_tipo_bitacora int

	select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)
	set @numero_int = CAST(@NUMERO as int )
	select @FechaAlta = getdate()
	
	IF OBJECT_ID('tempdb..#Bitacora') IS NOT NULL
				DROP TABLE #Bitacora
					
	CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));

  IF(@mensaje_validacion is null)
  BEGIN
	
	IF(@id_cuenta_externa IS NULL OR @id_cuenta_externa = 0)
	BEGIN
		IF NOT EXISTS(SELECT *  FROM TBL_BANCA_CUENTAS_EXTERNAS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int AND clabe_interbancaria = @clabe_spei)
		BEGIN
			INSERT INTO TBL_BANCA_CUENTAS_EXTERNAS 
			(id_tipo_cuenta_externa,numero_socio,clabe_interbancaria,titular_cuenta,alias,monto_maximo,correo,id_banco , fecha_alta,activa)
			VALUES(4,BANCA.dbo.FN_BANCA_CIFRAR(@numero_int),@clabe_spei,@titular_cuenta,@alias,@monto_maximo,@correo,@id_banco, @FechaAlta,1)
			 SELECT  @estatus = 200 , @mensaje_validacion= 'Registro de cuenta exitoso' , @id_tipo_bitacora  =  89
		END
		ELSE
		BEGIN
			SELECT id_excepcion AS estatus , descripcion as mensaje 
			FROM CAT_BANCA_EXCEPTIONS
			WHERE id_excepcion = 320

		END
	END
	ELSE
	BEGIN
		IF EXISTS(SELECT * FROM TBL_BANCA_CUENTAS_EXTERNAS WHERE id_cuenta_externa = @id_cuenta_externa and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int)
			BEGIN
				UPDATE TBL_BANCA_CUENTAS_EXTERNAS SET 
					numero_socio = BANCA.dbo.FN_BANCA_CIFRAR(@numero_int), 
					--clabe_interbancaria = @clabe_spei, 
					titular_cuenta = @titular_cuenta,
					alias = @alias, 
					monto_maximo = @monto_maximo, 
					correo = @correo,
					id_banco = @id_banco
				WHERE id_cuenta_externa = @id_cuenta_externa
				SELECT  @estatus = 200 , @mensaje_validacion= 'Registro de cuenta exitoso' , @id_tipo_bitacora  =  91
			END
		ELSE
		BEGIN
			SELECT id_excepcion AS estatus , descripcion as mensaje 
			FROM CAT_BANCA_EXCEPTIONS
			WHERE id_excepcion = 319
		END
	END

	-- INSERT EN BITACORRA --
		IF @@ERROR = 0 AND @estatus = 200
		 BEGIN
					
					INSERT INTO #Bitacora
					EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero, @id_tipo_bitacora
					SELECT * FROM #Bitacora
		 END

  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje

end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ALTA_CUENTA_EXTERNA_DEBITO]    Script Date: 07/11/2019 04:19:26 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		EDSON
-- Create date: 2018-05-08
-- Description: Registra un cuenta de debito externa
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_ALTA_CUENTA_EXTERNA_DEBITO]
@NUMERO varchar(20),
@numero_tarjeta varchar  (30),
@alias varchar(255),
@titular_cuenta varchar(255),
@monto_maximo money,
@correo varchar(255),
@id_cuenta_externa int,
@id_banco int 

AS
BEGIN

begin 
try
	Declare 
		@mensaje_validacion varchar(500),
		@estatus int , 
		@numero_int int ,
		@FechaAlta datetime,
		@id_tipo_bitacora int


	select @mensaje_validacion =msj, @estatus = estatus 
	from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)
	
	select @numero_int = CAST(@NUMERO as int ) , @FechaAlta = getdate()

	IF OBJECT_ID('tempdb..#Bitacora') IS NOT NULL
		DROP TABLE #Bitacora
					
	CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));



  if(@mensaje_validacion is null)
  BEGIN
		
		IF (@id_cuenta_externa IS NULL OR @id_cuenta_externa  = 0) --REGISTRO DE CUENTA
		BEGIN
			IF NOT EXISTS(SELECT *  FROM TBL_BANCA_CUENTAS_EXTERNAS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int and clabe_interbancaria = @numero_tarjeta)
			BEGIN
				INSERT INTO TBL_BANCA_CUENTAS_EXTERNAS 
					(numero_socio, id_tipo_cuenta_externa,titular_cuenta,alias,monto_maximo,correo,clabe_interbancaria,id_banco, fecha_alta,activa)
				VALUES
					(BANCA.dbo.FN_BANCA_CIFRAR(@numero_int),3,@titular_cuenta,@alias,@monto_maximo,@correo,@numero_tarjeta,@id_banco , @FechaAlta,1)
				SELECT  @estatus = 200 , @mensaje_validacion= 'Registro de cuenta exitoso' , @id_tipo_bitacora  =  89
			END
			ELSE
			BEGIN
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 320
			END
		END
		ELSE
		BEGIN ---ACTUALIZACI�N DE CUENTA
			IF EXISTS(SELECT *  FROM TBL_BANCA_CUENTAS_EXTERNAS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int 
			and clabe_interbancaria = @numero_tarjeta )
			BEGIN
				UPDATE TBL_BANCA_CUENTAS_EXTERNAS SET
					numero_socio= BANCA.dbo.FN_BANCA_CIFRAR(@numero_int), 
					titular_cuenta = @titular_cuenta,
					alias = @alias,
					monto_maximo = @monto_maximo,
					correo = @correo,
					--numero_tarjeta  =@numero_tarjeta,
					id_banco = @id_banco
				WHERE
					id_cuenta_externa = @id_cuenta_externa

				SELECT  @estatus = 200 , @mensaje_validacion= 'Registro de cuenta exitoso' , @id_tipo_bitacora  =  91
			END
			ELSE
			BEGIN
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 320
			END
		END

		-- INSERT EN BITACORRA --
		IF @@ERROR = 0 AND @estatus = 200
		 BEGIN
					
					INSERT INTO #Bitacora
					EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero, @id_tipo_bitacora
					SELECT * FROM #Bitacora
					SELECT @estatus AS estatus , @mensaje_validacion mensaje
		 END

  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje


end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ALTA_CUENTA_INTERNA]    Script Date: 21/08/2019 09:09:27 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_ALTA_CUENTA_INTERNA]
@NUMERO varchar(20),
@titular_cuenta varchar(300),
@clabe_corresponsalias varchar(20),
@alias varchar(255),
@monto_maximo money,
@correo varchar(255),
@id_cuenta_interna int
AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int,
@id_tipo_bitacora INT,-- PUEDE SER 30 alta de cuentas internas | (mismo banco) 'O 55 modificacion de cuenta interna
@tipoOrigen INT 

select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)
set @numero_int = CAST(@NUMERO as int )

IF OBJECT_ID('tempdb..#Bitacora') IS NOT NULL
			DROP TABLE #Bitacora

CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));
  
  if(@mensaje_validacion is null)
  BEGIN

		IF EXISTS (SELECT * FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE CUENTA = @clabe_corresponsalias)
		BEGIN
			IF EXISTS (SELECT * FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE CUENTA = @clabe_corresponsalias and NUMERO = @numero_int)
			BEGIN
			    SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 400
				RETURN
			END
			ELSE
			BEGIN
				IF(@id_cuenta_interna IS NULL OR @id_cuenta_interna = 0)
				BEGIN
					IF NOT EXISTS(SELECT *  FROM TBL_BANCA_CUENTAS_INTERNAS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int 
						AND clabe_corresponsalias = @clabe_corresponsalias
						AND activo = 1)
					BEGIN
						SET @id_tipo_bitacora= 30
						INSERT INTO TBL_BANCA_CUENTAS_INTERNAS (numero_socio,titular_cuenta,clabe_corresponsalias,alias,monto_maximo,correo,fecha_alta,divisa,activo)
						VALUES(BANCA.dbo.FN_BANCA_CIFRAR(@numero_int),@titular_cuenta,@clabe_corresponsalias,@alias,@monto_maximo,@correo,GETDATE(),'MXN',1)
						SELECT @estatus = 200
					END
					ELSE
					BEGIN
						SELECT id_excepcion AS estatus , descripcion as mensaje 
						FROM CAT_BANCA_EXCEPTIONS
						WHERE id_excepcion = 320
						return
					END
				END
				ELSE
				BEGIN
					IF NOT EXISTS(SELECT * FROM TBL_BANCA_CUENTAS_INTERNAS WHERE 
						id_cuenta_interna=@id_cuenta_interna
						and DATEDIFF(MINUTE,fecha_alta,getdate()) > 30
					)
					BEGIN
						SELECT id_excepcion AS estatus , descripcion as mensaje 
						FROM CAT_BANCA_EXCEPTIONS
						WHERE id_excepcion = 401
					END
						
					ELSE
					BEGIN	
						IF EXISTS(SELECT * FROM TBL_BANCA_CUENTAS_INTERNAS WHERE id_cuenta_interna = @id_cuenta_interna and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int)
							BEGIN
								SET @id_tipo_bitacora= 49
								UPDATE TBL_BANCA_CUENTAS_INTERNAS SET 
									titular_cuenta = @titular_cuenta,
									clabe_corresponsalias = @clabe_corresponsalias, 
									alias = @alias, 
									monto_maximo = @monto_maximo,
									correo=@correo
									--fecha_alta = GETDATE()
								where 
									id_cuenta_interna = @id_cuenta_interna
								--SELECT 200 as estatus
								SELECT @estatus = 200

							END
						ELSE
						BEGIN
								SELECT id_excepcion AS estatus , descripcion as mensaje 
								FROM CAT_BANCA_EXCEPTIONS
								WHERE id_excepcion = 319
								RETURN
						END
					END
				END
				
				IF @@ERROR = 0 AND @estatus = 200
				BEGIN
					
					INSERT INTO #Bitacora
					EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero, @id_tipo_bitacora
					SELECT * FROM #Bitacora
				END
				ELSE
				BEGIN
					select @estatus estatus, @mensaje_validacion mensaje
				END
				
			END
		END
		ELSE
		BEGIN
			SELECT id_excepcion AS estatus , descripcion as mensaje 
			FROM CAT_BANCA_EXCEPTIONS
			WHERE id_excepcion = 339
			RETURN
		END
  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje

end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ALTA_DOMICILIACION]    Script Date: 21/08/2019 10:42:34 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		EDSON PE�A
-- Create date: 2018-09-04
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_ALTA_DOMICILIACION]
@clabe_corresponsalias_retiro varchar(20),
@clabe_corresponsalias_deposito varchar(20),
@numero varchar(20),
@tipo_domiciliacion int,
@numero_referencia varchar(50) = null,
@id_producto int = null,
@id_servicio int = null,
@periodicidad_pago int ,
@monto_maximo money,
@dia_pago datetime,
@indefinido bit,
@fecha_de_vencimiento datetime,
@alias varchar(200),
@id_domiciliacion bigint = null,
@tipo_origen int


AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int,
@numero_socio_guardado int, 
@id_tipo_bitacora int  = 25 --Domiciliar Pago

select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@numero,1)
set @numero_int = CAST(@numero as int )

CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500))

 if(@mensaje_validacion is null)
  BEGIN
		

		IF EXISTS (SELECT * FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE CUENTA = @clabe_corresponsalias_retiro and NUMERO = @numero_int )
		begin
			IF EXISTS (SELECT * FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE CUENTA = @clabe_corresponsalias_deposito)
			BEGIN
				IF(@id_domiciliacion IS NULL OR @id_domiciliacion = 0)
				BEGIN
					IF NOT EXISTS(SELECT *  FROM TBL_BANCA_DOMICILIACIONES WHERE 
						BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int AND clabe_corresponsalias_deposito = @clabe_corresponsalias_deposito and alias = @alias and clabe_corresponsalias_retiro = @clabe_corresponsalias_retiro)
					BEGIN
						INSERT INTO TBL_BANCA_DOMICILIACIONES 
							(clabe_corresponsalias_retiro,clabe_corresponsalias_deposito ,numero_socio,id_tipo_domiciliacion ,numero_referencia ,
							id_producto ,id_servicio ,id_periodicidad_pago,monto_maximo ,dia_pago ,indefinido ,fecha_vencimiento,alias,fecha_alta,activo)
						VALUES
							(@clabe_corresponsalias_retiro,@clabe_corresponsalias_deposito ,BANCA.dbo.FN_BANCA_CIFRAR(@numero),@tipo_domiciliacion ,@numero_referencia ,
							@id_producto ,@id_servicio ,@periodicidad_pago  ,@monto_maximo ,@dia_pago ,@indefinido ,@fecha_de_vencimiento,@alias,GETDATE(),1)
					
					
						INSERT INTO #Bitacora
						EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_int, @id_tipo_bitacora, @tipo_origen

						--OBTENER EL DETALLE DE LA DOMICILIACION PARA PODER GENERAR EL PDF
						--@id_domiciliacion
						SELECT @id_domiciliacion =  MAX(id_domiciliacion) FROM TBL_BANCA_DOMICILIACIONES  WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)  =@numero
						GOTO OBTENER_DETALLE_DOMICILIACION
					END
					ELSE
					BEGIN
							SELECT id_excepcion AS estatus , descripcion as mensaje 
							FROM CAT_BANCA_EXCEPTIONS
							WHERE id_excepcion = 320
						RETURN
					END
				END
				ELSE
				BEGIN
					IF EXISTS(SELECT * FROM TBL_BANCA_DOMICILIACIONES WHERE id_domiciliacion = @id_domiciliacion and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int)
						BEGIN
							UPDATE TBL_BANCA_DOMICILIACIONES SET 
								clabe_corresponsalias_retiro = @clabe_corresponsalias_retiro,
								clabe_corresponsalias_deposito = @clabe_corresponsalias_deposito,
								numero_socio = BANCA.dbo.FN_BANCA_CIFRAR(@numero_int),
								id_tipo_domiciliacion = @tipo_domiciliacion,
								numero_referencia = @numero_referencia,
								id_producto = @id_producto,
								id_servicio = @id_servicio,
								id_periodicidad_pago = @periodicidad_pago,
								monto_maximo = @monto_maximo,
								dia_pago = @dia_pago,
								indefinido = @indefinido,
								fecha_vencimiento = @fecha_de_vencimiento,
								alias = @alias
							where 
								id_domiciliacion = @id_domiciliacion

						
							INSERT INTO #Bitacora
							EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_int, @id_tipo_bitacora, @tipo_origen
							--OBTENER EL DETALLE DE LA DOMICILIACION PARA PODER GENERAR EL PDF 
							GOTO OBTENER_DETALLE_DOMICILIACION
							--SELECT 200 as estatus
						END
					ELSE
					BEGIN
						SELECT id_excepcion AS estatus , descripcion as mensaje 
						FROM CAT_BANCA_EXCEPTIONS
						WHERE id_excepcion = 339
						RETURN
					END
				END
			END
			ELSE
			BEGIN
						SELECT id_excepcion AS estatus , descripcion as mensaje 
						FROM CAT_BANCA_EXCEPTIONS
						WHERE id_excepcion = 339
				RETURN
			END
		end
		else
		begin
						SELECT id_excepcion AS estatus , descripcion as mensaje 
						FROM CAT_BANCA_EXCEPTIONS
						WHERE id_excepcion = 339
			RETURN
		end
  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje
	  drop table #Bitacora
	  GOTO SALIR

	  OBTENER_DETALLE_DOMICILIACION:
	        select * from #Bitacora
	        print 'id de domiciliacion : '+cast(@id_domiciliacion as varchar)
	  		SELECT 
			D.id_domiciliacion,
			D.id_tipo_domiciliacion,
			D.id_producto,
			D.id_periodicidad_pago,
			D.fecha_vencimiento,
			D.monto_maximo,
			D.indefinido,
			D.dia_pago,
			D.fecha_alta,
			D.clabe_corresponsalias_retiro,
			D.clabe_corresponsalias_deposito,
			D.id_servicio,
			D.numero_referencia,
			D.alias,
			BANCA.dbo.FN_BANCA_DESCIFRAR (D.numero_socio) numero_socio,
			D.activo,
			D.folio_autorizacion,
			D.folio_cancelacion,
			P.descripcion descProducto ,
			TDO.Desc_prestamo descClabeRetiro,
			TDO1.Desc_prestamo descClabeDeposito,
			TD.descripcion descTipoDomiciliacion,
			PP.descripcion descPeriodicidadago
			
			FROM TBL_BANCA_DOMICILIACIONES D
			LEFT  JOIN  CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO AS P ON D.id_producto = P.id_producto AND D.id_servicio = P.id_servicios_pago
			LEFT  JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS AS CC ON CC.CUENTA = D.clabe_corresponsalias_retiro AND CC.NUMERO = BANCA.dbo.FN_BANCA_DESCIFRAR(D.NUMERO_SOCIO) 
			LEFT  JOIN HAPE..TIPOS_DE_OPERACIONES AS TDO ON TDO.Id_mov = CC.ID_MOV AND CC.NUMERO = BANCA.dbo.FN_BANCA_DESCIFRAR(D.NUMERO_SOCIO)
			LEFT  JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS AS CC1 ON CC1.CUENTA = D.clabe_corresponsalias_deposito AND CC.NUMERO = BANCA.dbo.FN_BANCA_DESCIFRAR(D.NUMERO_SOCIO)
			LEFT  JOIN HAPE..TIPOS_DE_OPERACIONES AS TDO1 ON TDO1.Id_mov = CC1.ID_MOV AND CC.NUMERO = BANCA.dbo.FN_BANCA_DESCIFRAR(D.NUMERO_SOCIO)
			INNER JOIN CAT_BANCA_TIPOS_DOMICILIACION AS TD ON TD.id_tipo_domiciliacion = D.id_tipo_domiciliacion
			INNER JOIN CAT_BANCA_PERIODICIDAD_PAGO  AS PP ON PP.id_periodicidad_pago = D.id_periodicidad_pago
			WHERE id_domiciliacion = @id_domiciliacion
			GOTO SALIR

	SALIR:

end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 	
	drop table #Bitacora
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_APLICA_TRANSACCIONES_INTERNAS_PROGRAMADAS]    Script Date: 21/08/2019 10:43:15 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		EDSON
-- Create date: 2018-09-10
-- Description:	
/*
	@id_tipo_transaccion : identifica que tipo de transacciones obtener, ya sean transacciones de haberes o de pago de prestamo
		-1: Transferencias entre Haberes
		-2: Pagos de prestamos
*/
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_APLICA_TRANSACCIONES_INTERNAS_PROGRAMADAS]
	@fecha_proceso datetime,
	@id_tipo_transaccion int

AS
BEGIN

begin try

	DECLARE 
	@mensaje_validacion varchar(500),
	@estatus int,
	@registro int


	IF @fecha_proceso is null
		SELECT @fecha_proceso = GETDATE()

	CREATE TABLE #TransaccionesProgramadas
	(
		id INT IDENTITY(1, 1) primary key ,
		id_transferencia	bigint,
		numeroSocio bigint,
		monto money,
		clabeCorresponsaliasRetiro varchar(16),
		clabeCorresponsaliasDeposito varchar(16),
		programada bit,
		horaProgramada datetime,
		tipoOrigen int,
		tipoTransferenciaInterna  int, 
		folio bigint,
		------- BITACORA
		id_bitacora bigint,
		id_tipo_bitacora int
	)

	CREATE TABLE #resultado_transferencia
	(
		estatus int,
		folio bigint,
		HoraTransaccion datetime,
		Monto money,
		error_procedur varchar(500),
		error_lin varchar(500),
		error_severit varchar(500),
		error_messag varchar(500),
		id_transferencia	bigint 
	)

	create table #notificaciones
	(
		idTipoNotificacion int , 
		celular varchar(20),
		correo varchar(500),
		cuerpo varchar(max),
		asunto varchar(500),
		numero bigint,
		nombre_socio varchar(200),
		tipo_bitacora varchar(500)
	)

	CREATE TABLE #SP_BANCA_PAGAR_PRESTAMO
	(
	    estatus int,
		folio bigint,
		HoraTransaccion datetime,
		Monto money,
		error_procedur varchar(500),
		error_lin varchar(500),
		error_severit varchar(500),
		error_messag varchar(500),
	)
	
	insert into #TransaccionesProgramadas
		(id_transferencia,numeroSocio,monto,clabeCorresponsaliasRetiro,clabeCorresponsaliasDeposito,programada,horaProgramada,
		tipoOrigen,tipoTransferenciaInterna,folio,id_bitacora,id_tipo_bitacora)
	select  
		a.id_transferencia,
		BANCA.dbo.FN_BANCA_DESCIFRAR(a.numero_socio) numero_socio,
		a.monto,
		a.clave_corresponsalias_origen,
		a.clave_corresponsalias_destino,
		0,--programada
		a.fecha_programada,--horaProgramada
		3,--tipoOrigen
		case --CuentaPropia = 1,     CuentaOtroSocio = 2
			when BANCA.dbo.FN_BANCA_DESCIFRAR(a.numero_socio) = b.numero then 1
			when BANCA.dbo.FN_BANCA_DESCIFRAR(a.numero_socio) <> b.numero then 2
		end,
		a.id_banca_folio,
		bo.id_bitacora,
		Bo.id_tipo_bitacora
	from 
		banca..tbl_banca_transferencias_internas a
	inner join
		HAPE..TBL_CORRESPONSALIAS_CUENTAS b on a.clave_corresponsalias_destino = b.CUENTA
	inner join
		BANCA..TBL_BANCA_BITACORA_OPERACIONES BO on BO.id_banca_folio = a.id_banca_folio  and BO.numero_socio = BANCA.dbo.FN_BANCA_DESCIFRAR(a.numero_socio)	
	where
		id_estatus_transferencia = 1
		and programada = 1
		and 1 = 
			case 
				when b.ID_MOV >= 100 and @id_tipo_transaccion = 1 then 1
				when b.ID_MOV < 100 and @id_tipo_transaccion = 2 then 1
			end
		and convert (varchar (12),a.fecha_programada,103) = convert (varchar (12),@fecha_proceso,103) 
		/*
		15	transferencia realizada |entre cuentras propias
		16	transferencia realizada |cuentas de misma instituci�n (entre socios)
		24	Pago programado|Pago a Pr�stamo|Entre cuentas propias
		50	Pago a pr�stamo|Cuentas entre socios
		*/
		and BO.id_tipo_bitacora in (15,16,24,50)
		--and id_transferencia = 88 --pruebas 

	order by a.fecha_programada


	set @registro = 1
	while @registro <= (select count(*) from #TransaccionesProgramadas)
	begin
		DECLARE
			@id_transferencia	bigint,
			@numeroSocio varchar(20),
			@monto money,
			@clabeCorresponsaliasRetiro varchar(16),
			@clabeCorresponsaliasDeposito varchar(16),
			@programada bit,
			@horaProgramada datetime,
			@tipoOrigen int,
			@tipoTransferenciaInterna  int

		BEGIN TRY
			SELECT @id_transferencia	= id_transferencia,
				@numeroSocio = convert (varchar,numeroSocio),
				@monto = monto,
				@clabeCorresponsaliasRetiro = clabeCorresponsaliasRetiro,
				@clabeCorresponsaliasDeposito = clabeCorresponsaliasDeposito,
				@programada = programada,
				@horaProgramada = horaProgramada,
				@tipoOrigen = tipoOrigen,
				@tipoTransferenciaInterna  = tipoTransferenciaInterna 
			FROM #TransaccionesProgramadas
			WHERE
				id = @registro
	

			IF @id_tipo_transaccion = 1 --1: Transferencias entre Haberes
			BEGIN
				insert into #resultado_transferencia (estatus,folio,HoraTransaccion,Monto,error_procedur,error_lin,error_severit,error_messag)
				exec BANCA..SP_BANCA_REALIZA_TRANSFERENCIA_INTERNA 
					@numeroSocio,@monto,@clabeCorresponsaliasRetiro,@clabeCorresponsaliasDeposito,
					@programada,@horaProgramada,@tipoOrigen,@tipoTransferenciaInterna,@id_transferencia

			END

			IF @id_tipo_transaccion = 2 --2: Pagos de prestamos
			BEGIN
				--insert into #resultado_transferencia (estatus,folio,HoraTransaccion,Monto,error_procedur,error_lin,error_severit,error_messag)
				exec BANCA..SP_BANCA_PAGAR_PRESTAMO 
					@clabeCorresponsaliasRetiro,@clabeCorresponsaliasDeposito,@monto,0/*TipoAnticipo*/,@tipoOrigen,@programada,
					@horaProgramada,null,@id_transferencia

				insert into #resultado_transferencia ( estatus,folio,HoraTransaccion,Monto,error_procedur,error_lin,error_severit,error_messag)
                select estatus,folio,HoraTransaccion,Monto,error_procedur,error_lin,error_severit,error_messag 
				from #SP_BANCA_PAGAR_PRESTAMO


			END


			update #resultado_transferencia 
			set 
				id_transferencia = @id_transferencia
			where
				id_transferencia is null

			--select * from #resultado_transferencia --pruebas

			declare @msj_error_transaccion varchar(1000) 
			select @msj_error_transaccion = error_messag from #resultado_transferencia where id_transferencia = @id_transferencia
			---Se actualiza el estatus de la transaccion en caso de no haberse efectuado correctamente
			if (select estatus from #resultado_transferencia where id_transferencia = @id_transferencia) <> 200
			begin	
				update BANCA..TBL_BANCA_TRANSFERENCIAS_INTERNAS
					set 
						id_estatus_transferencia = 3, --Rechazada
						fecha_transferencia_realizada =@fecha_proceso,
						msj_error_transaccion = @msj_error_transaccion
					where
						id_transferencia = @id_transferencia

				-----------------	SE ACTUALIZA LA BITACORA CON EL FALLO DE TRANSFERENCIA	-------------------
				update bo set 
					bo.id_tipo_bitacora = case 
						when @id_tipo_transaccion = 1 then 80--'transferencia no realizada'
						when @id_tipo_transaccion = 2 then 81--'pago no realizado' 
						end, --bitacora de error de transferencia
					bo.fecha_alta =  @fecha_proceso
				from #TransaccionesProgramadas trasn_pro
				inner join
					TBL_BANCA_BITACORA_OPERACIONES bo on bo.id_bitacora = trasn_pro.id_bitacora
				where 
					trasn_pro.id_transferencia = @id_transferencia

			end
			
			/*PARCHE DEL VIERNES 21-06-2019 */
			--if(select estatus from #resultado_transferencia where id_transferencia = @id_transferencia and @id_tipo_transaccion = 2) = 200
			--begin
			--	print 'ingresa a actualizar el tipo de bitacora en el pago'
			--	-----------------	SE ACTUALIZA LA BITACORA CON EL PAGO DE PRESTAMO APLICADO	-------------------
			--	update bo set 
			--		bo.id_tipo_bitacora = case 
			--			--when @id_tipo_transaccion = 1 then 15--'transferencia no realizada'
			--			when @id_tipo_transaccion = 2 then 23--'pago no realizado' 
			--			end, --bitacora de error de transferencia
			--		bo.fecha_alta =  @fecha_proceso
			--	from #TransaccionesProgramadas trasn_pro
			--	inner join
			--		TBL_BANCA_BITACORA_OPERACIONES bo on bo.id_bitacora = trasn_pro.id_bitacora
			--	where 
			--		trasn_pro.id_transferencia = @id_transferencia
			--end

			set @registro =  @registro +  1
		END TRY
		BEGIN CATCH
			print 'Error al afectar la transferencia/pago No: '+ cast(@id_transferencia as varchar) + cast(ERROR_MESSAGE() as varchar)
			set @registro =  @registro +  1
		END CATCH
	end
	

end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 	 		
end catch
	
	--select * from CAT_BANCA_TIPOS_BITACORA
	/*
	CMV Finanzas, Deposito a @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5
	CMV Finanzas, Deposito a @cuentaDeposito por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5
	
	*/
	
	--select * from #TransaccionesProgramadas
	--select * from #resultado_transferencia

	INSERT INTO #notificaciones (idTipoNotificacion,celular,correo,cuerpo,numero,nombre_socio,tipo_bitacora)
	SELECT
		1,
		persona.Tel_Celular,
		persona.Mail,
		REPLACE(
			REPLACE(
			REPLACE(
			REPLACE(
			REPLACE (NSMS.cuerpo
			,'@numeroReferencia', 
			/*	51	Retiro de Inverdinamica 
				52	Retiro de Ahorro 
				53	Retiro de D�bito */
			CASE 
				WHEN BO.id_tipo_bitacora in (51,52,53) THEN --PARA LAS NOTIFICACIONES DE RETIROS (COMPLEMENTO DE LAS TRANSFERENCIAS)
					tipo_opeOrigen.Desc_prestamo +' '+COALESCE(SUBSTRING(trans_pro.clave_corresponsalias_origen,7,3)+'****'+RIGHT(trans_pro.clave_corresponsalias_origen,4),'') 
				ELSE --- PARA LAS NOTIFICACIONES QUE INDICAN EL DEPOSITO
					tipo_opeDestino.Desc_prestamo +' '+COALESCE(SUBSTRING(trans_pro.clave_corresponsalias_destino,7,3)+'****'+RIGHT(trans_pro.clave_corresponsalias_destino,4),'') 
			END collate Traditional_Spanish_CI_AS)
			,'@cuentaDeposito',COALESCE(SUBSTRING(trans_pro.clave_corresponsalias_destino,7,3) +'****'+RIGHT(trans_pro.clave_corresponsalias_destino,4),'') collate Traditional_Spanish_CI_AS)
			,'@importe',('$'+cast(COALESCE(trans_pro.monto,'') as varchar )) )
			,'@fecha_hora_operacion',CONVERT(varchar ,coalesce(trans_pro.fecha_transferencia_realizada ,BO.fecha_alta),103)
				+' '+FORMAT(CONVERT(datetime, coalesce(trans_pro.fecha_transferencia_realizada,BO.fecha_alta)), 'hh:mm:ss tt'))
			,'@folio',COALESCE(trans_pro.id_banca_folio, id_bitacora)
		) cuerpo
		,BO.numero_socio 
		,persona.Nombre_s + ' ' +COALESCE(persona.Apellido_Paterno,'') + ' ' +COALESCE(persona.Apellido_Materno,'')
		,B.descripcion 
	FROM 
		#resultado_transferencia re_trans
	inner join
		TBL_BANCA_TRANSFERENCIAS_INTERNAS trans_pro on re_trans.id_transferencia  = trans_pro.id_transferencia
	inner join
		BANCA..TBL_BANCA_BITACORA_OPERACIONES BO on BO.id_banca_folio = trans_pro.id_banca_folio  and BO.numero_socio = BANCA.dbo.FN_BANCA_DESCIFRAR(trans_pro.numero_socio)	
	--inner join BANCA..TBL_BANCA_CONTRATOS_BANCA CB ON CB.Numero  = trans_pro.numero_socio-- BO.numero_socio 
	inner join HAPE..TBL_CONTRATOS_HABERES CB ON CB.numero = BANCA.dbo.FN_BANCA_DESCIFRAR(trans_pro.numero_socio) and CB.id_tipo_contrato=3
	inner join
		BANCA..CAT_BANCA_TIPOS_BITACORA B ON BO.id_tipo_bitacora = B.id_tipo_bitacora
	inner join
		BANCA..TBL_BANCA_NOTIFICACIONES_SMS NSMS ON NSMS.id_tipo_bitacora = BO.id_tipo_bitacora AND cb.id_tipo_notificacion in (1,3)
	inner join
		hape..PERSONA persona on BO.numero_socio = persona.Numero and persona.Id_Tipo_Persona = 1
	---modificacion para enviar las notificaciones con el nombre de las cuentas
	inner join
		HAPE..TBL_CORRESPONSALIAS_CUENTAS corresOrigen on trans_pro.clave_corresponsalias_origen = corresOrigen.CUENTA 
	inner join 
		HAPE..TBL_CORRESPONSALIAS_CUENTAS corresDestino on trans_pro.clave_corresponsalias_destino = corresDestino.CUENTA 
	inner join
		HAPE..TIPOS_DE_OPERACIONES tipo_opeOrigen on tipo_opeOrigen.Id_mov = corresOrigen.ID_MOV 
	inner join
		HAPE..TIPOS_DE_OPERACIONES tipo_opeDestino on tipo_opeDestino.Id_mov = corresDestino.ID_MOV 
	WHERE
		re_trans.estatus = 200 --solo las transacciones correctas	
		and bo.id_tipo_bitacora not in(24)-- descartamos la notificacion de programacion de prestamo
	
	INSERT INTO #notificaciones (idTipoNotificacion,celular,correo,cuerpo,asunto,numero,nombre_socio,tipo_bitacora)
	SELECT
		2,
		persona.Tel_Celular,
		persona.Mail,
		REPLACE(
			REPLACE(
			REPLACE (
			REPLACE (
			REPLACE (
			REPLACE (
			REPLACE (
			REPLACE (NCORREO.cuerpo
			,'@imagen',NCORREO.url_img_operacion)
			,'@Nombre',(persona.Nombre_s + ' ' +COALESCE(persona.Apellido_Paterno,'') + ' ' +COALESCE(persona.Apellido_Materno,'')) )
			,'@Operacion',COALESCE(B.descripcion,'Bloqueo autom�tico') )
			,'@cuentaRetiro', tipo_opeOrigen.Desc_prestamo +' '+COALESCE(SUBSTRING(trans_pro.clave_corresponsalias_origen,7,3)+'****'+RIGHT(trans_pro.clave_corresponsalias_origen,4),'') collate Traditional_Spanish_CI_AS)--COALESCE(trans_pro.clave_corresponsalias_origen,'') collate Traditional_Spanish_CI_AS)
			,'@cuentaDeposito', tipo_opeDestino.Desc_prestamo +' '+COALESCE(SUBSTRING(trans_pro.clave_corresponsalias_destino,7,3)+'****'+RIGHT(trans_pro.clave_corresponsalias_destino,4),'') collate Traditional_Spanish_CI_AS)--COALESCE(trans_pro.clave_corresponsalias_destino,'') collate Traditional_Spanish_CI_AS)
			,'@importe',('$'+cast(COALESCE(trans_pro.monto,'') as varchar )) )
			,'@fecha_hora_operacion',CONVERT(varchar ,coalesce(trans_pro.fecha_transferencia_realizada ,BO.fecha_alta),103)
				+' '+FORMAT(CONVERT(datetime, coalesce(trans_pro.fecha_transferencia_realizada,BO.fecha_alta)), 'hh:mm:ss tt'))
			,'@folio',COALESCE(trans_pro.id_banca_folio, id_bitacora)
		) cuerpo,
		asunto
		,BO.numero_socio 
		,persona.Nombre_s + ' ' +COALESCE(persona.Apellido_Paterno,'') + ' ' +COALESCE(persona.Apellido_Materno,'')
		,B.descripcion
	FROM 
		#resultado_transferencia re_trans
	inner join
		TBL_BANCA_TRANSFERENCIAS_INTERNAS trans_pro on re_trans.id_transferencia  = trans_pro.id_transferencia
	inner join
		BANCA..TBL_BANCA_BITACORA_OPERACIONES BO on BO.id_banca_folio = trans_pro.id_banca_folio  and BO.numero_socio = BANCA.dbo.FN_BANCA_DESCIFRAR(trans_pro.numero_socio)
	--inner join BANCA..TBL_BANCA_CONTRATOS_BANCA CB ON CB.Numero = BO.numero_socio 
	inner join HAPE..TBL_CONTRATOS_HABERES CB ON CB.numero = BANCA.dbo.FN_BANCA_DESCIFRAR(trans_pro.numero_socio) and CB.id_tipo_contrato=3
	inner join
		BANCA..CAT_BANCA_TIPOS_BITACORA B ON BO.id_tipo_bitacora = B.id_tipo_bitacora
	inner join
		BANCA..TBL_BANCA_NOTIFICACIONES_CORREO NCORREO ON NCORREO.id_tipo_bitacora = BO.id_tipo_bitacora AND cb.id_tipo_notificacion in (2,3)
	inner join
		hape..PERSONA persona on BO.numero_socio = persona.Numero and persona.Id_Tipo_Persona = 1
	---modificacion para enviar las notificaciones con el nombre de las cuentas
	inner join
		HAPE..TBL_CORRESPONSALIAS_CUENTAS corresOrigen on trans_pro.clave_corresponsalias_origen = corresOrigen.CUENTA 
	inner join 
		HAPE..TBL_CORRESPONSALIAS_CUENTAS corresDestino on trans_pro.clave_corresponsalias_destino = corresDestino.CUENTA 
	inner join
		HAPE..TIPOS_DE_OPERACIONES tipo_opeOrigen on tipo_opeOrigen.Id_mov = corresOrigen.ID_MOV 
	inner join
		HAPE..TIPOS_DE_OPERACIONES tipo_opeDestino on tipo_opeDestino.Id_mov = corresDestino.ID_MOV 
	WHERE
		re_trans.estatus = 200 --solo las transacciones correctas
		and bo.id_tipo_bitacora not in(24)-- descartamos la notificacion de programacion de prestamo
	
	select * from #notificaciones order by numero

	drop table #TransaccionesProgramadas
	drop table #resultado_transferencia
	drop table #notificaciones

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_APROVISIONAR_TOKEN]    Script Date: 21/08/2019 10:44:23 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_APROVISIONAR_TOKEN]
@NUMERO AS VARCHAR(20)
AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int 

select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)
set @numero_int = CAST(@NUMERO as int )

  if(@mensaje_validacion is null)
  BEGIN
	IF EXISTS (SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @NUMERO AND id_estatus_banca = 4)
	BEGIN
		if not exists(Select * from TBL_BANCA_SOCIOS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int and id_estatus_banca = 5)
		begin
			SET @numero_int = CAST(@NUMERO as int )
			UPDATE TBL_BANCA_SOCIOS SET id_estatus_banca = 5 WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int
			select 200 estatus
		end
		else 
		begin
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 313
		end
	END
	ELSE
	BEGIN
			SELECT id_excepcion AS estatus , descripcion as mensaje 
			FROM CAT_BANCA_EXCEPTIONS
			WHERE id_excepcion = 306
	END
  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje
end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ASIGNAR_CONTRASENA_EDO_CUENTA]    Script Date: 16/08/2019 08:38:34 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		EDSON
-- Create date: 2018-10-23
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_ASIGNAR_CONTRASENA_EDO_CUENTA]
	@numero_socio int,
	@contrasena varchar(100),
	@tipo_origen int = null,
	@numero_usuario varchar(20) = null
AS
BEGIN

begin try

	DECLARE 
	@mensaje varchar(200),
	@estatus int =1, 
	@id_tipo_bitacora int  = 42,
	@id_banca_folio int,
	@estatus_banca_socio int

	SELECT @estatus_banca_socio = id_estatus_banca FROM TBL_BANCA_SOCIOS WHERE banca.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio

	IF @estatus_banca_socio >= 3
	BEGIN
		
		UPDATE TBL_BANCA_SOCIOS
		SET
			contrasena_estado_cuenta = @contrasena
		WHERE
			banca.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio
		
		--------------------	BITACORA	--------------------
		IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
		BEGIN
			--se inserta a la bitacora directa ya que no es una accion de tansaccionalidad
			INSERT INTO TBL_BANCA_BITACORA_OPERACIONES (id_tipo_bitacora,numero_socio,fecha_alta,id_origen_operacion,usuario)
			VALUES (@id_tipo_bitacora , @numero_socio , getdate() , @tipo_origen,@numero_usuario)
			
		END
		
		select @estatus = 1, @mensaje = 'Asignaci�n correcta de contrase�a para la descarga de estado de cuenta.'

	END 
	ELSE
		select @estatus = 0, @mensaje = 'El estatus del socio no permite realizar esta acci�n.'

end try
begin catch
	select @estatus = 0, @mensaje = ERROR_MESSAGE() 	
end catch

	select @estatus as status , @mensaje as [error_message]

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ASIGNAR_CONTRASENA_TEMP]    Script Date: 16/08/2019 08:38:15 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		EDSON
-- Create date: 2018-10-23
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_ASIGNAR_CONTRASENA_TEMP]
	@numero_socio int,
	@contrasena_temp varchar(100),
	@tipo_origen int = null,
	@numero_usuario varchar(20) = null
AS
BEGIN

begin try

	DECLARE 
	@mensaje varchar(200),
	@estatus int =1, 
	@id_tipo_bitacora int  = 2,
	@id_banca_folio int,
	@estatus_banca_socio int

	SELECT @estatus_banca_socio = id_estatus_banca FROM TBL_BANCA_SOCIOS WHERE banca.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio

	IF @estatus_banca_socio >= 3 AND @estatus_banca_socio<6
	BEGIN
		
		UPDATE TBL_BANCA_SOCIOS
		SET
			contrasena_temp = @contrasena_temp,
			fecha_contrasena_temporal =  GETDATE(),
			id_estatus_banca = (case when @estatus_banca_socio = 3 then 4 else id_estatus_banca end),
			recuperar_contrasena =0,
			id_motivo_bloqueo = 1
		
		WHERE
			banca.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio
		
		--------------------	BITACORA	--------------------
		IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
		BEGIN
			--se inserta a la bitacora directa ya que no es una accion de tansaccionalidad
			INSERT INTO TBL_BANCA_BITACORA_OPERACIONES (id_tipo_bitacora,numero_socio,fecha_alta,id_origen_operacion,usuario)
			VALUES (@id_tipo_bitacora , @numero_socio , getdate() , @tipo_origen,@numero_usuario)
			/*
			INSERT INTO TBL_BANCA_FOLIOS (numero_socio,fecha_alta) values (@numero_socio,GETDATE())

			select @id_banca_folio = max(id_banca_folio)from TBL_BANCA_FOLIOS where numero_socio = @numero_socio
			
			EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_socio, @id_tipo_bitacora, @tipo_origen,@id_banca_folio,@numero_usuario
			*/
		END
		
		select @estatus = 200, @mensaje = 'Asignaci�n correcta de contrase�a registro.'

	END 
	ELSE
		select @estatus = 0, @mensaje = 'El estatus del socio no permite realizar esta acci�n.'

end try
begin catch
	select @estatus = 0, @mensaje = ERROR_MESSAGE() 	
end catch

	select @estatus as estatus , @mensaje as mensaje

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_AUTENTICAR_SOCIO]    Script Date: 10/10/2019 01:04:42 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			MAXIMILIANO GONZALEZ BETANCOURT
UsuarioRed		GOBM391548
Fecha			20180417
Objetivo		VALIDA EL NUMERO Y CONTRASE�A RECIBIDOS PARA EL INICIO DE SESION
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_AUTENTICAR_SOCIO]
	
		-- par�metros
		
		-- [aqu� van los par�metros]
    @numero varchar(20),
	@contrasena varchar(255),
	@tipo_origen int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@descripcion_estatus varchar(255),
						@validacion varchar(255),
						@numero_socio int,
						@contrasena_usuario varchar(255),
						@esSocioPuntal bit = 0,
						@pathImagen varchar (max) = '',
						@tipoSocioPuntal int
			
			end -- inicio
			
			

				--VALIDACIONES	
				--select @validacion = dbo.FN_BANCA_VALIDA_SOCIO(@numero,1)
				select @status = estatus, @validacion = msj from dbo.FN_BANCA_VALIDA_SOCIO (@Numero,1)
				IF(@validacion is null)
					BEGIN
					select @numero_socio = CAST(@numero as int)
					
					declare		
						@fechaContrasenaTemporal datetime, 
						@contrasenaTemporal varchar(300),
						@fechaContrasena datetime, 
						@viene_de_bloqueo bit
						
						select 
							@fechaContrasena = fecha_alta_contrasena , @fechaContrasenaTemporal = fecha_contrasena_temporal,
							@contrasena_usuario = contrasena , @viene_de_bloqueo  = isnull(viene_de_bloqueo,0), 
							@contrasenaTemporal = contrasena_temp
						from TBL_BANCA_SOCIOS 
						where
							BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio

					if(@fechaContrasena < @fechaContrasenaTemporal and @viene_de_bloqueo = 0)
					begin
						SELECT id_excepcion AS estatus , descripcion as [error_message]
						FROM CAT_BANCA_EXCEPTIONS
						WHERE id_excepcion = 333
						return
					end
					
					--IF(@contrasena = @contrasena_usuario)
					IF(
						(@contrasena = @contrasena_usuario and @viene_de_bloqueo = 0)
						or
						(@contrasena = @contrasenaTemporal and @viene_de_bloqueo = 1)
					)
					BEGIN
						IF EXISTS (SELECT 1 FROM HAPE..TBL_SOCIO_PUNTUAL WHERE NUMERO  = @numero )
						begin
							SELECT @tipoSocioPuntal =  id_tipo_socio_puntual FROM  HAPE..TBL_SOCIO_PUNTUAL WHERE NUMERO  = @numero 
						    SET @esSocioPuntal = 1
							
							-- obtenemos la ruta de la imagen ya sea socio puntual o normal
							SELECT @pathImagen = ruta_imagen FROM TBL_BANCA_IMAGENES 
							WHERE 
							 id_tipo_imagen =(CASE WHEN  @tipoSocioPuntal = 1 THEN 3 ELSE 0 END ) OR
							 id_tipo_imagen =(CASE WHEN  @tipoSocioPuntal = 2 THEN 4 ELSE 0 END ) 
							
						end
							
						-- select * from CAT_BANCA_TIPO_IMAGENES
						-- select * from TBL_BANCA_IMAGENES
						select 
						200 estatus, 
						ISNULL(Nombre_s,'')+' '+ISNULL(Apellido_Paterno,'')+' '+ISNULL(Apellido_Materno,'') Nombre_Completo,
						@esSocioPuntal es_socio_puntual,
						@pathImagen path_imagen,
						@tipoSocioPuntal tipo_socio_puntual,
						ISNULL(OP.descripcion,'Bienvenido a CMV Finanzas') ultima_sesion,
						S.fecha_ultima_sesion,
						case when edc.tarjeta_activa is null or  edc.tarjeta_activa ='' or  edc.tarjeta_activa='F' then 0 
							 when edc.tarjeta_activa ='T' then 1
					    end tarjetaActiva
						from TBL_BANCA_SOCIOS S 
						INNER JOIN
							HAPE..PERSONA P  ON BANCA.dbo.FN_BANCA_DESCIFRAR(S.numero_socio) = P.Numero AND P.Id_Tipo_Persona = 1
						LEFT JOIN
							BANCA..CAT_BANCA_ORIGEN_OPERACION OP on S.id_ultima_sesion  = OP.id_origen_operacion
						LEFT JOIN 
						     HAPE..EDO_DE_CUENTA EDC ON EDC.NUMERO = BANCA.dbo.FN_BANCA_DESCIFRAR(S.NUMERO_SOCIO) AND EDC.ID_MOV = 112
						where P.Numero = @numero_socio and P.Id_Tipo_Persona = 1
					
						update BANCA..TBL_BANCA_SOCIOS 
						set 
							id_ultima_sesion = @tipo_origen,
							fecha_ultima_sesion = GETDATE(),
							intentos_sesion = 0,
							intentos_respuesta=0
						where
							BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio
						-- INSERT EN LA BITACORA
						   IF @@ERROR = 0 
						   BEGIN
								IF OBJECT_ID('tempdb..#notificaciones') IS NOT NULL
									DROP TABLE #notificaciones

								DECLARE @id_tipo_bitacora INT = 64--	Ingreso de sesi�n
								
								CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));
								INSERT INTO #Bitacora
								EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero, @id_tipo_bitacora, @tipo_origen

						    END
					   -- FIN DE INSERT EN LA BITACORA
					END
					ELSE
					BEGIN
						
						DECLARE
							@limite_intentos_sesion int= 3,
							@intentos_sesion_socio int

						--AUMENTO DE INTENTOS DE INGRESO INCORRECTOS
						UPDATE TBL_BANCA_SOCIOS SET intentos_sesion = (ISNULL(intentos_sesion,0) +1)
						WHERE
							BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio

						SELECT @intentos_sesion_socio = ISNULL(intentos_sesion,0) FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio
						
						-- VALIDAMOS SI CUMPLE CON 3 INTENTOS SE BLOQUEA LA CUENTA
						IF (@intentos_sesion_socio) >= @limite_intentos_sesion
						BEGIN
							UPDATE TBL_BANCA_SOCIOS 
							SET 
								--CAT_BANCA_MOTIVOS_BLOQUEO --Bloqueo temporal contrasena incorrecta 3 ocaciones
								id_motivo_bloqueo =2 ,  
								viene_de_bloqueo = 1,
								fecha_motivo_bloqueo = GETDATE()
							WHERE 
								BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero

							SELECT  @status = id_excepcion  ,@error_message =  descripcion 
							FROM CAT_BANCA_EXCEPTIONS
							WHERE id_excepcion = 387

						END
						ELSE
							SELECT  @status = id_excepcion  ,@error_message =   'Le restan '+ cast((@limite_intentos_sesion-@intentos_sesion_socio) as varchar)+ ' intentos.' 
							FROM CAT_BANCA_EXCEPTIONS
							WHERE id_excepcion = 308
						
						SELECT @status AS estatus, @error_message error_message 

					END
				END
				ELSE
				BEGIN
					SELECT @error_message = @validacion
					SELECT @status AS estatus, @error_message error_message 
				END 


		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@status=0
		
			select @error_message as error_message, @status as status
		
		end catch -- catch principal
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_BLOQUEAR_SOCIO]    Script Date: 16/08/2019 08:37:05 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez
UsuarioRed		pegc837648
Fecha			20181023
Objetivo		Bloquear socio con banca activa en TBL_BANCA_SOCIOS
Proyecto		Administrador de Banca Electr�nica
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_BLOQUEAR_SOCIO]
	
		-- par�metros
		@numero_Socio int = null,
		@tipo_origen int = null,
		@numero_usuario varchar(20) = null,
		@descripcion_bloqueo varchar(max),
		@id_tipo_bitacora int,
		@id_motivo_bloqueo int,
		@xml xml = null 

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@id_banca_folio int
						--@id_tipo_bitacora int  = 7 ---cambiar esta variable a un parametro del SP
			
			end -- inicio
			
					begin -- validaciones
				if(@numero_Socio <>null)
				begin
					if not exists(SELECT * FROM HAPE.DBO.PERSONA WHERE NUMERO = @numero_Socio and @numero_Socio <> null)
						raiserror('El socio ingresado no existe',11,0)
					else if not exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio)
					raiserror('El socio no est� registrado en �CMV finanzas�',11,0)

					if exists (SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio and (id_estatus_banca<6 and banca_activa=0))
						raiserror('El socio ingresado no tiene su cuenta de �CMV finanzas� Activa',11,0)

					if exists (SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio and (id_motivo_bloqueo>1 and viene_de_bloqueo=1))
						raiserror('El socio ingresado ya est� Bloqueado en �CMV finanzas�',11,0)
				end

			end -- validaciones

			IF(@xml is not NULL and @numero_Socio is null)
			BEGIN
				SELECT
					Cuentas.value('Fecha_Alerta[1]', 'datetime') fecha_alerta_,			
					Cuentas.value('NUMERO_SOCIO[1]', 'int') numero_socio_,
					Cuentas.value('DESCRIPCION[1]', 'varchar(255)') descripcion_Alerta_
					into #bloquearSocios
					FROM 
				@xml.nodes('/Bloqueo_Fraudes/Numeros_alertados') AS XD(Cuentas)

				if exists(select numero_socio from banca..TBL_BANCA_SOCIOS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)  in(select numero_socio_ from #bloquearSocios) and banca_activa = 1 and id_motivo_bloqueo = 1)
					begin
					update banca..TBL_BANCA_SOCIOS 
						set 
							id_motivo_bloqueo=@id_motivo_bloqueo,
							fecha_motivo_bloqueo = GETDATE(),
							viene_de_bloqueo = 1,
							descripcion_bloqueo=@descripcion_bloqueo
						from  banca..TBL_BANCA_SOCIOS bancaSocios, #bloquearSocios bancaSociosTemp
						where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = bancaSociosTemp.numero_socio_;

						INSERT INTO 
						banca..TBL_BANCA_BITACORA_OPERACIONES 
						(
							id_tipo_bitacora,
							numero_socio,
							fecha_alta,
							id_origen_operacion
						)
		
						select 
							@id_tipo_bitacora, 
							numero_socio_,
							getdate(),
							@tipo_origen
						from 
							#bloquearSocios 
						where 
							numero_socio_  
						in (
							select 
								BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) 
							from 
								banca..TBL_BANCA_SOCIOS
							)
		
					end

				drop table #bloquearSocios
			END
			ELSE
			BEGIN

				update TBL_BANCA_SOCIOS set 
					id_motivo_bloqueo=@id_motivo_bloqueo,
					fecha_motivo_bloqueo = GETDATE(),
					viene_de_bloqueo = 1,
					descripcion_bloqueo=@descripcion_bloqueo
				where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio;

				IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
					BEGIN
					INSERT INTO 
						TBL_BANCA_BITACORA_OPERACIONES 
						(
							id_tipo_bitacora,
							numero_socio,
							fecha_alta,
							id_origen_operacion,
							usuario
						)
						VALUES 
						(
						@id_tipo_bitacora ,
							@numero_socio ,
							getdate() ,
							@tipo_origen,
							@numero_usuario
						)

						--INSERT INTO TBL_BANCA_FOLIOS 
						--(
						--	numero_socio,
						--	fecha_alta
						--) 
						--values (@numero_socio,GETDATE())

						--select @id_banca_folio = max(id_banca_folio)from TBL_BANCA_FOLIOS where numero_socio = @numero_Socio

						--EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_Socio, @id_tipo_bitacora, @tipo_origen,@id_banca_folio,@numero_usuario
					END
				END
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_BLOQUEO_AUTOMATICO_DE_ACCESO]    Script Date: 21/08/2019 11:51:21 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		EDSON
-- Create date: 2018-09-10
-- Description:	
--@Tipo_Bloqueo_OTP :	
--			Resetear la fecha de bloqueo de OTP = 1,
--			Colocar la fecha de bloqueo de OTP = 2
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_BLOQUEO_AUTOMATICO_DE_ACCESO]
	@fecha_proceso datetime

AS
BEGIN

begin try

	DECLARE 
	@mensaje_validacion varchar(500),
	@estatus int,
	@tipo_origen int = 5 --
	/*
	
select * from CAT_BANCA_MOTIVOS_BLOQUEO order by id_motivo_bloqueo desc
select * from CAT_BANCA_TIPOS_BITACORA order by id_tipo_bitacora desc 
	*/


	IF @fecha_proceso is null
		SELECT @fecha_proceso = GETDATE()
	
	create table #Socios_Bloqueados
	(
		numero int,
		id_tipo_bitacora int,
		id_motivo_bloqueo  int
	)

	create table #notificaciones
	(
		idTipoNotificacion int , 
		celular varchar(20),
		correo varchar(500),
		cuerpo varchar(max),
		asunto varchar(500),
		numero int,
		nombre_socio varchar(200),
		tipo_bitacora varchar(500)
	)

	/*
	o	Bloquear el acceso a los socios que tengan inactividad en el servicio en 1 a�o.
			-	Tomando en base el ultimo logeo.
			-	El a�o es en relaci�n a fecha. 
	*/
	insert into #Socios_Bloqueados (numero,id_tipo_bitacora,id_motivo_bloqueo)
	select 
		banca.dbo.fn_banca_descifrar(numero_socio)
		,56 -- Bloqueo autom�tico por inactividad en el servicio en 365 d�as (En base al �ltimo acceso)
		,4 -- Bloqueo autom�tico por inactividad en el servicio en 365 d�as (En base al �ltimo acceso)
	from BANCA..TBL_BANCA_SOCIOS
	where
		DATEDIFF(YEAR,isnull(fecha_ultima_sesion,@fecha_proceso),@fecha_proceso) >= 1
		and banca_activa = 1
		and id_motivo_bloqueo = 1

	/*
	o	Bloquear el acceso a todos los socios que tengan activo el servicio y se le aplique bloqueo Alto 
		considerando los diferentes bloqueos que se tienen:
			?	Bloqueo desde Imagen (pendiente de confirmar)
			?	Bloqueo de Cobranza.
			?	Bloqueo de Exclusi�n(pendiente).
	*/
	insert into #Socios_Bloqueados (numero,id_tipo_bitacora,id_motivo_bloqueo)
	select 
		banca.dbo.fn_banca_descifrar(sociosBanca.numero_socio)
		,58 -- Bloqueo autom�tico por bloqueo alto de Cobranza
		,10 -- Bloqueo autom�tico por bloqueo alto de Cobranza
	from hape..PERSONA persona
	inner join
		BANCA..TBL_BANCA_SOCIOS sociosBanca on persona.Numero = banca.dbo.fn_banca_descifrar(sociosBanca.numero_socio) and persona.Id_Persona = sociosBanca.id_persona
	where
		persona.Id_Tipo_Persona = 1
		and persona.Bloqueado_Cobranza = 'A'	 
		and sociosBanca.banca_activa = 1
		and sociosBanca.id_motivo_bloqueo = 1

	/*o	Bloquear el acceso a todos los socios que tengan activo el servicio y se les apliquen quebrantos.*/
	insert into #Socios_Bloqueados (numero,id_tipo_bitacora,id_motivo_bloqueo)
	select 
		banca.dbo.fn_banca_descifrar(sociosBanca.numero_socio)
		,59 -- Bloqueo autom�tico por aplicaci�n de quebrantos
		,11 -- Bloqueo autom�tico por aplicaci�n de quebrantos
	from QUEBRANTOS..quebranto_cuentas quebrantos
	inner join
		BANCA..TBL_BANCA_SOCIOS sociosBanca on quebrantos.Numero = banca.dbo.fn_banca_descifrar(sociosBanca.numero_socio)
	where
		quebrantos.id_status = 1	 
		and sociosBanca.banca_activa = 1
		and sociosBanca.id_motivo_bloqueo = 1

	/*o	Bloquear el acceso a todos los s ocios que se encuentren en proceso de bloqueo de exclusi�n. */
	insert into #Socios_Bloqueados (numero,id_tipo_bitacora,id_motivo_bloqueo)
	select 
		banca.dbo.fn_banca_descifrar(sociosBanca.numero_socio)
		,60 -- Bloqueo autom�tico por que se encuentra en proceso de bloqueo de exclusi�n
		,12 -- Bloqueo autom�tico por que se encuentra en proceso de bloqueo de exclusi�n
	from hape..PERSONA persona
	inner join
		BANCA..TBL_BANCA_SOCIOS sociosBanca on persona.Numero = banca.dbo.fn_banca_descifrar(sociosBanca.numero_socio) and persona.Id_Persona = sociosBanca.id_persona
	where
		persona.Id_Tipo_Persona = 1
		and persona.Bloqueado_Exclusion ='A' 	 
		and sociosBanca.banca_activa = 1
		and sociosBanca.id_motivo_bloqueo = 1


	update socios set 
		socios.id_motivo_bloqueo = soBl.id_motivo_bloqueo
		,socios.fecha_motivo_bloqueo = @fecha_proceso
	from 
		BANCA..TBL_BANCA_SOCIOS socios
	inner join	
		#Socios_Bloqueados soBl on banca.dbo.fn_banca_descifrar(socios.numero_socio) = soBl.numero


	----------------------------	INSERCI�N  A LA BIRACORA DE BANCA	-------------------------
	insert into 
		BANCA..TBL_BANCA_BITACORA_OPERACIONES (id_tipo_bitacora,numero_socio,fecha_alta,id_origen_operacion,usuario)
	select 
		id_tipo_bitacora,numero,@fecha_proceso,5,0 
	from 
		BANCA..TBL_BANCA_SOCIOS socios
	inner join	
		#Socios_Bloqueados soBl on banca.dbo.fn_banca_descifrar(socios.numero_socio) = soBl.numero and socios.id_motivo_bloqueo = soBl.id_motivo_bloqueo
	where
		socios.fecha_motivo_bloqueo = @fecha_proceso
	----------------------------										-------------------------




end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 	 		
end catch

	------------------------------------	SE REGRESAN LOS SOCIOS BLOQUEADOS	------------------------------
	/*select 
		200 as estatus,
		isnull(p.Nombre_s,' ')+' '+isnull(p.Apellido_Paterno,' ')+' '+isnull(p.Apellido_Materno,' ') nombreCompleto,
		CB.id_tipo_notificacion,
		p.Mail,
		p.Tel_Celular,
		socios.id_motivo_bloqueo,
		P.*
	from 
		TBL_BANCA_SOCIOS socios
	inner join	
		#Socios_Bloqueados soBl on socios.numero_socio = soBl.numero and socios.id_motivo_bloqueo = soBl.id_motivo_bloqueo
	inner join 
		HAPE..PERSONA p on socios.numero_socio = p.Numero and socios.id_persona = p.Id_Persona
	LEFT JOIN BANCA..TBL_BANCA_CONTRATOS_BANCA CB ON CB.Numero = socios.numero_socio 
	where
		socios.fecha_motivo_bloqueo = @fecha_proceso 
	*/

	---------------------------------------------------------------------------------------------------
	INSERT INTO #notificaciones (idTipoNotificacion,celular,correo,cuerpo,numero,nombre_socio,tipo_bitacora)
	SELECT
		1,
		persona.Tel_Celular,
		persona.Mail,
		REPLACE(
			REPLACE(
			REPLACE (NSMS.cuerpo
			,'@Nombre',(persona.Nombre_s + ' ' +COALESCE(persona.Apellido_Paterno,'') + ' ' +COALESCE(persona.Apellido_Materno,'')) )
			,'@fecha_hora_operacion',CONVERT(varchar , BO.fecha_alta,103)+' '+FORMAT(CONVERT(datetime, BO.fecha_alta), 'hh:mm:ss tt'))
			,'@folio',COALESCE(id_banca_folio, id_bitacora)
		) cuerpo
		,soBl.numero
		,persona.Nombre_s + ' ' +COALESCE(persona.Apellido_Paterno,'') + ' ' +COALESCE(persona.Apellido_Materno,'')
		,B.descripcion
	FROM 
		BANCA..TBL_BANCA_BITACORA_OPERACIONES BO 
	inner join	
		#Socios_Bloqueados soBl on BO.numero_socio = soBl.numero and BO.id_tipo_bitacora = soBl.id_tipo_bitacora
	--inner join BANCA..TBL_BANCA_CONTRATOS_BANCA CB ON CB.Numero = soBl.numero 
	inner join HAPE..TBL_CONTRATOS_HABERES CB ON CB.numero = soBl.numero and CB.id_tipo_contrato=3 
	inner join
		BANCA..CAT_BANCA_TIPOS_BITACORA B ON BO.id_tipo_bitacora = B.id_tipo_bitacora
	inner join
		BANCA..TBL_BANCA_NOTIFICACIONES_SMS NSMS ON NSMS.id_tipo_bitacora = BO.id_tipo_bitacora AND cb.id_tipo_notificacion in (1,3)
	inner join
		hape..PERSONA persona on soBl.numero = persona.Numero and persona.Id_Tipo_Persona = 1
	WHERE
		BO.fecha_alta = @fecha_proceso
	
	INSERT INTO #notificaciones (idTipoNotificacion,celular,correo,cuerpo,asunto,numero,nombre_socio,tipo_bitacora)
	SELECT
		2,
		persona.Tel_Celular,
		persona.Mail,
		REPLACE(
			REPLACE(
			REPLACE (
			REPLACE (
			REPLACE (NCORREO.cuerpo,'@imagen',NCORREO.url_img_operacion)
			,'@Operacion',COALESCE(B.descripcion,'Bloqueo autom�tico') )
			,'@Nombre',(persona.Nombre_s + ' ' +COALESCE(persona.Apellido_Paterno,'') + ' ' +COALESCE(persona.Apellido_Materno,'')) )
			,'@fecha_hora_operacion',CONVERT(varchar , BO.fecha_alta,103)+' '+FORMAT(CONVERT(datetime, BO.fecha_alta), 'hh:mm:ss tt'))
			,'@folio',COALESCE(id_banca_folio, id_bitacora)
		) cuerpo,
		asunto
		,soBl.numero
		,persona.Nombre_s + ' ' +COALESCE(persona.Apellido_Paterno,'') + ' ' +COALESCE(persona.Apellido_Materno,'')
		,B.descripcion
	FROM 
		BANCA..TBL_BANCA_BITACORA_OPERACIONES BO 
	inner join	
		#Socios_Bloqueados soBl on BO.numero_socio = soBl.numero and BO.id_tipo_bitacora = soBl.id_tipo_bitacora
	--inner join BANCA..TBL_BANCA_CONTRATOS_BANCA CB ON CB.Numero = soBl.numero 
	inner join HAPE..TBL_CONTRATOS_HABERES CB ON CB.numero = soBl.numero and CB.id_tipo_contrato=3
	inner join
		BANCA..CAT_BANCA_TIPOS_BITACORA B ON BO.id_tipo_bitacora = B.id_tipo_bitacora
	inner join
		BANCA..TBL_BANCA_NOTIFICACIONES_CORREO NCORREO ON NCORREO.id_tipo_bitacora = BO.id_tipo_bitacora AND cb.id_tipo_notificacion in (2,3)
	inner join
		hape..PERSONA persona on soBl.numero = persona.Numero and persona.Id_Tipo_Persona = 1
	WHERE
		BO.fecha_alta = @fecha_proceso

	select * from #notificaciones order by numero
	
	drop table #Socios_Bloqueados
	drop table #notificaciones
	
END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_BLOQUEO_DATABANKING]    Script Date: 21/08/2019 11:51:43 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			VIC
UsuarioRed		REXV666480
Fecha			20180503
Objetivo		VALIDA EL NUMERO DE SOCIO PROPORCIONADO Y REGRESA EL NOMBRE DEL SOCIO ENMASCARADO
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_BLOQUEO_DATABANKING]
	
		-- par�metros
		
		-- [aqu� van los par�metros]
    @numero_socio varchar(20),
	@id_motivo_bloqueo INT =1,
	@fecha_motivo_bloqueo datetime = null

as

if(@fecha_motivo_bloqueo is null)
	SET @fecha_motivo_bloqueo = getdate()

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@descripcion_estatus varchar(255),
						@validacion varchar(255),
						@numero int 
			
			end -- inicio
				

				--VALIDACIONES	
				--select @validacion = dbo.FN_BANCA_VALIDA_SOCIO(@numero_socio,1)
				select @status = estatus, @validacion = msj from dbo.FN_BANCA_VALIDA_SOCIO (@numero_socio,0)
				IF(@validacion is null )
					BEGIN
					select @numero = CAST(@numero_socio as int)
					UPDATE TBL_BANCA_SOCIOS SET id_motivo_bloqueo =@id_motivo_bloqueo , fecha_motivo_bloqueo = @fecha_motivo_bloqueo
					WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero
					SELECT 200 estatus , 'Actualizado Correctamente' mensaje
				END
				ELSE
				BEGIN
					SELECT @error_message = @validacion
					SELECT @status AS estatus, @error_message mensaje 
				END 
		end try -- try principal
		
		begin catch -- catch principal
		
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@status=1000
		
			select @error_message as mensaje, @status as estatus
		
		end catch -- catch principal
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_BLOQUEO_TEMPORAL]    Script Date: 21/08/2019 11:52:41 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_BLOQUEO_TEMPORAL]
@NUMERO AS VARCHAR(20),
@id_motivo_bloqueo INT,
@tipo_origen int

AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int,
@id_tipo_bitacora int 

select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,0)
set @numero_int = CAST(@NUMERO as int )

  if(@mensaje_validacion is null)
  BEGIN
	IF EXISTS(SELECT * FROM CAT_BANCA_MOTIVOS_BLOQUEO WHERE id_motivo_bloqueo = @id_motivo_bloqueo)
	BEGIN
		UPDATE TBL_BANCA_SOCIOS SET id_motivo_bloqueo = @id_motivo_bloqueo WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int

		select @id_tipo_bitacora = 
			case
				---DESBLOQUEO
				when @id_motivo_bloqueo = 1 and @tipo_origen = 2 then 9 --DESDE SUCURSAL 
				when @id_motivo_bloqueo = 1 and @tipo_origen = 4 then 10 --DESDE DATABANKING
				---BLOQUEO TEMPORAL CONTRASENA INCORRECTA 3 OCACIONES
				when @id_motivo_bloqueo = 2 then 4
				---BLOQUEO TEMPORAL RESPUESTA INCORRECTA
				when @id_motivo_bloqueo = 3 then 33
				---BLOQUEO TEMPORAL 365 DE INACTIVIDAD
				when @id_motivo_bloqueo = 4 then 5
				---BLOQUEO TEMPORAL DESDE SUCURSAL
				when @id_motivo_bloqueo = 5 and @tipo_origen = 2 then 7
				---Bloqueo temporal desde callcenter
				when @id_motivo_bloqueo = 6 and @tipo_origen = 4 then 8
				---BLOQUEO TEMPORAL CONTRASENA CADUCO
				when @id_motivo_bloqueo = 7 then 34
				---BLOQUEO TEMPORAL PROPIO
				when @id_motivo_bloqueo = 8 then 32
			end

		CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));
		INSERT INTO #Bitacora
		EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_int, @id_tipo_bitacora, @tipo_origen

		SELECT 200 AS estatus
	END
	ELSE
	BEGIN 
		SELECT 316 AS estatus, 'El motivo del bloqueo no es valido' as mensaje
	END
  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje
end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_CAMBIA_CONTRASENA]    Script Date: 11/03/2020 08:52:40 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_CAMBIA_CONTRASENA]
@NUMERO varchar(20),
@contrasena_nueva varchar(255),
@contrasena_confirmacion varchar(255),
@idTipoOrigen int 
AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int,
@IdTipoBitacora int = 11, --Cambio de contrase�a
@valida_banca int = 1, --Para la funcion de validar banca
@intentos_respuesta bit = 0,--para validadar si existen intentos de respueta, para cuando se intenta cambiar desde la web de cmvFinanzas o movil
@respuesta_valida int

if(@idTipoOrigen = 6)
	set @valida_banca = 0

select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,@valida_banca)
set @numero_int = CAST(@NUMERO as int )

select @intentos_respuesta = intentos_respuesta from BANCA..TBL_BANCA_SOCIOS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int

  if(@mensaje_validacion is null)
  BEGIN

	/*	---se anexa la validacion que si pretende cambiar la contrase�a desde cmvFinanzas o movil por lo tanto
		-- se valida que no tenga intentos fallidos de respuesta secreta, en caso de tenerlos se niega el cambio de contrase�a
		-- se valida que la respuesta de seguridad haya sido correcta
	*/	

	select top 1 @respuesta_valida = id_tipo_bitacora  from TBL_BANCA_BITACORA_OPERACIONES 
		where numero_socio=@NUMERO order by fecha_alta desc	
			
	IF(@intentos_respuesta > 0 and @idTipoOrigen <> 6 ) or (@respuesta_valida = 98) or (@respuesta_valida < > 99)
	BEGIN 
		SELECT @estatus = 1000 , @mensaje_validacion = 'Datos incorrectos'
		SELECT @estatus AS estatus , @mensaje_validacion mensaje
		return
	END
	IF EXISTS(

		SELECT * FROM(
		SELECT TOP 3 * FROM BANCA..TBL_BANCA_CONTRASENAS_SOCIO WHERE numero_socio = @numero_int
		ORDER BY fecha_alta DESC
		)CONTRA_ULTIMAS_3
		WHERE
			CONTRA_ULTIMAS_3.contrasena = @contrasena_nueva

	) or exists (select 1  from TBL_BANCA_SOCIOS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) =  @numero_int and contrasena = @contrasena_nueva)
	BEGIN
		SELECT id_excepcion AS estatus , descripcion as mensaje 
		FROM CAT_BANCA_EXCEPTIONS
		WHERE id_excepcion = 386
	END

	ELSE
	BEGIN

		IF (@contrasena_nueva = @contrasena_confirmacion)
		BEGIN
			
			INSERT INTO TBL_BANCA_BITACORA_OPERACIONES (id_tipo_bitacora,numero_socio,fecha_alta,id_origen_operacion)
			VALUES (@IdTipoBitacora , @numero_int , getdate() , @idTipoOrigen)

			UPDATE TBL_BANCA_SOCIOS 
			SET 
				contrasena = @contrasena_nueva, 
				fecha_alta_contrasena = GETDATE(),
				/*PARA  CAMBIAR LA CONTRASE�A DESDE LA PAGINA WEB SE NECESITA ACTUALIZAR LOS SIGUIENTES VALORES*/
				viene_de_bloqueo=0,
				recuperar_contrasena =0,
				id_motivo_bloqueo = 1
			WHERE 
				BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int

			---insercion al historial de contrase�as
			INSERT INTO 
					TBL_BANCA_CONTRASENAS_SOCIO (numero_socio,contrasena,fecha_alta)
				VALUES	
					(@numero_int,@contrasena_nueva,GETDATE())

			if @@ERROR = 0
			begin
				SELECT TOP  1 
				200 estatus,  B.descripcion mensaje, convert (varchar , fecha_alta, 103) fecha ,convert (varchar , fecha_alta, 108) hora,
				A.id_bitacora folio 
				FROM TBL_BANCA_BITACORA_OPERACIONES  A 
				JOIN CAT_BANCA_TIPOS_BITACORA B ON A.id_tipo_bitacora = B.id_tipo_bitacora
				WHERE A.numero_socio =@numero_int and A.id_tipo_bitacora = @IdTipoBitacora
				ORDER BY id_bitacora desc
			end
			else
				SELECT 1000 AS estatus, 'El error no se encuentra en un cat�logo definido por CMV' AS mensaje
		END
		ELSE
		BEGIN
			SELECT id_excepcion AS estatus , descripcion as mensaje 
			FROM CAT_BANCA_EXCEPTIONS
			WHERE id_excepcion = 308
		END
	END

  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje



end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_CAMBIA_ESTADO_SPEI]    Script Date: 19/11/2019 11:41:02 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_CAMBIA_ESTADO_SPEI] 

         
@Id bigint,     -- Folio de la operaci�n en Enlace Financiero
@empresa varchar(15), -- Nombre de la empresa que est� configurada en �STP�.
@folioOrigen varchar(50),  -- Un folio espec�fico de la aplicaci�n llamante que identifique a �sta orden de pago.Si no se incluye, por defecto se toma el valor de la clave de rastreo (si se incluye).
@estado bit, --El estado de la orden. Existen �nicamente dos estados de SPEI. "�xito" y "Devoluci�n". Los clientes de STP definen los estados.
@causaDevolucion int,--    La causa de devolucion de un SPEI del catalogo Catalog� de Devoluci�n
@request varchar(max)=null
AS
BEGIN
	begin try -- try principal
			begin -- declaraciones
							declare	
								@status int=0,
								@error_message varchar(255) = '',
								@error_line varchar(255) = '',
								@error_severity varchar(255) = '',
								@error_procedure varchar(255) = '',
								@message varchar(255) = 'Se registro correctamente la transferencia',
								@fecha_operacion datetime,
								@id_cuenta_externa bigint,
								@id_transferencia bigint,
								@id_folio_banca bigint,
								@clave_rastreo varchar(500),
								@id_tipomov int,
								@id_mov int,
								@num_poliza int,
								@montoTransaccion money,
								@saldo_actual money,
								@id_persona bigint,
								@numero bigint,
								@numusuario int  = 1012,
								@id_estatus_transferencia  int = 2, --Operaci�n Realizada
								@id_tipo_bitacora int = 96,--	Pago de servicio rechazado
								@id_origen_transaccion int  = 7, -- SPEI
								@id_tipo_persona int=1,

								---
								@tipo_poliza varchar(1) = 'M',
								@ccostos_origen varchar(10),
								@ccostos_compensacion varchar(10),
								@Num_cuentaContable_sucursal varchar(100),
								@nombre_origen varchar(100),
								@Ap_paterno_origen varchar(100),
								@Ap_materno_origen varchar(100)

							declare	
								@tran_name varchar(32) = 'SP_BANCA_REGISTRA_TRANSFERENCIA_EXTERNA',
								@tran_count int = @@trancount,
								@tran_scope bit = 0
			end -- declaraciones



			begin --validaciones


				print 'paso 01 sin validaciones por el momento'	
				IF NOT  EXISTS (SELECT 1 FROM  TBL_BANCA_TRANSFERENCIAS_EXTERNAS	WHERE  clave_rastreo = @folioOrigen)
				BEGIN
				     Select @message ='no existe folio origen y/o clave de rastreo' , @status = 0
					 raiserror (@message, 11, 0)
				END

				IF EXISTS (SELECT 1 FROM  TBL_BANCA_TRANSFERENCIAS_EXTERNAS WHERE clave_rastreo = @folioOrigen AND notificado_por_stp = 1 and id_estatus_transferencia = (case when @estado = 1 then 2 else 3 end))
				BEGIN
				      select 200 as estatus,'Se registro correctamente la transferencia' as mensaje
					  return 
				END

				--IF  EXISTS (SELECT 1 FROM  TBL_BANCA_TRANSFERENCIAS_EXTERNAS	WHERE  clave_rastreo = @folioOrigen and id_estatus_transferencia = 2)
				--BEGIN
				--     Select @message ='El folio origen y/o clave de rastreo se encuentra en: Operacion Realizada' , @status = 0
				--	 raiserror (@message, 11, 0)
				--END

				IF  @estado = 0 and @causaDevolucion <= 0 
				BEGIN
				     Select @message ='Por favor verifique la causa de devolucion ' , @status = 0
					 raiserror (@message, 11, 0)
				END
									
			 end --validaciones

			 begin--Proceso

				print 'paso 02'
				--extraer datos generales
				select @fecha_operacion = getdate() 


				--obtenemos los datos de la transferencia
				SELECT 
				@id_folio_banca = id_banca_folio,
				@numero = BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio),
				@clave_rastreo = clave_rastreo,
				@id_transferencia = id_transferencia
				FROM  TBL_BANCA_TRANSFERENCIAS_EXTERNAS
				WHERE  clave_rastreo = @folioOrigen
							
				
				---Se obtiene el numero de poliza de banca
				select @num_poliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
				select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'SPEI')
				and dia = DAY(GETDATE())

				---se obtienen los datos de la cuenta de retiro
				Select @id_tipomov = 1167	-- Dep�sito a DEBITO CMV por operaci�n rechazada SPEI
				Select @id_mov = ID_MOV FROM HAPE..TIPO_MOV WHERE ID_TIPOMOV = @id_tipomov
				

				--- se obtienen datos del socio 
				select 
					@id_persona = p.Id_Persona,
					@nombre_origen = p.Nombre_s,
					@Ap_paterno_origen = p.Apellido_Paterno,
					@Ap_materno_origen = p.Apellido_Materno,
					@ccostos_origen = s.Ccostos,
					@Num_cuentaContable_sucursal = nSuc.Num_Cuenta_Compensacion
				from HAPE..PERSONA p
				join HAPE.dbo.sucursales s
					on s.id_de_sucursal = p.id_de_sucursal
				join HAPE..NUM_SUCURSAL nSuc 
					on s.Num_Sucursal = nSuc.Num_Sucursal
				where Numero = @numero and Id_Tipo_Persona = @id_tipo_persona

				select @ccostos_compensacion = Ccostos from HAPE..NUM_SUCURSAL
				WHERE
					Num_Sucursal = 99 --'MEDIOS DE PAGO%'

			end


			 begin -- Transaccionalidad

				 print 'paso 03 (inicio de transacci�n)'
					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1

				-----------------------		proceso de transaccionalidad		--------------------

				---se registra en el log de cambio de estado
				insert into TBL_BANCA_LOG_CAMBIO_ESTADO_SPEI 
					(id_transferencia,numero,id_folio,empresa,folio_origen,estado,causa_devolucion,request)
				values
					(@id_transferencia,@numero,@Id,@empresa,@folioOrigen,@estado,@causaDevolucion,@request)


				---- UPDATE de transferencia
				IF @estado = 1 
				BEGIN
				     PRINT ' ESTADO DE LA TRANSFERENCIA : CORRECTO'
					 set @id_tipo_bitacora = 17
					 
				     -- ACTUALIZAMOS EL ESTATUS DE LA TRANSFERENCIA
					 UPDATE TBL_BANCA_TRANSFERENCIAS_EXTERNAS SET id_estatus_transferencia =2  , fecha_transferencia_realizada =@fecha_operacion ,notificado_por_stp = 1
					 WHERE clave_rastreo = @folioOrigen

					 INSERT INTO TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
					 VALUES (@id_folio_banca,@id_tipo_bitacora , @numero , @fecha_operacion, @id_origen_transaccion)

				END
				ELSE
				BEGIN
					PRINT ' ESTADO DE LA TRANSFERENCIA : DEVUELTO'
					set @id_tipo_bitacora = 96

					UPDATE TBL_BANCA_TRANSFERENCIAS_EXTERNAS 
					SET id_estatus_transferencia =3 , id_causa_devolucion_spei = @causaDevolucion , fecha_transferencia_realizada = @fecha_operacion , notificado_por_stp = 1
					WHERE clave_rastreo = @folioOrigen

					INSERT INTO TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
					VALUES (@id_folio_banca,@id_tipo_bitacora , @numero , @fecha_operacion, @id_origen_transaccion)

					SELECT @montoTransaccion =  isnull(Monto,0) FROM BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero AND clave_rastreo = @clave_rastreo
					SELECT @saldo_actual =  isnull(Saldo_Actual,0) FROM HAPE..EDO_DE_CUENTA WHERE Numero = @numero AND Id_mov = 112
					
					print '@clave_rastreo: ' +cast(@clave_rastreo as varchar)
					print '@numero: ' +cast(@numero as varchar)
					print '@montoTransaccion: ' +cast(@montoTransaccion as varchar)
					print '@saldo_actual: ' +cast(@saldo_actual as varchar)

					/*========================================	ACTUALIZACI�N DE MOVIMIENTOS ==============================
				     ======================================================================================================*/

					INSERT	HAPE..MOVIMIENTOS
						(
						NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
						NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
						ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR, id_origen
						)
					VALUES(
						@numero, 'T', @fecha_operacion, @montoTransaccion,round((@saldo_actual + @montoTransaccion),2), 'D',
						@num_poliza, @id_folio_banca, GETDATE(), @id_persona, @numusuario,
						@id_tipomov, @id_mov, 1, 'S', 7)


					/*========================================	ACTUALIZACI�N DE ESTADO DE CUENTA	================================
					==============================================================================================================*/
					UPDATE	HAPE..EDO_DE_CUENTA
					SET	SALDO_ACTUAL = round(@saldo_actual + @montoTransaccion,2),
						FECHA = @fecha_operacion
					WHERE	
						numero = @numero
						and id_mov = @id_mov
						AND Id_Tipo_persona = 1


					begin -- preparar captura
						
						--SPEI
						insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = '14100611940000'
						--sucursal del socio
						insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = @Num_cuentaContable_sucursal
						--Medios de pago		
						insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%MEDIOS%'
								and cc.Num_cuenta like '1410100099%'
						--movimiento de cuenta
						insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = tm.descripcion,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%DEBITO%'
								and cc.Num_cuenta like '2160000000%'
						
					end	-- preparar captura

					begin -- preparar captura_lacp
						
						--SPEI
						insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = '14100611940000'
						--sucursal del socio
						insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = @Num_cuentaContable_sucursal
						--Medios de pago		
						insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%MEDIOS%'
								and cc.Num_cuenta like '1410100099%'
						--movimiento de cuenta
						insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = tm.descripcion,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%DEBITO%'
								and cc.Num_cuenta like '2160000000%'
						
					end	-- preparar CAPTURA_lacp
			 END
								

				
			end   -- Transaccionalidad

			begin -- commit
				
					if @tran_count = 0
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							print 'paso 3.1 (commit de transacci�n)'
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				select @status = 200,@error_message ='Se registro correctamente la transferencia'
			end -- commit
			




	end try -- try principal
	
	begin catch -- catch principal

		select @status=coalesce(@status, 0)

		select	--@status=@status,
				--@status =error_state(),	
				@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
				@error_line = error_line(),
				@error_message = error_message(),
				@error_severity =
					case error_severity()
						when 11 then 'Error en validaci�n'
						when 12 then 'Error en consulta'
						when 13 then 'Error en actualizaci�n'
						else 'Error general'
					end

				--select @status=coalesce(@status, 0)
		-- revertir transacci�n si es necesario
		if @tran_scope = 1
		begin
			rollback tran @tran_name
		end
		
	end catch -- catch principal
	
		select @status as estatus ,@error_message  as mensaje , @numero as numeroSocio
END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_CANCELA_PAGO_SERVICIO]    Script Date: 21/08/2019 11:56:00 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			MAXIMILIANO GONZALEZ BETANCOURT
UsuarioRed		GOBM391548
Fecha			20180417
Objetivo		OBTIENE EL CATALOGO DE PREGUNTAS PARA QUE EL SOCIO SELECCIONE UNA 
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc
	[dbo].[SP_BANCA_CANCELA_PAGO_SERVICIO]
		-- par�metros
		@idPagoServicio int
		--@Monto decimal(18,2),
		--@NumeroSocio int , 
		--@IdCuentaRetiro int,
		--@IdTipoPersona int
as

	begin -- procedimiento
		
		begin try -- try principal
		
				-- declaraciones
				declare	@estatus int = 1,
						@error_message varchar(255) = '',
						@SaldoActual decimal(18,2),
						@Monto decimal(18,2),
						@NumeroSocio int , 
						@IdCuentaRetiro int,
						@IdTipoPersona int = 1 ,
						@idTipoMov int,
						@idOrigen int

			  -- Obtenemos los parametros de inicio para poder cancelar la operacion
				SELECT @NumeroSocio = BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) , @Monto = monto, @IdCuentaRetiro = id_cuenta_retiro,
				@idTipoMov = id_tipomov  , @idOrigen = id_origen
				FROM TBL_BANCA_PAGO_SERVICIOS where id_pago_servicios = @idPagoServicio

				print 'NumeroSocio: '+cast(@NumeroSocio as varchar)

				Select @SaldoActual = Saldo_Actual 
				from HAPE..EDO_DE_CUENTA 
				where Numero=@NumeroSocio and Id_Tipo_persona =@IdTipoPersona and Id_mov = @IdCuentaRetiro

				UPDATE HAPE..CAPTURA SET  Activo='F'
				WHERE 
			     Folio = @idPagoServicio and
				 Numero = @NumeroSocio and 
				 @idTipoMov = Id_Tipomov  and
				 @IdCuentaRetiro =  ID_mov and 
				 @idOrigen=id_origen and
				 @IdTipoPersona= Id_Tipo_persona 

				UPDATE HAPE..MOVIMIENTOS SET  Activo='F'
				WHERE Folio = @idPagoServicio and
				 Numero = @NumeroSocio and 
				 @idTipoMov = Id_Tipomov  and
				 @IdCuentaRetiro =  ID_mov and 
				 @idOrigen=id_origen and
				 @IdTipoPersona = Id_Tipo_persona

				UPDATE HAPE..EDO_DE_CUENTA SET Saldo_Actual = (@SaldoActual + @Monto)
				WHERE Numero = @NumeroSocio and Id_Tipo_persona = @IdTipoPersona AND Id_mov = @IdCuentaRetiro

				SELECT 200 estatus , 'OK' mensaje

		end try -- try principal
		
		begin catch -- catch principal

			SELECT @error_message =error_message(),@estatus=0  
		
			select ERROR_LINE() , @error_message as mensaje, @estatus as estatus
		
		end catch -- catch principal
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_CANCELACION_AUTOMATICO_DE_ACCESO]    Script Date: 21/08/2019 11:56:43 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		EDSON
-- Create date: 2018-09-10
-- Description:	Es utilizado por el robot de bloqueo y cancelacion de banca
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_CANCELACION_AUTOMATICO_DE_ACCESO]
	@fecha_proceso datetime

AS
BEGIN

begin try

	DECLARE 
	@mensaje_validacion varchar(500),
	@estatus int,
	@tipo_origen int = 5, --
	@descripcion_cancelar varchar(80) = 'Cancelaci�n por tener m�s de 180 d�as de bloqueo.'

	IF @fecha_proceso is null
		SELECT @fecha_proceso = GETDATE()
	
	create table #Socios_Cancelados
	(
		numero int,
		id_tipo_bitacora int,
		id_estatus_banca int
	)

	create table #notificaciones
	(
		idTipoNotificacion int , 
		celular varchar(20),
		correo varchar(500),
		cuerpo varchar(max),
		asunto varchar(500),
		numero int,
		nombre_socio varchar(200),
		tipo_bitacora varchar(500)
	)

	/*
		o	Cancelar servicio todos los socios que tengan m�s de 180 d�as de bloqueo
	*/
	insert into #Socios_Cancelados (numero,id_tipo_bitacora,id_estatus_banca)
	select 
		BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)
		,61 -- Cancelaci�n autom�tica por tener m�s de 180 d�as de bloqueo.
		,9
	from BANCA..TBL_BANCA_SOCIOS
	where
		DATEDIFF(DAY,isnull(fecha_motivo_bloqueo,@fecha_proceso),@fecha_proceso) >= 180
		and banca_activa = 1
		and id_motivo_bloqueo = 4



	update socios set 
		id_estatus_banca = 9, 
		banca_activa = 0,
		descripcion_cancelacion=@descripcion_cancelar,
		fecha_alta_solicitud =GETDATE(),
		viene_de_bloqueo = 0,
		contrasena =null,
		fecha_contrasena_temporal = null,
		contrasena_temp = null,
		fecha_alta_contrasena = null,
		id_pregunta_secreta = null,
		respuesta = null,
		fecha_motivo_bloqueo = null,
		id_imagen_antiphishing = null,
		vigencia_contrasena_temporal = null,
		id_ultima_sesion = null,
		fecha_ultima_sesion =null,
		intentos_sesion = null,
		intentos_respuesta = null,
		fecha_de_desbloqueo = null,
		contrasena_estado_cuenta = null,
		fecha_cancelacion = @fecha_proceso
	from 
		BANCA..TBL_BANCA_SOCIOS socios
	inner join	
		#Socios_Cancelados soBl on BANCA.dbo.FN_BANCA_DESCIFRAR(socios.numero_socio) = soBl.numero


	--Se deshabilitan las de cuentas de terceros del mismo banco
	update cuentas_internas 
		set cuentas_internas.activo = 0
	from BANCA..TBL_BANCA_CUENTAS_INTERNAS cuentas_internas
	inner join	
		#Socios_Cancelados soBl on BANCA.dbo.FN_BANCA_DESCIFRAR(cuentas_internas.numero_socio) = soBl.numero
	
	--Cancelaci�n de transferencias y pagos programados

	update trans set
		trans.id_estatus_transferencia = 3  
	from TBL_BANCA_TRANSFERENCIAS_INTERNAS trans
	inner join	
		#Socios_Cancelados soBl on BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio) = soBl.numero
	where 
		trans.programada = 1 
		and trans.id_estatus_transferencia = 1


	----------------------------	INSERCI�N  A LA BIRACORA DE BANCA	-------------------------
	insert into 
		BANCA..TBL_BANCA_BITACORA_OPERACIONES (id_tipo_bitacora,numero_socio,fecha_alta,id_origen_operacion,usuario)
	select 
		id_tipo_bitacora,numero,@fecha_proceso,5,0 
	from 
		BANCA..TBL_BANCA_SOCIOS socios
	inner join	
		#Socios_Cancelados soBl on BANCA.dbo.FN_BANCA_DESCIFRAR(socios.numero_socio) = soBl.numero and socios.id_estatus_banca = 9
	where
		socios.fecha_cancelacion = @fecha_proceso
		and socios.banca_activa = 0
	----------------------------										-------------------------




end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 	 		
end catch

	---------------------------------------------------------------------------------------------------
	INSERT INTO #notificaciones (idTipoNotificacion,celular,correo,cuerpo,numero,nombre_socio,tipo_bitacora)
	SELECT
		1,
		persona.Tel_Celular,
		persona.Mail,
		REPLACE(
			REPLACE(
			REPLACE (NSMS.cuerpo
			,'@Nombre',(persona.Nombre_s + ' ' +COALESCE(persona.Apellido_Paterno,'') + ' ' +COALESCE(persona.Apellido_Materno,'')) )
			,'@fecha_hora_operacion',CONVERT(varchar , BO.fecha_alta,103)+' '+FORMAT(CONVERT(datetime, BO.fecha_alta), 'hh:mm:ss tt'))
			,'@folio',COALESCE(id_banca_folio, id_bitacora)
		) cuerpo
		,soBl.numero
		,persona.Nombre_s + ' ' +COALESCE(persona.Apellido_Paterno,'') + ' ' +COALESCE(persona.Apellido_Materno,'')
		,B.descripcion
	FROM 
		BANCA..TBL_BANCA_BITACORA_OPERACIONES BO 
	inner join	
		#Socios_Cancelados soBl on BO.numero_socio = soBl.numero and BO.id_tipo_bitacora = soBl.id_tipo_bitacora
	inner join BANCA..TBL_BANCA_CONTRATOS_BANCA CB ON CB.Numero = soBl.numero 
	inner join
		BANCA..CAT_BANCA_TIPOS_BITACORA B ON BO.id_tipo_bitacora = B.id_tipo_bitacora
	inner join
		BANCA..TBL_BANCA_NOTIFICACIONES_SMS NSMS ON NSMS.id_tipo_bitacora = BO.id_tipo_bitacora AND cb.id_tipo_notificacion in (1,3)
	inner join
		hape..PERSONA persona on soBl.numero = persona.Numero and persona.Id_Tipo_Persona = 1
	WHERE
		BO.fecha_alta = @fecha_proceso
	
	INSERT INTO #notificaciones (idTipoNotificacion,celular,correo,cuerpo,asunto,numero,nombre_socio,tipo_bitacora)
	SELECT
		2,
		persona.Tel_Celular,
		persona.Mail,
		REPLACE(
			REPLACE(
			REPLACE (
			REPLACE (
			REPLACE (NCORREO.cuerpo,'@imagen',NCORREO.url_img_operacion)
			,'@Operacion',COALESCE(B.descripcion,'Bloqueo autom�tico') )
			,'@Nombre',(persona.Nombre_s + ' ' +COALESCE(persona.Apellido_Paterno,'') + ' ' +COALESCE(persona.Apellido_Materno,'')) )
			,'@fecha_hora_operacion',CONVERT(varchar , BO.fecha_alta,103)+' '+FORMAT(CONVERT(datetime, BO.fecha_alta), 'hh:mm:ss tt'))
			,'@folio',COALESCE(id_banca_folio, id_bitacora)
		) cuerpo,
		asunto
		,soBl.numero
		,persona.Nombre_s + ' ' +COALESCE(persona.Apellido_Paterno,'') + ' ' +COALESCE(persona.Apellido_Materno,'')
		,B.descripcion
	FROM 
		BANCA..TBL_BANCA_BITACORA_OPERACIONES BO 
	inner join	
		#Socios_Cancelados soBl on BO.numero_socio = soBl.numero and BO.id_tipo_bitacora = soBl.id_tipo_bitacora
	inner join BANCA..TBL_BANCA_CONTRATOS_BANCA CB ON CB.Numero = soBl.numero 
	inner join
		BANCA..CAT_BANCA_TIPOS_BITACORA B ON BO.id_tipo_bitacora = B.id_tipo_bitacora
	inner join
		BANCA..TBL_BANCA_NOTIFICACIONES_CORREO NCORREO ON NCORREO.id_tipo_bitacora = BO.id_tipo_bitacora AND cb.id_tipo_notificacion in (2,3)
	inner join
		hape..PERSONA persona on soBl.numero = persona.Numero and persona.Id_Tipo_Persona = 1
	WHERE
		BO.fecha_alta = @fecha_proceso


		
	----------------------------	BORRADO DE CONTRATOS DE BANCA	-------------------------
	
	delete contratos 
	from 
		BANCA..TBL_BANCA_SOCIOS socios
	inner join	
		#Socios_Cancelados soBl on BANCA.dbo.FN_BANCA_DESCIFRAR(socios.numero_socio) = soBl.numero and socios.id_estatus_banca = 9
	inner join
		BANCA..TBL_BANCA_CONTRATOS_BANCA contratos on contratos.numero = soBl.numero
	where
		socios.fecha_cancelacion = @fecha_proceso
		and socios.banca_activa = 0



	select * from #notificaciones order by numero
	
	drop table #Socios_Cancelados
	drop table #notificaciones
	
END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_CANCELAR_SERVICIO_BANCA]    Script Date: 18/03/2020 03:03:25 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER proc

	 [dbo].[SP_BANCA_CANCELAR_SERVICIO_BANCA]
	
		-- par�metros
		@numero_Socio Int,
		@tipo_origen int = null,
		@numero_usuario varchar(20) = null,
		@descripcion_cancelar varchar(max)
		-- [aqu� van los par�metros]

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@id_banca_folio int,
						@id_tipo_bitacora int  = 40
						
			
			end -- inicio
			
		  ---SELECT * FROM CAT_BANCA_ESTATUS_BANCA

			update TBL_BANCA_SOCIOS set
				id_estatus_banca = 9, 
				id_motivo_bloqueo=5,
				banca_activa = 0,
				descripcion_cancelacion=@descripcion_cancelar,
				fecha_alta_solicitud =GETDATE(),
				viene_de_bloqueo = 0,
				contrasena =null,
				fecha_contrasena_temporal = null,
				contrasena_temp = null,
				fecha_alta_contrasena = null,
				id_pregunta_secreta = null,
				respuesta = null,
				fecha_motivo_bloqueo = null,
				id_imagen_antiphishing = null,
				vigencia_contrasena_temporal = null,
				id_ultima_sesion = null,
				fecha_ultima_sesion =null,
				intentos_sesion = null,
				intentos_respuesta = null,
				fecha_de_desbloqueo = null,
				contrasena_estado_cuenta = null,
				recuperar_contrasena = 0
			where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)=@numero_Socio;
			delete from hape..tbl_contratos_haberes where numero = @numero_Socio and id_tipo_contrato = 3

			/*Se desactiva el socio en la tabla de UNE*/
			--select * from une..tbl_callcenter_socios
			
			update 
				une..tbl_callcenter_socios 
			set 
				banca_registrado = 0 
			where
				numero_socio = @numero_Socio 
			
			--select * from BANCA..CAT_BANCA_ESTATUS_TRANSFERENCIAS

			update  TBL_BANCA_TRANSFERENCIAS_INTERNAS
			set
				id_estatus_transferencia = 3
			where 
				BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio 
			and 
				programada = 1 
			and 
				id_estatus_transferencia = 1
				


			update
				TBL_BANCA_CUENTAS_INTERNAS  
			set
				activo = 0
			where
				BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio

			--ACTALIZACION QUE DESACTIVA LA CLABE DEL SOCIO SI ES QUE TIENE UNA
			/*if exists(select 1 from TBL_BANCA_CUENTAS_INTERBANCARIAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio)
			begin*/
				declare @ultimaCuentaSocio int
				select top 1 @ultimaCuentaSocio =id_cuenta from TBL_BANCA_CUENTAS_INTERBANCARIAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio order by fecha_alta desc
				
				update TBL_BANCA_CUENTAS_INTERBANCARIAS set activo = 0, id_estatus_cuenta = 3 where id_cuenta = @ultimaCuentaSocio
			--end

		
			--delete from tbl_banca_cuentas_internas where numero_socio  = @numero_Socio
			--DELETE FROM BANCA..TBL_BANCA_CONTRATOS_BANCA WHERE numero = @numero_Socio
			--------------------	BITACORA	--------------------
			IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
			BEGIN
				--se inserta a la bitacora directa ya que no es una accion de tansaccionalidad
				INSERT INTO TBL_BANCA_BITACORA_OPERACIONES (id_tipo_bitacora,numero_socio,fecha_alta,id_origen_operacion,usuario)
				VALUES (13/*Cancelacion de servicio*/ , @numero_socio , getdate() , @tipo_origen,@numero_usuario)
			
				------- LLAMADO DE SPS DE  FRAUDES-------
					
				create table #FraudesAlertasBaja
				(
					status int, 
					error_procedure varchar(max), 
					error_line varchar(max), 
					error_severity varchar(max),
					error_message varchar(max)
				)

				insert into #FraudesAlertasBaja
				EXEC SP_BANCA_FRAUDES_DEPURACION_ALERTAS_BAJA_SERVICIO @numero_socio,@numero_usuario

				drop table #FraudesAlertasBaja
				------- LLAMADO DE SPS DE  FRAUDES FIN-------
			END
			-------------------- FIN BITACORA-------------------
			
			IF @@ERROR = 0
				SELECT 200 estatus , 'OK' mensaje
			else
				SELECT -1 estatus , 'OK' mensaje

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end

			select	@status as estatus ,@error_procedure as mensaje


		end catch -- catch principal
		
	end -- procedimiento

go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_DESBLOQUEAR_SOCIO]    Script Date: 16/08/2019 08:37:35 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristia P�rez
UsuarioRed		pegc837648
Fecha			20181024
Objetivo		desbloquear socio de banca
Proyecto		Administrador de banca electr�nica
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_DESBLOQUEAR_SOCIO]
	
		-- parametros
		@numero_Socio int,
		@tipo_origen int = null,
		@numero_usuario varchar(20),
		@contrasena  varchar(max) = null,
		@id_tipo_bitacora int
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@id_banca_folio int
			
			end -- inicio
			
					begin -- validaciones
			
				if not exists(SELECT * FROM HAPE.DBO.PERSONA WHERE NUMERO = @numero_Socio)
					raiserror('El socio ingresado no existe',11,0)
				else if not exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE banca.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio)
				raiserror('El socio no esta registrado en �CMV finanzas�',11,0)

				if exists (SELECT * FROM TBL_BANCA_SOCIOS WHERE banca.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio and (id_estatus_banca<6 and banca_activa=0))
					raiserror('El socio ingresado no tiene su cuenta de �CMV finanzas� Activa',11,0)

				if exists (SELECT * FROM TBL_BANCA_SOCIOS WHERE banca.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio and (id_motivo_bloqueo=1 and viene_de_bloqueo=0))
					raiserror('El socio ingresado actualmente esta Desbloqueado en �CMV finanzas�',11,0)

				
			end -- validaciones

			IF EXISTS(
				SELECT * FROM(
				SELECT TOP 3 * FROM BANCA..TBL_BANCA_CONTRASENAS_SOCIO WHERE numero_socio = @numero_Socio
				ORDER BY fecha_alta DESC
				)CONTRA_ULTIMAS_3
				WHERE
					CONTRA_ULTIMAS_3.contrasena = @contrasena
			)
			BEGIN
				SELECT id_excepcion AS estatus , descripcion as error_message 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 386
				return 
			END
			else
			begin
				IF @contrasena IS NOT NULL AND @contrasena <> ''
				begin
					update TBL_BANCA_SOCIOS set 
						id_motivo_bloqueo=1,
						fecha_de_desbloqueo = GETDATE(),
						viene_de_bloqueo = 0,
						descripcion_bloqueo = null,
						contrasena = @contrasena,
						fecha_alta_contrasena = getdate(),
						intentos_sesion =0,
						intentos_respuesta = 0
					where banca.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio;
				end
				else
					begin
						update TBL_BANCA_SOCIOS set 
							id_motivo_bloqueo=1,
							fecha_de_desbloqueo = GETDATE(),
							viene_de_bloqueo = 0,
							descripcion_bloqueo = null,
							--contrasena_temp = null,
							fecha_alta_contrasena = getdate(),
							intentos_sesion =0,
							intentos_respuesta = 0
						where banca.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio;
					end
				
				IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
					BEGIN
					INSERT INTO 
						TBL_BANCA_BITACORA_OPERACIONES 
						(
							id_tipo_bitacora,
							numero_socio,
							fecha_alta,
							id_origen_operacion,
							usuario
						)
                     VALUES 
					 (
						@id_tipo_bitacora ,
						 @numero_socio ,
						 getdate() ,
						 @tipo_origen,
						 @numero_usuario
						)


						--INSERT INTO TBL_BANCA_FOLIOS 
						--(
						--	numero_socio,
						--	fecha_alta
						--) 
						--values (@numero_socio,GETDATE())

						--select @id_banca_folio = max(id_banca_folio)from TBL_BANCA_FOLIOS where numero_socio = @numero_Socio

						--EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_Socio, @id_tipo_bitacora, @tipo_origen,@id_banca_folio,@numero_usuario
					END
			end 

				
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status estatus,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
	
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_DESBLOQUEO_DATABANKING]    Script Date: 21/08/2019 12:06:51 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			VIC
UsuarioRed		REXV666480
Fecha			20180503
Objetivo		Desbloquea la cuenta del socio 
Proyecto		BANCA ELECTRONICA
Ticket			ticket
--id_origen_operacion--
1	Banca M�vil
2	Sucursal
3	Banca Web
4	Databanking
*/


ALTER proc	[dbo].[SP_BANCA_DESBLOQUEO_DATABANKING]
	
-- par�metros
		
	-- [aqu� van los par�metros]
    @numero_socio varchar(20),
	@id_motivo_bloqueo INT,
	@id_origen_operacion INT = 4,
	@fecha_motivo_bloqueo datetime = null

as

if(@fecha_motivo_bloqueo is null)
	SET @fecha_motivo_bloqueo = getdate()

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@descripcion_estatus varchar(255),
						@validacion varchar(255),
						@numero int,
						@id_tipo_bitacora int =0
			
			end -- inicio
				

				--VALIDACIONES	
				--select @validacion = dbo.FN_BANCA_VALIDA_SOCIO(@numero_socio,1)
				select @status = estatus, @validacion = msj from dbo.FN_BANCA_VALIDA_SOCIO (@numero_socio,0)
				IF(@validacion is null )
					BEGIN
					SELECT @numero = CAST(@numero_socio as int)
					
					UPDATE TBL_BANCA_SOCIOS SET id_motivo_bloqueo =@id_motivo_bloqueo , fecha_motivo_bloqueo = @fecha_motivo_bloqueo
					WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero
					
					SELECT	@id_tipo_bitacora = CASE  @id_origen_operacion
												WHEN  2 THEN  9 -- Desbloqueo de acceso a cuenta desde sucursal
												WHEN  4 THEN  10 -- Desbloqueo de acceso a cuenta desde Call Center
												ELSE @id_tipo_bitacora END 

					print 'numero'+ cast (@numero as varchar)
					print '@id_tipo_bitacora'+ cast (@id_tipo_bitacora as varchar)
					print '@id_origen_operacion'+ cast (@id_origen_operacion as varchar)

					CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));
					INSERT INTO #Bitacora
					EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero, @id_tipo_bitacora, @id_origen_operacion

					SELECT * FROM #Bitacora


				END
				ELSE
				BEGIN
					SELECT @error_message = @validacion
					SELECT @status AS estatus, @error_message mensaje 
				END 
		end try -- try principal
		
		begin catch -- catch principal
		
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@status=1000
		
			select @error_message as mensaje, @status as estatus
		
		end catch -- catch principal
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_DESCARGA_EDO_DE_CUENTA]    Script Date: 21/08/2019 12:08:58 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			MAXIMILIANO GONZALEZ BETANCOURT
UsuarioRed		GOBM391548
Fecha			20180417
Objetivo		VALIDA EL NUMERO Y CONTRASE�A RECIBIDOS PARA EL INICIO DE SESION
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_DESCARGA_EDO_DE_CUENTA]
	
		-- par�metros
		
		-- [aqu� van los par�metros]
    @numero varchar(20),
	@idDescarga int,
	@tipoEstadoCuenta int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@descripcion_estatus varchar(255),
						@validacion varchar(255),
						@numero_int int,
						@contrasena_usuario varchar(255) 
			
			end -- inicio
			
			

				--VALIDACIONES	
				select @status = estatus, @validacion = msj from dbo.FN_BANCA_VALIDA_SOCIO (@Numero,1)
				IF(@validacion is null)
				BEGIN
						SET @numero_int = cast(@numero as int)
						if  EXISTS (SELECT 1 from [CMV8049].[SERVICIOS_FINANCIEROS].dbo.TBL_FACTURACION_LOG_PRESTAMOS a where numero = @numero_int and folio = @idDescarga )
						    OR EXISTS (SELECT 1 from [CMV8049].[SERVICIOS_FINANCIEROS].dbo.TBL_FACTURACION_LOG_HABERES a where numero = @numero_int and folio = @idDescarga)
						BEGIN
							IF @tipoEstadoCuenta = 2
							BEGIN
								SELECT 200 estatus , A.* , S.contrasena_estado_cuenta
								from  [CMV8049].[SERVICIOS_FINANCIEROS].dbo.TBL_FACTURACION_LOG_PRESTAMOS A
								join BANCA.dbo.tbl_banca_socios S on A.numero = BANCA.dbo.FN_BANCA_DESCIFRAR(S.numero_socio)
								WHERE  A.numero = @numero_int and A.FOLIO = @idDescarga
								RETURN
							END
							ELSE
							BEGIN
								SELECT 200 estatus , A.* , S.contrasena_estado_cuenta
								FROM  [CMV8049].[SERVICIOS_FINANCIEROS].dbo.TBL_FACTURACION_LOG_HABERES A
								join BANCA.dbo.tbl_banca_socios S on A.numero = BANCA.dbo.FN_BANCA_DESCIFRAR(S.numero_socio)
								WHERE  A.numero = @numero_int and A.FOLIO = @idDescarga
							END
							
						END
						ELSE
						BEGIN
							SELECT id_excepcion AS estatus , descripcion as mensaje 
							FROM CAT_BANCA_EXCEPTIONS
							WHERE id_excepcion =352
							RETURN
						END
						print ''
				END
				ELSE
				BEGIN
					SELECT @error_message = @validacion
					SELECT @status AS estatus, @error_message mensaje 
				END 

		end try -- try principal
		
		begin catch -- catch principal
		
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@status=0
		
			select @error_message as mensaje, @status as estatus
		
		end catch -- catch principal
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ELIMINA_CUENTA_INTERNA]    Script Date: 21/08/2019 12:35:55 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_ELIMINA_CUENTA_INTERNA]
@NUMERO varchar(20),
@id_cuenta_interna BIGint
AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int ,
@id_tipo_bitacora INT = 54,-- baja de cuenta interna
@tipoOrigen INT 


IF OBJECT_ID('tempdb..#Bitacora') IS NOT NULL
	DROP TABLE #Bitacora

select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)
set @numero_int = CAST(@NUMERO as int )

  if(@mensaje_validacion is null)
  BEGIN
		if not exists(select * from TBL_BANCA_CUENTAS_INTERNAS where id_cuenta_interna = @id_cuenta_interna and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int)
		begin
			SELECT id_excepcion AS estatus , descripcion as mensaje 
			FROM CAT_BANCA_EXCEPTIONS
			WHERE id_excepcion =325
		end
		else 
		begin
			update 
				TBL_BANCA_CUENTAS_INTERNAS set activo = 0 
			where 
				id_cuenta_interna = @id_cuenta_interna and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int
			
			update TBL_BANCA_TRANSFERENCIAS_INTERNAS 
				set id_estatus_transferencia = 3
			where 
			BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int 
			and programada = 1 
			and id_cuenta_interna  = @id_cuenta_interna
			and id_estatus_transferencia = 1
			
		   if @@ERROR = 0 
		   BEGIN
				CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));
				INSERT INTO #Bitacora
				EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero, @id_tipo_bitacora
			END
			SELECT * FROM #Bitacora

		end
  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje
end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ELIMINAR_CUENTAS_EXTERNAS]    Script Date: 23/12/2019 01:06:47 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_ELIMINAR_CUENTAS_EXTERNAS]
@numero_socio AS VARCHAR(20),
@idCuenta bigint
AS
BEGIN

Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@status int = 1,
@error_message varchar(255) = '',
@validacion varchar(255),
@numero_int int ,
@id_tipo_bitacora int = 90

	IF OBJECT_ID('tempdb..#Bitacora') IS NOT NULL
				DROP TABLE #Bitacora

	CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));

	begin try -- try principal
		SELECT @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@numero_socio,1)

		IF @mensaje_validacion IS NOT NULL 
		BEGIN
				  SELECT @estatus AS estatus , @mensaje_validacion mensaje
				  RETURN
		END

		SET @numero_int = CAST(@numero_socio AS INT)

		IF EXISTS (SELECT 1 FROM TBL_BANCA_CUENTAS_EXTERNAS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int and id_cuenta_externa = @idCuenta)
		BEGIN
			UPDATE  TBL_BANCA_CUENTAS_EXTERNAS
			SET activa = 0
			WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int and id_cuenta_externa = @idCuenta

			update TBL_BANCA_TRANSFERENCIAS_EXTERNAS
				set id_estatus_transferencia = 3
			where 
			BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int 
			and programado = 1 
			and id_cuenta_externa  = @idCuenta
			and id_estatus_transferencia = 1

		END
		ELSE
		BEGIN
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion =355
			return
		END

		INSERT INTO #Bitacora
		EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_int, @id_tipo_bitacora
		SELECT * FROM #Bitacora

	end try -- try principal
		
	begin catch -- catch principal
		-- MANEJO DE ERRORES
		SELECT @error_message =error_message(),@status=1000
		select @error_message as mensaje, @status as estatus
	end catch -- catch principal

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_GENERAR_CONTRASENA_TEMP]    Script Date: 21/08/2019 03:57:39 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_GENERAR_CONTRASENA_TEMP]
@NUMERO AS VARCHAR(20),
@tipoOrigen int,
@contrasenaTemporal varchar(1000),
@fechaActualizacion datetime= null
AS
BEGIN

Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int ,
@id_tipo_bitacora int  = 2 --Genera la contrase�a temporal

if (@fechaActualizacion is null)
BEGIN
	SET @fechaActualizacion = GETDATE()
END 


select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,0)

IF @mensaje_validacion IS NOT NULL 
BEGIN
		  SELECT @estatus AS estatus , @mensaje_validacion mensaje
		  RETURN
END

IF NOT EXISTS (SELECT 1 FROM CAT_BANCA_ORIGEN_OPERACION WHERE id_origen_operacion = @tipoOrigen)
BEGIN
		SELECT id_excepcion AS estatus , descripcion as mensaje 
		FROM CAT_BANCA_EXCEPTIONS
		WHERE id_excepcion =357
	 RETURN
END

--IF  @tipoOrigen <> 4
--BEGIN
--	 SELECT '365' AS estatus , 'Id tipo origen invalido' mensaje
--	 RETURN
--END


SET @numero_int = CAST(@NUMERO AS INT)

		UPDATE TBL_BANCA_SOCIOS  
		SET contrasena_temp = @contrasenaTemporal , fecha_contrasena_temporal  = @fechaActualizacion ,
		--habilitar la bandera de vencimiento de la contrase�a temporal
		vigencia_contrasena_temporal = (case when @tipoOrigen = 4 then 1 else 0 end)
		WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int
		

		CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));
		
		INSERT INTO #Bitacora
		EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero, @id_tipo_bitacora, @tipoOrigen
		
		SELECT * FROM #Bitacora
		
END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_INSERTA_SERVICIOS_PRODUCTOS_GESTO_PAGO]    Script Date: 10/03/2020 09:33:18 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_INSERTA_SERVICIOS_PRODUCTOS_GESTO_PAGO]
	@var_xml xml

	AS
	BEGIN

	IF OBJECT_ID ('tempdb..#productosGestoPago') IS NOT NULL  
			DROP TABLE #productosGestoPago;

	BEGIN TRY
			BEGIN TRAN
				SELECT 
					idServicio = XTbl.value('(idServicio)[1]', 'int'),
					servicio = XTbl.value('(servicio)[1]', 'varchar(100)'),
					idProducto = XTbl.value('(idProducto)[1]', 'int'),
					producto = XTbl.value('(productoMember)[1]', 'varchar(100)'),
					idCatTipoServicio = XTbl.value('(idCatTipoServicio)[1]', 'int'),
					tipoFront = XTbl.value('(tipoFront)[1]', 'int'),
					hasDigitoVerificador = XTbl.value('(hasDigitoVerificador)[1]', 'bit'),
					precio = XTbl.value('(precio)[1]', 'decimal(18,2)'),
					showAyuda = XTbl.value('(showAyuda)[1]', 'bit'),
					tipoReferencia = XTbl.value('(tipoReferencia)[1]', 'varchar(5)'),
					legend = XTbl.value('legend[1]', 'varchar(5000)')
					
					INTO #productosGestoPago
				FROM 
					@var_xml.nodes('/ResponseConsultaProductos/PRODUCTOS/producto') AS XD(XTbl)

					--select * from #productosGestoPago

				----------------------- CATEGORIAS ------------------------------------------------------
				            
				INSERT INTO CAT_BANCA_CATEGORIAS_SERVICIOS_PAGO (id_categoria_servicios_pago,descripcion,activo,id_grupo_categoria_servicios_pago)
				SELECT p.idCatTipoServicio id_categoria_servicios_pago ,
				case 
					when   p.idCatTipoServicio = 1 then 'Movistar'
					when   p.idCatTipoServicio = 2 then 'Telcel'
					when   p.idCatTipoServicio = 3 then 'AT&T'
					when   p.idCatTipoServicio = 4 then 'Unefon'
					when   p.idCatTipoServicio = 5 then 'Pago de Servicios'
					when   p.idCatTipoServicio = 6 then 'Nextel'
					when   p.idCatTipoServicio = 7 then 'Pago de Impuestos / Gobierno'
					when   p.idCatTipoServicio = 8 then 'Productos Financieros'
					when   p.idCatTipoServicio = 9 then 'Productos por Cat�logo'
					when   p.idCatTipoServicio = 10 then 'Servicios de Prepago'
					when   p.idCatTipoServicio = 11 then 'Entretenimiento'
					when   p.idCatTipoServicio = 12 then 'Virgin'
					when   p.idCatTipoServicio = 13 then 'Otras Recargas'
					when   p.idCatTipoServicio = 14 then 'Venta de Seguros'
					when   p.idCatTipoServicio = 15 then 'Pago de Derechos de Agua'
					when   p.idCatTipoServicio = 16 then 'Juegos y Sorteos'
					when   p.idCatTipoServicio = 17 then 'MazTiempo'
					when   p.idCatTipoServicio = 18 then 'Servicios de Autopistas y Transportes'
				end descripcion,1 activo ,
				
				case 
					when   p.idCatTipoServicio = 1 then 1
					when   p.idCatTipoServicio = 2 then 1
					when   p.idCatTipoServicio = 3 then 1
					when   p.idCatTipoServicio= 4 then  1
					when   p.idCatTipoServicio = 5 then 0
					when   p.idCatTipoServicio = 6 then 0
					when   p.idCatTipoServicio = 7 then 0
					when   p.idCatTipoServicio = 8 then 0
					when   p.idCatTipoServicio = 9 then 0
					when   p.idCatTipoServicio = 10 then 0
					when   p.idCatTipoServicio = 11 then 0
					when   p.idCatTipoServicio = 12 then 0
					when   p.idCatTipoServicio = 13 then 0
					when   p.idCatTipoServicio = 14 then 0
					when   p.idCatTipoServicio = 15 then 0
					when   p.idCatTipoServicio = 16 then 0
					when   p.idCatTipoServicio = 17 then 0
					when   p.idCatTipoServicio = 18 then 0
				end idGrupoCategoria
				FROM  #productosGestoPago p
				where p.idCatTipoServicio not in (select id_categoria_servicios_pago from  CAT_BANCA_CATEGORIAS_SERVICIOS_PAGO)
				group by  p.idCatTipoServicio



				---------------------------------------- SERVICIOS ---------------------------------------
				insert into  CAT_BANCA_SERVICIOS_PAGO (id_servicios_pago,id_categoria_servicios_pago,descripcion,activo)
				select p.idServicio id_servicios_pago ,
						p.idCatTipoServicio id_categoria_servicios_pago ,
						p.servicio descripcion,
						1 activo
				FROM  #productosGestoPago p
				where p.idServicio not in (select idServicio from  CAT_BANCA_SERVICIOS_PAGO)
				group by  p.idServicio, p.idCatTipoServicio, p.servicio
				

				----------------------- PRODUCTOS ---------------------------------------------------------------------

				INSERT INTO  CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO (id_producto,id_servicios_pago,descripcion,tipo_front,precio,tipo_referencia,activo,id_cat_tipo_servicio,has_digito_verificador,comision_cmv,leyenda, comision_gestopago)
				SELECT 
						p.idProducto,
						p.idServicio,
						p.producto,
						p.tipoFront,
						case when  p.tipoFront = 2 then 0 else  p.precio end,
						--0 as precio,
						p.tipoReferencia,
						1 activo,
						p.idCatTipoServicio,
						p.hasDigitoVerificador,
						0.0 as comision,
						p.legend,
						case when  p.tipoFront = 2 then p.precio else 0 end
						--case when  p.idCatTipoServicio = 5 then p.precio else 0 end
				FROM  #productosGestoPago p
				where p.idProducto not in (select id_producto from  CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO)

				/****** CAMBIO SERVICIOS DESTACADOS  ******/
				
				update [BANCA].[dbo].[CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO]
					   set frecuente=0
				where id_producto in (453,454,456,457,458)

				update [BANCA].[dbo].[CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO]
					   set frecuente=1
				where id_producto in (271,597,598,628,640)


				--Validaci�n de ids existentes--
				declare @productos_desactivar table (id int)
				declare @ids_existentes table (id int)
				insert into @productos_desactivar 
				VALUES (656), (276), (621), (655), (5882), (5968), (5763), (5944), (194), (277), (236), (623), (654), (183), (390), (584), (585), (586), (587), (588), (6418), (6421), (6424), (193), (244), (184), (622), (5434), (658), (212), (620), (616), (618), (270)

				insert into  @ids_existentes SELECT
					pd.id as idInexistente
				FROM
					banca..CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO AS A
					RIGHT JOIN @productos_desactivar AS pd
						ON A.id_producto = pd.id
				WHERE
					A.id_producto IS NOT NULL

				--Update bandera de los productos
				update
					banca..CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
					set activo = 0
					where id_producto in (select * from @ids_existentes)


		COMMIT TRAN
		select 1 as estatus , 'OK' AS mensaje 	
	END TRY
	BEGIN CATCH
			ROLLBACK TRAN 
			select 0  as estatus , ERROR_MESSAGE() AS mensaje 		
	END CATCH
end
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_INSERTA_SOCIOS_PRUEBAS]    Script Date: 21/08/2019 03:59:23 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Autor
UsuarioRed		aaaa111111
Fecha			yyyymmdd
Objetivo		Objetivo
Proyecto		Proyecto
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_INSERTA_SOCIOS_PRUEBAS]
	
		-- parametros
@Id_Persona int,
@Numero_Socio int
		-- [aqu� van los par�metros]

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
						
				-- valores por defecto
			
			end -- inicio
			
			begin -- validaciones
			if not exists(SELECT * FROM HAPE.DBO.PERSONA WHERE NUMERO = @Numero_Socio and Id_Tipo_Persona=1)
					raiserror('El numero de socio ingresado no existe en Persona',11,0)

			if exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @Numero_Socio)
					raiserror('El numero ingresado ya existe EN TBL_BANCA_SOCIOS',11,0)	
			end -- validaciones
			insert into TBL_BANCA_SOCIOS 
			(id_persona,numero_socio,contrasena_temp,fecha_contrasena_temporal,fecha_alta_persona,id_estatus_banca,id_motivo_bloqueo,banca_activa)
			values
			(@Id_Persona,BANCA.dbo.FN_BANCA_CIFRAR(@Numero_Socio),'92783E2C53CC921E312EB32B88507A97',GETDATE(),GETDATE(),3,1,1)

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	go
	
	USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_INSERTAR_BITACORA]    Script Date: 16/08/2019 08:24:04 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian
UsuarioRed		pegc837648
Fecha			20181123
Objetivo		Insertar en status de bitacoras
Proyecto		Administrador de banca
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_INSERTAR_BITACORA]
	
		-- par�metros
		
		@id_tipo_bitacora int,
		@numero_socio bigint, 
        @tipo_origen int,
		@numero_usuario bigint

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
			
			end -- inicio
			
					begin -- validaciones
			
				if not exists(SELECT * FROM HAPE.DBO.PERSONA WHERE NUMERO = @numero_Socio)
					raiserror('El socio ingresado no existe',11,0)
				else if not exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE banca.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio)
				raiserror('El socio no esta registrado en �CMV finanzas�',11,0)

				if not exists(SELECT * FROM hape..TBL_CONTRATOS_HABERES WHERE numero = @numero_Socio and id_tipo_contrato = 3)
				raiserror('El socio no ha celebrado su contrato',11,0)

				
			end -- validaciones
				

				IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
					BEGIN
					INSERT INTO 
						TBL_BANCA_BITACORA_OPERACIONES 
						(
							id_tipo_bitacora,
							numero_socio,
							fecha_alta,
							id_origen_operacion,
							usuario
						)
                     VALUES 
					 (
						@id_tipo_bitacora ,
						 @numero_socio ,
						 getdate() ,
						 @tipo_origen,
						 @numero_usuario
						)

					END
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go


USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_INSERTAR_COMISION]    Script Date: 21/08/2019 04:00:38 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*
Autor			EDSON
Fecha			20190620
Objetivo		Realiza un cobro de una aclaracion no procedente 
Proyecto		Banca en l�nea
*/

ALTER PROCEDURE [dbo].[SP_BANCA_INSERTAR_COMISION]
		@numero int,
		@folio_UNE bigint,
		@id_tipo_comision	int,
		@id_origen_operacion int = 4,
		@numusuario	 int = null,
		@id_Tipo_Persona int =null
		
as

	begin -- procedimiento
		
		/*		@id_origen_operacion
		1	Banca M�vil
		2	Sucursal
		3	Banca Web
		4	Databanking*/

		--declare	@status int = 200
		
		begin try -- try principal
		
			begin -- inicio

				begin -- declaraciones
					declare	
						@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@message varchar(255) = 'Se registro correctamente la comisi�n',
						@id_persona int,
						@id_comision int = 0
				end -- declaraciones

			

			end -- inicio

			begin --validaciones

				print 'paso 01'	
				---No existe el tipo de comision que se desea registrar
				if not exists(select * from CAT_BANCA_TIPO_COMISIONES where id_tipo_comision = @id_tipo_comision and activo = 1)
				begin
					select @status = 0,@message = 'No existe el tipo de comision que se desea registrar'
					raiserror (@message, 11, 0)
				end	
			end

			begin--Proceso

				print 'paso 02'
				--datos generales
				select @id_Tipo_Persona = ISNULL(@id_Tipo_Persona,1)

				select @id_persona  = Id_Persona from 
				HAPE..PERSONA where Numero = @numero and Id_Tipo_Persona = @id_Tipo_Persona


				if(@id_tipo_comision = 1) ------Aclaraciones improcedentes
				begin
					
					--Reporte de aclaraci�n improcedente |desde Call Center

					print 'paso 03'
					----------------------------	INSERCI�N  DE LA COMISI�N	-------------------------
					insert into BANCA..TBL_BANCA_COMISIONES 
						(numero,id_persona,folio_UNE,monto,saldo,pagada,fecha_alta,id_tipo_comision)
					select 
						BANCA.dbo.FN_BANCA_CIFRAR(@numero),@id_persona,@folio_UNE,monto,monto,0,GETDATE(),@id_tipo_comision 
					from CAT_BANCA_TIPO_COMISIONES 
					where
						id_tipo_comision = @id_tipo_comision
						and activo = 1
					
					---se rescata el id de la comision insertado
					SELECT @id_comision = max(id_comision)
					from TBL_BANCA_COMISIONES 
					where
						BANCA.dbo.FN_BANCA_DESCIFRAR(numero) = @numero
						and id_tipo_comision = @id_tipo_comision
					

				end


			end

		end try -- try principal
		
		begin catch -- catch principal
		
			
			select @status=coalesce(@status, 0)


			select		
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de status

			select	@status estatus,
					@id_comision id_comision,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message mensaje
				
		end -- reporte de status
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_INSERTAR_PAGO_SERVICIO]    Script Date: 21/08/2019 04:01:18 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			
UsuarioRed		
Fecha			20180417
Objetivo		
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc
	[dbo].[SP_BANCA_INSERTAR_PAGO_SERVICIO]
		-- par�metros
		@idProducto int,
		@idServicio int,
		@ClabeCorresponsaliasRetiro varchar(20),
		@numeroSocio int,
		@monto decimal(18,2),
		@tipo_origen int = 3  ,-- banca web si no mandan nada
		@numeroReferencia varchar(100) = null
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@estatus int = 1,
						@error_message varchar(255) = '',
						@validacion varchar(255),
						@idPagoServicio int,
						@idTipoMov int,
						@IdCuentaRetiro int =null,
						@id_tipo_bitacora int = 21 --Pago de Servicio
			
			end -- inicio

			if not exists (select  1 from CAT_BANCA_SERVICIOS_PAGO where id_servicios_pago = @idServicio)
			begin
					SELECT id_excepcion AS estatus , descripcion as mensaje 
					FROM CAT_BANCA_EXCEPTIONS
					WHERE id_excepcion =355
					return
			end

			if not exists (select  1 from CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO where id_producto =@idProducto AND  id_servicios_pago = @idServicio)
			begin
					SELECT id_excepcion AS estatus , descripcion as mensaje 
					FROM CAT_BANCA_EXCEPTIONS
					WHERE id_excepcion =336
					return
			end

			select @IdCuentaRetiro = ID_MOV from HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE NUMERO = @numeroSocio  and CUENTA = @ClabeCorresponsaliasRetiro 

			if (@IdCuentaRetiro is null or @IdCuentaRetiro = '')
			begin
					SELECT id_excepcion AS estatus , descripcion as mensaje 
					FROM CAT_BANCA_EXCEPTIONS
					WHERE id_excepcion =362
					return
			end

			
			-- OBTENEMOS EL ID_TIPOMOV
			if @IdCuentaRetiro = 100   -- AHORRO
				SET @IdTipoMov  = 1051
			else if @IdCuentaRetiro = 103-- INVER
				SET @IdTipoMov  = 1152
			else if @IdCuentaRetiro = 112 -- DEBITO
					SET @IdTipoMov  = 1103



			INSERT INTO TBL_BANCA_PAGO_SERVICIOS
				(id_producto,id_servicio,id_cuenta_retiro,numero_socio,monto,numero_referencia,fecha_alta_pago,
				estado_operacion,id_origen,id_tipomov,clabe_corresponsalias_retiro)
			VALUES(@idProducto,@idServicio,@IdCuentaRetiro,BANCA.dbo.FN_BANCA_CIFRAR(@numeroSocio),@monto,@numeroReferencia,GETDATE(),0, @tipo_origen,@IdTipoMov,@ClabeCorresponsaliasRetiro)

			SELECT @idPagoServicio = MAX(id_pago_servicios) FROM TBL_BANCA_PAGO_SERVICIOS 
			WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio AND id_producto = @idProducto AND id_servicio = @idServicio

			
			CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500))
			INSERT INTO #Bitacora
			EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numeroSocio, @id_tipo_bitacora, @tipo_origen
			
			DROP TABLE #Bitacora


			select 200 estatus , 'OK' as mensaje , @idPagoServicio  as idPagoServicio

		end try -- try principal
		
		begin catch -- catch principal
		
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@estatus=0
		
			select @error_message as mensaje, @estatus as estatus
		
		end catch -- catch principal
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_INSERTAR_PAGOS_SERVICIO_PENDIENTES]    Script Date: 23/01/2020 10:26:11 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER proc

	[dbo].[SP_BANCA_INSERTAR_PAGOS_SERVICIO_PENDIENTES]
	
		-- parametros				
		@idBancaFolio bigint,		
		@request varchar(max) = null,
		@response varchar(max) = null,
		@numeroSocio bigint,
		@signed varchar(max)
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @ESTATUS int = 0,
						@mensaje varchar(max) = '',	
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
		
			end -- inicio
			
			begin -- �mbito de la actualizaci�n
			if not exists(select 1 from TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES where folio_banca = @idBancaFolio and numero_socio = @numeroSocio)
			begin
				SELECT @ESTATUS = 1				
				
				insert into banca..TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES (folio_banca,
				id_producto,
				numero_socio,
				id_estatus_transferencia,
				request_pago_realizado,
				response_pago_realizado,
				request_confirma_transaccion,
				response_confirma_transaccion,
				servicio_atendido,
				signed,
				intentos,
				mensaje_intentos_error)		
				select id_banca_folio, id_producto, BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio), id_estatus_transferencia, @request, @response, '' , '','', @signed,'',''
				from TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS where id_banca_folio = @idBancaFolio  and BANCA.dbo.FN_BANCA_DESCIFRAR(NUMERO_SOCIO) = @numeroSocio
	
			end
			else
			begin
				select @ESTATUS =0
				select @error_message = 'El registro ya existe en la tabla'
			end
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@ESTATUS = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
		if @error_message<>''
		begin
			select	
				@ESTATUS AS ESTATUS,
				@error_procedure error_procedure,
				@error_line error_line,
				@error_severity error_severity,
				@error_message error_message
			
		end
		else
		begin
			select 
				@ESTATUS AS ESTATUS,				
				'Registro insertado con exito' as mensaje
		end 
					
		end -- reporte de estatus
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_INSERTAR_SOCIO]    Script Date: 09/10/2019 04:44:16 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER proc

	[dbo].[SP_BANCA_INSERTAR_SOCIO]
	 
		-- par�metros
		@numero_Socio Int,
		@contrasenaTemp varchar(max),
		@contrasenaEdoCuenta  varchar(max),
		@numero_usuario varchar(20) = null,
		@tipo_origen INT = 2
		-- [aqu� van los par�metros]

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@id_banca_folio int,
						@id_tipo_bitacora int  = 40,
						@socio_edad int
						
			
			end -- inicio
			
			begin -- validaciones
			
				if not exists(SELECT * FROM HAPE.DBO.PERSONA WHERE NUMERO = @numero_Socio)
					raiserror('El socio ingresado no existe',11,0)

				if exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio and id_estatus_banca != 9)
					raiserror('El socio ingresado ya esta registrado en �CMV finanzas�',11,0)
				--if exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE numero_socio = @numero_Socio)
				--raiserror('El monto ingresado es m�s del que dispone en la institucion',11,0)
				--if exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE numero_socio = @numero_Socio )
				--	raiserror('El socio ya tiene una solicitud pendiente en Banca Electr�nica' ,11,0)

				
			end -- validaciones
			if exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio and id_estatus_banca = 9 )
				begin
						update TBL_BANCA_SOCIOS 
						set
							id_estatus_banca = 4, 
							id_motivo_bloqueo=1,
							banca_activa = 0,
							fecha_alta_solicitud =GETDATE(),
							viene_de_bloqueo = 0,
							contrasena =null,
							fecha_contrasena_temporal = GETDATE(),
							contrasena_temp = @contrasenaTemp,
							fecha_alta_contrasena = null,
							id_pregunta_secreta = null,
							respuesta = null,
							fecha_motivo_bloqueo = null,
							id_imagen_antiphishing = null,
							vigencia_contrasena_temporal = null,
							id_ultima_sesion = null,
							fecha_ultima_sesion =null,
							intentos_sesion = null,
							intentos_respuesta = null,
							fecha_de_desbloqueo = null,
							contrasena_estado_cuenta = @contrasenaEdoCuenta
						where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)=@numero_Socio;
						/* Actualizacion a tabla de UNE donde se valida si el socio existe*/
						update UNE..TBL_CALLCENTER_SOCIOS
						set							
							banca_registrado = 1,
							fecha_alta = getdate()
							where numero_socio = @numero_Socio
				end

				else if not exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio)
				begin

				INSERT INTO TBL_BANCA_SOCIOS 
				(
					id_persona,
					numero_socio,
					contrasena,
					fecha_alta_contrasena,
					contrasena_temp,
					fecha_contrasena_temporal,
					fecha_alta_persona,
					id_estatus_banca,
					id_pregunta_secreta,
					respuesta,
					id_motivo_bloqueo,
					banca_activa,
					fecha_alta_solicitud,
					contrasena_estado_cuenta
				)
				SELECT  
					s.Id_Persona,
					BANCA.dbo.FN_BANCA_CIFRAR(S.NUMERO),
					null            /*contrase�a*/,
					null            /*fecha_alta_contrasena*/,
					@contrasenaTemp /*contrasena_temp*/,
					GETDATE(),
					S.Fecha_Alta /*fecha_alta_persona*/,
					4    /* 1 = registro de solicitud id_estatus_banca select * from cat_banca_estatus_banca*/,
					null /*id_pregunta_secreta*/,
					null /* respuesta*/,
					1    /* id_motivo_bloqueo cart motivo bloque*/,
					0    /*banca_activa*/,
					GETDATE(), /*fecha_alta_solicitud*/
					@contrasenaEdoCuenta
					
				FROM HAPE..PERSONA s WHERE s.Numero = @numero_Socio and  s.Id_Tipo_Persona = 1

				/* Actualizacion a tabla de UNE donde se valida si el socio existe*/
				INSERT INTO UNE..TBL_CALLCENTER_SOCIOS
				(				
					numero_socio,
					banca_registrado,
					fecha_alta
				)
				select 
				@numero_Socio,
				1,
				getdate()
				
				end


				IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
					BEGIN
					INSERT INTO 
						TBL_BANCA_BITACORA_OPERACIONES 
						(
								id_tipo_bitacora,
								numero_socio,
								fecha_alta,
								id_origen_operacion,
								usuario
						)
						VALUES 
						(
							 @id_tipo_bitacora ,
							 @numero_socio ,
							 getdate() ,
							 @tipo_origen,
							 @numero_usuario
						)


						--SE VALIDA SI EL SOCIO TIENE DEBITO SE LE AGREGA SU CUNETA CLABE
						if exists(select 1 from hape..EDO_DE_CUENTA where Id_mov = 112 and numero = @numero_Socio and Tarjeta_activa = 'T')
							begin
								if exists(select 1 from TBL_BANCA_CUENTAS_INTERBANCARIAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio /*and activo = 0*/)
								begin
									if exists
									(
										select
										1
										where 											
											@numero_Socio 
										not in 
										(
											633626,
											666480,
											167484,
											314204,
											50013,
											187872,
											616206,
											730316
										)
									)
									begin
										update TBL_BANCA_CUENTAS_INTERBANCARIAS set activo = 0 where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio
									end
								end
								else
								begin
									exec banca.dbo.SP_CMV_INSERTAR_CUENTA_INTERBANCARIA @numero_Socio
								end
							end
					END

					-------------------------------------------------------------------------------------------------------------
					------ VALIDAMOS SI EXISTEN CUENTAS EN LA TABLA DE CORRESPONSALIAS LAS ACTIVAMOS TANT DE PRESTAMOS Y HABERES--
					-------------------------------------------------------------------------------------------------------------

					--IF EXISTS (SELECT 1 FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE ID_MOV = 10 AND NUMERO = @numero_Socio)
					--BEGIN
					--    UPDATE cc
					--	SET CC.ACTIVO = 1 
					--	FROM
					--	HAPE..TBL_CORRESPONSALIAS_CUENTAS cc
					--	JOIN HAPE..TBL_REVOLVENTE_LINEAS_CREDITO LC 
					--	ON  
					--		LC.Numero =  CC.numero 
					--		and cc.ID_MOV = 10
					--		and lc.num_ptmo = cc.NUM_PTMO
						   
					--	WHERE
					--			CC.Numero = @numero_Socio
					--			--and Saldo_Actual > 0
					--END
				
					--IF EXISTS (SELECT 1 FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE ID_MOV BETWEEN 1 AND 9 AND NUMERO = @numero_Socio)
					--BEGIN
					--    UPDATE cc
					--	SET CC.ACTIVO = 1 
					--	FROM
					--	HAPE..TBL_CORRESPONSALIAS_CUENTAS cc
					--	JOIN HAPE..EDO_DE_CUENTA EDC ON  EDC.Numero =  CC.numero  AND EDC.Id_mov = CC.ID_MOV and edc.Id_Tipo_persona  = 1
					--	WHERE
					--			CC.Numero = @numero_Socio
					--			and edc.Id_Tipo_persona  = 1
					--			and edc.Num_ptmo is not null
					--			and Saldo_Actual > 0
					--END

					--IF EXISTS (SELECT 1 FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE ID_MOV IN (100,103,112)  AND NUMERO = @numero_Socio)
					--BEGIN
					--    UPDATE cc
					--	SET CC.ACTIVO = 1 
					--	FROM
					--	HAPE..TBL_CORRESPONSALIAS_CUENTAS cc
					--	JOIN HAPE..EDO_DE_CUENTA EDC ON  EDC.Numero =  CC.numero  AND EDC.Id_mov = CC.ID_MOV and edc.Id_Tipo_persona  = 1
					--	WHERE
					--			CC.Numero = @numero_Socio
					--			and edc.Id_Tipo_persona  = 1
					--			and 1 = ( case when edc.Tarjeta_activa = 'T' and edc.Id_mov =112 then 1
					--					  when edc.id_mov in (100,103) then 1  end)
					--END

					--	--------------------------------------------------------------
					--	---- INSERTAMOS LOS PRESTAMOS EN TBL_CORRESPONSALIAS_CUENTAS--
					--	--------------------------------------------------------------

					
					--	INSERT INTO HAPE..TBL_CORRESPONSALIAS_CUENTAS  (NUMERO,CUENTA,FECHA_ALTA,ID_MOV,NUM_PTMO,ACTIVO)
					--	SELECT 
					--	s.numero ,
					--	'797'+'002'+REPLACE(STR(edc.Id_mov, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')  AS CLABE,
					--	getdate(),
					--	edc.Id_mov , 
					--	EDC.Num_ptmo , 
					--	1
					--	FROM  HAPE..PERSONA S  
					--	JOIN HAPE..EDO_DE_CUENTA EDC ON  EDC.Numero =  S.numero  AND EDC.Id_mov  IN (1,2,3,4,5,6,7,8,9) and edc.Id_Tipo_persona  = 1
					--	where
					--		s.Numero = @numero_Socio
					--		and s.Id_Tipo_Persona = 1
					--		and '797'+'002'+REPLACE(STR(edc.Id_mov, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')  not in 
					--	(
					--		SELECT CUENTA FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS 
					--	)
					--	and edc.Id_Tipo_persona  = 1
					--	and edc.Num_ptmo is not null
					--	and Saldo_Actual > 0
						


					--------------------------------------------------------------------------------------------------------
					----------------insertamos revolvente CORRESPONSALIAS---------------------------------------------------
					-------------------------------------------------------------------------------------------------------
					--	INSERT INTO HAPE..TBL_CORRESPONSALIAS_CUENTAS  (NUMERO,CUENTA,FECHA_ALTA,ID_MOV,NUM_PTMO,ACTIVO)
					--	SELECT 
					--	s.numero,
					--	'797'+'002'+REPLACE(STR(10, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')  AS CLABE,
					--	getdate(),
					--	10, 
					--	lc.num_ptmo , 
					--	1
					--	FROM  HAPE..PERSONA S JOIN
					--	HAPE..TBL_REVOLVENTE_LINEAS_CREDITO LC ON  lc.numero =  S.numero  
					--	 where
					--		s.Numero = @numero_Socio
					--		and s.Id_Tipo_Persona = 1 and '797'+'002'+REPLACE(STR(10, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')
					--		not in (   SELECT CUENTA FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS )


					--------------------------------------------------------------------------------------------------
					---- INSERTAMOS LOS HABERES EN TBL_CORRESPONSALIAS_CUENTAS----------------------------------------
					--------------------------------------------------------------------------------------------------

					--INSERT INTO HAPE..TBL_CORRESPONSALIAS_CUENTAS  (NUMERO,CUENTA,FECHA_ALTA,ID_MOV,NUM_PTMO,ACTIVO)
					--SELECT 
					--s.numero ,
					--'797'+'001'+REPLACE(STR(edc.Id_mov, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')  AS CLABE,
					--getdate(),
					--edc.Id_mov , 
					--EDC.Num_ptmo , 
					--1
					--FROM  HAPE..PERSONA S  
					--	JOIN HAPE..EDO_DE_CUENTA EDC ON  EDC.Numero =  S.numero  AND EDC.Id_mov  in (100,103,112) and edc.Id_Tipo_persona = 1
					--	where
					--	s.Numero = @numero_Socio
					--	and s.Id_Tipo_Persona = 1
					--	and ('797'+'001'+cast(edc.Id_mov as varchar)+REPLACE(STR(S.numero , 7), SPACE(1), '0') ) not in 
					--	(
					--	SELECT CUENTA FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS 
					--	)
					--and 1 = (case when edc.Tarjeta_activa = 'T' and edc.Id_mov =112 then 1
					--				when edc.id_mov in (100,103) then 1  end)
					--and edc.Id_Tipo_persona  = 1


					---- INSERTAMOS LAS CUENTAS INTERBANCARIAS EN TBL_CORRESPONSALIAS_INTERBANCARIAS
					--INSERT INTO TBL_BANCA_CUENTAS_INTERBANCARIAS (numero_socio,clabe,FECHA_ALTA,ID_MOV,NUM_PTMO,ACTIVO)
					--SELECT 
					--s.numero ,
					--'01797'+'001'+REPLACE(STR(edc.Id_mov, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')  AS CLABE,
					--getdate(),
					--edc.Id_mov , 
					--edc.Num_ptmo , 
					--1
					--FROM  HAPE..PERSONA S   
					--JOIN HAPE..EDO_DE_CUENTA EDC ON  EDC.Numero =  s.numero  AND EDC.Id_mov  in (100,103,112,1,2,3,4,5,6,7,8,9) and edc.Id_Tipo_persona = 1
					--	where
					--	s.Numero = @numero_Socio
					--	and s.Id_Tipo_Persona = 1
					--	and '01797'+'001'+REPLACE(STR(edc.Id_mov, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')  not in 
					--	(
					--	SELECT clabe FROM TBL_BANCA_CUENTAS_INTERBANCARIAS 
					--	)

					--and 1 = (case when edc.Tarjeta_activa = 'T' and edc.Id_mov =112 then 1
					--			when edc.id_mov in (100,103) then 1  
					--			when EDC.Id_mov in (1,2,3,4,5,6,7,8,9) and EDC.Saldo_Actual>0 AND EDC.Num_ptmo IS NOT NULL then 1
					--			end)
					--and edc.Id_Tipo_persona  = 1


		---SE INSERTA UNA ALERTA DE FRAUDE CUANDO EL SOCIO TENGA UNA EDAD MAYOR A LA DE @socio_edad--

					--EXEC SP_BANCA_FRAUDE_SIN_MOVIMIENTOS @numero_Socio
					exec SP_BANCA_FRAUDE_CREACION_PERFIL_TRANSACCIONAL_SOCIO @numero_Socio, @numero_usuario


					DECLARE @edad_Socio int, @FECHA_2 DATETIME = GETDATE(), @FECHA_1 DATETIME = (select Fecha_de_nacimiento from HAPE..persona where numero = @numero_Socio and Id_Tipo_Persona=1)

					set @edad_Socio =
					(select year(@fecha_2) - year(@fecha_1)
					-      case
							when
								substring(convert(varchar, @fecha_1, 112), 5, 4) >
								substring(convert(varchar, @fecha_2, 112), 5, 4)
										then 1
							else 0
					end
					)

					--select * from banca..TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS

					/*select  
						@socio_edad =  cast(Valor as int)
					from 
						banca..TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS 
					where 
						Id_parametro = 2
					and 
						Nombre_parametro 
					like 
						'%Alerta por Edad%'

					if(@edad_Socio>=@socio_edad)
					begin
					print''
						--EXEC SP_BANCA_FRAUDE_ALERTA_SOCIOS_MAYORES_DE_60 @numero_Socio
						if not exists(select * 	from  TBL_BANCA_FRAUDE_ALERTA where NUMERO_SOCIO = @numero_Socio and ID_TIPO_ALERTA = 5) 
							
							insert into TBL_BANCA_FRAUDE_ALERTA 
							(
								Fecha_alerta,
								NUMERO_SOCIO,
								ID_TIPO_ALERTA,
								ID_ALERTA_RECURRENTE,
								ID_ESTATUS
							)
							values
							(
								getdate(),
								@numero_Socio,
								4,
								0,
								1
							)

					end*/

					exec SP_BANCA_FRAUDE_ALERTA_EDAD @numero_socio


		--SE INSERTA UNA ALERTA DE FRAUDE CUANDO EL SOCIO QUE SE REGISTRO EN BANCA NO TIENE MOVIMIENTOS EN MAS DE UN A�O--
					exec SP_BANCA_FRAUDE_SIN_MOVS_ANIO_TST @numero_Socio

					

		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_MODIFICAR_MEDIO_NOTIFICACION]    Script Date: 16/08/2019 08:14:24 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez
UsuarioRed		pegc837648
Fecha			20181101
Objetivo		Modificar el medio notificacion del socio
Proyecto		Administrador de Banca Electr�nica
Ticket			ticket

*/

ALTER proc

[dbo].[SP_BANCA_MODIFICAR_MEDIO_NOTIFICACION]
	
		-- par�metros
		@numero_Socio int,
		@tipo_origen int = null,
		@numero_usuario varchar(20) = null,
		@id_tipo_notificacion int

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@id_banca_folio int,
						@id_tipo_bitacora int  = 41
			
			end -- inicio
			
					begin -- validaciones
			
				if not exists(SELECT * FROM HAPE.DBO.PERSONA WHERE NUMERO = @numero_Socio)
					raiserror('El socio ingresado no existe',11,0)
				else if not exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio)
				raiserror('El socio no esta registrado en �CMV finanzas�',11,0)

				--if exists (SELECT * FROM TBL_BANCA_SOCIOS WHERE numero_socio = @numero_Socio and (id_estatus_banca<6 and banca_activa=0))
				--	raiserror('El socio ingresado no tiene su cuenta de Banca Electr�nica Activa',11,0)
				if not exists(SELECT * FROM hape..tbl_contratos_haberes where numero=@numero_Socio and id_tipo_contrato = 3)
				raiserror('El socio no ha celebrado su contrato',11,0)

				
			end -- validaciones
				update hape..tbl_contratos_haberes set 
					id_tipo_notificacion = @id_tipo_notificacion
				where numero=@numero_Socio and id_tipo_contrato = 3;

				IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
					BEGIN
					INSERT INTO 
						TBL_BANCA_BITACORA_OPERACIONES 
						(
							id_tipo_bitacora,
							numero_socio,
							fecha_alta,
							id_origen_operacion,
							usuario
						)
                     VALUES 
					 (
						@id_tipo_bitacora ,
						 @numero_socio ,
						 getdate() ,
						 @tipo_origen,
						 @numero_usuario
						)


						--INSERT INTO TBL_BANCA_FOLIOS 
						--(
						--	numero_socio,
						--	fecha_alta
						--) 
						--values (@numero_socio,GETDATE())

						--select @id_banca_folio = max(id_banca_folio)from TBL_BANCA_FOLIOS where numero_socio = @numero_Socio

						--EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_Socio, @id_tipo_bitacora, @tipo_origen,@id_banca_folio,@numero_usuario
					END
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_MODIFICAR_MONTO_MAXIMO]    Script Date: 16/08/2019 08:14:47 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez
UsuarioRed		pegc837648
Fecha			20181114
Objetivo		Modificar el monto maximo del socio
Proyecto		Administrador de banca electr�nica
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_MODIFICAR_MONTO_MAXIMO]
	
		-- par�metros
		
		@numero_Socio int,
		@tipo_origen int = null,
		@numero_usuario varchar(20) = null,
		@monto_maximo_transferencia money
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@id_banca_folio int,
						@id_tipo_bitacora int  = 44
			
			end -- inicio
			
					begin -- validaciones
			
				if not exists(SELECT * FROM HAPE.DBO.PERSONA WHERE NUMERO = @numero_Socio)
					raiserror('El socio ingresado no existe',11,0)
				else if not exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio)
				raiserror('El socio no esta registrado en �CMV finanzas�',11,0)

				if not exists(SELECT * FROM hape.DBO.TBL_CONTRATOS_HABERES WHERE numero = @numero_Socio)
				raiserror('El socio no ha celebrado su contrato',11,0)

				
			end -- validaciones
				update HAPE.dbo.TBL_CONTRATOS_HABERES set 
					monto_maximo_transferencia = @monto_maximo_transferencia
				where numero=@numero_Socio and id_tipo_contrato = 3;

				IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
					BEGIN
					INSERT INTO 
						TBL_BANCA_BITACORA_OPERACIONES 
						(
							id_tipo_bitacora,
							numero_socio,
							fecha_alta,
							id_origen_operacion,
							usuario
						)
                     VALUES 
					 (
						@id_tipo_bitacora ,
						 @numero_socio ,
						 getdate() ,
						 @tipo_origen,
						 @numero_usuario
						)


						--INSERT INTO TBL_BANCA_FOLIOS 
						--(
						--	numero_socio,
						--	fecha_alta
						--) 
						--values (@numero_socio,GETDATE())

						--select @id_banca_folio = max(id_banca_folio)from TBL_BANCA_FOLIOS where numero_socio = @numero_Socio

						--EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_Socio, @id_tipo_bitacora, @tipo_origen,@id_banca_folio,@numero_usuario
					END
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_COMISIONES_NO_COBRADAS]    Script Date: 21/08/2019 04:07:34 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER proc

	[dbo].[SP_BANCA_OBTENER_COMISIONES_NO_COBRADAS]
	
		-- par�metros
		 @id_tipo_comision int
		
		-- [aqu� van los par�metros]

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
				
			
			end -- inicio
			
			begin -- transacci�n
				
				select 
					comisiones.id_comision,
					BANCA.dbo.FN_BANCA_DESCIFRAR(comisiones.numero) numero,
					comisiones.id_persona,
					comisiones.folio_UNE,
					comisiones.monto,
					comisiones.saldo,
					comisiones.pagada,
					comisiones.fecha_alta,
					comisiones.fecha_actualizacion,
					comisiones.fecha_pago,
					comisiones.id_tipo_comision,
					--socio.*,
					haberes.*,
					reporte.*
				from banca..TBL_BANCA_COMISIONES comisiones 
				inner join 
					hape..TBL_UNE_REPORTE reporte on reporte.NUMERO = BANCA.dbo.FN_BANCA_DESCIFRAR(comisiones.numero) and reporte.NUM_FOLIO = comisiones.folio_UNE
				inner join
					HAPE..TBL_CONTRATOS_HABERES haberes on haberes.numero = BANCA.dbo.FN_BANCA_DESCIFRAR(comisiones.numero) and haberes.id_tipo_contrato = 3
				where pagada = 0 and id_tipo_comision = @id_tipo_comision;
				
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
						
			-- revertir transacci�n si es necesario			
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			print ''
			-- select	@status status,
			--		@error_procedure error_procedure,
			--		@error_line error_line,
			--		@error_severity error_severity,
			--		@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_COMPROBANTE_PAGO_INTERNO_EXTERNO]    Script Date: 15/11/2019 10:29:45 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Victor Adrian Reyes
Fecha			20180417
Objetivo		OBTIENE EL CATALOGO DE BANCOS
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_OBTENER_COMPROBANTE_PAGO_INTERNO_EXTERNO]

@NUMERO varchar(20),
@idTipoBusqueda int,
@fechaInicio datetime,
@fechaFin datetime,
@folioAutorizacion bigint = null,
@tipoTransferencia int  = null  -- 1 TrasferenciasInternas , 2 -- TransferenciasExternas , 3-- PagoServicios -4-PagoPrestamos --5 todas

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message VARCHAR(500),
						@mensaje_validacion varchar(500),
						@estatus int , 
						@numero_int int,
						@numero_socio_guardado int 
			
			 end -- inicio		

			 IF @tipoTransferencia IS NULL 
			  SET @tipoTransferencia = 5


			IF OBJECT_ID('tempdb..#comprobantesPago') IS NOT NULL
			DROP TABLE #comprobantesPago


			CREATE TABLE #comprobantesPago (
			id_comprobante bigint null ,
			tipo_transferencia int,
			celular varchar(20) null ,
			bancoDestino varchar(500) ,
			clabe varchar(20),
			clabeRetiro varchar(50),
			clabeDeposito varchar(20),
			TitularCuentaDeposito varchar(500) null ,
			TitularCuentaRetiro varchar(1000) null ,
			importe decimal(18,2) null ,
			concepto varchar(500) null , 
			fechaAltaTransferencia varchar(20) null ,
			horaAltaTransferencia varchar(20) null ,
			folio bigint null , 
			correo varchar(100) null,
			estadoTransferencia varchar(500),
			idEstatusTransferecnia int,
			fechaTransferenciaProgramada varchar(20) null ,
			horaTransferenciaProgramada varchar(20) null ,
			fechaTransferenciaRealizada varchar(20) null ,
			horaTransferenciaRealizada varchar(20) null ,
			programado bit, 
			descComprobantePago varchar(500),
			id_cuenta_interna int

			)

		   select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)
		   Set @numero_int = CAST(@NUMERO as int )
		   print 'Numero:'+cast(@numero_int as varchar)
		  if(@mensaje_validacion is null)
			BEGIN
				if @tipoTransferencia = 1  OR @tipoTransferencia = 5
				BEGIN
					print 'INSERTAMOS CUENTAS INTERNA'
					------INSERTAMOS CUENTAS INTERNAS ----
					INSERT INTO #comprobantesPago (
								id_comprobante,
								tipo_transferencia,
								celular ,
								bancoDestino ,
								clabe,
								clabeRetiro,
								clabeDeposito,
								TitularCuentaDeposito ,
								TitularCuentaRetiro,
								importe ,
								concepto , 
								fechaAltaTransferencia, 
								horaAltaTransferencia,
								folio,
								correo,
								estadoTransferencia,
								idEstatusTransferecnia,
								fechaTransferenciaProgramada  ,
								horaTransferenciaProgramada ,
								fechaTransferenciaRealizada ,
								horaTransferenciaRealizada ,
								programado,
								descComprobantePago,
								id_cuenta_interna
								 ) 
					SELECT
						 A.id_transferencia,
						 1,--tipo_transferencia TrasferenciasInterna,
						 PS.Tel_Celular Celular, --celular
						 'CAJA MORELIA' BancoDestino,--bancoDestino
						 isnull(a.clave_corresponsalias_destino,'') clabe ,--clabe
						 isnull(SUBSTRING(a.clave_corresponsalias_origen,7,3)+'****'+RIGHT(a.clave_corresponsalias_origen,4),' ') clabeRetiro ,
						 isnull(SUBSTRING(a.clave_corresponsalias_destino,7,3)+'****'+RIGHT(a.clave_corresponsalias_destino,4),' ') clabeDeposito ,
						 case when P.Numero IS null then 'Transferencia entre mis cuentas' else isnull(P.Nombre_s,' ')+' '+ISNULL(P.Apellido_Paterno,'')+' '+ISNULL(P.Apellido_Materno,' ') end TitularCuentaDeposito,
						 isnull(PS.Nombre_s,' ')+' '+ISNULL(PS.Apellido_Paterno,'')+' '+ISNULL(PS.Apellido_Materno,' ') TiularCuenta,
						 A.monto,
						 case 
						      when   CI.alias Is null and CHARINDEX(cast(BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) as varchar),clave_corresponsalias_destino) > 0 and cc.ID_MOV <=10   then 'Pago a pr�stamo propio'
							  when   CI.alias Is null and CHARINDEX(cast(BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) as varchar),clave_corresponsalias_destino) > 0 and cc.ID_MOV > 10   then 'Transferencia entre mis cuentas'
							  when   CI.alias Is null and CHARINDEX(cast(BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) as varchar),clave_corresponsalias_destino) = 0 and cc.ID_MOV <= 10  then 'Pago a pr�stamos otros socios'
							  when   CI.alias Is null and CHARINDEX(cast(BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) as varchar),clave_corresponsalias_destino) = 0 and cc.ID_MOV > 10   then 'Transferencia entre socios'
							  when   CI.alias Is null then 'Transferencia entre mis cuentas)' else CI.alias end concepto,
						 CONVERT(varchar,A.fecha_alta_transferencia,103) fechaAltaTransferencia,
						 CONVERT(varchar,A.fecha_alta_transferencia,108) horaAltaTransferencia,
						 A.id_banca_folio Folio,
						 PS.Mail correo,
						 ET.descripcion, --estadoTransferencia
						 a.id_estatus_transferencia, --idEstatusTransferecnia,
						 CASE WHEN A.fecha_programada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_programada,103) END fechaTransferenciaProgramada,
						 CASE WHEN A.fecha_programada IS NULL  THEN ' ' ELSE CONVERT(varchar,A.fecha_programada,108) END horaAltaTransferenciaProgramada,
						 CASE WHEN A.fecha_transferencia_realizada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_transferencia_realizada,103) END fechaAltaTransferenciaRealizada,
						 CASE WHEN A.fecha_transferencia_realizada IS NULL  THEN ' ' ELSE CONVERT(varchar,A.fecha_transferencia_realizada,108) END horaTransferenciaRealizada,
						 A.programada,
						 case when cc.ID_MOV <=10 then 'Pago a pr�stamo' else 'Transferencia' end desComprobantePago,
						 CI.id_cuenta_interna
						
					FROM
						 [dbo].[TBL_BANCA_TRANSFERENCIAS_INTERNAS] A
						JOIN HAPE..PERSONA PS ON PS.numero =BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio)  AND PS.ID_TIPO_PERSONA = 1 AND BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio)  = @numero_int
						JOIN CAT_BANCA_ESTATUS_TRANSFERENCIAS ET ON ET.id_estatus_transferencia  = A.id_estatus_transferencia
						LEFT JOIN TBL_BANCA_CUENTAS_INTERNAS CI ON CI.id_cuenta_interna = A.id_cuenta_interna AND BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(CI.numero_socio)
						JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS CC ON CC.CUENTA = A.clave_corresponsalias_destino 
						LEFT JOIN HAPE..PERSONA P ON P.numero =CC.NUMERO  AND P.ID_TIPO_PERSONA = 1
					WHERE
						BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) = @numero_int AND
						/* @idTipoBusqueda = 1 BUSCAR POR DIA*/
						1=(CASE WHEN @idTipoBusqueda = 1 AND  Convert (varchar , A.fecha_alta_transferencia, 112) = convert(varchar,@fechaInicio ,112) THEN  1  ELSE 0 END  ) OR
						/* @idTipoBusqueda = 2 BUSCAR POR RANGO DE DIAS*/
						1=(CASE WHEN @idTipoBusqueda = 2 AND ( (convert (varchar , A.fecha_alta_transferencia, 112) >= convert(varchar,@fechaInicio ,112) AND convert (varchar , A.fecha_alta_transferencia, 112) <= convert(varchar,@fechaFin ,112)) 
														  OR (convert (varchar , A.fecha_transferencia_realizada, 112) >= convert(varchar,@fechaInicio ,112) AND convert (varchar , A.fecha_transferencia_realizada, 112) <= convert(varchar,@fechaFin ,112)) ) THEN 1 ELSE 0 END ) OR
						/* @idTipoBusqueda = 3 BUSCAR POR PERIODO*/
						1=(CASE WHEN @idTipoBusqueda = 3 AND  MONTH(A.fecha_alta_transferencia) = MONTH(@fechaInicio) AND YEAR ( A.fecha_alta_transferencia) = YEAR(@fechaFin ) THEN 1 ELSE 0 END ) OR
						/* @idTipoBusqueda = 4 BUSCAR POR MOVIMIENTO*/
						1=(CASE WHEN @idTipoBusqueda = 4 AND id_banca_folio = @folioAutorizacion THEN 1 ELSE 0 END )
				 END

				if @tipoTransferencia = 2  OR @tipoTransferencia = 5
				BEGIN
					print 'INSERTAMOS CUENTAS INTERNA'
					------INSERTAMOS CUENTAS EXTERNAS ----
					INSERT INTO #comprobantesPago (
								id_comprobante,
								tipo_transferencia,
								celular ,
								bancoDestino ,
								clabe,
								TitularCuentaDeposito ,
								TitularCuentaRetiro,
								importe ,
								concepto , 
								fechaAltaTransferencia, 
								horaAltaTransferencia,
								correo,
								folio,
								estadoTransferencia,
								idEstatusTransferecnia,
								fechaTransferenciaProgramada  ,
								horaTransferenciaProgramada ,
								fechaTransferenciaRealizada ,
								horaTransferenciaRealizada ,
								programado )

					SELECT
						A.id_transferencia,
						 2,--tipo_transferencia TransferenciasExternas,
						 PS.Tel_Celular Celular,
						 'BANCO' BancoDestino,
						--(CASE WHEN CE.id_tipo_externa IN (1,4) THEN  (SELECT institucion FROM CAT_BANCA_SPEI WHERE id_banco_spei = CE.id_banco )  ELSE (SELECT institucion FROM CAT_BANCA_BINES WHERE id_banco_bin = CE.id_banco ) END) BancoDestino,
						isnull(a.clabe_spei_destino,'') clabe ,
						CE.titular_cuenta TitularCuentaDeposito,
						isnull(PS.Nombre_s,' ')+' '+ISNULL(PS.Apellido_Paterno,'')+' '+ISNULL(PS.Apellido_Materno,' ') TiularCuenta,
						A.monto,
						CE.alias,
						CONVERT(varchar,A.fecha_alta_transferencia,103) fecha,
						CONVERT(varchar,A.fecha_alta_transferencia,108) hora,
						PS.Mail correo,
						A.id_banca_folio Folio,
						
						'Operaci�n Realizada', --estadoTransferencia
						 a.id_estatus_transferencia ,--idEstatusTransferecnia,
						 CASE WHEN A.fecha_programada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_programada,103) END fechaTransferenciaProgramada,
						 CASE WHEN A.fecha_programada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_programada,108) END horaAltaTransferenciaProgramada,
						 CASE WHEN A.fecha_transferencia_realizada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_transferencia_realizada,103) END fechaAltaTransferenciaRealizada,
						 CASE WHEN A.fecha_transferencia_realizada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_transferencia_realizada,108) END horaTransferenciaRealizada,
						 A.programado
					FROM 
						TBL_BANCA_TRANSFERENCIAS_EXTERNAS A
						JOIN HAPE..PERSONA PS ON PS.numero =BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio)  AND PS.ID_TIPO_PERSONA = 1 AND BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio)  = @numero_int
						 JOIN TBL_BANCA_CUENTAS_EXTERNAS CE ON CE.id_cuenta_externa = A.id_cuenta_externa AND BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(CE.numero_socio) and BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) = @numero_int
					WHERE
						 BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) = @numero_int AND(
						 /* @idTipoBusqueda = 1 BUSCAR POR DIA*/
						 1=(CASE WHEN @idTipoBusqueda = 1 AND  Convert (varchar , A.fecha_alta_transferencia, 112) = convert(varchar,@fechaInicio ,112) THEN  1  ELSE 0 END  ) OR
						 /* @idTipoBusqueda = 2 BUSCAR POR RANGO DE DIAS*/
						 1=(CASE WHEN @idTipoBusqueda = 2 AND  convert (varchar , A.fecha_alta_transferencia, 112) >= convert(varchar,@fechaInicio ,112) AND convert (varchar , A.fecha_alta_transferencia, 112) <= convert(varchar,@fechaFin ,112) THEN 1 ELSE 0 END ) OR
						 /* @idTipoBusqueda = 3 BUSCAR POR PERIODO*/
						 1=(CASE WHEN @idTipoBusqueda = 3 AND  MONTH(A.fecha_alta_transferencia) = MONTH(@fechaInicio) AND YEAR ( A.fecha_alta_transferencia) = YEAR(@fechaFin ) THEN 1 ELSE 0 END ) OR
						 /* @idTipoBusqueda = 4 BUSCAR POR MOVIMIENTO*/
						 1=(CASE WHEN @idTipoBusqueda = 4 AND id_banca_folio = @folioAutorizacion THEN 1 ELSE 0 END ) )
				END
						select 'OK' as mensaje, '200' as estatus
						select * from  #comprobantesPago ORDER BY id_comprobante

		END
		ELSE
			select @mensaje_validacion as mensaje, @estatus as estatus
		end try -- try principal
		
		begin catch -- catch principal
		
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@status=0
		
			select @error_message as mensaje, @status as estatus
		
		end catch -- catch principal
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_CUENTAS]    Script Date: 21/08/2019 04:09:01 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_OBTENER_CUENTAS]
@NUMERO AS VARCHAR(20),
@tipo_cuenta int
AS
BEGIN

Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int 

select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)

IF @mensaje_validacion IS NOT NULL 
BEGIN
		  SELECT @estatus AS estatus , @mensaje_validacion mensaje
		  RETURN
END

SET @numero_int = CAST(@NUMERO AS INT)

IF OBJECT_ID('tempdb..#TMP_CTAS') IS NOT NULL
	DROP TABLE #TMP_CTAS

CREATE TABLE #TMP_CTAS (
	IdMov int ,
	NombreCuenta varchar(100) , 
	Saldo Decimal (18,2) null ,
	FechaUltimoAbono varchar(20) null , 
	TipoCuenta int null , 
	NumeroContrato varchar(20) null,
	clabe_corresponsalias varchar(20),
	clabe_spei   varchar(20) null,
	estado_tarjeta int null,
	tipo_bloqueo_tarjeta int null, 
	idEsquema int  null,
	MontoIncialPrestamo decimal (18,2) null,
	idDescargaEdoCta int 
)

-- AHORRO
	IF @tipo_cuenta = 1 OR @tipo_cuenta = 0

		INSERT INTO #TMP_CTAS (IdMov  ,NombreCuenta  , Saldo  ,FechaUltimoAbono  , TipoCuenta ,NumeroContrato,clabe_corresponsalias,clabe_spei,estado_tarjeta,tipo_bloqueo_tarjeta/*,idDescargaEdoCta*/ )
		SELECT	    T.Id_mov, T.Desc_prestamo, E.Saldo_Actual,
		            (SELECT BANCA.DBO.FN_BANCA_VALIDA_FECHA_DEFAULT(MAX(Fecha_Mov)) FROM HAPE..MOVIMIENTOS WHERE id_mov = 100 AND Numero =@numero_int AND Id_tipomov IN(10,310)) FechaUltimoAbono ,
					1 as TipoCuenta,
					0 as NumeroContrato,
					CC.CUENTA as clabe_corresponsalias,
					BCI.clabe as clabe_spei,
					0 as estado_tarjeta,
					0 as tipo_bloqueo_tarjeta
					--,edo.id_descarga

		FROM		HAPE..EDO_DE_CUENTA E 
		JOIN        HAPE..TIPOS_DE_OPERACIONES T ON T.Id_mov = E.Id_mov
		LEFT JOIN	HAPE..TBL_CORRESPONSALIAS_CUENTAS CC ON CC.NUMERO = @numero_int and E.Id_mov = CC.ID_MOV 
		LEFT JOIN	BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS BCI ON BANCA.dbo.FN_BANCA_DESCIFRAR(BCI.numero_socio) = @numero_int and E.Id_mov = BCI.ID_MOV and BCI.ACTIVO = 1 and BCI.activo = 1
		--LEFT JOIN   (SELECT TOP 1 * from BANCA..TBL_BANCA_DESCARGA_ESTADO_DE_CUENTA WHERE NUMERO = @numero_int AND id_tipo_edo_cuenta = 1 order by fecha_alta desc) EDO ON  EDO.numero = @numero_int
		
		WHERE		E.NUMERO = @numero_int 
				AND E.id_mov = 100
				AND E.Id_Tipo_persona = 1
		
-- INVERDINAMICA
	IF @tipo_cuenta = 1 OR @tipo_cuenta = 0
		INSERT INTO #TMP_CTAS (IdMov  ,NombreCuenta  , Saldo  ,FechaUltimoAbono  , TipoCuenta ,NumeroContrato,clabe_corresponsalias,clabe_spei,estado_tarjeta,tipo_bloqueo_tarjeta/*,idDescargaEdoCta*/)
		SELECT	    T.Id_mov, T.Desc_prestamo, E.Saldo_Actual, 
					(SELECT BANCA.DBO.FN_BANCA_VALIDA_FECHA_DEFAULT(MAX(Fecha_Mov)) FROM HAPE..MOVIMIENTOS WHERE id_mov = 103 AND Numero =@numero_int AND Id_tipomov IN(50,350)) FechaUltimoAbono ,
					1 as TipoCuenta ,
					0 as NumeroContrato,
					CC.CUENTA as clabe_corresponsalias,
					BCI.clabe as clabe_spei,
					0 as estado_tarjeta,
					0 as tipo_bloqueo_tarjeta
		FROM		HAPE..EDO_DE_CUENTA E
		JOIN        HAPE..TIPOS_DE_OPERACIONES T ON T.Id_mov = E.Id_mov
		LEFT JOIN	HAPE..TBL_CORRESPONSALIAS_CUENTAS CC ON CC.NUMERO = @numero_int and E.Id_mov = CC.ID_MOV 
		LEFT JOIN	BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS BCI ON BANCA.dbo.FN_BANCA_DESCIFRAR(BCI.numero_socio) = @numero_int and E.Id_mov = BCI.ID_MOV and BCI.activo = 1
		LEFT JOIN   (SELECT TOP 1 * from BANCA..TBL_BANCA_DESCARGA_ESTADO_DE_CUENTA WHERE NUMERO = @numero_int AND id_tipo_edo_cuenta = 1 order by fecha_alta desc) EDO ON  EDO.numero = @numero_int

		WHERE		E.NUMERO = @numero_int 
				AND E.id_mov = 103
				AND E.Id_Tipo_persona = 1

-- DEBITO
	IF @tipo_cuenta = 1 OR @tipo_cuenta = 0
		IF EXISTS (
					SELECT TOP	1 NUMERO FROM HAPE..EDO_DE_CUENTA M WHERE NUMERO = @numero_int AND M.id_mov = 112 and Tarjeta_activa ='T'
				  )
		BEGIN

			INSERT INTO #TMP_CTAS (IdMov  ,NombreCuenta  , Saldo  ,FechaUltimoAbono  , TipoCuenta ,NumeroContrato,clabe_corresponsalias,clabe_spei,estado_tarjeta,tipo_bloqueo_tarjeta/*,idDescargaEdoCta*/)
			SELECT		T.Id_mov, T.Desc_prestamo, E.Saldo_Actual,
						(SELECT BANCA.DBO.FN_BANCA_VALIDA_FECHA_DEFAULT(MAX(Fecha_Mov))FROM HAPE..MOVIMIENTOS WHERE id_mov = 112 AND Numero =@numero_int AND Id_tipomov IN(1002,1001)) FechaUltimoAbono ,
						1 as TipoCuenta,
						0 as NumeroContrato,
						CC.CUENTA as clabe_corresponsalias,
						BCI.clabe as clabe_spei,
						1 as estado_tarjeta, --temporal
						1 as tipo_bloqueo_tarjeta --temporal
			FROM		HAPE..EDO_DE_CUENTA E
			JOIN        HAPE..TIPOS_DE_OPERACIONES T ON T.Id_mov = E.Id_mov
			LEFT JOIN	HAPE..TBL_CORRESPONSALIAS_CUENTAS CC ON CC.NUMERO = @numero_int and E.Id_mov = CC.ID_MOV 
			LEFT JOIN	BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS BCI ON BANCA.dbo.FN_BANCA_DESCIFRAR(BCI.numero_socio) = @numero_int and E.Id_mov = BCI.ID_MOV and BCI.activo = 1
			LEFT JOIN   (SELECT TOP 1 * from BANCA..TBL_BANCA_DESCARGA_ESTADO_DE_CUENTA WHERE NUMERO = @numero_int AND id_tipo_edo_cuenta = 1 order by fecha_alta desc) EDO ON  EDO.numero = @numero_int

			WHERE		E.NUMERO = @numero_int 
					AND E.id_mov = 112
					AND E.Id_Tipo_persona = 1
		END
	

-- PRESTAMOS

DECLARE
@FECHA_ULTIMO_ORD DATETIME,
@FECHA_ULTIMO_MOR DATETIME ,
@FECHA_ULTIMO_ABONO DATETIME,
@FECHA DATETIME
	
	IF @tipo_cuenta = 3 OR @tipo_cuenta = 0
	BEGIN
		IF EXISTS (
						SELECT TOP 1 E.Id_mov
						FROM	HAPE..EDO_DE_CUENTA E
								INNER JOIN hape..TIPOS_DE_OPERACIONES O ON O.Id_mov = E.Id_mov
						WHERE	E.Id_mov < 10 
							AND	Numero = @numero_int
							AND	Saldo_Actual > 0 
				  )
		BEGIN
		
			 SELECT	@FECHA_ULTIMO_ORD= Ultimo_Int_Ord,
					@FECHA_ULTIMO_MOR= Ultimo_Int_Mor,
					@FECHA_ULTIMO_ABONO= Ultimo_Abono
			 FROM HAPE..EDO_DE_CUENTA 
			 WHERE 
				   numero = @numero_int
			 AND   Saldo_Actual > 0 
			 AND   Id_mov < 10 

			 SELECT @FECHA=BANCA.DBO.FN_OBTENER_FECHA_ULTIMO_ABONO(@FECHA_ULTIMO_ORD,@FECHA_ULTIMO_MOR,@FECHA_ULTIMO_ABONO)

		 
			INSERT INTO #TMP_CTAS (IdMov  ,NombreCuenta  , Saldo  ,FechaUltimoAbono  , TipoCuenta ,NumeroContrato,clabe_corresponsalias,
			                  clabe_spei,estado_tarjeta,tipo_bloqueo_tarjeta , MontoIncialPrestamo,idEsquema/*,idDescargaEdoCta*/ )
			SELECT	 e.Id_mov, 
					BANCA.[dbo].FN_BANCA_OBTENER_NOMBRE_COMERCIAL(E.num_ptmo),/*O.Desc_prestamo,*/ 
					E.Saldo_Actual,
					BANCA.DBO.FN_BANCA_VALIDA_FECHA_DEFAULT(@FECHA),
					3 as TipoCuenta , 
					e.Num_ptmo as NumeroContrato,
					CC.CUENTA as clabe_corresponsalias,
					BCI.clabe as clabe_spei,
					0 as estado_tarjeta,
					0 as tipo_bloqueo_tarjeta, 
					e.Monto_Inicial,
					e.id_Esquema
					--,edo.id_descarga
					/*CASE
						WHEN Dias_Vencidos > 0 THEN 'VENCIDO'
						ELSE 'AL CORRIENTE'
					END AS ESTADO_CTA*/
			FROM	HAPE..EDO_DE_CUENTA E
					INNER JOIN hape..TIPOS_DE_OPERACIONES O ON O.Id_mov = E.Id_mov
					LEFT JOIN	HAPE..TBL_CORRESPONSALIAS_CUENTAS CC ON CC.NUMERO = @numero_int and E.Id_mov = CC.ID_MOV 
					LEFT JOIN	BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS BCI ON BANCA.dbo.FN_BANCA_DESCIFRAR(BCI.numero_socio) = @numero_int and E.Id_mov = BCI.ID_MOV and BCI.activo = 1
					--LEFT JOIN   (SELECT TOP 1 * from BANCA..TBL_BANCA_DESCARGA_ESTADO_DE_CUENTA WHERE NUMERO = @numero_int AND id_tipo_edo_cuenta = 2 and numero_prestamo = e.Num_ptmo  order by fecha_alta desc) EDO ON  EDO.numero = @numero_int

			WHERE	E.Id_mov < 10 
				AND	E.Numero = @numero_int
				AND	Saldo_Actual > 0 
				and E.id_tipo_persona= 1
		END

	-- REVOLVENTE

		IF EXISTS (SELECT 1 from HAPE..VW_REVOLVENTE_LINEAS where numero = @numero_int )
		BEGIN


			 select	@FECHA_ULTIMO_ORD= fecha_ultimo_abono,
					@FECHA_ULTIMO_MOR= fecha_ultimo_int_ord,
					@FECHA_ULTIMO_ABONO= fecha_ultimo_int_mor
			 from HAPE..VW_REVOLVENTE_LINEAS 
			 where numero = @numero_int

			 SELECT @FECHA=BANCA.DBO.FN_OBTENER_FECHA_ULTIMO_ABONO(@FECHA_ULTIMO_ORD,@FECHA_ULTIMO_MOR,@FECHA_ULTIMO_ABONO)

			 INSERT INTO #TMP_CTAS (IdMov  ,NombreCuenta  , Saldo  ,FechaUltimoAbono  , TipoCuenta ,NumeroContrato,clabe_corresponsalias,clabe_spei,estado_tarjeta,tipo_bloqueo_tarjeta, MontoIncialPrestamo , idEsquema)
			 SELECT 10,
				BANCA.[dbo].FN_BANCA_OBTENER_NOMBRE_COMERCIAL(E.num_ptmo),
				saldo_actual,
				BANCA.DBO.FN_BANCA_VALIDA_FECHA_DEFAULT(@FECHA),
				3 as TipoCuenta, 
				e.id_linea as NumeroContrato,
				CC.CUENTA as clabe_corresponsalias,
				BCI.clabe as clabe_spei,
				0 as estado_tarjeta,
				0 as tipo_bloqueo_tarjeta,
				e.limite_credito,
				4 as idEsquema
			 from HAPE..VW_REVOLVENTE_LINEAS  E
			 INNER JOIN hape..TIPOS_DE_OPERACIONES O ON O.Id_mov = 10
			 LEFT JOIN	HAPE..TBL_CORRESPONSALIAS_CUENTAS CC ON CC.NUMERO = @numero_int and 10 = CC.ID_MOV  
			 LEFT JOIN	BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS BCI ON BANCA.dbo.FN_BANCA_DESCIFRAR(BCI.numero_socio) = @numero_int and 10 = BCI.ID_MOV and BCI.activo = 1
			 where E.numero = @numero_int
		END
	END

-- PLAZOS FIJOS
	IF @tipo_cuenta = 2 OR @tipo_cuenta = 0
		IF EXISTS (
						SELECT  TOP 1 Numero
						FROM	HAPE..MOVIMIENTOS
						WHERE	Id_tipomov = 41 
							AND Activo = 'T' 
							AND	NUM_DPF NOT IN ( SELECT DISTINCT NUM_DPF FROM HAPE..MOVIMIENTOS WHERE Id_tipomov = 341 AND Id_Tipo_persona = 1 AND NUMERO = @numero_int AND Activo = 'T' ) 
							AND Numero = @numero_int
							AND Id_Tipo_persona = 1
				  )
		BEGIN
			INSERT INTO #TMP_CTAS (IdMov  ,NombreCuenta  , Saldo  ,FechaUltimoAbono  , TipoCuenta ,NumeroContrato,clabe_corresponsalias,clabe_spei,estado_tarjeta,tipo_bloqueo_tarjeta)
			SELECT	105, 'INVERPLUS CMV' /*+ CAST (DIAS AS VARCHAR(30)) AS DESCRIPCION_MOVIMIENTO*/,  
					isnull(MONTO,0) AS IMPORTE, 
					--(select saldo_actual from HAPE..EDO_DE_CUENTA where numero = @numero and id_mov = 105) AS SALDO, 
					 BANCA.DBO.FN_BANCA_VALIDA_FECHA_DEFAULT(Fecha_Mov),
					 2 as TipoCuenta,
					 NUM_DPF as NumeroContrato,
					'' as clabe_corresponsalias,
					'' as clabe_spei,
					0 as estado_tarjeta,
					0 as tipo_bloqueo_tarjeta
			FROM	HAPE..MOVIMIENTOS
			WHERE	Id_tipomov = 41 
				AND Activo = 'T' 
				AND	NUM_DPF NOT IN ( SELECT DISTINCT NUM_DPF FROM HAPE..MOVIMIENTOS 
				WHERE Id_tipomov = 341 AND Id_Tipo_persona = 1 AND NUMERO = @numero_int AND Activo = 'T' ) 
				AND Numero = @numero_int
				AND Id_Tipo_persona = 1
		END

-- FIN DEL PROCEDIMIENTO
SELECT 200 ESTATUS , *
FROM	#TMP_CTAS

--Convert(varchar(10), CONVERT(date,getdate(),106),103)
-- '$'+convert(varchar(50), CAST(m.Monto as money), -1) as IMPORTE
DROP TABLE #TMP_CTAS


END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_CUENTAS_DEPOSITO_EXTERNAS]    Script Date: 23/12/2019 01:10:30 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		MAXIMILIANO GONZALEZ
-- Create date: 2018-05-17
-- Description:	OBTIENE LAS CUENTAS DE DEPOSITO EXTERNAS DEL SOCIO DEL CUAL SE ENVIO EL NUMERO DE SOCIO
--	
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_OBTENER_CUENTAS_DEPOSITO_EXTERNAS]
@NUMERO varchar(20),
@TipoCuentaDepositoExterna int 
AS
BEGIN

--Transferencias = 1,
--Pago_Tarjeta_Credito = 2,
--Todas = 3

begin try
Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int 

  SELECT @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)
  SET @numero_int = CAST(@NUMERO as int )

  if(@mensaje_validacion is null)
  BEGIN
		IF EXISTS (SELECT * FROM TBL_BANCA_CUENTAS_EXTERNAS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int)
		BEGIN
		    CREATE TABLE #CUENTAS (
			id_cuenta_externa int ,
			id_tipo_externa int , 
			clabe varchar(20),
			titular_cuenta varchar(200),
			alias varchar(200) null ,
			monto_maximo decimal(18,2),
			correo  varchar(50) ,
			id_banco int ,
			institucion varchar(50) null ,
			id_Banco_BIN INT
			 )

					--  OBTENEMOS LAS CUENTAS EXTERNAS POR CLABE SPEI  CELULAR
					INSERT INTO  #CUENTAS (
					id_cuenta_externa  ,
					id_tipo_externa  , 
					clabe ,
					titular_cuenta ,
					alias  ,
					monto_maximo ,
					correo   ,
					id_banco  ,
					institucion,
					id_Banco_BIN)
					SELECT
					c.id_cuenta_externa,
					c.id_tipo_cuenta_externa,
					c.clabe_interbancaria,
					c.titular_cuenta,
					c.alias,
					c.monto_maximo,
					c.correo,
					spei.id_banco_spei,
					spei.institucion,
					spei.clabe id_banco_bin 
					FROM TBL_BANCA_CUENTAS_EXTERNAS c
					JOIN  CAT_BANCA_BANCOS_CLABES_SPEI  spei on c.id_banco =spei.id_banco_spei --AND C.id_tipo_cuenta_externa IN (1,4)
					WHERE 
					BANCA.dbo.FN_BANCA_DESCIFRAR(c.numero_socio) = @numero_int
					and c.activa = 1
					-- AND c.id_tipo_cuenta_externa IN (1,4)

					---- OBTENEMOS LAS CUENTAS Y EN ESTE CASO EL NUMERO DE TARJETA
					--INSERT INTO  #CUENTAS (
					--id_cuenta_externa  ,
					--id_tipo_externa  , 
					--clabe ,
					--titular_cuenta ,
					--alias  ,
					--monto_maximo ,
					--correo   ,
					--id_banco  ,
					--institucion )
					--SELECT
					--c.id_cuenta_externa,
					--c.id_tipo_cuenta_externa,
					--c.numero_tarjeta,
					--c.titular_cuenta,
					--c.alias,
					--c.monto_maximo,
					--c.correo,
					--bin.id_banco_bin,
					--bin.institucion
					--FROM TBL_BANCA_CUENTAS_EXTERNAS c
					--LEFT JOIN  CAT_BANCA_BINES  bin on c.id_banco =bin.id_banco_bin AND C.id_tipo_cuenta_externa in (2,3)
					--WHERE 
					--c.numero_socio = @numero_int AND
					--c.id_tipo_cuenta_externa  in (2,3)


			SELECT 200 estatus , 'OK' mensaje
			SELECT * 
			FROM
				 #CUENTAS
			WHERE
				 1 =  case when @TipoCuentaDepositoExterna = 1 and id_tipo_externa in (1,3,4) then 1 else 0 end  OR
				 1 =  case when @TipoCuentaDepositoExterna = 2 and id_tipo_externa in (2) then 1 else 0 end  OR
				 1 =  case when @TipoCuentaDepositoExterna = 3 then 1 else 0 end 
			DROP TABLE #CUENTAS

		END
		ELSE
		SELECT id_excepcion AS estatus , descripcion as mensaje 
		FROM CAT_BANCA_EXCEPTIONS
		WHERE id_excepcion = 340
  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje




end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_CUENTAS_DEPOSITO_INTERNA]    Script Date: 21/08/2019 04:11:22 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		MAXIMILIANO GONZALEZ
-- Create date: 2018-05-17
-- Description:	OBTIENE LAS CUENTAS DE DEPOSITO INTERNAS DEL SOCIO DEL CUAL SE ENVIO EL NUMERO DE SOCIOS
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_OBTENER_CUENTAS_DEPOSITO_INTERNA]
@NUMERO varchar(20),
@tipo_cuenta_deposito_interna int
AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int 

select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)
set @numero_int = CAST(@NUMERO as int )

  if(@mensaje_validacion is null)
  BEGIN
		--CUANDO TIPO CUENTA IGUAL A 1: Cuentas_Haberes_Socios_Mismo_Banco
		IF(@tipo_cuenta_deposito_interna = 1)
		BEGIN
			IF (SELECT COUNT(*) from  TBL_BANCA_CUENTAS_INTERNAS  cuentas_internas
				inner join
					HAPE.dbo.TBL_CORRESPONSALIAS_CUENTAS corres_cuentas on cuentas_internas.clabe_corresponsalias = corres_cuentas.CUENTA
				where 
					BANCA.dbo.FN_BANCA_DESCIFRAR(cuentas_internas.numero_socio) = @numero_int
					and cuentas_internas.activo = 1 
					and corres_cuentas.id_mov >= 100
				) > 0

				SELECT 200 estatus,
				cuentas_internas.id_cuenta_interna,
				BANCA.dbo.FN_BANCA_DESCIFRAR(cuentas_internas.numero_socio) numero_socio,
				cuentas_internas.titular_cuenta,
				cuentas_internas.clabe_corresponsalias,
				cuentas_internas.alias,
				cuentas_internas.monto_maximo,
				cuentas_internas.correo,
				cuentas_internas.fecha_alta,
				cuentas_internas.divisa,
				cuentas_internas.activo
				from 
					TBL_BANCA_CUENTAS_INTERNAS  cuentas_internas
				inner join
					HAPE.dbo.TBL_CORRESPONSALIAS_CUENTAS corres_cuentas on cuentas_internas.clabe_corresponsalias = corres_cuentas.CUENTA
				where 
					BANCA.dbo.FN_BANCA_DESCIFRAR(cuentas_internas.numero_socio) = @numero_int
					and cuentas_internas.activo = 1
					and corres_cuentas.id_mov >= 100
				order by corres_cuentas.Id_mov asc
			ELSE
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 340

		END
		--CUANDO TIPO CUENTA IGUAL A 2: Cuentas_Prestamos_Socios_Mismo_Banco
		IF(@tipo_cuenta_deposito_interna = 2)
		BEGIN
			IF (SELECT COUNT(*) from  TBL_BANCA_CUENTAS_INTERNAS  cuentas_internas
				inner join
					HAPE.dbo.TBL_CORRESPONSALIAS_CUENTAS corres_cuentas on cuentas_internas.clabe_corresponsalias = corres_cuentas.CUENTA
				where 
					BANCA.dbo.FN_BANCA_DESCIFRAR(cuentas_internas.numero_socio) = @numero_int
					and cuentas_internas.activo = 1
					and corres_cuentas.id_mov <= 10
				) > 0

				SELECT 200 estatus,
				cuentas_internas.id_cuenta_interna,
				BANCA.dbo.FN_BANCA_DESCIFRAR(cuentas_internas.numero_socio) numero_socio,
				cuentas_internas.titular_cuenta,
				cuentas_internas.clabe_corresponsalias,
				cuentas_internas.alias,
				cuentas_internas.monto_maximo,
				cuentas_internas.correo,
				cuentas_internas.fecha_alta,
				cuentas_internas.divisa,
				cuentas_internas.activo
				from 
					TBL_BANCA_CUENTAS_INTERNAS  cuentas_internas
				inner join
					HAPE.dbo.TBL_CORRESPONSALIAS_CUENTAS corres_cuentas on cuentas_internas.clabe_corresponsalias = corres_cuentas.CUENTA
				where 
					BANCA.dbo.FN_BANCA_DESCIFRAR(cuentas_internas.numero_socio) = @numero_int
					and cuentas_internas.activo = 1
					and corres_cuentas.id_mov <= 10
				order by corres_cuentas.Id_mov asc
			ELSE
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 340
		END
		--CUANDO TIPO CUENTA IGUAL A 3: Todas_Las_Cuentas_De_Deposito_Internas
		IF(@tipo_cuenta_deposito_interna = 3)
		BEGIN
			IF (SELECT COUNT(*) from  TBL_BANCA_CUENTAS_INTERNAS  cuentas_internas
				inner join
					HAPE.dbo.TBL_CORRESPONSALIAS_CUENTAS corres_cuentas on cuentas_internas.clabe_corresponsalias = corres_cuentas.CUENTA
				where 
					BANCA.dbo.FN_BANCA_DESCIFRAR(cuentas_internas.numero_socio) = @numero_int
					and cuentas_internas.activo = 1
				) > 0

				SELECT 200 estatus,
				cuentas_internas.id_cuenta_interna,
				BANCA.dbo.FN_BANCA_DESCIFRAR(cuentas_internas.numero_socio) numero_socio,
				cuentas_internas.titular_cuenta,
				cuentas_internas.clabe_corresponsalias,
				cuentas_internas.alias,
				cuentas_internas.monto_maximo,
				cuentas_internas.correo,
				cuentas_internas.fecha_alta,
				cuentas_internas.divisa,
				cuentas_internas.activo
				from 
					TBL_BANCA_CUENTAS_INTERNAS  cuentas_internas
				inner join
					HAPE.dbo.TBL_CORRESPONSALIAS_CUENTAS corres_cuentas on cuentas_internas.clabe_corresponsalias = corres_cuentas.CUENTA
				where 
					BANCA.dbo.FN_BANCA_DESCIFRAR(cuentas_internas.numero_socio) = @numero_int
					and cuentas_internas.activo = 1 
				order by corres_cuentas.Id_mov asc
			ELSE
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 340
		END
  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje
end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_DETALLE_CUENTA]    Script Date: 27/01/2020 01:24:46 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		EDSON
-- Create date: 2018-04-25
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_OBTENER_DETALLE_CUENTA]
@NUMERO AS VARCHAR(20),
@clabe_corresponsalias varchar(20),
@numero_contrato varchar(20)=null,
@id_tipo_persona int =null,
@fecha_calculo datetime = null

AS
BEGIN

Declare 
@mensaje_validacion varchar(500),
@estatus int =200, 
@numero_int int,
@id_mov int = 0

select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)

IF @mensaje_validacion IS NOT NULL 
BEGIN
		  SELECT @estatus AS estatus , @mensaje_validacion mensaje
		  RETURN
END

SET @numero_int = CAST(@NUMERO AS INT)

if not exists (select  * from HAPE..TBL_CORRESPONSALIAS_CUENTAS
where
	NUMERO = @numero_int and cuenta = @clabe_corresponsalias) 
	and (@numero_contrato IS NULL OR @numero_contrato = '' OR @numero_contrato = 0)
begin
	select 
		@estatus = 1000, 
		@mensaje_validacion = 'Datos incorrectos.'
end


IF(@fecha_calculo IS NULL)
	SELECT @fecha_calculo = GETDATE()

IF(@id_tipo_persona IS NULL)
	SELECT @id_tipo_persona = 1

IF (@numero_contrato IS NULL OR @numero_contrato = '' OR @numero_contrato = 0)
	select @id_mov = ID_MOV from HAPE.dbo.TBL_CORRESPONSALIAS_CUENTAS where CUENTA = @clabe_corresponsalias
ELSE
	SELECT @id_mov = 105

IF OBJECT_ID('tempdb..#Cuenta') IS NOT NULL
	DROP TABLE #Cuenta


IF OBJECT_ID('tempdb..#RESUMEN_PAGO') IS NOT NULL
	DROP TABLE #RESUMEN_PAGO




CREATE TABLE #Cuenta 
(
    --haberes
	ClabeCorresponsalias varchar(20)  COLLATE Traditional_Spanish_CI_AS,
	ClabeSpei			varchar(20),
	IdMov				int ,
	NombreCuenta		varchar(100) , 
	Saldo				money ,
	FechaUltimoAbono	datetime , 
	TipoCuenta			int,
	NumeroTarjeta		varchar (25),
	NumeroDepositos    money null,
	NumeroRetiros      money null,
	-- debito
	EstadoTarjeta		int default null,
	TipoBloqueoTarjeta	int default null,
	--------	PRESTAMOS	----------
	DiasVencidos		int,
	EstatusCredito		varchar(100) , --estatus_cartera
	PagoHoy 			money, --PagoAlCorriente
	PeriodosAtrasados	int,
	MontoInicial		money,
	FechaPrestamo		datetime,
	FechaCorte			varchar(100),
	FechaLimitePago		varchar(100),
	MontoDisponible		money,
	LimiteCredito		money,
    FechaUltimoPago		datetime,
	ReferenciaCorresponsales	varchar(100),
	---
	SaldoAdelantado		money default null,
	SaldoActual			money default null,
	idEsquema int null,
	----------	INVERSION	------------
	FechaApertura		varchar(20),
	NoContrato			int,
	FechaVencimiento	varchar(20),
	Plazo				int,
	Tasa				decimal(4,2),
	numeroPago			int

 )

 
-- AHORRO,INVERDINAMICA,DEBITO
IF(@id_mov IN (100,103,112))
BEGIN

			Declare @numRetiros money, @numDepositos money
			SELECT @numRetiros= ISNULL(SUM(Monto),0) FROM HAPE..MOVIMIENTOS WHERE 
			id_mov  = @id_mov 
			AND Activo ='T'
			AND Numero = @numero_int
			AND 
			1 = (case when Id_tipomov in (
										310 ,--	Retiro del Ahorro
										350 ,--	Retiro de InverDin�mica
										1001,--	Retiro de Tarjeta de D�bito
										120	,-- Retiro de Ahorro CMV por Dep�sito a Inverplus CMV
										121 ,-- Retiro de Inverdin�mica CMV por Dep�sito a Inverplus CMV
										122 --	Retiro de D�bito CMV por Dep�sito a Inverplus CMV

			) then 1
					end ) AND  CONVERT(VARCHAR ,Fecha_Mov , 112) =  CONVERT(VARCHAR ,@fecha_calculo  , 112)


			SELECT @numDepositos = ISNULL(SUM(isnull(Monto,0)),0) FROM HAPE..MOVIMIENTOS WHERE 
			id_mov  = @id_mov 
			AND Activo ='T'
			AND Numero = @numero_int 
			AND 
			1 = (case   when Id_tipomov in (
								10	 ,--Dep�sito al  Ahorro
								50	 ,--Dep�sito a InverDin�mica
								124	 ,--Dep�sito de Ahorro CMV por Retiro a Inverplus CMV
								125	 ,--Dep�sito de Inverdin�mica CMV por Retiro a Inverplus CMV
								126	 ,--Dep�sito de D�bito CMV por Retiro a Inverplus CMV
								1002 --Dep�sito a Tarjeta de D�bito

				) then 1 end )
			AND CONVERT(VARCHAR ,Fecha_Mov , 112) =  CONVERT(VARCHAR ,@fecha_calculo  , 112)



	INSERT INTO #Cuenta 
		(NumeroDepositos,NumeroRetiros  ,ClabeCorresponsalias,ClabeSpei,IdMov  ,NombreCuenta  , Saldo  ,FechaUltimoAbono  , TipoCuenta ,NumeroTarjeta,EstadoTarjeta,TipoBloqueoTarjeta)
	SELECT	   
		@numDepositos,
		@numRetiros, 
		@clabe_corresponsalias clabe_corresponsalias,
		CI.clabe clabe_spei,
		MOV.Id_mov, 
		MOV.Desc_prestamo,
		E.Saldo_Actual, E.Fecha,1,
		E.Num_tarjeta,
		case when @id_mov = 112 then 1 else null end estado_tarjeta,
		case when @id_mov = 112 then 1 else null end tipo_bloqueo_tarjeta
	FROM	HAPE..EDO_DE_CUENTA E 
	INNER JOIN
		HAPE..TIPOS_DE_OPERACIONES MOV ON E.Id_mov = MOV.Id_mov
	LEFT JOIN
		BANCA.dbo.TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON BANCA.dbo.FN_BANCA_DESCIFRAR(CI.numero_socio) = @numero_int AND CI.id_mov = @id_mov AND CI.activo = 1
	WHERE		
		E.NUMERO = @numero_int 
		AND E.id_mov = @id_mov
		AND E.Id_Tipo_persona = 1
END
ELSE
BEGIN
	-- PRESTAMOS
	IF	@id_mov < 10 AND EXISTS(SELECT * FROM HAPE..EDO_DE_CUENTA WHERE NUMERO = @numero_int AND Id_Tipo_persona = @id_tipo_persona 
								AND Id_mov = @id_mov AND Saldo_Actual > 0)
	BEGIN
		
		declare 
			@idEsquema int,
			@PagoHoy money,
			@fechaCorte varchar(20),
			@fechaLimitePago varchar(20)

		select @idEsquema = Id_Esquema from HAPE.dbo.EDO_DE_CUENTA where Numero = @numero_int AND Id_mov = @id_mov

		
		---DECRECIENTES
		IF @idEsquema = 1
		BEGIN
		    PRINT 'DECRECIENTES'
			-----CALCULO DE FECHA DE CORTE, Y DE LIMITE DE PAGO
			SELECT TOP 1 
				@fechaCorte = CAST((DATEADD(day,1,CALENDARIO.fecha_inicio)) as datetime),
				@fechaLimitePago =   CALENDARIO.fecha_fin
			FROM (
			select numero,id_mov,num_ptmo,MAX(version_calendario) version_calendario from 
				HAPE..TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES calendarioA			
			WHERE
				calendarioA.numero = @numero_int
				AND calendarioA.id_mov = @id_mov
			GROUP BY 
				numero,id_mov,num_ptmo
				) ULTIMO_CALENDARIO
			JOIN HAPE..TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES CALENDARIO ON CALENDARIO.numero = ULTIMO_CALENDARIO.numero
			AND CALENDARIO.id_mov =  ULTIMO_CALENDARIO.id_mov AND CALENDARIO.num_ptmo = ULTIMO_CALENDARIO.num_ptmo AND CALENDARIO.version_calendario = ULTIMO_CALENDARIO.version_calendario 
			WHERE
				( convert(varchar,fecha_fin,112) >= convert(varchar,@fecha_calculo,112) ) 
				and capital_actual > 0
			ORDER BY fecha_inicio ASC
			--PRINT '#RESUMEN_PAGO'

			

			create table #RESUMEN_PAGO(
				estatus int null,
				saldo_Actual money null,
				interes_moratorio money null,
				interes_ord_vencido money null,
				interes_ordinario_vigente money null,
				capital_vencido money null,
				capital_corte money null,
				capital_no_devengado_fin money null,
				pago_al_corriente	money null,
				saldo_adelanto money null,
				seguro_vida money null,
				seguro_danos money null,		
				capitalAmort money null,
				ivaIntMoratorio money null,
				ivaIntOrdinarioVencido money null,
				ivaIntOrdinarioVigente money null,
				-- para quitas
				int_moratorio_quitas money null,
				int_moratorio_quitas_iva money null,
				int_ordinario_quitas money null,
				int_ordinario_quitas_iva money null,
				reserva_capital money null,
				reserva_interes money null,
				gastos_cobranza money null,
				iva_gastos_cobranza money null,
				tasa_gastos_cobranza money null,
				primer_corte_vigente money null
			)
			--PRINT '#despues #RESUMEN_PAGO'
			insert #RESUMEN_PAGO (
			    estatus ,
				saldo_Actual  ,
				interes_moratorio  ,
				interes_ord_vencido  ,
				interes_ordinario_vigente  ,
				capital_vencido  ,
				capital_corte  ,
				capital_no_devengado_fin  ,
				pago_al_corriente	 ,
				saldo_adelanto  ,
				seguro_vida  ,
				seguro_danos  ,		
				capitalAmort  ,
				ivaIntMoratorio  ,
				ivaIntOrdinarioVencido  ,
				ivaIntOrdinarioVigente  ,
				-- para quitas
				int_moratorio_quitas  ,
				int_moratorio_quitas_iva  ,
				int_ordinario_quitas  ,
				int_ordinario_quitas_iva  ,
				reserva_capital  ,
				reserva_interes  ,
				gastos_cobranza ,
				iva_gastos_cobranza ,
				tasa_gastos_cobranza ,
				primer_corte_vigente  ) exec hape.dbo.SP_INTERES_DIARIO_OBTIENE_SALDOS @numero_int,@id_mov,@fecha_calculo 
			
			---SELECT 'resumen pago', * FROM #RESUMEN_PAGO
					
			
			INSERT INTO #Cuenta (ClabeCorresponsalias,ClabeSpei,IdMov  ,NombreCuenta  , Saldo  ,FechaUltimoPago, TipoCuenta,DiasVencidos,EstatusCredito
							,PagoHoy,PeriodosAtrasados,MontoInicial,FechaPrestamo,FechaCorte,FechaLimitePago , idEsquema)
		   
			SELECT	
				@clabe_corresponsalias clabe_corresponsalias,
				CI.clabe clabe_spei,
				EDO.id_mov, 
				BANCA.[dbo].FN_BANCA_OBTENER_NOMBRE_COMERCIAL(EDO.NUM_PTMO),/*MOV.Desc_prestamo,*/
				EDO.Saldo_Actual, 
				BANCA.DBO.FN_OBTENER_FECHA_ULTIMO_ABONO(EDO.Ultimo_Int_Ord,EDO.Ultimo_Int_Mor,EDO.Ultimo_Abono) FechaUltimoPago,
				3 Tipo_Cuenta
				,EDO.Dias_Vencidos,
				CASE
					WHEN EDO.Dias_Vencidos > 0 THEN 'VENCIDO'
					ELSE 'NO VENCIDO'
				END AS estado_credito,
				----
				--(coalesce((interes_moratorio_fin*1.16),0)+
				--coalesce((interes_moratorio_dia_fin*1.16),0)+
				--coalesce((interes_ordinario_vencido_fin*1.16),0)+
				--coalesce((interes_ordinario_vigente_fin*1.16),0)+
				--coalesce((interes_ordinario_dia_fin*1.16),0)+
				--coalesce((capital_vencido_fin*1.16),0)+
				--coalesce((capital_corte_fin*1.16),0)) 
				(select top 1 pago_al_corriente from #RESUMEN_PAGO ) pago_hoy,
				------
				coalesce(EDO.Periodos_Atrasados,0) periodos_atrasados,
				EDO.Monto_Inicial,
				EDO.Fecha_Ptmo,
				coalesce(@fechaCorte,'A la brevedad'), --FechaCorte
				coalesce(@fechaLimitePago,'A la brevedad') ,--FechaLimitePago
				@idEsquema
			FROM	HAPE..EDO_DE_CUENTA EDO
			INNER JOIN
				HAPE..TIPOS_DE_OPERACIONES MOV ON EDO.Id_mov = MOV.Id_mov
			--LEFT JOIN
				--#RESUMEN_PAGO RPAGO ON EDO.Id_mov = RPAGO.id_mov AND RPAGO.num_ptmo = EDO.Num_ptmo
			LEFT JOIN
				BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON EDO.Numero = BANCA.dbo.FN_BANCA_DESCIFRAR(CI.numero_socio) AND EDO.Id_mov = CI.id_mov AND EDO.Num_ptmo = CI.num_ptmo and CI.activo = 1
			WHERE	
				EDO.Numero = @numero_int
				AND EDO.Id_mov = @id_mov
				
		END

		---NIVELADOS
		IF @idEsquema = 2
		BEGIN
			
			declare @fecha1mesDespues datetime, @iva_mor money
			select @fecha1mesDespues = dateadd(mm,1,@fecha_calculo)
			
			INSERT INTO #Cuenta (ClabeCorresponsalias,ClabeSpei,IdMov,NombreCuenta  , Saldo  ,FechaUltimoPago, TipoCuenta,DiasVencidos,EstatusCredito
							,PagoHoy,PeriodosAtrasados,MontoInicial,FechaPrestamo,FechaCorte,FechaLimitePago,numeroPago, idEsquema)
			SELECT TOP 1 * FROM 
			(
				(SELECT
					@clabe_corresponsalias clabe_corresponsalias,
					TABLA.clabe clabe_spei,
					TABLA.Id_mov, 
					TABLA.Desc_prestamo,
					TABLA.Saldo_Actual, 
					TABLA.FechaUltimoPago,
					TABLA.Tipo_Cuenta,TABLA.Dias_Vencidos,TABLA.estado_credito,
					SUM(TABLA.pago_hoy) pago_hoy,
					TABLA.periodos_atrasados,TABLA.Monto_Inicial,TABLA.Fecha_Ptmo,
					TABLA.fecha_corte,TABLA.fecha_limite_pago,TABLA.Num_pago,
					@idEsquema as idEsquema
				FROM (
				SELECT 	EDO.id_mov, MOV.Desc_prestamo, EDO.Saldo_Actual, 
					BANCA.DBO.FN_OBTENER_FECHA_ULTIMO_ABONO(EDO.Ultimo_Int_Ord,EDO.Ultimo_Int_Mor,EDO.Ultimo_Abono) FechaUltimoPago,
					3 Tipo_Cuenta
					,EDO.Dias_Vencidos,
					CASE
						WHEN EDO.Dias_Vencidos > 0 THEN 'VENCIDO'
						ELSE 'NO VENCIDO'
					END AS estado_credito,
					----
					case 
						when Sum(round((DATEDIFF(day,AUTPTMOS.fecha_pago,getdate())*(EDO.Int_Mor/3000)*Capital),2,0)) > 0 then	
							Sum(round((DATEDIFF(day,AUTPTMOS.fecha_pago,getdate())*(EDO.Int_Mor/3000)*Capital),2,0)) + Sum(AUTPTMOS.Total)
						else
							Sum(AUTPTMOS.total)
					end pago_hoy,
					------
					coalesce(EDO.Periodos_Atrasados,0) periodos_atrasados,
					EDO.Monto_Inicial,
					CI.clabe, 
					EDO.Fecha_Ptmo,
					case 
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1 and AUTPTMOS.Num_pago = 1 ) then convert(varchar,AUTPTMOS.fecha_ptmo,120) 
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) <= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1) then 'A LA BREVEDAD'
						else convert(varchar,dateadd(mm,-1,dateadd(dd,1,AUTPTMOS.Fecha_pago)),120) 
					end fecha_corte,
					case 
						--when (convert(varchar,AUTPTMOS.Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1)then convert(varchar,AUTPTMOS.Fecha_pago,120) -- and Num_pago = 1 ) 
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and Id_status = 1 ) then convert(varchar,AUTPTMOS.Fecha_pago,120)
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) <= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1) then 'A LA BREVEDAD'
						else (convert(varchar,DATEADD(mm,1,AUTPTMOS.fecha_pago),120))
					end fecha_limite_pago,
					AUTPTMOS.Num_pago
				FROM	HAPE..EDO_DE_CUENTA EDO
				INNER JOIN
					HAPE..TIPOS_DE_OPERACIONES MOV ON EDO.Id_mov = MOV.Id_mov
				LEFT JOIN
					HAPE..TBL_AUTOMOTRIZ_PTMOS AUTPTMOS ON EDO.Id_mov = AUTPTMOS.id_mov AND AUTPTMOS.num_ptmo = EDO.Num_ptmo AND AUTPTMOS.Id_status=1
				LEFT JOIN
					BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON EDO.Numero = BANCA.dbo.FN_BANCA_DESCIFRAR(CI.numero_socio) AND EDO.Id_mov = CI.id_mov AND EDO.Num_ptmo = CI.num_ptmo and CI.activo = 1
				WHERE	
					EDO.Numero = @numero_int
					AND EDO.Id_mov = @id_mov
					AND(
						((convert(varchar,Fecha_pago,112) >= convert(varchar,@fecha_calculo,112)  ) and Id_status = 1 and Num_pago > 1)--pagos adelantados
						or (Id_status = 1 and Num_pago = 1 and DATEPART(mm,@fecha_calculo) = datepart(mm,Fecha_pago) and  DATEPART(YY,@fecha_calculo) = datepart(YY,Fecha_pago)) --primer pago
						or (convert(varchar,Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and convert(varchar,Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1 and Num_pago = 1 ) --primer pago
						or (convert(varchar,Fecha_pago,112) <= convert(varchar,@fecha_calculo,112) and convert(varchar,Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1 ) -- pagos atrasados 
					)
				GROUP BY	
					EDO.id_mov, MOV.Desc_prestamo, EDO.Saldo_Actual,EDO.Dias_Vencidos,EDO.Ultimo_Int_Ord,EDO.Ultimo_Int_Mor,EDO.Ultimo_Abono, EDO.CV_Diaria,
					EDO.Periodos_Atrasados,EDO.Monto_Inicial,CI.clabe,EDO.Fecha_Ptmo,AUTPTMOS.Fecha_pago,Id_status,Num_pago,AUTPTMOS.fecha_ptmo,AUTPTMOS.Num_pago
				)TABLA 
				GROUP BY 
					TABLA.Id_mov, TABLA.Desc_prestamo, TABLA.Saldo_Actual, 
					TABLA.FechaUltimoPago,
					TABLA.Tipo_Cuenta,TABLA.Dias_Vencidos,TABLA.estado_credito,TABLA.periodos_atrasados,TABLA.Monto_Inicial,
					TABLA.clabe,TABLA.Fecha_Ptmo,
					TABLA.fecha_corte,TABLA.fecha_limite_pago,TABLA.Num_pago
				)

				-------------------	TBL_HIPOTECARIO_PTMOS
				union

				(SELECT
					@clabe_corresponsalias clabe_corresponsalias,
					TABLA.clabe clabe_spei,
					TABLA.Id_mov, TABLA.Desc_prestamo, TABLA.Saldo_Actual, 
					TABLA.FechaUltimoPago,
					TABLA.Tipo_Cuenta,TABLA.Dias_Vencidos,TABLA.estado_credito,
					SUM(TABLA.pago_hoy) pago_hoy,
					TABLA.periodos_atrasados,TABLA.Monto_Inicial,TABLA.Fecha_Ptmo,
					TABLA.fecha_corte,TABLA.fecha_limite_pago,TABLA.Num_pago,
					@idEsquema as idEsquema
				FROM (
				SELECT 	EDO.id_mov, MOV.Desc_prestamo, EDO.Saldo_Actual, 
					BANCA.DBO.FN_OBTENER_FECHA_ULTIMO_ABONO(EDO.Ultimo_Int_Ord,EDO.Ultimo_Int_Mor,EDO.Ultimo_Abono) FechaUltimoPago,
					3 Tipo_Cuenta
					,EDO.Dias_Vencidos,
					CASE
						WHEN EDO.Dias_Vencidos > 0 THEN 'VENCIDO'
						ELSE 'NO VENCIDO'
					END AS estado_credito,
					----
					case 
						when Sum(round((DATEDIFF(day,AUTPTMOS.fecha_pago,getdate())*(EDO.Int_Mor/3000)*Capital),2,0)) > 0 then	
							Sum(round((DATEDIFF(day,AUTPTMOS.fecha_pago,getdate())*(EDO.Int_Mor/3000)*Capital),2,0)) + Sum(AUTPTMOS.Total)
						else
							Sum(AUTPTMOS.total)
					end pago_hoy,
					------
					coalesce(EDO.Periodos_Atrasados,0) periodos_atrasados,
					EDO.Monto_Inicial,
					CI.clabe, 
					EDO.Fecha_Ptmo,
					case 
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1 and AUTPTMOS.Num_pago = 1 ) then convert(varchar,AUTPTMOS.fecha_ptmo,120) 
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) <= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1) then 'A LA BREVEDAD'
						else convert(varchar,dateadd(mm,-1,dateadd(dd,1,AUTPTMOS.Fecha_pago)),120) 
					end fecha_corte,
					case 
						--when (convert(varchar,AUTPTMOS.Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1)then convert(varchar,AUTPTMOS.Fecha_pago,120) -- and Num_pago = 1 ) 
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and Id_status = 1 ) then convert(varchar,AUTPTMOS.Fecha_pago,120)
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) <= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1) then 'A LA BREVEDAD'
						else (convert(varchar,DATEADD(mm,1,AUTPTMOS.fecha_pago),120))
					end fecha_limite_pago,
					AUTPTMOS.Num_pago
				FROM	HAPE..EDO_DE_CUENTA EDO
				INNER JOIN
					HAPE..TIPOS_DE_OPERACIONES MOV ON EDO.Id_mov = MOV.Id_mov
				LEFT JOIN
					HAPE..TBL_HIPOTECARIO_PTMOS AUTPTMOS ON EDO.Id_mov = AUTPTMOS.id_mov AND AUTPTMOS.num_ptmo = EDO.Num_ptmo AND AUTPTMOS.Id_status=1
				LEFT JOIN
					BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON EDO.Numero = BANCA.dbo.FN_BANCA_DESCIFRAR(CI.numero_socio) AND EDO.Id_mov = CI.id_mov AND EDO.Num_ptmo = CI.num_ptmo and CI.activo = 1
				WHERE	
					EDO.Numero = @numero_int
					AND EDO.Id_mov = @id_mov
					AND(
						((convert(varchar,Fecha_pago,112) >= convert(varchar,@fecha_calculo,112)  ) and Id_status = 1 and Num_pago > 1)--pagos adelantados
						or (Id_status = 1 and Num_pago = 1 and DATEPART(mm,@fecha_calculo) = datepart(mm,Fecha_pago) and  DATEPART(YY,@fecha_calculo) = datepart(YY,Fecha_pago)) --primer pago
						or (convert(varchar,Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and convert(varchar,Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1 and Num_pago = 1 ) --primer pago
						or (convert(varchar,Fecha_pago,112) <= convert(varchar,@fecha_calculo,112) and convert(varchar,Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1 ) -- pagos atrasados 
					)
				GROUP BY	
					EDO.id_mov, MOV.Desc_prestamo, EDO.Saldo_Actual,EDO.Dias_Vencidos,EDO.Ultimo_Int_Ord,EDO.Ultimo_Int_Mor,EDO.Ultimo_Abono, EDO.CV_Diaria,
					EDO.Periodos_Atrasados,EDO.Monto_Inicial,CI.clabe,EDO.Fecha_Ptmo,AUTPTMOS.Fecha_pago,Id_status,Num_pago,AUTPTMOS.fecha_ptmo,AUTPTMOS.Num_pago
				)TABLA 
				GROUP BY 
					TABLA.Id_mov, TABLA.Desc_prestamo, TABLA.Saldo_Actual, 
					TABLA.FechaUltimoPago,
					TABLA.Tipo_Cuenta,TABLA.Dias_Vencidos,TABLA.estado_credito,TABLA.periodos_atrasados,TABLA.Monto_Inicial,
					TABLA.clabe,TABLA.Fecha_Ptmo,
					TABLA.fecha_corte,TABLA.fecha_limite_pago,TABLA.Num_pago
				)

				-------------------NIVELADOS

				union

				(SELECT
					@clabe_corresponsalias clabe_corresponsalias,
					TABLA.clabe clabe_spei,
					TABLA.Id_mov, TABLA.Desc_prestamo, TABLA.Saldo_Actual, 
					TABLA.FechaUltimoAbono,
					TABLA.Tipo_Cuenta,TABLA.Dias_Vencidos,TABLA.estado_credito,
					SUM(TABLA.pago_hoy) pago_hoy,
					TABLA.periodos_atrasados,TABLA.Monto_Inicial,TABLA.Fecha_Ptmo,
					TABLA.fecha_corte,TABLA.fecha_limite_pago,TABLA.Num_pago,
					@idEsquema as idEsquema
				FROM (
				SELECT 	EDO.id_mov, MOV.Desc_prestamo, EDO.Saldo_Actual, 
					BANCA.DBO.FN_OBTENER_FECHA_ULTIMO_ABONO(EDO.Ultimo_Int_Ord,EDO.Ultimo_Int_Mor,EDO.Ultimo_Abono) FechaUltimoAbono,
					3 Tipo_Cuenta
					,EDO.Dias_Vencidos,
					CASE
						WHEN EDO.Dias_Vencidos > 0 THEN 'VENCIDO'
						ELSE 'NO VENCIDO'
					END AS estado_credito,
					----
					case 
						when Sum(round((DATEDIFF(day,AUTPTMOS.fecha_pago,getdate())*(EDO.Int_Mor/3000)*Capital),2,0)) > 0 then	
							Sum(round((DATEDIFF(day,AUTPTMOS.fecha_pago,getdate())*(EDO.Int_Mor/3000)*Capital),2,0)) + Sum(AUTPTMOS.Total)
						else
							Sum(AUTPTMOS.total)
					end pago_hoy,
					------
					coalesce(EDO.Periodos_Atrasados,0) periodos_atrasados,
					EDO.Monto_Inicial,
					CI.clabe, 
					EDO.Fecha_Ptmo,
					case 
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1 and AUTPTMOS.Num_pago = 1 ) then convert(varchar,AUTPTMOS.fecha_ptmo,120) 
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) <= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1) then 'A LA BREVEDAD'
						else convert(varchar,dateadd(mm,-1,dateadd(dd,1,AUTPTMOS.Fecha_pago)),120) 
					end fecha_corte,
					case 
						--when (convert(varchar,AUTPTMOS.Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1)then convert(varchar,AUTPTMOS.Fecha_pago,120) -- and Num_pago = 1 ) 
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and Id_status = 1 ) then convert(varchar,AUTPTMOS.Fecha_pago,120)
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) <= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1) then 'A LA BREVEDAD'
						else (convert(varchar,DATEADD(mm,1,AUTPTMOS.fecha_pago),120))
					end fecha_limite_pago,
					AUTPTMOS.Num_pago
				FROM	HAPE..EDO_DE_CUENTA EDO
				INNER JOIN
					HAPE..TIPOS_DE_OPERACIONES MOV ON EDO.Id_mov = MOV.Id_mov
				LEFT JOIN
					HAPE..TBL_NIVELADOS_PTMOS AUTPTMOS ON EDO.Id_mov = AUTPTMOS.id_mov AND AUTPTMOS.num_ptmo = EDO.Num_ptmo AND AUTPTMOS.Id_status=1
				LEFT JOIN
					BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON EDO.Numero = BANCA.dbo.FN_BANCA_DESCIFRAR(CI.numero_socio) AND EDO.Id_mov = CI.id_mov AND EDO.Num_ptmo = CI.num_ptmo and CI.activo = 1
				WHERE	
					EDO.Numero = @numero_int
					AND EDO.Id_mov = @id_mov
					AND(
						((convert(varchar,Fecha_pago,112) >= convert(varchar,@fecha_calculo,112)  ) and Id_status = 1 and Num_pago > 1)--pagos adelantados
						or (Id_status = 1 and Num_pago = 1 and DATEPART(mm,@fecha_calculo) = datepart(mm,Fecha_pago) and  DATEPART(YY,@fecha_calculo) = datepart(YY,Fecha_pago)) --primer pago
						or (convert(varchar,Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and convert(varchar,Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1 and Num_pago = 1 ) --primer pago
						or (convert(varchar,Fecha_pago,112) <= convert(varchar,@fecha_calculo,112) and convert(varchar,Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1 ) -- pagos atrasados 
					)
				GROUP BY	
					EDO.id_mov, MOV.Desc_prestamo, EDO.Saldo_Actual,EDO.Dias_Vencidos,EDO.Ultimo_Int_Ord,EDO.Ultimo_Int_Mor,EDO.Ultimo_Abono, EDO.CV_Diaria,
					EDO.Periodos_Atrasados,EDO.Monto_Inicial,CI.clabe,EDO.Fecha_Ptmo,AUTPTMOS.Fecha_pago,Id_status,Num_pago,AUTPTMOS.fecha_ptmo,AUTPTMOS.Num_pago
				)TABLA 
				GROUP BY 
					TABLA.Id_mov, TABLA.Desc_prestamo, TABLA.Saldo_Actual, 
					TABLA.FechaUltimoAbono,
					TABLA.Tipo_Cuenta,TABLA.Dias_Vencidos,TABLA.estado_credito,TABLA.periodos_atrasados,TABLA.Monto_Inicial,
					TABLA.clabe,TABLA.Fecha_Ptmo,
					TABLA.fecha_corte,TABLA.fecha_limite_pago,TABLA.Num_pago
				)

				-------------------CREDINOMINA

				union

				(SELECT
					@clabe_corresponsalias clabe_corresponsalias,
					TABLA.clabe clabe_spei,
					TABLA.Id_mov, TABLA.Desc_prestamo, TABLA.Saldo_Actual, 
					TABLA.FechaUltimoPago,
					TABLA.Tipo_Cuenta,TABLA.Dias_Vencidos,TABLA.estado_credito,
					SUM(TABLA.pago_hoy) pago_hoy,
					TABLA.periodos_atrasados,TABLA.Monto_Inicial,TABLA.Fecha_Ptmo,
					TABLA.fecha_corte,TABLA.fecha_limite_pago,TABLA.Num_pago,
					@idEsquema as idEsquema
				FROM (
				SELECT 	EDO.id_mov, MOV.Desc_prestamo, EDO.Saldo_Actual, 
					BANCA.DBO.FN_OBTENER_FECHA_ULTIMO_ABONO(EDO.Ultimo_Int_Ord,EDO.Ultimo_Int_Mor,EDO.Ultimo_Abono) FechaUltimoPago,
					3 Tipo_Cuenta
					,EDO.Dias_Vencidos,
					CASE
						WHEN EDO.Dias_Vencidos > 0 THEN 'VENCIDO'
						ELSE 'NO VENCIDO'
					END AS estado_credito,
					----
					case 
						when Sum(round((DATEDIFF(day,AUTPTMOS.fecha_pago,getdate())*(EDO.Int_Mor/3000)*Capital),2,0)) > 0 then	
							Sum(round((DATEDIFF(day,AUTPTMOS.fecha_pago,getdate())*(EDO.Int_Mor/3000)*Capital),2,0)) + Sum(AUTPTMOS.Total)
						else
							Sum(AUTPTMOS.total)
					end pago_hoy,
					------
					coalesce(EDO.Periodos_Atrasados,0) periodos_atrasados,
					EDO.Monto_Inicial,
					CI.clabe, 
					EDO.Fecha_Ptmo,
					case 
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1 and AUTPTMOS.Num_pago = 1 ) then convert(varchar,AUTPTMOS.fecha_ptmo,120) 
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) <= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1) then 'A LA BREVEDAD'
						else convert(varchar,dateadd(mm,-1,dateadd(dd,1,AUTPTMOS.Fecha_pago)),120) 
					end fecha_corte,
					case 
						--when (convert(varchar,AUTPTMOS.Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1)then convert(varchar,AUTPTMOS.Fecha_pago,120) -- and Num_pago = 1 ) 
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and Id_status = 1 ) then convert(varchar,AUTPTMOS.Fecha_pago,120)
						when (convert(varchar,AUTPTMOS.Fecha_pago,112) <= convert(varchar,@fecha_calculo,112) and convert(varchar,AUTPTMOS.Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1) then 'A LA BREVEDAD'
						else (convert(varchar,DATEADD(mm,1,AUTPTMOS.fecha_pago),120))
					end fecha_limite_pago,
					AUTPTMOS.Num_pago
				FROM	HAPE..EDO_DE_CUENTA EDO
				INNER JOIN
					HAPE..TIPOS_DE_OPERACIONES MOV ON EDO.Id_mov = MOV.Id_mov
				LEFT JOIN
					HAPE..TBL_CREDINOMINA_PTMOS AUTPTMOS ON EDO.Id_mov = AUTPTMOS.id_mov AND AUTPTMOS.num_ptmo = EDO.Num_ptmo AND AUTPTMOS.Id_status=1
				LEFT JOIN
					BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON EDO.Numero = BANCA.dbo.FN_BANCA_DESCIFRAR(CI.numero_socio) AND EDO.Id_mov = CI.id_mov AND EDO.Num_ptmo = CI.num_ptmo and CI.activo = 1
				WHERE	
					EDO.Numero = @numero_int
					AND EDO.Id_mov = @id_mov
					AND(
						((convert(varchar,Fecha_pago,112) >= convert(varchar,@fecha_calculo,112)  ) and Id_status = 1 and Num_pago > 1)--pagos adelantados
						or (Id_status = 1 and Num_pago = 1 and DATEPART(mm,@fecha_calculo) = datepart(mm,Fecha_pago) and  DATEPART(YY,@fecha_calculo) = datepart(YY,Fecha_pago)) --primer pago
						or (convert(varchar,Fecha_pago,112) >= convert(varchar,@fecha_calculo,112) and convert(varchar,Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1 and Num_pago = 1 ) --primer pago
						or (convert(varchar,Fecha_pago,112) <= convert(varchar,@fecha_calculo,112) and convert(varchar,Fecha_pago,112) < convert(varchar,@fecha1mesDespues,112) and Id_status = 1 ) -- pagos atrasados 
					)
				GROUP BY	
					EDO.id_mov, MOV.Desc_prestamo, EDO.Saldo_Actual,EDO.Dias_Vencidos,EDO.Ultimo_Int_Ord,EDO.Ultimo_Int_Mor,EDO.Ultimo_Abono, EDO.CV_Diaria,
					EDO.Periodos_Atrasados,EDO.Monto_Inicial,CI.clabe,EDO.Fecha_Ptmo,AUTPTMOS.Fecha_pago,Id_status,Num_pago,AUTPTMOS.fecha_ptmo,AUTPTMOS.Num_pago
				)TABLA 
				GROUP BY 
					TABLA.Id_mov, TABLA.Desc_prestamo, TABLA.Saldo_Actual, 
					TABLA.FechaUltimoPago,
					TABLA.Tipo_Cuenta,TABLA.Dias_Vencidos,TABLA.estado_credito,TABLA.periodos_atrasados,TABLA.Monto_Inicial,
					TABLA.clabe,TABLA.Fecha_Ptmo,
					TABLA.fecha_corte,TABLA.fecha_limite_pago,TABLA.Num_pago
				)
			)TABLA_FIN
			ORDER BY TABLA_FIN.Num_pago 

		END
	END
	---REVOLVENTE
	ELSE IF @id_mov = 10  AND EXISTS(SELECT * FROM HAPE..TBL_REVOLVENTE_LINEAS_CREDITO WHERE NUMERO = @numero_int AND Id_Tipo_persona = @id_tipo_persona AND limite_credito > 0 )
	BEGIN
		set @idEsquema = 4

		create table #resumenSaldo(
			activa INT,
			actualizado BIT,
			nombre VARCHAR(100),
			paterno VARCHAR(100) ,
			materno VARCHAR(100),
			calle VARCHAR(100),
			numero_exterior VARCHAR(100),
			numero_interior VARCHAR(100),
			colonia VARCHAR(100),
			codigo_postal VARCHAR(100),
			municipio VARCHAR(100),
			entidad_federativa VARCHAR(100),
			id_linea INT,
			numero INT,
			id_tipo_persona INT,
			num_ptmo VARCHAR(100),
			planx VARCHAR(1),
			id_de_sucursal INT,
			saldo_actual MONEY,
			limite_credito MONEY,
			tasa_ord DECIMAL(7,2),
			tasa_mor  DECIMAL(7,2),
			CAT  DECIMAL(7,2),
			fecha_autorizacion DATETIME,
			fecha_ultimo_incremento DATETIME,
			dia_corte INT,
			dia_limite INT,
			id_estado INT,
			estado VARCHAR(20),
			disponible MONEY,
			pago_minimo MONEY,
			pago_liquidacion MONEY
		)

		INSERT #resumenSaldo exec HAPE..SP_REVOLVENTE_OBTIENE_INFO_RESUMEN_SALDOS @numero_int ,1

		print 'REVOLVENTE '
		print 'antes de insertar a cuenta '
		INSERT INTO #Cuenta (ClabeCorresponsalias,ClabeSpei,IdMov  ,NombreCuenta  , Saldo  ,FechaUltimoPago, TipoCuenta,DiasVencidos,EstatusCredito
							,PagoHoy,PeriodosAtrasados,MontoInicial,FechaPrestamo,FechaCorte,FechaLimitePago,
							MontoDisponible,LimiteCredito , idEsquema)
			
			SELECT	
				distinct
				@clabe_corresponsalias clabe_corresponsalias,
				CI.clabe clabe_spei,
				MOV.Id_mov, 
				
				BANCA.[dbo].FN_BANCA_OBTENER_NOMBRE_COMERCIAL(VWLINEAS.NUM_PTMO) Desc_prestamo,
				REVLINEAS.Saldo_Actual, 
				BANCA.DBO.FN_OBTENER_FECHA_ULTIMO_ABONO(VWLINEAS.fecha_ultimo_int_ord,VWLINEAS.fecha_ultimo_int_mor,VWLINEAS.fecha_ultimo_abono) FechaUltimoPago,--?
				3 Tipo_Cuenta,
				VWLINEAS.dias_vencidos,
				CASE
					WHEN VWLINEAS.CV_Diaria > 0 THEN 'VENCIDO'
					ELSE 'NO VENCIDO'
				END AS estado_credito,
				------
				RESUMEN.pago_minimo pago_hoy, --?verificar si es lo corrrecto
				------
				coalesce(VWLINEAS.periodos_vencidos ,0) periodos_atrasados,
				REVLINEAS.saldo_actual,
				VWLINEAS.fecha_autorizacion,
				case	
				when DAY(@fecha_calculo) < REVLINEAS.dia_corte then 
					CAST(CAST(DATEPART(YEAR,@fecha_calculo) AS varchar) + '-' + CAST(DATEPART(MONTH,@fecha_calculo) AS varchar) + '-' + CAST(REVLINEAS.dia_corte AS varchar) AS DATETIME)
				when DAY(@fecha_calculo) > REVLINEAS.dia_corte then
					CAST(CAST(DATEPART(YEAR,@fecha_calculo) AS varchar) + '-' + CAST(DATEPART(MONTH,DATEADD(MONTH,1,@fecha_calculo)) AS varchar) + '-' + CAST(REVLINEAS.dia_corte AS varchar) AS DATETIME) 
				when DAY(@fecha_calculo) = REVLINEAS.dia_corte then
					@fecha_calculo
				end fecha_corte, --FechaCorte
				case	
				when DAY(@fecha_calculo) < REVLINEAS.dia_limite then 
					CAST(CAST(DATEPART(YEAR,@fecha_calculo) AS varchar) + '-' + CAST(DATEPART(MONTH,@fecha_calculo) AS varchar) + '-' + CAST(REVLINEAS.dia_limite AS varchar) AS DATETIME)
				when DAY(@fecha_calculo) > REVLINEAS.dia_limite then
					CAST(CAST(DATEPART(YEAR,@fecha_calculo) AS varchar) + '-' + CAST(DATEPART(MONTH,DATEADD(MONTH,1,@fecha_calculo)) AS varchar) + '-' + CAST(REVLINEAS.dia_limite AS varchar) AS DATETIME) 
				when DAY(@fecha_calculo) = REVLINEAS.dia_limite then
					@fecha_calculo
				end fecha_limite_pago, --FechaLimitePago,
				RESUMEN.disponible, --MONTO_DISPONIBLE,
				VWLINEAS.limite_credito,
				@idEsquema
			FROM	HAPE..TBL_REVOLVENTE_LINEAS_CREDITO REVLINEAS
			INNER JOIN
				HAPE..TIPOS_DE_OPERACIONES MOV ON 10 = MOV.Id_mov
			INNER JOIN
				HAPE..VW_REVOLVENTE_LINEAS VWLINEAS ON VWLINEAS.id_linea = REVLINEAS.id_linea
			LEFT JOIN
				BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON REVLINEAS.Numero = BANCA.dbo.FN_BANCA_DESCIFRAR(CI.numero_socio) AND 10 = CI.id_mov AND REVLINEAS.Num_ptmo = CI.num_ptmo and CI.activo = 1
			left JOIN
				HAPE..TBL_REVOLVENTE_DISPOSICIONES DISPOCICIONES ON DISPOCICIONES.id_linea = REVLINEAS.id_linea 
			INNER JOIN
				#resumenSaldo RESUMEN ON REVLINEAS.id_linea = RESUMEN.id_linea
			WHERE	
				REVLINEAS.Numero = @numero_int

			DROP TABLE #resumenSaldo
			print 'despues de insertar a cuenta'
		---568451

	END
	ELSE IF @id_mov = 105 and (@numero_contrato is not null and @numero_contrato > 0)-- PLAZOS FIJOS
	BEGIN
		
	    IF OBJECT_ID('tempdb..#temp_DPF_detalle') IS NOT NULL
				DROP TABLE #temp_DPF_detalle
		declare
			@FechaVencimiento datetime,
			@fechaEjecucion  datetime = getdate(),
			@ultima_tasa_dpf float
			create table #temp_DPF_detalle
						(
     						estatus int,
							error_message			varchar(255) ,
							error_line				varchar(255) ,
							error_severity			varchar(255) ,
							error_procedure		varchar(255),
							id									int identity (1,1)	not null,
							fecha_mov							datetime		null,
							fecha_dpf_final						datetime		null,
							num_dpf								int				null,
							tasa_dpf							float			null,
							ultima_tasa_dpf						float			null,
							monto								float			null, 
							saldo								float			null, 
							dias								int				null,
							interes_dpf							float			null,
							folio								int				null,
							tipo_poliza							varchar(1)		null,
							numusuario							int				null,
							id_persona							int				null,
							dpf_en_garantia						varchar(1)		null,
							fecha_vencimiento					datetime		null,
							disp_por_dia_inhabil				datetime		null,
							fecha_prox_venc						datetime		null,
							diff_dias_inhabiles					int				null,
							interes_dias_inhabiles				money			null,
							interes_diario_dpf					money			null,
							isr_a_retener						money			null,
							uma									money			null,
							exencion							money			null,
							instruccion_venc	                bit             null,
							posible_cancelar					bit				default 0							
						)
	          INSERT INTO #temp_DPF_detalle(estatus ,
									error_message	,
									error_line		,
									error_severity	,
									error_procedure	,
									id				,
									fecha_mov		,
									fecha_dpf_final	,
									num_dpf			,
									tasa_dpf		,
									ultima_tasa_dpf	,
									monto			, 
									saldo			, 
									dias			,
									interes_dpf		,
									folio			,
									tipo_poliza		,
									numusuario		,
									id_persona		,
									dpf_en_garantia	,
									fecha_vencimiento	,
									disp_por_dia_inhabil,
									fecha_prox_venc		,
									diff_dias_inhabiles	,
									interes_dias_inhabiles,
									interes_diario_dpf	,
									isr_a_retener		,
									uma					,
									exencion			,
									instruccion_venc,
									posible_cancelar)

		exec HAPE..SP_DIAS_INHABILES_CONSULTA_DPF  null, @fechaEjecucion , @numero_int , @numero_contrato
		select @FechaVencimiento = fecha_vencimiento, @ultima_tasa_dpf= ultima_tasa_dpf from #temp_DPF_detalle

		
		INSERT INTO #Cuenta (Saldo , ClabeCorresponsalias,ClabeSpei,IdMov  ,NombreCuenta  , FechaApertura,NoContrato,FechaVencimiento,Plazo,Tasa,TipoCuenta)
		SELECT	
		    monto,
			'' clabe_corresponsalias,
			'' clabe_spei,
			105
			,MOV.Desc_prestamo,
			CONVERT(varchar , Fecha_Mov,103) as Fecha_Mov,
			Num_DPF,
			CONVERT(varchar , @FechaVencimiento,103) as FechaVencimiento
			,Dias, @ultima_tasa_dpf,2
		FROM	HAPE..MOVIMIENTOS
		INNER JOIN
				HAPE..TIPOS_DE_OPERACIONES MOV ON MOVIMIENTOS.id_mov = MOV.Id_mov
		WHERE	
			Numero = @numero_int
			AND Id_Tipo_persona = 1
			AND Id_tipomov = 41 
			AND Activo = 'T' 
			AND Num_DPF = @numero_contrato
			
			
		END
	ELSE
	BEGIN
		SELECT id_excepcion AS estatus , descripcion as mensaje 
		FROM CAT_BANCA_EXCEPTIONS
		WHERE id_excepcion = 319
		RETURN
	END

END
print 'id_mov->'+cast(@id_mov as varchar)
IF(@id_mov < 9) and exists (select 1 from #Cuenta)
BEGIN

		UPDATE C SET
		 C.SaldoAdelantado  = isnull(EDC.saldo_adelanto,0)
		 --C.NombreCuenta = BANCA.[dbo].FN_BANCA_OBTENER_NOMBRE_COMERCIAL(CC.NUM_PTMO)
		FROM 
		#Cuenta C  
		JOIN HAPE..EDO_DE_CUENTA EDC ON C. IdMov = EDC.Id_mov AND EDC.Numero = @NUMERO  and edc.Id_Tipo_persona = 1
		JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS CC ON CC.CUENTA = C.ClabeCorresponsalias
		WHERE EDC.Id_Tipo_persona = 1 AND EDC.Numero = @NUMERO

END

-- FIN DEL PROCEDIMIENTO

SELECT @estatus ESTATUS ,@mensaje_validacion mensaje , * FROM	#Cuenta

IF OBJECT_ID('tempdb..#Cuenta') IS NOT NULL
	DROP TABLE #Cuenta


IF OBJECT_ID('tempdb..#RESUMEN_PAGO') IS NOT NULL
	DROP TABLE #RESUMEN_PAGO

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_DOMICILIACIONES]    Script Date: 21/08/2019 04:13:57 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_OBTENER_DOMICILIACIONES]
@numeroSocio AS VARCHAR(20),
@activo bit = 1

AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int,
@numero_int int 

select @mensaje_validacion =msj ,@estatus = estatus  from  dbo.FN_BANCA_VALIDA_SOCIO(@numeroSocio,0)

  if(@mensaje_validacion is  null )
  BEGIN
  SET @numero_int = CAST(@numeroSocio as int )
		-- VALIDACIONES --
		-- FIN DE VALIDACIONES -
	IF EXISTS (SELECT 1 FROM TBL_BANCA_DOMICILIACIONES  WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int)
	BEGIN

			SELECT 200 estatus,  'OK' mensaje
			SELECT 
			P.descripcion descProducto ,
			TDO.Desc_prestamo descClabeRetiro,
			TDO1.Desc_prestamo descCuentaDeposito,
			TD.descripcion descTipoDomiciliacion,
			PP.descripcion descPeriodicidadago,
			D.id_domiciliacion,
			D.id_tipo_domiciliacion,
			D.id_producto,
			D.id_periodicidad_pago,
			D.fecha_vencimiento,
			D.monto_maximo,
			D.indefinido,
			D.dia_pago,
			D.fecha_alta,
			D.clabe_corresponsalias_retiro,
			D.clabe_corresponsalias_deposito,
			D.id_servicio,
			D.numero_referencia,
			D.alias,
			BANCA.dbo.FN_BANCA_DESCIFRAR(D.numero_socio) numero_socio,
			D.activo,
			D.folio_autorizacion,
			D.folio_cancelacion 
			FROM TBL_BANCA_DOMICILIACIONES D
			LEFT  JOIN  CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO AS P ON D.id_producto = P.id_producto AND D.id_servicio = P.id_servicios_pago
			LEFT  JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS AS CC ON CC.CUENTA = D.clabe_corresponsalias_retiro AND CC.NUMERO = BANCA.dbo.FN_BANCA_DESCIFRAR(D.NUMERO_SOCIO) 
			LEFT  JOIN HAPE..TIPOS_DE_OPERACIONES AS TDO ON TDO.Id_mov = CC.ID_MOV AND CC.NUMERO = BANCA.dbo.FN_BANCA_DESCIFRAR(D.NUMERO_SOCIO)
			LEFT  JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS AS CC1 ON CC1.CUENTA = D.clabe_corresponsalias_deposito AND CC.NUMERO = BANCA.dbo.FN_BANCA_DESCIFRAR(D.NUMERO_SOCIO) 
			LEFT  JOIN HAPE..TIPOS_DE_OPERACIONES AS TDO1 ON TDO1.Id_mov = CC1.ID_MOV AND CC.NUMERO = BANCA.dbo.FN_BANCA_DESCIFRAR(D.NUMERO_SOCIO)
			INNER JOIN CAT_BANCA_TIPOS_DOMICILIACION AS TD ON TD.id_tipo_domiciliacion = D.id_tipo_domiciliacion
			INNER JOIN CAT_BANCA_PERIODICIDAD_PAGO  AS PP ON PP.id_periodicidad_pago = D.id_periodicidad_pago
			WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(D.numero_socio) = @numero_int and d.activo = @activo
  END
  ELSE
  BEGIN
		SELECT id_excepcion AS estatus , descripcion as mensaje 
		FROM CAT_BANCA_EXCEPTIONS
		WHERE id_excepcion = 372
  END
  END
  ELSE
	  SELECT 300 AS estatus , @mensaje_validacion mensaje
end try
begin catch
	select -1 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_MOVIMIENTOS_CUENTA]    Script Date: 18/03/2020 04:55:38 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_OBTENER_MOVIMIENTOS_CUENTA]
@numero AS VARCHAR(20),
@clabeCorresponsalias varchar(20),
@periodo bit,
@fecha_calculo datetime = null
AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int,
@FECHAINICIO DATETIME,
@FECHAFIN DATETIME,
@CONTADOR INT, 
@id_mov int 

declare @ultimaCuentaSocio int
select top 1 @ultimaCuentaSocio =id_cuenta from TBL_BANCA_CUENTAS_INTERBANCARIAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int order by fecha_alta desc

set @fecha_calculo = COALESCE(@fecha_calculo,getdate())
select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@numero,1)
set @numero_int = CAST(@numero as int )

  if(@mensaje_validacion is null)
  BEGIN

	 -- SE VALIDA QUE EXISTA  ESA CLABE CORRESPONSALIAS
	 IF EXISTS (SELECT 1  FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS  WHERE NUMERO = @numero_int  AND CUENTA = @clabeCorresponsalias)
	 BEGIN
		 SELECT @id_mov = ID_MOV  FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS  WHERE NUMERO = @numero_int  AND CUENTA = @clabeCorresponsalias 
	 END
	 ELSE
	 BEGIN
			SELECT id_excepcion AS estatus , descripcion as mensaje 
			FROM CAT_BANCA_EXCEPTIONS
			WHERE id_excepcion = 356
		RETURN
	 END

	SET @FECHAINICIO  = DATEADD(MONTH,-1,@fecha_calculo)
	SET @FECHAFIN  = @fecha_calculo

	IF @periodo = 0
	begin
		SET @FECHAINICIO = DATEADD(MONTH,-2,@FECHAINICIO)
		SET @FECHAFIN  = DATEADD(MONTH,-2,@fecha_calculo)
		SET @FECHAFIN = DATEADD (dd, -1, DATEADD(mm, DATEDIFF(mm, 0, @FECHAFIN) + 1, 0))
	end 
	-- set a inicio de mes 
	SELECT @FECHAINICIO =  DATEADD(mm, DATEDIFF(mm, 0, @FECHAINICIO), 0)
	print '@FECHAINICIO: '+ cast(@FECHAINICIO as varchar(10))
	print '@FECHAFIN: ' +cast(@FECHAFIN as varchar(10))

	SELECT 200 estatus,
	coalesce(m.Monto,0) monto,
	coalesce(m.Saldo,0) saldo,
	replace(t.Descripcion,'#','') + case when m.id_tipomov in (41, 341, 120, 121, 122, 123, 124, 125, 126, 127, 128,88,89,512,513
	/*
	,1166-- Dep�sito a DEBITO CMV por Transferencia SPEI
	,1167--	Dep�sito a DEBITO CMV por operaci�n rechazada SPEI
	,1169--	Retiro de DEBITO CMV por Transferencia SPEI
	,1184--	Dep�sito a AHORRO CMV por operaci�n rechazada de Pago de Servicio
	,1186--	Retiro de AHORRO CMV por Pago de Servicio
	,1187--	Dep�sito a INVERDIN�MICA CMV por operaci�n rechazada de Pago de Servicio
	,1189--	Retiro de INVERDIN�MICA CMV por Pago de Servicio
	,1190--	Dep�sito a DEBITO CMV por operaci�n rechazada de Pago de Servicio
	,1192--	Retiro de DEBITO CMV por Pago de Servicio
	*/
	) 
										then ' #' + CAST(m.Num_DPF as varchar) 
										else ''
										end Descripcion,
	BANCA.DBO.FN_BANCA_VALIDA_FECHA_DEFAULT(m.Fecha_Mov) Fecha_Mov ,
	case 
	when t.Debe_haber = 'H' then '+'
	when t.Debe_haber = 'D' then '-'
	end Debe_haber,
	isnull(CI.clabe,'') as clabeInterbancaria,
	t.Id_tipomov
	FROM HAPE..MOVIMIENTOS m 
	inner join HAPE..TIPO_MOV t on m.Id_tipomov = t.Id_tipomov
	LEFT JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS  CC ON CC.ID_MOV = @id_mov AND CC.NUMERO = @numero AND CC.CUENTA  = @clabeCorresponsalias
	LEFT JOIN TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON CI.id_mov = @id_mov AND ci.id_cuenta = @ultimaCuentaSocio
	WHERE 
	CONVERT(varchar,Fecha_Mov,112) BETWEEN CONVERT(VARCHAR,@FECHAINICIO,112) AND CONVERT(VARCHAR,@FECHAFIN,112)
	AND M.Numero = @numero_int AND m.id_mov = @id_mov
	AND m.Activo = 'T' ORDER BY m.Fecha_Mov asc

	/*IMPORTANTE SE COMENTARON LA SIGUINETES LINEAS DEBIDO A QUE CAMBIO EL PROCESO
	DE OBTENER LOS MOVIMIENTOS*/
	-- -- si el idmov es una de sus cuentas de haberes  todo se obtiene de movimientos
	--IF(@id_mov IN (100,103,112))
	--BEGIN -- SI ES UNA CUENTA DE HABER
	--	 SELECT 200 estatus,
	--	 coalesce(m.Monto,0) monto,
	--	 coalesce(m.Saldo,0) saldo,
	--	 replace(t.Descripcion,'#','') + case when m.id_tipomov in (41, 341, 120, 121, 122, 123, 124, 125, 126, 127, 128,88,89,512,513) 
	--					                           then ' #' + CAST(m.Num_DPF as varchar) 
	--											   else ''
	--											   end Descripcion,
	--	 BANCA.DBO.FN_BANCA_VALIDA_FECHA_DEFAULT(m.Fecha_Mov) Fecha_Mov ,
	--	 case 
	--		when t.Debe_haber = 'H' then '+'
	--		when t.Debe_haber = 'D' then '-'
	--	 end Debe_haber,
	--	 isnull(CI.clabe,'') as clabeInterbancaria,
	--	 t.Id_tipomov
	--	 FROM HAPE..MOVIMIENTOS m 
	--	 inner join HAPE..TIPO_MOV t on m.Id_tipomov = t.Id_tipomov
	--	 LEFT JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS  CC ON CC.ID_MOV = @id_mov AND CC.NUMERO = @numero AND CC.CUENTA  = @clabeCorresponsalias
	--	 LEFT JOIN TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON CI.id_mov = @id_mov AND CI.numero_socio = @numero
	--	 WHERE 
	--	 CONVERT(varchar,Fecha_Mov,112) BETWEEN CONVERT(VARCHAR,@FECHAINICIO,112) AND CONVERT(VARCHAR,@FECHAFIN,112)
	--	 AND M.Numero = @numero_int AND m.id_mov = @id_mov
	--	 AND m.Activo = 'T' ORDER BY m.Fecha_Mov DESC
	--END
	----SI ES UN PRESTAMO DECRECIENTE
	--ELSE IF EXISTS (SELECT * FROM HAPE..TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES WHERE numero = @numero_int AND id_mov = @id_mov)
	--BEGIN
	--	/*DECLARE
		
	--	@NUMCORTE INT 
	
	--	SELECT @NUMCORTE =  MAX(num_corte) FROM HAPE..TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES WHERE numero = @numero_int AND id_mov = @id_mov
	--	AND  CONVERT(varchar,fecha_fin,112) <  CONVERT(varchar,@fecha_calculo,112) AND version_calendario = (SELECT MAX(version_calendario) FROM HAPE..TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES WHERE numero = @numero_int AND id_mov = @id_mov)
		
	--	SELECT @FECHAINICIO = fecha_inicio, @FECHAFIN = fecha_fin FROM HAPE..TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES
	--	WHERE numero = @numero_int AND id_mov = @id_mov AND num_corte = @NUMCORTE
	--		  AND version_calendario = (SELECT MAX(version_calendario) FROM HAPE..TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES WHERE numero = @numero_int AND id_mov = @id_mov)
		
	--	set @FECHAINICIO = DATEADD(DAY, -(DAY(@FECHAFIN)),@FECHAFIN)

	--	IF @periodo = 0
	--		SET @FECHAINICIO = DATEADD(MONTH,-3,@FECHAINICIO)
	--	*/

	--	 SELECT 200 estatus,
	--	 coalesce(m.Monto,0) monto,
	--	 coalesce(m.Saldo,0) saldo,
	--	 t.Descripcion,BANCA.DBO.FN_BANCA_VALIDA_FECHA_DEFAULT(m.Fecha_Mov) Fecha_Mov ,
	--	 case 
	--		when t.Debe_haber = 'H' then '+'
	--		when t.Debe_haber = 'D' then '-'
	--	 end Debe_haber,
	--	 isnull(CI.clabe,'') as clabeInterbancaria
	--	 FROM HAPE..MOVIMIENTOS m 
	--	 inner join HAPE..TIPO_MOV t on m.Id_tipomov = t.Id_tipomov
	--	 LEFT JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS  CC ON CC.ID_MOV = @id_mov AND CC.NUMERO = @numero AND CC.CUENTA  = @clabeCorresponsalias
	--	 LEFT JOIN TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON CI.id_mov = @id_mov AND CI.numero_socio = @numero
	--	 WHERE 
	--	 CONVERT(varchar,Fecha_Mov,112) BETWEEN CONVERT(VARCHAR,@FECHAINICIO,112) AND CONVERT(VARCHAR,@FECHAFIN,112)
	--	 AND M.Numero = @numero_int AND m.id_mov = @id_mov
	--	 AND m.Activo = 'T' ORDER BY m.Fecha_Mov DESC
		
	--END
	----SI ES UN PRESTAMO AUTOMOTRIZ
	--ELSE IF EXISTS (SELECT * FROM HAPE..TBL_AUTOMOTRIZ_PTMOS WHERE Numero = @numero_int AND Id_mov = @id_mov)
	--BEGIN
	--    /*
	--	SELECT  @CONTADOR = MAX(Contador) FROM HAPE..TBL_AUTOMOTRIZ_PTMOS WHERE Numero = @numero_int AND Id_mov = @id_mov AND CONVERT(VARCHAR,Fecha_pago,112) < CONVERT(VARCHAR,@fecha_calculo,112)
		
	--	SELECT @FECHAFIN = Fecha_pago FROM HAPE..TBL_AUTOMOTRIZ_PTMOS WHERE Numero = @numero_int AND Id_mov = @id_mov AND Contador = @CONTADOR
		
	--	SET @FECHAINICIO = DATEADD(DAY, -(DAY(@FECHAFIN)),@FECHAFIN)
		
	--	IF @periodo = 0
	--		SET @FECHAINICIO = DATEADD(MONTH,-3,@FECHAINICIO)
	--	*/

	--	SELECT 200 estatus,
	--		coalesce(m.Monto,0) monto,
	--		coalesce(m.Saldo,0) saldo,
	--		t.Descripcion,BANCA.DBO.FN_BANCA_VALIDA_FECHA_DEFAULT(m.Fecha_Mov) Fecha_Mov ,
	--		case 
	--			when t.Debe_haber = 'H' then '+'
	--			when t.Debe_haber = 'D' then '-'
	--		 end Debe_haber,
	--		isnull(CI.clabe,'') as clabeInterbancaria
	--	FROM HAPE..MOVIMIENTOS m 
	--	inner join HAPE..TIPO_MOV t on m.Id_tipomov = t.Id_tipomov
	--	LEFT JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS  CC ON CC.ID_MOV = @id_mov AND CC.NUMERO = @numero AND CC.CUENTA  = @clabeCorresponsalias
	--	LEFT JOIN TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON CI.id_mov = @id_mov AND CI.numero_socio = @numero
	--	WHERE  
	--		CONVERT(varchar,Fecha_Mov,112) BETWEEN CONVERT(VARCHAR,@FECHAINICIO,112) AND CONVERT(VARCHAR,@FECHAFIN,112)
	--		AND M.Numero = @numero_int AND m.id_mov = @id_mov
	--		AND m.Activo = 'T' ORDER BY m.Fecha_Mov DESC
	--END
	---- SI ES UN PRESTAMO HIPOTECARIO
	--ELSE IF EXISTS (SELECT * FROM HAPE..TBL_HIPOTECARIO_PTMOS WHERE Numero = @numero_int AND Id_mov = @id_mov)
	--BEGIN
	    
	--	/*
	--	SELECT  @CONTADOR = MAX(Contador) FROM HAPE..TBL_HIPOTECARIO_PTMOS WHERE Numero = @numero_int AND Id_mov = @id_mov AND CONVERT(VARCHAR,Fecha_pago,112) < CONVERT(VARCHAR,@fecha_calculo,112)
		
	--	SELECT @FECHAFIN = Fecha_pago FROM HAPE..TBL_HIPOTECARIO_PTMOS WHERE Numero = @numero_int AND Id_mov = @id_mov AND Contador = @CONTADOR
		
	--	set @FECHAINICIO = DATEADD(DAY, -(DAY(@FECHAFIN)),@FECHAFIN)
		
	--	IF @periodo = 0
	--		SET @FECHAINICIO = DATEADD(MONTH,-3,@FECHAINICIO)
	--	*/
		
	--	SELECT 200 estatus,
	--	coalesce(m.Monto,0) monto,
	--	coalesce(m.Saldo,0) saldo,
	--	t.Descripcion,BANCA.DBO.FN_BANCA_VALIDA_FECHA_DEFAULT(m.Fecha_Mov) Fecha_Mov,
	--	case 
	--		when t.Debe_haber = 'H' then '+'
	--		when t.Debe_haber = 'D' then '-'
	--	 end Debe_haber,
	--	isnull(CI.clabe,'') as clabeInterbancaria
	--	FROM HAPE..MOVIMIENTOS m 
	--	inner join HAPE..TIPO_MOV t on m.Id_tipomov = t.Id_tipomov
	--	LEFT JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS  CC ON CC.ID_MOV = @id_mov AND CC.NUMERO = @numero AND CC.CUENTA  = @clabeCorresponsalias
	--	LEFT JOIN TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON CI.id_mov = @id_mov AND CI.numero_socio = @numero
	--	WHERE 
	--	 CONVERT(varchar,Fecha_Mov,112) BETWEEN CONVERT(VARCHAR,@FECHAINICIO,112) AND CONVERT(VARCHAR,@FECHAFIN,112)
	--	 AND M.Numero = @numero_int AND m.id_mov = @id_mov
	--	 AND m.Activo = 'T' ORDER BY m.Fecha_Mov DESC
	--END
	---- SI ES UN PRESTAMO NIVELADO
	--ELSE IF EXISTS(SELECT * FROM HAPE..TBL_NIVELADOS_PTMOS WHERE Numero = @numero_int AND Id_mov = @id_mov)
	--BEGIN
	--   /*
	--	SELECT  @CONTADOR = MAX(Contador) FROM HAPE..TBL_NIVELADOS_PTMOS WHERE Numero = @numero_int AND Id_mov = @id_mov AND CONVERT(VARCHAR,Fecha_pago,112) < CONVERT(VARCHAR,@fecha_calculo,112)

	--	SELECT @FECHAFIN = Fecha_pago FROM HAPE..TBL_NIVELADOS_PTMOS WHERE Numero = @numero_int AND Id_mov = @id_mov AND Contador = @CONTADOR

	--	set @FECHAINICIO = DATEADD(DAY, -(DAY(@FECHAFIN)),@FECHAFIN)
		
	--	IF @periodo = 0
	--		SET @FECHAINICIO = DATEADD(MONTH,-3,@FECHAINICIO)
	--	*/

	--	SELECT 200 estatus,
	--	coalesce(m.Monto,0) monto,
	--	coalesce(m.Saldo,0) saldo,
	--	t.Descripcion,BANCA.DBO.FN_BANCA_VALIDA_FECHA_DEFAULT(m.Fecha_Mov) Fecha_Mov ,
	--	case 
	--		when t.Debe_haber = 'H' then '+'
	--		when t.Debe_haber = 'D' then '-'
	--	 end Debe_haber,
	--	isnull(CI.clabe,'') as clabeInterbancaria
	--	FROM HAPE..MOVIMIENTOS m 
	--	Inner join HAPE..TIPO_MOV t on m.Id_tipomov = t.Id_tipomov
	--	LEFT JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS  CC ON CC.ID_MOV = @id_mov AND CC.NUMERO = @numero AND CC.CUENTA  = @clabeCorresponsalias
	--	LEFT JOIN TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON CI.id_mov = @id_mov AND CI.numero_socio = @numero
	--	WHERE  
	--	 CONVERT(varchar,Fecha_Mov,112) BETWEEN CONVERT(VARCHAR,@FECHAINICIO,112) AND CONVERT(VARCHAR,@FECHAFIN,112)
	--	 AND m.Numero = @numero_int AND m.id_mov = @id_mov
	--	 AND m.Activo = 'T' ORDER BY m.Fecha_Mov DESC
	--END
	---- SI ES UN CREDINOMINA
	--ELSE IF EXISTS(SELECT * FROM HAPE..TBL_CREDINOMINA_PTMOS_CAJAS WHERE Numero = @numero_int AND Id_mov = @id_mov)
	--BEGIN
	--	/*
	--	SELECT  @CONTADOR = MAX(Contador) FROM HAPE..TBL_CREDINOMINA_PTMOS_CAJAS WHERE Numero = @numero_int AND Id_mov = @id_mov AND CONVERT(VARCHAR,Fecha_pago,112) < CONVERT(VARCHAR,@fecha_calculo,112)
		
	--	SELECT @FECHAFIN = Fecha_pago FROM HAPE..TBL_CREDINOMINA_PTMOS_CAJAS WHERE Numero = @numero_int AND Id_mov = @id_mov AND Contador = @CONTADOR
		
	--	set @FECHAINICIO = DATEADD(DAY, -(DAY(@FECHAFIN)),@FECHAFIN)
		
	--	IF @periodo = 0
	--		SET @FECHAINICIO = DATEADD(MONTH,-3,@FECHAINICIO)
	--	*/
	--	SELECT 200 estatus,
	--	coalesce(m.Monto,0) monto,
	--	coalesce(m.Saldo,0) saldo,
	--	t.Descripcion,BANCA.DBO.FN_BANCA_VALIDA_FECHA_DEFAULT(m.Fecha_Mov) Fecha_Mov ,
	--	case 
	--		when t.Debe_haber = 'H' then '+'
	--		when t.Debe_haber = 'D' then '-'
	--	 end Debe_haber,
	--	isnull(CI.clabe,'') as clabeInterbancaria
	--	FROM HAPE..MOVIMIENTOS m 
	--	inner join HAPE..TIPO_MOV t on m.Id_tipomov = t.Id_tipomov
	--	LEFT JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS  CC ON CC.ID_MOV = @id_mov AND CC.NUMERO = @numero AND CC.CUENTA  = @clabeCorresponsalias
	--	LEFT JOIN TBL_BANCA_CUENTAS_INTERBANCARIAS CI ON CI.id_mov = @id_mov AND CI.numero_socio = @numero
	--	WHERE 
	--	 CONVERT(varchar,Fecha_Mov,112)BETWEEN CONVERT(VARCHAR,@FECHAINICIO,112) AND CONVERT(VARCHAR,@FECHAFIN,112)
	--	 AND m.Numero = @numero_int AND m.id_mov = @id_mov
	--	 AND m.Activo = 'T' ORDER BY m.Fecha_Mov DESC
	--END
	--ELSE
	--BEGIN
	--	SELECT id_excepcion AS estatus , descripcion as mensaje 
	--	FROM CAT_BANCA_EXCEPTIONS
	--	WHERE id_excepcion = 338
	--END
  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje
end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_NOTIFICACION]    Script Date: 18/03/2020 05:31:11 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez
UsuarioRed		pegc837648
Fecha			20181107
Objetivo		Mostrar el cuerpo de las notificaiones 
Proyecto		Administrador de banca electr�nica
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_OBTENER_NOTIFICACION]
	
		-- par�metros
		@numeroSocio bigint,
		@id_tipo_bitacora int,
	    @id_tipo_notificacion int = null,
		@noCel varchar(10) = null,
		@correo varchar(500) =null,
		@idMov int =null,
		@numDPF int =  null,
		@ticket_banca int = null,
		@fecha_compromiso datetime = null,
		@medio_reporte varchar(200) = null,
		@fecha_apertura_reporte datetime = null,
		@IdServicioSocio bigint =  null
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''

				declare @ultimaCuentaSocio int
				select top 1 @ultimaCuentaSocio =id_cuenta from TBL_BANCA_CUENTAS_INTERBANCARIAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio order by fecha_alta desc

			end -- inicio
			
			BEGIN -- validaciones
			
				IF (@id_tipo_notificacion is null)
				BEGIN
					
					IF exists (SELECT 1 FROM  hape..TBL_CONTRATOS_HABERES WHERE numero =@numeroSocio and id_tipo_contrato = 3)
					BEGIN
						SELECT @id_tipo_notificacion = id_tipo_notificacion FROM  hape..TBL_CONTRATOS_HABERES WHERE numero =@numeroSocio and id_tipo_contrato = 3
					END
					ELSE
					BEGIN
						SELECT 'El socio no tiene definido un medio de notificaci�n' mensaje , '-1' estatus
						return
					END
				END

				if ((@ticket_banca is not null or @ticket_banca>0) and @id_tipo_bitacora in (63))
				begin
					update hape..TBL_UNE_REPORTE set fecha_compromiso_reporte = @fecha_compromiso where folio_banca = @ticket_banca
				end

			END -- validaciones
					
			IF OBJECT_ID('tempdb..#notificaciones') IS NOT NULL
			DROP TABLE #notificaciones

			create table #notificaciones
			(
				idTipoNotificacion int , 
				celular varchar(10),
				correo varchar(500),
				cuerpo varchar(max),
				asunto varchar(500),
				ordenby int ,
				
			)

			IF OBJECT_ID('tempdb..#notificaciones_sms') IS NOT NULL
			DROP TABLE #notificaciones_sms

			create table #notificaciones_sms
			(
			    id int identity(1,1),
				idTipoBitacora int,
				cuerpo varchar(max),
				idMov int,
				importeCuentaRetiro money,
				cuentaRetiro varchar(500),
				cuentaRetiroMascara varchar(500),
				cuentaRetiroCorreo varchar(500)
			)

			declare 
				@nota VARCHAR(max), 
				@folio  bigint  = null, 
				@fecha varchar(10) ,
				@hora varchar (11),
				@importe money,
				@cuentaOrigen varchar(500),
				@cuentaDestino varchar(500),
				@clabeOrigenMascara varchar(500),
				@clabeDestinoMascara varchar(500),
				@operacion varchar(500),
				@nombreSocio varchar(1000),
				@descPrestamo Varchar(1000),
				@link varchar(max) = '',
				@esProgramado char(1)='0',
				@nombreComercial varchar(500),
				@numPtmo varchar(20),
				@idEstatusTransferencia  int,
				@claveRastreo varchar(500),
				@descServicio varchar(1000),
				@descripcionDevolucion varchar(1000)
				
			    -- OBTENEMOS LOS DATOS GENERALES DE LA NOTIFICACION
				if (@numDPF is null)
				begin
					SELECT TOP 1 
						@folio = COALESCE(id_banca_folio, id_bitacora) ,
						@fecha = CONVERT(varchar , fecha_alta,103) ,
						@hora =  RIGHT(CONVERT(VARCHAR,fecha_alta, 22), 11) ,
						@operacion  = b.descripcion
										
					FROM 
						TBL_BANCA_BITACORA_OPERACIONES  BO JOIN
						CAT_BANCA_TIPOS_BITACORA B ON BO.id_tipo_bitacora = B.id_tipo_bitacora
					WHERE 
						numero_socio = @numeroSocio and b.id_tipo_bitacora = @id_tipo_bitacora order by fecha_alta desc

				end
				else-- ESTE CODIGO LO USA EL ROBOT QUE ENVIA LAS CONSTANCIAS DE DPF ES UN ROBOT QUE DESARROLLO JESSY
				begin
					print'num dpf'+cast(@numDPF as varchar)

					SELECT TOP 1 
							@folio = COALESCE(id_banca_folio, id_bitacora) ,
							@fecha = CONVERT(varchar , BO.fecha_alta,103) ,
							@hora =  FORMAT(CONVERT(datetime, BO.fecha_alta), 'hh:mm:ss tt') ,
							@operacion  = b.descripcion
										
						FROM 
							TBL_BANCA_BITACORA_OPERACIONES  BO JOIN
							CAT_BANCA_TIPOS_BITACORA B ON BO.id_tipo_bitacora = B.id_tipo_bitacora JOIN 
							HAPE..MOVIMIENTOS M ON M.Activo ='T' 
							AND M.Id_tipomov = 41 
							AND M.Num_DPF = @numDPF 
							AND M.id_origen in(3,4)
							AND M.Folio = BO.id_banca_folio
							
						WHERE 
							numero_socio = @numeroSocio 
							and b.id_tipo_bitacora = @id_tipo_bitacora 
							AND M.Num_DPF = @numDPF 
							AND M.Id_tipomov = 41 
							AND M.Numero = @numeroSocio
							order by BO.fecha_alta desc
				end



				print 'FOLIO:' + cast(@folio as varchar)

				--OBTENEMOS EL NOMRBE DE LA PERSONA PARA LOS CORREOS
				SELECT 
					@nombreSocio = ISNULL(Nombre_s,'')+' '+ISNULL(Apellido_Paterno,'')+' '+ISNULL(Apellido_Materno,''),
					@noCel = case when  @noCel  is null or @noCel = '' then Tel_Celular else @noCel end,
					@correo = case when  @correo  is null or  @correo =''  then Mail else @correo end 
				FROM HAPE..PERSONA 
				WHERE Numero =@numeroSocio and id_tipo_persona = 1
			


			--1	SMS,--2	Correo electr�nico,--3	Ambos medios

			if(@folio is not null or @folio < > '')
				BEGIN
				      -- PREGUNTAMOS SI ES UN DEPOSITO DE PLAZO FIJO ENTONCES OBTENEMOS EL NUMDPF
					  IF (@id_tipo_bitacora = 19)
					  BEGIN
						  SELECT 
								@numDPF = Num_DPF,
								@importe = ISNULL(Monto,'0')
						  FROM HAPE..MOVIMIENTOS 
						  WHERE Folio = @folio AND Numero = @numeroSocio AND Activo ='T' AND Id_tipomov = 41
					  END

					   -- PREGUNTAMOS SI ES UNA CANCELACION DE  DEPOSITO DE PLAZO FIJO ENTONCES OBTENEMOS EL NUMDPF Y EL IMPORTE
					  IF (@id_tipo_bitacora = 20)
					  BEGIN
						  SELECT 
								@numDPF = Num_DPF,
								@importe = ISNULL(Monto,'0')
						  FROM HAPE..MOVIMIENTOS 
						  WHERE Folio = @folio AND Numero = @numeroSocio AND Activo ='T' AND Id_tipomov = 341
					  END

					  -- PREGUNTAMOS SI ES UN  PAGO A PRESTAMO OBTENEMOS EL MONTO DEL PAGO Y LA DESCRIPCION DEL PRODUCTO
					  IF (@id_tipo_bitacora = 23)
					  BEGIN
						  SELECT 
								@numDPF = Num_DPF,
								@importe = ISNULL(Monto,'0')
						  FROM HAPE..MOVIMIENTOS 
						  WHERE Folio = @folio AND 
						  Numero = @numeroSocio
						  AND Activo ='T' 
						  and id_origen in(3,4)
					  END

					  -- OBTENER CUENTA ORIGEN Y DESTINO PARA TRANSFERENCIAS
					  /*
						  15	transferencia realizada |entre cuentras propias
						  16	transferencia realizada |cuentas de misma instituci�n (entre socios)
						  23	pago realizado|Pago a Prestamo|Entre cuentas propias
						  50	pago realizado|Pago a Prestamo|cuentas mismo banco (entre socios)
						  51	Retiro de Inverdinamica 
						  52	Retiro de Ahorro 
						  53	Retiro de D�bito 
						  19	dep�sito de Inverplus CMV
						  24	Pago programado|Pago a Pr�stamo
						  85	Transferencia Programada | cuentas misma instituci�n (entre socios)
                          70	Transferencia Programada | Entre cuentas propias
					  */
					  IF (@id_tipo_bitacora IN (15,16,23,50,24,70,85,86))
					  BEGIN
							
							SELECT 
								@cuentaOrigen =  TDO.Desc_prestamo,
								@cuentaDestino = TDOD.Desc_prestamo,
								@clabeOrigenMascara =  SUBSTRING(TI.clave_corresponsalias_origen,7,3)+'****'+RIGHT(TI.clave_corresponsalias_origen,4),
								@clabeDestinoMascara = SUBSTRING(TI.clave_corresponsalias_destino,7,3)+'****'+RIGHT(TI.clave_corresponsalias_destino,4),
								@importe = ISNULL(TI.monto,'0'),
								@esProgramado = programada,
								@fecha = isnull(CONVERT(varchar , TI.fecha_programada,103) , CONVERT(varchar , TI.fecha_transferencia_realizada,103)) ,
								--@hora =  isnull(FORMAT(CONVERT(datetime, TI.fecha_programada), 'hh:mm:ss tt') ,FORMAT(CONVERT(datetime, TI.fecha_transferencia_realizada), 'hh:mm:ss tt')  ) ,
								@hora = ISNULL(RIGHT(CONVERT(VARCHAR,TI.fecha_programada, 22), 11),RIGHT(CONVERT(VARCHAR,TI.fecha_transferencia_realizada, 22), 11) ),
								@numPtmo = c1.NUM_PTMO,
								@idEstatusTransferencia = isnull(TI.id_estatus_transferencia,0)

						    FROM TBL_BANCA_TRANSFERENCIAS_INTERNAS TI JOIN
							HAPE..TBL_CORRESPONSALIAS_CUENTAS  C  ON TI.clave_corresponsalias_origen = C.CUENTA and BANCA.dbo.FN_BANCA_DESCIFRAR(TI.numero_socio) = @numeroSocio JOIN
							HAPE..TBL_CORRESPONSALIAS_CUENTAS  C1  ON TI.clave_corresponsalias_destino = C1.CUENTA JOIN
							HAPE..TIPOS_DE_OPERACIONES TDO ON TDO.ID_MOV  = C.ID_MOV JOIN
							HAPE..TIPOS_DE_OPERACIONES TDOD ON TDOD.ID_MOV  = C1.ID_MOV
							WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(TI.numero_socio) = @numeroSocio AND id_banca_folio = @folio

					  END
					   --  SI ES UN SPEI ENVIADO
					  if(@id_tipo_bitacora in (92,17,88, 96))
					  BEGIN
					      SELECT 
						        @claveRastreo = TI.clave_rastreo,
								@cuentaOrigen = CASE WHEN @id_tipo_bitacora = 93 THEN  TDO.Desc_prestamo ELSE ' ' END,
								@cuentaDestino =  CASE WHEN @id_tipo_bitacora = 92 THEN  TDO.Desc_prestamo ELSE ' ' END,
								@clabeOrigenMascara =   SUBSTRING(TI.clabe_spei_origen,7,3)+'****'+RIGHT(TI.clabe_spei_origen,4) ,
								@clabeDestinoMascara =  SUBSTRING(TI.clabe_spei_destino,7,3)+'****'+RIGHT(TI.clabe_spei_destino,4) ,
								@importe = ISNULL(TI.monto,'0'),
								@esProgramado = programado,
								@fecha = isnull(CONVERT(varchar , TI.fecha_programada,103) , CONVERT(varchar , TI.fecha_transferencia_realizada,103)) ,
								@hora= ISNULL(RIGHT(CONVERT(VARCHAR,TI.fecha_programada, 22), 11),RIGHT(CONVERT(VARCHAR,TI.fecha_transferencia_realizada, 22), 11) ),
								@idEstatusTransferencia = isnull(TI.id_estatus_transferencia,0)

						    FROM TBL_BANCA_TRANSFERENCIAS_EXTERNAS TI LEFT JOIN
							TBL_BANCA_CUENTAS_INTERBANCARIAS  C  ON TI.clabe_spei_destino = C.clabe and c.id_cuenta = @ultimaCuentaSocio  LEFT JOIN
							HAPE..TIPOS_DE_OPERACIONES TDO ON TDO.ID_MOV  = C.ID_MOV 
							WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(TI.numero_socio) = @numeroSocio AND id_banca_folio = @folio
						 
					  END

					   --  SI ES UN SPEI RECIBIDO
					  if(@id_tipo_bitacora in (92))
					  BEGIN
					      SELECT 
						        @claveRastreo = TI.clave_rastreo,
								@cuentaOrigen = CASE WHEN @id_tipo_bitacora = 93 THEN  TDO.Desc_prestamo ELSE ' ' END,
								@cuentaDestino =  CASE WHEN @id_tipo_bitacora = 92 THEN  TDO.Desc_prestamo ELSE ' ' END,
								@clabeOrigenMascara =   SUBSTRING(TI.cuenta_ordenante,7,3)+'****'+RIGHT(TI.cuenta_ordenante,4) ,
								@clabeDestinoMascara =  SUBSTRING(TI.cuenta_beneficiario,7,3)+'****'+RIGHT(TI.cuenta_beneficiario,4) ,
								@importe = ISNULL(TI.monto,'0'),
								@idEstatusTransferencia = isnull(TI.id_estatus_transferencia,0)

						    FROM TBL_BANCA_TRANSFERENCIAS_EXTERNAS_RECIBIDAS TI LEFT JOIN
							TBL_BANCA_CUENTAS_INTERBANCARIAS  C  ON TI.cuenta_beneficiario = C.clabe and c.id_cuenta = @ultimaCuentaSocio  LEFT JOIN
							HAPE..TIPOS_DE_OPERACIONES TDO ON TDO.ID_MOV  = C.ID_MOV 
							WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(TI.numero_socio) = @numeroSocio AND id_banca_folio = @folio
						 
					  END

					   --  SI ES UN PAGO DE SERVICIO
					  if(@id_tipo_bitacora in (21,93))
					  BEGIN
					      SELECT 
								@cuentaOrigen = TDO.Desc_prestamo ,
								@clabeOrigenMascara =   SUBSTRING(PS.clabe_corresponsalias_retiro,7,3)+'****'+RIGHT(PS.clabe_corresponsalias_retiro,4) ,
								@importe = ISNULL(PS.monto,'0'),
								@fecha = isnull(CONVERT(varchar , PS.fecha_pago_realizado,103),'') ,
								--@hora =  isnull(FORMAT(CONVERT(datetime, PS.fecha_pago_realizado), 'hh:mm:ss tt'),'')  ,
								@hora =  isnull(RIGHT(CONVERT(VARCHAR,PS.fecha_pago_realizado, 22), 11),''),
								@idEstatusTransferencia = isnull( PS.id_estatus_transferencia,0),
								@descServicio= /* S.descripcion +' | '+*/P.descripcion,
								@descripcionDevolucion = mensaje_error

						    FROM TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS PS LEFT JOIN
							TBL_BANCA_CUENTAS_INTERBANCARIAS  C  ON PS.clabe_corresponsalias_retiro = C.clabe and id_cuenta = @ultimaCuentaSocio  LEFT JOIN
							HAPE..TIPOS_DE_OPERACIONES TDO ON TDO.ID_MOV  = C.ID_MOV join
							CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO P ON P.id_producto = PS.id_producto AND P.id_servicios_pago = PS.id_servicio JOIN
							CAT_BANCA_SERVICIOS_PAGO S ON S.id_servicios_pago = PS.id_servicio
							WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(PS.numero_socio) = @numeroSocio AND id_banca_folio = @folio
						 
					  END

					    --  SI ES UNA ALTA DE SERVICIO o UNA ACTUALIZACION o BAJA DE SERVICIO
					  if(@id_tipo_bitacora in (38,39,94))
					  BEGIN
					      SELECT 
								@descServicio= /* S.descripcion +' | '+*/P.descripcion
						    FROM TBL_BANCA_SERVICIOS_SOCIOS ss LEFT JOIN
							CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO P ON P.id_producto = ss.id_producto AND P.id_servicios_pago = ss.id_servicio JOIN
							CAT_BANCA_SERVICIOS_PAGO S ON S.id_servicios_pago = ss.id_servicio
							WHERE ss.id_servicio_socio= @IdServicioSocio
						 
					  END

					  IF(@id_tipo_bitacora in (23,24))
					  BEGIN
						select @nombreComercial = BANCA.[dbo].FN_BANCA_OBTENER_NOMBRE_COMERCIAL (@numPtmo)
					  END
					  
					  IF (@id_tipo_bitacora IN (79))
					  BEGIN
						SELECT  @folio = codigo_contrasena FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio
					  END

					  IF (@id_tipo_bitacora IN (31))
					  BEGIN
						SELECT  @link = 'https://auth.cajamorelia.com.mx:443/ValidaNumero/CheckNumero?n=@Numero'
					  END
					  					  
					  IF (@id_tipo_bitacora IN (20))
					  BEGIN
					  --@clabeOrigenMascara =  SUBSTRING(TI.clave_corresponsalias_origen,7,3)+'****'+RIGHT(TI.clave_corresponsalias_origen,4),
						  select 
						  @clabeDestinoMascara =  SUBSTRING(A.CUENTA,7,3)+'****'+RIGHT(A.CUENTA,4),
						  @cuentaDestino = b.Desc_prestamo from hape..TBL_CORRESPONSALIAS_CUENTAS A join
						  hape..TIPOS_DE_OPERACIONES B on A.ID_MOV = B.Id_mov where A.Id_mov = 103  AND A.NUMERO = @numeroSocio
					  END


					    --OBTENEMOS EL ID DE NOTIFICACIONES QUE TIENE EL MISMO FOLIO
					   -- YA QUE DEBEMOS NOTIFICAR  LOS HABERES AFECTADOS POR OPERACION
							INSERT INTO #notificaciones_sms (idTipoBitacora , idMov)
							SELECT id_tipo_bitacora ,  CASE WHEN id_tipo_bitacora =51 THEN 103
															WHEN id_tipo_bitacora =52 THEN 100
															WHEN id_tipo_bitacora =53 THEN 112
														 END id_Mov
						    from  tbl_banca_bitacora_operaciones
							where 
								id_banca_folio = @folio 
								and @id_tipo_bitacora not in (93,96)-- 93 pago de servicio rechazaso si es un pago de servicio rechazo no se notifica de donde se tomo 

							
						--SI NO EXISTE REGISTRO EN ESTA TABLA QUIERE DECIR QUE NO SON NOTIFIACIONES   DE TRANSFERENCIAS O PAGOS POR LO TANTO
						--NO TIENEN REGISTRO EN LA TABLA tbl_banca_bitacora_operaciones Y NECESITAMOS INSERTAR LA NOTIFICACIONES DE MANERA MANUAL
							IF NOT EXISTS (SELECT 1 FROM #notificaciones_sms)
							BEGIN
								INSERT INTO #notificaciones_sms (idTipoBitacora , idMov) VALUES (@id_tipo_bitacora , 0)
							END
							

						--ACTUALIZAMOS LOS VALORES  DE LAS CUENTAS DE RETIRO EN CASO DE QUE EXISTA ALGUNA 
							UPDATE	A
							SET
								A.importeCuentaRetiro = isnull(Monto,0),
								A.cuentaRetiro = TDO.Desc_prestamo,
								A.cuentaRetiroMascara = SUBSTRING(CC.CUENTA,7,3)+'****'+RIGHT(CC.CUENTA,4),
								A.cuentaRetiroCorreo =N'<span style="font-weight:500; ">'+TDO.Desc_prestamo+' '+SUBSTRING(CC.CUENTA,7,3)+'****'+RIGHT(CC.CUENTA,4)+' '+'$'+ CONVERT(varchar, CAST(ISNULL(Monto,0) AS money), 1)+N'</span><br/>'
							FROM   
								#notificaciones_sms A
								JOIN HAPE..MOVIMIENTOS M on A.idMov = M.id_mov and M.Numero  = @numeroSocio
								JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS CC ON  CC.ID_MOV = M.ID_MOV and CC.NUMERO = @numeroSocio
								JOIN HAPE..TIPOS_DE_OPERACIONES TDO on TDO.Id_mov = M.id_mov
							WHERE 
								M.Numero = @numeroSocio AND
								Folio = @folio AND
								M.id_mov  = CC.id_mov

													
								PRINT'@cuentaOrigen '+ @cuentaOrigen
								PRINT'@clabeOrigenMascara '+  @clabeOrigenMascara 
								PRINT'@importe '+  CAST(@importe  AS VARCHAR)
								PRINT'@esProgramado '+  @esProgramado 
								PRINT'@fecha '+  @fecha
								PRINT'@hora '+  @hora 
								PRINT'@idEstatusTransferencia '+ CAST(@idEstatusTransferencia AS VARCHAR)

					  -- VALIDAMOS SI EL TIPO DE NOTIFICACION ES POR CELULAR O AMBOS
					  IF @id_tipo_notificacion = 1 OR @id_tipo_notificacion  = 3
						BEGIN				
							
							-- ACTUALIZAMOS EL TEXTO QUE SE VA A MANDAR DEPENDIENDO
							-- DEL ID DE LA NOTIFICACION
							UPDATE	A
							SET 	A.cuerpo = B.cuerpo
							FROM	#notificaciones_sms A join TBL_BANCA_NOTIFICACIONES_SMS B
							on A.idTipoBitacora = B.id_tipo_bitacora

							
							
							-- DECLARACION VARIABLES 
							declare
								  @indiceMin int ,
							      @indiceMax int ,
								  @id_tipo_bitacora_retiro int ,
								  @importeCuentaRetiro money=0,
								  @cuentaRetiro varchar(500),
								  @cuentaRetiroMascara varchar(500)

							-- SI ES UN PAGO PROGRAMADO , UNA TRANSFERENCIA SE ELIMINAN LAS ID DE id_tipo_bitacora
							-- YA QUE EL ROBOT DE LOS PAGOS PROGRAMADOS SE ENCARGAR DE NOTIFICAR LOS RETIROS
							-- DE LAS CUENTAS DE HABERES
						    IF @esProgramado = '1'
								DELETE FROM #notificaciones_sms where idTipoBitacora in (51,52,53)
							
	
							SELECT @indiceMin = isnull(min(id),0) ,@indiceMax = isnull(max(id),0)
						    FROM   #notificaciones_sms
							
							WHILE (@indiceMin <= @indiceMax)
								BEGIN -- INICIO DEL WHILE
									
									-- OBTENEMOS LA ESTRUCTURA DE LA NOTIFICACION PARA COMENZAR
									-- REEMPLAZAR LOS PARAMETROS	
								
									 SELECT 
										@nota = cuerpo,
										@id_tipo_bitacora_retiro = idTipoBitacora,
										@cuentaRetiro = cuentaRetiro ,
										@cuentaRetiroMascara= cuentaRetiroMascara,
										@importeCuentaRetiro = importeCuentaRetiro
									FROM   #notificaciones_sms
									WHERE  id = @indiceMin


									print '@id_tipo_bitacora'+cast(@id_tipo_bitacora as varchar)
									print '@esProgramado'+cast(@esProgramado as varchar)
									print '@nota'+cast(@nota as varchar)
									 --
									/*IF @esProgramado = '1' and @id_tipo_bitacora IN (15,16,23,50)
									BEGIN
									  
										SET @nota = REPLACE(@nota ,'Deposito','Deposito programado') 
										SET @nota = REPLACE(@nota ,'Pago realizado','Pago programado') 
									END
									*/

									-- REMPLAZO DE PARAMETROS--
									SET @nota = REPLACE(@nota ,'@numDPF',isnull(@numDPF,'')) -- SET @numDPF
									SET @nota = REPLACE(@nota ,'@fecha_hora_operacion',@fecha+' '+ CASE WHEN @idEstatusTransferencia = 1 AND @esProgramado = '1' THEN '' ELSE @hora END ) -- SET DE HORA Y FECHA
									SET @nota = REPLACE(@nota ,'@folio',isnull(@folio,'')) 
									SET @nota = REPLACE(@nota ,'@link',isnull(@link,''))
									SET @nota = REPLACE(@nota ,'@ticket_banca',isnull(@ticket_banca,'')) -- TICKET DE REPORTE DE BANCA
									SET @nota = REPLACE(@nota ,'@fecha_compromiso',Convert(varchar,isnull(@fecha_compromiso,''), 103)) -- TICKET DE REPORTE DE BANCA 
									SET @nota = REPLACE(@nota ,'@medio_reporte',isnull(@medio_reporte,''))
									SET @nota = REPLACE(@nota ,'@fecha_apertura_reporte',Convert(varchar,isnull(@fecha_apertura_reporte,''), 103)) -- TICKET DE REPORTE DE BANCA 
					
						
									-- VALIDAMOS SI LAS NOTIFICACIONES SON RETIROS DE LAS CUENTAS DE HABERES
									-- TAMBIEN VALIDA QUE NO SEA UNA PAGO PROGAMADO YA QUE SI ES PROGRAMADO NO ES NECESARIO ENVIAR 
									IF (@id_tipo_bitacora_retiro IN (51,52,53) AND (@esProgramado = '0' OR @id_tipo_bitacora = 19))
									BEGIN -- INICIO DE VALIDAMOS SI LAS NOTIFICACIONES SON RETIROS DE LAS CUENTAS DE HABERES
									   
										SET @nota = REPLACE(@nota ,'@numeroReferencia',(iSNULL(@cuentaRetiro,'')+' '+ISNULL(@cuentaRetiroMascara,'') )) 
										SET @nota = REPLACE(@nota ,'@importe','$'+ CONVERT(varchar, CAST(ISNULL(@importeCuentaRetiro,'') AS money), 1))

									END -- FIN DE VALIDAMOS SI LAS NOTIFICACIONES SON RETIROS DE LAS CUENTAS DE HABERES
									ELSE
									BEGIN
										SET @nota = REPLACE(@nota ,'@importe','$'+ CONVERT(varchar, CAST(ISNULL(@importe,'') AS money), 1)) -- SET DE IMPORTE
										SET @nota = REPLACE(@nota ,'@numeroReferencia',(CASE WHEN @id_tipo_bitacora in (15,20) THEN ISNULL(@cuentaDestino,'')+' '+ISNULL(@clabeDestinoMascara,'') ELSE ISNULL(@clabeDestinoMascara,'') END))
									END
							
									----PARA PRESTAMOS OBTENEMOS  SE REALIZA EL SET DEL NOMBRE COMERCIAL ----
									SET @nota = REPLACE(@nota ,'@producto',isnull(@nombreComercial,'')) 
									SET @nota = REPLACE(@nota ,'@claveRastreo',ISNULL(@claveRastreo,'')) 

									----PARA PAGO DE SERVICIOS  SE REALIZA EL SET DE LA DESCRIPCION DEL PAGO DE SERVICIO ----
									SET @nota = REPLACE(@nota ,'@descServicio',ISNULL(@descServicio,'')) 
									SET @nota = REPLACE(@nota ,'@leyenda',ISNULL(@descripcionDevolucion,'')) 
									
							       
								    -- INSERTA A LA TABLA GENERAL DE NOTIFICACION YA CON LOS PARAMETROS REEMPLAZDOS
									INSERT INTO #notificaciones VALUES(1,@noCel ,@correo,@nota ,'',1)
									
									SET @indiceMin = @indiceMin +1

							END -- FIN DEL WHILE

							
						END

						---- VALIDAMOS SI EL TIPO DE NOTIFICACION ES POR CORREO O AMBOS
						IF @id_tipo_notificacion = 2 OR @id_tipo_notificacion  = 3
						BEGIN

							declare 
							@img varchar(max) ='',
							@asunto varchar(500)

									SELECT 
										@nota = cuerpo , 
										@img= url_img_operacion,
										@asunto = asunto
									FROM 
										TBL_BANCA_NOTIFICACIONES_CORREO 
									WHERE
											id_tipo_bitacora = @id_tipo_bitacora
							
							--ACTUALIZAMOS LAS VARIABLES
							if @esProgramado = '1' and @id_tipo_bitacora IN (15,16,50,70)
							begin
								print '@esProgramado: '+@esProgramado
								SET @operacion = REPLACE(@operacion ,'realizada','')
								SET @nota = REPLACE(@nota ,'@operacion',@operacion) -- SET DE OPERACION
								SET @nota = REPLACE(@nota ,'La operaci�n de','Operaci�n programada') -- SET DE OPERACION
								SET @nota = REPLACE(@nota ,'Fecha y Hora','Fecha Programada:') -- SET DE OPERACION
								SET @asunto = REPLACE(@asunto ,'realizada','programada')
								SET @asunto = REPLACE(@asunto ,'Pago a pr�stamo|Cuentas entre socios','programada')
							end
							else IF (@id_tipo_bitacora in (21,38,39,93,94))-- si es pago de servicio o alta de servicio, o actualicacion de servicio , o baja de pago de servicio
							BEGIN
								SET @nota = REPLACE(@nota ,'@operacion',ISNULL(@operacion+' | '+@descServicio,'')) 
							END
							else
							BEGIN
								SET @nota = REPLACE(@nota ,'@operacion',ISNULL(@operacion,'')) -- SET DE OPERACION
							END

							-- VALIDAMOS SI ES UNA APERTURA DE PLAZO FIJO 
							-- SE CONCATENAN LAS CUENTAS DE HABERES INVOLUCRADAS EN LA APERTURA
							IF (@id_tipo_bitacora = 19)
							BEGIN
							      DECLARE
								  @cuentasRetiro varchar(1000) ='' 
									   SELECT @cuentasRetiro = STUFF((
											SELECT ' '+ sms.cuentaRetiroCorreo
											FROM  #notificaciones_sms sms 
											FOR XML PATH('')
											),1,1, '')
								 select @cuentasRetiro = replace(replace(@cuentasRetiro,'&lt;','<'),'&gt;','>')
								 -- 
								 SET @nota = REPLACE(@nota ,'@cuentas',ISNULL(@cuentasRetiro,''))
							END 


							IF (@id_tipo_bitacora = 20)
							BEGIN
								 SET @nota = REPLACE(@nota ,'@CuentaRetiro',(ISNULL(@cuentaDestino,'')+' '+ISNULL(@clabeDestinoMascara,'')))
							END 

														

							SET @nota = REPLACE(@nota ,'@imagen',ISNULL(@img,'')) -- SET DE HORA Y FECHA
							SET @nota = REPLACE(@nota ,'@fecha_hora_operacion',@fecha+' '+CASE WHEN @idEstatusTransferencia = 1 AND @esProgramado = '1' THEN '' ELSE @hora END ) -- SET DE HORA Y FECHA
							SET @nota = REPLACE(@nota ,'@folio',ISNULL(@folio,'')) -- SET DE HORA Y FECHA
							SET @nota = REPLACE(@nota ,'@CuentaRetiro',ISNULL(@cuentaOrigen,'')+' '+ISNULL(@clabeOrigenMascara,'')) -- SET cuentaRetiro
							SET @nota = REPLACE(@nota ,'@CuentaDeposito',(CASE WHEN @id_tipo_bitacora in (15,70) THEN ISNULL(@cuentaDestino,'')+' '+ISNULL(@clabeDestinoMascara,'') ELSE ISNULL(@clabeDestinoMascara,'') END))
							SET @nota = REPLACE(@nota ,'@Importe','$'+ CONVERT(varchar, CAST(ISNULL(@importe,'') AS money), 1))--  SET IMPORTE
							SET @nota = REPLACE(@nota ,'@Nombre', ISNULL(@nombreSocio,''))--  SET @importe
							SET @nota = REPLACE(@nota ,'@link', ISNULL(@link,''))
							SET @nota = REPLACE(@nota ,'@ticket_banca', ISNULL(@ticket_banca,'')) 
							SET @nota = REPLACE(@nota ,'@fecha_compromiso', Convert(varchar,isnull(@fecha_compromiso,''), 103)) 
							SET @nota = REPLACE(@nota ,'@medio_reporte', ISNULL(@medio_reporte,''))
							SET @nota = REPLACE(@nota ,'@fecha_apertura_reporte', Convert(varchar,isnull(@fecha_apertura_reporte,''), 103)) 
							SET @nota = REPLACE(@nota ,'@claveRastreo',ISNULL(@claveRastreo,'')) 
							SET @nota = REPLACE(@nota ,'@leyenda',ISNULL(@descripcionDevolucion,'')) 
						
							INSERT INTO #notificaciones VALUES(2,@noCel ,@correo,@nota ,@asunto,3)
							PRINT 'CUENTA DESTINO: '+(@cuentaDestino)
						END
				END

            print 'folio: '+cast(isnull(@folio, ' ') as varchar)
			print '@cuentaOrigen: '+cast(isnull(@cuentaOrigen, ' ') as varchar)

			
		    select 200 estatus , 'OK' mensaje
			SELECT * FROM #notificaciones order by ordenby
			
			
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
				select	@status estatus,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message mensaje
		end catch -- catch principal
		
		--begin -- reporte de status
		
		
				
		--end -- reporte de status
		
	end -- procedimiento

go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_PAGOS_SERVICIO_PENDIENTES]    Script Date: 23/01/2020 01:45:40 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER proc

	[dbo].[SP_BANCA_OBTENER_PAGOS_SERVICIO_PENDIENTES]
	
		-- parametros		
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @ESTATUS int = 0,
						@mensaje varchar(max) = '',	
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''

			end -- inicio
			
			begin -- �mbito de la actualizaci�n
				if exists(select 1 from TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES)
				begin
					SELECT @ESTATUS = 1
				end
				else
				begin
					select @error_message = 'No hay registros en la tabla'
				end

			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@ESTATUS = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
		if @error_message<>''
		begin
			select	
				@ESTATUS AS ESTATUS,
				@error_procedure error_procedure,
				@error_line error_line,
				@error_severity error_severity,
				@error_message error_message
			
		end
		else
		SELECT 
			serviciosPendientes.id_pago_pendiente,
			pagoServicios.id_banca_folio,
			serviciosPendientes.REQUEST_PAGO_REALIZADO,
			serviciosPendientes.RESPONSE_PAGO_REALIZADO,
			serviciosPendientes.SERVICIO_ATENDIDO,	
			serviciosPendientes.ID_ESTATUS_TRANSFERENCIA,	
			serviciosPendientes.request_confirma_transaccion,
			serviciosPendientes.response_confirma_transaccion,	
			pagoServicios.clabe_corresponsalias_retiro,
			pagoServicios.id_producto,
			pagoServicios.id_servicio,
			pagoServicios.monto,
			productos.comision_cmv,
			pagoServicios.numero_referencia,
			BANCA.dbo.FN_BANCA_DESCIFRAR(pagoServicios.numero_socio) numero_socio,
			productos.precio,
			pagoServicios.telefono,
			productos.tipo_front,
			8 as tipo_origen,
			pagoServicios.folio_autorizacion,
			pagoServicios.pin
			 
		from 
			TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES serviciosPendientes
		inner join
			TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS pagoServicios
		on
			(serviciosPendientes.folio_banca = pagoServicios.id_banca_folio)
		inner join
			CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO productos 
		on
			(productos.id_producto = pagoServicios.id_producto)
		 where
			serviciosPendientes.SERVICIO_ATENDIDO = 0
			and 
			serviciosPendientes.id_estatus_transferencia = 1

			--and
			--serviciosPendientes.intentos<2
					
		end -- reporte de estatus
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_PREGUNTA_SECRETA_SOCIO]    Script Date: 21/08/2019 04:22:05 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_OBTENER_PREGUNTA_SECRETA_SOCIO]
@NUMERO AS VARCHAR(20)
AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int 

select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)
set @numero_int = CAST(@NUMERO as int )

  if(@mensaje_validacion is null)
  BEGIN
		SELECT 200 AS estatus , P.id_pregunta_secreta, respuesta , P.pregunta_secreta
		FROM TBL_BANCA_SOCIOS S JOIN CAT_BANCA_PREGUNTAS_SECRETAS P 
		ON S.id_pregunta_secreta = P.id_pregunta_secreta
		WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int
  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje



end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[sp_banca_obtener_socio]    Script Date: 16/08/2019 08:24:50 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez
UsuarioRed		pegc837648
Fecha			20181220
Objetivo		Obtener los datos del socio en banca
Proyecto		Administrador de banca
Ticket			ticket

*/

ALTER proc

	[dbo].[sp_banca_obtener_socio]
	
		-- par�metros
		
		@numero_socio bigint,
		@idTIpoPersona int  =1

as

	BEGIN

begin try
declare
@existeError bit  = 0 ,
@mensajeError varchar(500) = ''

	-- validaciones
	
	if not exists (select 1 from BANCA..TBL_BANCA_SOCIOS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio)
	 begin
		SELECT 
		0 estatus ,
		1 existeError,
		'EL socio no esta registrado en �CMV Finanzas�. |' mensajeError
	end
	else
		SELECT 
	1 estatus ,
	0 existeError,
	'' mensajeError,
	isnull(p.Nombre_s,' ')+' '+isnull(p.Apellido_Paterno,' ')+' '+isnull(p.Apellido_Materno,' ') nombreCompleto,
	CASE WHEN BANCA.dbo.FN_BANCA_DESCIFRAR(S.numero_socio) IS NULL THEN 1  ELSE 0 END puedeActivar,
	CASE WHEN S.id_motivo_bloqueo  <> 1 THEN 1  ELSE 0 END bloqueado,
	CASE WHEN CB.numero IS NULL THEN 0 ELSE 1 END tieneContratoBanca,
	isnull(S.banca_activa,0)banca_activa,
	ISNULL(s.id_estatus_banca,0) id_estatus_banca,
	ISNULL(CB.monto_maximo_transferencia,0) monto_maximo_transferencia,
	CB.id_tipo_notificacion,
	p.Mail,
	p.Tel_Celular,
	C.Codigo_Postal,C.Nombre_Colonia , L.Nombre_Localidad, E.DESCRIPCION,
	isnull(p.Calle,'')+' '+isnull(p.Numero_Exterior,'')+', '+ISNULL(C.Nombre_Colonia,' ')+','+isnull(cast(C.Codigo_Postal as varchar),'')+' '+ISNULL(L.Nombre_Localidad,'')+' '+ISNULL(E.DESCRIPCION,' ') domiCompleto,
	s.id_motivo_bloqueo,
	P.*
	FROM HAPE..PERSONA  P
	LEFT JOIN hape..CNBV_MNPIO_COL C ON P.Id_Colonia_CNBV = C.Id_Colonia_CNBV
	LEFT JOIN hape..CNBV_LOCALIDADES L ON L.Id_Localidad_CNBV = C.Id_Localidad_CNBV AND C.Id_Entidad_Federativa = L.Id_Entidad_Federativa
	LEFT JOIN hape..ENTIDAD_FEDERATIVA E ON E.ID_ENTIDAD_FEDERATIVA  = C.Id_Entidad_Federativa
	LEFT JOIN BANCA..TBL_BANCA_SOCIOS  S ON BANCA.dbo.FN_BANCA_DESCIFRAR(S.NUMERO_SOCIO) = P.Numero AND P.Id_Tipo_Persona = @idTIpoPersona
	LEFT JOIN hape..TBL_CONTRATOS_HABERES CB ON CB.Numero = @numero_socio  and  id_tipo_contrato = 3
	WHERE P.NUMERO = @numero_socio 
	AND P.Id_Tipo_Persona =  @idTIpoPersona
	-- fin de validaciones

end try
begin catch
	select 0 as estatus , ERROR_MESSAGE() AS mensaje 	
	
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_TRANSACCIONES_SPEI_PROGRAMADAS]    Script Date: 12/02/2020 11:27:53 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		EDSON
-- Create date: 2018-09-10
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_OBTENER_TRANSACCIONES_SPEI_PROGRAMADAS]
	@fecha_proceso datetime
AS
BEGIN

begin try

	DECLARE 
	@mensaje_validacion varchar(500),
	@estatus int,
	@registro int


	IF @fecha_proceso is null
		SELECT @fecha_proceso = GETDATE()

	CREATE TABLE #TransaccionesProgramadas
	(
		id INT IDENTITY(1, 1) primary key ,
		id_transferencia	int,
		numero int,
		monto money,
		clabe_spei_retiro varchar(20),
		clabe_spei_deposito varchar(20),
		fecha_programada datetime,
		programado bit,
		id_origen_operacion int,
		concepto_pago varchar(300),
		id_tipo_persona_origen int,
		----
		clave_rastreo varchar(500),
        referencia_numerica int,
        nombre_beneficiario varchar(300),
        id_bancoBIN int,
		------- BITACORA
		id_bitacora bigint,
		id_tipo_bitacora int,
		------- ORDENANDTE
		nombre_ordenante varchar(20),
		ap_paterno_ordenante varchar(20),
		ap_materno_ordenante varchar(20),
		rfc_ordenante varchar(20),
		id_tipo_cuenta_externa int
	)

	CREATE TABLE #resultado_transferencia
	(
		estatus int,
		IdTransferenciaCMV bigint,
		referenciaNumerica bigint,
		claveRastreo varchar(500),
		HoraTransaccion datetime,
		Monto money,
		concepto_pago varchar(300),
		error_procedur varchar(500),
		error_lin varchar(500),
		error_severit varchar(500),
		error_messag varchar(500)
	)

	
	insert into #TransaccionesProgramadas
		(id_transferencia,numero,monto,clabe_spei_retiro,clabe_spei_deposito,fecha_programada,programado,
		id_origen_operacion,concepto_pago,id_tipo_persona_origen,clave_rastreo,referencia_numerica,
		nombre_beneficiario,id_bancoBIN,nombre_ordenante,ap_paterno_ordenante,ap_materno_ordenante,rfc_ordenante,
		id_tipo_cuenta_externa)
	select  
		a.id_transferencia,
		BANCA.dbo.FN_BANCA_DESCIFRAR(a.numero_socio) numero_socio,
		a.monto,
		a.clabe_spei_origen,
		a.clabe_spei_destino,
		a.fecha_programada,--horaProgramada
		0,--programada
		7,--id_origen_operacion
		a.concepto_pago,
		1, --id_tipo_persona_origen
		a.clave_rastreo,
		a.referencia_numerica,
		cuExt.titular_cuenta,
		banco.clabe id_bancoBIN,
		persona.Nombre_s,
		persona.Apellido_Paterno,
		persona.Apellido_Materno,
		persona.Rfc,
		cuExt.id_tipo_cuenta_externa id_tipo_cuenta_externa
	from 
		banca..TBL_BANCA_TRANSFERENCIAS_EXTERNAS a
	inner join
		BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS b on a.clabe_spei_origen = b.clabe
	inner join
		BANCA..TBL_BANCA_BITACORA_OPERACIONES BO on BO.id_banca_folio = a.id_banca_folio  and BO.numero_socio = BANCA.dbo.FN_BANCA_DESCIFRAR(a.numero_socio)	
	inner join
		BANCA..TBL_BANCA_CUENTAS_EXTERNAS cuExt on BANCA.dbo.FN_BANCA_DESCIFRAR(a.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(cuExt.numero_socio) and a.id_cuenta_externa = cuExt.id_cuenta_externa
	inner join
		BANCA..CAT_BANCA_BANCOS_CLABES_SPEI banco on cuExt.id_banco = banco.id_banco_spei
	inner join
		HAPE..PERSONA persona on persona.Numero = BANCA.dbo.FN_BANCA_DESCIFRAR(a.numero_socio)
	where
		id_estatus_transferencia = 1
		and A.programado = 1
		and a.id_transferencia_SPEI is null
		and convert (varchar (12),a.fecha_programada,103) = convert (varchar (12),@fecha_proceso,103) 
		/*
			88 -- Transferencia Programada |  Entre cuentas externas
		*/
		and BO.id_tipo_bitacora in (88)
		--and id_transferencia = 88 --pruebas 
	order by a.fecha_programada

	/*
	set @registro = 1
	while @registro <= (select count(*) from #TransaccionesProgramadas)
	begin
		DECLARE
			@numero int,
			@monto money,
			@clabe_spei_retiro varchar(20),
			@clabe_spei_deposito varchar(20),
			@fecha_programada datetime,
			@programado bit,
			@id_origen_operacion int,
			@concepto_pago varchar(300),
			@id_tipo_persona_origen int = null,
			@id_tranferencia_externa bigint 

		BEGIN TRY
			SELECT 
				@numero  = numero,
				@monto = monto,
				@clabe_spei_retiro = clabe_spei_retiro,
				@clabe_spei_deposito = clabe_spei_deposito,
				@fecha_programada = fecha_programada,
				@programado = programado,
				@id_origen_operacion  = id_origen_operacion,
				@concepto_pago = concepto_pago,
				@id_tipo_persona_origen = id_tipo_persona_origen,
				@id_tranferencia_externa = id_transferencia
			FROM #TransaccionesProgramadas
			WHERE
				id = @registro
	
			insert into #resultado_transferencia 
				(estatus,IdTransferenciaCMV,referenciaNumerica,claveRastreo,HoraTransaccion,Monto,
				concepto_pago,error_procedur,error_lin,error_severit,error_messag)
			exec BANCA..SP_BANCA_REALIZA_TRANSFERENCIA_EXTERNA 
				@numero,@monto,@clabe_spei_retiro,@clabe_spei_deposito,@fecha_programada,@programado,
				@id_origen_operacion,@concepto_pago,@id_tipo_persona_origen,@id_tranferencia_externa


			update #resultado_transferencia 
			set 
				IdTransferenciaCMV = @id_tranferencia_externa
			where
				IdTransferenciaCMV is null

			--select * from #resultado_transferencia --pruebas

			declare @msj_error_transaccion varchar(1000) 
			select @msj_error_transaccion = error_messag from #resultado_transferencia where IdTransferenciaCMV = @id_tranferencia_externa
			---Se actualiza el estatus de la transaccion en caso de no haberse efectuado correctamente
			if (select estatus from #resultado_transferencia where IdTransferenciaCMV = @id_tranferencia_externa) <> 200
			begin	
				update BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS
					set 
						id_estatus_transferencia = 3, --Rechazada
						fecha_transferencia_realizada =@fecha_proceso,
						mensaje_error = @msj_error_transaccion
					where
						id_transferencia = @id_tranferencia_externa

				-----------------	SE ACTUALIZA LA BITACORA CON EL FALLO DE TRANSFERENCIA	-------------------
				/*update bo set 
					bo.id_tipo_bitacora = case 
						when @id_tipo_transaccion = 1 then 80--'transferencia no realizada'
						when @id_tipo_transaccion = 2 then 81--'pago no realizado' 
						end, --bitacora de error de transferencia
					bo.fecha_alta =  @fecha_proceso
				from #TransaccionesProgramadas trasn_pro
				inner join
					TBL_BANCA_BITACORA_OPERACIONES bo on bo.id_bitacora = trasn_pro.id_bitacora
				where 
					trasn_pro.id_transferencia = @id_transferencia
			*/
			end
			set @registro =  @registro +  1
		END TRY
		BEGIN CATCH
			print 'Error al afectar la transferencia con id: '+ cast(@id_tranferencia_externa as varchar) + cast(ERROR_MESSAGE() as varchar)
			set @registro =  @registro +  1
		END CATCH
	end
	*/	

end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 	 		
end catch
	
	--select * from #resultado_transferencia where estatus = 200 --transferencias ejecutadas correctamente
	select * from #TransaccionesProgramadas
	drop table #TransaccionesProgramadas
	drop table #resultado_transferencia

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_TRANSACCIONES_SPEI_PROGRAMADAS]    Script Date: 12/02/2020 11:27:53 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		EDSON
-- Create date: 2018-09-10
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_OBTENER_TRANSACCIONES_SPEI_PROGRAMADAS]
	@fecha_proceso datetime
AS
BEGIN

begin try

	DECLARE 
	@mensaje_validacion varchar(500),
	@estatus int,
	@registro int


	IF @fecha_proceso is null
		SELECT @fecha_proceso = GETDATE()

	CREATE TABLE #TransaccionesProgramadas
	(
		id INT IDENTITY(1, 1) primary key ,
		id_transferencia	int,
		numero int,
		monto money,
		clabe_spei_retiro varchar(20),
		clabe_spei_deposito varchar(20),
		fecha_programada datetime,
		programado bit,
		id_origen_operacion int,
		concepto_pago varchar(300),
		id_tipo_persona_origen int,
		----
		clave_rastreo varchar(500),
        referencia_numerica int,
        nombre_beneficiario varchar(300),
        id_bancoBIN int,
		------- BITACORA
		id_bitacora bigint,
		id_tipo_bitacora int,
		------- ORDENANDTE
		nombre_ordenante varchar(20),
		ap_paterno_ordenante varchar(20),
		ap_materno_ordenante varchar(20),
		rfc_ordenante varchar(20),
		id_tipo_cuenta_externa int
	)

	CREATE TABLE #resultado_transferencia
	(
		estatus int,
		IdTransferenciaCMV bigint,
		referenciaNumerica bigint,
		claveRastreo varchar(500),
		HoraTransaccion datetime,
		Monto money,
		concepto_pago varchar(300),
		error_procedur varchar(500),
		error_lin varchar(500),
		error_severit varchar(500),
		error_messag varchar(500)
	)

	
	insert into #TransaccionesProgramadas
		(id_transferencia,numero,monto,clabe_spei_retiro,clabe_spei_deposito,fecha_programada,programado,
		id_origen_operacion,concepto_pago,id_tipo_persona_origen,clave_rastreo,referencia_numerica,
		nombre_beneficiario,id_bancoBIN,nombre_ordenante,ap_paterno_ordenante,ap_materno_ordenante,rfc_ordenante,
		id_tipo_cuenta_externa)
	select  
		a.id_transferencia,
		BANCA.dbo.FN_BANCA_DESCIFRAR(a.numero_socio) numero_socio,
		a.monto,
		a.clabe_spei_origen,
		a.clabe_spei_destino,
		a.fecha_programada,--horaProgramada
		0,--programada
		7,--id_origen_operacion
		a.concepto_pago,
		1, --id_tipo_persona_origen
		a.clave_rastreo,
		a.referencia_numerica,
		cuExt.titular_cuenta,
		banco.clabe id_bancoBIN,
		persona.Nombre_s,
		persona.Apellido_Paterno,
		persona.Apellido_Materno,
		persona.Rfc,
		cuExt.id_tipo_cuenta_externa id_tipo_cuenta_externa
	from 
		banca..TBL_BANCA_TRANSFERENCIAS_EXTERNAS a
	inner join
		BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS b on a.clabe_spei_origen = b.clabe
	inner join
		BANCA..TBL_BANCA_BITACORA_OPERACIONES BO on BO.id_banca_folio = a.id_banca_folio  and BO.numero_socio = BANCA.dbo.FN_BANCA_DESCIFRAR(a.numero_socio)	
	inner join
		BANCA..TBL_BANCA_CUENTAS_EXTERNAS cuExt on BANCA.dbo.FN_BANCA_DESCIFRAR(a.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(cuExt.numero_socio) and a.id_cuenta_externa = cuExt.id_cuenta_externa
	inner join
		BANCA..CAT_BANCA_BANCOS_CLABES_SPEI banco on cuExt.id_banco = banco.id_banco_spei
	inner join
		HAPE..PERSONA persona on persona.Numero = BANCA.dbo.FN_BANCA_DESCIFRAR(a.numero_socio)
	where
		id_estatus_transferencia = 1
		and A.programado = 1
		and a.id_transferencia_SPEI is null
		and convert (varchar (12),a.fecha_programada,103) = convert (varchar (12),@fecha_proceso,103) 
		/*
			88 -- Transferencia Programada |  Entre cuentas externas
		*/
		and BO.id_tipo_bitacora in (88)
		--and id_transferencia = 88 --pruebas 
	order by a.fecha_programada

	/*
	set @registro = 1
	while @registro <= (select count(*) from #TransaccionesProgramadas)
	begin
		DECLARE
			@numero int,
			@monto money,
			@clabe_spei_retiro varchar(20),
			@clabe_spei_deposito varchar(20),
			@fecha_programada datetime,
			@programado bit,
			@id_origen_operacion int,
			@concepto_pago varchar(300),
			@id_tipo_persona_origen int = null,
			@id_tranferencia_externa bigint 

		BEGIN TRY
			SELECT 
				@numero  = numero,
				@monto = monto,
				@clabe_spei_retiro = clabe_spei_retiro,
				@clabe_spei_deposito = clabe_spei_deposito,
				@fecha_programada = fecha_programada,
				@programado = programado,
				@id_origen_operacion  = id_origen_operacion,
				@concepto_pago = concepto_pago,
				@id_tipo_persona_origen = id_tipo_persona_origen,
				@id_tranferencia_externa = id_transferencia
			FROM #TransaccionesProgramadas
			WHERE
				id = @registro
	
			insert into #resultado_transferencia 
				(estatus,IdTransferenciaCMV,referenciaNumerica,claveRastreo,HoraTransaccion,Monto,
				concepto_pago,error_procedur,error_lin,error_severit,error_messag)
			exec BANCA..SP_BANCA_REALIZA_TRANSFERENCIA_EXTERNA 
				@numero,@monto,@clabe_spei_retiro,@clabe_spei_deposito,@fecha_programada,@programado,
				@id_origen_operacion,@concepto_pago,@id_tipo_persona_origen,@id_tranferencia_externa


			update #resultado_transferencia 
			set 
				IdTransferenciaCMV = @id_tranferencia_externa
			where
				IdTransferenciaCMV is null

			--select * from #resultado_transferencia --pruebas

			declare @msj_error_transaccion varchar(1000) 
			select @msj_error_transaccion = error_messag from #resultado_transferencia where IdTransferenciaCMV = @id_tranferencia_externa
			---Se actualiza el estatus de la transaccion en caso de no haberse efectuado correctamente
			if (select estatus from #resultado_transferencia where IdTransferenciaCMV = @id_tranferencia_externa) <> 200
			begin	
				update BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS
					set 
						id_estatus_transferencia = 3, --Rechazada
						fecha_transferencia_realizada =@fecha_proceso,
						mensaje_error = @msj_error_transaccion
					where
						id_transferencia = @id_tranferencia_externa

				-----------------	SE ACTUALIZA LA BITACORA CON EL FALLO DE TRANSFERENCIA	-------------------
				/*update bo set 
					bo.id_tipo_bitacora = case 
						when @id_tipo_transaccion = 1 then 80--'transferencia no realizada'
						when @id_tipo_transaccion = 2 then 81--'pago no realizado' 
						end, --bitacora de error de transferencia
					bo.fecha_alta =  @fecha_proceso
				from #TransaccionesProgramadas trasn_pro
				inner join
					TBL_BANCA_BITACORA_OPERACIONES bo on bo.id_bitacora = trasn_pro.id_bitacora
				where 
					trasn_pro.id_transferencia = @id_transferencia
			*/
			end
			set @registro =  @registro +  1
		END TRY
		BEGIN CATCH
			print 'Error al afectar la transferencia con id: '+ cast(@id_tranferencia_externa as varchar) + cast(ERROR_MESSAGE() as varchar)
			set @registro =  @registro +  1
		END CATCH
	end
	*/	

end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 	 		
end catch
	
	--select * from #resultado_transferencia where estatus = 200 --transferencias ejecutadas correctamente
	select * from #TransaccionesProgramadas
	drop table #TransaccionesProgramadas
	drop table #resultado_transferencia

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_TRANSFERENCIAS_PAGOS_PROGRAMADOS]    Script Date: 08/08/2019 03:02:23 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Victor Adrian Reyes
Fecha			20180417
Objetivo		
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_OBTENER_TRANSFERENCIAS_PAGOS_PROGRAMADOS]

@NUMERO varchar(20),
@tipoTransferencia int  = null  -- 1 TrasferenciasInternas , 2 -- TransferenciasExternas , 3-- PagoServicios  4-PagoPrestamos --5 todas

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message VARCHAR(500),
						@mensaje_validacion varchar(500),
						@estatus int , 
						@numero_int int,
						@numero_socio_guardado int 
			
			 end -- inicio		

			 IF @tipoTransferencia IS NULL 
			  SET @tipoTransferencia = 5


			IF OBJECT_ID('tempdb..#programados') IS NOT NULL
			DROP TABLE #programados


			CREATE TABLE #programados (
			id_comprobante bigint null ,
			tipo_transferencia int,
			celular varchar(20) null ,
			bancoDestino varchar(500) ,
			clabe varchar(20),
			TitularCuentaDeposito varchar(500) null ,
			TitularCuentaRetiro varchar(1000) null ,
			importe decimal(18,2) null ,
			concepto varchar(500) null , 
			fechaAltaTransferencia varchar(20) null ,
			horaAltaTransferencia varchar(20) null ,
			folio bigint null , 
			correo varchar(100) null,
			estadoTransferencia varchar(500),
			idEstatusTransferecnia int,
			fechaTransferenciaProgramada varchar(20) null ,
			horaTransferenciaProgramada varchar(20) null ,
			fechaTransferenciaRealizada varchar(20) null ,
			horaTransferenciaRealizada varchar(20) null ,
			programado bit 

			)

		   select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)
		   Set @numero_int = CAST(@NUMERO as int )
		   print 'Numero:'+cast(@numero_int as varchar)
		  if(@mensaje_validacion is null)
			BEGIN
				if @tipoTransferencia = 1  OR @tipoTransferencia = 5
				BEGIN
					print 'INSERTAMOS CUENTAS INTERNA'
					------INSERTAMOS CUENTAS INTERNAS ----
					INSERT INTO #programados (
								id_comprobante,
								tipo_transferencia,
								celular ,
								bancoDestino ,
								clabe,
								TitularCuentaDeposito ,
								TitularCuentaRetiro,
								importe ,
								concepto , 
								fechaAltaTransferencia, 
								horaAltaTransferencia,
								folio,
								correo,
								estadoTransferencia,
								idEstatusTransferecnia,
								fechaTransferenciaProgramada  ,
								horaTransferenciaProgramada ,
								fechaTransferenciaRealizada ,
								horaTransferenciaRealizada ,
								programado 
								 ) 
					SELECT
						 A.id_transferencia,
						 CASE WHEN SUBSTRING(CC.CUENTA,4,3) ='002' THEN  4 ELSE 1 END,--tipo_transferencia TrasferenciasInterna,
						 PS.Tel_Celular Celular, --celular
						 'CAJA MORELIA' BancoDestino,--bancoDestino
						 isnull(a.clave_corresponsalias_destino,'') clabe ,--clabe
						 case when P.Numero IS null then 'Transferencia entre mis cuentas' else isnull(P.Nombre_s,' ')+' '+ISNULL(P.Apellido_Paterno,'')+' '+ISNULL(P.Apellido_Materno,' ') end TitularCuentaDeposito,
						 isnull(PS.Nombre_s,' ')+' '+ISNULL(PS.Apellido_Paterno,'')+' '+ISNULL(PS.Apellido_Materno,' ') TiularCuenta,
						 A.monto,
						 case when  CI.alias Is null then 'Transferencia entre mis cuentas' else CI.alias end concepto,
						 CONVERT(varchar,A.fecha_alta_transferencia,103) fechaAltaTransferencia,
						 CONVERT(varchar,A.fecha_alta_transferencia,108) horaAltaTransferencia,
						 A.id_banca_folio Folio,
						 PS.Mail correo,
						 ET.descripcion,
						 a.id_estatus_transferencia, --idEstatusTransferecnia,
						 CASE WHEN A.fecha_programada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_programada,103) END fechaTransferenciaProgramada,
						 CASE WHEN A.fecha_programada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_programada,108) END horaAltaTransferenciaProgramada,
						 CASE WHEN A.fecha_transferencia_realizada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_transferencia_realizada,103) END fechaAltaTransferenciaRealizada,
						 CASE WHEN A.fecha_transferencia_realizada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_transferencia_realizada,108) END horaTransferenciaRealizada,
						 A.programada
					FROM
						 [dbo].[TBL_BANCA_TRANSFERENCIAS_INTERNAS] A
						JOIN HAPE..PERSONA PS ON PS.numero =BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio)  AND PS.ID_TIPO_PERSONA = 1 AND BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio)  = @numero_int
						LEFT JOIN TBL_BANCA_CUENTAS_INTERNAS CI ON CI.id_cuenta_interna = A.id_cuenta_interna AND BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(CI.numero_socio)
						JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS CC ON CC.CUENTA = A.clave_corresponsalias_destino 
						LEFT JOIN HAPE..PERSONA P ON P.numero =CC.NUMERO  AND P.ID_TIPO_PERSONA = 1
						JOIN CAT_BANCA_ESTATUS_TRANSFERENCIAS ET ON ET.id_estatus_transferencia = A.id_estatus_transferencia
					WHERE
						BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) = @numero_int AND
						A.programada = 1
						and A.id_estatus_transferencia = 1
						and CONVERT(varchar,A.fecha_programada,112) >= CONVERT(varchar,GETDATE(),112)

				 END

				if @tipoTransferencia = 2  OR @tipoTransferencia = 5
				BEGIN
					print 'INSERTAMOS CUENTAS INTERNA'
					------INSERTAMOS CUENTAS EXTERNAS ----
					INSERT INTO #programados (
								id_comprobante,
								tipo_transferencia,
								celular ,
								bancoDestino ,
								clabe,
								TitularCuentaDeposito ,
								TitularCuentaRetiro,
								importe ,
								concepto , 
								fechaAltaTransferencia, 
								horaAltaTransferencia,
								correo,
								folio,
								estadoTransferencia,
								idEstatusTransferecnia,
								fechaTransferenciaProgramada  ,
								horaTransferenciaProgramada ,
								fechaTransferenciaRealizada ,
								horaTransferenciaRealizada ,
								programado )

					SELECT
						 A.id_transferencia,
						 2,--tipo_transferencia TransferenciasExternas,
						 PS.Tel_Celular Celular,
						 ' ' as BancoDestino, -- error
						--(CASE WHEN CE.id_cuenta_externa IN (1,4) THEN  (SELECT institucion FROM CAT_BANCA_SPEI WHERE id_banco_spei = CE.id_banco )  ELSE (SELECT institucion FROM CAT_BANCA_BINES WHERE id_banco_bin = CE.id_banco ) END) BancoDestino,
						isnull(a.clabe_spei_destino,'') clabe ,
						CE.titular_cuenta TitularCuentaDeposito,
						isnull(PS.Nombre_s,' ')+' '+ISNULL(PS.Apellido_Paterno,'')+' '+ISNULL(PS.Apellido_Materno,' ') TiularCuenta,
						A.monto,
						CE.alias,
						CONVERT(varchar,A.fecha_alta_transferencia,103) fecha,
						CONVERT(varchar,A.fecha_alta_transferencia,108) hora,
						PS.Mail correo,
						A.id_banca_folio Folio,
						 ET.descripcion, --estadoTransferencia
						 a.id_estatus_transferencia ,--idEstatusTransferecnia,
						 CASE WHEN A.fecha_programada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_programada,103) END fechaTransferenciaProgramada,
						 CASE WHEN A.fecha_programada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_programada,108) END horaAltaTransferenciaProgramada,
						 CASE WHEN A.fecha_transferencia_realizada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_transferencia_realizada,103) END fechaAltaTransferenciaRealizada,
						 CASE WHEN A.fecha_transferencia_realizada IS NULL  THEN 'N/A ' ELSE CONVERT(varchar,A.fecha_transferencia_realizada,108) END horaTransferenciaRealizada,
						 A.programado
					FROM 
						TBL_BANCA_TRANSFERENCIAS_EXTERNAS A
						JOIN HAPE..PERSONA PS ON PS.numero =BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio)  AND PS.ID_TIPO_PERSONA = 1 AND BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio)  = @numero_int
						JOIN TBL_BANCA_CUENTAS_EXTERNAS CE ON CE.id_cuenta_externa = A.id_cuenta_externa AND BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(CE.numero_socio) and BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) = @numero_int
						JOIN CAT_BANCA_ESTATUS_TRANSFERENCIAS ET ON ET.id_estatus_transferencia = A.id_estatus_transferencia
					WHERE
						 BANCA.dbo.FN_BANCA_DESCIFRAR(A.numero_socio) = @numero_int AND
						 A.programado = 1
						 and A.id_estatus_transferencia = 1
						 and CONVERT(varchar,A.fecha_programada,112) >= CONVERT(varchar,GETDATE(),112)
				END
						select 'OK' as mensaje, '200' as estatus
						select * from  #programados ORDER BY tipo_transferencia

		END
		ELSE
			select @mensaje_validacion as mensaje, @estatus as estatus
		end try -- try principal
		
		begin catch -- catch principal
		
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@status=0
		
			select @error_message as mensaje, @status as estatus
		
		end catch -- catch principal
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_PAGAR_PRESTAMO]    Script Date: 12/11/2019 01:49:21 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Mar Mej�a Murillo
UsuarioRed		memm373565
Fecha			20190110
Objetivo		Realiza el pago de un cr�dito a trav�s de Banca en L�nea
Proyecto		Banca en L�nea
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_PAGAR_PRESTAMO]
	
		@clabeCorresponsaliasRetiro varchar(16),
		@clabeCorresponsaliasDeposito varchar(16),
		@Monto decimal(18,2),
		@TipoAnticipo int = null,
		@TipoOrigen int = null,
		@programada bit = null,
		@horaProgramada datetime = null,
		@fechaOperacion datetime = null,
		@id_transferencia bigint = null

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				begin -- declaraciones

					declare	@status int = 200,
							@error_message varchar(255) = '',
							@error_line varchar(255) = '',
							@error_severity varchar(255) = '',
							@error_procedure varchar(255) = '',
							@sql nvarchar(4000) = 'delete #SP_BANCA_PAGAR_PRESTAMO',
					        @standalone	bit = 1
						
					declare	@tran_name varchar(32) = 'REALIZA_PAGO_PRESTAMO',
							@tran_count int = @@trancount,
							@tran_scope bit = 0,
							@estatus_sp_interno int = 1,
							@mensaje_sp_interno varchar(500)

					--declare
					--		@numusuario int = 6012,
					--		@num_poliza bigint,
					--		@id_persona_origen int,
					--		@id_persona_destino int,
					--		@saldo_adelanto_destino money,
					--		@aplica_iva_destino money,
					--		@retiro_ahorro_total money,
					--		@retiro_inver_total money,
					--		@retiro_debito_total money,
					--		@retiro_adelanto_total money = 0,
					--		@num_ptmo_destino varchar(14),
					--		@gastos_cobranza_destino money,
					--		@iva_gastos_cobranza_destino money,
					--		@gastos_cobranza_mas_iva_destino money,
					--		@tasa_gastos_cobranza_destino float,
					--		@monto_liquidacion_destino money,
					--		@no_asignado_destino money,
					--		@titular_destino varchar(1) = 'T',
					--		@plazo_destino int,
					--		@reestructura_destino varchar(1),
					--		@diferencia_redondeo money

					declare	@numero_origen int,
							@numero_destino int,
							@es_decreciente_destino bit = 0,
							@es_nivelado_destino bit = 0,
							@es_revolvente_destino bit = 0,
							@pago_liquidacion_destino money = 0,
							@pago_al_corriente_destino money = 0,
							@tipo_poliza varchar(1) = 'M',
							@message varchar(255),
							@total_efectivo money = 0,
							@num_poliza bigint,
							@id_mov_origen int,
							@id_mov_destino int,
							@saldo_origen money,
							@saldo_destino money,
							@id_esquema_destino int,
							@saldo_adelanto_destino money,
							@aplica_iva_destino bit,
							@num_ptmo_destino varchar(14),
							@planx_destino varchar(1),
							@numero_fin_destino int,
							@id_persona_origen int,
							@id_persona_destino int,
							@plazo_destino int,
							@id_tipo_persona_origen int = 1,
							@id_tipo_persona_destino int = 1,
							@tasa_ord_destino float,
							@tasa_mor_destino float,
							@numero_fin_lacp_destino int,
							@id_amortizacion_destino int,
							@id_renovado_destino int,
							@reestructura_destino varchar(1),
							@nombre_s_destino varchar(100),
							@apellido_paterno_destino varchar(100),
							@apellido_materno_destino varchar(100),
							@seguro_vida_destino money,
							@seguro_da�os_destino money,
							@int_mor_destino money,
							@iva_int_mor_destino money,
							@int_ord_ven_destino money,
							@iva_int_ord_ven_destino money,
							@int_ord_vig_destino money,
							@iva_int_ord_vig_destino money,
							@cap_ven_destino money,
							@cap_vig_destino money,
							@int_ord_hoy_destino money,
							@iva_int_ord_hoy_destino money,
							@cap_no_dev_destino money,
							@gastos_cobranza_destino money,
							@iva_gastos_cobranza_destino money,
							@fecha_sistema datetime = getdate(),
							@folio bigint,
							@folio_previo bigint,
							@id_tipo_bitacora int = 23,
							@id_cuenta_origen bigint,
							@id_cuenta_destino bigint,
							@saldo_ahorro_origen money,
							@saldo_inver_origen money,
							@saldo_debito_origen money,
							@liquida_destino bit,
							@hay_excedente_destino bit,
							@al_corriente_destino bit,
							@monto_necesario money,
							@seguro_vida_saldado money = 0,
							@seguro_da�os_saldado money = 0,
							@int_mor_saldado money = 0,
							@iva_int_mor_saldado money = 0,
							@moratorios_mas_iva_saldado money = 0,
							@int_ord_ven_saldado money,
							@iva_int_ord_ven_saldado money,
							@int_ord_vig_saldado money,
							@iva_int_ord_vig_saldado money,
							@cap_ven_saldado money,
							@cap_vig_saldado money,
							@int_ord_hoy_saldado money,
							@iva_int_ord_hoy_saldado money,
							@cap_no_dev_saldado money,
							@gastos_cobranza_saldado money,
							@iva_gastos_cobranza_saldado money,
							@gastos_cobranza_mas_iva_saldado money,
							@no_asignado_destino money,
							@ahorro_base_origen money = 0,
							@respaldo_ahorro money = 0,
							@numusuario int = 6012,
							@monto_tomado_ahorro money = 0,
							@monto_tomado_inver money = 0,
							@monto_tomado_debito money = 0,
							@monto_tomado_efectivo money = 0,
							@monto_tomado_adelanto money = 0,
							@titular_pago varchar(1) = 'T',
							@id_linea_destino bigint,
							@ccostos_origen varchar(10),
							@ccostos_destino varchar(10),
							@pago_mismo_socio bit = 0,
							@MontoOriginalTransaccion decimal(18,2) =0

					-- se agrego para incidencia de compensaciones pagos entre socios de diferentes sucursales - 01/04/2019
					declare  @fecha_ini datetime
							,@fecha_fin datetime		
							,@ccostos_medpa varchar (10) = 'MEDPA'
							,@cta_contable_suc_duena varchar(50)
							,@des_contable_suc_duena varchar(255)
							,@cta_contable_suc_destino varchar(50)
							,@des_contable_suc_destino varchar(255)

					select	identity (int, 1, 1) contador,
							id_persona,
							activo,
							numero,
							nombre_s,
							apellido_paterno,
							apellido_materno,
							total_movs,
							total_ficha,
							id_tipomov,
							cuenta,
							concepto,
							fecha_mov,
							monto,
							id_mov,
							num_poliza,
							tipo_poliza,
							folio,
							id_tipo_persona,
							num_cheq,
							desc1,
							desc2,
							planx,
							desc3,
							fecha_dpf_final,
							num_dpf,
							tasa,
							interes,
							dias,
							debe_haber,
							numusuario,
							numero_fin,
							plazo,
							interes_ord,
							interes_mor,
							contador_provision,
							ccostos,
							nombre_beneficiario,
							parentesco_beneficiario,
							porcentaje_beneficiario,
							nombre_beneficiario2,
							parentesco_beneficiario2,
							porcentaje_beneficiario2,
							numero_fin_lacp,
							id_esquema,
							titular,
							num_ptmo,
							id_amortizacion,
							id_renovado,
							reestructura,
							id_origen,
							id_tipo_pago_prestamo
					into	#captura_previo
					from	hape.dbo.captura
					where	1 = 0

					create table
						#procedimiento_pago_credito
							(
							status			int null,
							error_procedure	varchar(255) null,
							error_line		varchar(255) null,
							error_severity	varchar(255) null,
							error_message	varchar(255) null,
							)

					create table
						#actualiza_edo_de_cuenta_haberes_previo
							(
							numero			int null,
							id_mov			int null,
							saldo_anterior	money null,
							diferencia		money null,
							saldo_posterior	money null,
							fecha			datetime null,
							)

					create table
						#obtiene_saldos
							(
							status						int null,
							saldo_actual				money null,
							interes_moratorio			money null,
							interes_ord_vencido			money null,
							interes_ordinario_vigente	money null,
							capital_vencido				money null,
							capital_corte				money null,
							capital_no_devengado_fin	money null,
							pago_al_corriente			money null,
							saldo_adelanto				money null,
							seguro_vida					money null,
							seguro_danos				money null,
							capitalAmort				money null,
							ivaIntMoratorio				money null,
							ivaIntOrdinarioVencido		money null,
							ivaIntOrdinarioVigente		money null,
							int_moratorio_quitas		money null,
							int_moratorio_quitas_iva	money null,
							int_ordinario_quitas		money null,
							int_ordinario_quitas_iva	money null,
							reserva_capital				money null,
							reserva_interes				money null,
							gastos_cobranza				money null,
							iva_gastos_cobranza			money null,
							tasa_gastos_cobranza		money null,
							primer_corte_vigente		money null
							)

					create table
						#obtiene_saldos_revolvente
							(
							id_linea				bigint null,
							numero					int null,
							id_mov					int null,
							num_ptmo				varchar(14) null,
							planx					varchar(1) null,
							saldo_actual			money null,
							id_estado				int null,
							cv_diaria				bit null,
							fecha_traspaso_CV		datetime null,
							dias_vencidos			int null,
							periodos_vencidos		int null,
							fecha_ultimo_abono		datetime null,
							fecha_ultimo_int_ord	datetime null,
							fecha_ultimo_int_mor	datetime null,
							moratorios				money null,
							iva_moratorios			money null,
							ordinarios_vencidos		money null,
							iva_ordinarios_vencidos	money null,
							ordinarios_corte		money null,
							iva_ordinarios_corte	money null,
							capital_vencido			money null,
							capital_corte			money null,
							ordinarios_al_hoy		money null,
							iva_ordinarios_al_hoy	money null,
							capital_no_devengado	money null,
							pago_minimo				money null,
							pago_minimo_total		money null,
							pago_liquidacion		money null,
							pago_liquidacion_total	money null,
							gastos_cobranza			money null,
							iva_gastos_cobranza		money null,
							tasa_gastos_cobranza	float null,
							seguro_vida				money null,
							seguro_da�os			money null,
							)

					create table
						#sp_cred_obtiene_desglose_monto_a_pagar
							(
							status					int null,
							error_procedure			varchar(255) null,
							error_line				varchar(255) null,
							error_severity			varchar(255) null,
							error_message			varchar(255) null,
							seguro_vida				money null,
							seguro_da�os			money null,
							int_mor					money null,
							iva_int_mor				money null,
							int_ord_ven				money null,
							iva_int_ord_ven			money null,
							int_ord_vig				money null,
							iva_int_ord_vig			money null,
							cap_ven					money null,
							cap_vig					money null,
							int_ord_hoy				money null,
							iva_int_ord_hoy			money null,
							cap_no_dev				money null,
							gastos_cobranza			money null,
							iva_gastos_cobranza		money null,
							tasa_gastos_cobranza	float null,
							monto_a_pagar			money null,
							no_asignado				money null,
							saldo_actual			money null,
							saldo_ahorro			money null,
							saldo_inver				money null,
							saldo_debito			money null,
							)
            
			begin try -- revisar tabla de resultados

				exec (@sql)

				select @standalone = 0

			end try -- revisar tabla de resultados

			begin catch -- revisar tabla de resultados

			     	CREATE TABLE #SP_BANCA_PAGAR_PRESTAMO
					(
							estatus int,
							folio bigint,
							HoraTransaccion datetime,
							Monto money,
							error_procedur varchar(500),
							error_lin varchar(500),
							error_severit varchar(500),
							error_messag varchar(500)
					)

			end catch -- revisar tabla de resultados



				end -- declaraciones
						
				begin -- valores por defecto

					select	@fechaOperacion = coalesce(@fechaOperacion, getdate()),
							@TipoOrigen = coalesce(@TipoOrigen, 3),
							@tipo_poliza = coalesce(@tipo_poliza, 'M'),
							@total_efectivo = -coalesce(@total_efectivo, 0),
							@programada = coalesce(@programada, 0),
							@MontoOriginalTransaccion =@Monto

				end -- valores por defecto

			end -- inicio
			
			begin -- validaciones de par�metros

			
			
				if not exists(select 1 from hape.dbo.tbl_corresponsalias_cuentas where cuenta = @clabeCorresponsaliasRetiro )

					begin -- validar clabe de retiro
											
							select @status = 339
							select @message = 'La clabe [' + @clabeCorresponsaliasRetiro + '] de corresponsal�as proporcionada no existe'
							raiserror (@message, 11, 0)

					end -- validar clabe de retiro

				if not exists(select 1 from hape.dbo.tbl_corresponsalias_cuentas where cuenta = @clabeCorresponsaliasDeposito )

					begin -- validar clabe de dep�sito

							select @status = 339
							select @message = 'La clabe [' + @clabeCorresponsaliasDeposito + '] de corresponsal�as proporcionada no existe'
							raiserror (@message, 11, 0)

					end -- validar clabe de dep�sito
					

				declare
					@id_mov int,
					@numeroSocioDestino int,
					@numeroSocioOrigen int,
					@monto_transferencias_al_dia money,
					@limite_monto_al_dia money 

				SELECT @id_mov = id_mov ,@numeroSocioDestino=  NUMERO FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE  cuenta = @clabeCorresponsaliasDeposito 
				SELECT @numeroSocioOrigen =  NUMERO FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE  cuenta = @clabeCorresponsaliasRetiro 
				---

				IF EXISTS(select * from HAPE..PERSONA where numero = @numeroSocioDestino AND Id_Tipo_Persona = 1 and 
					(Bloqueado_Cobranza = 'A' OR Bloqueado_Exclusion = 'A'))
				begin
						select @status = id_excepcion, @message  = descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 408
						raiserror (@message, 11, 0)
				end
				

				
			

				--===================================	VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS	===============================
					BEGIN
						
						if @monto > (select monto_maximo from TBL_BANCA_CUENTAS_INTERNAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)=@numeroSocioOrigen and clabe_corresponsalias=@clabeCorresponsaliasDeposito and activo=1) 
						begin -- validar monto maximo de transaccion
							select @status = id_excepcion, @message  = descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 321
							raiserror (@message, 11, 0)

						end -- validar monto maximo de transaccion

						declare 
							@fecha_ datetime, 
							@tipoTransferencia int 
							

						if(@programada = 0)
							select @fecha_ = @fechaOperacion
						else
							select @fecha_ = @horaProgramada

						select @tipoTransferencia = case 
							when @numero_origen = @numero_destino then 3	---3.- PAGO DE PRESTAMOS CMV MIS CUENTAS
							else 4 end										---4.- PAGO DE PRESTAMOS CMV OTRAS CUENTAS

						select 
							@status = estatus, @message = msj  
						from  
							FN_VALIDAR_LIMITES_TRANSFERENCIAS_DIARIO (@tipoTransferencia,@numero_origen,@monto,@fecha_,@programada)

						if @status <> 200
						begin
							raiserror (@message, 11, 0)
						end
					END ---VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS


				/*
				select @limite_monto_al_dia = coalesce(maximo,0) from TBL_BANCA_LIMITES_TRANSFERENCIAS where id_limite_transferencia =  1 and activo = 1
					
				---Calculo del monto de transferencia generado al dia de transferencia
				select  @monto_transferencias_al_dia = sum(convert(money,isnull(monto,0)))
				from TBL_BANCA_TRANSFERENCIAS_INTERNAS
				where
					numero_socio = @numeroSocioOrigen
					--and id_estatus_transferencia = 2 --Realizada
					and 
					(
						(convert(varchar,fecha_transferencia_realizada,112) = CONVERT(varchar,@fechaOperacion,112) and @programada=0)
					or 
						(convert(varchar,fecha_programada,112) = CONVERT(varchar,@horaProgramada,112) and @programada=1 )
					)
					--convert(varchar,GETDATE(),112)
				group by numero_socio

				  print '@numero_origen: '+cast( @numeroSocioOrigen as varchar)
				  print '@fechaOperacion: '+  CONVERT(varchar,@fechaOperacion,112)
				  print '@horaProgramada: '+ CONVERT(varchar,@horaProgramada,112) 
				  print '@monto_transferencias_al_dia'+ cast(isnull(@monto_transferencias_al_dia,0) as varchar)
				  print '@monto'+ cast(@monto as varchar)
				  print '@limite_monto_al_dia'+ cast(@limite_monto_al_dia as varchar)

				if (@monto_transferencias_al_dia + isnull(@monto,0)) > @limite_monto_al_dia and 
				(@id_transferencia = 0 OR @id_transferencia is null)--- es para cuando se ejecuta los pagos programados ya no los contemple
					begin -- validar monto maximo de transaccion
					  
						select @status=321
						select @message = descripcion from CAT_BANCA_EXCEPTIONS where id_excepcion =321 --'321|El monto m�ximo de transferencia de la cuenta es excedido.'
						raiserror (@message, 11, 0)
					end -- validar monto maximo de transaccion
				*/

				if(@id_mov between 1 and 9)
				begin
					if not EXISTS (select 1	from hape.dbo.edo_de_cuenta where 	numero=@numeroSocioDestino and id_mov=@id_mov and saldo_actual > 0)
					BEGIN
						select @status = 405
						SELECT @message = descripcion FROM CAT_BANCA_EXCEPTIONS	WHERE id_excepcion = 405
						raiserror (@message, 11, 0)
					END
				END
				

				IF (@numeroSocioDestino  = @numeroSocioOrigen )
					SET @pago_mismo_socio =1
				ELSE
					SET @pago_mismo_socio =0

				print '@pago_mismo_socio = '+cast(@pago_mismo_socio as varchar)
				print '@numeroSocioOrigen = '+cast(@numeroSocioOrigen as varchar)
				print '@@numeroSocioDestino = '+cast(@numeroSocioDestino as varchar)

				if @pago_mismo_socio = 0
				begin -- si el pago es a otro socio del mismo banco
					
					if not exists(select * from TBL_BANCA_CUENTAS_INTERNAS where 
								clabe_corresponsalias=@clabeCorresponsaliasDeposito and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocioOrigen and activo = 1
								and DATEDIFF(MINUTE,fecha_alta,getdate()) > 30
							)
						begin -- validar que la clave corresponsalia de deposito tenga un periodo mayor a 30 minutos despues de haber sido dada de alta

							select @status=339
							select @message = 'Espere el tiempo de registro de la cuenta para poder hacer uso de ella'
							raiserror (@message, 11, 0)

						end -- validar que la clave corresponsalia de deposito tenga un periodo mayor a 30 minutos despues de haber sido dada de alta


					if (@id_mov = 10) and  EXISTS(select 1 from HAPE..TBL_REVOLVENTE_LINEAS_CREDITO where numero  = @numeroSocioDestino and saldo_actual = limite_credito)
					begin
					
						  select @status = id_excepcion , @message = descripcion from CAT_BANCA_EXCEPTIONS where id_excepcion = 408
						  raiserror (@message, 11, 0)
					end

				end 
				else  -- si el pago del prestamo es del mismo socio
				begin
				    print 'no tiene sentido esta validacion'
					--if (@id_mov = 10) and  EXISTS(select 1 from HAPE..TBL_REVOLVENTE_LINEAS_CREDITO where numero  = @numeroSocioOrigen and saldo_actual = limite_credito)
					--	begin
					
					--		  select @status = id_excepcion , @message = descripcion from CAT_BANCA_EXCEPTIONS where id_excepcion = 408
					--		  raiserror (@message, 11, 0)
					--	end
				end

				--if (@id_mov = 10 and @TipoAnticipo != 1)
				--begin -- validar que no se puede realizar un ReduccionPlazo,ReduccionAmortizacion,PagoParaAdelantar
				--	select @status = id_excepcion ,@message = descripcion 	from  CAT_BANCA_EXCEPTIONS 	where id_excepcion = 407
				--	raiserror (@message, 11, 0)
				--end -- validar que no se puede realizar un ReduccionPlazo,ReduccionAmortizacion,PagoParaAdelantar

				
				
				if (@TipoAnticipo = 4 )

					begin -- validar que sea un pago para adelantar

							select @status = id_excepcion ,@message = descripcion 
							from  CAT_BANCA_EXCEPTIONS 
							where id_excepcion = 404
							raiserror (@message, 11, 0)

					end -- validar que sea un pago para adelantar
				
			end -- validaciones de par�metros

			begin -- preparaci�n
			
				begin -- obtener n�mero de p�liza de banca para el d�a

					select	@num_poliza = numpoliza
					from	hape.dbo.tbl_cmv_folios_polizas_procesos
					where	idProcesoPoliza =
								(
								select	idprocesopoliza
								from	hape.dbo.cat_cmv_procesos_polizas
								where	descripcion = 'BANCA ELECTRONICA'
								)
							and dia = day(@fechaOperacion)

				end -- obtener n�mero de p�liza de banca para el d�a

				begin -- recopilar datos de las cuentas

					select	@numero_origen = numero,
							@id_mov_origen = id_mov
					from	hape.dbo.tbl_corresponsalias_cuentas
					where	cuenta = @clabeCorresponsaliasRetiro
							

					insert	#actualiza_edo_de_cuenta_haberes_previo
							(
							numero,
							id_mov,
							saldo_anterior,
							fecha
							)
					select	numero,
							id_mov,
							saldo_actual,
							fecha
					from	hape.dbo.edo_de_cuenta
					where	numero = @numero_origen
							and id_mov in (100, 103, 112)

					select	id_persona,
							numero,
							nombre_s,
							apellido_paterno,
							apellido_materno,
							s.id_de_sucursal,
							ccostos_origen = s.ccostos,
							ccostos_destino = s.ccostos
					into	#persona_
					from	hape.dbo.persona p
								join hape.dbo.sucursales s
									on s.id_de_sucursal = p.id_de_sucursal
					where	numero = @numero_origen
							and id_tipo_persona = 1

					select	@ccostos_origen = ccostos_origen
					from	#persona_

					select	@numero_destino = numero,
							@id_mov_destino = id_mov
					from	hape.dbo.tbl_corresponsalias_cuentas
					where	cuenta = @clabeCorresponsaliasDeposito
							

					select	@saldo_origen = saldo_anterior
					from	#actualiza_edo_de_cuenta_haberes_previo
					where	numero = @numero_origen
							and id_mov = @id_mov_origen

					select	@saldo_ahorro_origen = saldo_anterior,
							@respaldo_ahorro = saldo_anterior
					from	#actualiza_edo_de_cuenta_haberes_previo
					where	id_mov = 100

					select	@saldo_inver_origen = saldo_anterior
					from	#actualiza_edo_de_cuenta_haberes_previo
					where	id_mov = 103

					select	@saldo_debito_origen = saldo_anterior
					from	#actualiza_edo_de_cuenta_haberes_previo
					where	id_mov = 112

					select	@saldo_destino = saldo_actual,
							@id_esquema_destino = id_esquema,
							@saldo_adelanto_destino = saldo_adelanto,
							@aplica_iva_destino = aplica_iva,
							@num_ptmo_destino = num_ptmo,
							@planx_destino = planx,
							@numero_fin_destino = numero_fin,
							@plazo_destino = plazo,
							@tasa_ord_destino = int_ord,
							@tasa_mor_destino = int_mor,
							@numero_fin_lacp_destino = numero_fin_lacp,
							@id_amortizacion_destino = id_amortizacion,
							@id_renovado_destino = id_renovado,
							@reestructura_destino = reestructurado
					from	hape.dbo.edo_de_cuenta
					where	numero = @numero_destino
							and id_mov = @id_mov_destino

					select	@id_persona_origen = id_persona
					from	hape.dbo.persona
					where	numero = @numero_origen
							and id_tipo_persona = @id_tipo_persona_origen

					select	@ccostos_destino = s.Ccostos
					from	hape.dbo.persona p
							join hape.dbo.sucursales s
								on s.Id_de_Sucursal = p.Id_de_Sucursal
					where	numero = @numero_destino
							and Id_Tipo_Persona = 1

					update	#persona_
					set		ccostos_destino = @ccostos_destino

					select	@id_persona_destino = id_persona,
							@nombre_s_destino = Nombre_s,
							@apellido_paterno_destino = Apellido_Paterno,
							@apellido_materno_destino = Apellido_Materno					
					from	hape.dbo.persona
					where	numero = @numero_destino
							and id_tipo_persona = @id_tipo_persona_destino

					if @id_mov_destino = 10

						select	@id_esquema_destino = 4,
								@saldo_adelanto_destino = 0,
								@aplica_iva_destino = 1

				-- obtenemos la cuenta contable de la sucursal del socio origen para compensaciones - 01/04/2019
					select	@cta_contable_suc_duena =	n.Num_Cuenta_Compensacion,
							@des_contable_suc_duena =	n.Concepto
														from	hape.dbo.SUCURSALES s 
																inner join hape.dbo.NUM_SUCURSAL n
																	on n.Num_Sucursal = s.Num_Sucursal
																inner join hape.dbo.PERSONA c
																	on c.Id_de_sucursal = s.Id_de_Sucursal
														where	c.Numero = @numero_origen
															and	c.Id_Tipo_Persona = 1

				-- obtenemos la cuenta contable de la sucursal del socio destino para compensaciones - 01/04/2019
					select	@cta_contable_suc_destino =		n.Num_Cuenta_Compensacion,
							@des_contable_suc_destino =		n.Concepto
															from	hape.dbo.SUCURSALES s 
																	inner join hape.dbo.NUM_SUCURSAL n
																		on n.Num_Sucursal = s.Num_Sucursal
																	inner join hape.dbo.PERSONA c
																		on c.Id_de_sucursal = s.Id_de_Sucursal
															where	c.Numero = @numero_destino
																and	c.Id_Tipo_Persona = 1

				end -- recopilar datos de las cuentas

				begin -- remapear el tipo de anticipo

					select @TipoAnticipo =
						case
							when @TipoAnticipo = 1 -- normal
								then 0
							when @TipoAnticipo = 3 -- reducci�n de amortizaci�n
								then 1
							when @TipoAnticipo = 4 -- adelanto
								then 3
							else
								2 -- anticipo
						end

				end -- remapear el tipo de anticipo

				begin -- determinar tipo de pr�stamo

					if @id_esquema_destino = 1

						select @es_decreciente_destino = 1

					else if @id_esquema_destino in (2, 3)

						select @es_nivelado_destino = 1

					else if @id_esquema_destino = 4

						select @es_revolvente_destino = 1

				end -- determinar tipo de pr�stamo

				begin try -- obtiene saldos

					if @es_decreciente_destino = 1

						begin -- decrecientes

							insert	#obtiene_saldos
									(
									status,
									saldo_actual,
									interes_moratorio,
									interes_ord_vencido,
									interes_ordinario_vigente,
									capital_vencido,
									capital_corte,
									capital_no_devengado_fin,
									pago_al_corriente,
									saldo_adelanto,
									seguro_vida,
									seguro_danos,
									capitalamort,
									ivaintmoratorio,
									ivaintordinariovencido,
									ivaintordinariovigente,
									int_moratorio_quitas,
									int_moratorio_quitas_iva,
									int_ordinario_quitas,
									int_ordinario_quitas_iva,
									reserva_capital,
									reserva_interes,
									gastos_cobranza,
									iva_gastos_cobranza,
									tasa_gastos_cobranza,
									primer_corte_vigente
									)
							exec	hape.dbo.sp_interes_diario_obtiene_saldos
									@numero_destino,
									@id_mov_destino,
									@fechaOperacion,
									1

							select	@seguro_vida_destino = coalesce(seguro_vida, 0),
									@seguro_da�os_destino = coalesce(seguro_danos, 0),
									@int_mor_destino = coalesce(interes_moratorio, 0),
									@iva_int_mor_destino = coalesce(ivaIntMoratorio, 0),
									@int_ord_ven_destino = coalesce(interes_ord_vencido, 0),
									@iva_int_ord_ven_destino = coalesce(ivaIntOrdinarioVencido, 0),
									@int_ord_vig_destino = coalesce(interes_ordinario_vigente, 0),
									@iva_int_ord_vig_destino = coalesce(ivaIntOrdinarioVigente, 0),
									@cap_ven_destino = coalesce(capital_vencido, 0),
									@cap_vig_destino = coalesce(capital_corte, 0),
									@int_ord_hoy_destino = 0,
									@iva_int_ord_hoy_destino = 0,
									@cap_no_dev_destino = coalesce(capital_no_devengado_fin, 0),
									@saldo_adelanto_destino = coalesce(saldo_adelanto, 0)
							from	#obtiene_saldos

						end -- decrecientes

					else if @es_nivelado_destino = 1

						begin -- nivelados
							insert	#obtiene_saldos
									(
									status,
									saldo_actual,
									interes_moratorio,
									interes_ord_vencido,
									interes_ordinario_vigente,
									capital_vencido,
									capital_corte,
									seguro_vida,
									seguro_danos,
									saldo_adelanto,
									pago_al_corriente,
									capital_no_devengado_fin,
									capitalamort,
									ivaintmoratorio,
									ivaintordinariovencido,
									ivaintordinariovigente,
									int_moratorio_quitas,
									int_moratorio_quitas_iva,
									int_ordinario_quitas,
									int_ordinario_quitas_iva,
									reserva_capital,
									reserva_interes,
									gastos_cobranza,
									iva_gastos_cobranza,
									tasa_gastos_cobranza,
									primer_corte_vigente
									)
							exec	hape.dbo.sp_interes_diario_obtiene_saldos_banca_nivelados
									@numero_destino,
									@id_mov_destino,
									@fechaOperacion,
									1


							select	@seguro_vida_destino = coalesce(seguro_vida, 0),
									@seguro_da�os_destino = coalesce(seguro_danos, 0),
									@int_mor_destino = coalesce(interes_moratorio, 0),
									@iva_int_mor_destino = coalesce(ivaIntMoratorio, 0),
									@int_ord_ven_destino = coalesce(interes_ord_vencido, 0),
									@iva_int_ord_ven_destino = coalesce(ivaIntOrdinarioVencido, 0),
									@int_ord_vig_destino = coalesce(interes_ordinario_vigente, 0),
									@iva_int_ord_vig_destino = coalesce(ivaIntOrdinarioVigente, 0),
									@cap_ven_destino = coalesce(capital_vencido, 0),
									@cap_vig_destino = coalesce(capital_corte, 0),
									@int_ord_hoy_destino = 0,
									@iva_int_ord_hoy_destino = 0,
									@cap_no_dev_destino = coalesce(capital_no_devengado_fin, 0),
									@saldo_adelanto_destino = coalesce(saldo_adelanto, 0)
							from	#obtiene_saldos

							
							
						end -- nivelados

					else if @es_revolvente_destino = 1

						begin -- revolventes

							insert	#obtiene_saldos_revolvente
									(
									id_linea,
									numero,
									id_mov,
									num_ptmo,
									planx,
									saldo_actual,
									id_estado,
									cv_diaria,
									fecha_traspaso_CV,
									dias_vencidos,
									periodos_vencidos,
									fecha_ultimo_abono,
									fecha_ultimo_int_ord,
									fecha_ultimo_int_mor,
									moratorios,
									iva_moratorios,
									ordinarios_vencidos,
									iva_ordinarios_vencidos,
									ordinarios_corte,
									iva_ordinarios_corte,
									capital_vencido,
									capital_corte,
									ordinarios_al_hoy,
									iva_ordinarios_al_hoy,
									capital_no_devengado,
									pago_minimo,
									pago_minimo_total,
									pago_liquidacion,
									pago_liquidacion_total,
									gastos_cobranza,
									iva_gastos_cobranza,
									tasa_gastos_cobranza,
									seguro_vida,
									seguro_da�os
									)
							exec	hape.dbo.sp_revolvente_obtiene_saldos
									@numero_destino,
									@fechaOperacion

							select	@id_linea_destino = id_linea,
									@pago_liquidacion_destino = pago_liquidacion_total,
									@pago_al_corriente_destino = pago_minimo_total,
									@saldo_adelanto_destino = 0,
									@num_ptmo_destino = num_ptmo,
									@seguro_vida_destino = coalesce(seguro_vida, 0),
									@seguro_da�os_destino = coalesce(seguro_da�os, 0),
									@int_mor_destino = coalesce(moratorios, 0),
									@iva_int_mor_destino = coalesce(iva_moratorios, 0),
									@int_ord_ven_destino = coalesce(ordinarios_vencidos, 0),
									@iva_int_ord_ven_destino = coalesce(iva_ordinarios_vencidos, 0),
									@int_ord_vig_destino = coalesce(ordinarios_corte, 0),
									@iva_int_ord_vig_destino = coalesce(iva_ordinarios_corte, 0),
									@cap_ven_destino = coalesce(capital_vencido, 0),
									@cap_vig_destino = coalesce(capital_corte, 0),
									@int_ord_hoy_destino = coalesce(ordinarios_al_hoy, 0),
									@iva_int_ord_hoy_destino = coalesce(iva_ordinarios_al_hoy, 0),
									@cap_no_dev_destino = coalesce(capital_no_devengado, 0)
							from	#obtiene_saldos_revolvente

							--if (/*(@pago_al_corriente_destino < @monto or @pago_al_corriente_destino = 0) and*/ @pago_liquidacion_destino != @monto) and @programada = 0

							--	begin

							--		select @status = 407
							--		select @message = descripcion from CAT_BANCA_EXCEPTIONS where id_excepcion = @status
							--		raiserror (@message, 11, 0)

							--	end

						end -- revolventes

				end try 
				begin catch 
					print '**Error en obtiene saldos----'
					select @status = 339
					select @message = 'Error al procesar el pago, intente mas tarde.'
					raiserror (@message, 11, 0)
				end catch  -- obtiene saldos

				begin try -- obtiene desglose de monto a pagar inicial para recuperar pago de liquidaci�n y pago al corriente

					if @es_decreciente_destino = 1

						begin -- decrecientes

							exec hape.dbo.sp_cred_obtiene_desglose_monto_a_pagar

								@numero = @numero_destino,
								@id_mov = @id_mov_destino,
								@num_ptmo = @num_ptmo_destino,
								@monto_a_pagar = null,
								@seguro_vida = @seguro_vida_destino,
								@seguro_da�os = @seguro_da�os_destino,
								@int_mor = @int_mor_destino,
								@iva_int_mor = @iva_int_mor_destino,
								@int_ord_ven = @int_ord_ven_destino,
								@iva_int_ord_ven = @iva_int_ord_ven_destino,
								@int_ord_vig = @int_ord_vig_destino,
								@iva_int_ord_vig = @iva_int_ord_vig_destino,
								@cap_ven = @cap_ven_destino,
								@cap_vig = @cap_vig_destino,
								@int_ord_hoy = @int_ord_hoy_destino,
								@iva_int_ord_hoy = @iva_int_ord_hoy_destino,
								@cap_no_dev = @cap_no_dev_destino,
								@fecha = @fechaOperacion

							select	@seguro_vida_destino = coalesce(seguro_vida, 0),
									@seguro_da�os_destino = coalesce(seguro_da�os, 0),
									@int_mor_destino = coalesce(int_mor, 0),
									@iva_int_mor_destino = coalesce(iva_int_mor, 0),
									@int_ord_ven_destino = coalesce(int_ord_ven, 0),
									@iva_int_ord_ven_destino = coalesce(iva_int_ord_ven, 0),
									@int_ord_vig_destino = coalesce(int_ord_vig, 0),
									@iva_int_ord_vig_destino = coalesce(iva_int_ord_vig, 0),
									@cap_ven_destino = coalesce(cap_ven, 0),
									@cap_vig_destino = coalesce(cap_vig, 0),
									@int_ord_hoy_destino = int_ord_hoy,
									@iva_int_ord_hoy_destino = iva_int_ord_hoy,
									@cap_no_dev_destino = coalesce(cap_no_dev, 0),
									@gastos_cobranza_destino = coalesce(gastos_cobranza, 0),
									@iva_gastos_cobranza_destino = coalesce(iva_gastos_cobranza, 0),
									@pago_liquidacion_destino = coalesce(monto_a_pagar, 0)--,
--									@saldo_ahorro_origen = coalesce(saldo_ahorro, 0),
--									@respaldo_ahorro = coalesce(saldo_ahorro, 0),
--									@saldo_inver_origen = coalesce(saldo_inver, 0),
--									@saldo_debito_origen = coalesce(saldo_debito, 0)
							from	#sp_cred_obtiene_desglose_monto_a_pagar

							select	@pago_al_corriente_destino = @seguro_vida_destino + @seguro_da�os_destino + @int_mor_destino + @iva_int_mor_destino
									+ @int_ord_ven_destino + @iva_int_ord_ven_destino + @int_ord_vig_destino + @iva_int_ord_vig_destino + @cap_ven_destino
									+ @cap_vig_destino + @gastos_cobranza_destino + @iva_gastos_cobranza_destino

						end -- decrecientes

					else if @es_nivelado_destino = 1

						begin -- nivelados

							exec hape.dbo.sp_cred_obtiene_desglose_monto_a_pagar_nivelados
								@numero = @numero_destino,
								@id_mov = @id_mov_destino,
								@num_ptmo = @num_ptmo_destino,
								@monto_a_pagar = null,
								@seguro_vida = @seguro_vida_destino,
								@seguro_da�os = @seguro_da�os_destino,
								@fecha = @fechaOperacion

							select	@seguro_vida_destino = coalesce(seguro_vida, 0),
									@seguro_da�os_destino = coalesce(seguro_da�os, 0),
									@int_mor_destino = coalesce(int_mor, 0),
									@iva_int_mor_destino = coalesce(iva_int_mor, 0),
									@int_ord_ven_destino = coalesce(int_ord_ven, 0),
									@iva_int_ord_ven_destino = coalesce(iva_int_ord_ven, 0),
									@int_ord_vig_destino = coalesce(int_ord_vig, 0),
									@iva_int_ord_vig_destino = coalesce(iva_int_ord_vig, 0),
									@cap_ven_destino = coalesce(cap_ven, 0),
									@cap_vig_destino = coalesce(cap_vig, 0),
									@int_ord_hoy_destino = coalesce(int_ord_hoy, 0),
									@iva_int_ord_hoy_destino = coalesce(iva_int_ord_hoy, 0),
									@cap_no_dev_destino = coalesce(cap_no_dev, 0),
									@gastos_cobranza_destino = coalesce(gastos_cobranza, 0),
									@iva_gastos_cobranza_destino = coalesce(iva_gastos_cobranza, 0),
									@pago_liquidacion_destino = coalesce(monto_a_pagar, 0)--,
									--@saldo_ahorro_origen = coalesce(saldo_ahorro, 0),
									--@respaldo_ahorro = coalesce(saldo_ahorro, 0),
									--@saldo_inver_origen = coalesce(saldo_inver, 0),
									--@saldo_debito_origen = coalesce(saldo_debito, 0)
							from	#sp_cred_obtiene_desglose_monto_a_pagar

							select	@pago_al_corriente_destino = @seguro_vida_destino + @seguro_da�os_destino + @int_mor_destino + @iva_int_mor_destino
									+ @int_ord_ven_destino + @iva_int_ord_ven_destino + @int_ord_vig_destino + @iva_int_ord_vig_destino + @cap_ven_destino
									+ @cap_vig_destino + @gastos_cobranza_destino + @iva_gastos_cobranza_destino

						end -- nivelados

					else if @es_revolvente_destino = 1

						begin -- revolventes

							exec hape.dbo.sp_cred_obtiene_desglose_monto_a_pagar

								@numero = @numero_destino,
								@id_mov = @id_mov_destino,
								@num_ptmo = @num_ptmo_destino,
								@monto_a_pagar = null,
								@seguro_vida = @seguro_vida_destino,
								@seguro_da�os = @seguro_da�os_destino,
								@int_mor = @int_mor_destino,
								@iva_int_mor = @iva_int_mor_destino,
								@int_ord_ven = @int_ord_ven_destino,
								@iva_int_ord_ven = @iva_int_ord_ven_destino,
								@int_ord_vig = @int_ord_vig_destino,
								@iva_int_ord_vig = @iva_int_ord_vig_destino,
								@cap_ven = @cap_ven_destino,
								@cap_vig = @cap_vig_destino,
								@int_ord_hoy = @int_ord_hoy_destino,
								@iva_int_ord_hoy = @iva_int_ord_hoy_destino,
								@cap_no_dev = @cap_no_dev_destino,
								@fecha = @fechaOperacion

							select	@seguro_vida_destino = coalesce(seguro_vida, 0),
									@seguro_da�os_destino = coalesce(seguro_da�os, 0),
									@int_mor_destino = coalesce(int_mor, 0),
									@iva_int_mor_destino = coalesce(iva_int_mor, 0),
									@int_ord_ven_destino = coalesce(int_ord_ven, 0),
									@iva_int_ord_ven_destino = coalesce(iva_int_ord_ven, 0),
									@int_ord_vig_destino = coalesce(int_ord_vig, 0),
									@iva_int_ord_vig_destino = coalesce(iva_int_ord_vig, 0),
									@cap_ven_destino = coalesce(cap_ven, 0),
									@cap_vig_destino = coalesce(cap_vig, 0),
									@int_ord_hoy_destino = coalesce(int_ord_hoy, 0),
									@iva_int_ord_hoy_destino = coalesce(iva_int_ord_hoy, 0),
									@cap_no_dev_destino = coalesce(cap_no_dev, 0),
									@gastos_cobranza_destino = coalesce(gastos_cobranza, 0),
									@iva_gastos_cobranza_destino = coalesce(iva_gastos_cobranza, 0),
									@pago_liquidacion_destino = coalesce(monto_a_pagar, 0)--,
									--@saldo_ahorro_origen = coalesce(saldo_ahorro, 0),
									--@respaldo_ahorro = coalesce(saldo_ahorro, 0),
									--@saldo_inver_origen = coalesce(saldo_inver, 0),
									--@saldo_debito_origen = coalesce(saldo_debito, 0)
							from	#sp_cred_obtiene_desglose_monto_a_pagar

							select	@pago_al_corriente_destino = @seguro_vida_destino + @seguro_da�os_destino + @int_mor_destino + @iva_int_mor_destino
									+ @int_ord_ven_destino + @iva_int_ord_ven_destino + @int_ord_vig_destino + @iva_int_ord_vig_destino + @cap_ven_destino
									+ @cap_vig_destino + @gastos_cobranza_destino + @iva_gastos_cobranza_destino

						end -- revolventes 
				end try 
				begin catch 
					print '**Error en obtiene desglose de monto a pagar inicial para recuperar pago de liquidaci�n y pago al corriente----'
					select @status = 339
					select @message = 'Error al procesar el pago, intente mas tarde.'
					raiserror (@message, 11, 0)
				end catch  -- obtiene desglose de monto a pagar inicial para recuperar pago de liquidaci�n y pago al corriente

				begin -- determinantes

					begin -- excedente de liquidaci�n

						if @monto + @saldo_adelanto_destino > @pago_liquidacion_destino

							select @monto = @pago_liquidacion_destino - @saldo_adelanto_destino

					end -- excedente de liquidaci�n

					begin -- liquidaci�n

						if @monto + @saldo_adelanto_destino = @pago_liquidacion_destino

							select @liquida_destino = 1

						else

							select @liquida_destino = 0

					end -- liquidaci�n

					begin -- hay excedente sobre pago al corriente

						if @monto > @pago_al_corriente_destino

							select	@hay_excedente_destino = 1,
									@al_corriente_destino = 1

						else

							select @hay_excedente_destino = 0

					end -- hay excedente sobre pago al corriente


					begin -- pago al corriente

						if @monto !< @pago_al_corriente_destino

							select @al_corriente_destino = 1

						else

							select @al_corriente_destino = 0

					end -- paga justo al corriente

					begin -- ajustar tipo de anticipo si es necesario

						if @liquida_destino = 1

							begin -- ajustar para liquidaci�n

								if @cap_no_dev_destino > 0

									select @TipoAnticipo = 2

								else

									select @TipoAnticipo = 0

							end -- ajustar para liquidaci�n

						else if @hay_excedente_destino = 1 and @TipoAnticipo not in (1, 2, 3)

							begin -- ajustar para excedente no reconocido por default

								select @TipoAnticipo = 1 -------------------- default recorte de amortizaci�n?

							end -- ajustar para excedente no reconocido por default

						else if @hay_excedente_destino = 0 and @TipoAnticipo in (1, 2)

							begin -- ajustar para pago normal

								select @TipoAnticipo = 0

							end -- ajustar para pago normal

					end -- ajustar tipo de anticipo si es necesario

					begin -- ajustar monto necesario que considere el saldo de adelanto para liquidaciones

						select @monto_necesario = @monto + case when @liquida_destino = 1 then @saldo_adelanto_destino else 0 end

					end -- ajustar monto necesario que considere el saldo de adelanto para liquidaciones

					--select	monto = @monto,
					--		monto_necesario = @monto_necesario,
					--		saldo_adelanto = @saldo_adelanto_destino,
					--		pago_liquidacion = @pago_liquidacion_destino,
					--		liquida = @liquida_destino,
					--		hay_excedente_destino = @hay_excedente_destino,
					--		al_corriente_destino = @al_corriente_destino,
					--		tipo_anticipo = @TipoAnticipo
					--		-----------------------------------------------

					------------------------- aqu� me qued�

					--select @monto, @monto_necesario, @saldo_adelanto_destino----------------

				end -- determinantes

				begin try -- obtiene desglose de monto a pagar con proyecci�n del saldado

					if @es_decreciente_destino = 1

						begin -- decrecientes

							exec hape.dbo.sp_cred_obtiene_desglose_monto_a_pagar

								@numero = @numero_destino,
								@id_mov = @id_mov_destino,
								@num_ptmo = @num_ptmo_destino,
								@monto_a_pagar = @monto_necesario,
								@seguro_vida = @seguro_vida_destino,
								@seguro_da�os = @seguro_da�os_destino,
								@int_mor = @int_mor_destino,
								@iva_int_mor = @iva_int_mor_destino,
								@int_ord_ven = @int_ord_ven_destino,
								@iva_int_ord_ven = @iva_int_ord_ven_destino,
								@int_ord_vig = @int_ord_vig_destino,
								@iva_int_ord_vig = @iva_int_ord_vig_destino,
								@cap_ven = @cap_ven_destino,
								@cap_vig = @cap_vig_destino,
								@int_ord_hoy = @int_ord_hoy_destino,
								@iva_int_ord_hoy = @iva_int_ord_hoy_destino,
								@cap_no_dev = @cap_no_dev_destino,
								@fecha = @fechaOperacion

							select	@seguro_vida_saldado = coalesce(seguro_vida, 0),
									@seguro_da�os_saldado = coalesce(seguro_da�os, 0),
									@int_mor_saldado = coalesce(int_mor, 0),
									@iva_int_mor_saldado = coalesce(iva_int_mor, 0),
									@int_ord_ven_saldado = coalesce(int_ord_ven, 0),
									@iva_int_ord_ven_saldado = coalesce(iva_int_ord_ven, 0),
									@int_ord_vig_saldado = coalesce(int_ord_vig, 0),
									@iva_int_ord_vig_saldado = coalesce(iva_int_ord_vig, 0),
									@cap_ven_saldado = coalesce(cap_ven, 0),
									@cap_vig_saldado = coalesce(cap_vig, 0),
									@int_ord_hoy_saldado = int_ord_hoy,
									@iva_int_ord_hoy_saldado = iva_int_ord_hoy,
									@cap_no_dev_saldado = coalesce(cap_no_dev, 0),
									@gastos_cobranza_saldado = coalesce(gastos_cobranza, 0),
									@iva_gastos_cobranza_saldado = coalesce(iva_gastos_cobranza, 0),
									--@saldo_ahorro_origen = coalesce(saldo_ahorro, 0),
									--@respaldo_ahorro = coalesce(saldo_ahorro, 0),
									--@saldo_inver_origen = coalesce(saldo_inver, 0),
									--@saldo_debito_origen = coalesce(saldo_debito, 0),
									@no_asignado_destino = coalesce(no_asignado, 0)
							from	#sp_cred_obtiene_desglose_monto_a_pagar

						end -- decrecientes

					else if @es_nivelado_destino = 1

						begin -- nivelados

							exec hape.dbo.sp_cred_obtiene_desglose_monto_a_pagar_nivelados
								@numero = @numero_destino,
								@id_mov = @id_mov_destino,
								@num_ptmo = @num_ptmo_destino,
								@monto_a_pagar = @monto_necesario,
								@seguro_vida = @seguro_vida_destino,
								@seguro_da�os = @seguro_da�os_destino,
								@fecha = @fechaOperacion

							select	@seguro_vida_saldado = coalesce(seguro_vida, 0),
									@seguro_da�os_saldado = coalesce(seguro_da�os, 0),
									@int_mor_saldado = coalesce(int_mor, 0),
									@iva_int_mor_saldado = coalesce(iva_int_mor, 0),
									@int_ord_ven_saldado = coalesce(int_ord_ven, 0),
									@iva_int_ord_ven_saldado = coalesce(iva_int_ord_ven, 0),
									@int_ord_vig_saldado = coalesce(int_ord_vig, 0),
									@iva_int_ord_vig_saldado = coalesce(iva_int_ord_vig, 0),
									@cap_ven_saldado = coalesce(cap_ven, 0),
									@cap_vig_saldado = coalesce(cap_vig, 0),
									@int_ord_hoy_saldado = int_ord_hoy,
									@iva_int_ord_hoy_saldado = iva_int_ord_hoy,
									@cap_no_dev_saldado = coalesce(cap_no_dev, 0),
									@gastos_cobranza_saldado = coalesce(gastos_cobranza, 0),
									@iva_gastos_cobranza_saldado = coalesce(iva_gastos_cobranza, 0),
									--@saldo_ahorro_origen = coalesce(saldo_ahorro, 0),
									--@respaldo_ahorro = coalesce(saldo_ahorro, 0),
									--@saldo_inver_origen = coalesce(saldo_inver, 0),
									--@saldo_debito_origen = coalesce(saldo_debito, 0),
									@no_asignado_destino = coalesce(no_asignado, 0)
							from	#sp_cred_obtiene_desglose_monto_a_pagar

							IF @no_asignado_destino != 0 and @programada  = 0 /*  incidencia 1011 12 de marzo 2019*/
							BEGIN
								SELECT @message = descripcion , @status = id_excepcion FROM CAT_BANCA_EXCEPTIONS	WHERE id_excepcion = 406
								raiserror (@message, 11, 0)
					
							END

--						select @monto, @monto_necesario -----------


							begin -- ajustar a pagos completos si no hay excedente para anticipar en nivelados

							if @no_asignado_destino > 0 and @liquida_destino = 0 and @hay_excedente_destino = 0 and @TipoAnticipo != 3

								select @monto -= @no_asignado_destino, @monto_necesario -= @no_asignado_destino

							end -- ajustar a pagos completos si no hay excedente para anticipar en nivelados



						end -- nivelados

					else if @es_revolvente_destino = 1

						begin -- revolventes

							exec hape.dbo.sp_cred_obtiene_desglose_monto_a_pagar

								@numero = @numero_destino,
								@id_mov = @id_mov_destino,
								@num_ptmo = @num_ptmo_destino,
								@monto_a_pagar = @monto_necesario,
								@seguro_vida = @seguro_vida_destino,
								@seguro_da�os = @seguro_da�os_destino,
								@int_mor = @int_mor_destino,
								@iva_int_mor = @iva_int_mor_destino,
								@int_ord_ven = @int_ord_ven_destino,
								@iva_int_ord_ven = @iva_int_ord_ven_destino,
								@int_ord_vig = @int_ord_vig_destino,
								@iva_int_ord_vig = @iva_int_ord_vig_destino,
								@cap_ven = @cap_ven_destino,
								@cap_vig = @cap_vig_destino,
								@int_ord_hoy = @int_ord_hoy_destino,
								@iva_int_ord_hoy = @iva_int_ord_hoy_destino,
								@cap_no_dev = @cap_no_dev_destino,
								@fecha = @fechaOperacion

							select	@seguro_vida_saldado = coalesce(seguro_vida, 0),
									@seguro_da�os_saldado = coalesce(seguro_da�os, 0),
									@int_mor_saldado = coalesce(int_mor, 0),
									@iva_int_mor_saldado = coalesce(iva_int_mor, 0),
									@int_ord_ven_saldado = coalesce(int_ord_ven, 0),
									@iva_int_ord_ven_saldado = coalesce(iva_int_ord_ven, 0),
									@int_ord_vig_saldado = coalesce(int_ord_vig, 0),
									@iva_int_ord_vig_saldado = coalesce(iva_int_ord_vig, 0),
									@cap_ven_saldado = coalesce(cap_ven, 0),
									@cap_vig_saldado = coalesce(cap_vig, 0),
									@int_ord_hoy_saldado = int_ord_hoy,
									@iva_int_ord_hoy_saldado = iva_int_ord_hoy,
									@cap_no_dev_saldado = coalesce(cap_no_dev, 0),
									@gastos_cobranza_saldado = coalesce(gastos_cobranza, 0),
									@iva_gastos_cobranza_saldado = coalesce(iva_gastos_cobranza, 0),
									--@saldo_ahorro_origen = coalesce(saldo_ahorro, 0),
									--@respaldo_ahorro = coalesce(saldo_ahorro, 0),
									--@saldo_inver_origen = coalesce(saldo_inver, 0),
									--@saldo_debito_origen = coalesce(saldo_debito, 0),
									@no_asignado_destino = coalesce(no_asignado, 0)
							from	#sp_cred_obtiene_desglose_monto_a_pagar

						end -- revolventes

				end try 
				begin catch 
					print '**Obtiene desglose de monto a pagar con proyecci�n del saldado----'
					select @status = 339
					select @message = 'Error al procesar el pago, intente mas tarde.'
					raiserror (@message, 11, 0)
				end catch -- obtiene desglose de monto a pagar con proyecci�n del saldado

--						select @monto, @monto_necesario -----------


				begin -- revisar ahorro comprometido del origen en caso que sea retiro del ahorro

					if @id_mov_origen = 100

						begin

							select	@ahorro_base_origen = sum(ahorro_base)
							from	(
									select	ahorro_base = cast(coalesce(ahorro_base, 0) as money)
									from	hape.dbo.edo_de_cuenta
									where	numero = @numero_origen
											and id_mov < 100
											and saldo_actual > 0
									) _

							select @ahorro_base_origen = coalesce(@ahorro_base_origen, 0)

							if @ahorro_base_origen > 0

								select @saldo_ahorro_origen -= @ahorro_base_origen

							if @saldo_ahorro_origen < 0

								select @saldo_ahorro_origen = 0

							select @saldo_origen = @saldo_ahorro_origen

						end


				end -- revisar ahorro comprometido del origen en caso que sea retiro del ahorro

				begin -- determinar cantidades a tomar en haberes

					if @id_persona_origen = @id_persona_destino

						begin -- si son cuentas de la misma persona

							select	@monto_tomado_ahorro = 0,
									@monto_tomado_inver = 0,
									@monto_tomado_debito = 0,
									@monto_tomado_efectivo = 0,
									@monto_tomado_adelanto = case when @liquida_destino = 1 then -@saldo_adelanto_destino else 0 end

							if @id_mov_origen = 100

								select	@monto_tomado_ahorro = -@monto
										
							else if @id_mov_origen = 103

								select	@monto_tomado_inver = -@monto

							else if @id_mov_origen = 112

								select	@monto_tomado_debito = -@monto

						end -- si son cuentas de la misma persona

					else

						begin -- no son cuentas de la misma persona

							select	@monto_tomado_ahorro = 0,
									@monto_tomado_inver = 0,
									@monto_tomado_debito = 0,
									@monto_tomado_efectivo = -@monto,
									@monto_tomado_adelanto = case when @liquida_destino = 1 then -@saldo_adelanto_destino else 0 end

						end -- no son cuentas de la misma persona

				end -- determinar cantidades a tomar en haberes

				begin -- determinar gastos de cobranza saldados con inva

					select @gastos_cobranza_mas_iva_saldado = @gastos_cobranza_saldado + @iva_gastos_cobranza_saldado

					select @moratorios_mas_iva_saldado = @int_mor_saldado + @iva_int_mor_saldado

				end -- determinar gastos de cobranza saldados con inva

				begin -- preparar captura adicional en caso de que sea al pago de un socio distinto

					if @id_persona_origen != @id_persona_destino

						begin -- ajuste del titular para el pago a cr�dito

							select @titular_pago = 'F'

						end -- ajuste del titular para el pago a cr�dito

						begin -- si cuenta de origen y cuenta de destino son de distintas personas

							if @programada = 0

								begin -- si no est� programada

									if @id_mov_origen = 100

										begin -- ahorro

											insert	#captura_previo
													(
													id_persona,
													activo,
													numero,
													nombre_s,
													apellido_paterno,
													apellido_materno,
													total_movs,
													total_ficha,
													id_tipomov,
													cuenta,
													concepto,
													fecha_mov,
													monto,
													id_mov,
													num_poliza,
													tipo_poliza,
													folio,
													id_tipo_persona,
													num_cheq,
													desc1,
													desc2,
													planx,
													desc3,
													fecha_dpf_final,
													num_dpf,
													tasa,
													interes,
													dias,
													debe_haber,
													numusuario,
													numero_fin,
													plazo,
													interes_ord,
													interes_mor,
													contador_provision,
													ccostos,
													nombre_beneficiario,
													parentesco_beneficiario,
													porcentaje_beneficiario,
													nombre_beneficiario2,
													parentesco_beneficiario2,
													porcentaje_beneficiario2,
													numero_fin_lacp,
													id_esquema,
													titular,
													num_ptmo,
													id_amortizacion,
													id_renovado,
													reestructura,
													id_origen
													)

											select	id_persona,
													'T',
													p.numero,
													nombre_s,
													apellido_paterno,
													apellido_materno,
													total_movs = 0,
													total_ficha = 0,
													tm.id_tipomov,
													cuenta = cc.num_cuenta,
													concepto = tm.descripcion,
													fecha_mov = @fechaOperacion,
													monto = abs(@monto),
													tm.id_mov,
													num_poliza = @num_poliza,
													tipo_poliza = @tipo_poliza,
													folio = @folio_previo,
													id_tipo_persona = 1,
													num_cheq = 0,
													desc1 = 0,
													desc2 = 0,
													planx = @planx_destino,
													desc3 = 0,
													fecha_dpf_final = cast(@fechaOperacion as date),
													num_dpf = 0,
													tasa = 0,
													interes = 0,
													dias = 0,
													debe_haber = 'D',
													numusuario = @numusuario,
													numero_fin = @numero_fin_destino,
													plazo = @plazo_destino,
													interes_ord = @tasa_ord_destino,
													interes_mor = @tasa_mor_destino,
													contador_provision = 0,
													p.ccostos_origen,
													nombre_beneficiario = '',
													parentesco_beneficiario = '',
													porcentaje_beneficiario = 0,
													nombre_beneficiario2 = '',
													parentesco_beneficiario2 = '',
													porcentaje_beneficiario2 = 0,
													numero_fin_lacp = @numero_fin_lacp_destino,
													id_esquema = 1,
													titular = 'T',
													num_ptmo = @num_ptmo_destino,
													id_amortizacion = @id_amortizacion_destino,
													id_renovado = @id_renovado_destino,
													reestructura = @reestructura_destino,
													id_origen = 3
											from	#persona_ p
													join hape.dbo.tipo_mov tm
														on tm.id_mov = 100
														and tm.id_tipomov = 310
													join hape.dbo.cuentas_contables cc
														on cc.concepto like '%ahorro%socios'
														and cc.num_cuenta like '212%'
										end -- ahorro

									else if @id_mov_origen = 103

										begin -- inverdin�mica

											insert	#captura_previo
													(
													id_persona,
													activo,
													numero,
													nombre_s,
													apellido_paterno,
													apellido_materno,
													total_movs,
													total_ficha,
													id_tipomov,
													cuenta,
													concepto,
													fecha_mov,
													monto,
													id_mov,
													num_poliza,
													tipo_poliza,
													folio,
													id_tipo_persona,
													num_cheq,
													desc1,
													desc2,
													planx,
													desc3,
													fecha_dpf_final,
													num_dpf,
													tasa,
													interes,
													dias,
													debe_haber,
													numusuario,
													numero_fin,
													plazo,
													interes_ord,
													interes_mor,
													contador_provision,
													ccostos,
													nombre_beneficiario,
													parentesco_beneficiario,
													porcentaje_beneficiario,
													nombre_beneficiario2,
													parentesco_beneficiario2,
													porcentaje_beneficiario2,
													numero_fin_lacp,
													id_esquema,
													titular,
													num_ptmo,
													id_amortizacion,
													id_renovado,
													reestructura,
													id_origen
													)

											select	id_persona,
													'T',
													p.numero,
													nombre_s,
													apellido_paterno,
													apellido_materno,
													total_movs = 0,
													total_ficha = 0,
													tm.id_tipomov,
													cuenta = cc.num_cuenta,
													concepto = tm.descripcion,
													fecha_mov = @fechaOperacion,
													monto = abs(@monto),
													tm.id_mov,
													num_poliza = @num_poliza,
													tipo_poliza = @tipo_poliza,
													folio = @folio_previo,
													id_tipo_persona = 1,
													num_cheq = 0,
													desc1 = 0,
													desc2 = 0,
													planx = @planx_destino,
													desc3 = 0,
													fecha_dpf_final = cast(@fechaOperacion as date),
													num_dpf = 0,
													tasa = 0,
													interes = 0,
													dias = 0,
													debe_haber = 'D',
													numusuario = @numusuario,
													numero_fin = @numero_fin_destino,
													plazo = @plazo_destino,
													interes_ord = @tasa_ord_destino,
													interes_mor = @tasa_mor_destino,
													contador_provision = 0,
													p.ccostos_origen,
													nombre_beneficiario = '',
													parentesco_beneficiario = '',
													porcentaje_beneficiario = 0,
													nombre_beneficiario2 = '',
													parentesco_beneficiario2 = '',
													porcentaje_beneficiario2 = 0,
													numero_fin_lacp = @numero_fin_lacp_destino,
													id_esquema = 1,
													titular = 'T',
													num_ptmo = @num_ptmo_destino,
													id_amortizacion = @id_amortizacion_destino,
													id_renovado = @id_renovado_destino,
													reestructura = @reestructura_destino,
													id_origen = 3
											from	#persona_ p
													join hape.dbo.tipo_mov tm
														on tm.id_mov = 103
														and tm.id_tipomov = 350
													join hape.dbo.cuentas_contables cc
														on cc.concepto like '%vista'
														and cc.num_cuenta like '211%'

										end -- inverdin�mica

									else if @id_mov_origen = 112

										begin -- d�bito

											insert	#captura_previo
													(
													id_persona,
													activo,
													numero,
													nombre_s,
													apellido_paterno,
													apellido_materno,
													total_movs,
													total_ficha,
													id_tipomov,
													cuenta,
													concepto,
													fecha_mov,
													monto,
													id_mov,
													num_poliza,
													tipo_poliza,
													folio,
													id_tipo_persona,
													num_cheq,
													desc1,
													desc2,
													planx,
													desc3,
													fecha_dpf_final,
													num_dpf,
													tasa,
													interes,
													dias,
													debe_haber,
													numusuario,
													numero_fin,
													plazo,
													interes_ord,
													interes_mor,
													contador_provision,
													ccostos,
													nombre_beneficiario,
													parentesco_beneficiario,
													porcentaje_beneficiario,
													nombre_beneficiario2,
													parentesco_beneficiario2,
													porcentaje_beneficiario2,
													numero_fin_lacp,
													id_esquema,
													titular,
													num_ptmo,
													id_amortizacion,
													id_renovado,
													reestructura,
													id_origen
													)

											select	id_persona,
													'T',
													p.numero,
													nombre_s,
													apellido_paterno,
													apellido_materno,
													total_movs = 0,
													total_ficha = 0,
													tm.id_tipomov,
													cuenta = cc.num_cuenta,
													concepto = tm.descripcion,
													fecha_mov = @fechaOperacion,
													monto = abs(@monto),
													tm.id_mov,
													num_poliza = @num_poliza,
													tipo_poliza = @tipo_poliza,
													folio = @folio_previo,
													id_tipo_persona = 1,
													num_cheq = 0,
													desc1 = 0,
													desc2 = 0,
													planx = @planx_destino,
													desc3 = 0,
													fecha_dpf_final = cast(@fechaOperacion as date),
													num_dpf = 0,
													tasa = 0,
													interes = 0,
													dias = 0,
													debe_haber = 'D',
													numusuario = @numusuario,
													numero_fin = @numero_fin_destino,
													plazo = @plazo_destino,
													interes_ord = @tasa_ord_destino,
													interes_mor = @tasa_mor_destino,
													contador_provision = 0,
													p.ccostos_origen,
													nombre_beneficiario = '',
													parentesco_beneficiario = '',
													porcentaje_beneficiario = 0,
													nombre_beneficiario2 = '',
													parentesco_beneficiario2 = '',
													porcentaje_beneficiario2 = 0,
													numero_fin_lacp = @numero_fin_lacp_destino,
													id_esquema = 1,
													titular = 'T',
													num_ptmo = @num_ptmo_destino,
													id_amortizacion = @id_amortizacion_destino,
													id_renovado = @id_renovado_destino,
													reestructura = @reestructura_destino,
													id_origen = 3
											from	#persona_ p
													join hape.dbo.tipo_mov tm
														on tm.id_mov = 112
														and tm.id_tipomov = 1001
													join hape.dbo.cuentas_contables cc
														on cc.concepto like 'debito%'
														and cc.num_cuenta like '216%'

										end -- d�bito

									begin -- cajas
										-- se comenta por que no deberia haber flujo de efectivo en las transacciones de banca
										--insert	#captura_previo
										--		(
										--		id_persona,
										--		activo,
										--		numero,
										--		nombre_s,
										--		apellido_paterno,
										--		apellido_materno,
										--		total_movs,
										--		total_ficha,
										--		id_tipomov,
										--		cuenta,
										--		concepto,
										--		fecha_mov,
										--		monto,
										--		id_mov,
										--		num_poliza,
										--		tipo_poliza,
										--		folio,
										--		id_tipo_persona,
										--		num_cheq,
										--		desc1,
										--		desc2,
										--		planx,
										--		desc3,
										--		fecha_dpf_final,
										--		num_dpf,
										--		tasa,
										--		interes,
										--		dias,
										--		debe_haber,
										--		numusuario,
										--		numero_fin,
										--		plazo,
										--		interes_ord,
										--		interes_mor,
										--		contador_provision,
										--		ccostos,
										--		nombre_beneficiario,
										--		parentesco_beneficiario,
										--		porcentaje_beneficiario,
										--		nombre_beneficiario2,
										--		parentesco_beneficiario2,
										--		porcentaje_beneficiario2,
										--		numero_fin_lacp,
										--		id_esquema,
										--		titular,
										--		num_ptmo,
										--		id_amortizacion,
										--		id_renovado,
										--		reestructura,
										--		id_origen
										--		)

										--select	id_persona,
										--		'T',
										--		p.numero,
										--		nombre_s,
										--		apellido_paterno,
										--		apellido_materno,
										--		total_movs = 0,
										--		total_ficha = 0,
										--		id_tipomov = 961,
										--		cuenta = cc.num_cuenta,
										--		concepto = 'Cajas',
										--		fecha_mov = @fechaOperacion,
										--		monto = 0.0,--abs(@monto),
										--		id_mov = null,
										--		num_poliza = @num_poliza,
										--		tipo_poliza = @tipo_poliza,
										--		folio = @folio_previo,
										--		id_tipo_persona = 1,
										--		num_cheq = 0,
										--		desc1 = 0,
										--		desc2 = 0,
										--		planx = @planx_destino,
										--		desc3 = 0,
										--		fecha_dpf_final = cast(@fechaOperacion as date),
										--		num_dpf = 0,
										--		tasa = 0,
										--		interes = 0,
										--		dias = 0,
										--		debe_haber = 'H',
										--		numusuario = @numusuario,
										--		numero_fin = @numero_fin_destino,
										--		plazo = @plazo_destino,
										--		interes_ord = @tasa_ord_destino,
										--		interes_mor = @tasa_mor_destino,
										--		contador_provision = 0,
										--		p.ccostos_origen,
										--		nombre_beneficiario = '',
										--		parentesco_beneficiario = '',
										--		porcentaje_beneficiario = 0,
										--		nombre_beneficiario2 = '',
										--		parentesco_beneficiario2 = '',
										--		porcentaje_beneficiario2 = 0,
										--		numero_fin_lacp = @numero_fin_lacp_destino,
										--		id_esquema = 1,
										--		titular = 'T',
										--		num_ptmo = @num_ptmo_destino,
										--		id_amortizacion = @id_amortizacion_destino,
										--		id_renovado = @id_renovado_destino,
										--		reestructura = @reestructura_destino,
										--		id_origen = 3
										--from	#persona_ p
										--		join hape.dbo.cuentas_contables cc
										--			on concepto like 'caja'
										--			and num_cuenta like '111%'
										
										-- cta compensacion sucursal destino en lugar del registro de flujo de efectivo
										insert	#captura_previo
												(
												id_persona,
												activo,
												numero,
												nombre_s,
												apellido_paterno,
												apellido_materno,
												total_movs,
												total_ficha,
												id_tipomov,
												cuenta,
												concepto,
												fecha_mov,
												monto,
												id_mov,
												num_poliza,
												tipo_poliza,
												folio,
												id_tipo_persona,
												num_cheq,
												desc1,
												desc2,
												planx,
												desc3,
												fecha_dpf_final,
												num_dpf,
												tasa,
												interes,
												dias,
												debe_haber,
												numusuario,
												numero_fin,
												plazo,
												interes_ord,
												interes_mor,
												contador_provision,
												ccostos,
												nombre_beneficiario,
												parentesco_beneficiario,
												porcentaje_beneficiario,
												nombre_beneficiario2,
												parentesco_beneficiario2,
												porcentaje_beneficiario2,
												numero_fin_lacp,
												id_esquema,
												titular,
												num_ptmo,
												id_amortizacion,
												id_renovado,
												reestructura,
												id_origen
												)

										select	id_persona,
												'T',
												p.numero,
												nombre_s,
												apellido_paterno,
												apellido_materno,
												total_movs = 0,
												total_ficha = 0,
												id_tipomov = 0,
												cuenta = @cta_contable_suc_destino,
												concepto = @des_contable_suc_destino,--'Dep�sito al  Ahorro CMV',
												fecha_mov = @fechaOperacion,
												monto = abs(@monto),
												id_mov = null,
												num_poliza = @num_poliza,
												tipo_poliza = @tipo_poliza,
												folio = @folio_previo,
												id_tipo_persona = 1,
												num_cheq = 0,
												desc1 = 0,
												desc2 = 0,
												planx = @planx_destino,
												desc3 = 0,
												fecha_dpf_final = cast(@fechaOperacion as date),
												num_dpf = 0,
												tasa = 0,
												interes = 0,
												dias = 0,
												debe_haber = 'H',
												numusuario = @numusuario,
												numero_fin = @numero_fin_destino,
												plazo = @plazo_destino,
												interes_ord = @tasa_ord_destino,
												interes_mor = @tasa_mor_destino,
												contador_provision = 0,
												p.ccostos_origen,
												nombre_beneficiario = '',
												parentesco_beneficiario = '',
												porcentaje_beneficiario = 0,
												nombre_beneficiario2 = '',
												parentesco_beneficiario2 = '',
												porcentaje_beneficiario2 = 0,
												numero_fin_lacp = @numero_fin_lacp_destino,
												id_esquema = 1,
												titular = 'T',
												num_ptmo = @num_ptmo_destino,
												id_amortizacion = @id_amortizacion_destino,
												id_renovado = @id_renovado_destino,
												reestructura = @reestructura_destino,
												id_origen = 3
										from	#persona_ p

									end -- cajas


									begin -- actualizar totales

										update	c
										set		c.total_movs = _.count_,
												c.total_ficha = abs(@monto)
										from	(
												select	count(1) count_
												from	#captura_previo
												) _
												cross join #captura_previo c

									end -- actualizar totales

								end -- si no est� programada

						end -- si cuenta de origen y cuenta de destino son de distintas personas

				end -- preparar captura adicional en caso de que sea al pago de un socio distinto

				--select * from #captura_previo

				-- BREAKPOINT

				--select	pago_al_corriente = @pago_al_corriente_destino, pago_liquidacion = @pago_liquidacion_destino,
				--		numero = @numero_destino, id_mov = @id_mov_destino, num_ptmo = @num_ptmo_destino,
				--		seguro_vida = @seguro_vida_destino, seguro_da�os = @seguro_da�os_destino, int_mor = @int_mor_destino,
				--		iva_int_mor = @iva_int_mor_destino, int_ord_ven = @int_ord_ven_destino, iva_int_ord_ven = @iva_int_ord_ven_destino,
				--		int_ord_vig = @int_ord_vig_destino, iva_int_ord_vig = @iva_int_ord_vig_destino, cap_ven = @cap_ven_destino,
				--		cap_vig = @cap_vig_destino, int_ord_hoy = @int_ord_hoy_destino, iva_int_ord_hoy = @iva_int_ord_hoy_destino,
				--		cap_no_dev = @cap_no_dev_destino, gastos_cobranza = @gastos_cobranza_destino, iva_gastos_cobranza = @iva_gastos_cobranza_destino,
				--		fecha = @fechaOperacion, saldo_adelanto_destino = @saldo_adelanto_destino, saldo_ahorro_disponible_origen = @saldo_ahorro_origen,
				--		saldo_ahorro_comprometido_origen = @ahorro_base_origen, saldo_inver_origen = @saldo_inver_origen, saldo_debito_origen = @saldo_debito_origen,
				--		seguro_vida_saldado = @seguro_vida_saldado, seguro_da�os_saldado = @seguro_da�os_saldado, int_mor_saldado = @int_mor_saldado,
				--		iva_int_mor_saldado = @iva_int_mor_saldado, int_ord_ven_saldado = @int_ord_ven_saldado, iva_int_ord_ven_saldado = @iva_int_ord_ven_saldado,
				--		int_ord_vig = @int_ord_vig_destino, iva_int_ord_vig = @iva_int_ord_vig_destino, cap_ven = @cap_ven_destino,
				--		cap_vig_saldado = @cap_vig_saldado, int_ord_hoy_saldado = @int_ord_hoy_saldado, iva_int_ord_hoy_saldado = @iva_int_ord_hoy_saldado,
				--		cap_no_dev_saldado = @cap_no_dev_saldado, gastos_cobranza_saldado = @gastos_cobranza_saldado,
				--		iva_gastos_cobranza_saldado = @iva_gastos_cobranza_saldado, no_asignado_destino = @no_asignado_destino,
				--		monto = @monto, monto_necesario = @monto_necesario, liquida = @liquida_destino, hay_excedente = @hay_excedente_destino,
				--		al_corriente = @al_corriente_destino, tipo_anticipo = @TipoAnticipo,
				--		monto_tomado_ahorro = @monto_tomado_ahorro, monto_tomado_inver = @monto_tomado_inver, monto_tomado_debito = @monto_tomado_debito,
				--		monto_tomado_efectivo = @monto_tomado_efectivo, monto_tomado_adelanto = @monto_tomado_adelanto
				--		----------------------------------------------------

				--select dec = @es_decreciente, niv = @es_nivelado, rev = @es_revolvente

				--begin -- preparar montos de cuentas de haberes

				--	if @id_mov_origen = 100

				--		begin -- del ahorro

				--			select	@retiro_ahorro_total = -@monto,
				--					@retiro_inver_total = 0,
				--					@retiro_debito_total = 0

				--		end -- del ahorro

				--	else if @id_mov_origen = 103

				--		begin -- de inverdin�mica

				--			select	@retiro_ahorro_total = 0,
				--					@retiro_inver_total = -@monto,
				--					@retiro_debito_total = 0

				--		end -- de inverdin�mica

				--	else if @id_mov_origen = 112

				--		begin -- de d�bito

				--			select	@retiro_ahorro_total = 0,
				--					@retiro_inver_total = 0,
				--					@retiro_debito_total = -@monto

				--		end -- de d�bito

				--	if @numero_origen != @numero_destino

				--		begin -- si es dep�sito a otro socio

				--			select	@retiro_ahorro_total = 0,
				--					@retiro_inver_total = 0,
				--					@retiro_debito_total = 0,
				--					@efectivo = -@monto,
				--					@titular_destino = 'F'

				--		end -- si es dep�sito a otro socio

				--	else

				--		select	@efectivo = 0

				--	--select @retiro_ahorro_total, @retiro_inver_total, @retiro_debito_total, @efectivo, @id_mov_origen, @id_mov_destino, @monto

				--end -- preparar montos de cuentas de haberes

			end -- preparaci�n

			begin -- validaciones de preparaci�n
			
				if @id_mov_origen not in(100, 103, 112)

					begin 

						select @status = 379
						select @message = 'La clabe [' + @clabeCorresponsaliasRetiro + '] de corresponsal�as no est� asociada a una cuenta de haberes'
						raiserror (@message, 11, 0)

					end 

				if @id_mov_destino !< 100

					begin 

						select @status = 359
						select @message = 'La clabe [' + @clabeCorresponsaliasDeposito + '] de corresponsal�as no est� asociada a un pr�stamo'
						raiserror (@message, 11, 0)

					end

				--select @saldo_origen, @monto------------------------

				if @saldo_origen < @monto and @programada = 0

					begin

						select @status = 329
						select @message = 'Saldo insuficiente'
						raiserror (@message, 11, 0)

					end

				if @saldo_destino < 0.01

					begin

						select @status = 380
						select @message = 'El pr�stamo no esta vigente'
						raiserror (@message, 11, 0)

					end

			end -- validaciones de preparaci�n
			
			begin -- transacci�n

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio

				begin -- revisar saldos de haberes

					if not exists (select 1 from hape.dbo.edo_de_cuenta where numero = @numero_origen and id_mov = @id_mov_origen and saldo_actual = case when @id_mov_origen = 100 then @respaldo_ahorro else @saldo_origen end)

						begin

							select @status = 329-------------------------- qu� status le doy a este error?

							raiserror ('Una transacci�n previa ha afectado los saldos, revise los saldos y en caso necesario, aplique nuevamente la transacci�n', 11, 0)

						end

				end -- revisar saldos de haberes
				
				begin -- generar folio

					if (@id_transferencia is null)
					begin
						insert	tbl_banca_folios
								(numero_socio, fecha_alta)
						values	(@numero_origen, @fecha_sistema)
											
						/*if @numero_origen != @numero_destino
							begin

								select	@folio_previo = max(id_banca_folio)
								from	tbl_banca_folios	
								where	numero_socio = @numero_origen

								insert	tbl_banca_folios
										(numero_socio, fecha_alta)
								values	(@numero_origen, @fecha_sistema)

							end
						*/
						select	@folio = max(id_banca_folio)
						from	tbl_banca_folios	
						where	numero_socio = @numero_origen
					end
					else
					begin
						SELECT @folio = id_banca_folio FROM TBL_BANCA_TRANSFERENCIAS_INTERNAS WHERE id_transferencia = @id_transferencia
					end
						
					set @folio_previo =@folio

				end -- generar folio

				begin -- registrar en bit�cora

					if @pago_mismo_socio = 0 -- si el pago del prestamo es a otro socio
						set @id_tipo_bitacora =50

					IF @programada = 1
						set @id_tipo_bitacora =24

                    if (@id_transferencia is null or @id_transferencia = 0) -- se anexa para q solo lo haga una ocasion
					begin

						select @id_tipo_bitacora =  case 
														when @pago_mismo_socio = 1 and @programada  = 0 then  23
														when @pago_mismo_socio = 1 and @programada  = 1 then  24
														when @pago_mismo_socio = 0 and @programada  = 0 then  50
														when @pago_mismo_socio = 0 and @programada  = 1 then  86
													end


						insert	tbl_banca_bitacora_operaciones
								(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
						values	(@folio, @id_tipo_bitacora, @numero_origen, @fecha_sistema, @tipoOrigen)

					    if (@programada = 0)
						begin 
							--- PARA NOTIFICAR DEL RETIRO  AL SOCIO DE LA CUENTA ORIGEN
							select @id_tipo_bitacora = case when  @id_mov_origen = 100 then  52
															when  @id_mov_origen = 103 then  51
															when  @id_mov_origen = 112 then  53
														end
					
							insert	tbl_banca_bitacora_operaciones
									(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							values	(@folio, @id_tipo_bitacora, @numero_origen, @fecha_sistema, @tipoOrigen)
					  end
					end
					else
					begin
							select @id_tipo_bitacora =  case 
															when @pago_mismo_socio = 1 and @programada  = 0 then  23
															when @pago_mismo_socio = 0 and @programada  = 0 then  50
														end

							insert	tbl_banca_bitacora_operaciones
									(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							values	(@folio, @id_tipo_bitacora, @numero_origen, @fecha_sistema, @tipoOrigen)

							select @id_tipo_bitacora = case 
															when  @id_mov_origen = 100 then  52
															when  @id_mov_origen = 103 then  51
															when  @id_mov_origen = 112 then  53
													   end
							insert	tbl_banca_bitacora_operaciones
									(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							values	(@folio, @id_tipo_bitacora, @numero_origen, @fecha_sistema, @tipoOrigen)
					end

				end -- registrar en bit�cora

				begin -- recopilar cuentas internas

					select	@id_cuenta_origen = id_cuenta_interna
					from	tbl_banca_cuentas_internas
					where	clabe_corresponsalias = @clabeCorresponsaliasRetiro

					select	@id_cuenta_destino =
								case
									when @numero_origen != @numero_destino
										then id_cuenta_interna
									else
										null
								end
					from	tbl_banca_cuentas_internas
					where	clabe_corresponsalias = @clabeCorresponsaliasDeposito
					and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_origen

				end -- recopilar cuentas internas

				begin -- insertar en tbl_banca_transferencias_internas

					if @id_transferencia is null

						begin

							insert tbl_banca_transferencias_internas	
								(
								id_cuenta_interna,
								monto,
								fecha_alta_transferencia,
								fecha_transferencia_realizada,
								id_estatus_transferencia,
								numero_socio,
								fecha_programada,
								id_banca_folio,
								clave_corresponsalias_origen,
								clave_corresponsalias_destino,
								programada
								)
							values
								(
								@id_cuenta_destino,
							   case when @programada = 1  /*incidencia 1012  12 de marzo 2019*/
										then @MontoOriginalTransaccion 
									 else @monto 
							    end,
								@fecha_sistema,
								case
									when @programada = 1
										then null
									else @fecha_sistema
								end,
								case
									when @programada = 1
										then 1
									else 2
								end,
								BANCA.dbo.FN_BANCA_CIFRAR(@numero_origen),
								case
									when @programada = 1
										then @horaProgramada
									else null
								end,
								@folio,
								@clabeCorresponsaliasRetiro,
								@clabeCorresponsaliasDeposito,
								@programada
								)

						end

				end -- insertar en tbl_banca_transferencias_internas

				if @programada = 0

					begin -- si no est� programada, se aplica de inmediato

						if @id_persona_origen != @id_persona_destino

							begin -- afectar haberes de socio distinto

								begin -- captura

									insert	hape.dbo.captura
											(
											id_persona,
											activo,
											numero,
											nombre_s,
											apellido_paterno,
											apellido_materno,
											total_movs,
											total_ficha,
											id_tipomov,
											cuenta,
											concepto,
											fecha_mov,
											monto,
											id_mov,
											num_poliza,
											tipo_poliza,
											folio,
											id_tipo_persona,
											num_cheq,
											desc1,
											desc2,
											planx,
											desc3,
											fecha_dpf_final,
											num_dpf,
											tasa,
											interes,
											dias,
											debe_haber,
											numusuario,
											numero_fin,
											plazo,
											interes_ord,
											interes_mor,
											contador_provision,
											ccostos,
											nombre_beneficiario,
											parentesco_beneficiario,
											porcentaje_beneficiario,
											nombre_beneficiario2,
											parentesco_beneficiario2,
											porcentaje_beneficiario2,
											numero_fin_lacp,
											id_esquema,
											titular,
											num_ptmo,
											id_amortizacion,
											id_renovado,
											reestructura,
											id_origen,
											id_tipo_pago_prestamo
											)
									select	id_persona,
											activo,
											numero,
											nombre_s,
											apellido_paterno,
											apellido_materno,
											total_movs,
											total_ficha,
											id_tipomov,
											cuenta,
											concepto,
											fecha_mov,
											monto,
											id_mov,
											num_poliza,
											tipo_poliza,
											@folio_previo,
											id_tipo_persona,
											num_cheq,
											desc1,
											desc2,
											planx,
											desc3,
											fecha_dpf_final,
											num_dpf,
											tasa,
											interes,
											dias,
											debe_haber,
											numusuario,
											numero_fin,
											plazo,
											interes_ord,
											interes_mor,
											contador_provision,
											ccostos,
											nombre_beneficiario,
											parentesco_beneficiario,
											porcentaje_beneficiario,
											nombre_beneficiario2,
											parentesco_beneficiario2,
											porcentaje_beneficiario2,
											numero_fin_lacp,
											id_esquema,
											titular,
											num_ptmo,
											id_amortizacion,
											id_renovado,
											reestructura,
											id_origen,
											id_tipo_pago_prestamo
									from	#captura_previo
									order by
											contador

								end -- captura

								begin -- captura_lacp

									insert	hape.dbo.captura_lacp
											(
											id_persona,
											activo,
											numero,
											nombre_s,
											apellido_paterno,
											apellido_materno,
											total_movs,
											total_ficha,
											id_tipomov,
											cuenta,
											concepto,
											fecha_mov,
											monto,
											id_mov,
											num_poliza,
											tipo_poliza,
											folio,
											id_tipo_persona,
											num_cheq,
											desc1,
											desc2,
											planx,
											desc3,
											fecha_dpf_final,
											num_dpf,
											tasa,
											interes,
											dias,
											debe_haber,
											numusuario,
											numero_fin,
											plazo,
											interes_ord,
											interes_mor,
											contador_provision,
											ccostos,
											nombre_beneficiario,
											parentesco_beneficiario,
											porcentaje_beneficiario,
											nombre_beneficiario2,
											parentesco_beneficiario2,
											porcentaje_beneficiario2,
											numero_fin_lacp,
											id_esquema,
											titular,
											num_ptmo,
											id_amortizacion,
											id_renovado,
											reestructura,
											id_origen,
											id_tipo_pago_prestamo
											)
									select	id_persona,
											activo,
											numero,
											nombre_s,
											apellido_paterno,
											apellido_materno,
											total_movs,
											total_ficha,
											id_tipomov,
											cuenta,
											concepto,
											fecha_mov,
											monto,
											id_mov,
											num_poliza,
											tipo_poliza,
											@folio_previo,
											id_tipo_persona,
											num_cheq,
											desc1,
											desc2,
											planx,
											desc3,
											fecha_dpf_final,
											num_dpf,
											tasa,
											interes,
											dias,
											debe_haber,
											numusuario,
											numero_fin,
											plazo,
											interes_ord,
											interes_mor,
											contador_provision,
											ccostos,
											nombre_beneficiario,
											parentesco_beneficiario,
											porcentaje_beneficiario,
											nombre_beneficiario2,
											parentesco_beneficiario2,
											porcentaje_beneficiario2,
											numero_fin_lacp,
											id_esquema,
											titular,
											num_ptmo,
											id_amortizacion,
											id_renovado,
											reestructura,
											id_origen,
											id_tipo_pago_prestamo
									from	#captura_previo
									order by
											contador

								end -- captura_lacp

								begin -- insertar en movimientos

									insert	hape.dbo.movimientos
											(
											numero,
											activo,
											fecha_mov,
											monto,
											saldo,
											tipo_poliza,
											num_poliza,
											folio,
											fecha_alta,
											interes_ord,
											interes_mor,
											plazo,
											numero_fin,
											id_persona,
											numusuario,
											id_tipomov,
											fecha_dpf_final,
											num_dpf,
											tasa_dpf,
											interes_dpf,
											dias,
											id_mov,
											id_tipo_persona,
											numero_fin_lacp,
											reestructura,
											id_motivo_reestructura,
											id_esquema,
											id_convenio,
											id_amortizacion,
											titular,
											planx,
											num_ptmo,
											id_nomina,
											id_esquema_nomina,
											id_renovado,
											id_origen,
											id_tipo_pago_prestamo
											)
									select	c.numero,
											c.activo,
											fecha_mov,
											monto,
											saldo = 0,
											tipo_poliza,
											num_poliza,
											folio = @folio_previo,
											fecha_alta = @fechaOperacion,
											interes_ord,
											interes_mor,
											c.plazo,
											c.numero_fin,
											c.id_persona,
											numusuario,
											id_tipomov,
											fecha_dpf_final,
											num_dpf,
											tasa_dpf = 0,
											interes_dpf = 0,
											dias,
											c.id_mov,
											c.id_tipo_persona,
											c.numero_fin_lacp,
											reestructura,
											id_motivo_reestructura = null,
											c.id_esquema,
											id_convenio = null,
											c.id_amortizacion,
											titular,
											c.planx,
											c.num_ptmo,
											null id_nomina,
											null id_esquema_nomina,
											c.id_renovado,
											id_origen,
											id_tipo_pago_prestamo
									from	#captura_previo c
									where	id_tipomov not in (961, 701, 702, 0)

								end -- insertar en movimientos

								begin -- actualizar saldo en movimientos

									select	identity(int, 1, 1) id,
											cast(m.contador as int) contador,
											m.numero,
											m.id_mov,
											monto,
											saldo_antes = cast(null as money),
											saldo_despues = cast(null as money),
											operacion = -1
									into	#saldos_movimientos_previo
									from	hape.dbo.movimientos m
									where	numusuario = @numusuario
											and folio = @folio_previo
											and cast(fecha_mov as date) = cast(@fechaOperacion as date)
											and num_poliza = @num_poliza
											and m.id_mov !< 100

									update	u
									set		saldo_antes = __.saldo,
											saldo_despues = __.saldo + operacion * monto
									from	(
											select	_.*, cta.saldo_actual saldo
											from	hape.dbo.edo_de_cuenta cta
													join
														(							
														select	min(sm.contador) contador, sm.numero, sm.id_mov
														from	#saldos_movimientos_previo sm
														group by sm.numero, sm.id_mov
														) _
														on _.numero = cta.numero
														and _.id_mov = cta.id_mov
											) __
											join #saldos_movimientos_previo u
												on u.contador = __.contador

									while exists
										(
										select	1
										from	#saldos_movimientos_previo sm1
												join #saldos_movimientos_previo sm2
													on sm2.id = sm1.id + 1
													and sm2.numero = sm1.numero
													and sm2.id_mov = sm1.id_mov
													and sm2.saldo_antes is null
										)

									update	sm2
									set		saldo_antes = sm1.saldo_despues,
											saldo_despues = sm1.saldo_despues + sm2.operacion * sm2.monto
									from	#saldos_movimientos_previo sm1
											join #saldos_movimientos_previo sm2
												on sm2.id = sm1.id + 1
												and sm2.numero = sm1.numero
												and sm2.id_mov = sm1.id_mov
												and sm2.saldo_antes is null

									update	m
									set		saldo = sm.saldo_despues
									from	hape.dbo.movimientos m
											join #saldos_movimientos_previo sm
												on sm.numero = m.numero
												and sm.contador = m.contador

								end -- actualizar saldo en movimientos

								begin -- actualizar edo_de_cuenta

									if @id_mov_origen = 100

										update	#actualiza_edo_de_cuenta_haberes_previo
										set		diferencia = -@monto_necesario,
												saldo_posterior = saldo_anterior - @monto_necesario
										where	id_mov = 100

									if @id_mov_origen = 103

										update	#actualiza_edo_de_cuenta_haberes_previo
										set		diferencia = -@monto_necesario,
												saldo_posterior = saldo_anterior - @monto_necesario
										where	id_mov = 103

									if @id_mov_origen = 112

										update	#actualiza_edo_de_cuenta_haberes_previo
										set		diferencia = -@monto_necesario,
												saldo_posterior = saldo_anterior - @monto_necesario
										where	id_mov = 112

									update	#actualiza_edo_de_cuenta_haberes_previo
									set		diferencia = coalesce(diferencia, 0),
											saldo_posterior = coalesce(saldo_posterior, 0)

									update	cta
									set		saldo_actual = ae.saldo_posterior,
											fecha = ae.fecha
									from	#actualiza_edo_de_cuenta_haberes_previo ae
											join hape.dbo.edo_de_cuenta cta
												on cta.numero = ae.numero
												and cta.id_mov = ae.id_mov
												and ae.diferencia != 0

								end -- actualizar edo_de_cuenta

							end -- afectar afectar haberes de socio distinto

						begin -- afectar pago a cr�dito

							--select @es_nivelado_destino ----------------------------
							print '@es_decreciente_destino :'+ cast(@es_decreciente_destino as varchar)
							if @es_decreciente_destino = 1

								begin try -- decrecientes

									if @TipoAnticipo != 3

										begin -- no es adelanto

											--select  numero = @numero_destino,
											--		id_mov = @id_mov_destino,
											--		int_mor = @int_mor_saldado,
											--		iva_int_mor = @iva_int_mor_saldado,
											--		int_ord_ven = @int_ord_ven_saldado,
											--		iva_int_ord_ven = @iva_int_ord_ven_saldado,
											--		int_ord_vig = @int_ord_vig_saldado,
											--		iva_int_ord_vig = @iva_int_ord_vig_saldado,
											--		capital_vencido = @cap_ven_saldado,
											--		capital_vigente = @cap_vig_saldado,
											--		capital_no_devengado = @cap_no_dev_saldado,
											--		numusuario = @numusuario,
											--		num_poliza = @num_poliza,
											--		folio = @folio,
											--		tipo_poliza = @tipo_poliza,
											--		contador_provision = 0,
											--		titular = @titular_pago,
											--		ahorro = @monto_tomado_ahorro,
											--		inverdinamica = @monto_tomado_inver,
											--		debito = @monto_tomado_debito,
											--		saldo_adelanto = @monto_tomado_adelanto,
											--		saldo_cuenta_contable = 0,
											--		cuenta_contable = '',
											--		efectivo = @monto_tomado_efectivo,
											--		gastos_cobranza = @gastos_cobranza_mas_iva_saldado,
											--		id_origen = 3,
											--		id_tipo_persona = 1,
											--		fecha = @fechaOperacion,
											--		id_tipo_pago_prestamo = @TipoAnticipo
											
											-----------------------

											exec hape.dbo.SP_INTERES_DIARIO_REALIZA_PAGO_DECRECIENTE 

												@numero = @numero_destino,
												@id_mov = @id_mov_destino,
												@int_mor = @int_mor_saldado,
												@iva_int_mor = @iva_int_mor_saldado,
												@int_ord_ven = @int_ord_ven_saldado,
												@iva_int_ord_ven = @iva_int_ord_ven_saldado,
												@int_ord_vig = @int_ord_vig_saldado,
												@iva_int_ord_vig = @iva_int_ord_vig_saldado,
												@capital_vencido = @cap_ven_saldado,
												@capital_vigente = @cap_vig_saldado,
												@capital_no_devengado = @cap_no_dev_saldado,
												@numusuario = @numusuario,
												@num_poliza = @num_poliza,
												@folio = @folio,
												@tipo_poliza = @tipo_poliza,
												@contador_provision = 0,
												@titular = @titular_pago,
												@ahorro = @monto_tomado_ahorro,
												@inverdinamica = @monto_tomado_inver,
												@debito = @monto_tomado_debito,
												@saldo_adelanto = @monto_tomado_adelanto,
												@saldo_cuenta_contable = 0,
												@cuenta_contable = '',
												@efectivo = @monto_tomado_efectivo,
												@gastos_cobranza = @gastos_cobranza_mas_iva_saldado,
												@id_origen = 3,
												@id_tipo_persona = 1,
												@fecha = @fechaOperacion,
												@id_tipo_pago_prestamo = @TipoAnticipo

										end -- no es adelanto

								else if @TipoAnticipo = 3

									begin -- es adelanto

										exec hape.dbo.SP_INTERES_DIARIO_REALIZA_PAGO_DECRECIENTE 

											@numero = @numero_destino,
											@id_mov = @id_mov_destino,
											@int_mor = 0,
											@iva_int_mor = 0,
											@int_ord_ven = 0,
											@iva_int_ord_ven = 0,
											@int_ord_vig = 0,
											@iva_int_ord_vig = 0,
											@capital_vencido = 0,
											@capital_vigente = 0,
											@capital_no_devengado = 0,
											@numusuario = @numusuario,
											@num_poliza = @num_poliza,
											@folio = @folio,
											@tipo_poliza = @tipo_poliza,
											@contador_provision = 0,
											@titular = @titular_pago,
											@ahorro = @monto_tomado_ahorro,
											@inverdinamica = @monto_tomado_inver,
											@debito = @monto_tomado_debito,
											@saldo_adelanto = @monto_necesario,
											@saldo_cuenta_contable = 0,
											@cuenta_contable = '',
											@efectivo = @monto_tomado_efectivo,
											@gastos_cobranza = @gastos_cobranza_mas_iva_saldado,
											@id_origen = 3,
											@id_tipo_persona = 1,
											@fecha = @fechaOperacion,
											@id_tipo_pago_prestamo = @TipoAnticipo

									end -- es adelanto

								end try 
								begin catch 
									print '**Error en SP_INTERES_DIARIO_REALIZA_PAGO_DECRECIENTE ----'
									select @status = 339
									select @message = 'Error al procesar el pago, intente mas tarde.'
									raiserror (@message, 11, 0)
								end catch -- decrecientes

							else if @es_nivelado_destino = 1

								begin try -- es nivelado

									--select @TipoAnticipo-----------------------

									if @TipoAnticipo != 3

										begin -- no es adelanto

											exec HAPE.dbo.sp_interes_diario_realiza_pago_nivelado
												@numero = @numero_destino,
												@id_mov = @id_mov_destino,
												@pago_total = @monto_necesario,
												@numusuario = @numusuario,
												@num_poliza = @num_poliza,
												@folio = @folio,
												@tipo_poliza = @tipo_poliza,
												@contador_provision = 0,
												@titular = @titular_pago,
												@ahorro = @monto_tomado_ahorro,
												@inverdinamica = @monto_tomado_inver,
												@debito = @monto_tomado_debito,
												@saldo_adelanto = @monto_tomado_adelanto,
												@saldo_cuenta_contable = 0,
												@cuenta_contable = '',
												@efectivo = @monto_tomado_efectivo,
												@gastos_cobranza = @gastos_cobranza_mas_iva_saldado,
												@id_origen = 3,
												@id_tipo_persona = 1,
												@fecha = @fechaOperacion,
												@id_tipo_pago_prestamo = @TipoAnticipo,
												@moratorios_e_iva = @moratorios_mas_iva_saldado

										end -- no es adelanto

									else if @TipoAnticipo = 3

										begin -- es adelanto

											--select 'ENTRA' ----------------------

											--select
											--	[@numero] = @numero_destino,
											--	[@id_mov] = @id_mov_destino,
											--	[@pago_total] = 0,
											--	[@numusuario] = @numusuario,
											--	[@num_poliza] = @num_poliza,
											--	[@folio] = @folio,
											--	[@tipo_poliza] = @tipo_poliza,
											--	[@contador_provision] = 0,
											--	[@titular] = @titular_pago,
											--	[@ahorro] = @monto_tomado_ahorro,
											--	[@inverdinamica] = @monto_tomado_inver,
											--	[@debito] = @monto_tomado_debito,
											--	[@saldo_adelanto] = @monto_necesario,
											--	[@saldo_cuenta_contable] = 0,
											--	[@cuenta_contable] = '',
											--	[@efectivo] = @monto_tomado_efectivo,
											--	[@gastos_cobranza] = @gastos_cobranza_mas_iva_saldado,
											--	[@id_origen] = 3,
											--	[@id_tipo_persona] = 1,
											--	[@fecha] = @fechaOperacion,
											--	[@id_tipo_pago_prestamo] = @TipoAnticipo,
											--	[@moratorios_e_iva] = 0,
											--	[@monto] = @monto
												
												----------------------

											exec HAPE.dbo.sp_interes_diario_realiza_pago_nivelado
												@numero = @numero_destino,
												@id_mov = @id_mov_destino,
												@pago_total = 0,
												@numusuario = @numusuario,
												@num_poliza = @num_poliza,
												@folio = @folio,
												@tipo_poliza = @tipo_poliza,
												@contador_provision = 0,
												@titular = @titular_pago,
												@ahorro = @monto_tomado_ahorro,
												@inverdinamica = @monto_tomado_inver,
												@debito = @monto_tomado_debito,
												@saldo_adelanto = @monto_necesario,
												@saldo_cuenta_contable = 0,
												@cuenta_contable = '',
												@efectivo = @monto_tomado_efectivo,
												@gastos_cobranza = @gastos_cobranza_mas_iva_saldado,
												@id_origen = 3,
												@id_tipo_persona = 1,
												@fecha = @fechaOperacion,
												@id_tipo_pago_prestamo = @TipoAnticipo,
												@moratorios_e_iva = 0

										end -- es adelanto

								end try
								begin catch 
									print '**Error en sp_interes_diario_realiza_pago_nivelado ----'
									select @status = 339
									select @message = 'Error al procesar el pago, intente mas tarde.'
									raiserror (@message, 11, 0)
								end catch -- es nivelado

							else if @es_revolvente_destino = 1

								begin try -- revolvente

									if (@TipoAnticipo = 3)

										raiserror ('Los pr�stamos revolventes no permiten adelantos', 13, 0)

									exec hape.dbo.sp_revolvente_realiza_pago

										@id_linea = @id_linea_destino,
										@numero = @numero_destino,
										@pago_total = @monto_necesario,
										@numusuario = @numusuario,
										@num_poliza = @num_poliza,
										@folio = @folio,
										@contador_provision = 0,
										@titular = @titular_pago,
										@ahorro = @monto_tomado_ahorro,
										@inverdinamica = @monto_tomado_inver,
										@debito = @monto_tomado_debito,
										@efectivo = @monto_tomado_efectivo,
										@id_tipo_persona = 1,
										@fecha = @fechaOperacion,
										@gastos_cobranza = @gastos_cobranza_mas_iva_saldado,
										@id_origen = 3

								end try
								begin catch 
									print '**Error en sp_revolvente_realiza_pago ----'
									select @status = 339
									select @message = 'Error al procesar el pago, intente mas tarde.'
									raiserror (@message, 11, 0)
								end catch -- revolvente

							if exists (select * from #procedimiento_pago_credito where status != 1)

								begin

									--select * from #procedimiento_pago_credito -------------------

									select	@message = error_message
									from	#procedimiento_pago_credito

									select @status = 378

									raiserror(@message, 13, 0)

								end

							-- se actualiza la cuenta de cajas por la cuenta de compensacion de la sucursal due�a si los socios son de diferente sucursal
							-- CAPTURA_lacp
								update	hape.dbo.CAPTURA_lacp
								set		Cuenta = a.cta_contable_suc_duena,
										Concepto = a.des_contable_suc_duena,
										Id_Tipomov = 0

								from	(
											select	Contador,
													Ccostos,
													@numero_destino as numero_destino, 
													@cta_contable_suc_duena cta_contable_suc_duena,
													@des_contable_suc_duena des_contable_suc_duena,
														
													cuenta
											from	hape.dbo.CAPTURA_lacp 
											where	folio = @folio 
												and Num_Poliza = @num_poliza 
												and numero = @numero_destino 
												and id_origen = 3 
												and Cuenta like '111%' 
												and Id_Tipomov = 961 
												and Activo = 'T'

										)A
								where	folio = @folio 
									and Num_Poliza = @num_poliza 
									and numero = @numero_destino 
									and id_origen = 3 
									and hape.dbo.CAPTURA_lacp.Cuenta like '111%' 
									and Id_Tipomov = 961 
									and Activo = 'T'

							-- se actualiza la cuenta de cajas por la cuenta de compensacion de la sucursal due�a si los socios son de diferente sucursal
							-- CAPTURA
								update	hape.dbo.CAPTURA
								set		Cuenta = a.cta_contable_suc_duena,
										Concepto = a.des_contable_suc_duena,
										Id_Tipomov = 0

								from	(
											select	Contador,
													Ccostos,
													@numero_destino as numero_destino, 
													@cta_contable_suc_duena cta_contable_suc_duena,
													@des_contable_suc_duena des_contable_suc_duena,
														
													cuenta
											from	hape.dbo.CAPTURA 
											where	folio = @folio 
												and Num_Poliza = @num_poliza 
												and numero = @numero_destino 
												and id_origen = 3 
												and Cuenta like '111%' 
												and Id_Tipomov = 961 
												and Activo = 'T'

										)A
								where	folio = @folio 
									and Num_Poliza = @num_poliza 
									and numero = @numero_destino 
									and id_origen = 3 
									and hape.dbo.CAPTURA.Cuenta like '111%' 
									and Id_Tipomov = 961 
									and Activo = 'T'

	
						end -- afectar pago a cr�dito

					end -- si no est� programada, se aplica de inmediato

				--begin  -- compensaciones

				--	if ( @ccostos_origen <> @ccostos_destino ) 
				--		begin

				--			select @fecha_ini = convert(datetime,CONVERT(varchar(10), @fechaOperacion, 103),103) 
				--			select @fecha_fin = dateadd(dd, 1, @fecha_ini) 

				--			create table 
				--				#temp_ccostos
				--					(
				--						 ccostos_destino varchar(10)
				--						,ccostos_origen varchar(10)
				--						,id_de_sucursal int
				--						,num_cuenta_compensacion_origen varchar(50)
				--						,num_cuenta_compensacion_destino varchar(50)
				--						,monto money
				--						,folio int
				--						,num_poliza int
				--					)

				--			create table 
				--				#cuentas_compensadas 
				--					( 
				--						 cuenta varchar(50) 
				--						,ccostos varchar(10)
				--						,total_haber money 
				--						,total_debe money
				--						,origen varchar(50)
				--						,monto money
				--						,folio int
				--						,num_poliza int
				--					)

				--			create table 
				--				#tbl_poliza
				--					(
				--						cuenta varchar(50), 
				--						ccostos varchar(10), 
				--						monto money, 
				--						tipo_asiento int, folio int
				--					)


				--			-- obtenemos la cuenta contable de la sucursal del socio origen para compensaciones
				--				select	@cta_contable_suc_duena =	n.Num_Cuenta_Compensacion
				--													from	hape.dbo.SUCURSALES s 
				--															inner join hape.dbo.NUM_SUCURSAL n
				--																on n.Num_Sucursal = s.Num_Sucursal
				--															inner join hape.dbo.PERSONA c
				--																on c.Id_de_sucursal = s.Id_de_Sucursal
				--													where	c.Numero = @numero_origen
				--														and	c.Id_Tipo_Persona = 1

				--			-- obtenemos todos los centros de costos que no son de la sucursal del socio origen
				--				insert into #temp_ccostos (ccostos_destino, ccostos_origen, id_de_sucursal,num_cuenta_compensacion_origen, num_cuenta_compensacion_destino,monto,folio,num_poliza)
				--				SELECT	c.CCOSTOS, @ccostos_origen, Num_Sucursal, @cta_contable_suc_duena, Num_Cuenta_Compensacion, Monto, Folio, Num_Poliza 
				--				FROM	hape.dbo.captura_lacp c
				--						inner join hape.dbo.NUM_SUCURSAL n
				--							on c.Ccostos collate SQL_Latin1_General_CP1_CI_AS = n.Ccostos collate SQL_Latin1_General_CP1_CI_AS
				--				WHERE	FECHA_MOV>@fecha_ini AND FECHA_MOV<@fecha_fin AND ID_TIPOMOV<>-1 AND ID_TIPOMOV<>961 
				--						AND c.ACTIVO='T' AND NUMUSUARIO=@numusuario AND TIPO_POLIZA='M'
				--						and c.Ccostos <> @ccostos_origen and c.Ccostos <> @ccostos_medpa and c.id_origen not in (2)
				--						and c.Folio = @folio
								
				--			-- compensaciones de cuentas q no son de la sucursal del socio origen
				--			-- monto que se debe de compensar de operaciones que se hicieron en la sucural que no es el ccostos del socio origen
				--				insert into #cuentas_compensadas (cuenta, ccostos, total_haber, total_debe, origen, monto,folio,num_poliza)
				--				SELECT	CUENTA, c.ccostos, 
				--						case
				--							when DEBE_HABER = 'H' then abs(monto)
				--							else 0
				--						end as total_haber,
				--						case
				--							when DEBE_HABER = 'D' then abs(monto)
				--							else 0
				--						end as total_debe
				--						,'otras' as origen, monto,folio,num_poliza
				--				FROM	hape.dbo.captura_lacp c		
				--				WHERE	Fecha_mov>=@fecha_ini 
				--					AND FECHA_MOV<@fecha_fin 
				--					AND ID_TIPOMOV<>-1 
				--					AND ID_TIPOMOV<>961
				--					AND ACTIVO = 'T' 
				--					and c.ccostos  <> @ccostos_origen
				--					AND c.ccostos <> @ccostos_medpa 
				--					AND NUMUSUARIO = @numusuario 
				--					AND TIPO_POLIZA = 'M'
				--					AND CUENTA <> '11100700000000' AND  CUENTA <> '14101000990000' AND  CUENTA <> '23201100010000'  --   //se elemina las compensasciones de estas cuentas debido al ticket 36773
				--					and c.id_origen not in (2)
				--					and Folio = @folio
							
							
				--			-----------------------------------------------------------------------
				--			-- se insertan 4 registros por cuenta para hacer la compensacion 
				--			-----------------------------------------------------------------------
				--			---- cancelacion de saldo en sucursal origen
				--			--	insert into #tbl_poliza(monto, tipo_asiento, cuenta, ccostos, folio)
				--			--	select  distinct 
				--			--			--'compensa_1',
				--			--			case when total_debe > 0 then total_debe else total_haber end as monto,
				--			--			case when total_debe > 0 then 1 else -1 end as tipo, 
				--			--			---1 as tipo, 
				--			--			case 
				--			--				when total_debe > 0 then temp.num_cuenta_compensacion_destino 								
				--			--				else comp.cuenta 
				--			--			end as cuenta_,
				--			--			temp.ccostos_destino as ccostos,comp.folio
				--			--	from	#cuentas_compensadas comp 
				--			--			inner join #temp_ccostos temp 
				--			--				on comp.ccostos = temp.ccostos_destino
				--			--	--where 1 = case when comp.origen = 'divisas' then 0 else 1 end -- los primeros dos asientos de las divisas aplica diferente la compensacion

				--			---- cuenta compensacion 141_ en cuenta origen
				--			--	insert into #tbl_poliza(monto, tipo_asiento, cuenta, ccostos, folio)
				--			--	select  distinct
				--			--			--'compensa_2', --141x
				--			--			case when total_debe > 0 then total_debe else total_haber end as monto ,
				--			--			case when total_debe > 0 then -1 else 1 end as tipo, 
				--			--			---1 as tipo_,
				--			--			case 
				--			--				when total_debe > 0 then comp.cuenta 
				--			--				else temp.num_cuenta_compensacion_destino 
				--			--			end as cuenta_,
				--			--			temp.ccostos_origen as ccostos,comp.folio
				--			--	from	#cuentas_compensadas comp 
				--			--			inner join #temp_ccostos temp 
				--			--				on comp.ccostos = temp.ccostos_destino
				--			--	--where 1 = case when comp.origen = 'divisas' then 0 else 1 end -- los primeros dos asientos de las divisas aplica diferente la compensacion

				--			---- cuenta compensacion 141_ en cuenta destino
				--			--	insert into #tbl_poliza(monto, tipo_asiento, cuenta, ccostos, folio)
				--			--	select  distinct
				--			--			--'compensa_3', --141xx
				--			--			case when total_debe > 0 then total_debe else total_haber end as monto,
				--			--			case when total_debe > 0 then 1 else -1 end as tipo, 
				--			--			case 
				--			--				when total_debe > 0 then comp.cuenta 
				--			--				else temp.num_cuenta_compensacion_origen 
				--			--			end as cuenta_,
				--			--			temp.ccostos_destino as ccostos,comp.folio
				--			--	from	#cuentas_compensadas comp 
				--			--			inner join #temp_ccostos temp 
				--			--				on comp.ccostos = temp.ccostos_destino

				--			---- inserta el saldo en cuenta destino
				--			--	insert into #tbl_poliza(monto, tipo_asiento, cuenta, ccostos, folio)
				--			--	select  distinct
				--			--			--'compensa_4',
				--			--			case when total_debe > 0 then total_debe else total_haber end as monto,
				--			--			case when total_debe > 0 then -1 else 1 end as tipo, 
				--			--			--1 as tipo_,
				--			--			case 
				--			--				when total_debe > 0 then temp.num_cuenta_compensacion_origen 
				--			--				else comp.cuenta 
				--			--			end as cuenta_,
				--			--			temp.ccostos_origen as ccostos,comp.folio
				--			--	from	#cuentas_compensadas comp 
				--			--			inner join #temp_ccostos temp 
				--			--				on comp.ccostos = temp.ccostos_destino
									
				--			-- insercion a captura_lacp 
				--			 --se inserta la informacion en captura_lacp para el num_poliza del cajero
				--				insert into  
				--					hape.dbo.CAPTURA_lacp (	Id_persona,Activo,Numero,Nombre_s,Apellido_paterno,Apellido_materno,Total_movs,Total_ficha,
				--											Id_Tipomov,Cuenta,Concepto,Fecha_mov,Monto,Neto,ID_mov,Banco,clave_Local,Linea,Num_Poliza,Tipo_poliza,
				--											Folio,Id_Tipo_persona,Num_cheq,Desc1,Desc2,planx,Aval1_socio,Aval1_numero,Aval2_socio,Aval2_numero,
				--											Desc3,Desc4,FECHA_DPF_final,NUM_DPF,TASA,INTERES,DIAS,DEBE_HABER,NUMUSUARIO,PROCESADO,FECHA_ALTA,
				--											numero_Fin,numero_fin2,Plazo,Interes_ord,Interes_mor,Monto2,Plazo2,Interes_ord2,Interes_mor2,Aval1_avalados,
				--											Aval2_avalados,Fec_inicio,Fec_prog,Contador_provision,Ccostos,NOMBRE_BENEFICIARIO,PARENTESCO_BENEFICIARIO,
				--											PORCENTAJE_BENEFICIARIO,NOMBRE_BENEFICIARIO2,PARENTESCO_BENEFICIARIO2,PORCENTAJE_BENEFICIARIO2,Id_Sol,
				--											Numero_Fin_LACP,Reestructura,Id_Motivo_Reestructura,Id_Esquema,Id_Convenio,Id_Amortizacion,Ent_Federativa,
				--											Cve_Municipio,Cve_Localidad,Identificador,Transferencia,Fecha_Pago,Bimestre,Referencia,Cve_Archivo,Impreso,
				--											Folio_Impresion,Documentacion,dpf_en_garantia,Titular,Id_Nomina,Id_Esquema_Nomina,Id_Leyenda,Num_ptmo,
				--											Id_Renovado,Ahorro_Base,Tasa_Pasiva,Id_Fondeador,Numero_Fondeo,id_origen--,id_tipo_pago_prestamo
				--											)

				--				select	0 as Id_persona,'T' as Activo,0 as Numero,'' as Nombre_s,'' as Apellido_paterno, '' as Apellido_materno,0 as Total_movs,
				--						0 as Total_ficha,0 as Id_Tipomov,
				--						Cuenta,c.Concepto,
				--						getdate() as Fecha_mov, p.monto,0 as Neto,0 as ID_mov,0 as Banco,0 as clave_Local,0 as Linea,
				--						@num_poliza,'M' as Tipo_poliza,p.folio as Folio,0 as Id_Tipo_persona,0 as Num_cheq,0 as Desc1,0 as Desc2,
				--						0 as planx,0 as Aval1_socio,0 as Aval1_numero,0 as Aval2_socio,0 as Aval2_numero,0 as Desc3,
				--						0 as Desc4,0 as FECHA_DPF_final,0 as NUM_DPF,0 as TASA,0 as INTERES,0 as DIAS,
				--						case when p.tipo_asiento = -1 then 'D' else 'H' end as DEBE_HABER,
				--						@numusuario as  NUMUSUARIO,0 as PROCESADO,getdate() as FECHA_ALTA,0 as numero_Fin,0 as numero_fin2,
				--						0 as Plazo,0 as Interes_ord,0 as Interes_mor,0 as Monto2,0 as Plazo2,0 as Interes_ord2,
				--						0 as Interes_mor2,0 as Aval1_avalados,0 as Aval2_avalados,0 as Fec_inicio,0 as Fec_prog,
				--						0 as Contador_provision,p.ccostos,'' as NOMBRE_BENEFICIARIO,'' as PARENTESCO_BENEFICIARIO,
				--						0 as PORCENTAJE_BENEFICIARIO,'' as NOMBRE_BENEFICIARIO2,'' as PARENTESCO_BENEFICIARIO2,
				--						0 as PORCENTAJE_BENEFICIARIO2,'' as Id_Sol,0 as Numero_Fin_LACP,0 as Reestructura,
				--						0 as Id_Motivo_Reestructura,0 as Id_Esquema,0 as Id_Convenio,0 as Id_Amortizacion,
				--						0 as Ent_Federativa,0 as Cve_Municipio,0 as Cve_Localidad,0 as Identificador,0 as Transferencia,
				--						0 as Fecha_Pago,0 as Bimestre,0 as Referencia,0 as Cve_Archivo,0 as Impreso,0 as Folio_Impresion,
				--						0 as Documentacion,0 as dpf_en_garantia,0 as Titular,0 as Id_Nomina,0 as Id_Esquema_Nomina,
				--						0 as Id_Leyenda,'' as Num_ptmo,0 as Id_Renovado,0 as Ahorro_Base,0 as Tasa_Pasiva,
				--						0 as Id_Fondeador,0 as Numero_Fondeo,@TipoOrigen--,id_tipo_pago_prestamo
				--				from	#tbl_poliza p
				--						left join hape.dbo.CUENTAS_CONTABLES c on p.cuenta collate SQL_Latin1_General_CP1_CI_AS = c.Num_cuenta collate SQL_Latin1_General_CP1_CI_AS

				--			drop table #tbl_poliza
				--			drop table #temp_ccostos
				--			drop table #cuentas_compensadas

				--		end --if ( @ccostos_origen <> @ccostos_destino )
					
				--end  -- compensaciones


				begin -- componente N de la transacci�n
				
					print '[aqu� va un componente de la transacci�n]'
				
				end -- componente N de la transacci�n

				begin -- actualizar estatus transferencia interna

					if @id_transferencia is not null and @programada = 0

						update	tbl_banca_transferencias_internas
						set		id_estatus_transferencia = 2,
								fecha_transferencia_realizada = @fechaOperacion
						where	id_transferencia = @id_transferencia

				end -- actualizar estatus transferencia interna
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal

			-- captura del error
			select	--@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
						
			print @error_message

			-- revertir transacci�n si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
			
			if @status = 200
				select @status = -1, @error_message = 'Error al procesar el pago, intente mas tarde.'

		end catch -- catch principal
		
		--begin -- reporte de status
		
		--	select	@status status,
		--			@error_procedure error_procedure,
		--			@error_line error_line,
		--			@error_severity error_severity,
		--			@error_message error_message
				
		--end -- reporte de status

		begin -- reporte de status
		    
			insert into #SP_BANCA_PAGAR_PRESTAMO(estatus,folio,HoraTransaccion,Monto,error_procedur,error_lin,error_severit,error_messag)
			select	estatus = @status,
					case when @status = 200 then @folio else null end Folio,
					case when @status = 200 then @fecha_sistema else null end HoraTransaccion,
					case when @status = 200 then @monto else null end Monto,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message mensaje

			if @standalone = 1
				select * from #SP_BANCA_PAGAR_PRESTAMO
				
		end -- reporte de status
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_REALIZA_COBRO_COMISION]    Script Date: 29/10/2019 01:07:22 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			EDSON
Fecha			20190620
Objetivo		Realiza un pago de una comision 
Proyecto		Banca en l�nea
Ticket			______
*/

ALTER PROCEDURE [dbo].[SP_BANCA_REALIZA_COBRO_COMISION]
		@numero int,
		@id_comision int,
		@id_tipo_persona int = null 
as

	begin -- procedimiento
		
		--declare	@status int = 200
		
		begin try -- try principal
		
			begin -- inicio

			
				begin -- declaraciones
					declare	
						@status int = 0,-- = 200
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@message varchar(255)

					declare	
						@tran_name varchar(32) = 'COBRO_COMISI�N_BANCA',
						@tran_count int = @@trancount,
						@tran_scope bit = 0

					declare
						@id_persona int,
						@num_poliza int,
						@folio int,
						@tasa_iva decimal(10,2),
						@saldo decimal(10,2),
						@iva decimal(10,2),
						@saldo_total_pagado decimal(10,2) =0,
						@saldo_debito decimal(10,2),
						@saldo_inver decimal(10,2),
						@saldo_ahorro decimal(10,2),
						@total_haberes decimal(10,2),
						@saldo_restante decimal(10,2),
						@fecha_mov datetime,
						@id_mov int,
						@operacion int,
						@id_tipomov int,
						@monto decimal(10,2) = 0,
						@max_cont_mov bigint,
						@pagada bit = 0,
						--
						@tipo_poliza varchar(1) = 'M',
						@numusuario int = 1024,
						@ccostos_origen varchar(10),
						@nombre_origen varchar(100),
						@Ap_paterno_origen varchar(100),
						@Ap_materno_origen varchar(100)

				end -- declaraciones

			end -- inicio

			begin --validaciones

				print 'paso 01'	
				---No existe la comision que desea cobrar
				if not exists(select * from BANCA..TBL_BANCA_COMISIONES where id_comision = @id_comision and BANCA.dbo.FN_BANCA_DESCIFRAR(numero) = @numero and pagada = 0)
				begin
					select @status = 0,@message = 'No existe o ya se liquido la comision que desea cobrar'
					raiserror (@message, 11, 0)
				end	
				---validar que la comision pertenesca al mismo socio que la origino, en caso de darse de baja y no haber cubierto la comisi�n
				if not exists(select * from HAPE..PERSONA persona 
				inner join BANCA..TBL_BANCA_COMISIONES comision on persona.Numero = BANCA.dbo.FN_BANCA_DESCIFRAR(comision.numero) 
				and persona.Id_Persona = comision.id_persona)
				begin
					select @status = 0,@message = 'La comision que intenta cobrar, no es permitida, que no que le pertenece al socio actual'
					raiserror (@message, 11, 0)
				end
			end


			
		begin -- transacci�n	

			begin --Datos generales

				print 'paso 02'
				select @id_tipo_persona = ISNULL(@id_tipo_persona,1)
 
				---Se obtiene el numero de poliza de banca
					select @num_poliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
					select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'BANCA ELECTRONICA')
					and dia = DAY(GETDATE())

				--Se los datos de la persona
				select 
					@id_persona = p.Id_Persona,
					@nombre_origen = p.Nombre_s,
					@Ap_paterno_origen = p.Apellido_Paterno,
					@Ap_materno_origen = p.Apellido_Materno,
					@ccostos_origen = s.Ccostos
				from HAPE..PERSONA p
				join HAPE.dbo.sucursales s
					on s.id_de_sucursal = p.id_de_sucursal
				where Numero = @numero and Id_Tipo_Persona = @id_tipo_persona

				select @tasa_iva = tasa/100.0 from HAPE..tasas where contador in (select max(contador) from HAPE..tasas where id_mov = 111)

				-- calcular saldos adeudados y en haberes
				select @saldo = round(saldo,2), @iva = round(saldo * @tasa_iva, 2, 1) from BANCA..TBL_BANCA_COMISIONES where BANCA.dbo.FN_BANCA_DESCIFRAR(numero) = @numero and id_comision = @id_comision and pagada = 0

				select @saldo_debito = round(saldo_actual,2) from HAPE..edo_de_cuenta where numero = @numero and id_mov = 112 and Id_Tipo_persona=@id_tipo_persona

				select @saldo_inver =round(saldo_actual,2) from HAPE..edo_de_cuenta where numero = @numero and id_mov = 103 and id_tipo_persona = @id_tipo_persona

				select @saldo_ahorro = round(saldo_actual - 
				(select isnull(sum(ahorro_base),0) from HAPE..edo_de_cuenta where numero = @numero and 
				id_mov in (1, 2, 3, 4, 5, 6, 7, 8, 9) and Id_Tipo_persona = @id_tipo_persona and saldo_actual > 0) ,2) 
				from HAPE..edo_de_cuenta where numero = @numero and id_mov = 100 and id_tipo_persona = @id_tipo_persona

				-- en caso de que tenga mas ahorro comprometido que saldo en la cuenta d ahorro
				if @saldo_ahorro < 0 
					set @saldo_ahorro = 0 
				
				set @total_haberes = round((@saldo_debito + @saldo_inver + @saldo_ahorro),2)

				-- si no hay saldo suficiente, ajustar saldo a disponible en haberes
				if @total_haberes < (@saldo + @iva)
					select	@saldo = round(@total_haberes / (1 + @tasa_iva),2),
						@iva = round(@total_haberes - @total_haberes / (1 + @tasa_iva),2)

			end

			begin -- inicio

				print 'paso 03'
				if @tran_count = 0
					begin tran @tran_name
				else
					save tran @tran_name
				
				select @tran_scope = 1

				select @saldo_restante = round(@saldo + @iva,2)

				select @fecha_mov = GETDATE()

				declare
					@monto_cuenta money,
					@iva_cuenta money,
					@id_mov_iva int
				

				print 'paso 04'
				--Se obtiene el nuevo folio de banca para realizar la afectacion
				if @total_haberes > 0 and @saldo_restante > 0
				begin
					insert BANCA..TBL_BANCA_FOLIOS(numero_socio, fecha_alta) values(@numero, getdate())
					select @folio=max(id_banca_folio) from BANCA..TBL_BANCA_FOLIOS
					where
						numero_socio =  @numero

					print 'paso 05'
					if @saldo_debito > 0
						begin
						--tenemos mas saldo en deuda que en debito,por lo tanto se toma todo el saldo de debito
						if @saldo_restante > @saldo_debito and @saldo_restante > 0 
							begin
								select	
									@monto_cuenta = round(@saldo_debito / (1 + @tasa_iva), 2),
									@iva_cuenta = round(@saldo_debito - @saldo_debito / (1 + @tasa_iva), 2)
								select @saldo_restante = (@saldo_restante - @saldo_debito)
							end
						else if @saldo_restante > 0 --tenemos mas saldo en debito que la deuda, tomamos solamente el dinero para liquidar la comision
							begin
								print 'liquida saldo restante con debito'
								select	
									@monto_cuenta = round(@saldo_restante / (1 + @tasa_iva), 2),
									@iva_cuenta = round(@saldo_restante - @saldo_restante / (1 + @tasa_iva), 2)
								select @saldo_restante = 0
								select @pagada = 1
							end
							

							select @monto = (@monto_cuenta + @iva_cuenta)
							select @saldo_debito = (@saldo_debito - @monto_cuenta)

							/*====================	RETIRO DE DEBITO CMV POR TRANSFERENCIA A ACLARACI�N IMPROCEDENTE	====================
							  ==============================================================================================================*/
							Select @id_tipomov = 1018
							SELECT @id_mov = ID_MOV, @operacion = OPERACION FROM HAPE..TIPO_MOV WHERE ID_TIPOMOV = @id_tipomov
							INSERT	HAPE..MOVIMIENTOS
								(
								NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
								NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
								ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR
								)
							VALUES	(
								@numero, 'T', @fecha_mov, @monto_cuenta, @saldo_debito, 'D',
								@num_poliza, @folio, GETDATE(), @id_persona, @numusuario,
								@id_tipomov, @id_mov, 1, 'S'
								)

							/*====================	I.V.A. POR ACLARACI�N IMPROCEDENTE DE DEBITO CMV EN CMV FINANZAS	====================
							  ==============================================================================================================*/
							select @saldo_debito = (@saldo_debito - @iva_cuenta)
							select @id_mov_iva = 1012
							INSERT	HAPE..MOVIMIENTOS
								(
								NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
								NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
								ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR
								)
							VALUES	(
								@numero, 'T', @fecha_mov, @iva_cuenta, @saldo_debito, 'D',
								@num_poliza, @folio, GETDATE(), @id_persona, @numusuario,
								@id_mov_iva, @id_mov, 1, 'S'
								)

							/*========================================	CAIDA CONTABLE CAPTURA_LACP	=======================================
							  ==============================================================================================================*/
							 insert	HAPE..captura_lacp(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

							select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 0,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = tm.descripcion,
								fecha_mov = @fecha_mov,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @folio,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_mov as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = 3
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = 112 and
								tm.id_tipomov = 1001 and
								cc.concepto like 'debito%'
								and cc.num_cuenta like '216%'

							 insert	HAPE..captura_lacp(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

								select	@id_persona,
									'T',
									@numero,
									@nombre_origen,
									@Ap_paterno_origen,
									@Ap_materno_origen,
									total_movs = 0,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									cc.concepto,
									fecha_mov = @fecha_mov,
									monto = abs(@iva_cuenta),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @folio,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									planx = null,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha_mov as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'D',
									numusuario = @numusuario,
									numero_fin = null,
									plazo = null,
									interes_ord = null,
									interes_mor = null,
									contador_provision = null,
									@ccostos_origen,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = null,
									id_esquema = null,
									titular = 'S',
									num_ptmo = null,
									id_amortizacion = null,
									id_renovado = null,
									reestructura = null,
									id_origen = 3
								from	HAPE.dbo.tipo_mov tm
								join HAPE.dbo.cuentas_contables cc
									on tm.id_mov = 112 and
									tm.id_tipomov = 1001 and
									cc.concepto like 'I.V.A. TRASLADADO%'
									and cc.num_cuenta like '23200300010000%'


							 insert	HAPE..captura_lacp(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

							select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 0,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								cc.concepto,
								fecha_mov = @fecha_mov,
								monto = abs(@monto_cuenta),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @folio,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_mov as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = 3
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = 112 and
								tm.id_tipomov = 1001 and
								cc.concepto like 'ACLARACION IMPROCEDENTE CMV FINANZAS%'
								and cc.num_cuenta like '40800100170000%'


							----- actualizaci�n de estado de cuenta
							UPDATE	HAPE..EDO_DE_CUENTA
							SET	SALDO_ACTUAL = SALDO_ACTUAL - @monto, 
								FECHA = @FECHA_MOV
							WHERE	
								numero = @numero
								and id_mov = @id_mov
								AND Id_Tipo_persona = @id_tipo_persona

							---- inserci�n a la tabla de TBL_BANCA_COBROS_AUTOMATICOS_COMISIONES
							SELECT @max_cont_mov = MAX(CONTADOR) FROM HAPE..MOVIMIENTOS 
							WHERE NUMERO = @NUMERO AND ID_TIPOMOV = @ID_TIPOMOV

							insert into BANCA..TBL_BANCA_COBROS_AUTOMATICOS_COMISIONES 
							(contador_movimientos,numero,id_tipomov,monto,num_poliza,folio,numusuario,fecha_mov,id_comision)
							values(@max_cont_mov,BANCA.dbo.FN_BANCA_CIFRAR(@numero),@id_tipomov,@monto_cuenta,@num_poliza,@folio,@numusuario,@fecha_mov,@id_comision)
							-------------------------------- IVA ---------------------------
							SELECT @max_cont_mov = MAX(CONTADOR) FROM HAPE..MOVIMIENTOS 
							WHERE NUMERO = @NUMERO AND ID_TIPOMOV = @id_mov_iva

							insert into BANCA..TBL_BANCA_COBROS_AUTOMATICOS_COMISIONES 
							(contador_movimientos,numero,id_tipomov,monto,num_poliza,folio,numusuario,fecha_mov,id_comision)
							values(@max_cont_mov,BANCA.dbo.FN_BANCA_CIFRAR(@numero),@id_mov_iva,@iva_cuenta,@num_poliza,@folio,@numusuario,@fecha_mov,@id_comision)

							select @saldo_total_pagado = @saldo_total_pagado + @monto_cuenta
						end

					print 'paso 06'
					if @saldo_inver > 0 and @pagada = 0
						begin
						if @saldo_restante > @saldo_inver and @saldo_restante > 0
							begin	
								select	
									@monto_cuenta = round(@saldo_inver / (1 + @tasa_iva), 2),
									@iva_cuenta = round(@saldo_inver - @saldo_inver / (1 + @tasa_iva), 2)
								select @saldo_restante = @saldo_restante - @saldo_inver
							end
						else if @saldo_restante > 0
							begin
								print 'liquida saldo restante con inver'
								select	
									@monto_cuenta = round(@saldo_restante / (1 + @tasa_iva), 2),
									@iva_cuenta = round(@saldo_restante - @saldo_restante / (1 + @tasa_iva), 2)
								select @saldo_restante = 0
								select @pagada = 1
							end

							select @monto = (@monto_cuenta + @iva_cuenta)
							select @saldo_inver = (@saldo_inver - @monto_cuenta)

							/*====================	RETIRO DE INVERDIN�MICA CMV POR TRANSFERENCIA A ACLARACI�N IMPROCEDENTE	================
							  ==============================================================================================================*/
							select @id_tipomov = 1017
							SELECT @id_mov = ID_MOV, @operacion = OPERACION FROM HAPE..TIPO_MOV WHERE ID_TIPOMOV = @id_tipomov
							INSERT	HAPE..MOVIMIENTOS
								(
								NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
								NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
								ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR
								)
							VALUES	(
								@numero, 'T', @fecha_mov, @monto_cuenta, @saldo_inver, 'D',
								@num_poliza, @folio, GETDATE(), @id_persona, @numusuario,
								@id_tipomov, @id_mov, 1, 'S'
								)

							/*====================	I.V.A. POR ACLARACI�N IMPROCEDENTE DE INVERDIN�MICA CMV EN CMV FINANZAS	================
							  ==============================================================================================================*/
							select @saldo_inver = (@saldo_inver - @iva_cuenta)
							select @id_mov_iva = 1011
							INSERT	HAPE..MOVIMIENTOS
								(
								NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
								NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
								ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR
								)
							VALUES	(
								@numero, 'T', @fecha_mov, @iva_cuenta, @saldo_inver, 'D',
								@num_poliza, @folio, GETDATE(), @id_persona, @numusuario,
								@id_mov_iva, @id_mov, 1, 'S'
								)
							/*========================================	CAIDA CONTABLE CAPTURA_LACP	=======================================
							  ==============================================================================================================*/

							 insert	HAPE..captura_lacp(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

							select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 0,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = tm.descripcion,
								fecha_mov = @fecha_mov,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @folio,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_mov as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = 3
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = 103 and
								tm.id_tipomov = 350 and
								cc.concepto like '%vista%'
								and cc.num_cuenta like '211%'

							 insert	HAPE..captura_lacp(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

							select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 0,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								cc.concepto,
								fecha_mov = @fecha_mov,
								monto = abs(@iva_cuenta),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @folio,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_mov as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = 3
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = 103 and
								tm.id_tipomov = 350 and
								cc.concepto like 'I.V.A. TRASLADADO%'
								and cc.num_cuenta like '23200300010000%'


							 insert	HAPE..captura_lacp(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

							select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 0,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								cc.concepto,
								fecha_mov = @fecha_mov,
								monto = abs(@monto_cuenta),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @folio,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_mov as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = 3
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = 103 and
								tm.id_tipomov = 350 and
								cc.concepto like 'ACLARACION IMPROCEDENTE CMV FINANZAS%'
								and cc.num_cuenta like '40800100170000%'



							/*========================================	ACTUALIZACI�N DE ESTADO DE CUENTA	================================
							  ==============================================================================================================*/
 
							UPDATE	HAPE..EDO_DE_CUENTA
							SET	SALDO_ACTUAL = SALDO_ACTUAL - @monto,
								FECHA = @FECHA_MOV
							WHERE	
								numero = @numero
								and id_mov = @id_mov
								AND Id_Tipo_persona = @id_tipo_persona

							---- inserci�n a la tabla de TBL_BANCA_COBROS_AUTOMATICOS_COMISIONES
							SELECT @max_cont_mov = MAX(CONTADOR) FROM HAPE..MOVIMIENTOS 
							WHERE NUMERO = @NUMERO AND ID_TIPOMOV = @ID_TIPOMOV

							insert into TBL_BANCA_COBROS_AUTOMATICOS_COMISIONES 
							(contador_movimientos,numero,id_tipomov,monto,num_poliza,folio,numusuario,fecha_mov,id_comision)
							values(@max_cont_mov,BANCA.dbo.FN_BANCA_CIFRAR(@numero),@id_tipomov,@monto_cuenta,@num_poliza,@folio,@numusuario,@fecha_mov,@id_comision)
							-------------------------------- IVA ---------------------------
							SELECT @max_cont_mov = MAX(CONTADOR) FROM HAPE..MOVIMIENTOS 
							WHERE NUMERO = @NUMERO AND ID_TIPOMOV = @id_mov_iva

							insert into TBL_BANCA_COBROS_AUTOMATICOS_COMISIONES 
							(contador_movimientos,numero,id_tipomov,monto,num_poliza,folio,numusuario,fecha_mov,id_comision)
							values(@max_cont_mov,BANCA.dbo.FN_BANCA_CIFRAR(@numero),@id_mov_iva,@iva_cuenta,@num_poliza,@folio,@numusuario,@fecha_mov,@id_comision)

							select @saldo_total_pagado = @saldo_total_pagado + @monto_cuenta
						end

					print 'saldo_restante: ' +cast(@saldo_restante as varchar) + ' saldo ahorro: ' +cast(@saldo_ahorro as varchar)
					print 'paso 07'
					if @saldo_ahorro > 0 and @pagada = 0
						begin
						if (@saldo_restante > @saldo_ahorro) and @saldo_restante > 0
							begin
								select	
									@monto_cuenta = round(@saldo_ahorro / (1 + @tasa_iva), 2),
									@iva_cuenta = round(@saldo_ahorro - @saldo_ahorro / (1 + @tasa_iva), 2)
								select @saldo_restante = @saldo_restante - @saldo_ahorro
							end
						else if @saldo_restante > 0
							begin
								print 'liquida saldo restante con ahorro'
								select	
									@monto_cuenta = round(@saldo_restante / (1 + @tasa_iva), 2),
									@iva_cuenta = round(@saldo_restante - @saldo_restante / (1 + @tasa_iva), 2)
								select @saldo_restante = 0
								select @pagada = 1
							end

							select @monto = (@monto_cuenta + @iva_cuenta)
							select @saldo_ahorro = (@saldo_ahorro - @monto_cuenta)

							/*======================	RETIRO DE AHORRO CMV POR TRANSFERENCIA A ACLARACI�N IMPROCEDENTE	================
							  ==============================================================================================================*/
							select @id_tipomov = 1016
							SELECT @id_mov = ID_MOV, @operacion = OPERACION FROM HAPE..TIPO_MOV WHERE ID_TIPOMOV = @id_tipomov
							INSERT	HAPE..MOVIMIENTOS
								(
								NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
								NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
								ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR
								)
							VALUES	(
								@numero, 'T', @fecha_mov, @monto_cuenta, @saldo_ahorro, 'D',
								@num_poliza, @folio, GETDATE(), @id_persona, @numusuario,
								@id_tipomov, @id_mov, 1, 'S'
								)

							/*======================	I.V.A. POR ACLARACI�N IMPROCEDENTE DE AHORRO CMV EN CMV FINANZAS	=================
							  ==============================================================================================================*/
							select @saldo_ahorro = (@saldo_ahorro - @iva_cuenta)
							select @id_mov_iva = 1010
							INSERT	HAPE..MOVIMIENTOS
								(
								NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
								NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
								ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR
								)
							VALUES	(
								@numero, 'T', @fecha_mov, @iva_cuenta, @saldo_ahorro, 'D',
								@num_poliza, @folio, GETDATE(), @id_persona, @numusuario,
								@id_mov_iva, @id_mov, 1, 'S'
								)
							/*========================================	CAIDA CONTABLE CAPTURA_LACP	=======================================
							  ==============================================================================================================*/

							insert	HAPE..captura_lacp(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

							select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 0,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = tm.descripcion,
								fecha_mov = @fecha_mov,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @folio,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_mov as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = 3
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = 100 and
								tm.id_tipomov = 310 and
								cc.concepto like '%vista%'
								and cc.num_cuenta like '211%'

							insert	HAPE..captura_lacp(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

							select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 0,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								cc.concepto,
								fecha_mov = @fecha_mov,
								monto = abs(@iva_cuenta),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @folio,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_mov as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = 3
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = 100 and
								tm.id_tipomov = 310 and
								cc.concepto like 'I.V.A. TRASLADADO%'
								and cc.num_cuenta like '23200300010000%'


							insert	HAPE..captura_lacp(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

							select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 0,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								cc.concepto,
								fecha_mov = @fecha_mov,
								monto = abs(@monto_cuenta),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @folio,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_mov as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = 3
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = 100 and
								tm.id_tipomov = 310 and
								cc.concepto like 'ACLARACION IMPROCEDENTE CMV FINANZAS%'
								and cc.num_cuenta like '40800100170000%'
						
							/*========================================	ACTUALIZACI�N DE ESTADO DE CUENTA	================================
							  ==============================================================================================================*/
							UPDATE	HAPE..EDO_DE_CUENTA
							SET	SALDO_ACTUAL = SALDO_ACTUAL - @monto,
								FECHA = @FECHA_MOV
							WHERE	
								numero = @numero
								and id_mov = @id_mov
								AND Id_Tipo_persona = @id_tipo_persona

							---- inserci�n a la tabla de TBL_BANCA_COBROS_AUTOMATICOS_COMISIONES
							SELECT @max_cont_mov = MAX(CONTADOR) FROM HAPE..MOVIMIENTOS 
							WHERE NUMERO = @NUMERO AND ID_TIPOMOV = @ID_TIPOMOV

							insert into BANCA..TBL_BANCA_COBROS_AUTOMATICOS_COMISIONES 
							(contador_movimientos,numero,id_tipomov,monto,num_poliza,folio,numusuario,fecha_mov,id_comision)
							values(@max_cont_mov,BANCA.dbo.FN_BANCA_CIFRAR(@numero),@id_tipomov,@monto_cuenta,@num_poliza,@folio,@numusuario,@fecha_mov,@id_comision)
							-------------------------------- IVA ---------------------------
							SELECT @max_cont_mov = MAX(CONTADOR) FROM HAPE..MOVIMIENTOS 
							WHERE NUMERO = @NUMERO AND ID_TIPOMOV = @id_mov_iva

							insert into BANCA..TBL_BANCA_COBROS_AUTOMATICOS_COMISIONES 
							(contador_movimientos,numero,id_tipomov,monto,num_poliza,folio,numusuario,fecha_mov,id_comision)
							values(@max_cont_mov,BANCA.dbo.FN_BANCA_CIFRAR(@numero),@id_mov_iva,@iva_cuenta,@num_poliza,@folio,@numusuario,@fecha_mov,@id_comision)

							select @saldo_total_pagado = @saldo_total_pagado + @monto_cuenta
						end


					print 'paso 08'
					update BANCA..TBL_BANCA_COMISIONES set saldo = round(saldo - @saldo_total_pagado,2,1) ,fecha_actualizacion= @fecha_mov
					where id_comision = @id_comision

				end
			end -- inicio

			begin -- commit
				
					if @tran_count = 0
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
			end -- commit

			print 'paso 09'
			if exists (select * from BANCA..TBL_BANCA_COMISIONES where id_comision = @id_comision and saldo = 0)
			begin
				update BANCA..TBL_BANCA_COMISIONES set pagada = 1,fecha_pago = @fecha_mov where id_comision = @id_comision
				select @status = 1,@error_message ='Se ha efectuado correctamente el cobro de la aclaraci�n improcedente'

				----------------------------se valida el cambio de estatus---------------------------------------------------------
				declare @folioUNE int
				select @folioUNE = folio_UNE from TBL_BANCA_COMISIONES where id_comision = @id_comision


				if exists(select 1 from hape..tbl_une_reporte where num_folio= @folioUNE and id_satisfactorio = 1)
				begin
					if exists (select top 1 * from TBL_CALLCENTER_REPORTES_MULTIFOLIO where folio_une = @folioUNE and (ID_SATISFACTORIO =2 and DEPOSITADO is null))
					begin
						print'el socio tiene reportes procedentes pendientes'
					end
					else
					begin
						update 
							HAPE..TBL_UNE_REPORTE 
						set 
							ID_ESTATUS_REPORTE = 6
						where
								NUM_FOLIO = @folioUNE
							print 'no hay procedentes pendientes'
						end
				end

				--if not exists (select top 1 * from TBL_CALLCENTER_REPORTES_MULTIFOLIO where folio_une = 945 and ((ID_SATISFACTORIO is null) or(ID_SATISFACTORIO =2 and DEPOSITADO is null)))
				--begin
				--	update HAPE..TBL_UNE_REPORTE set ID_ESTATUS_REPORTE = 6
				--	where
				--			NUM_FOLIO = @folioUNE
				--			print 'dice que no hay procedentes'
				--end
				--else 
				--begin
				--	if exists (select top 1 * from TBL_CALLCENTER_REPORTES_MULTIFOLIO where folio_une = 941 and ID_SATISFACTORIO =2 and depositado is null)
				--	begin
				--		print 'El reporte tiene folios pendientes procedentes'
				--	end
				--	else if exists (select top 1 * from TBL_CALLCENTER_REPORTES_MULTIFOLIO where folio_une = 941 and ID_SATISFACTORIO = 2 and depositado is null)
				--	begin
				--		print 'El reporte tiene folios pendientes procedentes'
				--	end
				--	else
				--	begin
				--		print 'dice que ya dr puede actualizar el estatus'

				--		update HAPE..TBL_UNE_REPORTE set ID_ESTATUS_REPORTE = 6
				--		where
				--				NUM_FOLIO = @folioUNE
				--	end
				--end

			end

		end -- transacci�n

		
		end try -- try principal
		
		begin catch -- catch principal
		
			
			select @status=coalesce(@status, 0)

			select	--@status=@status,
					--@status =error_state(),	
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end

					--select @status=coalesce(@status, 0)
			-- revertir transacci�n si es necesario
			if @tran_scope = 1
			begin
				rollback tran @tran_name
			end


		
		end catch -- catch principal
		
		begin -- reporte de status

			select	@status estatus,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message mensaje
				
		end -- reporte de status
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_REALIZA_PAGO_ACLARACION_PROCEDENTE]    Script Date: 06/11/2019 10:41:30 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			EDSON
Fecha			20190620
Objetivo		Realiza un pago de una comision 
Proyecto		Banca en l�nea
Ticket			______
*/

ALTER PROCEDURE [dbo].[SP_BANCA_REALIZA_PAGO_ACLARACION_PROCEDENTE]
		@id_folio_banca int,
		@numero int,
		@importe_solucion money,
		@id_mov_deposito int, -- cuenta donde se realizara el deposito de la aclaracion
		@numusuario int,
		@tipo_transferencia int, --1: transferencia mismo banco, 2: transferencia entre otros bancos
		@id_tipo_persona int = null 
as

	begin -- procedimiento
		
		--declare	@status int = 200
		
		begin try -- try principal
		
			begin -- inicio

			
				begin -- declaraciones
					declare	
						@status int = 0,-- = 200
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@message varchar(255)

					declare	
						@tran_name varchar(32) = 'SP_BANCA_REALIZA_PAGO_ACLARACION_PROCEDENTE',
						@tran_count int = @@trancount,
						@tran_scope bit = 0

					declare
						@num_poliza int,
						@folio_afecta bigint,
						@fecha_mov datetime,
						@saldo_cuenta money,
						@id_tipomov int,
						@id_persona int,
						@id_tipomov_cargo int = 702,---Cargo Cuenta Contable
						@id_mov_cargo int = 108, --CUENTAS CONTABLES
						---
						@tipo_poliza varchar(1) = 'M',
						@ccostos_origen varchar(10),
						@nombre_origen varchar(100),
						@Ap_paterno_origen varchar(100),
						@Ap_materno_origen varchar(100)

				end -- declaraciones

			end -- inicio

			begin --validaciones

				print 'paso 01'	

				if @tipo_transferencia = 1
				begin
					---No existe la comision que desea cobrar
					if not exists(select * from BANCA..TBL_BANCA_TRANSFERENCIAS_INTERNAS where 
					id_banca_folio = @id_folio_banca and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero)
					and not exists(select * from BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS where 
					id_banca_folio = @id_folio_banca and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero)
					begin
						select @status = 0,@message = 'No existe el folio ingresado'
						raiserror (@message, 11, 0)
					end	
					
				end
				
			end
			
		begin -- transacci�n	

			begin --Datos generales

				print 'paso 02'

				---Se obtiene el numero de poliza
				select @num_poliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
				select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'BANCA ELECTRONICA')
				and dia = DAY(GETDATE())

				select @fecha_mov = ISNULL (@fecha_mov,getdate())

				select @id_tipo_persona = ISNULL(@id_tipo_persona,1)

				if @tipo_transferencia = 1
				begin

					----se obtienen los datos del socio
					select 
						@id_persona = p.Id_Persona,
						@nombre_origen = p.Nombre_s,
						@Ap_paterno_origen = p.Apellido_Paterno,
						@Ap_materno_origen = p.Apellido_Materno,
						@ccostos_origen = s.Ccostos
					from HAPE..PERSONA p
					join HAPE.dbo.sucursales s
						on s.id_de_sucursal = p.id_de_sucursal
					where Numero = @numero and Id_Tipo_Persona = @id_tipo_persona

					----se obtiene el saldo actual y tipo de movimiento a realizar
					select 
						@saldo_cuenta = Saldo_Actual ,
						@id_tipomov = case 
							when Id_mov = 100 then 10
							when Id_mov = 103 then 50 end
					from HAPE..EDO_DE_CUENTA
					where
						numero  = @numero
						and Id_mov = @id_mov_deposito

					

				end

			end

			begin -- inicio

				print 'paso 03 (inicio de transacci�n)'
				if @tran_count = 0
					begin tran @tran_name
				else
					save tran @tran_name
				
				select @tran_scope = 1

				--=======================================	INICIO PROCESO	=======================================

				if @tipo_transferencia = 1
				begin

					INSERT INTO BANCA..TBL_BANCA_FOLIOS (numero_socio,fecha_alta)
					values 
						(@numero,@fecha_mov)

					select @folio_afecta =  MAX(id_banca_folio) from 
					BANCA..TBL_BANCA_FOLIOS where numero_socio = @numero
					

				/*====================	DEPOSITO POR ACLARACI�N PROCEDENTE	================*/
					INSERT	HAPE..MOVIMIENTOS
					(
						NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
						NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
						ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR
					)
					VALUES	(
						@numero, 'T', @fecha_mov, @importe_solucion, 
						round((@saldo_cuenta + @importe_solucion),2), 'D',
						@num_poliza, @folio_afecta, GETDATE(), @id_persona, @numusuario,
						@id_tipomov, @id_mov_deposito, 1, 'S'
					)

					/*========================================	CAIDA CONTABLE CAPTURA_LACP	=======================================
					==============================================================================================================*/
					--Abono
					insert	HAPE..captura_lacp(
						id_persona,
						activo,
						numero,
						nombre_s,
						apellido_paterno,
						apellido_materno,
						total_movs,
						total_ficha,
						id_tipomov,
						cuenta,
						concepto,
						fecha_mov,
						monto,
						id_mov,
						num_poliza,
						tipo_poliza,
						folio,
						id_tipo_persona,
						num_cheq,
						desc1,
						desc2,
						planx,
						desc3,
						fecha_dpf_final,
						num_dpf,
						tasa,
						interes,
						dias,
						debe_haber,
						numusuario,
						numero_fin,
						plazo,
						interes_ord,
						interes_mor,
						contador_provision,
						ccostos,
						nombre_beneficiario,
						parentesco_beneficiario,
						porcentaje_beneficiario,
						nombre_beneficiario2,
						parentesco_beneficiario2,
						porcentaje_beneficiario2,
						numero_fin_lacp,
						id_esquema,
						titular,
						num_ptmo,
						id_amortizacion,
						id_renovado,
						reestructura,
						id_origen
					)

					select	@id_persona,
						'T',
						@numero,
						@nombre_origen,
						@Ap_paterno_origen,
						@Ap_materno_origen,
						total_movs = 0,
						total_ficha = 0,
						tm.id_tipomov,
						cuenta = cc.num_cuenta,
						concepto = tm.descripcion,
						fecha_mov = @fecha_mov,
						monto = abs(@importe_solucion),
						tm.id_mov,
						num_poliza = @num_poliza,
						tipo_poliza = @tipo_poliza,
						folio = @folio_afecta,
						id_tipo_persona = 1,
						num_cheq = 0,
						desc1 = 0,
						desc2 = 0,
						planx = null,
						desc3 = 0,
						fecha_dpf_final = cast(@fecha_mov as date),
						num_dpf = 0,
						tasa = 0,
						interes = 0,
						dias = 0,
						debe_haber = 'H',
						numusuario = @numusuario,
						numero_fin = null,
						plazo = null,
						interes_ord = null,
						interes_mor = null,
						contador_provision = null,
						@ccostos_origen,
						nombre_beneficiario = '',
						parentesco_beneficiario = '',
						porcentaje_beneficiario = 0,
						nombre_beneficiario2 = '',
						parentesco_beneficiario2 = '',
						porcentaje_beneficiario2 = 0,
						numero_fin_lacp = null,
						id_esquema = null,
						titular = 'S',
						num_ptmo = null,
						id_amortizacion = null,
						id_renovado = null,
						reestructura = null,
						id_origen = 3
						from	HAPE.dbo.tipo_mov tm
						join HAPE.dbo.cuentas_contables cc
						on tm.id_mov = @id_mov_deposito and
						tm.id_tipomov = @id_tipomov 
						--and cc.concepto like '%vista%'
						--and like '211%'
						and cc.num_cuenta = case 
							when @id_mov_deposito = 100 then '21200000000000' 
							when @id_mov_deposito = 103 then '21100000000000'
							when @id_mov_deposito = 112 then '21600000000000'
						end
					
					--Cargo
					insert	HAPE..captura_lacp(
						id_persona,
						activo,
						numero,
						nombre_s,
						apellido_paterno,
						apellido_materno,
						total_movs,
						total_ficha,
						id_tipomov,
						cuenta,
						concepto,
						fecha_mov,
						monto,
						id_mov,
						num_poliza,
						tipo_poliza,
						folio,
						id_tipo_persona,
						num_cheq,
						desc1,
						desc2,
						planx,
						desc3,
						fecha_dpf_final,
						num_dpf,
						tasa,
						interes,
						dias,
						debe_haber,
						numusuario,
						numero_fin,
						plazo,
						interes_ord,
						interes_mor,
						contador_provision,
						ccostos,
						nombre_beneficiario,
						parentesco_beneficiario,
						porcentaje_beneficiario,
						nombre_beneficiario2,
						parentesco_beneficiario2,
						porcentaje_beneficiario2,
						numero_fin_lacp,
						id_esquema,
						titular,
						num_ptmo,
						id_amortizacion,
						id_renovado,
						reestructura,
						id_origen
					)

					select	@id_persona,
						'T',
						@numero,
						@nombre_origen,
						@Ap_paterno_origen,
						@Ap_materno_origen,
						total_movs = 0,
						total_ficha = 0,
						tm.id_tipomov,
						cuenta = cc.num_cuenta,
						concepto = cc.Concepto,
						fecha_mov = @fecha_mov,
						monto = abs(@importe_solucion),
						tm.id_mov,
						num_poliza = @num_poliza,
						tipo_poliza = @tipo_poliza,
						folio = @folio_afecta,
						id_tipo_persona = 1,
						num_cheq = 0,
						desc1 = 0,
						desc2 = 0,
						planx = null,
						desc3 = 0,
						fecha_dpf_final = cast(@fecha_mov as date),
						num_dpf = 0,
						tasa = 0,
						interes = 0,
						dias = 0,
						debe_haber = 'D',
						numusuario = @numusuario,
						numero_fin = null,
						plazo = null,
						interes_ord = null,
						interes_mor = null,
						contador_provision = null,
						@ccostos_origen,
						nombre_beneficiario = '',
						parentesco_beneficiario = '',
						porcentaje_beneficiario = 0,
						nombre_beneficiario2 = '',
						parentesco_beneficiario2 = '',
						porcentaje_beneficiario2 = 0,
						numero_fin_lacp = null,
						id_esquema = null,
						titular = 'S',
						num_ptmo = null,
						id_amortizacion = null,
						id_renovado = null,
						reestructura = null,
						id_origen = 3
						from	HAPE.dbo.tipo_mov tm
						join HAPE.dbo.cuentas_contables cc
						on tm.id_mov = @id_mov_cargo
						and tm.id_tipomov = @id_tipomov_cargo
						where
						cc.num_cuenta = '51200400220000'
							

					/*========================================	ACTUALIZACI�N DE ESTADO DE CUENTA	================================
					==============================================================================================================*/
					UPDATE	HAPE..EDO_DE_CUENTA
					SET	SALDO_ACTUAL = round(SALDO_ACTUAL + @importe_solucion,2),
						FECHA = @FECHA_MOV
					WHERE	
						numero = @numero
						and id_mov = @id_mov_deposito
						AND Id_Tipo_persona = @id_tipo_persona
					
					/*========================================	ACTUALIZACI�N DE REPORTE DE UNE	================================
					==============================================================================================================*/
					/*update HAPE..TBL_UNE_REPORTE set ID_ESTATUS_REPORTE = 6 
					where
						 folio_autorizacion_banca = @id_folio_banca*/
						 

						 update banca..TBL_CALLCENTER_REPORTES_MULTIFOLIO set depositado = 1 where folio_autorizacion = @id_folio_banca
						 
						 declare @folioUNE int = (select folio_une from TBL_CALLCENTER_REPORTES_MULTIFOLIO where folio_autorizacion = @id_folio_banca)
						 --select folio_une from TBL_CALLCENTER_REPORTES_MULTIFOLIO where folio_autorizacion = 24
						 if not exists (select top 1 1 from TBL_CALLCENTER_REPORTES_MULTIFOLIO where folio_une = @folioUNE and depositado is null)
						 begin
							update 
								HAPE..TBL_UNE_REPORTE set ID_ESTATUS_REPORTE = 6 
							where
								 NUM_FOLIO = @folioUNE
							--select 'ya no hay reportes, se tiene que actualizar el estatus del reporte'
							--select ID_ESTATUS_REPORTE,* from hape..TBL_UNE_REPORTE where NUM_FOLIO = @folioUNE
						 end
						 --select * from hape..TBL_UNE_REPORTE where NUM_FOLIO =  @folioUNE

				end ---fin de transferencias internas

	
			end -- inicio

			begin -- commit
				
					if @tran_count = 0
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				select @status = 1,@error_message ='Se ha efectuado correctamente el deposito de la aclaraci�n procedente.'
			end -- commit

		

		end -- transacci�n

		
		end try -- try principal
			
		
		begin catch -- catch principal
		
			
			select @status=coalesce(@status, 0)

			select	--@status=@status,
					--@status =error_state(),	
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end

					--select @status=coalesce(@status, 0)
			-- revertir transacci�n si es necesario
			if @tran_scope = 1
			begin
				rollback tran @tran_name
			end


		
		end catch -- catch principal
		
		begin -- reporte de status

			select	@status estatus,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message mensaje
				
		end -- reporte de status
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_REALIZA_PAGO_SERVICIO]    Script Date: 27/01/2020 03:55:49 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			MAXIMILIANO GONZALEZ BETANCOURT
UsuarioRed		GOBM391548
Fecha			20180417
Objetivo		OBTIENE EL CATALOGO DE PREGUNTAS PARA QUE EL SOCIO SELECCIONE UNA 
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc
	[dbo].[SP_BANCA_REALIZA_PAGO_SERVICIO]
		-- par�metros
		@ClabeCorresponsaliasRetiro varchar(20),
		@NumeroSocio varchar(10),
		@monto decimal(18,2),
		@IdProducto int ,
		@idServicio int,
		@numeroReferencia varchar(50) = null ,
		@telefono varchar (20) = null,
		@idTipoPersona int = 1,
		@idTipoFront int,
		@tipo_origen int = 3, -- banca web 
		@esConsulta bit = 0

		-- [aqu� van los par�metros]
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@estatus int = 1,
						@error_message varchar(255) = '',
						@validacion varchar(255),
						@idTransferencia int,
						@SaldoActual decimal(18,2),
						@AhorroBase decimal (18,2),
						@SaldoDisponible decimal(18,2),
						@IdCuentaRetiro int,
						@mensaje_validacion varchar (100),
						@numero_int int,
						@fechaTransaccion datetime =  getDate(),
						@id_folio_banca bigint,
						@idEstatusTransfenrecia int = 1, --Pendiente por aplicar,
						@id_origen_operacion int = 3

				declare	@tran_name varchar(32) = 'REALIZA_PAGO_SERVICIO',
						@tran_count int = @@trancount,
						@tran_scope bit = 0
			
			end -- inicio

			--validaciones generales de cmv finanzas
			select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NumeroSocio,1)
			IF(@mensaje_validacion is not null)
				 raiserror (@mensaje_validacion, 11, 0)
			
			select @id_origen_operacion = case when @tipo_origen = 1 then 3 else @tipo_origen end

			set @numero_int = CAST(@NumeroSocio as int )


			IF @esConsulta = 1
			begin
			 ---- Generacion de folio de banca
				insert into BANCA..TBL_BANCA_FOLIOS (numero_socio,fecha_alta)
				values (@numero_int,@fechaTransaccion)

				select @id_folio_banca = MAX (id_banca_folio) from BANCA..TBL_BANCA_FOLIOS where
				numero_socio = @numero_int
			--=========== end Generacion de folio de banca
						
					---INSERTAMOS LA TRABSFERENCIAS REFERENTE AL PAGO 
				INSERT INTO TBL_BANCA_TRANSFERENCIAs_PAGO_SERVICIOS
					(id_producto,id_servicio,numero_socio,monto,numero_referencia,fecha_alta_pago,
					id_estatus_transferencia,id_origen,clabe_corresponsalias_retiro, telefono,id_banca_folio)
				VALUES(@idProducto,@idServicio,BANCA.dbo.FN_BANCA_CIFRAR(@numeroSocio),@monto,@numeroReferencia,GETDATE(),@idEstatusTransfenrecia, @tipo_origen,@ClabeCorresponsaliasRetiro,@telefono, @id_folio_banca)

				goto RESULT

			end
			--obtener el id_mov de la cuenta de retiro
			select @IdCuentaRetiro = ID_MOV from HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE NUMERO = @numeroSocio  and CUENTA = @ClabeCorresponsaliasRetiro
			/*if (@IdCuentaRetiro is null or @IdCuentaRetiro = '')
			begin
					SELECT id_excepcion AS estatus , descripcion as mensaje 
					FROM CAT_BANCA_EXCEPTIONS
					WHERE id_excepcion =362
					return
			end*/

			
				-- obtenes el saldo actual de estado de cuenta para despues validar que no este corruto al momento de afectarlo
				select @SaldoActual = Saldo_Actual 
				from HAPE..EDO_DE_CUENTA
				where Numero = @NumeroSocio and Id_mov = @IdCuentaRetiro

				-- SE VALIDA QUE EL SALDO ACTUAL SEA MAYOR A CERO PARA PODER EFECTUAR EL MOVIMIENTO
				if @SaldoActual <= 0 --or @SaldoActual is null
				begin
					SELECT id_excepcion AS estatus , descripcion as mensaje 
					FROM CAT_BANCA_EXCEPTIONS
					WHERE id_excepcion =346
					return
				end


				--  SI EL PAGO SE QUIERE REALIZAR DESDE  SU CUENTA DE AHORRO HAY QUE VALIDAR EL AHORRO BASE
				IF(@IdCuentaRetiro = 100)
				BEGIN

					SELECT @AhorroBase = isnull(sum(isnull(Ahorro_Base,0)),0) 
					FROM HAPE..EDO_DE_CUENTA 
					WHERE  Numero = @NumeroSocio and Id_Tipo_persona = @idTipoPersona and Saldo_Actual  >0
					SET @SaldoDisponible = @SaldoActual - @AhorroBase

					  --print '@idTipoPersona: '+ cast(@idTipoPersona as varchar)
				--      print 'saldo actual: '+ cast(@SaldoActual as varchar)
				--      print '@SaldoDisponible_ '+ cast(@SaldoDisponible as varchar)
					  --print '@@AhorroBase '+ cast(@AhorroBase as varchar)

					IF @SaldoDisponible <=0 
					BEGIN
				 
						SELECT id_excepcion AS estatus , descripcion as mensaje 

						FROM CAT_BANCA_EXCEPTIONS
						WHERE id_excepcion =346
						  return
					END
				END
				ELSE -- ASIGNAMOS EL SALDO ACTUAL AL SALDO DISPONIBLE  PARA SEGUIR RELIZANDO OPERACION CUANDO LA CUENTA DE RETIRO NO ES AHORRO
					SET @SaldoDisponible = @SaldoActual
           

				-- VALIDA QUE EL MONTO DE LA OPERACION SEA MENOR AL SALDO DISPONIBLE PARA PODER EFECTUAR LA OPERACION
				if @monto > @SaldoDisponible
				begin	
					SELECT id_excepcion AS estatus , descripcion as mensaje 
					FROM CAT_BANCA_EXCEPTIONS
					WHERE id_excepcion =346
					return
				end
		 

			--===================================	VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS	===============================
				BEGIN
					declare 
						@fecha_ datetime = getdate(),
						@tipoTransferencia int
					
					select @tipoTransferencia = 7	---7.- PAGO DE SERVICIOS

					select 
						@estatus = estatus, @mensaje_validacion = msj  
					from  
						FN_VALIDAR_LIMITES_TRANSFERENCIAS_DIARIO (@tipoTransferencia,@numeroSocio,@monto,@fecha_,0)

					if @estatus <> 200
					begin
						SELECT @estatus AS estatus , @mensaje_validacion as mensaje 
						return
						--raiserror (@mensaje_validacion, 11, 0)
					end
				END ---VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS

			----------------------  QUERYS PARA EFECTUAR EL PAGO , MOVIMIENTOS , CAPTURA , ------------------------------------------------
			

			DECLARE 

				@SaldoDespuesDeOperacion decimal (18,2),
				@NumPoliza bigint  = 0000,
				@TipoPoliza varchar(1) ='D',
				@NumUsuarioBanca int = 1012 ,
				@IdPersona int,
				@IdTipoMov int,							
				@CuentaContable varchar(14) =	'',
				@CuentaContableSucursal varchar(14) =	'',
				@NomreS varchar(50),
				@ApellidoPaterno varchar(50),
				@ApellidoMaterno varchar(50),
				@TotalMovs int = 1,
				@ConceptoCaptura  varchar(1000)='',
				@DebeHaber varchar(1)='D',
				@id_bitacora int = 21, --pago de servicio
				@ccostos_socio varchar(20),
				@ccostos_compensacion varchar(20)

				-- OBTENEMOS EL ID_TIPOMOV
				if @IdCuentaRetiro = 100   -- AHORRO
					SET @IdTipoMov  = 1186
				else if @IdCuentaRetiro = 103-- INVER
					SET @IdTipoMov  = 1189
				else if @IdCuentaRetiro = 112 -- DEBITO
					SET @IdTipoMov  = 1192



				-- OBTENEMOS EL ID PERSONA
				SELECT
					@IdPersona = p.Id_Persona , 
					@NomreS = p.Nombre_s , @ApellidoPaterno =ISNULL(p.Apellido_Paterno,''), @ApellidoMaterno = ISNULL(p.Apellido_Materno,' '),
					@CuentaContableSucursal = nSuc.Num_Cuenta_Compensacion,
					@ccostos_socio = s.Ccostos
				FROM HAPE..PERSONA p
				join HAPE.dbo.sucursales s
					on s.id_de_sucursal = p.id_de_sucursal
				join HAPE..NUM_SUCURSAL nSuc 
					on s.Num_Sucursal = nSuc.Num_Sucursal
				WHERE Numero = @NumeroSocio AND Id_Tipo_Persona  = @idTipoPersona

				---Se obtiene el numero de poliza de banca
				select @NumPoliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
				select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'BANCA ELECTRONICA')
				and dia = DAY(GETDATE())

				select @ccostos_compensacion = Ccostos from HAPE..NUM_SUCURSAL
				WHERE
					Num_Sucursal = 99 --'MEDIOS DE PAGO%'

				--REGRESAMOS EL SALDO QUE SE VE REFLEJADO  EN ESTADO DE CUENTA PARA PODER EFECTUAR LA OPERACION
				IF @IdCuentaRetiro = 100
					SET @SaldoDisponible = @SaldoDisponible + @AhorroBase


				--OBTENEMOS SALDO DESPUES DE LA OPERACION
				SET @SaldoDespuesDeOperacion = @SaldoDisponible - @monto


			
				
				BEGIN --SE INICIALIZA LA TRANZACION PERO PRIMERO SE VALIDA SI EXISTTE UNA TRANSACCION PADRE

							if @tran_count = 0
								begin tran @tran_name
							else
								save tran @tran_name
				
							select @tran_scope = 1
				
						
					     --- SE REVISA QUE EL SALDO ACTUAL  DE EDO DE CUENTA SIGUE SIENDO EL MISMO CON EL QUE HICIMOS LOS CALCULOS ---
						 IF exists (select 1 from HAPE..EDO_DE_CUENTA where numero = @NumeroSocio and id_mov = @IdCuentaRetiro and saldo_actual != @SaldoActual)
						 BEGIN
							raiserror ('Transferencia incorrecta.Los saldos obtenidos al inicio de la transacci�n han sido modificados por otra transacci�', 11, 0)
						 END
						 ---
						 ---- Generacion de folio de banca
							insert into BANCA..TBL_BANCA_FOLIOS (numero_socio,fecha_alta)
							values (@numero_int,@fechaTransaccion)

							select @id_folio_banca = MAX (id_banca_folio) from BANCA..TBL_BANCA_FOLIOS where
							numero_socio = @numero_int
						--=========== end Generacion de folio de banca
						
						 ---INSERTAMOS LA TRABSFERENCIAS REFERENTE AL PAGO 
						INSERT INTO TBL_BANCA_TRANSFERENCIAs_PAGO_SERVICIOS
							(id_producto,id_servicio,numero_socio,monto,numero_referencia,fecha_alta_pago,
							id_estatus_transferencia,id_origen,clabe_corresponsalias_retiro, telefono,id_banca_folio)
						VALUES(@idProducto,@idServicio,BANCA.dbo.FN_BANCA_CIFRAR(@numeroSocio),@monto,@numeroReferencia,GETDATE(),@idEstatusTransfenrecia, @tipo_origen,@ClabeCorresponsaliasRetiro,@telefono, @id_folio_banca)

				        ------------ UPDATE A ESTADO DE CUENTA -------------
						
						UPDATE HAPE..EDO_DE_CUENTA
						SET Saldo_Actual = @SaldoDespuesDeOperacion,
							Fecha =@fechaTransaccion
						WHERE 
						Numero = @NumeroSocio and Id_mov = @IdCuentaRetiro and Id_Tipo_persona = @idTipoPersona


						----------- FIN DE UPDATE A ESTADO DE CUENTA --------
						--
						--
						--
						------------ INSERT A MOVIMIENTOS--------------------
						print 'antes de movimientos'
						INSERT INTO HAPE.dbo.MOVIMIENTOS 
							(Numero,Activo,Fecha_Mov,
							Monto,Saldo,Tipo_Poliza,
							Num_Poliza,	Folio,Fecha_Alta,
							Id_Persona,	Numusuario,Id_tipomov,
							id_mov,	Id_Tipo_persona,id_origen,Titular)
						VALUES
						(   @NumeroSocio, 'T' , @fechaTransaccion,
							@monto,@SaldoDespuesDeOperacion,@TipoPoliza ,
							@NumPoliza , @id_folio_banca , @fechaTransaccion,
							@IdPersona , @NumUsuarioBanca,@IdTipoMov,
							@IdCuentaRetiro,@idTipoPersona,@id_origen_operacion,'S'
			 			)
						print 'despues de movimientos'
						---- FIN DE INSERT MOVIMIENTOS
						--
						--
						--
						--============================ INSERT CAPTURA ============================
						print 'antes de CAPTURA'
						begin
						--******	INSERCI�N DEL MOVIMIENTO		******
						select @ConceptoCaptura ='',@CuentaContable=''
						SELECT @ConceptoCaptura = Descripcion FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov
						select @CuentaContable =  Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like 
						case 
							when @IdCuentaRetiro = 100 then '2120000000%'
							when @IdCuentaRetiro = 103 then '2110000000%'
							when @IdCuentaRetiro = 112 then '2160000000%'
						end
						select @DebeHaber = 'D'
						INSERT INTO HAPE..CAPTURA
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCION SERVICIO DE BANCA	(HABER - ABONO)	******
						--obtenemos la descripcion del  movimiento
						select @ConceptoCaptura ='',@CuentaContable=''
						SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov
						print'@IdTipoMov'+ cast(@IdTipoMov as varchar)
						-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
						SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
						WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

						select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
						select @DebeHaber = 'H'

						INSERT INTO HAPE..CAPTURA
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCION SERVICIO DE BANCA	(DEBE - CARGO)	******
						--obtenemos la descripcion del  movimiento
						select @ConceptoCaptura ='',@CuentaContable=''
						SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

						-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
						SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
						WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto
																											   
						select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
						select @DebeHaber = 'D'

						INSERT INTO HAPE..CAPTURA
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCI�N MEDIOS DE PAGO	ABONO	******
						select @ConceptoCaptura ='',@CuentaContable=''
						select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
						from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14101000990000%'
						select @DebeHaber = 'H'

						INSERT INTO HAPE..CAPTURA
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCI�N SUCURSAL DEL SOCIO CARGO	******
						select @ConceptoCaptura ='',@CuentaContable=''
						select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
						from HAPE..CUENTAS_CONTABLES  where Num_cuenta = @CuentaContableSucursal
						select @DebeHaber = 'D'

						INSERT INTO HAPE..CAPTURA
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_compensacion
						)

						--******	INSERCI�N GESTO PAGO ABONO	******
						select @ConceptoCaptura ='',@CuentaContable=''
						select 
							@CuentaContable =   Num_cuenta, 
							@ConceptoCaptura = 'GESTO PAGO'--Concepto (Se forzo a que diga gesto pago, ya que al darse de alta en productivo no la registraron como debia ser)
						from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14100611950000%'
						select @DebeHaber = 'H'

						INSERT INTO HAPE..CAPTURA
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_compensacion
						)

						print 'despues de CAPTURA'
						end
						--- FIN DEL INSERT DE CAPTURA  ---

						--============================ INSERT CAPTURA_lacp ============================
						print 'antes de CAPTURA_lacp'
						begin
						--******	INSERCI�N DEL MOVIMIENTO		******
						select @ConceptoCaptura ='',@CuentaContable=''
						SELECT @ConceptoCaptura = Descripcion FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov
						select @CuentaContable =  Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like 
						case 
							when @IdCuentaRetiro = 100 then '2120000000%'
							when @IdCuentaRetiro = 103 then '2110000000%'
							when @IdCuentaRetiro = 112 then '2160000000%'
						end
						select @DebeHaber = 'D'
						INSERT INTO HAPE..CAPTURA_lacp
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCION SERVICIO DE BANCA	(HABER - ABONO)	******
						--obtenemos la descripcion del  movimiento
						select @ConceptoCaptura ='',@CuentaContable=''
						SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

						-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
						SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
						WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

						select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
						select @DebeHaber = 'H'
						INSERT INTO HAPE..CAPTURA_lacp
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCION SERVICIO DE BANCA	(DEBE - CARGO)	******
						--obtenemos la descripcion del  movimiento
						select @ConceptoCaptura ='',@CuentaContable=''
						SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

						-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
						SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
						WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

						select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
						select @DebeHaber = 'D'
						INSERT INTO HAPE..CAPTURA_lacp
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCI�N MEDIOS DE PAGO	ABONO	******
						select @ConceptoCaptura ='',@CuentaContable=''
						select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
						from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14101000990000%'
						select @DebeHaber = 'H'

						INSERT INTO HAPE..CAPTURA_lacp
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCI�N SUCURSAL DEL SOCIO CARGO	******
						select @ConceptoCaptura ='',@CuentaContable=''
						select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
						from HAPE..CUENTAS_CONTABLES  where Num_cuenta = @CuentaContableSucursal
						select @DebeHaber = 'D'

						INSERT INTO HAPE..CAPTURA_lacp
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_compensacion
						)

						--******	INSERCI�N GESTO PAGO ABONO	******
						select @ConceptoCaptura ='',@CuentaContable=''
						select 
							@CuentaContable =  Num_cuenta, 
							@ConceptoCaptura = 'GESTO PAGO'--Concepto (Se forzo a que diga gesto pago, ya que al darse de alta en productivo no la registraron como debia ser)
						from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14100611950000%'
						select @DebeHaber = 'H'

						INSERT INTO HAPE..CAPTURA_lacp
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_compensacion
						)

						print 'despues de CAPTURA_lacp'

						end
						--- FIN DEL INSERT DE CAPTURA_lacp  ---

		
			   BEGIN -- commit
				
					if @tran_count = 0

						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
			   END -- commit	
				  	
			  END -- FIN DE SE INICIALIZA LA TRANZACION PERO PRIMERO SE VALIDA SI EXISTTE UNA TRANSACCION PADRE 


			  RESULT:
			  	  BEGIN		
					--SELECT 200 estatus , 'OK' mensaje , @id_folio_banca as id_folio_banca
					declare 
					@necesitaPin bit = 0,
					@leyenda varchar(max) = '',
					@id_tipo_bitacora int

					select @leyenda = leyenda from CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO where id_producto = @IdProducto and id_servicios_pago = @idServicio

					if exists(SELECT id_cat_tipo_servicio FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO WHERE id_producto = @IdProducto and id_servicios_pago = @idServicio  and id_cat_tipo_servicio in (10,11))
					set @necesitaPin = 1

					--******	INSERCI�N DE BITACORA	******
					/*select @id_tipo_bitacora = 38 --Alta de pago de servicio
					insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
					values(@id_folio_banca, @id_tipo_bitacora, @numero_int, getdate(), @tipo_origen)

					select * from CAT_BANCA_TIPOS_BITACORA order by 
					*/


					/*se extrae informacion adicional para  validaciones en el front y regresamos el folio generado*/
					Select 200 estatus , @necesitaPin as necesitaPin ,'OK'   mensaje , @id_folio_banca as id_folio_banca,@leyenda as leyenda, * 
					from CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO 
					where id_producto  = @IdProducto and id_servicios_pago = @idServicio
				 END 

		end try -- try principal
		
		begin catch -- catch principal

		   if @tran_scope = 1
				rollback tran @tran_name
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@estatus=0  
		
			select ERROR_LINE() , @error_message as mensaje, @estatus as estatus
		
		end catch -- catch principal
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_REALIZA_TRANSFERENCIA_EXTERNA]    Script Date: 14/02/2020 02:18:04 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*
Autor			EDSON
Fecha			20190808
Objetivo		Realiza el registro de una transferencia externa
Proyecto		Banca en l�nea
*/

ALTER PROCEDURE [dbo].[SP_BANCA_REALIZA_TRANSFERENCIA_EXTERNA]
		@numero int,
		@monto money,
		@clabe_spei_retiro varchar(20),
		@clabe_spei_deposito varchar(20),
		@fecha_programada datetime,
		@programado bit,
		@tipo_origen int, --
		@concepto_pago varchar(300),
		@id_tipo_persona_origen int = null,
		@id_tranferencia_externa bigint = null
as

	begin -- procedimiento
		
		/*		@tipo_origen
		1	Banca M�vil
		2	Sucursal
		3	Banca Web
		4	Databanking
		5	SPEI*/

		--declare	@status int = 200
		
		begin try -- try principal
		
			begin -- inicio

				begin -- declaraciones
					declare	
						@status int=0,
						@error_message varchar(255) = '',
						@id_origen_operacion int,---CAT_CMV_ORIGEN_TRANSACCION
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@message varchar(255) = 'Se registro correctamente la transferencia',
						@fecha_operacion datetime,
						@id_cuenta_externa bigint,
						@id_transferencia bigint,
						@id_folio_banca bigint,
						@clave_rastreo varchar(500),
						@id_tipomov int,
						@id_mov int,
						@num_poliza int,
						@saldo_cuenta_retiro money,
						@id_persona bigint,
						@numusuario int  = 1012,
						@referencia_numerica int,
						------
						---
						@tipo_poliza varchar(1) = 'M',
						@ccostos_origen varchar(10),
						@ccostos_compensacion varchar(10),
						@Num_cuentaContable_sucursal varchar(100),
						@nombre_origen varchar(100),
						@Ap_paterno_origen varchar(100),
						@Ap_materno_origen varchar(100),
						@rfc_origen varchar(20),
						@id_tipo_cuenta_externa int,

						----
						@id_bitacora int

					declare	
						@tran_name varchar(32) = 'SP_BANCA_REGISTRA_TRANSFERENCIA_EXTERNA',
						@tran_count int = @@trancount,
						@tran_scope bit = 0
				end -- declaraciones

			

			end -- inicio

			begin--Proceso

				print 'paso 01'
				--extraer datos generales
				select @fecha_operacion = getdate()
				select @id_origen_operacion = 7 ---SPEI
				select @id_tipo_persona_origen = ISNULL(@id_tipo_persona_origen,1)

				select 
					@id_cuenta_externa = id_cuenta_externa, 
					@id_tipo_cuenta_externa = 
						case 
							when id_tipo_cuenta_externa = 1 then 10 --Celular ligado a cuenta CLABE
							when id_tipo_cuenta_externa = 2 then 0 --Tarjeta de cr�dito
							when id_tipo_cuenta_externa = 3 then 3 --Tarjeta de debito
							when id_tipo_cuenta_externa = 4 then 40 --CLABE Interbancaria
						end
				from BANCA..TBL_BANCA_CUENTAS_EXTERNAS 
				where clabe_interbancaria = @clabe_spei_deposito and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero
				

				---Se obtiene el numero de poliza de banca
				select @num_poliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
				select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'SPEI')
				and dia = DAY(GETDATE())

				---se obtienen los datos de la cuenta de retiro
				Select @id_tipomov = 1169 ---1169	Retiro de DEBITO CMV por Transferencia SPEI
				Select @id_mov = ID_MOV FROM HAPE..TIPO_MOV WHERE ID_TIPOMOV = @id_tipomov
				select @saldo_cuenta_retiro = Saldo_Actual from hape..edo_de_cuenta 
				where 
					numero = @numero and id_tipo_persona = @id_tipo_persona_origen 
					and id_mov = @id_mov

				----se obtienen los datos del socio
				select 
					@id_persona = p.Id_Persona,
					@nombre_origen = p.Nombre_s,
					@Ap_paterno_origen = p.Apellido_Paterno,
					@Ap_materno_origen = p.Apellido_Materno,
					@ccostos_origen = s.Ccostos,
					@Num_cuentaContable_sucursal = nSuc.Num_Cuenta_Compensacion,
					@rfc_origen = rfc
				from HAPE..PERSONA p
				join HAPE.dbo.sucursales s
					on s.id_de_sucursal = p.id_de_sucursal
				join HAPE..NUM_SUCURSAL nSuc 
					on s.Num_Sucursal = nSuc.Num_Sucursal
				where Numero = @numero and Id_Tipo_Persona = @id_tipo_persona_origen

				select @ccostos_compensacion = Ccostos from HAPE..NUM_SUCURSAL
				WHERE
					Num_Sucursal = 99 --'MEDIOS DE PAGO%'

			end

			begin -- validaciones de par�metros
				print 'paso 02'	
				---No existe la cuenta externa destino asociada al socio
				if not exists(select * from BANCA..TBL_BANCA_CUENTAS_EXTERNAS  where clabe_interbancaria = @clabe_spei_deposito and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero)
				begin
					select @status = 0,@message = 'No existe la cuenta destino, asociada al socio.'
					raiserror (@message, 11, 0)
				end	

				if not exists (select 1 from HAPE.dbo.persona where numero = @numero and id_tipo_persona = @id_tipo_persona_origen)
					begin -- validar persona de origen

						select @status=301
						select @message = '301|N�mero de socio no existe|No se encontr� una coincidencia para n�mero y tipo de socio de origen indicados [' + cast(@numero as varchar) + '/' + cast(@id_tipo_persona_origen as varchar) + ']'
						raiserror (@message, 11, 0)

					end -- validar persona de origen

				if @saldo_cuenta_retiro < @monto and @programado = 0 ---se valida siempre y cuando ya se valla a afectar
				begin -- validar fondos suficientes

					select @status=329
					select @message = '329|Saldo insuficiente|El monto solicitado [' + cast(@monto as varchar) + '] excede al disponible [' + cast(@saldo_cuenta_retiro as varchar) + '] en la cuenta indicada'
					raiserror(@message, 11, 0)

				end -- validar fondos suficientes
					
				if @monto !> 0
				begin -- validar monto

					select @status=346
					select @message = '346|Saldo no es mayor a 0|El monto indicado [' + cast(@monto as varchar) + '] debe ser mayor a 0.00'
					raiserror(@message, 11, 0)

				end -- validar monto

				if coalesce(@numusuario, 0) = 0 or not exists (select 1 from HAPE.dbo.claves where Numusuario = @numusuario)
				begin -- validar usuario

					select @status=345
					select @message  = '345|Transferencia incorrecta|El usuario indicado [' + cast(@numusuario as varchar) + '] no es v�lido'
					raiserror (@message, 11, 0)

				end -- validar usuario

				if coalesce(@num_poliza, 0) = 0
				begin -- validar p�liza

					select @status=347
					select @message = '347|N�mero de p�liza no existe|El n�mero de p�liza indicado no es v�lido'
					raiserror (@message, 11, 0)

				end -- validar p�liza

				if (@id_mov<>112)
				begin -- validar cuentas internas

					select @status=374
					select @message = '374|Operaci�n invalida  para numero[' + cast(@numero as varchar) + ']'
					raiserror (@message, 11, 0)

				end -- validar cuentas internas

					
				IF EXISTS(select * from HAPE..PERSONA where numero = @numero AND Id_Tipo_Persona = 1 and 
				(Bloqueado_Cobranza = 'A' OR Bloqueado_Exclusion = 'A'))
				begin
					select @status = id_excepcion, @message  = descripcion from BANCA..CAT_BANCA_EXCEPTIONS where  id_excepcion = 382
					raiserror (@message, 11, 0)
				end

				if(@programado=1)
				begin
					if ( (convert(varchar, @fecha_programada, 112)<convert(varchar, getdate(), 112)) or (convert(varchar, @fecha_programada, 112)=convert(varchar, getdate(), 112) and convert(char(8), @fecha_programada, 108)<=convert(char(8), getdate(), 108)) )
					begin -- validar fecha de programacion

						select @status=384
						select @message = '384|Fecha programada invalida'
						raiserror (@message, 11, 0)

					end -- validar fecha de programacion
				end

				--Dias inhabiles
				IF (select inhabil from hape..TBL_DIAS_INHABILES_CALENDARIO 
				where 
				(convert(varchar(20),fecha,112) = convert(varchar(20),@fecha_operacion,112) and @programado = 0)
				or 
				(convert(varchar(20),fecha,112) = convert(varchar(20),@fecha_programada,112) and @programado = 1)
				) = 1
				BEGIN
					select @status=384
					select @message = '384|Fecha inhabil'
					raiserror (@message, 11, 0)
				END

				--Uso de cuenta despues de los 30 min. de registro
				if not exists(select * from TBL_BANCA_CUENTAS_EXTERNAS where 
					clabe_interbancaria=@clabe_spei_deposito and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero and activa = 1
					and DATEDIFF(MINUTE,fecha_alta,getdate()) > 30
				)
				begin -- validar que la clave corresponsalia de deposito tenga un periodo mayor a 30 minutos despues de haber sido dada de alta
					select @status=339
					select @message = 'Espere el tiempo de registro de la cuenta para poder hacer uso de ella'
					raiserror (@message, 11, 0)
				end -- -- validar que la clave corresponsalia de deposito tenga un periodo mayor a 30 minutos despues de haber sido dada de alta
									

				--===================================	VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS	===============================
				BEGIN
						
					if @monto > (select monto_maximo from TBL_BANCA_CUENTAS_EXTERNAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)=@numero 
					and clabe_interbancaria=@clabe_spei_deposito)
					begin -- validar monto maximo de transaccion
						print 'monto >'
						select @status=321
						select @message = '321|El monto m�ximo de transferencia de la cuenta es excedido.'
						raiserror (@message, 11, 0)

					end -- validar monto maximo de transaccion

					declare 
						@fecha_ datetime,
						@tipoTransferencia int
					 
					if(@programado = 0)
						select @fecha_ = @fecha_operacion
					else
						select @fecha_ = @fecha_programada

					select @tipoTransferencia = 6	---6.- TRANSFERENCIAS SPEI

					select 
						@status = estatus, @message = msj  
					from  
						FN_VALIDAR_LIMITES_TRANSFERENCIAS_DIARIO (@tipoTransferencia,@numero,@monto,@fecha_,@programado)

					if @status <> 200
					begin
						raiserror (@message, 11, 0)
					end
				END ---VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS
				
									
					
			end -- validaciones de par�metros

			begin -- Transaccionalidad

				print 'paso 03 (inicio de transacci�n)'
				if @tran_count = 0
					begin tran @tran_name
				else
					save tran @tran_name
				
				select @tran_scope = 1

				-----------------------		proceso de transaccionalidad		--------------------

				---- Generacion de transferencia
				if @id_tranferencia_externa is not null and @id_tranferencia_externa > 0 -- para pago programado
				begin
					select @id_transferencia = @id_tranferencia_externa
					select @id_folio_banca = id_banca_folio from 
						TBL_BANCA_TRANSFERENCIAS_EXTERNAS 
						where id_transferencia = @id_transferencia
				end
				else
				begin
					--- se obtiene la referencia numerica 
					select top 1 @referencia_numerica =  referencia_numerica
					from BANCA..TBL_BANCA_REFERENCIAS_NUMERICAS 
					where
						numero = @numero
					order by id_referencia_numerica desc

					select @referencia_numerica = case 
						when isnull(@referencia_numerica,0) = 9999999 then 1
						else (isnull(@referencia_numerica,0) +1)
					end

					---- Generacion de folio de banca
					insert into BANCA..TBL_BANCA_FOLIOS (numero_socio,fecha_alta)
					values (@numero,@fecha_programada)

					select @id_folio_banca = MAX (id_banca_folio) from BANCA..TBL_BANCA_FOLIOS where
					numero_socio = @numero
					--=========== end Generacion de folio de banca

					if @programado = 0
					begin
						set @fecha_programada = null
					end

					---- insercion de transferencia
					insert into BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS 
						(monto,id_estatus_transferencia,numero_socio,fecha_programada,
						programado,fecha_alta_transferencia,id_banca_folio,clabe_spei_origen,
						clabe_spei_destino,id_cuenta_externa,concepto_pago,notificado_por_stp
						)
					values
						(@monto,1/*pendiente*/,BANCA.dbo.FN_BANCA_CIFRAR(@numero),@fecha_programada,
						@programado,@fecha_operacion,@id_folio_banca,@clabe_spei_retiro,
						@clabe_spei_deposito,@id_cuenta_externa,@concepto_pago,0)

					select @id_transferencia = max (id_transferencia) from BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS 
					where
						BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero and id_cuenta_externa = @id_cuenta_externa and clabe_spei_destino = @clabe_spei_deposito
					--=========== insercion de transferencia

				end

				--=========== end Generacion de transferencia

				---- Generacion de clave de rastreo y asignacion de referencia numerica
				if (@id_tranferencia_externa is not null and @id_tranferencia_externa > 0)
				begin
					select @clave_rastreo = clave_rastreo from 
					TBL_BANCA_TRANSFERENCIAS_EXTERNAS where id_transferencia = @id_tranferencia_externa
				end
				else
				begin
					if len(cast(@id_transferencia as varchar(200))) <= 8
						select @clave_rastreo = 'CMV' + RIGHT('00000000' + Ltrim(Rtrim(@id_transferencia)),8)
					else
						select @clave_rastreo = 'CMV' + cast(@id_transferencia as varchar(200))

					update BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS 
					set		
						clave_rastreo = @clave_rastreo,
						referencia_numerica = @referencia_numerica
					where 
						id_transferencia = @id_transferencia

					insert into BANCA..TBL_BANCA_REFERENCIAS_NUMERICAS 
						(referencia_numerica,numero,id_transferencia_externa,clave_rastreo,fecha_alta)
					values
						(@referencia_numerica,@numero,@id_transferencia,@clave_rastreo,@fecha_operacion)
				end
				--=========== end Generacion de clave de rastreo


				---- Afectaci�n de saldos
				if(@programado = 0)
				begin
					print('==========================	PROCESO DE AFECTACI�N	=============================')
					/*========================================	RETIRO DE DEBITO CMV	=======================================
					==============================================================================================================*/
					INSERT	HAPE..MOVIMIENTOS
						(
						NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
						NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
						ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR
						)
					VALUES	(
						@numero, 'T', @fecha_operacion, @monto,round((@saldo_cuenta_retiro - @monto),2), 'D',
						@num_poliza, @id_folio_banca, GETDATE(), @id_persona, @numusuario,
						@id_tipomov, @id_mov,@id_origen_operacion, 'S'
						)
					
					print(@id_folio_banca)

					begin -- preparar captura
						
						--movimiento de cuenta
						insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = tm.descripcion,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%DEBITO%'
								and cc.Num_cuenta like '2160000000%'
						--Medios de pago		
						insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%MEDIOS%'
								and cc.Num_cuenta like '1410100099%'	
						--sucursal del socio
						insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = @Num_cuentaContable_sucursal
						--SPEI
						insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = '14100611940000'

					end	-- preparar captura

					begin -- preparar captura_lacp
						
						--movimiento de cuenta
						insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = tm.descripcion,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%DEBITO%'
								and cc.Num_cuenta like '2160000000%'
						--Medios de pago		
						insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%MEDIOS%'
								and cc.Num_cuenta like '1410100099%'	
						--sucursal del socio
						insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = @Num_cuentaContable_sucursal
						--SPEI
						insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = '14100611940000'

					end	-- preparar CAPTURA_lacp

					print('Afectaci�n de estado de cuenta')
					/*========================================	ACTUALIZACI�N DE ESTADO DE CUENTA	================================
					==============================================================================================================*/
					UPDATE	HAPE..EDO_DE_CUENTA
					SET	SALDO_ACTUAL = round(SALDO_ACTUAL - @monto,2),
						FECHA = @fecha_operacion
					WHERE	
						numero = @numero
						and id_mov = @id_mov
						AND Id_Tipo_persona = 1

				end
				--=========== end Afectaci�n de saldos

			end

			
			begin-- INSERCI�N DE BITACORA
				if(@programado = 0 ) --transferencia para realizar
				begin
					print('==========================	PROCESO DE REGISTRO DE BITACORA	=============================')
					--select @id_bitacora = 17 --Transferencia realizada | Entre cuentas externas

					--insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
					--values(@id_folio_banca, @id_bitacora, @numero, getdate(), @id_origen_operacion)

					select @id_bitacora = 53 --Retiro de D�bito 

					insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
					values(@id_folio_banca, @id_bitacora, @numero, getdate(), @tipo_origen)


				end
				else ---Transferencias programadas
				begin
					select @id_bitacora = 88 -- Transferencia Programada |  Entre cuentas externas

					insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
					values(@id_folio_banca, @id_bitacora, @numero, getdate(), @tipo_origen)

				end
			end


			--begin-- ACTUALIZACION DE ESTATUS DE TRANSFERENCIA
			--	if(@programado = 0 ) --transferencia para realizar
			--	begin
			--		update 
			--			TBL_BANCA_TRANSFERENCIAS_EXTERNAS 
			--		set 
			--			id_estatus_transferencia = 2
			--		where
			--			id_transferencia = @id_transferencia
			--	end
			--end


			begin -- commit
				
					if @tran_count = 0
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				select @status = 200,@error_message ='Se registro correctamente la transferencia'
			end -- commit


		end try -- try principal
		
		begin catch -- catch principal

			select @status=coalesce(@status, 0)

			select	--@status=@status,
					--@status =error_state(),	
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end

					--select @status=coalesce(@status, 0)
			-- revertir transacci�n si es necesario
			if @tran_scope = 1
			begin
				rollback tran @tran_name
			end

			if @id_transferencia is not null and @id_transferencia > 0
			begin
				update BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS
				set 
					id_estatus_transferencia = 3, --Rechazada
					mensaje_error = @error_message
				where
					id_transferencia = @id_transferencia
			end

		end catch -- catch principal
		
		begin -- reporte de status

			select	@status estatus,
					case when @status=200 then @id_transferencia else null end IdTransferenciaCMV,
					case when @status=200 then @id_folio_banca else null end referenciaNumerica,
					case when @status=200 then @clave_rastreo else null end claveRastreo,
					case when @status=200 then @fecha_operacion else null end HoraTransaccion,
					case when @status=200 then @monto else null end Monto,
					case when @status=200 then @nombre_origen else null end nombre_origen,
					case when @status=200 then @rfc_origen else null end rfc_origen,
					case when @status=200 then @id_tipo_cuenta_externa else null end id_tipo_cuenta_externa,
					@concepto_pago concepto_pago ,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message mensaje
				
		end -- reporte de status
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_REALIZA_TRANSFERENCIA_INTERNA]    Script Date: 07/11/2019 01:10:57 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



/*

Autor			Mar Mej�a Murillo
UsuarioRed		memm373565
Fecha			20180607
Objetivo		Realiza una transferencia de una cuenta de haberes de un socio de origen a una cuenta de haberes de un socio de destino
Proyecto		Banca en l�nea
Ticket			______

*/

ALTER proc

	[dbo].[SP_BANCA_REALIZA_TRANSFERENCIA_INTERNA]
		@numeroSocio varchar(20),
		@monto money,--decimal(18,2),
		@clabeCorresponsaliasRetiro varchar(16),
		@clabeCorresponsaliasDeposito varchar(16),
		@programada bit,
		@horaProgramada datetime,
		@tipoOrigen int,
		@tipoTransferenciaInterna  int, 	--  CuentaPropia = 1,     CuentaOtroSocio = 2
		@id_transferencia int = null

as

	begin -- procedimiento
		
		--declare	@status int = 200
		declare	@status int-- = 200
		begin try -- try principal
		
			begin -- inicio

			
				begin -- declaraciones

					--declare	@status int = 200,
						declare	@error_message varchar(255) = '',
							@error_line varchar(255) = '',
							@error_severity varchar(255) = '',
							@error_procedure varchar(255) = ''
						
					declare	@tran_name varchar(32) = 'REALIZA_TRANSFERENCIA_INTERNA',
							@tran_count int = @@trancount,
							@tran_scope bit = 0

					declare @message varchar(255),
							@saldo_origen money,
							@saldo_destino money,
							@numero_destino int,
							@id_tipo_persona_origen int,
							@id_tipo_persona_destino int,
							@fecha datetime,
							@tipo_poliza varchar(1),
							@id_mov_origen int,
							@id_mov_destino int,
							@numusuario int,
							@num_poliza int,
							@folio int,
							@id_tipo_bitacora int,
							@id_cuenta_origen int,
							@id_cuenta_destino int,
							@numero_origen int,
							@id_linea_revolvente bigint,
							@fecha_tran datetime,
							@ccostos_origen varchar(10),
							@ccostos_destino varchar(10),
							@Ahorro_Base money,
							----variables para validar el limite de transferencia diaria
							@monto_transferencias_al_dia money,
							@limite_monto_al_dia money
							


					select @numero_origen=cast(@numeroSocio as int)
					select @numero_destino = numero from hape.dbo.TBL_CORRESPONSALIAS_CUENTAS where cuenta=@clabeCorresponsaliasDeposito 

					select @id_tipo_persona_origen=1, @id_tipo_persona_destino=1, @numusuario=1024--, @num_poliza=300000

					---Se obtiene el numero de poliza de banca
					select @num_poliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
					select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'BANCA ELECTRONICA')
					and dia = DAY(GETDATE())



					begin -- validaciones

						print 'paso 01'	
						if (@tipoTransferenciaInterna = 1)
						begin
							if (SELECT NUMERO from hape..TBL_CORRESPONSALIAS_CUENTAS where cuenta  =  @clabeCorresponsaliasDeposito) < > (SELECT NUMERO from hape..TBL_CORRESPONSALIAS_CUENTAS where cuenta  =  @clabeCorresponsaliasRetiro)
							begin
								select @status=381
								select @message = '381|Clabe corresponsal�as no est�n asociadas a un mismo socio'
								raiserror (@message, 11, 0)
							end
						end
						else if (@tipoTransferenciaInterna = 2)
						begin
								if not exists(select * from TBL_BANCA_CUENTAS_INTERNAS where clabe_corresponsalias=@clabeCorresponsaliasDeposito and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_origen and activo = 1)
								begin -- validar que la cuenta exista siempre y cuando la transferencia sea a otro socio no a al mismo

									select @status=305
									select @message = '305|IdCuenta interna [' + @clabeCorresponsaliasDeposito + '] no existe'
									raiserror (@message, 11, 0)

								end -- validar que la cuenta exista
								
								
								if not exists(select * from TBL_BANCA_CUENTAS_INTERNAS where 
									clabe_corresponsalias=@clabeCorresponsaliasDeposito and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_origen and activo = 1
									and DATEDIFF(MINUTE,fecha_alta,getdate()) > 30
								)
								begin -- validar que la clave corresponsalia de deposito tenga un periodo mayor a 30 minutos despues de haber sido dada de alta

										select @status=339
										select @message = 'Espere el tiempo de registro de la cuenta para poder hacer uso de ella'
										raiserror (@message, 11, 0)

								end -- -- validar que la clave corresponsalia de deposito tenga un periodo mayor a 30 minutos despues de haber sido dada de alta
									
						end

						print 'paso 02'	
						if not exists(select * from hape..TBL_CORRESPONSALIAS_CUENTAS where numero = cast(@numeroSocio as int ) and CUENTA  = @clabeCorresponsaliasRetiro )
						begin -- validar que la cuenta exista

								select @status=305
								select @message = '305|IdCuenta interna [' + @clabeCorresponsaliasRetiro + '] no existe'
								raiserror (@message, 11, 0)

						end -- validar que la cuenta exista

						print 'paso 03'	
						if not exists(select * from hape.dbo.TBL_CORRESPONSALIAS_CUENTAS where cuenta=@clabeCorresponsaliasRetiro )
						begin -- validar clave corresponsalia

								select @status=339
								select @message = '339|La clabe[' + @clabeCorresponsaliasRetiro + '] de corresponsalias proporcionada no existe'
								raiserror (@message, 11, 0)

						end -- validar clave corresponsalia

						print 'paso 04'	
						if not exists(select * from hape.dbo.TBL_CORRESPONSALIAS_CUENTAS where cuenta=@clabeCorresponsaliasDeposito )
							begin -- validar clave corresponsalia

									select @status=339
									select @message = '339|La clabe[' + @clabeCorresponsaliasDeposito + '] de corresponsalias proporcionada no existe'
									raiserror (@message, 11, 0)

							end -- validar clave corresponsalia
								
					
					end -- validaciones			
			

					print 'paso 05'					
					select cast(contador as int) contador, id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov,
                                  cuenta, concepto, fecha_mov, monto, neto, id_mov, banco, clave_local, linea, num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1,
                                  desc2, planx, aval1_socio, aval1_numero, aval2_socio, aval2_numero, desc3, desc4, fecha_dpf_final, num_dpf, tasa, interes, dias, debe_haber,
                                  numusuario, procesado, fecha_alta, numero_fin, numero_fin2, plazo, interes_ord, interes_mor, monto2, plazo2, interes_ord2, interes_mor2,
                                  aval1_avalados, aval2_avalados, fec_inicio, fec_prog, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario,
                                  porcentaje_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, porcentaje_beneficiario2, id_sol, numero_fin_lacp, reestructura,
                                  id_motivo_reestructura, id_esquema, cast(id_convenio as int) id_convenio, id_amortizacion, ent_federativa, cve_municipio, cve_localidad, identificador, transferencia,
                                  fecha_pago, bimestre, referencia, cve_archivo, impreso, folio_impresion, documentacion, dpf_en_garantia, titular, id_nomina, id_esquema_nomina,
                                  id_leyenda, num_ptmo, id_renovado, ahorro_base, tasa_pasiva, id_fondeador, numero_fondeo, id_origen, id_tipo_pago_prestamo
                    into   #captura_
                    from   hape.dbo.captura
                    where  1 = 0


					select cast(contador as int) contador, id_persona, activo, numero, nombre_s, apellido_paterno, apellido_materno, total_movs, total_ficha, id_tipomov,
                                  cuenta, concepto, fecha_mov, monto, neto, id_mov, banco, clave_local, linea, num_poliza, tipo_poliza, folio, id_tipo_persona, num_cheq, desc1,
                                  desc2, planx, aval1_socio, aval1_numero, aval2_socio, aval2_numero, desc3, desc4, fecha_dpf_final, num_dpf, tasa, interes, dias, debe_haber,
                                  numusuario, procesado, fecha_alta, numero_fin, numero_fin2, plazo, interes_ord, interes_mor, monto2, plazo2, interes_ord2, interes_mor2,
                                  aval1_avalados, aval2_avalados, fec_inicio, fec_prog, contador_provision, ccostos, nombre_beneficiario, parentesco_beneficiario,
                                  porcentaje_beneficiario, nombre_beneficiario2, parentesco_beneficiario2, porcentaje_beneficiario2, id_sol, numero_fin_lacp, reestructura,
                                  id_motivo_reestructura, id_esquema, cast(id_convenio as int) id_convenio, id_amortizacion, ent_federativa, cve_municipio, cve_localidad, identificador, transferencia,
                                  fecha_pago, bimestre, referencia, cve_archivo, impreso, folio_impresion, documentacion, dpf_en_garantia, titular, id_nomina, id_esquema_nomina,
                                  id_leyenda, num_ptmo, id_renovado, ahorro_base, tasa_pasiva, id_fondeador, numero_fondeo, id_origen, id_tipo_pago_prestamo
                    into   #captura_lacp
                    from   hape.dbo.CAPTURA_lacp
                    where  1 = 0



						print 'paso 06'	
						select	id_persona_origen = id_persona,
								numero_origen = @numero_origen,
								id_tipo_persona_origen = @id_tipo_persona_origen,
								nombre_origen = nombre_s,
								paterno_origen = apellido_paterno,
								materno_origen = apellido_materno,
								id_de_sucursal_origen = s.id_de_sucursal,
								ccostos_origen = s.ccostos,
								id_persona_destino = null,
								numero_destino = @numero_destino,
								id_tipo_persona_destino = @id_tipo_persona_destino,
								nombre_destino = cast(null as varchar(40)),
								paterno_destino = cast(null as varchar(40)),
								materno_destino = cast(null as varchar(40)),
								id_de_sucursal_destino = null,
								ccostos_destino = CAST(null as varchar(10))
						into	#persona
						from	HAPE.dbo.persona po
									join HAPE.dbo.sucursales s
										on s.id_de_sucursal = po.id_de_sucursal
						where	po.numero = @numero_origen
								and po.id_tipo_persona = @id_tipo_persona_origen

						

						print 'paso 07'	
						if @numero_origen = @numero_destino and @id_tipo_persona_origen = @id_tipo_persona_destino
							update	#persona
							set		id_persona_destino = id_persona_origen,
									nombre_destino = nombre_origen,
									paterno_destino = paterno_origen,
									materno_destino = materno_origen,
									id_de_sucursal_destino = id_de_sucursal_origen,
									ccostos_destino = ccostos_origen

						else

							update	p
							set		p.id_persona_destino = pd.id_persona,
									p.nombre_destino = pd.nombre_s,
									p.paterno_destino = pd.apellido_paterno,
									p.materno_destino = pd.apellido_materno,
									p.id_de_sucursal_destino = pd.id_de_sucursal,
									p.ccostos_destino = s.ccostos
							from	HAPE.dbo.persona pd
									join #persona p
										on pd.numero = @numero_destino
										and pd.id_tipo_persona = @id_tipo_persona_destino
									join HAPE.dbo.sucursales s
										on s.id_de_sucursal = pd.id_de_sucursal
							where	pd.numero = @numero_destino
									and pd.id_tipo_persona = @id_tipo_persona_destino
						
						--asignacion de centro de costos
						select @ccostos_origen = ccostos_origen, @ccostos_destino = ccostos_destino from #persona

				end -- declaraciones

			

				begin -- inicializaciones y valores por defecto

					select	@fecha = coalesce(@fecha, getdate()),
							@tipo_poliza = coalesce(@tipo_poliza, 'M'),
							@tipoOrigen = coalesce(@tipoOrigen, 3),					
							@fecha_tran=getdate()
					
					select @id_mov_origen=ID_MOV from hape.dbo.TBL_CORRESPONSALIAS_CUENTAS where cuenta=@clabeCorresponsaliasRetiro 
					select @id_mov_destino=ID_MOV from hape.dbo.TBL_CORRESPONSALIAS_CUENTAS where cuenta=@clabeCorresponsaliasDeposito 


					select @saldo_origen = saldo_actual from HAPE.dbo.edo_de_cuenta where numero = @numero_origen and Id_Tipo_persona = 1 and id_mov = @id_mov_origen
					select @saldo_destino = saldo_actual from HAPE.dbo.edo_de_cuenta where numero = @numero_destino and Id_Tipo_persona = 1 and id_mov = @id_mov_destino

					------Ahorro comprometido
					select @Ahorro_Base = coalesce(sum(Ahorro_Base),0) from 
						HAPE..EDO_DE_CUENTA where numero = @numero_origen and Id_Tipo_persona = 1 and Id_mov < 10 and Saldo_Actual > 0
					

				end -- inicializaciones y valores por defecto


			end -- inicio

			begin -- validaciones de par�metros

					if not exists (select 1 from HAPE.dbo.persona where numero = @numero_origen and id_tipo_persona = @id_tipo_persona_origen)

						begin -- validar persona de origen

							select @status=301
							select @message = '301|N�mero de socio no existe|No se encontr� una coincidencia para n�mero y tipo de socio de origen indicados [' + cast(@numero_origen as varchar) + '/' + cast(@id_tipo_persona_origen as varchar) + ']'
							raiserror (@message, 11, 0)

						end -- validar persona de origen
				
					
					if not exists (select 1 from HAPE.dbo.persona where numero = @numero_destino and id_tipo_persona = @id_tipo_persona_destino)

						begin -- validar persona de destino

							select @status=301
							select @message = '301|N�mero de socio no existe|No se encontr� una coincidencia para n�mero y tipo de socio de destino indicados [' + cast(@numero_destino as varchar) + '/' + cast(@id_tipo_persona_destino as varchar) + ']'
							raiserror (@message, 11, 0)

						end -- validar persona de destino


					if @saldo_origen < @monto and @programada=0 and @id_mov_origen <> 100
					begin -- validar fondos suficientes

						select @status=329
						select @message = '329|Saldo insuficiente|El monto solicitado [' + cast(@monto as varchar) + '] excede al disponible [' + cast(@saldo_origen as varchar) + '] en la cuenta indicada'
						raiserror(@message, 11, 0)

					end -- validar fondos suficientes
					
					if (@saldo_origen-@Ahorro_Base) < @monto and @programada=0 and @id_mov_origen = 100
					begin -- validar fondos suficientes

						select @status=329
						select @message = '329|Saldo insuficiente|El monto solicitado [' + cast(@monto as varchar) + '] excede al disponible [' + cast(@saldo_origen as varchar) + '] en la cuenta indicada'
						raiserror(@message, 11, 0)

					end -- validar fondos suficientes


					if @monto !> 0

					begin -- validar monto

						select @status=346
						select @message = '346|Saldo no es mayor a 0|El monto indicado [' + cast(@monto as varchar) + '] debe ser mayor a 0.00'
						raiserror(@message, 11, 0)

					end -- validar monto



					if coalesce(@numusuario, 0) = 0 or not exists (select 1 from HAPE.dbo.claves where Numusuario = @numusuario)

					begin -- validar usuario

						select @status=345
						select @message  = '345|Transferencia incorrecta|El usuario indicado [' + cast(@numusuario as varchar) + '] no es v�lido'
						raiserror (@message, 11, 0)

					end -- validar usuario



					if coalesce(@num_poliza, 0) = 0

					begin -- validar p�liza

						select @status=347
						select @message = '347|N�mero de p�liza no existe|El n�mero de p�liza indicado no es v�lido'
						raiserror (@message, 11, 0)

					end -- validar p�liza



					if (@id_mov_origen = 101 and @id_tipo_persona_origen = 1)
					or (@id_mov_origen in (100, 103, 112) and @id_tipo_persona_origen = 2)
					or (@id_mov_origen not in (100, 101, 103, 112, 10))

					begin -- validar cuentas internas

						select @status=325
						select @message = '325|IdCuenta interna no existe|La combinaci�n de tipo de persona indicado [' + cast(@id_tipo_persona_origen as varchar) + '] y el tipo de cuenta indicado [' + cast(@id_mov_origen as varchar) + '] no existe'
						raiserror (@message, 11, 0)

					end -- validar cuentas internas


					if (@id_mov_destino = 101 and @id_tipo_persona_destino = 1)
					or (@id_mov_destino in (100, 103, 112) and @id_tipo_persona_destino = 2)
					or (@id_mov_destino not in (100, 101, 103, 112))

					begin -- validar cuentas internas

						select @status=325
						select @message = '325|IdCuenta interna no existe|La combinaci�n de tipo de persona indicado [' + cast(@id_tipo_persona_destino as varchar) + '] y el tipo de cuenta indicado [' + cast(@id_mov_destino as varchar) + '] no existe'
						raiserror (@message, 11, 0)

					end -- validar cuentas internas


					if (@id_mov_origen=10 and @id_mov_destino<>103)
					begin -- validar cuentas internas

						select @status=374
						select @message = '374|Operaci�n invalida  para numero[' + cast(@numero_origen as varchar) + ']'
						raiserror (@message, 11, 0)

					end -- validar cuentas internas

					print '@id_mov_origen '+cast (@id_mov_origen as varchar)
					if(@id_mov_origen = 10)
					begin
					
							--IF OBJECT_ID('tempdb..#TMP_RESULT_VALIDA_CANDADOS_DISPOSICIO') IS NOT NULL
							--DROP TABLE #TMP_RESULT_VALIDA_CANDADOS_DISPOSICIO

							--CREATE TABLE #TMP_RESULT_VALIDA_CANDADOS_DISPOSICION (
							--_status int,
							--_error_procedure varchar(1000),
							--_error_line varchar(1000),
							--_error_severity varchar(1000),
							--_error_message varchar(1000) )
							
							select @id_linea_revolvente=id_linea from hape.dbo.TBL_REVOLVENTE_LINEAS_CREDITO where numero=@numero_origen and id_tipo_persona=@id_tipo_persona_origen
						
							--insert into #TMP_RESULT_VALIDA_CANDADOS_DISPOSICION (
							--_status ,
							--_error_procedure,
							--_error_line,
							--_error_severity ,
							--_error_message
							--)

							create table #RESULTADOS_SP_REVOLVENTE_VALIDA_CANDADOS_DISPOSICION(
������������������������		status������������int null,
������������������������		error_procedure����varchar(255) null,
������������������������		error_line��������varchar(255) null,
������������������������		error_severity����varchar(255) null,
������������������������		error_message����varchar(255) null,
������������������������	)

							exec hape.dbo.SP_REVOLVENTE_VALIDA_CANDADOS_DISPOSICION 
							@id_linea=@id_linea_revolvente,
							@numero=@numero_origen,
							@monto=@monto

							print '@id_linea_revolvente'+cast (@id_linea_revolvente as varchar)
							print '@numero'+cast (@numero_origen as varchar)
							print '@monto'+cast (@monto as varchar)
							
							if ((select status from #RESULTADOS_SP_REVOLVENTE_VALIDA_CANDADOS_DISPOSICION) =0)
							begin
									select @status=374
									select  @message= error_message  from #RESULTADOS_SP_REVOLVENTE_VALIDA_CANDADOS_DISPOSICION
									raiserror (@message, 11, 0)
							end
					end

					if (@numero_origen=@numero_destino and @id_mov_origen=@id_mov_destino)
					begin -- validar cuentas internas

						select @status=374
						select @message = '374|Operaci�n invalida  para numero[' + cast(@numero_origen as varchar) + ']'
						raiserror (@message, 11, 0)

					end -- validar cuentas internas

					IF EXISTS(select * from HAPE..PERSONA where numero = @numero_destino AND Id_Tipo_Persona = 1 and 
					(Bloqueado_Cobranza = 'A' OR Bloqueado_Exclusion = 'A'))
					begin
						 if (substring(@clabeCorresponsaliasDeposito,7,3) <> 103)
						 begin
							select @status = id_excepcion, @message  = descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 382
							raiserror (@message, 11, 0)
						 end 
					end
				

					if(@programada=1)
					begin
						if ( (convert(varchar, @horaProgramada, 112)<convert(varchar, getdate(), 112)) or (convert(varchar, @horaProgramada, 112)=convert(varchar, getdate(), 112) and convert(char(8), @horaProgramada, 108)<=convert(char(8), getdate(), 108)) )
						begin -- validar fecha de programacion

							select @status=384
							select @message = '384|Fecha programada invalida'
							raiserror (@message, 11, 0)

						end -- validar fecha de programacion
					end					
					
					--===================================	VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS	===============================
					BEGIN
						
						if @monto > (select monto_maximo from TBL_BANCA_CUENTAS_INTERNAS 
						where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)=@numero_origen and clabe_corresponsalias=@clabeCorresponsaliasDeposito and activo=1) and @tipoTransferenciaInterna=2
						begin -- validar monto maximo de transaccion
							print 'monto >'
							select @status=321
							select @message = '321|El monto m�ximo de transferencia de la cuenta es excedido.'
							raiserror (@message, 11, 0)

						end -- validar monto maximo de transaccion

						declare 
							@fecha_ datetime, 
							@tipoTransferencia int

						if(@programada = 0)
							select @fecha_ = @fecha_tran
						else
							select @fecha_ = @horaProgramada

						select @tipoTransferencia = case 
							when @numero_origen = @numero_destino then 1	---1.- TRANSFERENCIAS INTERNAS CMV MIS CUENTAS
							else 2 end										---2.- TRANSFERENCIAS INTERNAS CMV OTRAS CUENTAS

						select 
							@status = estatus, @message = msj  
						from  
							dbo.FN_VALIDAR_LIMITES_TRANSFERENCIAS_DIARIO (@tipoTransferencia,@numero_origen,@monto,@fecha_,@programada)

						if @status <> 200
						begin
							print 'Entra a error de validacion: ' + @message
							raiserror (@message, 11, 0)
						end
					END ---VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS

			end -- validaciones de par�metros




			
		begin -- transacci�n	


					begin -- inicio

						if @tran_count = 0
							begin tran @tran_name
						else
							save tran @tran_name
				
						select @tran_scope = 1


				
					end -- inicio


					begin --folio

							IF @id_transferencia IS NULL OR @id_transferencia = 0
							BEGIN
								insert TBL_BANCA_FOLIOS(numero_socio, fecha_alta) values(@numero_origen, getdate())
							
								select @folio=max(id_banca_folio) from TBL_BANCA_FOLIOS
								where
									numero_socio =  @numero_origen

								select @id_tipo_bitacora =  case 
																when @numero_origen =  @numero_destino and @programada  = 0 then  15
																when @numero_origen <> @numero_destino and @programada  = 0 then 16
																when @numero_origen =  @numero_destino and @programada  = 1 then 70
																when @numero_origen <> @numero_destino and @programada  = 1 then 85
															end

								

								insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
								values(@folio, @id_tipo_bitacora, @numero_origen, getdate(), @tipoOrigen)
								
								--- PARA NOTIFICAR DEL RETIRO  AL SOCIO DE LA CUENTA ORIGEN
								if @programada = 0
								begin
								  select @id_tipo_bitacora = case when  @id_mov_origen = 100 then  52
																when  @id_mov_origen = 103 then  51
																when  @id_mov_origen = 112 then  53
															end

								
								   insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
								   values(@folio, @id_tipo_bitacora, @numero_origen, getdate(), @tipoOrigen)
								end
								---
							END
							ELSE
							BEGIN


								print 'Entra a obtener folio'
								select @folio= id_banca_folio from TBL_BANCA_TRANSFERENCIAS_INTERNAS
								where
									BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) =  @numero_origen
									AND id_transferencia = @id_transferencia

								UPDATE TBL_BANCA_TRANSFERENCIAS_INTERNAS
								SET 
									fecha_transferencia_realizada = GETDATE(),
									id_estatus_transferencia = 2
								WHERE
									id_transferencia = @id_transferencia
									AND BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_origen

								select @id_tipo_bitacora =  case 
																when @numero_origen =  @numero_destino then  15
																when @numero_origen <> @numero_destino then 16
															end


								insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
								values(@folio, @id_tipo_bitacora, @numero_origen, getdate(), @tipoOrigen)
								

								 select @id_tipo_bitacora = case when  @id_mov_origen = 100 then  52
																when  @id_mov_origen = 103 then  51
																when  @id_mov_origen = 112 then  53
															end

								
								   insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
								   values(@folio, @id_tipo_bitacora, @numero_origen, getdate(), @tipoOrigen)



							END

					end -- folio


					begin -- registra transferencia interna

							if @numero_origen <> @numero_destino
							begin 
							
								select @id_cuenta_origen=id_cuenta_interna from TBL_BANCA_CUENTAS_INTERNAS where clabe_corresponsalias=@clabeCorresponsaliasRetiro

								select @id_cuenta_destino=id_cuenta_interna from TBL_BANCA_CUENTAS_INTERNAS where clabe_corresponsalias=@clabeCorresponsaliasDeposito and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) =  @numeroSocio
							end
							else
							begin
								select @id_cuenta_origen=id_cuenta_interna from TBL_BANCA_CUENTAS_INTERNAS where clabe_corresponsalias=@clabeCorresponsaliasRetiro

								select @id_cuenta_destino=null
							end 
							IF @id_transferencia IS NULL OR @id_transferencia = 0
								insert TBL_BANCA_TRANSFERENCIAS_INTERNAS	
								(								
									id_cuenta_interna,
									monto,
									fecha_alta_transferencia,
									fecha_transferencia_realizada,
									id_estatus_transferencia,
									numero_socio,
									fecha_programada,
									id_banca_folio,
									clave_corresponsalias_origen,
									clave_corresponsalias_destino,
									programada
								)
								values
								(								
									@id_cuenta_destino,
									@monto,
									getdate(),
									case when @programada=1 then null else getdate() end,
									case when @programada=1 then 1 else 2 end,
									BANCA.dbo.FN_BANCA_CIFRAR(@numero_origen),
									case when @programada=1 then @horaProgramada else null end,
									@folio,
									@clabeCorresponsaliasRetiro,
									@clabeCorresponsaliasDeposito,
									@programada
								)


					end -- registra transferencia interna


					declare @origen_transaccion int

					select @origen_transaccion = 3 --*se asigna siempre "3" 
						--case 
							--when @tipoOrigen = 3 then 3 -- 3 Banca en l�nea 
							--when @tipoOrigen = 1 then 4 -- 4	Banca m�vil
							--else @tipoOrigen 
						--end

					if @programada=0 OR @id_transferencia > 0
					begin --si no es programada

							begin -- preparar captura

									begin -- preparar origen

											if @id_mov_origen = 100

											begin -- ahorro

												insert	#captura_
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_origen,
														'T',
														p.numero_origen,
														nombre_origen,
														paterno_origen,
														materno_origen,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'D',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_origen,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = 'S',
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 100
															and tm.id_tipomov = 310
														join HAPE.dbo.cuentas_contables cc
															on cc.Concepto like '%ahorro%socios'
															and cc.Num_cuenta like '212%'

											end -- ahorro


											if @id_mov_origen = 101

											begin -- ahorro de menores

												insert	#captura_
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_origen,
														'T',
														p.numero_origen,
														nombre_origen,
														paterno_origen,
														materno_origen,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'D',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_origen,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = 'S',
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 101
															and tm.id_tipomov = 312
														join HAPE.dbo.cuentas_contables cc
															on cc.Concepto like '%ahorro%menores'
															and cc.Num_cuenta like '213%'

											end -- ahorro de menores


											if @id_mov_origen = 103

											begin -- inverdin�mica

												insert	#captura_
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_origen,
														'T',
														p.numero_origen,
														nombre_origen,
														paterno_origen,
														materno_origen,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'D',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_origen,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = 'S',
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 103
															and tm.id_tipomov = 350
														join HAPE.dbo.cuentas_contables cc
															on cc.Concepto like '%vista'
															and cc.Num_cuenta like '211%'

											end -- inverdin�mica


											if @id_mov_origen = 112

											begin -- d�bito

												insert	#captura_
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_origen,
														'T',
														p.numero_origen,
														nombre_origen,
														paterno_origen,
														materno_origen,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'D',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_origen,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = 'S',
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 112
															and tm.id_tipomov = 1001
														join HAPE.dbo.cuentas_contables cc
															on cc.concepto like 'debito%'
															and cc.num_cuenta like '216%'

											end -- d�bito


									end -- preparar origen


									--begin -- cajas

									--		insert	#captura_
									--		(
									--		id_persona,
									--		activo,
									--		numero,
									--		nombre_s,
									--		apellido_paterno,
									--		apellido_materno,
									--		total_movs,
									--		total_ficha,
									--		id_tipomov,
									--		cuenta,
									--		concepto,
									--		fecha_mov,
									--		monto,
									--		id_mov,
									--		num_poliza,
									--		tipo_poliza,
									--		folio,
									--		id_tipo_persona,
									--		num_cheq,
									--		desc1,
									--		desc2,
									--		planx,
									--		desc3,
									--		fecha_dpf_final,
									--		num_dpf,
									--		tasa,
									--		interes,
									--		dias,
									--		debe_haber,
									--		numusuario,
									--		numero_fin,
									--		plazo,
									--		interes_ord,
									--		interes_mor,
									--		contador_provision,
									--		ccostos,
									--		nombre_beneficiario,
									--		parentesco_beneficiario,
									--		porcentaje_beneficiario,
									--		nombre_beneficiario2,
									--		parentesco_beneficiario2,
									--		porcentaje_beneficiario2,
									--		numero_fin_lacp,
									--		id_esquema,
									--		titular,
									--		num_ptmo,
									--		id_amortizacion,
									--		id_renovado,
									--		reestructura,
									--		id_origen
									--		)

									--select	id_persona_origen,
									--		'T',
									--		numero_origen,
									--		nombre_origen,
									--		paterno_origen,
									--		materno_origen,
									--		total_movs = 0,
									--		total_ficha = 0,
									--		id_tipomov = 961,
									--		cuenta = cc.num_cuenta,
									--		concepto = 'Cajas',
									--		fecha_mov = @fecha,
									--		monto = 0,
									--		id_mov = null,
									--		num_poliza = @num_poliza,
									--		tipo_poliza = @tipo_poliza,
									--		folio = @folio,
									--		id_tipo_persona = 1,
									--		num_cheq = 0,
									--		desc1 = 0,
									--		desc2 = 0,
									--		planx = null,
									--		desc3 = 0,
									--		fecha_dpf_final = cast(@fecha as date),
									--		num_dpf = 0,
									--		tasa = 0,
									--		interes = 0,
									--		dias = 0,
									--		debe_haber = 'H',
									--		numusuario = @numusuario,
									--		numero_fin = null,
									--		plazo = null,
									--		interes_ord = null,
									--		interes_mor = null,
									--		contador_provision = null,
									--		ccostos_origen,
									--		nombre_beneficiario = '',
									--		parentesco_beneficiario = '',
									--		porcentaje_beneficiario = 0,
									--		nombre_beneficiario2 = '',
									--		parentesco_beneficiario2 = '',
									--		porcentaje_beneficiario2 = 0,
									--		numero_fin_lacp = null,
									--		id_esquema = null,
									--		titular = 'S',
									--		num_ptmo = null,
									--		id_amortizacion = null,
									--		id_renovado = null,
									--		reestructura = null,
									--		id_origen = @tipoOrigen
									--from	#persona p
									--		join HAPE.dbo.cuentas_contables cc
									--			on concepto like 'caja'
									--			and num_cuenta like '111%'

									--end -- cajas



									begin -- prepara destino

											if @id_mov_destino = 100

											begin -- ahorro

												insert	#captura_
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_destino,
														'T',
														p.numero_destino,
														nombre_destino,
														paterno_destino,
														materno_destino,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'H',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_destino,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = case when @numero_origen = @numero_destino then 'S' else 'N' end,
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 100
															and tm.id_tipomov = 10
														join HAPE.dbo.cuentas_contables cc
															on cc.Concepto like '%ahorro%socios'
															and cc.Num_cuenta like '212%'

											end -- ahorro


											if @id_mov_destino = 101

											begin -- ahorro de menores

												insert	#captura_
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_destino,
														'T',
														p.numero_destino,
														nombre_destino,
														paterno_destino,
														materno_destino,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'H',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_destino,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = case when @numero_origen = @numero_destino then 'S' else 'N' end,
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 101
															and tm.id_tipomov = 12--HAPE.dbo.tm.id_tipomov = 12
														join hape..cuentas_contables cc
															on cc.Concepto like '%ahorro%menores'
															and cc.Num_cuenta like '213%'

											end -- ahorro de menores


											if @id_mov_destino = 103

											begin -- inverdin�mica

												insert	#captura_
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_destino,
														'T',
														p.numero_destino,
														nombre_destino,
														paterno_destino,
														materno_destino,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'H',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_destino,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = case when @numero_origen = @numero_destino then 'S' else 'N' end,
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 103
															and tm.id_tipomov = 50
														join HAPE.dbo.cuentas_contables cc
															on cc.Concepto like '%vista'
															and cc.Num_cuenta like '211%'

											end -- inverdin�mica


											if @id_mov_destino = 112

											begin -- d�bito

												insert	#captura_
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_destino,
														'T',
														p.numero_destino,
														nombre_destino,
														paterno_destino,
														materno_destino,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'H',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_destino,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = case when @numero_origen = @numero_destino then 'S' else 'N' end,
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 112
															and tm.id_tipomov = 1002
														join HAPE.dbo.cuentas_contables cc
															on cc.concepto like 'debito%'
															and cc.num_cuenta like '216%'

											end -- d�bito

									end -- prepara destino


									begin -- actualizar totales

										update	c
										set		c.total_movs = _.count_,
												c.total_ficha = 0
										from	(
												select	count(1) count_
												from	#captura_
												) _
												cross join #captura_ c

									end -- actualizar totales					
					
							end -- preparar captura		


							begin -- preparar captura_lacp

									begin -- preparar origen

											if @id_mov_origen = 100

											begin -- ahorro

												insert	#captura_lacp
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_origen,
														'T',
														p.numero_origen,
														nombre_origen,
														paterno_origen,
														materno_origen,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'D',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_origen,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = 'S',
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 100
															and tm.id_tipomov = 310
														join HAPE.dbo.cuentas_contables cc
															on cc.Concepto like '%ahorro%socios'
															and cc.Num_cuenta like '212%'

											end -- ahorro


											if @id_mov_origen = 101

											begin -- ahorro de menores

												insert	#captura_lacp
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_origen,
														'T',
														p.numero_origen,
														nombre_origen,
														paterno_origen,
														materno_origen,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'D',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_origen,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = 'S',
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 101
															and tm.id_tipomov = 312
														join HAPE.dbo.cuentas_contables cc
															on cc.Concepto like '%ahorro%menores'
															and cc.Num_cuenta like '213%'

											end -- ahorro de menores


											if @id_mov_origen = 103

											begin -- inverdin�mica

												insert	#captura_lacp
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_origen,
														'T',
														p.numero_origen,
														nombre_origen,
														paterno_origen,
														materno_origen,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'D',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_origen,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = 'S',
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 103
															and tm.id_tipomov = 350
														join HAPE.dbo.cuentas_contables cc
															on cc.Concepto like '%vista'
															and cc.Num_cuenta like '211%'

											end -- inverdin�mica


											if @id_mov_origen = 112

											begin -- d�bito

												insert	#captura_lacp
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_origen,
														'T',
														p.numero_origen,
														nombre_origen,
														paterno_origen,
														materno_origen,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'D',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_origen,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = 'S',
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 112
															and tm.id_tipomov = 1001
														join HAPE.dbo.cuentas_contables cc
															on cc.concepto like 'debito%'
															and cc.num_cuenta like '216%'

											end -- d�bito

											---Compensaci�n origen
											if(@ccostos_origen <> @ccostos_destino)
											begin
												
												declare 
													@cuenta_compensacion_origen varchar(40),
													@concepto_compensacion_origen varchar(80)

												select 
													 @cuenta_compensacion_origen = num_su.Num_Cuenta_Compensacion,
													 @concepto_compensacion_origen = num_su.Concepto
												from #persona p
												inner join 
													HAPE..sucursales su on p.id_de_sucursal_origen = su.Id_de_Sucursal
												inner join
													HAPE..NUM_SUCURSAL num_su on num_su.Num_Sucursal = su.Num_Sucursal

											    insert	#captura_lacp
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_origen,
														'T',
														p.numero_origen,
														nombre_origen,
														paterno_origen,
														materno_origen,
														total_movs = 0,
														total_ficha = 0,
														0,--tm.id_tipomov,
														cuenta = @cuenta_compensacion_origen,
														concepto = @concepto_compensacion_origen,
														fecha_mov = @fecha,
														monto = abs(@monto),
														null,--tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'D',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_destino,-----el centro de costo, se invierte para las compensaciones
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = 'S',
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 100
															and tm.id_tipomov = 310
														join HAPE.dbo.cuentas_contables cc
															on cc.Concepto like '%ahorro%socios'
															and cc.Num_cuenta like '212%'
		
											end ---Compensaci�n origen


									end -- preparar origen


									begin -- prepara destino

											if @id_mov_destino = 100

											begin -- ahorro

												insert	#captura_lacp
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_destino,
														'T',
														p.numero_destino,
														nombre_destino,
														paterno_destino,
														materno_destino,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'H',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_destino,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = case when @numero_origen = @numero_destino then 'S' else 'N' end,
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 100
															and tm.id_tipomov = 10
														join HAPE.dbo.cuentas_contables cc
															on cc.Concepto like '%ahorro%socios'
															and cc.Num_cuenta like '212%'

											end -- ahorro


											if @id_mov_destino = 101

											begin -- ahorro de menores

												insert	#captura_lacp
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_destino,
														'T',
														p.numero_destino,
														nombre_destino,
														paterno_destino,
														materno_destino,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'H',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_destino,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = case when @numero_origen = @numero_destino then 'S' else 'N' end,
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 101
															and HAPE.dbo.tm.id_tipomov = 12
														join cuentas_contables cc
															on cc.Concepto like '%ahorro%menores'
															and cc.Num_cuenta like '213%'

											end -- ahorro de menores


											if @id_mov_destino = 103

											begin -- inverdin�mica

												insert	#captura_lacp
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_destino,
														'T',
														p.numero_destino,
														nombre_destino,
														paterno_destino,
														materno_destino,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'H',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_destino,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = case when @numero_origen = @numero_destino then 'S' else 'N' end,
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 103
															and tm.id_tipomov = 50
														join HAPE.dbo.cuentas_contables cc
															on cc.Concepto like '%vista'
															and cc.Num_cuenta like '211%'

											end -- inverdin�mica


											if @id_mov_destino = 112

											begin -- d�bito

												insert	#captura_lacp
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_destino,
														'T',
														p.numero_destino,
														nombre_destino,
														paterno_destino,
														materno_destino,
														total_movs = 0,
														total_ficha = 0,
														tm.id_tipomov,
														cuenta = cc.num_cuenta,
														concepto = tm.descripcion,
														fecha_mov = @fecha,
														monto = abs(@monto),
														tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'H',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_destino,
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = case when @numero_origen = @numero_destino then 'S' else 'N' end,
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 112
															and tm.id_tipomov = 1002
														join HAPE.dbo.cuentas_contables cc
															on cc.concepto like 'debito%'
															and cc.num_cuenta like '216%'

											end -- d�bito

											---Compensaci�n destino
											if(@ccostos_origen <> @ccostos_destino)
											begin
												
												declare 
													@cuenta_compensacion_destino varchar(40),
													@concepto_compensacion_destino varchar(80)

												select 
													 @cuenta_compensacion_destino = num_su.Num_Cuenta_Compensacion,
													 @concepto_compensacion_destino = num_su.Concepto
												from #persona p
												inner join 
													HAPE..sucursales su on p.id_de_sucursal_destino = su.Id_de_Sucursal
												inner join
													HAPE..NUM_SUCURSAL num_su on num_su.Num_Sucursal = su.Num_Sucursal

												insert	#captura_lacp
														(
														id_persona,
														activo,
														numero,
														nombre_s,
														apellido_paterno,
														apellido_materno,
														total_movs,
														total_ficha,
														id_tipomov,
														cuenta,
														concepto,
														fecha_mov,
														monto,
														id_mov,
														num_poliza,
														tipo_poliza,
														folio,
														id_tipo_persona,
														num_cheq,
														desc1,
														desc2,
														planx,
														desc3,
														fecha_dpf_final,
														num_dpf,
														tasa,
														interes,
														dias,
														debe_haber,
														numusuario,
														numero_fin,
														plazo,
														interes_ord,
														interes_mor,
														contador_provision,
														ccostos,
														nombre_beneficiario,
														parentesco_beneficiario,
														porcentaje_beneficiario,
														nombre_beneficiario2,
														parentesco_beneficiario2,
														porcentaje_beneficiario2,
														numero_fin_lacp,
														id_esquema,
														titular,
														num_ptmo,
														id_amortizacion,
														id_renovado,
														reestructura,
														id_origen
														)

												select	id_persona_destino,
														'T',
														p.numero_destino,
														nombre_destino,
														paterno_destino,
														materno_destino,
														total_movs = 0,
														total_ficha = 0,
														0,--tm.id_tipomov,
														cuenta = @cuenta_compensacion_destino,
														concepto = @concepto_compensacion_destino,
														fecha_mov = @fecha,
														monto = abs(@monto),
														null,--tm.id_mov,
														num_poliza = @num_poliza,
														tipo_poliza = @tipo_poliza,
														folio = @folio,
														id_tipo_persona = 1,
														num_cheq = 0,
														desc1 = 0,
														desc2 = 0,
														planx = null,
														desc3 = 0,
														fecha_dpf_final = cast(@fecha as date),
														num_dpf = 0,
														tasa = 0,
														interes = 0,
														dias = 0,
														debe_haber = 'H',
														numusuario = @numusuario,
														numero_fin = null,
														plazo = null,
														interes_ord = null,
														interes_mor = null,
														contador_provision = null,
														p.ccostos_origen,-----el centro de costo, se invierte para las compensaciones
														nombre_beneficiario = '',
														parentesco_beneficiario = '',
														porcentaje_beneficiario = 0,
														nombre_beneficiario2 = '',
														parentesco_beneficiario2 = '',
														porcentaje_beneficiario2 = 0,
														numero_fin_lacp = null,
														id_esquema = null,
														titular = case when @numero_origen = @numero_destino then 'S' else 'N' end,
														num_ptmo = null,
														id_amortizacion = null,
														id_renovado = null,
														reestructura = null,
														id_origen = @origen_transaccion
												from	#persona p
														join HAPE.dbo.tipo_mov tm
															on tm.id_mov = 100
															and tm.id_tipomov = 10
														join HAPE.dbo.cuentas_contables cc
															on cc.Concepto like '%ahorro%socios'
															and cc.Num_cuenta like '212%'
		
											end

									end -- prepara destino


									begin -- actualizar totales

										update	c
										set		c.total_movs = _.count_,
												c.total_ficha = 0
										from	(
												select	count(1) count_
												from	#captura_lacp
												) _
												cross join #captura_lacp c

									end -- actualizar totales					
					
							end -- preparar captura_lacp	



							begin -- se revisan los saldos en las cuentas involucradas
				
								if exists (select 1 from HAPE.dbo.edo_de_cuenta where numero = @numero_origen and id_mov = @id_mov_origen and saldo_actual != @saldo_origen)
									or exists (select 1 from HAPE.dbo.edo_de_cuenta where numero = @numero_destino and id_mov = @id_mov_destino and saldo_actual != @saldo_destino)

									begin

										select @status=345
										select @message = '345|Transferencia incorrecta|Los saldos obtenidos al inicio de la transacci�n han sido modificados por otra transacci�n'

										raiserror (@message, 11, 0)

									end
				
							end -- se revisan los saldos en las cuentas involucradas



					 if (@id_mov_origen != 10)
					 begin -- inicio del if si no es revolvente
							begin -- insertar en captura

																																																																																																																			insert	hape.dbo.captura
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen,
									id_tipo_pago_prestamo
									)
							select	id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen,
									id_tipo_pago_prestamo
							from	#captura_
							order by
									contador

							end -- insertar en captura


							begin -- insertar en captura_lacp

																																																																																																																			insert	hape.dbo.captura_lacp
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen,
									id_tipo_pago_prestamo
									)
							select	id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen,
									id_tipo_pago_prestamo
							from	#captura_lacp
							order by
									contador

							end -- insertar en captura_lacp


							begin -- insertar en movimientos

																																																																																						insert	hape.dbo.movimientos
									(
									numero,
									activo,
									fecha_mov,
									monto,
									saldo,
									tipo_poliza,
									num_poliza,
									folio,
									fecha_alta,
									interes_ord,
									interes_mor,
									plazo,
									numero_fin,
									id_persona,
									numusuario,
									id_tipomov,
									fecha_dpf_final,
									num_dpf,
									tasa_dpf,
									interes_dpf,
									dias,
									id_mov,
									id_tipo_persona,
									numero_fin_lacp,
									reestructura,
									id_motivo_reestructura,
									id_esquema,
									id_convenio,
									id_amortizacion,
									titular,
									planx,
									num_ptmo,
									id_nomina,
									id_esquema_nomina,
									id_renovado,
									id_origen,
									id_tipo_pago_prestamo
									)
							select	c.numero,
									c.activo,
									fecha_mov,
									monto,
									saldo = 0,
									tipo_poliza,
									num_poliza,
									folio,
									fecha_alta = @fecha,
									interes_ord,
									interes_mor,
									c.plazo,
									c.numero_fin,
									c.id_persona,
									numusuario,
									id_tipomov,
									fecha_dpf_final,
									num_dpf,
									tasa_dpf = 0,
									interes_dpf = 0,
									dias,
									c.id_mov,
									c.id_tipo_persona,
									c.numero_fin_lacp,
									reestructura,
									id_motivo_reestructura = null,
									c.id_esquema,
									id_convenio = null,
									c.id_amortizacion,
									titular,
									c.planx,
									c.num_ptmo,
									null id_nomina,
									null id_esquema_nomina,
									c.id_renovado,
									id_origen,
									id_tipo_pago_prestamo
							from	#captura_ c
							where	id_tipomov != 961

							end -- insertar en movimientos
						



						    begin -- actualizar saldo en movimientos

							select	identity(int, 1, 1) id,
									cast(m.contador as int) contador,
									m.numero,
									m.id_mov,
									monto,
									saldo_antes = cast(null as money),
									saldo_despues = cast(null as money),
									case
										when
											id_mov = 100 and Id_tipomov = 10
											or id_mov = 101 and Id_tipomov = 12
											or id_mov = 103 and Id_tipomov = 50
											or id_mov = 112 and Id_tipomov = 1002
											then 1
										else -1
									end operacion
							into	#saldos_movimientos
							from	hape.dbo.movimientos m
							where	numusuario = @numusuario
									and folio = @folio
									and cast(fecha_mov as date) = cast(@fecha as date)
									and num_poliza = @num_poliza
									and m.id_mov !< 100

							update	u
							set		saldo_antes = __.saldo,
									saldo_despues = __.saldo + operacion * monto
							from	(
									select	_.*, cta.saldo_actual saldo
									from	hape.dbo.edo_de_cuenta cta
											join
												(							
												select	min(sm.contador) contador, sm.numero, sm.id_mov
												from	#saldos_movimientos sm
												group by sm.numero, sm.id_mov
												) _
												on _.numero = cta.numero
												and _.id_mov = cta.id_mov
									) __
									join #saldos_movimientos u
										on u.contador = __.contador

							while exists
								(
								select	1
								from	#saldos_movimientos sm1
										join #saldos_movimientos sm2
											on sm2.id = sm1.id + 1
											and sm2.numero = sm1.numero
											and sm2.id_mov = sm1.id_mov
											and sm2.saldo_antes is null
								)

							update	sm2
							set		saldo_antes = sm1.saldo_despues,
									saldo_despues = sm1.saldo_despues + sm2.operacion * sm2.monto
							from	#saldos_movimientos sm1
									join #saldos_movimientos sm2
										on sm2.id = sm1.id + 1
										and sm2.numero = sm1.numero
										and sm2.id_mov = sm1.id_mov
										and sm2.saldo_antes is null

							update	m
							set		saldo = round(sm.saldo_despues, 2)
							from	hape.dbo.movimientos m
									join #saldos_movimientos sm
										on sm.numero = m.numero
										and sm.contador = m.contador

						end -- actualizar saldo en movimientos

						    begin -- actualizar edo_de_cuenta



							begin -- haberes

								update	HAPE.dbo.edo_de_cuenta
								set		saldo_actual = round(saldo_actual - @monto, 2),
										Fecha=@fecha_tran
								where	numero = @numero_origen
										and id_mov = @id_mov_origen
										and id_tipo_persona = @id_tipo_persona_origen

								update	HAPE.dbo.edo_de_cuenta
								set		saldo_actual = round(saldo_actual + @monto, 2),
										Fecha=@fecha_tran
								where	numero = @numero_destino
										and id_mov = @id_mov_destino
										and id_tipo_persona = @id_tipo_persona_destino

							end -- haberes

						end -- actualizar edo_de_cuenta

					  end   -- fin del if  si no es revolvente

						if @id_mov_origen=10
						begin -- si es revolvente


							create table
							#sp_revolvente_inserta_nueva_disposicion
								(
								status			int null,
								error_procedure	varchar(255) null,
								error_line		varchar(255) null,
								error_severity	varchar(255) null,
								error_message	varchar(255) null,
								id_disposicion	int null,
								) 

							
							--select @id_linea_revolvente, @numero_origen, @monto, @numusuario, @folio, @num_poliza, 0 as contador_provision, @id_tipo_persona_origen, @fecha, @numusuario, 3
							exec hape.dbo.SP_REVOLVENTE_INSERTA_NUEVA_DISPOSICION @id_linea_revolvente, @numero_origen, @monto, @numusuario, @folio, @num_poliza, 0, @id_tipo_persona_origen, @fecha, @numusuario, 3
							
							
							

							declare @status_tabla int
							select @status_tabla=status from #sp_revolvente_inserta_nueva_disposicion


							if(@status_tabla<=0 or @status_tabla is null)
							begin
								select @status=382
								select @message = (select error_message from #sp_revolvente_inserta_nueva_disposicion)
								raiserror (@message, 11, 0)
							end


						end -- si es revolvente


					end -- si no es programada

					

					begin -- commit
				
							if @tran_count = 0
					

								begin -- si la transacci�n se inici� dentro de este �mbito
						
									commit tran @tran_name
									select @tran_scope = 0
						
								end -- si la transacci�n se inici� dentro de este �mbito
				
					end -- commit


					select @status = 200

			end -- transacci�n




				
		
		end try -- try principal
		
		begin catch -- catch principal
		
			
			select @status=coalesce(@status, 383)


			select	--@status=@status,
					--@status =error_state(),	
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end

					--select @status=coalesce(@status, 0)
			-- revertir transacci�n si es necesario
			if @tran_scope = 1
			begin

				rollback tran @tran_name
			end


		
		end catch -- catch principal
		
		begin -- reporte de status

			select	@status estatus,
					case when @status=200 then @folio else null end folio,
					case when @status=200 then @fecha_tran else null end HoraTransaccion,
					case when @status=200 then @monto else null end Monto,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message mensaje
				
		end -- reporte de status
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_REALIZAR_INVERSION]    Script Date: 29/01/2020 10:47:09 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		VICTOR ADRIAN REYES
-- Create date: 2
-- Description:	
--				
-- =============================================

ALTER PROCEDURE [dbo].[SP_BANCA_REALIZAR_INVERSION]

@NumeroSocio varchar(20),
@dias int ,
@tasa decimal(18,2),
@cuentas xml,
@idOrigen int = 3, 
@idTipoPersona int = 1
as 

BEGIN -- INICIO SP


		declare	@estatus int = 1,
				@error_message varchar(255),
				@validacion varchar(255),
				@AhorroBase decimal (18,2),
				@idInversion int,
				@numero_int int,
				@idOrigenHape int = 3,
				@monto_min_inversion money,
				@monto_max_inversion money,
				@monto_inversiones_al_dia money,
				@montoTotalInversion money,
				@tasaInversionAValidar float

		declare	@tran_name varchar(32) = 'REALIZA_INVERSION_BANCA',
				@tran_count int = @@trancount,
				@tran_scope bit = 0
			
		begin try
	
			IF OBJECT_ID('tempdb..#cuentasDPF') IS NOT NULL
			DROP TABLE #cuentasDPF

			IF OBJECT_ID('tempdb..#tasaInversion') IS NOT NULL
			DROP TABLE #tasaInversion

			create table #tasaInversion
			(
				estatus int null, 
			    mensaje varchar(250), 
				contador int ,
				tasa float,
				Fecha_cambio	datetime,
				Minimo	int,
				Maximo	int,
				Plazo_min	int,
				Plazo_max	int,
				Descripcion	varchar(30),
				Id_mov	smallint,
				Id_tipomov	int,
			)


			create table #cuentasDPF
			(
				idCuenta int null, -- ID_MOV
			    clabeCorresponsalias varchar(20)  collate Traditional_Spanish_CI_AS null ,
				monto  decimal(18,2)  null , 
				numero int null , 
				saldoActual decimal(18,2) null ,
				saldoDisponible decimal(18,2) null,
				saldoDespuesDeOperacion decimal(18,2), 
				idTipoMovRetiro int NULL,
				concepCaptura varchar(250) NULL,
				Cuenta varchar(14) NULL,
				DebeHaber varchar(1) NULL
			)

			-- select * from hape..TBL_CMV_FOLIOS_POLIZAS_PROCESOS 
			-- select * from hape..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'BANCA ELECTRONICA'
			 -- validaciones de que la cuenta no este bloquear  , el socio tenga su cuenta activa
		SELECT @error_message =msj ,@estatus = estatus  FROM  dbo.FN_BANCA_VALIDA_SOCIO(@NumeroSocio,1)

		IF(@error_message is null )
			BEGIN
			  SET @numero_int = CAST(@NumeroSocio as int )
			;WITH XMLNAMESPACES(
			 'http://schemas.datacontract.org/2004/07/ServiciosBancaEntidades.Requests' as n,
			 'http://schemas.datacontract.org/2004/07/ServiciosBancaEntidades.Inversiones' as a)
			INSERT INTO #cuentasDPF (numero,clabeCorresponsalias , monto /*,idCuenta*/ )
			SELECT  
			@NumeroSocio,
            Cuentas.value('a:ClabeCorresponsaliasRetiro[1]', 'varchar(20)'),
	        Cuentas.value('a:Monto[1]', 'decimal(18,2)')
			--Cuentas.value('a:ClabeCorresponsaliasRetiro[1]', 'int')
		    FROM 
			@cuentas.nodes('//n:RequestRealizarInversion/n:CuentasRetiro/a:CuentaInversion') AS XD(Cuentas)

			
			BEGIN -- VALIDACIONES
				    

				/*--Se valida que las cuentas de corresponsalias recibidas sean del socio indicado en el request
					por lo tanto si se encuentra una distinta se manda el error		*/
				IF EXISTS (
				select * from #cuentasDPF c join HAPE..TBL_CORRESPONSALIAS_CUENTAS cc on c.clabeCorresponsalias = cc.CUENTA
				where
					cc.NUMERO <> @numero_int)
				BEGIN
					SELECT  @error_message = 'Datos incorrectos'
					SELECT 1000 AS estatus  , @error_message mensaje
					return
				END



				-- OBTENEMOS LOS ID_MOV CON BASE A LA CLABE DE CORRESPONSALIAS
				  UPDATE #cuentasDPF 
							SET  #cuentasDPF.clabeCorresponsalias = Hc.CUENTA,
								#cuentasDPF.idCuenta = HC.ID_MOV
					FROM 
						#cuentasDPF c join HAPE..TBL_CORRESPONSALIAS_CUENTAS HC
						on c.numero = HC.Numero and c.clabeCorresponsalias = HC.CUENTA
					WHERE
						 HC.Numero =c.numero
					--ELIMINAMOS CUENTAS DONDE LOS MONTOS SEAN IGUALES A CERO  PARA SOLO TRABAJAR CON LAS QUE SE DESEAN AFECTAR
					DELETE FROM #cuentasDPF WHERE monto <=0 or idCuenta<=10
					
					--VALIDAMOS QUE SE TENGAN CUENTAS DE HABERES PARA COMENZAR LAS OPERACIONES
					-- ESTA VALIDACION SE AGREGA DEBIDO A QUE PUEDEN MANDAR CUENTAS DE PRESTAMOS
					if ((select COUNT(*) from #cuentasDPF) <=0 )
					begin
							SELECT  @error_message = descripcion
							FROM CAT_BANCA_EXCEPTIONS
							WHERE id_excepcion = 383
							SELECT 383 AS estatus  , @error_message mensaje
							return
					end

					
					
					-- SI EN LAS CUENTAS QUE MANDA EXISTE  LA CUENTA DE AHORRO SE BUSCA SI TIENE AHORRO COMPROMETIDO
						if exists (select 1 from #cuentasDPF where idCuenta = 100 and monto  > 0)
						BEGIN
							 SELECT @AhorroBase = isnull(sum(isnull(Ahorro_Base,0)),0) 
							 FROM HAPE..EDO_DE_CUENTA  
							 WHERE  Numero = @numero_int 
								and Id_Tipo_persona = @idTipoPersona
								and Id_mov < 100
								and Saldo_Actual > 0
						END
					PRINT 'EDC'+CAST(ISNULL(@AhorroBase,0) AS VARCHAR)


			     
				--- OBTENEMOS LOS SALDOS DE LAS CUENTAS DISPONIBLES DE ESTADO DE CUENTA
					UPDATE #cuentasDPF 
							SET  #cuentasDPF.saldoDisponible = CASE 
							WHEN C.idCuenta = 100 THEN isnull((EDC.Saldo_Actual - ISNULL(@AhorroBase,0)),0) ELSE  EDC.Saldo_Actual END,
							#cuentasDPF.saldoActual = ISNULL(EDC.Saldo_Actual,0),
							#cuentasDPF.idTipoMovRetiro = CASE WHEN C.idCuenta = 100 THEN 310
															  WHEN C.idCuenta = 103 THEN 350
															  WHEN C.idCuenta = 112 THEN 1001 END,
						   #cuentasDPF.Cuenta = CASE WHEN C.idCuenta = 100 THEN '21200000000000'
															  WHEN C.idCuenta = 103 THEN '21100000000000'
															  WHEN C.idCuenta = 112 THEN '21600000000000' END

					FROM 
						#cuentasDPF c join HAPE..EDO_DE_CUENTA EDC 
						on c.numero = EDC.Numero 
						and c.idCuenta = EDC.Id_mov 
					WHERE
						 EDC.Numero =c.numero AND EDC.Id_Tipo_persona = @idTipoPersona

				-- actualizamos el saldo que quedaria despues de restar el monto para realizar la inversion
					UPDATE #cuentasDPF SET saldoDespuesDeOperacion = (isnull(saldoDisponible,0) - monto)

				-- ACTUALIZAMOS LAS DESCRIPCION DE LOS MOVIMIENTOS y el valor de debe_haber
					UPDATE #cuentasDPF 
							SET  #cuentasDPF.concepCaptura = TM.Descripcion,
								 #cuentasDPF.DebeHaber = TM.Debe_haber
					FROM 
						#cuentasDPF c join HAPE..TIPO_MOV TM 
						on c.idCuenta = TM.Id_mov AND c.idTipoMovRetiro = TM.Id_tipomov

					 
					 --validos que la tasa de inversion se valida
						 select @montoTotalInversion = SUM (isnull(monto,0)) from #cuentasDPF

						 insert into #tasaInversion (estatus, mensaje,contador,tasa,Fecha_cambio, Minimo,Maximo,Plazo_min,Plazo_max,Descripcion,Id_mov,Id_tipomov)
						 exec [SP_BANCA_OBTENER_TASA_INVERSION] @montoTotalInversion, @dias, @numero_int

						--select * from #tasaInversion

						 select @tasaInversionAValidar = isnull(tasa,0) from #tasaInversion
						 --print '@tasaInversionAValidar' +cast (@tasaInversionAValidar as varchar)
						 if (@tasaInversionAValidar <> @tasa OR (select COUNT(*) from #tasaInversion) <=0)
						 BEGIN 
							  SELECT @error_message = descripcion
							  FROM CAT_BANCA_EXCEPTIONS
							  WHERE id_excepcion = 409

							  SELECT 409 AS estatus  , @error_message mensaje
							  return
						 END
					 -- fin de validos que la tasa de inversion se valida

					 
					

					-- validamos si despues de la operacion el saldo es menor que cero  regresamos un exception 
					IF EXISTS (SELECT 1  FROM #cuentasDPF WHERE saldoDespuesDeOperacion < 0 )
						BEGIN
								SELECT @error_message =descripcion
								FROM CAT_BANCA_EXCEPTIONS
								WHERE id_excepcion = 329
								
								SELECT @error_message  =@error_message+' '+TDO.Desc_prestamo FROM HAPE..TIPOS_DE_OPERACIONES TDO JOIN #cuentasDPF C ON TDO.Id_mov = C.idCuenta
								WHERE C.saldoDespuesDeOperacion < 0
								SELECT 329 AS estatus  , @error_message mensaje
								return
						END

					--ACTUALIZAMOS EL SALDO DE AHORRO PARA QUE SE VEA REFLEJADO LA OPERACION CON SALDO ACTUAL Y 
					--NO CON EL SALDO DISPONIBLE
					IF EXISTS (SELECT 1 FROM #cuentasDPF WHERE idCuenta = 100)
						UPDATE #cuentasDPF SET saldoDespuesDeOperacion = (saldoActual - monto) WHERE idCuenta = 100

					
					select @idOrigenHape = ( case when @idOrigen = 1 then 4 else 3 end)
					--select * from CAT_BANCA_EXCEPTIONS order by id_excepcion

					--  VALIDACI�N DEL MONTO TOTAL QUE SEA MULTIPLO DE 100
					IF (SELECT (SUM(ISNULL(monto,0))) % 100 FROM #cuentasDPF) > 0
					BEGIN
							SELECT descripcion as mensaje , id_excepcion as estatus	FROM CAT_BANCA_EXCEPTIONS	WHERE id_excepcion = 394
							return
						   --raiserror ('El monto de la apertura no es permitido, requiere ser multiplo de 100.', 11, 0)
					END
					
					--===================================	VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS	===============================
					BEGIN
						declare 
							@fecha_ datetime, 
							@tipoTransferencia int 

						select @tipoTransferencia = 5	---5.- INVERSIONES

						select 
							@estatus = estatus, @error_message = msj  
						from  
							FN_VALIDAR_LIMITES_TRANSFERENCIAS_DIARIO (@tipoTransferencia,@numero_int,@montoTotalInversion,getDate(),0/*programada*/)

						if @estatus <> 200
						begin
							raiserror (@error_message, 11, 0)
						end
					END ---VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS


					/*
					SELECT @monto_min_inversion = minimo, @monto_max_inversion = maximo from TBL_BANCA_LIMITES_TRANSFERENCIAS
						WHERE id_limite_transferencia = 4

					--  VALIDACI�N DEL MONTO TOTAL QUE SEA MAYOR AL MINIMO CONFIGURADO
					IF (SELECT SUM(ISNULL(monto,0)) FROM #cuentasDPF) < @monto_min_inversion
					begin
							SELECT descripcion as mensaje , id_excepcion as estatus	FROM CAT_BANCA_EXCEPTIONS	WHERE id_excepcion = 397
							return
							--raiserror ('El monto de la apertura no es permitido, no cumple con el monto minimo', 11, 0)
					end

					select @monto_inversiones_al_dia = SUM (Monto) from hape..MOVIMIENTOS where Numero = @numero_int and id_mov = 105 and Id_tipomov = 41 
						and Activo = 'T' and CONVERT(varchar,Fecha_Mov,112) = CONVERT(varchar,GETDATE(),112) 

					--  VALIDACI�N DEL MONTO TOTAL QUE SEA MAYOR AL MAXIMO POR D�A CONFIGURADO
					IF (SELECT (SUM(ISNULL(monto,0)) + @monto_inversiones_al_dia)  FROM #cuentasDPF) > @monto_max_inversion
					begin
							SELECT descripcion as mensaje , id_excepcion as estatus	FROM CAT_BANCA_EXCEPTIONS	WHERE id_excepcion = 396
							return
						--raiserror ('El monto de la apertura no es permitido, excede el monto m�ximo de inversi�n por d�a.', 11, 0)
					end

					*/

					
			END
	
			BEGIN --SE INICIALIZA LA TRANZACION PERO PRIMERO SE VALIDA SI EXISTTE UNA TRANSACCION PADRE

				DECLARE
				@NumPoliza BIGint  = 0000,
				@TipoPoliza varchar(1) ='M', --CAJAS
				@NumUsuarioBanca int = 1024 ,
				@CuentaContable varchar(14) = '21400000000000',
				@DebeHaber varchar(1)='H',
				@fechaTransaccion datetime =  getDate(),
				@Titular varchar(1)='S',
				@IdPersona int,
				@NombreS varchar(50),
				@ApellidoPaterno varchar(50),
				@ApellidoMaterno varchar(50),
				@TotalMovs int = 1,
				@ConceptoCaptura  varchar(1000)='',
				@SaldoDepositosPLazos decimal (18,2),
				@MontoTotalOperacion decimal(18,2),
				@NumDPF int ,
				@Ccostos varchar(10),
				@id_banca_folio bigint,
				@folio_bitacora bigint, -- el folio que se le debe notificar al usuario
				@calle varchar(max),
				@fechaVencimiento  date,
				@fechaOperacion datetime = getdate(),
				@rendimientos_antes_impuestos decimal(18,2),
				@retension_isr decimal(18,2),
				@idSucusal int ,
				@id_constancia bigint,
				@id_estatus_envio int = 1 -- Pendiente de envio

				

				   --OBTENEMOS EL NUMERO DE POLIZA PARA BANCA ELECTRONICA
					select @NumPoliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
					select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'BANCA ELECTRONICA')
					and dia = DAY(GETDATE()) 


				-- OBTENEMOS EL ID PERSONA Y NOMBRE PARA CAPTURA
					SELECT
					@IdPersona = Id_Persona , 
					@NombreS = Nombre_s , @ApellidoPaterno =ISNULL(Apellido_Paterno,''), @ApellidoMaterno = ISNULL(Apellido_Materno,' '),
					@Ccostos  = S.Ccostos,
					@idSucusal = S.Id_de_Sucursal
					FROM HAPE..PERSONA P 
					JOIN HAPE..SUCURSALES S  on P.Id_de_Sucursal = S.Id_de_Sucursal
					WHERE Numero = @numero_int AND Id_Tipo_Persona  = @idTipoPersona
					
					PRINT 'persona'+ cast(@numero_int as varchar)

				-- OBTENEMOS LA DESCRIPCION DEL MOVIMIENTO
				   SELECT @ConceptoCaptura = Descripcion FROM HAPE..TIPO_MOV WHERE Id_TIPOmov = 41 AND Id_mov = 105
		   		   			

				--  OBTENEMOS EL MONTO TOTAL DE LA OPERACION
					SELECT  @MontoTotalOperacion = SUM(ISNULL(monto,0)) FROM #cuentasDPF
		
				
						--  VALIDAMOS SI EXISTEN SALDOS DIFERENTES  CON LOS QUE SE REALIZO EL CALCULO
						IF EXISTS ( SELECT * FROM  #cuentasDPF C JOIN HAPE..EDO_DE_CUENTA EDC  
										ON C.idCuenta  = EDC.Id_mov AND C.numero = EDC.Numero AND EDC.Id_Tipo_persona = @idTipoPersona
										WHERE C.saldoActual != cast(EDC.Saldo_Actual as decimal(18,2)))
						BEGIN
						      
							SELECT descripcion as mensaje , id_excepcion as estatus	FROM CAT_BANCA_EXCEPTIONS	WHERE id_excepcion = 398
							return
						      --raiserror ('Apertura incorrecta.Los saldos obtenidos al inicio de la transacci�n han sido modificados por otra transacci�n', 11, 0)
						END

					-- VALIDAMOS SI EXISTE UN TRANSCCION PREVIO SE GUARDA  DE NO SER ASI SE INICIALIZA
						IF @tran_count = 0
							begin tran @tran_name
						ELSE
							save tran @tran_name
				
						SELECT @tran_scope = 1


						DECLARE
						@id_tipo_bitacora int= 19, -- Apertura de Inversion
						@estatusBitacora  int,
						@mensaje_bitacora varchar(500)
						
						-- OBTENEMOS EL FOLIO PARA DAR SEGUIMIENTO DESDE LA BITACORA
						-- ESTE FOLIO ES EL QUE DEBE REFLEJARSE EN MOVIMIENTOS Y CAPTURA CAPTURA_LACP DE HAPE
						INSERT INTO BANCA..TBL_BANCA_FOLIOS (numero_socio,fecha_alta) values(@numero_int , getdate())
						SELECT @id_banca_folio = MAX(id_banca_folio) from BANCA..TBL_BANCA_FOLIOS where numero_socio =@numero_int

						BEGIN -- REGISTRO EN BITACORA
							/*select @id_tipo_bitacora = case when  @id_mov_origen = 100 then  52
																when  @id_mov_origen = 103 then  51
																when  @id_mov_origen = 112 then  53
														end
							*/
							-- INSERTAMOS EN LA BITACORA LOS ID�S CORRESPONDIENTES A LA CUENTAS DE DONDE 
							-- SE TOMA EL DINEROS PARA REALIZAR PARA LA APERTURA DE LA INVESION
							INSERT INTO TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							SELECT 
								   @id_banca_folio,
								   CASE WHEN idCuenta = 100 THEN 52
														WHEN idCuenta = 103 THEN 51
														WHEN idCuenta = 112 THEN 53 END,
									@numero_int,
									GETDATE(),
									@idOrigen
							FROM #cuentasDPF

							-- INSERTAMOS EN LA BITACORA EL ID CORRESPONDIENTE A LA APERTURA DE UNA  INVERSION
						    insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							values(@id_banca_folio, @id_tipo_bitacora, @numero_int, getdate(), @idOrigen)
							
							
							select @mensaje_bitacora =descripcion from CAT_BANCA_TIPOS_BITACORA  where id_tipo_bitacora = 19
							/*IF OBJECT_ID('tempdb..#Results') IS NOT NULL
							DROP TABLE #Results
					
							CREATE TABLE #Results (estatus int null , mensaje varchar(500) null , folio bigint null , descripcion varchar(500))
 
							INSERT #Results EXECUTE SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_int , @id_tipo_bitacora,@idOrigen, @id_banca_folio
							SELECT @estatusBitacora = estatus  , @mensaje_bitacora = descripcion , @folio_bitacora = folio FROM #Results

							IF @estatusBitacora <> 200
							BEGIN
								raiserror (@mensaje_bitacora, 11, 0)
							END*/

						END -- REGISTRO BITACORA



						-- OBTENEMOS EL NUMERO DE PLAZO FIJO  QUE DEBERIA CORRESPONDER SI TODO ESTA BIEN 
						INSERT INTO HAPE..num_dpf(numusuario) values (@NumUsuarioBanca)
						SELECT @NumDPF=max(id_num_dpf) from HAPE..num_dpf where numusuario=@NumUsuarioBanca
						

						-- OBTENER EL NUMERO DE MOVIMIENTOS  Y SE SUMA 1 POR LA APERTURA DEL PLAZO
						SELECT @TotalMovs =(COUNT(*)+1)FROM #cuentasDPF WHERE monto > 0
						PRINT 'TOTAL MOVIMIENTOS '+ cast(@TotalMovs as varchar)

						---- INSERTAMOS LOS BENEFICIARIOS  DEL PLAZO FIJO 
						INSERT INTO hape..BENEFICIARIOS (Nombre_s,
													Apellido_Paterno,
													Apellido_Materno,
													Porcentaje,
													Id_Parentesco,
													Num_DPF,
													Id_persona,
													calle,
													Numero_Exterior,
													Numero_Interior,
													Id_Colonia_CNBV,
													Fecha_Nacimiento)
						SELECT  
												Nombre_Referencia,
												Apellido_Paterno_Referencia,
												Apellido_Materno_Referencia,
												Porcentaje,
												Id_Parentesco,
												@numDPF,
												Id_persona,
												Calle_Referencia,
												Numero_Exterior_Referencia,
												Numero_Interior_Referencia,
												Id_Colonia_CNBV,
												Fecha_de_Nacimiento
						FROM hape..referencias 
						WHERE Id_de_Referencia in (1,7,8,9) and Id_Persona = @IdPersona


						----INICIO INSERTAMOS LA CONSTANCIA
						if OBJECT_ID('tempdb..#estatusConstancia') is not null
							drop table #estatusConstancia


						CREATE TABLE #estatusConstancia
						( 
							status int ,
							error_message varchar(255) ,
							error_line varchar(255) ,
							error_severity varchar(255) ,
							error_procedure varchar(255),
							--lugar_operacion varchar(255),
							--nombre_usuario varchar(255)
						)


						if OBJECT_ID('tempdb..#proyecciones_plazo') is not null
							drop table #proyecciones_plazo

						CREATE TABLE #proyecciones_plazo
						(
							fecha_proximo_vencimiento datetime,
							interes_proyectado decimal,
							isr_a_retener decimal
						)
						---- OBTENEMOS EL RENDIMIENTO DEL PLAZO
						INSERT INTO #proyecciones_plazo
						exec HAPE..SP_CAJAS_OBTIENE_PROYECCION_PLAZO  @MontoTotalOperacion,@tasa,@dias,@fechaOperacion


						---- obtenemos  fecha_vencimiento   rendimientos  e isr del plazo
						select
						   @rendimientos_antes_impuestos = ( isnull(interes_proyectado,0) - isnull(isr_a_retener,0)),
						   @retension_isr = isnull(isr_a_retener,0),
						   @fechaVencimiento = fecha_proximo_vencimiento
						  from #proyecciones_plazo

						INSERT INTO  #estatusConstancia
						exec hape..SP_CONTRATOS_HABERES_INSERTA_CONSTANCIA 
						@numDPF,@numPoliza,@dias,@rendimientos_antes_impuestos,
						@retension_isr,@fechaVencimiento,@MontoTotalOperacion,0/*NumUsuario*/,@idSucusal,@tasa,@id_estatus_envio /*para el servicio*/

						
						IF((SELECT [status] FROM  #estatusConstancia) <> 1)
						BEGIN
							raiserror ('Apertura incorrecta. Datos incorrectos para realizar la constancia', 11, 0)
						END

						-- insertamos los movimientos de los haberes afectados para la apertua del plazo fijo
						select @id_constancia= id_constancia from hape..TBL_CONTRATOS_HABERES_CONSTANCIA where num_dpf=@numDPF
						insert into HAPE..TBL_CONTRATOS_HABERES_MOVS_DPF (id_constancia , id_mov , importe_cargado , importe_depositado , fecha_alta)
						select  @id_constancia , idCuenta,monto,0 , GETDATE() from #cuentasDPF
						
						-- insertamo el movimiento del plazo fijo
						insert into HAPE..TBL_CONTRATOS_HABERES_MOVS_DPF (id_constancia , id_mov , importe_cargado , importe_depositado , fecha_alta)
						values(@id_constancia , 105,0,@MontoTotalOperacion , GETDATE() )

				
						--------------- UPDATE A ESTADO DE CUENTA -------------
						UPDATE HAPE..EDO_DE_CUENTA
								SET HAPE..EDO_DE_CUENTA.Saldo_Actual =  c.saldoDespuesDeOperacion
						FROM HAPE..EDO_DE_CUENTA EDC JOIN  #CuentasDPF c 
						ON EDC.Numero = c.numero AND EDC.Id_Tipo_persona = @idTipoPersona AND EDC.Id_mov = c.idCuenta
						WHERE 
						C.Numero = @numero_int and Id_mov = c.idCuenta and Id_Tipo_persona = @idTipoPersona


						-- OBTENEMOS LOS MONTOS DE LOS PLAZOS FIJOS QUE TIENE
						SELECT @SaldoDepositosPLazos = ISNULL(Saldo_Actual,0) FROM HAPE..EDO_DE_CUENTA 
						WHERE  Numero = @numero_int AND Id_mov = 105 AND Id_Tipo_persona = @idTipoPersona
						PRINT'@SaldoDepositosPLazos:'+CAST(@SaldoDepositosPLazos AS VARCHAR)						 

						--  ACTUALIZAMOS EL SALDO DE LOS DEPOSITOS DE PLAZO FIJO CON LOS QUE CUENTA EL SOCIO
						UPDATE HAPE..EDO_DE_CUENTA 
						SET Saldo_Actual = (@SaldoDepositosPLazos + @MontoTotalOperacion)
						WHERE Numero = @numero_int and Id_mov = 105 and Id_Tipo_persona = @idTipoPersona


						------ INICIO INSERTAMOS  EL MOVIMIENTO CORRESPONDIENTE A LA APERTURA  ---
								print 'antes de INICIO INSERTAMOS EL MOVIMIENTO CORRESPONDIENTE A LA APERTURA'
								INSERT INTO HAPE.dbo.MOVIMIENTOS 
									(Numero,Activo,Fecha_Mov,
									Monto,Saldo,Tipo_Poliza,
									Num_Poliza,	Folio,Fecha_Alta,
									Id_Persona,	Numusuario,Id_tipomov,
									id_mov,	Id_Tipo_persona,id_origen,
									Tasa_DPF,Interes_DPF,Dias,Num_DPF,
									Fecha_DPF_final , Titular, Id_Esquema)
								VALUES
								(   @NumeroSocio, 'T' , @fechaTransaccion,
									@MontoTotalOperacion, @MontoTotalOperacion,@TipoPoliza ,
									@NumPoliza , @id_banca_folio , @fechaTransaccion,
									@IdPersona , @NumUsuarioBanca,41,
									105,@idTipoPersona,@idOrigenHape,
									@tasa,@tasa,@dias,@NumDPF,
									DATEADD(DAY,@dias,@fechaTransaccion),@Titular , 0
			 					)
								print 'DESPUES de INICIO INSERTAMOS EL MOVIMIENTO CORRESPONDIENTE A LA APERTURA'
						-- FIN INSERTAMOS  EL MOVIMIENTO CORRESPONDIENTE A LA APERTURA   ---

						-- INICIO INSERTAMOS EN CAPTURA EL MOVIMIENTO CORRESPONDIENTE A LA APERTURA DEL DPF
							INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,DIAS,NUM_DPF,
								TASA,INTERES,FECHA_DPF_final,
								Ccostos,Titular
								)
							VALUES(
									@IdPersona , 'T', @NumeroSocio,
									@NombreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs, 0,41,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@MontoTotalOperacion,
									@NumPoliza,@TipoPoliza,@id_banca_folio,
									@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@idOrigenHape,105,
									@dias,@NumDPF,@tasa,@tasa,DATEADD(DAY,@dias,@fechaTransaccion),
									@Ccostos,@Titular)
						-- FIN INSERTAMOS EN CAPTURA

						-- INICIO INSERTAMOS EN CAPTURA_lACP EL MOVIMIENTO CORRESPONDIENTE A LA APERTURA DEL DPF
						INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,DIAS,NUM_DPF,
								TASA,INTERES,FECHA_DPF_final,
								Ccostos,Titular
								)
							VALUES(
									@IdPersona , 'T', @NumeroSocio,
									@NombreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs, 0,41,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@MontoTotalOperacion,
									@NumPoliza,@TipoPoliza,@id_banca_folio,
									@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@idOrigenHape,105,
									@dias,@NumDPF,@tasa,@tasa,DATEADD(DAY,@dias,@fechaTransaccion),
									@Ccostos,@Titular)

						-- FIN INSERTAMOS EN CAPTURA_lACP EL MOVIMIENTO CORRESPONDIENTE A LA APERTURA DEL DPF
				
						--
						------------ INSERT A MOVIMIENTOS--------------------
								print 'antes de movimientos'
								INSERT INTO HAPE.dbo.MOVIMIENTOS 
									(Numero,Activo,Fecha_Mov,
									Monto,Saldo,Tipo_Poliza,
									Num_Poliza,	Folio,Fecha_Alta,
									Id_Persona,	Numusuario,Id_tipomov,
									id_mov,	Id_Tipo_persona,id_origen,Num_DPF)
								SELECT
									@NumeroSocio, 'T' , @fechaTransaccion,
									C.monto,C.saldoDespuesDeOperacion,@TipoPoliza ,
									@NumPoliza , @id_banca_folio , @fechaTransaccion,
									@IdPersona , @NumUsuarioBanca,C.idTipoMovRetiro,
									C.idCuenta,@idTipoPersona,@idOrigenHape,@NumDPF
			 					from #cuentasDPF C
								print 'despues de movimientos'

						------------  FIN DE INSERT MOVIMIENTOS --------------------------
						--
						--

						------- INSERT CAPTURA --------------------------------------------

								print 'ANTES de CAPTURA'
								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,NUM_DPF,
								Ccostos,Titular)
								SELECT
									@IdPersona , 'T', @NumeroSocio,
									@NombreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,0,C.idTipoMovRetiro,
									C.Cuenta,C.concepCaptura,@fechaTransaccion,C.monto,
									@NumPoliza,@TipoPoliza,@id_banca_folio,
									@idTipoPersona,C.DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@idOrigenHape,C.idCuenta , @NumDPF,
									@Ccostos , @Titular

								FROM #cuentasDPF C
								print 'despues de CAPTURA'

						------- FIN CAPTURA --------------------------------------------

						------- INSERT CAPTURA LACP --------------------------------------------

								print 'ANTES de CAPTURA LACP'
								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,NUM_DPF,
								Ccostos,Titular)
								SELECT
									@IdPersona , 'T', @NumeroSocio,
									@NombreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,0,C.idTipoMovRetiro,
									C.Cuenta,C.concepCaptura,@fechaTransaccion,C.monto,
									@NumPoliza,@TipoPoliza,@id_banca_folio,
									@idTipoPersona,C.DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@idOrigenHape,C.idCuenta , @NumDPF,
									@Ccostos , @Titular
								FROM #cuentasDPF C
								print 'despues de CAPTURA LACP'

						------- FIN CAPTURA LACP--------------------------------------------
				

				select 
				    @NombreS+' '+@ApellidoPaterno+' '+@ApellidoMaterno nombreCompleto, -- Nombre completo del socio
					@folio_bitacora as folioBitacora , -- Es el folio que se le debe notificar al usuario 
					@idInversion as folioOperacion, -- el folio interno de la operacion es el identity
					@NumDPF folioConstancia,  -- numero de plazo fijo que le corresponce 
					@id_banca_folio folioBanca, -- folio que se ve reflejado  en movimientos y en captura
					@MontoTotalOperacion montoInversion,
					@tasa tasaInversion,
					@dias PlazoInversion,
					@mensaje_bitacora DescripcionOperacion, --Apertura de la Inversion
					convert(varchar, @fechaVencimiento,103) fechaVencimiento,
					200 as estatus ,
					'OK' AS mensaje ,	
					convert(varchar, @fechaTransaccion, 103) fecha_transaccion,
				    convert(varchar, @fechaTransaccion, 108) hora_transaccion
				COMMIT TRAN 

			 END  --fin de SE INICIALIZA LA TRANZACION PERO PRIMERO SE VALIDA SI EXISTTE UNA TRANSACCION PADRE
		END
		ELSE
		BEGIN
			SELECT @error_message as mensaje, @estatus as estatus
		END
			  
		end try -- try principal
		begin catch -- catch principal

				   if @tran_scope = 1
						rollback tran @tran_name
					-- MANEJO DE ERRORES
					SELECT @error_message =error_message(),@estatus=0  
		
					select ERROR_LINE() ERRORLINE, @error_message as mensaje, @estatus as estatus
		
		end catch -- catch principal
END -- END SP
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_RECUPERAR_CONTRASENA]    Script Date: 11/03/2020 08:37:07 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		EDSON
-- Create date: 2018-04-03
-- Description:	VALIDA QUE LA RESPUESTA RECIBIDA SEA LA QUE TIENE REGISTRADA EL SOCIO
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_RECUPERAR_CONTRASENA]

@NUMERO varchar(20),
@respuesta_secreta varchar(max)
AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int , 
@numero_int int,
@respuesta_guardada varchar(255) 


select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NUMERO,1)
set @numero_int = CAST(@NUMERO as int )

IF(@mensaje_validacion is null)
BEGIN
	SELECT @respuesta_guardada = respuesta FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int
	IF (@respuesta_secreta COLLATE SQL_Latin1_General_CP1_CS_AS = @respuesta_guardada)
	BEGIN
		--CREA BIT�CORA DE RESPUESTA CORRECTA
		INSERT INTO TBL_BANCA_BITACORA_OPERACIONES (id_tipo_bitacora,numero_socio,fecha_alta)
			VALUES (99 , @numero_int , getdate())
		SELECT 200 AS estatus, 'La respuesta coincide correctamente' AS mensaje
		UPDATE TBL_BANCA_SOCIOS 
			SET 
				intentos_respuesta = 0
			WHERE 
				BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero
	END
	ELSE
	BEGIN
		DECLARE
			@limite_intentos_respuesta int= 3,
			@intentos_respuesta_socio int

		--CREA BIT�CORA DE RESPUESTA INCORRECTA
		INSERT INTO TBL_BANCA_BITACORA_OPERACIONES (id_tipo_bitacora,numero_socio,fecha_alta)
			VALUES (98 , @numero_int , getdate())

		--AUMENTO DE INTENTOS INCORRECTOS DE LA RESPUESTA A LA PREGUNTA SECRETA 
		UPDATE TBL_BANCA_SOCIOS SET intentos_respuesta = (ISNULL(intentos_respuesta,0) +1)
		WHERE
			BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int

		SELECT @intentos_respuesta_socio = ISNULL(intentos_respuesta,0) FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int
						
		-- VALIDAMOS SI CUMPLE CON 3 INTENTOS SE BLOQUEA LA CUENTA
		IF (@intentos_respuesta_socio) = @limite_intentos_respuesta
		BEGIN
			UPDATE TBL_BANCA_SOCIOS 
			SET 
				--CAT_BANCA_MOTIVOS_BLOQUEO --Bloqueo temporal respuesta incorrecta
				id_motivo_bloqueo =3 ,  
				viene_de_bloqueo = 1,
				fecha_motivo_bloqueo = GETDATE()
			WHERE 
				BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero

				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion =387
		END
		ELSE
			SELECT id_excepcion AS estatus , descripcion+' '+cast((@limite_intentos_respuesta-@intentos_respuesta_socio) as varchar)+ ' intentos.'  AS mensaje 
			FROM CAT_BANCA_EXCEPTIONS
			WHERE id_excepcion = 385
	END
	--BEGIN
	--	SELECT 308 AS estatus, 'La respuesta es incorrecta' AS mensaje
	--END
END
ELSE
	SELECT @estatus AS estatus , @mensaje_validacion mensaje


end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_VALIDA_CONTRASENA_TEMPORAL]    Script Date: 21/08/2019 04:51:47 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			MAXIMILIANO GONZALEZ BETANCOURT
UsuarioRed		GOBM391548
Fecha			20180417
Objetivo		VALIDA QUE LA CONTRSE�A TEMPORAL NO ESTE VENCIDA 
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_VALIDA_CONTRASENA_TEMPORAL]
	
		-- par�metros
		
		-- [aqu� van los par�metros]
    @numero_socio varchar(20),
	@contrasena_temporal VARCHAR(255)

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@descripcion_estatus varchar(255),
						@validacion varchar(255),
						@fecha_contrasena_temporal datetime,
						@cont_temporal varchar(255),
						@tieneVigencia bit,
						@tiene_bloqueo bit
			
			end -- inicio
			
			

				--VALIDACIONES	
				--select @validacion = dbo.FN_BANCA_VALIDA_SOCIO(@numero_socio,1)
				select @status = estatus, @validacion = msj from dbo.FN_BANCA_VALIDA_SOCIO (@numero_socio,0)
				IF @validacion is not null
				begin
					select @error_message = @validacion
					GOTO SALIR;
					--select @error_message as error_message, @status as status
				end
				
				DECLARE
				@fechaContrasena datetime

				SELECT @fecha_contrasena_temporal = fecha_contrasena_temporal , @fechaContrasena = fecha_alta_contrasena,
				@tiene_bloqueo = case when id_motivo_bloqueo = 1 then 0 else 1 end
				FROM TBL_BANCA_SOCIOS
				WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = CAST(@numero_socio AS int)
				
				if @fecha_contrasena_temporal is null 
					set @fecha_contrasena_temporal = '19000101'
				if @fechaContrasena is null
					set @fechaContrasena = '19000101'

				
				IF(@fecha_contrasena_temporal < @fechaContrasena)
				BEGIN
					SELECT id_excepcion AS estatus , descripcion as mensaje 
					FROM CAT_BANCA_EXCEPTIONS
					--WHERE id_excepcion = 332
					WHERE id_excepcion =318

					GOTO SALIR;
				END

				IF @tiene_bloqueo = 1
				BEGIN
					SELECT id_excepcion AS estatus , descripcion as mensaje 
					FROM CAT_BANCA_EXCEPTIONS
					WHERE id_excepcion = 302
					GOTO SALIR;
				END


				SELECT @tieneVigencia  = vigencia_contrasena_temporal FROM TBL_BANCA_SOCIOS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = CAST(@numero_socio as int)
				print 'Vigencia temporal'+cast(@tieneVigencia as varchar)
				IF @tieneVigencia = 1 
				BEGIN
					IF(DATEDIFF(DAY,@fecha_contrasena_temporal,GETDATE()) > 2)
					BEGIN
						SELECT id_excepcion AS estatus , descripcion as mensaje 
						FROM CAT_BANCA_EXCEPTIONS
						--WHERE id_excepcion =332
						WHERE id_excepcion =318
						GOTO SALIR;
					END
				END
				
				SELECT @cont_temporal = contrasena_temp FROM TBL_BANCA_SOCIOS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = CAST(@numero_socio as int)
				IF(@cont_temporal <> @contrasena_temporal)
				BEGIN
						SELECT id_excepcion AS estatus , descripcion as mensaje 
						FROM CAT_BANCA_EXCEPTIONS
						--WHERE id_excepcion =308
						WHERE id_excepcion =318
					GOTO SALIR;
				END
				ELSE
				BEGIN
					select @status = 200
					GOTO SALIR;
				END
				
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@status=0
		
			select @error_message as error_message, @status as status
		
		end catch -- catch principal
		
		SALIR:
		select @error_message as mensaje, @status as estatus
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_VALIDA_FOLIO_SOCIO]    Script Date: 20/11/2019 10:11:50 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER proc

	[dbo].[SP_BANCA_VALIDA_FOLIO_SOCIO]
	
		-- parametros
		@id_banca_folio int,
		@numero_socio int
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@fecha_actual datetime
						
					
			end -- inicio
			
			
			
			begin -- �mbito de la actualizaci�n
				
				if exists(select * from tbl_banca_transferencias_internas where id_banca_folio = @id_banca_folio and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio)
				or exists(select * from TBL_BANCA_TRANSFERENCIAS_EXTERNAS where id_banca_folio = @id_banca_folio and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio)
				or exists(select * from TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS where id_banca_folio = @id_banca_folio and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio)
				begin
					if not exists(select * from TBL_CALLCENTER_REPORTES_MULTIFOLIO where FOLIO_AUTORIZACION = @id_banca_folio and ID_SATISFACTORIO<>0)
					begin
						select @estatus = 1
					end
					else
					begin
						select @estatus = 0
					end					
				end
				else
				begin
					select @estatus = 0 
				end
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
		if @error_message<>''
		begin
			select	@estatus status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
		end
		else
		select @estatus estatus
					
		end -- reporte de estatus
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_VALIDA_NUMERO]    Script Date: 27/01/2020 04:22:10 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			MAXIMILIANO GONZALEZ BETANCOURT
UsuarioRed		GOBM391548
Fecha			20180417
Objetivo		VALIDA EL NUMERO DE SOCIO PROPORCIONADO Y REGRESA EL NOMBRE DEL SOCIO ENMASCARADO
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_VALIDA_NUMERO]
	
		-- par�metros
		
		-- [aqu� van los par�metros]
    @numero_socio varchar(20)

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@descripcion_estatus varchar(255),
						@validacion varchar(255),
						@numero bigint 
			
			end -- inicio
			
			

				--VALIDACIONES	
				--select @validacion = dbo.FN_BANCA_VALIDA_SOCIO(@numero_socio,1)
				select @status = estatus, @validacion = msj from dbo.FN_BANCA_VALIDA_SOCIO (@numero_socio,1)
				IF(@validacion is null )
					BEGIN
					select @numero = CAST(@numero_socio as bigint)
					select 200 estatus,
					ISNULL(Nombre_s,'')+' '+ISNULL(Apellido_Paterno,'')+' '+ISNULL(Apellido_Materno,'') Nombre_Completo,
					id_motivo_bloqueo,
					IA.ruta_imagen,
					s.viene_de_bloqueo
					from TBL_BANCA_SOCIOS S JOIN
					HAPE..PERSONA P  ON BANCA.dbo.FN_BANCA_DESCIFRAR(S.numero_socio) = P.Numero AND P.Id_Tipo_Persona = 1
					JOIN HAPE.[dbo].[CNBV_MNPIO_COL] COL ON P.Id_Colonia_CNBV = COL.Id_Colonia_CNBV
					LEFT JOIN CAT_BANCA_IMAGENES_ANTIPHISHING IA ON S.id_imagen_antiphishing = IA.id_imagen_antiphishing
					where Numero = @numero and Id_Tipo_Persona = 1
				END
				ELSE
				BEGIN
					/*SELECT @error_message = @validacion
					SELECT @status AS estatus, @error_message error_message */

					/* --------------Broken Authentication (Account Harvesting) ------------
					Devolver usuarios fake para no evidenciar los usuarios que no 
					existen o no esten registrados del lado de CMV para devolver siempre un 200*/
					declare 
						@imagen varchar(200),
						@nombre varchar(200)
					
					select @imagen = ruta_imagen from banca..CAT_BANCA_IMAGENES_ANTIPHISHING order by newid() 

					
					select @nombre = RIGHT(substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ',(abs(checksum(newid())) % 26)+1, 2) + '000',5) +' '+
						RIGHT(substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ',(abs(checksum(newid())) % 26)+1, 2) + '000',5)  +' '+
						RIGHT(substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ',(abs(checksum(newid())) % 26)+1, 2) + '000',5) 

					select top 1 200 estatus,
					@nombre Nombre_Completo,
					1 id_motivo_bloqueo,
					@imagen ruta_imagen,
					cast(0 as bit) viene_de_bloqueo

				END 


		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@status=100
		
			select @error_message as error_message, @status as status
		
		end catch -- catch principal
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_CALLCENTER_GENERA_CODIGO_CONTRASENA]    Script Date: 16/08/2019 01:19:23 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_CALLCENTER_GENERA_CODIGO_CONTRASENA]
@NUMERO AS VARCHAR(20),
@correo as varchar (1000)
AS
BEGIN

	declare
	@estatus int = 200 ,
	@mensaje varchar(1000),
	@numeroInt bigint,
	@id_tipo_bitacora INT = 79,
	@tipoOrigen INT = 6
	SET @numeroInt = CAST (@NUMERO AS BIGINT)

	IF NOT EXISTS (SELECT 1 FROM  TBL_BANCA_SOCIOS WHERE BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numeroInt)
	BEGIN
		 SELECT @estatus  = -1  , @mensaje  ='Usuario invalido | No existe registro en la tabla TBL_BANCA_SOCIOS'
	END
	
	IF NOT EXISTS (SELECT 1 FROM  HAPE..PERSONA WHERE Numero = @numeroInt and Mail  = @correo) 
	BEGIN
		 SELECT @estatus  = -1  , @mensaje  ='Usuario invalido | No existe el numero o el correo en persona'
	END


	IF (@estatus <> -1)
	BEGIN

	        CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));
			INSERT INTO #Bitacora
			EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero, @id_tipo_bitacora, @tipoOrigen

			   DECLARE
					@codigo bigint

			   select @codigo  = FLOOR(RAND(CHECKSUM(NEWID()))*(99999-10000+1)+10000)
			   UPDATE TBL_BANCA_SOCIOS 
			   SET 
					codigo_contrasena = @codigo,
					fecha_codigo_contrasena = GETDATE()
			   WHERE  BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numeroInt
			   
			   select 200 estatus , 'OK' mensaje , @codigo codigoContrasena 
			   return
		
	END

	SELECT @estatus as estatus , @mensaje  as 	mensaje

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_CALLCENTER_INSERTAR_FOLIO_MULTIFOLIO]    Script Date: 20/11/2019 10:51:06 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER proc

	[dbo].[SP_CALLCENTER_INSERTAR_FOLIO_MULTIFOLIO]
	
		-- parametros		
		@folioUNE int,
		@folioAutorizacion int,
		@numeroSocio int,
		@importeReclamo decimal,
		@idMedioMov int,
		@idTipoCuentaBanca int,
		@fechaTransacion datetime,
		@usuarioRegistra int 
		 
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @ESTATUS int = 0,
						@mensaje varchar(max) = '',	
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''

 
			end -- inicio
			
			
			
			begin -- �mbito de la actualizaci�n
			if(@folioAutorizacion<>0)
			begin
				if not exists (select 1 from tbl_banca_transferencias_internas where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) =@numeroSocio and id_banca_folio=@folioAutorizacion)
				and not exists (select 1 from TBL_BANCA_TRANSFERENCIAS_EXTERNAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) =@numeroSocio and id_banca_folio=@folioAutorizacion)
				and not exists (select 1 from TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) =@numeroSocio and id_banca_folio=@folioAutorizacion)
				begin
					select @error_message = 'No existe ningun folio para este socio.'
				end
				else
				if not exists
				(
					select 1 
					from 
						TBL_CALLCENTER_REPORTES_MULTIFOLIO mulifolio 
					inner join 
						tbl_banca_transferencias_internas transfInt 
					on 
					(
						mulifolio.FOLIO_AUTORIZACION = transfInt.id_banca_folio
					) 
					where 
						mulifolio.FOLIO_UNE = @folioUNE and transfInt.id_banca_folio = @folioAutorizacion
				)
				and
				not exists
				(
					select 1 
					from 
						TBL_CALLCENTER_REPORTES_MULTIFOLIO mulifolio 
					inner join 
						TBL_BANCA_TRANSFERENCIAS_EXTERNAS transfExt 
					on 
					(
						mulifolio.FOLIO_AUTORIZACION = transfExt.id_banca_folio
					) 
					where 
						mulifolio.FOLIO_UNE = @folioUNE and transfExt.id_banca_folio = @folioAutorizacion
				)

				and
				not exists
				(
					select 1 
					from 
						TBL_CALLCENTER_REPORTES_MULTIFOLIO mulifolio 
					inner join 
						TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS pagoServicio 
					on 
					(
						mulifolio.FOLIO_AUTORIZACION = pagoServicio.id_banca_folio
					) 
					where 
						mulifolio.FOLIO_UNE = @folioUNE and pagoServicio.id_banca_folio = @folioAutorizacion
				)

				begin
					SELECT @ESTATUS = 1
				
					insert into TBL_CALLCENTER_REPORTES_MULTIFOLIO(
						folio_une,
						folio_autorizacion,
						numero_socio,
						importe_reclamado,
						id_medio_movimiento,
						id_tipo_cuenta_banca,
						fecha_transacion,
						usuario_registra,
						fecha_alta_reporte,
						id_satisfactorio,
						id_cuenta_no_afectada_banca
					) values
					(
						@folioUNE,
						@folioAutorizacion,
						BANCA.dbo.FN_BANCA_CIFRAR(@numeroSocio),
						@importeReclamo,
						@idMedioMov,
						@idTipoCuentaBanca,
						@fechaTransacion,
						@usuarioRegistra,
						getdate(),
						null,
						null

					)	
				end
				else
				begin
					select @error_message = 'Este folio ya fue reportado anteriormente.'
				end
			end
			else
			begin
				SELECT @ESTATUS = 1
				
					insert into TBL_CALLCENTER_REPORTES_MULTIFOLIO (
					folio_une,
					folio_autorizacion,
					numero_socio,
					importe_reclamado,
					id_medio_movimiento,
					id_tipo_cuenta_banca,
					fecha_transacion,
					usuario_registra,
					fecha_alta_reporte,
					id_satisfactorio,
					id_cuenta_no_afectada_banca

					)
					values
					(
						@folioUNE,
						@folioAutorizacion,
						BANCA.dbo.FN_BANCA_CIFRAR(@numeroSocio),
						@importeReclamo,
						@idMedioMov,
						@idTipoCuentaBanca,
						@fechaTransacion,
						@usuarioRegistra,
						getdate(),
						null,
						null
					)
			end
			


			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@ESTATUS = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
		if @error_message<>''
		begin
			select	
				@ESTATUS AS ESTATUS,
				@error_procedure error_procedure,
				@error_line error_line,
				@error_severity error_severity,
				@error_message error_message
			
		end
		else
		select 
			@ESTATUS as ESTATUS,
			@mensaje mensaje
		
					
		end -- reporte de estatus
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_CALLCENTER_INSERTAR_REGISTRO_REPORTE]    Script Date: 16/08/2019 01:19:38 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER proc


	[dbo].[SP_CALLCENTER_INSERTAR_REGISTRO_REPORTE]
	
		-- par�metros
		@numero_Socio bigint,
		@ID_SUPUESTOS_REPORTE bigint,
		@detalles_llamada varchar(max),
		@numero_usuario varchar(20) = null,
		@id_tipo_bitacora int
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@id_banca_folio int,						
						@tipo_origen INT = 4,
						@id_reporte int = 0
			
			end -- inicio
			
			begin -- validaciones
			
				if not exists(SELECT * FROM HAPE.DBO.PERSONA WHERE NUMERO = @numero_Socio)
					raiserror('El socio ingresado no existe',11,0)

			end -- validaciones
			
					INSERT INTO TBL_CALLCENTER_REGISTRO_REPORTE 
					(
						numero_socio,						
						detalles_llamada,
						fecha_registro_reporte,
						ID_SUPUESTOS_REPORTE
					) values

					(
						@numero_Socio,						
						@detalles_llamada, 
						getdate(),
						@ID_SUPUESTOS_REPORTE
					)

					SELECT @id_reporte = MAX(id_registro_reporte) FROM TBL_CALLCENTER_REGISTRO_REPORTE

					set @id_reporte = @id_reporte +1
					--WHERE
					--	numero_socio = @numero_Socio 
					--	AND ID_SUPUESTOS_REPORTE = @ID_SUPUESTOS_REPORTE
						

					if @ID_SUPUESTOS_REPORTE in(2172, 2171)
					begin
						update BANCA..TBL_BANCA_SOCIOS set recuperar_contrasena = 1, id_motivo_bloqueo = 6 where BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio

						IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
						BEGIN
						INSERT INTO 
							TBL_BANCA_BITACORA_OPERACIONES 
							(
									id_tipo_bitacora,
									numero_socio,
									fecha_alta,
									id_origen_operacion,
									usuario
							)
							VALUES 
							(
								 31 ,
								 @numero_socio ,
								 getdate() ,
								 @tipo_origen,
								 @numero_usuario
							)

							INSERT INTO 
							TBL_BANCA_BITACORA_OPERACIONES 
							(
									id_tipo_bitacora,
									numero_socio,
									fecha_alta,
									id_origen_operacion,
									usuario
							)
							VALUES 
							(
								 79 ,
								 @numero_socio ,
								 getdate() ,
								 @tipo_origen,
								 @numero_usuario
							)

						END

					end					
					else
					begin
						update BANCA..TBL_BANCA_SOCIOS set recuperar_contrasena = 0 where BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numero_Socio

						IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
						BEGIN
						INSERT INTO 
							TBL_BANCA_BITACORA_OPERACIONES 
							(
									id_tipo_bitacora,
									numero_socio,
									fecha_alta,
									id_origen_operacion,
									usuario
							)
							VALUES 
							(
								 63 ,
								 @numero_socio ,
								 getdate() ,
								 @tipo_origen,
								 @numero_usuario
							)

						END

					end

		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
					
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,
					@id_reporte as id_reporte
		end -- reporte de status
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_CALLCENTER_OBTENER_FOLIO_A_EDITAR]    Script Date: 09/12/2019 01:51:57 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER proc

	[dbo].[SP_CALLCENTER_OBTENER_FOLIO_A_EDITAR]
	
		-- parametros		
		@IdIncidenciaReporte int
		 
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @ESTATUS int = 0,
						@mensaje varchar(max) = '',	
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@folioAutorizacion int = (select folio_autorizacion from TBL_CALLCENTER_REPORTES_MULTIFOLIO where ID_INCIDENCIA_REPORTE = @IdIncidenciaReporte)
 
						
					
			end -- inicio
			
			
			begin -- �mbito de la actualizaci�n
				if exists(select 1 from TBL_CALLCENTER_REPORTES_MULTIFOLIO where ID_INCIDENCIA_REPORTE = @IdIncidenciaReporte)
				begin
					SELECT @ESTATUS = 1
						
				end
				else
				begin
					select @error_message = 'El folio no existe'
				end			

			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@ESTATUS = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
		if @error_message<>''
		begin
			select	
				@ESTATUS AS ESTATUS,
				@error_procedure error_procedure,
				@error_line error_line,
				@error_severity error_severity,
				@error_message error_message
			
		end
		else
		if @folioAutorizacion <>0
		begin
			create table #TipoTransferenciaFolio(folio_autorizacion int,estatus int, mensaje varchar(max))
			insert into #TipoTransferenciaFolio (folio_autorizacion,estatus, mensaje)
			exec SP_BANCA_VALIDA_TIPO_TRANSFERENCIA_BANCA_FOLIO @folioAutorizacion

			select 
				@ESTATUS as ESTATUS,
				@mensaje mensaje,
				Reportes.ID_INCIDENCIA_REPORTE,
				Reportes.FOLIO_UNE,
				Reportes.FOLIO_AUTORIZACION,
				BANCA.dbo.FN_BANCA_DESCIFRAR(Reportes.NUMERO_SOCIO),
				Reportes.IMPORTE_RECLAMADO,
				Reportes.ID_MEDIO_MOVIMIENTO,
				MedioMov.descripcion_medio MEDIO_MOVIMIENTO,
				Reportes.ID_TIPO_CUENTA_BANCA,
				TipoCnta.DESCRIPCION TIPO_CUENTA_BANCA,
				Reportes.FECHA_TRANSACION,
				Reportes.USUARIO_REGISTRA,
				Reportes.FECHA_ALTA_REPORTE,
				tipoTransF.estatus as tipo_transferencia_folio
					
			from
				TBL_CALLCENTER_REPORTES_MULTIFOLIO Reportes 
			inner join
				CAT_CALLCENTER_MEDIO_MOVIMIENTO MedioMov
				on (Reportes.ID_MEDIO_MOVIMIENTO = MedioMov.ID_MEDIO_MOVIMIENTO)
			inner join 
				hape..CAT_UNE_TIPO_CUENTA_BANCA TipoCnta
				on (Reportes.ID_TIPO_CUENTA_BANCA = TipoCnta.ID_TIPO_CUENTA_BANCA)
			inner join 
				#TipoTransferenciaFolio tipoTransF
				on (tipoTransF.folio_autorizacion = Reportes.folio_autorizacion)
			where Reportes.ID_INCIDENCIA_REPORTE = @IdIncidenciaReporte
			drop table #TipoTransferenciaFolio
		end
		else
		begin
			select 
			@ESTATUS as ESTATUS,
			@mensaje mensaje,
			Reportes.ID_INCIDENCIA_REPORTE,
			Reportes.FOLIO_UNE,
			Reportes.FOLIO_AUTORIZACION,
			BANCA.dbo.FN_BANCA_DESCIFRAR(Reportes.NUMERO_SOCIO) NUMERO_SOCIO,
			Reportes.IMPORTE_RECLAMADO,
			Reportes.ID_MEDIO_MOVIMIENTO,
			MedioMov.descripcion_medio MEDIO_MOVIMIENTO,
			Reportes.ID_TIPO_CUENTA_BANCA,
			TipoCnta.DESCRIPCION TIPO_CUENTA_BANCA,
			Reportes.FECHA_TRANSACION,
			Reportes.USUARIO_REGISTRA,
			Reportes.FECHA_ALTA_REPORTE
					
		from
			TBL_CALLCENTER_REPORTES_MULTIFOLIO Reportes 
		inner join
			CAT_CALLCENTER_MEDIO_MOVIMIENTO MedioMov
			on (Reportes.ID_MEDIO_MOVIMIENTO = MedioMov.ID_MEDIO_MOVIMIENTO)
		inner join 
			hape..CAT_UNE_TIPO_CUENTA_BANCA TipoCnta
			on (Reportes.ID_TIPO_CUENTA_BANCA = TipoCnta.ID_TIPO_CUENTA_BANCA)
		where Reportes.ID_INCIDENCIA_REPORTE = @IdIncidenciaReporte
		end		
		end -- reporte de estatus
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_CALLCENTER_OBTENER_FOLIOS_PROCEDENTES_MULTIFOLIO]    Script Date: 12/11/2019 11:58:35 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER proc

	[dbo].[SP_CALLCENTER_OBTENER_FOLIOS_PROCEDENTES_MULTIFOLIO]
	
		-- parametros		
		@folioUNE int
		 
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @ESTATUS int = 0,
						@mensaje varchar(max) = '',	
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''

			end -- inicio
			
			
			
			begin -- �mbito de la actualizaci�n
			if not exists(select 1 from TBL_CALLCENTER_REPORTES_MULTIFOLIO where FOLIO_UNE = @folioUNE)
			begin
				SELECT @ESTATUS = 0
				select @error_message = 'El socio no cuenta con reportes en Call Center'
			end
			else
			begin
				SELECT @ESTATUS = 1
			end


			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@ESTATUS = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
		if @error_message<>''
		begin
			select	
				@ESTATUS AS ESTATUS,
				@error_procedure error_procedure,
				@error_line error_line,
				@error_severity error_severity,
				@error_message error_message
			
		end
		else
		select 
			@ESTATUS as ESTATUS,
			@mensaje mensaje,
			Reportes.ID_INCIDENCIA_REPORTE,
			Reportes.FOLIO_UNE,
			Reportes.FOLIO_AUTORIZACION,
			BANCA.dbo.FN_BANCA_DESCIFRAR(Reportes.NUMERO_SOCIO) NUMERO_SOCIO,
			Reportes.IMPORTE_RECLAMADO,
			Reportes.ID_MEDIO_MOVIMIENTO,
			MedioMov.descripcion_medio MEDIO_MOVIMIENTO,
			Reportes.ID_TIPO_CUENTA_BANCA,
			TipoCnta.DESCRIPCION TIPO_CUENTA_BANCA,
			Reportes.FECHA_TRANSACION,
			Reportes.USUARIO_REGISTRA,
			Reportes.FECHA_ALTA_REPORTE,
			Reportes.ID_SATISFACTORIO,
			Reportes.ID_CUENTA_NO_AFECTADA_BANCA,
			Reportes.DEPOSITADO
					
		from
			TBL_CALLCENTER_REPORTES_MULTIFOLIO Reportes 
		inner join
			CAT_CALLCENTER_MEDIO_MOVIMIENTO MedioMov
			on (Reportes.ID_MEDIO_MOVIMIENTO = MedioMov.ID_MEDIO_MOVIMIENTO)
		inner join 
			hape..CAT_UNE_TIPO_CUENTA_BANCA TipoCnta
			on (Reportes.ID_TIPO_CUENTA_BANCA = TipoCnta.ID_TIPO_CUENTA_BANCA)
		where 
			Reportes.FOLIO_UNE = @folioUNE
		and
			Reportes.ID_SATISFACTORIO = 2	
		and
			(Reportes.DEPOSITADO is null or Reportes.DEPOSITADO = 0)

					
		end -- reporte de estatus
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_CALLCENTER_VALIDA_BLOQUEO_USUARIO]    Script Date: 16/08/2019 01:20:29 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_CALLCENTER_VALIDA_BLOQUEO_USUARIO]
@NUMERO AS VARCHAR(20)
AS
BEGIN

	declare
	@estatus int = 200 ,
	@mensaje varchar(1000),
	@numeroInt bigint,
	@idSupuestoReporte bigint =0

	
	SET @numeroInt = CAST (@NUMERO AS BIGINT)

	IF NOT EXISTS (SELECT 1 FROM  TBL_BANCA_SOCIOS WHERE BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numeroInt)
	BEGIN
		 SELECT @estatus  = -1  , @mensaje  ='Usuario invalido | No existe registro en la tabla TBL_BANCA_SOCIOS'
	END
	
	
    IF  NOT EXISTS (select 1 from TBL_BANCA_SOCIOS where BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numeroInt AND recuperar_contrasena = 1)
	BEGIN
		 SELECT @estatus  = -1  , @mensaje  ='Usuario invalido | No existe registro en TBL_BANCA_SOCIOS activo para el proceso de recuperar contrase�a'	
	END
	

	IF EXISTS (select 1 from TBL_BANCA_SOCIOS where BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numeroInt AND 	DATEDIFF(day,fecha_alta_recuperar_contrasena,GETDATE()) > 3)
	BEGIN
		SELECT @estatus  = -1  , @mensaje  ='Usuario invalido | El timepo para reestablecer la contrase�a ha expirado'	
	END

	if(@estatus = 200 )
	BEGIN
				select @idSupuestoReporte = maxRegistro.ID_SUPUESTOS_REPORTE from 
				(select * from TBL_CALLCENTER_REGISTRO_REPORTE where id_registro_reporte = 
				(select max(id_registro_reporte) from BANCA..TBL_CALLCENTER_REGISTRO_REPORTE where numero_socio = @numeroInt)) 
				maxRegistro join hape..CAT_UNE_SUPUESTOS_REPORTE  reportes on maxRegistro.ID_SUPUESTOS_REPORTE = reportes.ID_SUPUESTOS_REPORTE
				where reportes.ACTIVO = 1 and maxRegistro.numero_socio = @numeroInt
		if @idSupuestoReporte > 0
		BEGIN
				SELECT @estatus  = 200  , @mensaje  ='ok'	
		END
		ELSE
		BEGIN 
			SELECT   @estatus= -1  , @mensaje  ='Usuario invalido | no tiene un reporte desde call center'
		END
    END
		
	SELECT @estatus as estatus , @mensaje  as 	mensaje  ,@idSupuestoReporte idSupuestoReporte
	

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_CALLCENTER_VALIDA_CODIGO_CONTRASENA]    Script Date: 16/08/2019 01:20:41 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_CALLCENTER_VALIDA_CODIGO_CONTRASENA]
@NUMERO AS VARCHAR(20),
@correo as varchar (1000),
@codioContrasena int 
AS
BEGIN

	declare
	@estatus int =200,
	@mensaje varchar(1000),
	@numeroInt bigint
	
	
	SET @numeroInt = CAST (@NUMERO AS BIGINT)

	IF NOT EXISTS (SELECT 1 FROM  TBL_BANCA_SOCIOS WHERE BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numeroInt)
	BEGIN
		 SELECT @estatus  = -1  , @mensaje  ='Usuario invalido | No existe registro en la tabla TBL_BANCA_SOCIOS'
	END
	
	IF NOT EXISTS (SELECT 1 FROM  HAPE..PERSONA WHERE Numero = @numeroInt and Mail  = @correo) 
	BEGIN
		 SELECT @estatus  = -1  , @mensaje  ='Usuario invalido | No existe el numero o el correo en persona'
	END
	if @estatus  <> -1
	BEGIN
		   DECLARE
				@FechaAltaCodigoContrasena datetime
		   
		   SELECT @FechaAltaCodigoContrasena = fecha_codigo_contrasena 
		   FROM  TBL_BANCA_SOCIOS
		   WHERE  BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numeroInt
		   IF (DATEDIFF(minute,@FechaAltaCodigoContrasena,GETDATE()) > 5 )
		   BEGIN
				SELECT   @estatus= -1  , @mensaje  ='Codigo invalido | el codigo ha expirado'
		   END
		   ELSE
		   BEGIN
				 IF EXISTS ( SELECT 1 FROM TBL_BANCA_SOCIOS WHERE BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numeroInt  AND codigo_contrasena  = @codioContrasena)
					SELECT   @estatus= 200  , @mensaje  ='OK'
				 ELSE
				 	SELECT   @estatus= -1  , @mensaje  ='Codigo invalido | el codigo no corresponde con ese numero de socio'
			END
				 
	END	   
	

	SELECT @estatus as estatus , @mensaje  as 	mensaje

END
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_CMV_INSERTAR_CUENTA_INTERBANCARIA]    Script Date: 18/03/2020 04:26:24 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER proc

	[dbo].[SP_CMV_INSERTAR_CUENTA_INTERBANCARIA]
	
		-- parametros		
		@numero_socio int
		 
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @STATUS int = 0,
						@mensaje varchar(max) = '',	
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',

						@fecha datetime = getdate(),
						@NoSTP varchar(3) = '646',
						@Zona varchar(3) ='180',
						@NoEmpresa varchar(4)='1811',
						@cuenta  varchar(17)
 
						
					
			end -- inicio
			
			
			
			begin -- �mbito de la actualizaci�n
				--if not exists (select 1 from TBL_BANCA_CUENTAS_INTERBANCARIAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio)
					--begin
					declare @ultimaCuentaSocio int
				select top 1 @ultimaCuentaSocio =id_cuenta from TBL_BANCA_CUENTAS_INTERBANCARIAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio order by fecha_alta desc
				
				/*if exists (select * from TBL_BANCA_CUENTAS_INTERBANCARIAS where id_cuenta = @ultimaCuentaSocio)
				begin
					select  @cuenta =(@NoSTP+@Zona+@NoEmpresa+REPLACE(STR((select id_cuenta from TBL_BANCA_CUENTAS_INTERBANCARIAS where id_cuenta = @ultimaCuentaSocio  ), 7), SPACE(1), '0') ) 
				end
				else
				begin*/
					select  @cuenta =(@NoSTP+@Zona+@NoEmpresa+REPLACE(STR((select ISNULL( max (id_cuenta) +1 , 1) from TBL_BANCA_CUENTAS_INTERBANCARIAS), 7), SPACE(1), '0') ) 
				--end
					--select  @cuenta =  (@NoSTP+@Zona+@NoEmpresa+REPLACE(STR((select id_cuenta from TBL_BANCA_CUENTAS_INTERBANCARIAS where numero_socio = @numero_socio), 7), SPACE(1), '0') )  
	
				IF OBJECT_ID('tempdb..#resultDigitoVerificador') IS NOT NULL
					begin
						DROP TABLE #resultDigitoVerificador
					end

				create table #resultDigitoVerificador
				(
					estatus int null ,
					mensaje varchar(1000) null,
					cuenta varchar(18) null,
					digito_verificador varchar(1) null,
					numero int null
				)

				insert into #resultDigitoVerificador (estatus,mensaje,cuenta,digito_verificador, numero)
				exec SP_BANCA_OBTENER_DIGITO_VERIFICADOR @numero_socio , @cuenta
						
				declare @curp varchar(max),
						@rfc varchar(max),
						@rfc_curp varchar(max),
						@id_estatus_cuenta int

				select @curp = curp, @rfc = Rfc from HAPE..PERSONA where numero = @numero_socio	and id_tipo_persona = 1	
				select @rfc_curp = rfc_curp, @id_estatus_cuenta = id_estatus_cuenta from TBL_BANCA_CUENTAS_INTERBANCARIAS where id_cuenta = @ultimaCuentaSocio
						
				/*if not exists(select 1 from TBL_BANCA_CUENTAS_INTERBANCARIAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio)
				begin*/

					insert into TBL_BANCA_CUENTAS_INTERBANCARIAS (numero_socio,id_mov,num_ptmo,clabe,fecha_alta,activo, rfc_curp, id_estatus_cuenta) 
					values 
					(
						BANCA.dbo.FN_BANCA_CIFRAR(@numero_socio),
						112,
						'',
						(select cuenta from #resultDigitoVerificador where numero = @numero_socio),
						getdate(),
						0,
						@rfc,
						1
					)
					select @STATUS = 1
					select @mensaje = 'Clabe interbancaria insertada con exito.'
							
				/*end
				else
				begin
					if (@rfc_curp = @rfc) --and (@id_estatus_cuenta = 4)
					begin
						update 
							TBL_BANCA_CUENTAS_INTERBANCARIAS 
						set 									
							activo = 0,
							estatus_STP = null,
							mensaje_STP = null,
							fecha_estatus_STP = null,
							rfc_curp = @curp,
							id_estatus_cuenta = 1
						where 
							BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio
					end

					else if (@rfc_curp <> @rfc) --and (@id_estatus_cuenta = 4)
					begin
						update 
							TBL_BANCA_CUENTAS_INTERBANCARIAS 
						set 									
							activo = 0,
							estatus_STP = null,
							mensaje_STP = null,
							fecha_estatus_STP = null,
							rfc_curp = @rfc,
							id_estatus_cuenta = 1
						where 
							BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio
					end

					select @STATUS = 1
					select @mensaje = 'Clabe actualizada con exito.'
				end	*/																

			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@STATUS = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
		if @error_message<>''
		begin
			select	
				@STATUS AS STATUS,
				@error_procedure error_procedure,
				@error_line error_line,
				@error_severity error_severity,
				@error_message error_message
			
		end
		else
		select 
			@STATUS as STATUS,
			@mensaje mensaje
					
		end -- reporte de estatus
		
	end -- procedimiento

go
	

	






	USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_GESTION_BENEFICIARIOS]    Script Date: 21/08/2019 04:14:38 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			VIC
UsuarioRed		REXV666480
Fecha			20180503
Objetivo		VALIDA EL NUMERO DE SOCIO PROPORCIONADO Y REGRESA EL NOMBRE DEL SOCIO ENMASCARADO
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/


ALTER proc	[dbo].[SP_BANCA_OBTENER_GESTION_BENEFICIARIOS]
	
		-- par�metros
		
		-- [aqu� van los par�metros]
    @numero_socio varchar(20)

as
DECLARE
@numero_int int 
SET @numero_int = CAST(@numero_socio AS INT)

CREATE TABLE #CUENTAS_BENEFICIARIOS (tipoCuenta varchar(50) null ,idCuenta int null , alias varchar(255) null , referencia varchar(255) null)

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@validacion varchar(255),
						@numero int 
			
			end -- inicio
				
				--VALIDACIONES	
				--select @validacion = dbo.FN_BANCA_VALIDA_SOCIO(@numero_socio,1)
				select @status = estatus, @validacion = msj from dbo.FN_BANCA_VALIDA_SOCIO (@numero_socio,1)
				IF(@validacion is null )
					BEGIN

					    -- CUENTAS EXTERNAS
						INSERT INTO #CUENTAS_BENEFICIARIOS (tipoCuenta, idCuenta , alias , referencia )
						SELECT 'EXTERNA', id_cuenta_externa ,alias ,titular_cuenta as nombreBeneficiario 
						from  TBL_BANCA_CUENTAS_EXTERNAS 
						where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)  = @numero_int
						
						-- CUENTAS INTERNAS
						INSERT INTO #CUENTAS_BENEFICIARIOS (tipoCuenta, idCuenta , alias , referencia )
						SELECT 'INTERNA', id_cuenta_interna ,alias , ISNULL(p.Nombre_s,' ')+' '+ISNULL(p.Apellido_Paterno,' ')+' '+ISNULL(P.Apellido_Materno,' ') as nombre_beneficiario
						from TBL_BANCA_CUENTAS_INTERNAS CI join hape..PERSONA P ON BANCA.dbo.FN_BANCA_DESCIFRAR(CI.numero_socio)= P.Numero and P.Id_Tipo_Persona = 1
						where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)  = @numero_int 

					END
				ELSE
				BEGIN
					SELECT @error_message = @validacion
					SELECT @status AS estatus, @error_message mensaje 
				END 
		end try -- try principal
		
		begin catch -- catch principal
		
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@status=1000
		
			select @error_message as mensaje, @status as estatus
		
		end catch -- catch principal


		select 'OK' as mensaje, '200' as estatus
		select * from #CUENTAS_BENEFICIARIOS

		DROP TABLE #CUENTAS_BENEFICIARIOS

	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_DATOS_FIRMA_CUENTAS_SOCIO]    Script Date: 18/03/2020 04:13:38 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER proc

	[dbo].[SP_BANCA_OBTENER_DATOS_FIRMA_CUENTAS_SOCIO]
	
		-- parametros
		@numeroSocio int
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = ''						

					
			end -- inicio
			
			/*					
			*/
			
			begin -- �mbito de la actualizaci�n
				
				declare @ultimaCuentaSocio int
				select top 1 @ultimaCuentaSocio =id_cuenta from TBL_BANCA_CUENTAS_INTERBANCARIAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio order by fecha_alta desc
				

				if exists(select 1 from TBL_BANCA_CUENTAS_INTERBANCARIAS where id_cuenta = @ultimaCuentaSocio)
				begin
					select @estatus = 200;
					select 
						p.nombre_s nombre, 
						p.apellido_paterno, 
						p.apellido_materno, 
						ci.clabe cuenta, 
						'CAJA_MORELIA' empresa,
						ci.rfc_curp,
						@estatus estatus	
					from 
						HAPE..persona p 
					inner join 
						banca..tbl_banca_cuentas_interbancarias ci 
					on
					(
						p.numero =  BANCA.dbo.FN_BANCA_DESCIFRAR(ci.numero_socio)
					) 
					where 
						p.numero = @numeroSocio
						and 
						p.id_tipo_persona = 1
						and
						ci.id_cuenta = @ultimaCuentaSocio
					

				end
				else
				begin
					select @error_message = 'El socio tiene su cuenta interbancaria inactiva o no cuenta con ella'
					select @estatus = -1
				end
							
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			/*else
			begin
				select
					 @estatus estatus, @mensaje as mensaje				
			end*/			
		end -- reporte de estatus
		
	end -- procedimiento
	grant exec on SP_BANCA_OBTENER_DATOS_FIRMA_CUENTAS_SOCIO to public

go
