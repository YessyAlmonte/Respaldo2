USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZAR_INTENTOS_PAGO_SERVICIOS_PENDIENTES]    Script Date: 24/01/2020 02:18:08 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20200129
Objetivo		se actualizan datos necesarios al dar de alta una cuenta para STP
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_BANCA_ACTUALIZAR_ESTATUS_CUENTA_STP_SOCIO' and xtype = 'p')
	drop proc SP_BANCA_ACTUALIZAR_ESTATUS_CUENTA_STP_SOCIO
go

create proc

	[dbo].[SP_BANCA_ACTUALIZAR_ESTATUS_CUENTA_STP_SOCIO]
	
		-- parametros
		@numeroSocio int,
		@estatusSTP int,
		@mensajeSTP varchar (max)
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = ''						

					
			end -- inicio
			
			/*					
			*/
			
			begin -- �mbito de la actualizaci�n
				
				if exists(select 1 from TBL_BANCA_CUENTAS_INTERBANCARIAS where numero_socio = @numeroSocio and (estatus_STP is null or estatus_STP <> 0))
				begin
					select @estatus = 200;
					select @mensaje = 'Datos actualizados correctamente.'
					update 
						TBL_BANCA_CUENTAS_INTERBANCARIAS 
					set 
						estatus_STP = @estatusSTP, 
						mensaje_STP= @mensajeSTP, 
						fecha_estatus_STP = GETDATE() 
					where
						numero_socio = @numeroSocio
				end
				else
				begin
					if exists(select 1 from TBL_BANCA_CUENTAS_INTERBANCARIAS where numero_socio = @numeroSocio and  estatus_STP = 0)					
						select @error_message = 'El socio ya  tiene su cuenta interbancaria activa.'					
					else
						select @error_message = 'El socio tiene su cuenta interbancaria inactiva o no cuenta con ella.'
					
					select @estatus = -1
				end
							
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			else
			begin
				select
					 @estatus estatus, @mensaje as mensaje				
			end			
		end -- reporte de estatus
		
	end -- procedimiento
	grant exec on SP_BANCA_ACTUALIZAR_ESTATUS_CUENTA_STP_SOCIO to public
	go

	USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZAR_INTENTOS_PAGO_SERVICIOS_PENDIENTES]    Script Date: 24/01/2020 02:18:08 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

if exists (select * from sysobjects where name like 'SP_BANCA_ACTUALIZAR_INTENTOS_PAGO_SERVICIOS_PENDIENTES' and xtype = 'p')
	drop proc SP_BANCA_ACTUALIZAR_INTENTOS_PAGO_SERVICIOS_PENDIENTES
go

create proc


	[dbo].[SP_BANCA_ACTUALIZAR_INTENTOS_PAGO_SERVICIOS_PENDIENTES]
	
		-- parametros
		@idPagoPendiente int,		
		@requestPagoRealizado varchar(max) = null, 
		@responsePagoRealizado varchar(max) =null,
		@idEstatusTransferencia int = null,
		@folioBanca int = null,
		@mensajeServicio varchar(max) = null,
		@mensajeIntentosError varchar(max) = null,
		@signed varchar(max) = null
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = '',
						@transIntentos int

					
			end -- inicio
			
			/*					
			*/
			
			begin -- �mbito de la actualizaci�n
				
				if exists(select 1 from TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES where id_pago_pendiente = @idPagoPendiente)
				begin
					if exists(select intentos from  TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES where id_pago_pendiente = @idPagoPendiente and intentos is null)
					begin
						update TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES set intentos = 0 where id_pago_pendiente = @idPagoPendiente 
					end

					select @transIntentos = intentos from TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES where id_pago_pendiente = @idPagoPendiente
					update TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES set intentos = (@transIntentos+1), mensaje_intentos_error = @mensajeIntentosError, id_estatus_transferencia = 3 where id_pago_pendiente = @idPagoPendiente
					update TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS set mensaje_error = @mensajeIntentosError where id_banca_folio = @folioBanca 

					if  @requestPagoRealizado <> '' or @requestPagoRealizado is not null
					begin
						update TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES set request_confirma_transaccion = @requestPagoRealizado where id_pago_pendiente = @idPagoPendiente	
						update TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS set request = @requestPagoRealizado where id_banca_folio = @folioBanca 
					end
					else
					if  @responsePagoRealizado <> '' or @responsePagoRealizado is not null
					begin
						update TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES set response_confirma_transaccion = @responsePagoRealizado where id_pago_pendiente = @idPagoPendiente	
						update TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS set response = @responsePagoRealizado where id_banca_folio = @folioBanca 
					end
					
					if  @signed <> '' or @signed is not null
					begin
						update TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES set signed = @signed where id_pago_pendiente = @idPagoPendiente	
						update TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS set signed = @signed where id_banca_folio = @folioBanca 
					end

					update TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS set id_estatus_transferencia = 3 where id_banca_folio = @folioBanca


					/*if(select intentos from TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES where id_pago_pendiente = @idPagoPendiente)>2
					begin
						update TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES						
					end*/

					select @estatus = 200;
					select @mensaje = 'Regisitro Actualizado';
				end
				else
				begin
					select @error_message = 'El id ingresado no existe';
					select @estatus = -1;
				end
				
							
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			else
			begin
				select
					 @estatus estatus, @mensaje as mensaje				
			end			
		end -- reporte de estatus
		
	end -- procedimiento
	grant exec on SP_BANCA_ACTUALIZAR_INTENTOS_PAGO_SERVICIOS_PENDIENTES to public
	go

	USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZAR_INTENTOS_PAGO_SERVICIOS_PENDIENTES]    Script Date: 24/01/2020 02:18:08 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20200130
Objetivo		sp que obtiene socios que aun no tienen la clabe activa en STP
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_BANCA_OBTENER_CUENTAS_A_ACTUALIZAR_CLABE_STP' and xtype = 'p')
	drop proc SP_BANCA_OBTENER_CUENTAS_A_ACTUALIZAR_CLABE_STP
go

create proc

	[dbo].[SP_BANCA_OBTENER_CUENTAS_A_ACTUALIZAR_CLABE_STP]
	
		-- parametros
		--@numeroSocio int,
		--@estatusSTP int,
		--@mensajeSTP varchar (max)
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = ''						

					
			end -- inicio
			
			/*					
			*/
			
			begin -- �mbito de la actualizaci�n
				/*
				if exists(select * from TBL_BANCA_CUENTAS_INTERBANCARIAS where estatus_STP <>0 or estatus_STP is null)
				begin
					select @estatus = 200;
					--select @mensaje = 'Datos actualizados correctamente.'
					
				end
				else
				begin					
					select @error_message = 'No hay socios para actualizar.'					
					select @estatus = -1
				end
					*/
					print ''		
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			else
			begin
				select
					@estatus estatus, 
					@mensaje as mensaje,
					* 
				from 
					TBL_BANCA_CUENTAS_INTERBANCARIAS 
				where 
					estatus_STP <>0 
					or 
					estatus_STP is null	
			end			
		end -- reporte de estatus
		
	end -- procedimiento
	grant exec on SP_BANCA_OBTENER_CUENTAS_A_ACTUALIZAR_CLABE_STP to public
	go

	USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZAR_INTENTOS_PAGO_SERVICIOS_PENDIENTES]    Script Date: 24/01/2020 02:18:08 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20200129
Objetivo		se obtienen datos necesarios para crear firma electronica que se inserta en la alta de cuentas STP
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_BANCA_OBTENER_DATOS_FIRMA_CUENTAS_SOCIO' and xtype = 'p')
	drop proc SP_BANCA_OBTENER_DATOS_FIRMA_CUENTAS_SOCIO
go

create proc

	[dbo].[SP_BANCA_OBTENER_DATOS_FIRMA_CUENTAS_SOCIO]
	
		-- parametros
		@numeroSocio int
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = ''						

					
			end -- inicio
			
			/*					
			*/
			
			begin -- �mbito de la actualizaci�n
				
				if exists(select 1 from TBL_BANCA_CUENTAS_INTERBANCARIAS where numero_socio = @numeroSocio)
				begin
					select @estatus = 200;
					select 
						p.nombre_s nombre, 
						p.apellido_paterno, 
						p.apellido_materno, 
						ci.clabe cuenta, 
						'CAJA_MORELIA' empresa,
						p.curp rfc_curp,
						@estatus estatus	
					from 
						HAPE..persona p 
					inner join 
						banca..tbl_banca_cuentas_interbancarias ci 
					on
					(
						p.numero = ci.numero_socio
					) 
					where 
						p.numero = @numeroSocio

					

				end
				else
				begin
					select @error_message = 'El socio tiene su cuenta interbancaria inactiva o no cuenta con ella'
					select @estatus = -1
				end
							
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			/*else
			begin
				select
					 @estatus estatus, @mensaje as mensaje				
			end*/			
		end -- reporte de estatus
		
	end -- procedimiento
	grant exec on SP_BANCA_OBTENER_DATOS_FIRMA_CUENTAS_SOCIO to public
	go


USE [BANCA]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20190830
Objetivo		Actuaizar las transferencias de pago de servicio que se han quedado pendientes.
Proyecto		Pago de servicios /Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_BANCA_ACTUALIZAR_PAGOS_SERVICIO_PENDIENTES' and xtype = 'p')
	drop proc SP_BANCA_ACTUALIZAR_PAGOS_SERVICIO_PENDIENTES
go

create proc

	[dbo].[SP_BANCA_ACTUALIZAR_PAGOS_SERVICIO_PENDIENTES]
	
		-- parametros		
		@idPagoPendiente int,
		@requestPagoRealizado varchar(max),
		@responsePagoRealizado varchar(max),
		@idEstatusTransferencia int,
		@folioBanca int,
		@mensajeServicio varchar(max) = null
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @ESTATUS int = 0,
						@mensaje varchar(max) = '',	
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@folioAutorizacion varchar(max) = '',						
						@pin varchar(max) = '',
						@monto decimal = 0

			end -- inicio
			
			begin -- �mbito de la actualizaci�n
				if exists(select 1 from TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES where ID_PAGO_PENDIENTE = @idPagoPendiente and SERVICIO_ATENDIDO = 0)
				begin
					--hay que validar de que el pa este pagado en 0
					SELECT @ESTATUS = 1

					select 
						@folioAutorizacion = folio_autorizacion, 
						@pin = pin,
						@monto = monto
						from TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS where id_banca_folio = @folioBanca

					if(@idEstatusTransferencia = 1 or @idEstatusTransferencia = 6)
					begin
						update 
							TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES 
						set 
							SERVICIO_ATENDIDO =1, 
							request_confirma_transaccion = @requestPagoRealizado,
							response_confirma_transaccion = @responsePagoRealizado,
							ID_ESTATUS_TRANSFERENCIA = 2
						where 
							folio_banca = @folioBanca


						update 
							TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS
						set 
							id_estatus_transferencia = 2
						where 
							id_banca_folio = @folioBanca
					end
					else
					begin
						update 
							TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS_PENDIENTES 
						set 
							SERVICIO_ATENDIDO =1, 
							request_confirma_transaccion = @requestPagoRealizado,
							response_confirma_transaccion = @responsePagoRealizado,
							ID_ESTATUS_TRANSFERENCIA = 3
						where 
							folio_banca = @folioBanca


						update 
							TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS
						set 
							id_estatus_transferencia = 3
						where 
							id_banca_folio = @folioBanca
					end

					exec SP_BANCA_ACTUALIZA_ESTATUS_PAGO_SERVICIO 
					@folioBanca, --liato
					@idEstatusTransferencia, --listo
					@folioAutorizacion, --pendiente de obtener
					@mensajeServicio, --
					@pin, --no es necesario?
					@monto, --pendiente de obtener
					@requestPagoRealizado, --listo
					@responsePagoRealizado, --listo
					@idEstatusTransferencia --listo

		--exec SP_BANCA_OBTENER_PAGOS_SERVICIO_PENDIENTES

				end

				else
				begin
					SELECT @ESTATUS = 0
					select @error_message = 'El pago no existe en la base de datos'
				end

			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@ESTATUS = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
		if @error_message<>''
		begin
			select	
				@ESTATUS AS ESTATUS,
				@error_procedure error_procedure,
				@error_line error_line,
				@error_severity error_severity,
				@error_message error_message
			
		end
		else
		SELECT @ESTATUS as ESTATUS, 'Registro actualizados con exito' as mensaje

					
		end -- reporte de estatus
		
	end -- procedimiento
	go

	grant exec on SP_BANCA_ACTUALIZAR_PAGOS_SERVICIO_PENDIENTES to public
	go

	USE BANCA
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_BANCA_ASIGNA_ID_TRANSFERENCIA_SPEI]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[SP_BANCA_ASIGNA_ID_TRANSFERENCIA_SPEI]
GO


/*
Autor			EDSON
Fecha			20190808
Objetivo		ASIGNA EL ID DE TRNASFERENCIA SPEI QUE ASIGNA EL PROVEEDOR DE SPEI(STP)
Proyecto		Banca en l�nea
*/

CREATE PROCEDURE [dbo].[SP_BANCA_ASIGNA_ID_TRANSFERENCIA_SPEI]
		@numero int,
		@id_transferencia bigint,
		@id_transferencia_spei bigint
as

	begin -- procedimiento
	
		--declare	@status int = 200
		
		begin try -- try principal
		
			begin -- inicio

				begin -- declaraciones
					declare	
						@status int=1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@message varchar(255) = 'Se registro correctamente la transferencia'
				end -- declaraciones

			

			end -- inicio

			begin --validaciones

				print 'paso 01'	
				---No existe la transferencia asociada al socio
				if not exists(select * from BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS  
				where id_transferencia = @id_transferencia and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero)
				begin
					select @status = 0,@message = 'No existe la transferencia asociada al socio.'
					raiserror (@message, 11, 0)
				end	

				
			end

			begin--Proceso

				print 'paso 02'
				--
				update BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS
				set
					id_transferencia_SPEI = @id_transferencia_spei
				where
					id_transferencia = @id_transferencia

			end

		end try -- try principal
		
		begin catch -- catch principal


			select	--@status=@status,
					--@status =error_state(),	
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end

			
		end catch -- catch principal
		
		begin -- reporte de status

			select	@status estatus,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message mensaje
				
		end -- reporte de status
		
	end -- procedimiento

GO

GRANT EXEC ON SP_BANCA_ASIGNA_ID_TRANSFERENCIA_SPEI TO PUBLIC 
GO


USE BANCA 
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_BANCA_ERROR_REGISTRA_ORDEN_SPEI]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].SP_BANCA_ERROR_REGISTRA_ORDEN_SPEI
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE SP_BANCA_ERROR_REGISTRA_ORDEN_SPEI        
@id_transferencia bigint,     -- id de la transferencia spei (id de la tabla transferencias_externas)
@clave_rastreo varchar(50),  -- clave de rastreo unico de la transferencia
@id_error_registra_orden int,--    La causa de devolucion de un SPEI del catalogo Catalog� de Devoluci�n
@mensaje_error varchar(max) = null	---Error general o causado al mmomento de consumir el ws de spei
AS
BEGIN
	begin try -- try principal
			begin -- declaraciones
							declare	
								@status int=0,
								@error_message varchar(255) = '',
								@error_line varchar(255) = '',
								@error_severity varchar(255) = '',
								@error_procedure varchar(255) = '',
								@message varchar(255) = 'Se registro correctamente la transferencia',
								@fecha_operacion datetime,
								@id_cuenta_externa bigint,
								@id_folio_banca bigint,
								@id_tipomov int,
								@id_mov int,
								@num_poliza int,
								@montoTransaccion money,
								@saldo_actual money,
								@id_persona bigint,
								@numero bigint,
								@numusuario int  = 1012,
								@id_estatus_transferencia  int = 2, --Operaci�n Realizada
								@id_tipo_bitacora int = 17, -- Transferencia  a Terceros
								@id_origen_transaccion int  = 7, -- SPEI
								---
								@tipo_poliza varchar(1) = 'M',
								@ccostos_origen varchar(10),
								@ccostos_compensacion varchar(10),
								@Num_cuentaContable_sucursal varchar(100),
								@nombre_origen varchar(100),
								@Ap_paterno_origen varchar(100),
								@Ap_materno_origen varchar(100),
								@id_tipo_persona int = 1

							declare	
								@tran_name varchar(32) = 'SP_BANCA_REGISTRA_TRANSFERENCIA_EXTERNA',
								@tran_count int = @@trancount,
								@tran_scope bit = 0
			end -- declaraciones



			begin --validaciones

				print 'paso 01 sin validaciones por el momento'	
				IF NOT  EXISTS (SELECT 1 FROM  TBL_BANCA_TRANSFERENCIAS_EXTERNAS WHERE id_transferencia = @id_transferencia and  
					clave_rastreo = @clave_rastreo)
				BEGIN
				     Select @message ='no existe folio origen y/o clave de rastreo' , @status = -1
					 raiserror (@message, 11, 0)
				END

				IF  EXISTS (SELECT 1 FROM  TBL_BANCA_TRANSFERENCIAS_EXTERNAS	WHERE  id_transferencia = @id_transferencia and
					clave_rastreo = @clave_rastreo and id_estatus_transferencia = 2)
				BEGIN
				     Select @message ='El folio origen y/o clave de rastreo se encuentra en: Operacion Realizada' , @status = -1
					 raiserror (@message, 11, 0)
				END

				IF  @id_error_registra_orden > 0 
				BEGIN
				     Select @message ='Por favor verifique la causa de devolucion ' , @status = -1
					 raiserror (@message, 11, 0)
				END
									
			 end --validaciones

			 begin--Proceso

				print 'paso 02'
				--extraer datos generales
				select @fecha_operacion = getdate() 


				--obtenemos los datos de la transferencia
				SELECT 
				@id_folio_banca = id_banca_folio,
				@numero = BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio),
				@clave_rastreo = clave_rastreo
				 FROM  TBL_BANCA_TRANSFERENCIAS_EXTERNAS
				WHERE  
					id_transferencia = @id_transferencia
					and clave_rastreo = @clave_rastreo
				
				---Se obtiene el numero de poliza de banca
				select @num_poliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
				select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'SPEI')
				and dia = DAY(GETDATE())

				---se obtienen los datos de la cuenta de retiro
				Select @id_tipomov = 1002
				Select @id_mov = ID_MOV FROM HAPE..TIPO_MOV WHERE ID_TIPOMOV = @id_tipomov

				--- se obtienen datos del socio 
				select 
					@id_persona = p.Id_Persona,
					@nombre_origen = p.Nombre_s,
					@Ap_paterno_origen = p.Apellido_Paterno,
					@Ap_materno_origen = p.Apellido_Materno,
					@ccostos_origen = s.Ccostos,
					@Num_cuentaContable_sucursal = nSuc.Num_Cuenta_Compensacion
				from HAPE..PERSONA p
				join HAPE.dbo.sucursales s
					on s.id_de_sucursal = p.id_de_sucursal
				join HAPE..NUM_SUCURSAL nSuc 
					on s.Num_Sucursal = nSuc.Num_Sucursal
				where Numero = @numero and Id_Tipo_Persona = @id_tipo_persona

				select @ccostos_compensacion = Ccostos from HAPE..NUM_SUCURSAL
				WHERE
					Num_Sucursal = 99 --'MEDIOS DE PAGO%'

			end


			 begin -- Transaccionalidad

				 print 'paso 03 (inicio de transacci�n)'
					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1

				-----------------------		proceso de transaccionalidad		--------------------

				
				---- UPDATE de transferencia
					PRINT ' ESTADO DE LA TRANSFERENCIA : CON ERROR'

					UPDATE TBL_BANCA_TRANSFERENCIAS_EXTERNAS 
					SET id_estatus_transferencia =3 , id_error_registra_orden = @id_error_registra_orden , 
					fecha_transferencia_realizada = @fecha_operacion,
					mensaje_error = @mensaje_error
					WHERE id_transferencia = @id_transferencia
					and clave_rastreo = @clave_rastreo

					SELECT @montoTransaccion =  isnull(Monto,0) FROM BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS 
					WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero AND id_transferencia = @id_transferencia 
					and clave_rastreo = @clave_rastreo
					
					SELECT @saldo_actual =  isnull(Saldo_Actual,0) FROM HAPE..EDO_DE_CUENTA WHERE Numero = @numero AND Id_mov = 112 and Id_Tipo_persona = 1
					print '@clave_rastreo: ' +cast(@clave_rastreo as varchar)
					print '@numero: ' +cast(@numero as varchar)
					print '@montoTransaccion: ' +cast(@montoTransaccion as varchar)
					print '@saldo_actual: ' +cast(@saldo_actual as varchar)

					/*========================================	ACTUALIZACI�N DE MOVIMIENTOS ==============================
				     ======================================================================================================*/

					INSERT	HAPE..MOVIMIENTOS
						(
						NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
						NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
						ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR, id_origen
						)
					VALUES(
						@numero, 'T', @fecha_operacion, @montoTransaccion,round((@saldo_actual + @montoTransaccion),2), 'D',
						@num_poliza, @id_folio_banca, GETDATE(), @id_persona, @numusuario,
						@id_tipomov, @id_mov, 1, 'S', @id_origen_transaccion)


					/*========================================	ACTUALIZACI�N DE ESTADO DE CUENTA	================================
					==============================================================================================================*/
					UPDATE	HAPE..EDO_DE_CUENTA
					SET	SALDO_ACTUAL = round(@saldo_actual + @montoTransaccion,2),
						FECHA = @fecha_operacion
					WHERE	
						numero = @numero
						and id_mov = @id_mov
						AND Id_Tipo_persona = 1
			
					
					begin -- preparar captura
						
						--SPEI
						insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = '14100611940000'
						--sucursal del socio
						insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = @Num_cuentaContable_sucursal
						--Medios de pago		
						insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%MEDIOS%'
								and cc.Num_cuenta like '1410100099%'
						--movimiento de cuenta
						insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = tm.descripcion,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%DEBITO%'
								and cc.Num_cuenta like '2160000000%'
						
					end	-- preparar captura

					begin -- preparar captura_lacp
						
						--SPEI
						insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = '14100611940000'
						--sucursal del socio
						insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = @Num_cuentaContable_sucursal
						--Medios de pago		
						insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%MEDIOS%'
								and cc.Num_cuenta like '1410100099%'
						--movimiento de cuenta
						insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = tm.descripcion,
								fecha_mov = @fecha_operacion,
								monto = abs(@montoTransaccion),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_transaccion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%DEBITO%'
								and cc.Num_cuenta like '2160000000%'
						
					end	-- preparar CAPTURA_lacp
						

				
			end   -- Transaccionalidad

			begin -- commit
				
					if @tran_count = 0
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							print 'paso 3.1 (commit de transacci�n)'
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				select @status = 200,@error_message ='Se registro correctamente la transferencia'
			end -- commit
			




	end try -- try principal
	
	begin catch -- catch principal

		select @status=coalesce(@status, 0)

		select	--@status=@status,
				--@status =error_state(),	
				@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
				@error_line = error_line(),
				@error_message = error_message(),
				@error_severity =
					case error_severity()
						when 11 then 'Error en validaci�n'
						when 12 then 'Error en consulta'
						when 13 then 'Error en actualizaci�n'
						else 'Error general'
					end

				--select @status=coalesce(@status, 0)
		-- revertir transacci�n si es necesario
		if @tran_scope = 1
		begin
			rollback tran @tran_name
		end
		
	end catch -- catch principal
	
		select @status as estatus ,@error_message  as mensaje
END
GO

GRANT EXEC ON SP_BANCA_ERROR_REGISTRA_ORDEN_SPEI TO PUBLIC
GO

use banca
go

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_BANCA_OBTENER_COMPROBANTES_PAGO_CEP]') AND type in (N'P', N'PC'))
	--DROP PROCEDURE [dbo].[SP_BANCA_OBTENER_COMPROBANTE_PAGO_CEP]
	DROP PROCEDURE [dbo].[SP_BANCA_OBTENER_COMPROBANTES_PAGO_CEP]
GO


-- =============================================
-- Author:		EDSON
-- Create date: 2018-09-10
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[SP_BANCA_OBTENER_COMPROBANTES_PAGO_CEP]
	@NumeroSocio varchar(20),
	@TipoBusquedaComprobante int,
	@FechaInicio datetime,
	@FechaFin datetime,
	@TipoOrigen int,
	@TipoTransferenciaExterna int, -- Enviadas = 2, Devueltas = 3
	@folioAutorizacion bigint
AS
BEGIN

begin try

	-- declaraciones
	declare	@status int = 1,
	@error_message VARCHAR(500),
	@mensaje_validacion varchar(500),
	@estatus int , 
	@numero_int int


	select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NumeroSocio,1)
	Set @numero_int = CAST(@NumeroSocio as int )
	
	IF OBJECT_ID('tempdb..#comprobantesPagoSPEI') IS NOT NULL
		DROP TABLE #comprobantesPagoSPEI


	CREATE TABLE #comprobantesPagoSPEI (
		IdTransferenciaCMV bigint,
		BancoReceptor varchar(100),
		BancoEmisor varchar(100),
		ClableSPEIRetiro varchar(100),
		ClaveRastreo varchar(40),
		ConceptoPago varchar(500) ,
		FechaAutorizacion varchar(20) null,
		FechaProgramada varchar(20) null,
		FechaTransacion varchar(20) null,
		HoraProgramada varchar(20) null ,
		HoraTransaccion varchar(20) null ,
		IdComprantePagoCEP bigint, 
		NombreEmisor varchar(250) null ,
		Plazo int,
		Programado bit, 
		ReferenciaNumerica varchar(20) null,
		TitularCuenta varchar(200) null
	)


	if(@mensaje_validacion is null)
	BEGIN
		
		INSERT INTO #comprobantesPagoSPEI 
		(
			IdTransferenciaCMV,
			BancoReceptor,
			BancoEmisor,
			ClableSPEIRetiro,
			ClaveRastreo,
			ConceptoPago ,
			FechaAutorizacion ,
			FechaProgramada ,
			FechaTransacion ,
			HoraProgramada ,
			HoraTransaccion ,
			IdComprantePagoCEP, 
			NombreEmisor ,
			Plazo,
			Programado, 
			ReferenciaNumerica,
			TitularCuenta
		)
		SELECT
			trans.id_transferencia,
			banco.institucion,
			'CAJA MORELIA',
			trans.clabe_spei_origen,
			trans.clave_rastreo,
			trans.concepto_pago,
			CONVERT(varchar,trans.fecha_alta_transferencia,103) FechaAutorizacion,
			CONVERT(varchar,trans.fecha_programada,103) FechaProgramada,
			CONVERT(varchar,trans.fecha_transferencia_realizada,103) FechaTransacion,
			CONVERT(varchar,trans.fecha_programada,108) HoraProgramada,
			CONVERT(varchar,trans.fecha_transferencia_realizada,108) HoraTransaccion,
			trans.id_banca_folio IdComprantePagoCEP,
			isnull(PS.Nombre_s,' ')+' '+ISNULL(PS.Apellido_Paterno,'')+' '+ISNULL(PS.Apellido_Materno,' ') NombreEmisor,
			1, --plazo
			trans.programado,
			trans.referencia_numerica,
			cuenExt.titular_cuenta
		FROM
			BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS trans
		INNER JOIN
			BANCA..TBL_BANCA_CUENTAS_EXTERNAS cuenExt on trans.id_cuenta_externa = cuenExt.id_cuenta_externa
		INNER JOIN
			BANCA..CAT_BANCA_BANCOS_CLABES_SPEI banco on cuenExt.id_banco = banco.id_banco_spei
		INNER JOIN
			HAPE..PERSONA PS ON PS.numero =BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio)  AND PS.ID_TIPO_PERSONA = 1 
		WHERE
			BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio) = @numero_int AND
			trans.id_estatus_transferencia = @TipoTransferenciaExterna and
			
			/* @idTipoBusqueda = 1 BUSCAR POR DIA*/
			1=(CASE WHEN @TipoBusquedaComprobante = 1 AND  Convert (varchar , trans.fecha_alta_transferencia, 112) = convert(varchar,@fechaInicio ,112) THEN  1  ELSE 0 END  ) OR
			/* @idTipoBusqueda = 2 BUSCAR POR RANGO DE DIAS*/
			1=(CASE WHEN @TipoBusquedaComprobante = 2 AND 
				( (convert (varchar , trans.fecha_alta_transferencia, 112) >= convert(varchar,@fechaInicio ,112) AND convert (varchar , trans.fecha_alta_transferencia, 112) <= convert(varchar,@fechaFin ,112)) 
				OR (convert (varchar , trans.fecha_transferencia_realizada, 112) >= convert(varchar,@fechaInicio ,112) AND convert (varchar , trans.fecha_transferencia_realizada, 112) <= convert(varchar,@fechaFin ,112)) ) THEN 1 ELSE 0 END ) OR
			/* @idTipoBusqueda = 3 BUSCAR POR PERIODO*/
			1=(CASE WHEN @TipoBusquedaComprobante = 3 AND  MONTH(trans.fecha_alta_transferencia) = MONTH(@fechaInicio) AND YEAR (trans.fecha_alta_transferencia) = YEAR(@fechaFin ) THEN 1 ELSE 0 END ) OR
			/* @idTipoBusqueda = 4 BUSCAR POR MOVIMIENTO*/
			1=(CASE WHEN @TipoBusquedaComprobante = 4 AND id_banca_folio = @folioAutorizacion THEN 1 ELSE 0 END )

			select 'OK' as mensaje, '200' as estatus
			select * from  #comprobantesPagoSPEI ORDER BY IdTransferenciaCMV
		
			
	END
	ELSE
		select @mensaje_validacion as mensaje, @estatus as estatus

end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 	 		
end catch
	
END
GO

GRANT EXEC ON SP_BANCA_OBTENER_COMPROBANTES_PAGO_CEP TO PUBLIC 
GO

use banca
go

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_BANCA_OBTENER_COMPROBANTES_PAGO_SERVICIOS]') AND type in (N'P', N'PC'))
	--DROP PROCEDURE [dbo].[SP_BANCA_OBTENER_COMPROBANTES_PAGO_SERVICIOS]
	DROP PROCEDURE [dbo].[SP_BANCA_OBTENER_COMPROBANTES_PAGO_SERVICIOS]
GO


-- =============================================
-- Author:		EDSON
-- Create date: 2019-10-03
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[SP_BANCA_OBTENER_COMPROBANTES_PAGO_SERVICIOS]
	@NumeroSocio varchar(20),
	@TipoBusquedaComprobante int,
	@FechaInicio datetime,
	@FechaFin datetime,
	@TipoOrigen int,
	@folioAutorizacion bigint
AS
BEGIN

begin try

	-- declaraciones
	declare	@status int = 1,
	@error_message VARCHAR(500),
	@mensaje_validacion varchar(500),
	@estatus int , 
	@numero_int int,
	@cuenta_spei_socio varchar(20)


	select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NumeroSocio,1)
	Set @numero_int = CAST(@NumeroSocio as int )
	
	IF OBJECT_ID('tempdb..#comprobantesPagoServicio') IS NOT NULL
		DROP TABLE #comprobantesPagoServicio


	CREATE TABLE #comprobantesPagoServicio (
		IdComprobante bigint,
		ClabeRetiro varchar(100),
		HoraTransaccion varchar(20) null ,
		FechaTransacion varchar(20) null,
		HoraAutorizacion varchar(20) null ,
		FechaAutorizacion varchar(20) null,
		Importe money,
		Comision money,
		Referencia varchar(30) null,
		FolioAutorizacion varchar(50),
		NumAutorizacion varchar(50) ,
		DescripcionProducto varchar(250) null ,
		IdProducto int null,
		IdTipoFront int null,
		DescripcionServicio varchar(250) null ,
		IdServicio int null,
		Telefono varchar(50),
		EstadoTransferencia varchar(100) null ,
		EstatusTransferencia int null,
		leyendaProducto varchar(5000)
	)


	if(@mensaje_validacion is null)
	BEGIN
		
		INSERT INTO #comprobantesPagoServicio 
		(
			IdComprobante ,
			ClabeRetiro ,
			HoraTransaccion ,
			FechaTransacion ,
			HoraAutorizacion ,
			FechaAutorizacion ,
			Importe ,
			Comision ,
			Referencia ,
			FolioAutorizacion ,
			NumAutorizacion,
			DescripcionProducto ,
			IdProducto ,
			IdTipoFront,
			DescripcionServicio ,
			IdServicio ,
			Telefono ,
			EstadoTransferencia ,
			EstatusTransferencia,
			leyendaProducto
		)
		SELECT
			trans.id_pago_servicios,
			trans.clabe_corresponsalias_retiro,
			CONVERT(varchar,trans.fecha_pago_realizado,108) HoraTransaccion,
			CONVERT(varchar,trans.fecha_pago_realizado,103) FechaTransacion,
			CONVERT(varchar,trans.fecha_alta_pago,108) HoraTransaccion,
			CONVERT(varchar,trans.fecha_alta_pago,103) FechaTransacion,
			trans.monto,
			prod.comision_cmv,
			trans.numero_referencia,
			trans.id_banca_folio, --FolioAutorizacion ?
			trans.folio_autorizacion,
			prod.descripcion, --DescripcionProducto
			prod.id_producto,
			prod.tipo_front,
			serv.descripcion,  --DescripcionServicio
			serv.id_servicios_pago,
			trans.telefono,
			estatus.descripcion, --EstadoTransferencia
			trans.id_estatus_transferencia,
			prod.leyenda
		FROM
			BANCA..TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS trans
		INNER JOIN
			BANCA..CAT_BANCA_SERVICIOS_PAGO serv on serv.id_servicios_pago = trans.id_servicio
		INNER JOIN
			BANCA..CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO prod on prod.id_producto = trans.id_producto
		INNER JOIN
			HAPE..PERSONA PS ON PS.numero =BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio)  AND PS.ID_TIPO_PERSONA = 1 
		INNER JOIN
			BANCA..CAT_BANCA_ESTATUS_TRANSFERENCIAS estatus on trans.id_estatus_transferencia = estatus.id_estatus_transferencia
		WHERE
			BANCA.dbo.FN_BANCA_DESCIFRAR(trans.numero_socio) = @numero_int AND
			/* @idTipoBusqueda = 1 BUSCAR POR DIA*/
			1=(CASE WHEN @TipoBusquedaComprobante = 1 AND  Convert (varchar , trans.fecha_alta_pago, 112) = convert(varchar,@fechaInicio ,112) THEN  1  ELSE 0 END  ) OR
			/* @idTipoBusqueda = 2 BUSCAR POR RANGO DE DIAS*/
			1=(CASE WHEN @TipoBusquedaComprobante = 2 AND 
				( (convert (varchar , trans.fecha_alta_pago, 112) >= convert(varchar,@fechaInicio ,112) AND convert (varchar , trans.fecha_alta_pago, 112) <= convert(varchar,@fechaFin ,112)) 
				OR (convert (varchar , trans.fecha_alta_pago, 112) >= convert(varchar,@fechaInicio ,112) AND convert (varchar , trans.fecha_alta_pago, 112) <= convert(varchar,@fechaFin ,112)) ) THEN 1 ELSE 0 END ) OR
			/* @idTipoBusqueda = 3 BUSCAR POR PERIODO*/
			1=(CASE WHEN @TipoBusquedaComprobante = 3 AND  MONTH(trans.fecha_alta_pago) = MONTH(@fechaInicio) AND YEAR (trans.fecha_alta_pago) = YEAR(@fechaFin ) THEN 1 ELSE 0 END ) OR
			/* @idTipoBusqueda = 4 BUSCAR POR MOVIMIENTO*/
			1=(CASE WHEN @TipoBusquedaComprobante = 4 AND trans.id_banca_folio = @folioAutorizacion THEN 1 ELSE 0 END )

			select 'OK' as mensaje, '200' as estatus
			select * from  #comprobantesPagoServicio ORDER BY IdComprobante
			
	END
	ELSE
		select @mensaje_validacion as mensaje, @estatus as estatus

end try
begin catch
	select 1000 as estatus , ERROR_MESSAGE() AS mensaje 	 		
end catch
	
END
GO

GRANT EXEC ON SP_BANCA_OBTENER_COMPROBANTES_PAGO_SERVICIOS TO PUBLIC 
GO

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZAR_INTENTOS_PAGO_SERVICIOS_PENDIENTES]    Script Date: 24/01/2020 02:18:08 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20200130
Objetivo		sp que obtiene socios que aun no tienen la clabe activa en STP
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_BANCA_OBTENER_CUENTAS_A_ACTUALIZAR_CLABE_STP' and xtype = 'p')
	drop proc SP_BANCA_OBTENER_CUENTAS_A_ACTUALIZAR_CLABE_STP
go

create proc

	[dbo].[SP_BANCA_OBTENER_CUENTAS_A_ACTUALIZAR_CLABE_STP]
	
		-- parametros
		--@numeroSocio int,
		--@estatusSTP int,
		--@mensajeSTP varchar (max)
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = ''						

					
			end -- inicio
			
			/*					
			*/
			
			begin -- �mbito de la actualizaci�n
				/*
				if exists(select * from TBL_BANCA_CUENTAS_INTERBANCARIAS where estatus_STP <>0 or estatus_STP is null)
				begin
					select @estatus = 200;
					--select @mensaje = 'Datos actualizados correctamente.'
					
				end
				else
				begin					
					select @error_message = 'No hay socios para actualizar.'					
					select @estatus = -1
				end
					*/
					print ''		
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			else
			begin
				select
					@estatus estatus, 
					@mensaje as mensaje,
					id_cuenta,
					BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) numero_socio,
					id_mov,
					num_ptmo,
					clabe,
					fecha_alta,
					activo,
					estatus_STP,
					mensaje_STP,
					fecha_estatus_STP,
					rfc_curp,
					id_estatus_cuenta 
				from 
					TBL_BANCA_CUENTAS_INTERBANCARIAS 
				where
					--activo =0
					--and
					id_estatus_cuenta = 1
			end			
		end -- reporte de estatus
		
	end -- procedimiento
	grant exec on SP_BANCA_OBTENER_CUENTAS_A_ACTUALIZAR_CLABE_STP to public
	go

		USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_CUENTAS_A_ELIMINAR_CLABE_STP]    Script Date: 24/01/2020 02:18:08 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20200130
Objetivo		sp que obtiene socios que a los cuales se les dara de baja la clabe en STP
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_BANCA_OBTENER_CUENTAS_A_ELIMINAR_CLABE_STP' and xtype = 'p')
	drop proc SP_BANCA_OBTENER_CUENTAS_A_ELIMINAR_CLABE_STP
go

create proc

	[dbo].[SP_BANCA_OBTENER_CUENTAS_A_ELIMINAR_CLABE_STP]
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = ''						

					
			end -- inicio
			
			/*					
			*/
			
			begin -- �mbito de la actualizaci�n				
					print ''		
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			else
			begin
				select
					@estatus estatus, 
					@mensaje as mensaje,
					id_cuenta,
					BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) numero_socio,
					id_mov,
					num_ptmo,
					clabe,
					fecha_alta,
					activo,
					estatus_STP,
					mensaje_STP,
					fecha_estatus_STP,
					rfc_curp,
					id_estatus_cuenta 
				from 
					TBL_BANCA_CUENTAS_INTERBANCARIAS 
				where
					--activo =1
					--and
					id_estatus_cuenta = 3
			end			
		end -- reporte de estatus
		
	end -- procedimiento
	grant exec on SP_BANCA_OBTENER_CUENTAS_A_ELIMINAR_CLABE_STP to public
	go

	USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZAR_INTENTOS_PAGO_SERVICIOS_PENDIENTES]    Script Date: 24/01/2020 02:18:08 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20200129
Objetivo		se obtienen datos necesarios para crear firma electronica que se inserta en la alta de cuentas STP
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_BANCA_OBTENER_DATOS_FIRMA_CUENTAS_SOCIO' and xtype = 'p')
	drop proc SP_BANCA_OBTENER_DATOS_FIRMA_CUENTAS_SOCIO
go

create proc

	[dbo].[SP_BANCA_OBTENER_DATOS_FIRMA_CUENTAS_SOCIO]
	
		-- parametros
		@numeroSocio int
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = ''						

					
			end -- inicio
			
			/*					
			*/
			
			begin -- �mbito de la actualizaci�n
				
				if exists(select 1 from TBL_BANCA_CUENTAS_INTERBANCARIAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio)
				begin
					select @estatus = 200;
					select 
						p.nombre_s nombre, 
						p.apellido_paterno, 
						p.apellido_materno, 
						ci.clabe cuenta, 
						'CAJA_MORELIA' empresa,
						ci.rfc_curp,
						@estatus estatus	
					from 
						HAPE..persona p 
					inner join 
						banca..tbl_banca_cuentas_interbancarias ci 
					on
					(
						p.numero = BANCA.dbo.FN_BANCA_DESCIFRAR(ci.numero_socio)
					) 
					where 
						p.numero = @numeroSocio
						and 
						p.id_tipo_persona = 1

					

				end
				else
				begin
					select @error_message = 'El socio tiene su cuenta interbancaria inactiva o no cuenta con ella'
					select @estatus = -1
				end
							
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			/*else
			begin
				select
					 @estatus estatus, @mensaje as mensaje				
			end*/			
		end -- reporte de estatus
		
	end -- procedimiento
	grant exec on SP_BANCA_OBTENER_DATOS_FIRMA_CUENTAS_SOCIO to public
	go

	USE [BANCA]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20190902
Objetivo		Obtiene todos los socios que estan o fueron registrados en banca
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_BANCA_OBTENER_SOCIO_REGISTRADO' and xtype = 'p')
	drop proc SP_BANCA_OBTENER_SOCIO_REGISTRADO
go

create proc

	[dbo].[SP_BANCA_OBTENER_SOCIO_REGISTRADO]
	
		-- parametros		
		@numero_socio int
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@fecha datetime = getdate() 						
					
			end -- inicio
			
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
		if @error_message<>''
		begin
			select	
				@estatus estatus,
				@error_procedure error_procedure,
				@error_line error_line,
				@error_severity error_severity,
				@error_message error_message
			
		end
		else
		select 
			id_socio,
			id_persona,
			BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) numero_socio,
			contrasena,
			fecha_alta_contrasena,
			contrasena_temp,
			fecha_contrasena_temporal,
			fecha_alta_persona,
			id_estatus_banca,
			id_pregunta_secreta,
			respuesta,
			id_motivo_bloqueo,
			banca_activa,
			fecha_motivo_bloqueo,
			id_imagen_antiphishing,
			vigencia_contrasena_temporal,
			viene_de_bloqueo,
			id_ultima_sesion,
			fecha_ultima_sesion,
			intentos_sesion,
			intentos_respuesta,
			fecha_alta_solicitud,
			fecha_de_desbloqueo,
			contrasena_estado_cuenta,
			descripcion_bloqueo,
			descripcion_cancelacion,
			fecha_bloqueo_OTP,
			fecha_cancelacion,
			codigo_contrasena,
			fecha_codigo_contrasena,
			recuperar_contrasena,
			fecha_alta_recuperar_contrasena
		from 
			TBL_BANCA_SOCIOS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio
					
		end -- reporte de estatus
		
	end -- procedimiento
	go

	grant exec on SP_BANCA_OBTENER_SOCIO_REGISTRADO to public
	go

	USE [BANCA]
go
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_BANCA_PAGO_SERVICIO_CONFIRMA_TRANSACCION]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].SP_BANCA_PAGO_SERVICIO_CONFIRMA_TRANSACCION
GO
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZA_ESTATUS_PAGO_SERVICIO]    Script Date: 23/01/2020 11:51:41 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Mar Mej�a Murillo
UsuarioRed		memm373565
Fecha			20180607
Objetivo		Actualiza el estatus de una transferencia interna dado su id_transferencia
Proyecto		Banca en l�nea
Ticket			______

*/

create proc
	[dbo].[SP_BANCA_PAGO_SERVICIO_CONFIRMA_TRANSACCION]
	
		@idBancaFolio			bigint,
		@codigo		int,
		@folioAutorizacion		varchar(100),
		@mensaje		varchar(5000),
		@pin		varchar(10) = null,
		@monto money,
		@request varchar(max),
		@response varchar(max),
		@signed varchar(max),
		@tipoOrigen int = null,
		@estatusTransferencia int = null
		
as

	begin -- procedimiento

		begin try -- try principal

			begin -- inicio

				begin -- declaraciones

					declare @status int = 200,
							@error_message varchar(255) = '',
							@error_line varchar(255) = '',
							@error_severity varchar(255) = '',
							@error_procedure varchar(255) = '',
							
								
							@tran_name varchar(32) = 'SP_BANCA_ACTUALIZA_ESTATUS_PAGO_SERVICIO',
							@tran_count int = @@trancount,
							@tran_scope bit = 0,
							@fecha_operacion datetime,
			
							@id_tipo_bitacora int,
							@id_origen_transaccion int = 3 --
					-- declare de variables
							declare
								@id_mov int,
								@num_poliza int,
								@saldo_actual money,
								@id_persona bigint,
								@numero bigint,
								@id_tipo_persona int = 1,

								--- son muy necesarias para la poliza
								@ccostos_compensacion varchar(20),
								@ccostos_socio varchar(20),
								@NumPoliza bigint  = 0000,
								@TipoPoliza varchar(1) ='D',
								@NumUsuarioBanca int = 1012 ,
								@IdPersona int,
								@IdTipoMov int,							
								@CuentaContable varchar(14) =	'',
								@CuentaContableSucursal varchar(14) =	'',
								@NomreS varchar(50),
								@ApellidoPaterno varchar(50),
								@ApellidoMaterno varchar(50),
								@TotalMovs int = 1,
								@ConceptoCaptura  varchar(1000)='',
								@DebeHaber varchar(1)='H',
								@fechaTransaccion datetime =  getDate(),
								@idServicio int,
								@idProducto int 


					select @fecha_operacion = coalesce(@fecha_operacion, getdate())

				end -- declaraciones

			end -- inicio

			begin -- �mbito de la actualizaci�n

					select @estatusTransferencia = case when @codigo =1 then  2 else 3  end
					select @status = case when @codigo =1 then  200 else 410 /*Pago de servicio rechazado*/  end
					
					select @numero = BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio),  @id_mov = cc.id_mov from tbl_banca_transferencias_pago_servicios S
					join hape..tbl_corresponsalias_cuentas CC on S.clabe_corresponsalias_retiro = CC.cuenta
					where s.id_banca_folio = @idBancaFolio

					

					select @saldo_actual = Saldo_Actual 
					from 
						HAPE..EDO_DE_CUENTA 
					where 
						Numero = @numero 
						and Id_mov = @id_mov 
						and Id_Tipo_persona = @id_tipo_persona

					select 
						@idServicio = id_servicio, @idProducto = id_producto 
					from 
						BANCA..TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS
					where
						id_banca_folio= @idBancaFolio and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero

					update	TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS
					set		
		
						fecha_pago_realizado = @fecha_operacion,
						folio_autorizacion =  @folioAutorizacion,
						pin =@pin,
						mensaje_error = @mensaje,
						codigo = @codigo,
						id_estatus_transferencia = @estatusTransferencia,
						request =@request,
						response  = @response,
						signed = @signed
					where	
						id_banca_folio = @idBancaFolio
					
					if @codigo =  1 or @codigo = 6 -- si el ws regresa 1 de operacion realizada exitosamente o 6 operacion confirma exitosamente
					begin 
						select @id_tipo_bitacora = 21 --Pago de servicios

						--select * from CAT_BANCA_TIPOS_BITACORA

						insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
						values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @tipoOrigen)

						---bitacora para indicar de donde se realizo el retiro de dinero
						select @id_tipo_bitacora = case
							when @id_mov = 100 then 52
							when @id_mov = 103 then 51
							when @id_mov = 112 then 53
						end

						insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
						values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @tipoOrigen)

						-- VALIDAMOS SI EL PAGO DE SERVICIO NECESITA CODIGO DE ACTIVACION						
						if exists(SELECT id_cat_tipo_servicio FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO WHERE id_producto = @IdProducto and id_servicios_pago = @idServicio  and id_cat_tipo_servicio in (10,11))
						BEGIN
							select @id_tipo_bitacora = 97 --Pago de Servicio + Codigo de Activacion
							insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @tipoOrigen)
						END

						--select * from CAT_BANCA_TIPOS_BITACORA ORDER BY id_tipo_bitacora DESC
					end

					-- proceso para  realizar la devolucion del monto del pago de serivicio cuando este es rechazado
					 if @codigo not in(1,6)  
					 begin
						begin-- se obtienes los datos para el proceso de devolucion  y la poliza
											  						

								--insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
								--values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @id_origen_transaccion)
										
								---Se obtiene el numero de poliza de banca
								select @num_poliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
								select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'BANCA ELECTRONICA')
								and dia = DAY(GETDATE())

								-- OBTENEMOS EL ID_TIPOMOV
								if @id_mov = 100   -- 1184	Dep�sito a AHORRO CMV por operaci�n rechazada de Pago de Servicio
									SET @IdTipoMov  = 1184
								else if @id_mov = 103-- 1187	Dep�sito a INVERDIN�MICA CMV por operaci�n rechazada de Pago de Servicio
									SET @IdTipoMov  = 1187
								else if @id_mov = 112 -- 1190	Dep�sito a DEBITO CMV por operaci�n rechazada de Pago de Servicio
									SET @IdTipoMov  = 1190

									--- se obtienen datos del socio 
								select 
									@id_persona = p.Id_Persona,
									@NomreS = p.Nombre_s,
									@ApellidoPaterno = p.Apellido_Paterno,
									@ApellidoMaterno = p.Apellido_Materno,
									@ccostos_socio = s.Ccostos,
									@CuentaContableSucursal = nSuc.Num_Cuenta_Compensacion
								from HAPE..PERSONA p
								join HAPE.dbo.sucursales s
									on s.id_de_sucursal = p.id_de_sucursal
								join HAPE..NUM_SUCURSAL nSuc 
									on s.Num_Sucursal = nSuc.Num_Sucursal
								where Numero = @numero and Id_Tipo_Persona = @id_tipo_persona

								select @ccostos_compensacion = Ccostos from HAPE..NUM_SUCURSAL
								WHERE
									Num_Sucursal = 99 --'MEDIOS DE PAGO%'
						end


						begin -- Transaccionalidad

								print 'paso 03 (inicio de transacci�n)'
								if @tran_count = 0
									begin tran @tran_name
								else
									save tran @tran_name
				
								select @tran_scope = 1	
									/*========================================	ACTUALIZACI�N DE MOVIMIENTOS ==============================
									======================================================================================================*/

								INSERT	HAPE..MOVIMIENTOS
									(
									NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
									NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
									ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR, id_origen
									)
								VALUES(
									@numero, 'T', @fecha_operacion, @monto,round((@saldo_actual + @monto),2), 'D',
									@num_poliza, @idBancaFolio, GETDATE(), @id_persona, @NumUsuarioBanca,
									@IdTipoMov, @id_mov, 1, 'S', @id_origen_transaccion)


								/*========================================	ACTUALIZACI�N DE ESTADO DE CUENTA	================================
								==============================================================================================================*/
								UPDATE	HAPE..EDO_DE_CUENTA
								SET	SALDO_ACTUAL = round(@saldo_actual + @monto,2),
									FECHA = @fecha_operacion
								WHERE	
									numero = @numero
									and id_mov = @id_mov
									AND Id_Tipo_persona = 1

							    print 'antes de CAPTURA'
								begin
								--******	INSERCI�N DEL MOVIMIENTO		******
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov
								select @CuentaContable =  Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like 
								case 
									when @id_mov = 100 then '2120000000%'
									when @id_mov = 103 then '2110000000%'
									when @id_mov = 112 then '2160000000%'
								end
								select @DebeHaber = 'H'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCION SERVICIO DE BANCA	(DEBE - CARGO)	******
								--obtenemos la descripcion del  movimiento
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

								-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
								SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
								WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

								select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCION SERVICIO DE BANCA	(HABER - ABONO)	******
								--obtenemos la descripcion del  movimiento
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

								-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
								SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
								WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

								select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
								select @DebeHaber = 'H'
								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCI�N MEDIOS DE PAGO	CARGO	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14101000990000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCI�N SUCURSAL DEL SOCIO HABER	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta = @CuentaContableSucursal
								select @DebeHaber = 'H'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_compensacion
								)

								--******	INSERCI�N GESTO PAGO CARGO	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select 
									@CuentaContable =  Num_cuenta, 
									@ConceptoCaptura = 'GESTO PAGO'--Concepto (Se forzo a que diga gesto pago, ya que al darse de alta en productivo no la registraron como debia ser)
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14100611950000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_compensacion
								)

								print 'despues de CAPTURA'
								end
								--- FIN DEL INSERT DE CAPTURA  ---

								--============================ INSERT CAPTURA_lacp ============================
								print 'antes de CAPTURA_lacp'
								begin
								--******	INSERCI�N DEL MOVIMIENTO		******
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov
								select @CuentaContable =  Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like 
								case 
									when @id_mov = 100 then '2120000000%'
									when @id_mov = 103 then '2110000000%'
									when @id_mov = 112 then '2160000000%'
								end
								select @DebeHaber = 'H'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCION SERVICIO DE BANCA	(DEBE - CARGO)	******
								--obtenemos la descripcion del  movimiento
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

								-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
								SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
								WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

								select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCION SERVICIO DE BANCA	(HABER - ABONO)	******
								--obtenemos la descripcion del  movimiento
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

								-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
								SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
								WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

								select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
								select @DebeHaber = 'H'
								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCI�N MEDIOS DE PAGO	CARGO	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14101000990000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCI�N SUCURSAL DEL SOCIO HABER	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta = @CuentaContableSucursal
								select @DebeHaber = 'H'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_compensacion
								)

								--******	INSERCI�N GESTO PAGO CARGO	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select 
									@CuentaContable =  Num_cuenta, 
									@ConceptoCaptura = 'GESTO PAGO'--Concepto (Se forzo a que diga gesto pago, ya que al darse de alta en productivo no la registraron como debia ser)
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14100611950000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@NumPoliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_compensacion
								)

								print 'despues de CAPTURA_lacp'
								end

								--============================ INSERT DE BITACORA ============================
								select @id_tipo_bitacora = 93 --Pago de servicio rechazado

								--select * from CAT_BANCA_TIPOS_BITACORA

								insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
								values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @id_origen_transaccion)

						end

						commit tran
					 end

			end -- �mbito de la actualizaci�n

		end try -- try principal

		begin catch -- catch principal

				select @status=coalesce(@status, 0)

				select	--@status=@status,
						--@status =error_state(),	
						@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
						@error_line = error_line(),
						@error_message = error_message(),
						@error_severity =
							case error_severity()
								when 11 then 'Error en validaci�n'
								when 12 then 'Error en consulta'
								when 13 then 'Error en actualizaci�n'
								else 'Error general'
							end

						--select @status=coalesce(@status, 0)
				-- revertir transacci�n si es necesario
				if @tran_scope = 1
				begin
					rollback tran @tran_name
				end

		end catch -- catch principal

		begin -- reporte de estatus
					select 
						@status as estatus , 
						mensaje_error as mensaje,
						CONVERT(varchar , @fecha_operacion ,103) as fecha_transaccion, 
						FORMAT(CONVERT(datetime, @fecha_operacion),'hh:mm:ss tt') as hora_transaccion,
						* 
					from 
						TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS where id_banca_folio = @idBancaFolio

		end -- reporte de estatus

	end -- procedimiento

go

grant exec on [SP_BANCA_PAGO_SERVICIO_CONFIRMA_TRANSACCION] to public
go

USE BANCA 
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_BANCA_RECIBE_TRANSFERENCIA_EXTERNA]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].SP_BANCA_RECIBE_TRANSFERENCIA_EXTERNA
GO

-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE SP_BANCA_RECIBE_TRANSFERENCIA_EXTERNA 

         
@Id bigint,     -- Folio de la operaci�n en Enlace Financiero
@FechaOperacion varchar(8), -- El formato de la fecha ser� AAAAMMDD.
@InstitucionOrdenante int,  --  La clave de la instituci�n que genera el pago.    
@InstitucionBeneficiara int, --  La clave de la instituci�n a la que va dirigida el pago     
@ClaveRastreo varchar(50),--    La clave de rastreo asociada a la orden de pago.    
@Monto decimal (19,2), -- El monto de la orden de pago         
@NombreOrdenante  varchar(120), --El nombre del ordenante asociado a �sta orden de 
@TipoCuentaOrdenante int , --La clave del tipo de cuenta del ordenante seg�n el Catalog� Tipo Cuenta      
@CuentaOrdenante varchar (20), -- La cuenta del ordenante          
@RfcCurpOrdenante varchar(18) null,         
@NombreBenificiario varchar(40),-- El nombre del beneficiario de �sta orden de pago.   
@TipoCuentaBeneficiario int,    -- El tipo de la cuenta del beneficiario. Catalog� Tipo Cuenta     
@CuentaBeneficiario varchar(20), -- La cuenta del beneficiario     
@RfcCurpBeneficiario varchar(18) null,          
@ConceptoPago varchar(40),
@RefereneciaNumerica bigint,          
@Empresa varchar(15) = 'CAJA_MORELIA',
@id_origen_operacion  int =  7, -- hape..CAT_CMV_ORIGEN_TRANSACCION SPEI
@id_tipo_persona_origen int = 1
AS
BEGIN
	begin try -- try principal
			begin -- declaraciones
							declare	
								@status int=0,
								@error_message varchar(255) = '',
								@error_line varchar(255) = '',
								@error_severity varchar(255) = '',
								@error_procedure varchar(255) = '',
								@message varchar(255) = 'Se registro correctamente la transferencia',
								@fecha_operacion datetime,
								@id_cuenta_externa bigint,
								@id_transferencia bigint,
								@id_folio_banca bigint,
								@clave_rastreo varchar(500),
								@id_tipomov int,
								@id_mov int,
								@num_poliza int,
								@saldo_cuenta_deposito money,
								@id_persona bigint,
								@numusuario int  = 1012,
								@numero bigint,
								@id_estatus_transferencia  int = 2, --Operaci�n Realizada
								@id_tipo_bitacora int =  92 -- SPEI RECIBIDO
								--@fecha_programada datetime

						declare--variables para la poliza
								@tipo_poliza varchar(1) = 'M',
								@ccostos_origen varchar(10),
								@ccostos_compensacion varchar(10),
								@Num_cuentaContable_sucursal varchar(100),
								@nombre_origen varchar(100),
								@Ap_paterno_origen varchar(100),
								@Ap_materno_origen varchar(100)


							declare	
								@tran_name varchar(32) = 'SP_BANCA_REGISTRA_TRANSFERENCIA_EXTERNA',
								@tran_count int = @@trancount,
								@tran_scope bit = 0
			end -- declaraciones



			begin --validaciones

						print 'paso 01'	
						---No existe la cuenta externa destino asociada al socio
						IF not exists(select * from BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS  where clabe = @CuentaBeneficiario)
						BEGIN
							select @status = 0,@message = 'No existe la cuenta destino, asociada al socio.'
							raiserror (@message, 11, 0)
						END
						ELSE
						BEGIN
							select @numero = BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) from BANCA..TBL_BANCA_CUENTAS_INTERBANCARIAS  where clabe = @CuentaBeneficiario
						END


						IF EXISTS(select * from HAPE..PERSONA where numero = @numero AND Id_Tipo_Persona = 1 and 
						(Bloqueado_Cobranza = 'A' OR Bloqueado_Exclusion = 'A'))
						BEGIN
						      select @status = 0,@message = 'El socio se encuentra bloquado.'
							  raiserror (@message, 11, 0)
						END 

						-- se valida: si realizan una operacion que ya fue ejecutada solo se notifique que ya fue ejecutada 
						IF EXISTS (select 1 from TBL_BANCA_TRANSFERENCIAS_EXTERNAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero AND id_transferencia_SPEI  = @Id and id_estatus_transferencia = 2)
						BEGIN
							  print 'SPEI ya ejecutado solo notificamos'
						      select @status = 200,@message = 'Se registro correctamente la transferencia'
							  raiserror (@message, 11, 0)
						END 

						IF  @TipoCuentaOrdenante not  in (3,10,40)  or @TipoCuentaBeneficiario not  in (3,10,40)
						BEGIN
						      select @status = 0,@message = 'Tipo Cuenta incorrecta'
							  raiserror (@message, 11, 0)
						END

						IF 0 = (select case when @TipoCuentaOrdenante= 3  and  len(@CuentaOrdenante)= 16 then 1 --si esta TC  16 digitos
									        when @TipoCuentaOrdenante= 10 and  len(@CuentaOrdenante)= 10 then 1 --si esta celular  10 digitos
											when @TipoCuentaOrdenante= 40 and  len(@CuentaOrdenante)= 18 then 1 --si esta CLABE  18 digitos
								       else 0 end )
						BEGIN
						      select @status = 0,@message = 'Cuenta ordenante no corresponde al tipo de cuenta '
							  raiserror (@message, 11, 0)
						END 

						IF 0 = (select case when @TipoCuentaBeneficiario= 3  and  len(@CuentaBeneficiario)= 16 then 1 --si esta TC  16 digitos
									        when @TipoCuentaBeneficiario= 10 and  len(@CuentaBeneficiario)= 10 then 1 --si esta celular  10 digitos
											when @TipoCuentaBeneficiario= 40 and  len(@CuentaBeneficiario)= 18 then 1 --si esta CLABE  18 digitos
								       else 0 end )
						BEGIN
						      select @status = 0,@message = 'Cuenta beneficiario no corresponde al tipo de cuenta '
							  raiserror (@message, 11, 0)
						END 
																	

				
			 end --validaciones

			 begin--Proceso

				print 'paso 02'
				--extraer datos generales
				select @fecha_operacion = getdate() 


				---Se obtiene el numero de poliza de banca
				select @num_poliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
				select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'SPEI')
				and dia = DAY(GETDATE())

				---se obtienen los datos de la cuenta de deposito
				Select @id_tipomov = 1166 --Dep�sito a DEBITO CMV por Transferencia SPEI
				Select @id_mov = ID_MOV FROM HAPE..TIPO_MOV WHERE ID_TIPOMOV = @id_tipomov
				
				select @saldo_cuenta_deposito = Saldo_Actual 
				from  hape..edo_de_cuenta 
				where numero = @numero and id_tipo_persona = 1 and id_mov = 112


				----se obtienen los datos del socio
				select 
					@id_persona = p.Id_Persona,
					@nombre_origen = p.Nombre_s,
					@Ap_paterno_origen = p.Apellido_Paterno,
					@Ap_materno_origen = p.Apellido_Materno,
					@ccostos_origen = s.Ccostos,
					@Num_cuentaContable_sucursal = nSuc.Num_Cuenta_Compensacion
				from HAPE..PERSONA p
				join HAPE.dbo.sucursales s
					on s.id_de_sucursal = p.id_de_sucursal
				join HAPE..NUM_SUCURSAL nSuc 
					on s.Num_Sucursal = nSuc.Num_Sucursal
				where Numero = @numero and Id_Tipo_Persona = @id_tipo_persona_origen

				select @ccostos_compensacion = Ccostos from HAPE..NUM_SUCURSAL
				WHERE
					Num_Sucursal = 99 --'MEDIOS DE PAGO%'

			end


			 begin -- Transaccionalidad

				 print 'paso 03 (inicio de transacci�n)'
					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1

				-----------------------		proceso de transaccionalidad		--------------------

				---- Generacion de folio de banca
				insert into BANCA..TBL_BANCA_FOLIOS (numero_socio,fecha_alta)
				values (@numero,@fecha_operacion)

				select @id_folio_banca = MAX (id_banca_folio) from BANCA..TBL_BANCA_FOLIOS where
				numero_socio = @numero
				--=========== end Generacion de folio de banca

				-- insert en bitacora
					insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
					values(@id_folio_banca, @id_tipo_bitacora, @numero, getdate(), @id_origen_operacion)
				-- fin de  inser bitacora

				---- Generacion insercion de transferencia
				insert into BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS_RECIBIDAS
					(id_enlace_financiero,fecha_operacion,institucion_ordenante,institucion_beneficiaria,
					clave_rastreo,monto,nombre_ordenante,tipo_cuenta_ordenante,cuenta_ordenante,rfc_curp_ordenante,
					nombre_beneficiario,tipo_cuenta_beneficiario,cuenta_beneficiario,rfc_curp_beneficiario,concepto_pago,
					referencia_numerica,empresa,
					fecha_transferencia_realizada,id_estatus_transferencia,numero_socio,id_banca_folio)
				VALUES
					(@Id,@FechaOperacion,@InstitucionOrdenante,@InstitucionBeneficiara,
					@ClaveRastreo,@Monto,@NombreOrdenante,@TipoCuentaOrdenante,@CuentaOrdenante,@RfcCurpOrdenante,
					@NombreBenificiario,@TipoCuentaBeneficiario,@CuentaBeneficiario,@RfcCurpBeneficiario,@ConceptoPago,
					@RefereneciaNumerica,@Empresa,
					@fecha_operacion,@id_estatus_transferencia,BANCA.dbo.FN_BANCA_CIFRAR(@numero),@id_folio_banca)

				--insert into BANCA..TBL_BANCA_TRANSFERENCIAS_EXTERNAS 
				--	(monto,fecha_transferencia_realizada,id_estatus_transferencia,numero_socio,fecha_programada,
				--	programado,fecha_alta_transferencia,id_banca_folio,clabe_spei_origen,
				--	clabe_spei_destino,id_cuenta_externa,concepto_pago,clave_rastreo,id_transferencia_SPEI,referencia_numerica
				--	)
				--values
				--	(@monto,@fecha_operacion,@id_estatus_transferencia,@numero,@fecha_operacion,
				--	0,@fecha_operacion,@id_folio_banca,@CuentaOrdenante,
				--	@CuentaBeneficiario,null,@ConceptoPago,@ClaveRastreo , @Id,@RefereneciaNumerica)

					/*========================================	ACTUALIZACI�N DE MOVIMIENTOS ==============================
					==============================================================================================================*/

					INSERT	HAPE..MOVIMIENTOS
						(
						NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
						NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
						ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR, id_origen
						)
					VALUES(
						@numero, 'T', @fecha_operacion, @monto,round((@saldo_cuenta_deposito + @monto),2), 'D',
						@num_poliza, @id_folio_banca, GETDATE(), @id_persona, @numusuario,
						@id_tipomov, @id_mov, 1, 'S' , @id_origen_operacion)

					
					/*========================================	ACTUALIZACI�N DE ESTADO DE CUENTA	================================
					==============================================================================================================*/
					UPDATE	HAPE..EDO_DE_CUENTA
					SET	SALDO_ACTUAL = round(@saldo_cuenta_deposito + @monto,2),
						FECHA = @fecha_operacion
					WHERE	
						numero = @numero
						and id_mov = @id_mov
						AND Id_Tipo_persona = 1
					print '@Num_cuentaContable_sucursal'+@Num_cuentaContable_sucursal

					-- insert en CAPTURA_lacp el movimiento correspondiente a SPEI
					insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = '14100611940000'

					-- insert en CAPTURA_lacp el movimiento correspondiente a la sucursal del socio
					insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov and
								cc.Num_cuenta =  @Num_cuentaContable_sucursal

					-- insert en CAPTURA_lacp el movimiento correspondiente a medio de pago
				    insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%MEDIOS%'
								and cc.Num_cuenta like '1410100099%'	

					-- insert en CAPTURA_lacp el movimiento correspondiente al movimiento que estamos realizando
				    insert	HAPE..CAPTURA_lacp
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = tm.descripcion,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%DEBITO%'
								and cc.Num_cuenta like '2160000000%'	

					-- insert en CAPTURA_lacp el movimiento correspondiente a SPEI
					insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_compensacion,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.Num_cuenta = '14100611940000'
					
					-- insert en captura el movimiento correspondiente a la sucursal del socio
					insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto =cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'H',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov and
								cc.Num_cuenta =  @Num_cuentaContable_sucursal

					-- insert en captura el movimiento correspondiente a medio de pago
				    insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = cc.Concepto,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%MEDIOS%'
								and cc.Num_cuenta like '1410100099%'	

					-- insert en captura el movimiento correspondiente al movimiento que estamos realizando
				    insert	HAPE..CAPTURA
								(
								id_persona,
								activo,
								numero,
								nombre_s,
								apellido_paterno,
								apellido_materno,
								total_movs,
								total_ficha,
								id_tipomov,
								cuenta,
								concepto,
								fecha_mov,
								monto,
								id_mov,
								num_poliza,
								tipo_poliza,
								folio,
								id_tipo_persona,
								num_cheq,
								desc1,
								desc2,
								planx,
								desc3,
								fecha_dpf_final,
								num_dpf,
								tasa,
								interes,
								dias,
								debe_haber,
								numusuario,
								numero_fin,
								plazo,
								interes_ord,
								interes_mor,
								contador_provision,
								ccostos,
								nombre_beneficiario,
								parentesco_beneficiario,
								porcentaje_beneficiario,
								nombre_beneficiario2,
								parentesco_beneficiario2,
								porcentaje_beneficiario2,
								numero_fin_lacp,
								id_esquema,
								titular,
								num_ptmo,
								id_amortizacion,
								id_renovado,
								reestructura,
								id_origen
								)

						select	@id_persona,
								'T',
								@numero,
								@nombre_origen,
								@Ap_paterno_origen,
								@Ap_materno_origen,
								total_movs = 1,
								total_ficha = 0,
								tm.id_tipomov,
								cuenta = cc.num_cuenta,
								concepto = tm.descripcion,
								fecha_mov = @fecha_operacion,
								monto = abs(@monto),
								tm.id_mov,
								num_poliza = @num_poliza,
								tipo_poliza = @tipo_poliza,
								folio = @id_folio_banca,
								id_tipo_persona = 1,
								num_cheq = 0,
								desc1 = 0,
								desc2 = 0,
								planx = null,
								desc3 = 0,
								fecha_dpf_final = cast(@fecha_operacion as date),
								num_dpf = 0,
								tasa = 0,
								interes = 0,
								dias = 0,
								debe_haber = 'D',
								numusuario = @numusuario,
								numero_fin = null,
								plazo = null,
								interes_ord = null,
								interes_mor = null,
								contador_provision = null,
								@ccostos_origen,
								nombre_beneficiario = '',
								parentesco_beneficiario = '',
								porcentaje_beneficiario = 0,
								nombre_beneficiario2 = '',
								parentesco_beneficiario2 = '',
								porcentaje_beneficiario2 = 0,
								numero_fin_lacp = null,
								id_esquema = null,
								titular = 'S',
								num_ptmo = null,
								id_amortizacion = null,
								id_renovado = null,
								reestructura = null,
								id_origen = @id_origen_operacion
							from	HAPE.dbo.tipo_mov tm
							join HAPE.dbo.cuentas_contables cc
								on tm.id_mov = @id_mov and
								tm.id_tipomov = @id_tipomov 
								and cc.concepto like '%DEBITO%'
								and cc.Num_cuenta like '2160000000%'	
								
								
				
			end   -- Transaccionalidad

			begin -- commit
				
					if @tran_count = 0
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							print 'paso 3.1 (commit de transacci�n)'
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				select @status = 200, @error_message ='Se registro correctamente la transferencia'
			end -- commit
			




	end try -- try principal
	
	begin catch -- catch principal

		select @status=coalesce(@status, 0)

		select	--@status=@status,
				--@status =error_state(),	
				@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
				@error_line = error_line(),
				@error_message = error_message(),
				@error_severity =
					case error_severity()
						when 11 then 'Error en validaci�n'
						when 12 then 'Error en consulta'
						when 13 then 'Error en actualizaci�n'
						else 'Error general'
					end

				--select @status=coalesce(@status, 0)
		-- revertir transacci�n si es necesario
		if @tran_scope = 1
		begin
			rollback tran @tran_name
		end
		
	end catch -- catch principal
	
		select @status as estatus ,@error_message  as mensaje , @numero as numeroSocio
END
GO

USE [BANCA]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			2019110
Objetivo		Obtiene la cuenta a la cual se le depositara el reembolzo de un reporte procedente de call center
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_CALLCENTER_OBTENER_CUENTA_REEMBOLSO' and xtype = 'p')
	drop proc SP_CALLCENTER_OBTENER_CUENTA_REEMBOLSO
go

create proc

	[dbo].[SP_CALLCENTER_OBTENER_CUENTA_REEMBOLSO]
	
		-- parametros		
		@numeroSocio int,
		@folioAutorizacion int
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@fecha datetime = getdate(),
						@idCuentaNoAfectada int,
						@cuentaCorresponsalias varchar(max) 						
					
			end -- inicio
			
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		

		if exists (select 1 from BANCA..TBL_CALLCENTER_REPORTES_MULTIFOLIO where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio and folio_autorizacion = @folioAutorizacion)
			begin			
				select @idCuentaNoAfectada = id_cuenta_no_afectada_banca from BANCA..TBL_CALLCENTER_REPORTES_MULTIFOLIO where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio and folio_autorizacion = @folioAutorizacion

				--select @idCuentaNoAfectada
				if (@idCuentaNoAfectada =1)
				begin
					if exists(select 1 from TBL_BANCA_TRANSFERENCIAS_INTERNAS where id_banca_folio = @folioAutorizacion and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio)
					begin
						select @cuentaCorresponsalias = (select clave_corresponsalias_origen from  banca..TBL_BANCA_TRANSFERENCIAS_INTERNAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio and id_banca_folio =@folioAutorizacion)
					end
					else if exists(select 1 from TBL_BANCA_TRANSFERENCIAS_EXTERNAS where id_banca_folio = @folioAutorizacion and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio)
					begin
						select @cuentaCorresponsalias = (select Cuenta from  hape..TBL_CORRESPONSALIAS_CUENTAS where numero = @numeroSocio and ID_MOV =112)
					end
				end
				else if (@idCuentaNoAfectada =2)
				begin
					select @cuentaCorresponsalias = (select clave_corresponsalias_destino from  banca..TBL_BANCA_TRANSFERENCIAS_INTERNAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio and id_banca_folio =@folioAutorizacion)
				end

			end
			else
			begin
				select  @error_message = 'El socio no cuenta con ningun reporte reclamado con este folio.', @estatus = 0
			end


		begin -- reporte de estatus
		if @error_message<>''
		begin
			select	
				@estatus estatus,
				@error_procedure error_procedure,
				@error_line error_line,
				@error_severity error_severity,
				@error_message error_message
			
		end
		else
		select 
			tipoOperacion.desc_prestamo,
			tipoOperacion.id_mov,
			edoCuenta.saldo_Actual
		from 
			hape..TIPOS_DE_OPERACIONES tipoOperacion
		join 
			HAPE..TBL_CORRESPONSALIAS_CUENTAS cuentasCorresponsalias
		on 
			(tipoOperacion.id_mov = cuentasCorresponsalias.id_mov)
		join 
			hape..edo_de_cuenta edoCuenta 
		on 
			(tipoOperacion.id_mov = edoCuenta.id_mov) and edoCuenta.numero = @numeroSocio
		where 
			cuentasCorresponsalias.cuenta = @cuentaCorresponsalias

		end -- reporte de estatus
		
	end -- procedimiento
	go

	grant exec on SP_CALLCENTER_OBTENER_CUENTA_REEMBOLSO to public
	go

	USE [BANCA]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20190830
Objetivo		Obtener los folios que ha registrado un socio con repecto a un folio de UNE.
Proyecto		Call Center /SPEI
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_CALLCENTER_OBTENER_FOLIOS_MULTIFOLIO' and xtype = 'p')
	drop proc SP_CALLCENTER_OBTENER_FOLIOS_MULTIFOLIO
go

create proc

	[dbo].[SP_CALLCENTER_OBTENER_FOLIOS_MULTIFOLIO]
	
		-- parametros		
		@folioUNE int		
		 
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @ESTATUS int = 0,
						@mensaje varchar(max) = '',	
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''

 
						
					
			end -- inicio
			
			
			
			begin -- �mbito de la actualizaci�n
			if exists(select 1 from TBL_CALLCENTER_REPORTES_MULTIFOLIO where FOLIO_UNE = @folioUNE)
			begin
				SELECT @ESTATUS = 1				
			end
			else
			begin
				select @error_message = 'El socio no cuenta con reportes en Call Center'
			end


			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@ESTATUS = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
		if @error_message<>''
		begin
			select	
				@ESTATUS AS ESTATUS,
				@error_procedure error_procedure,
				@error_line error_line,
				@error_severity error_severity,
				@error_message error_message
			
		end
		else
		select 
			@ESTATUS as ESTATUS,
			@mensaje mensaje,
			Reportes.ID_INCIDENCIA_REPORTE,
			Reportes.FOLIO_UNE,
			Reportes.FOLIO_AUTORIZACION,
			BANCA.dbo.FN_BANCA_DESCIFRAR(Reportes.NUMERO_SOCIO) NUMERO_SOCIO,
			Reportes.IMPORTE_RECLAMADO,
			Reportes.ID_MEDIO_MOVIMIENTO,
			MedioMov.descripcion_medio MEDIO_MOVIMIENTO,
			Reportes.ID_TIPO_CUENTA_BANCA,
			TipoCnta.DESCRIPCION TIPO_CUENTA_BANCA,
			Reportes.FECHA_TRANSACION,
			Reportes.USUARIO_REGISTRA,
			Reportes.FECHA_ALTA_REPORTE,
			Reportes.ID_SATISFACTORIO,
			Reportes.ID_CUENTA_NO_AFECTADA_BANCA
					
		from
			TBL_CALLCENTER_REPORTES_MULTIFOLIO Reportes 
		inner join
			CAT_CALLCENTER_MEDIO_MOVIMIENTO MedioMov
			on (Reportes.ID_MEDIO_MOVIMIENTO = MedioMov.ID_MEDIO_MOVIMIENTO)
		inner join 
			hape..CAT_UNE_TIPO_CUENTA_BANCA TipoCnta
			on (Reportes.ID_TIPO_CUENTA_BANCA = TipoCnta.ID_TIPO_CUENTA_BANCA)
		where Reportes.FOLIO_UNE = @folioUNE
					
		end -- reporte de estatus
		
	end -- procedimiento
	go

	grant exec on SP_CALLCENTER_OBTENER_FOLIOS_MULTIFOLIO to public
	go

	USE BANCA 
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_CMV_GENERA_CUENTA_INTERBANCARIA]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].SP_CMV_GENERA_CUENTA_INTERBANCARIA
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE SP_CMV_GENERA_CUENTA_INTERBANCARIA 
@nosocio BIGint
AS
BEGIN
	declare
	@NoSTP varchar(3) = '646',
	@Zona varchar(3) ='180',
	@NoEmpresa varchar(4)='1811',
	@cuenta  varchar(17)

	begin try
		select  @cuenta =  (@NoSTP+@Zona+@NoEmpresa+REPLACE(STR((select id_cuenta from TBL_BANCA_CUENTAS_INTERBANCARIAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @nosocio), 7), SPACE(1), '0') )  
	
		IF OBJECT_ID('tempdb..#resultDigitoVerificador') IS NOT NULL
			DROP TABLE #resultDigitoVerificador


			create table #resultDigitoVerificador
			(
				estatus int null ,
				mensaje varchar(1000) null,
				cuenta varchar(18) null,
				digito_verificador varchar(1) null,
				numero int null
			)	

			insert into #resultDigitoVerificador (estatus,mensaje,cuenta,digito_verificador, numero)
			exec SP_BANCA_OBTENER_DIGITO_VERIFICADOR @noSocio , @cuenta

			

	 end try
	 begin catch

		 insert into #resultDigitoVerificador (estatus,mensaje,cuenta,digito_verificador, numero)
		 select	 -1, error_message(),'' , -1,-1
			
	 end catch

	 select * from #resultDigitoVerificador
END
GO
