use banca
go

USE [BANCA]
GO
/****** Object:  UserDefinedFunction [dbo].[FN_BANCA_VALIDA_SOCIO]    Script Date: 22/08/2019 08:11:39 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION [dbo].[FN_BANCA_VALIDA_SOCIO] (@numero varchar(20),@valida_banca int ) 
RETURNS @error table
(
		estatus	int null,
		msj	varchar(255)
)
AS BEGIN
Declare 
@msj varchar(250),
@codigo int,
@numero_socio bigint,
@horario_operacion datetime,
@hora_operacion int
	--if(LEN(@numero) < 6)
	-- begin
	--	insert	@error
	--		(estatus, msj)
	--	values	(301, 'Numero de socio no existe')
	--	return 
	--end
	-- select * from CAT_BANCA_EXCEPTIONS order by id_excepcion
	-- valida que exista el numero en persona
	select @numero_socio = CAST(@numero as bigint)

	select @horario_operacion = GETDATE()
	select @hora_operacion =  DATEPART(HOUR,@horario_operacion)

	if(@hora_operacion between 0 and 3)
	begin
		--Fuera de horario operaci�n'
		insert	@error
			(estatus, msj)
		select id_excepcion, descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 402
		return 
	end

	if not exists (SELECT * FROM HAPE.dbo.PERSONA WHERE Numero = @numero_socio AND Id_Tipo_Persona = 1)
	begin
		insert	@error
			(estatus, msj)
		select id_excepcion, descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 318
		--(301, 'Numero de socio no existe')
		return
	end

	if not exists (SELECT * FROM HAPE.dbo.CLAVES WHERE Numemp = @numero_socio)
	begin
		insert	@error
			(estatus, msj)
		select id_excepcion, descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 318
		--(301, 'Numero de socio no esta en claves')
		return
	end

	-- valida que este en persona y que tiene un mail valido
	if EXISTS (SELECT * FROM HAPE.dbo.PERSONA WHERE Numero = @numero_socio AND Id_Tipo_Persona = 1 AND (Mail IS NULL OR Mail = ''))
	begin
		insert	@error
			(estatus, msj)
		select id_excepcion, descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 318
		--values	(318, 'N�mero de socio o correo inv�lido')
		return
	end
	--valida que exista en la table de banca socios
	IF NOT EXISTS (SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio)
	begin
		insert	@error
			(estatus, msj)
		--values	(305, 'La cuenta de banca no esta activa')
		select id_excepcion, descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 305
		return
	end

	--valida que tenga el pago cubierto del servicio
	IF NOT EXISTS (SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio AND id_estatus_banca >= 2)
	begin
		insert	@error
			(estatus, msj)
			select id_excepcion, descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 305
		--values (305, 'La cuenta de banca no esta activa. No se ha realizado el pago del servicio.')
		return
	end

	---validaci�n para cobro legal o bloqueo exlusion
	IF EXISTS(select * from HAPE..PERSONA where numero = @numero_socio AND Id_Tipo_Persona = 1 and 
		(Bloqueado_Cobranza = 'A' OR Bloqueado_Exclusion = 'A'))
	begin
		insert	@error
			(estatus, msj)
			select id_excepcion, descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 403
		return
	end

	
	IF(@valida_banca = 1)
	BEGIN
		IF NOT EXISTS (SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio AND banca_activa = 1)
		begin
			insert	@error
			(estatus, msj)
			select id_excepcion, descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 305
			--values (305, 'La cuenta de banca no esta activa')
		return
		end

		IF NOT EXISTS (SELECT * FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio AND id_motivo_bloqueo = 1 )
		begin
				insert	@error
			(estatus, msj)
			select id_excepcion, descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 302
			--values	(302, 'Cuenta bloqueada')
		return
		end

	END
	--	RETURN @error
	return  
END


