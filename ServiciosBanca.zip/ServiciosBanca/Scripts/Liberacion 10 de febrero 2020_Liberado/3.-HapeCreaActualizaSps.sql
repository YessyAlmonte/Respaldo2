﻿use hape
go

-- se crea procedimiento SP_BANCA_CONSULTA_CTAS_CORRESPONSALIAS
if exists (select * from sysobjects where name like 'SP_BANCA_CONSULTA_CTAS_CORRESPONSALIAS' and xtype = 'p' and db_name() = 'hape')
	drop proc SP_BANCA_CONSULTA_CTAS_CORRESPONSALIAS
go

/*

Autor			Autor
UsuarioRed		aaaa111111
Fecha			yyyymmdd
Objetivo		Objetivo
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_BANCA_CONSULTA_CTAS_CORRESPONSALIAS
	
	@numero int
	
as

	begin -- procedimiento
	
		begin try -- try principal
		
			SELECT ctas.*,op.Desc_prestamo 
			FROM TBL_CORRESPONSALIAS_CUENTAS ctas
			join TIPOS_DE_OPERACIONES op on ctas.id_mov=op.id_mov
			where NUMERO=@numero and ACTIVO=1
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- [selecci�n en caso de que el select del try falle]
		
		end catch -- catch principal
		
	end -- procedimiento
go

grant exec on SP_BANCA_CONSULTA_CTAS_CORRESPONSALIAS to public

USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_CREDITO_CARGAR_SOLICITUD_ACTUALIZAR]    Script Date: 19/02/2019 03:12:02 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			EDUARDO LEMUS ZAVALA
UsuarioRed		LEZE667231
Fecha			20181105
Objetivo		OBTENER QUIENES PARTICIPAN EN EL CREDITO
Proyecto		GUARDADO PARCIAL SOLICITUD
Ticket			ticket

*/

ALTER proc [dbo].[SP_CREDITO_CARGAR_SOLICITUD_ACTUALIZAR]
@ID_SOL VARCHAR(16),
@TIPO_PARTICIPANTE INT
as
begin

	DECLARE @NUMERO INT, @ING_NETO MONEY, @ING_EXTRA_NETO MONEY,@ING_BRUTO MONEY = 0, @ING_EXTRA_BRUTO MONEY = 0, @IDSUBPRODUCTO INT, @ARRAIGO_DOM DATETIME

	SELECT @NUMERO = CASE WHEN @TIPO_PARTICIPANTE = 1 THEN NUMERO WHEN @TIPO_PARTICIPANTE = 2 THEN Aval1_Numero ELSE Aval2_Numero END,
	@IDSUBPRODUCTO = id_subproducto
	FROM CRED_SOLICITUD_CREDITO 
	WHERE id_sol = @ID_SOL AND Activo = 'T'
	
	select @ING_NETO = ISNULL(ing_nto,0), @ING_EXTRA_NETO = ISNULL(ing_extra_nto,0),@ING_BRUTO = ISNULL(ing_bto,0),@ING_EXTRA_BRUTO = ISNULL(ing_extra_bto,0) from TBL_PRECALIFICADOR 
	where numero = @numero and id_subproducto = @IDSUBPRODUCTO and id_precalificacion IN (SELECT MAX(ID_PRECALIFICACION) FROM TBL_PRECALIFICADOR WHERE NUMERO = @NUMERO and id_subproducto = @IDSUBPRODUCTO)

	if(@TIPO_PARTICIPANTE = 1)
	begin
		SELECT @ARRAIGO_DOM = ARRAIGO FROM TBL_CRED_DATOS_ADICIONALES_SOLICITUD WHERE id_sol = @ID_SOL
		SELECT CRED.Numero NUMERO, COL.Id_Entidad_Federativa,EF.DESCRIPCION ESTADO,COL.Id_Localidad_CNBV,loc.nombre_localidad CNBV_Municipio,CRED.Id_Colonia_CNBV Id_Colonia_CNBV, 
		COL.Nombre_Colonia+' ('+upper(substring(tipo_colonia,1,1))+substring(lower(tipo_colonia),2,len(tipo_colonia))+')' Nombre_colonia,
		CRED.Calle CALLE,CRED.Numero_Interior Numero_Interior, CRED.Numero_Exterior Numero_Exterior,
		cast(@ARRAIGO_DOM as datetime) Arraigo,CRED.Nombre_Conyuge Nombre_Conyuge, CRED.Apellido_Paterno_Conyuge Apellido_Paterno_conyuge,
		CRED.Apellido_Materno_Conyuge Apellido_Materno_Conyuge,
		replace(replace(PER.Telefono,')',''),'(','') Telefono, 
		replace(replace(PER.Tel_Trabajo,')',''),'(','') Tel_Trabajo, 
		replace(replace(PER.Tel_Celular,')',''),'(','') Tel_Celular, 
		CRED.Ingreso_1 Ingreso_1, CRED.Ingreso_2 Ingreso_2, EMP.Puesto, cred.Finalidad_Esp, cred.id_garantia,
		CRED.Id_Mov, CRED.Planx, 
		@ING_BRUTO ING_BRUTO, 
		@ING_EXTRA_BRUTO ING_EXTRA_BRUTO, 
		CASE WHEN ISNULL(@ING_NETO,0)=0 THEN Ingreso_1 ELSE @ING_NETO END ING_NETO, 
		CASE WHEN ISNULL(@ING_EXTRA_NETO,0)=0 THEN Ingreso_2 ELSE @ING_EXTRA_NETO END ING_EXTRA_NETO,
		CRED.Id_Puesto_Cred PUESTO_CRED
		,'T' per_socio
		FROM CRED_SOLICITUD_CREDITO CRED
		INNER JOIN PERSONA PER ON CRED.Numero=PER.Numero AND PER.Id_Tipo_Persona=1
		INNER JOIN CNBV_MNPIO_COL COL ON CRED.Id_Colonia_CNBV = COL.Id_Colonia_CNBV
		INNER JOIN CNBV_LOCALIDADES loc on COL.Id_Localidad_CNBV=loc.Id_Localidad_CNBV and COL.Id_Entidad_Federativa=loc.Id_Entidad_Federativa
		INNER JOIN ENTIDAD_FEDERATIVA EF ON EF.ID_ENTIDAD_FEDERATIVA = loc.Id_Entidad_Federativa
		INNER JOIN TBL_BURO_DATOS_EMPLEADOR EMP ON EMP.Num_Ptmo = CRED.id_sol AND EMP.Numero = @NUMERO
		WHERE CRED.id_sol = @ID_SOL AND CRED.Activo = 'T' AND CRED.Numero = @NUMERO

	end
	else if(@TIPO_PARTICIPANTE = 2)
	begin

		SELECT CRED.Aval1_Numero NUMERO, COL.Id_Entidad_Federativa,EF.DESCRIPCION ESTADO,COL.Id_Localidad_CNBV,loc.nombre_localidad CNBV_Municipio,CRED.Aval1_Id_Colonia_CNBV Id_Colonia_CNBV,
		COL.Nombre_Colonia+' ('+upper(substring(tipo_colonia,1,1))+substring(lower(tipo_colonia),2,len(tipo_colonia))+')' Nombre_colonia,
		CRED.Aval1_Calle CALLE,CRED.Aval1_Numero_Interior Numero_Interior, CRED.Aval1_Numero_Exterior Numero_Exterior,
		cast(CRED.Aval1_Arraigo as datetime) Arraigo,CRED.Aval1_Nombre_Conyuge Nombre_Conyuge, CRED.Aval1_Apellido_Paterno_Conyuge Apellido_Paterno_Conyuge,
		CRED.Aval1_Apellido_Materno_Conyuge Apellido_Materno_Conyuge,
		--CRED.Aval1_Telefono Telefono, 
		--CRED.Aval1_Tel_Trabajo Tel_Trabajo, 
		--CRED.Aval1_Tel_Celular Tel_Celular,
		replace(replace(PER.Telefono,')',''),'(','') Telefono, 
		replace(replace(PER.Tel_Trabajo,')',''),'(','') Tel_Trabajo, 
		replace(replace(per.Tel_Celular,')',''),'(','') Tel_Celular,
		CRED.Aval1_Ingreso_1 Ingreso_1, CRED.Aval1_Ingreso_2 Ingreso_2, EMP.Puesto, cred.Finalidad_Esp, cred.id_garantia,
		CRED.Id_Mov, CRED.Planx, 
		@ING_BRUTO  ING_BRUTO, 
		@ING_EXTRA_BRUTO ING_EXTRA_BRUTO, 
		case when isnull(@ING_NETO,0)=0 then CRED.Aval1_Ingreso_1 else @ING_NETO end ING_NETO, 
		case when isnull(@ING_EXTRA_NETO,0)=0 then CRED.Aval1_Ingreso_2 else @ING_EXTRA_NETO end ING_EXTRA_NETO,
		CRED.Aval1_Id_Puesto_Cred PUESTO_CRED
		,CRED.Aval1_Socio per_socio
		FROM CRED_SOLICITUD_CREDITO CRED
		INNER JOIN PERSONA PER ON CRED.Aval1_Numero=PER.Numero AND PER.Id_Tipo_Persona= CASE WHEN Aval1_Socio='T' then 1 else 3 end
		INNER JOIN CNBV_MNPIO_COL COL ON CRED.Aval1_Id_Colonia_CNBV = COL.Id_Colonia_CNBV
		INNER JOIN CNBV_LOCALIDADES loc on COL.Id_Localidad_CNBV=loc.Id_Localidad_CNBV and COL.Id_Entidad_Federativa=loc.Id_Entidad_Federativa
		INNER JOIN ENTIDAD_FEDERATIVA EF ON EF.ID_ENTIDAD_FEDERATIVA = loc.Id_Entidad_Federativa
		INNER JOIN TBL_BURO_DATOS_EMPLEADOR EMP ON EMP.Num_Ptmo = CRED.id_sol AND EMP.Numero = @NUMERO
		WHERE CRED.id_sol = @ID_SOL AND CRED.Activo = 'T' AND CRED.Aval1_Numero = @NUMERO

	end
	else if(@TIPO_PARTICIPANTE = 3)
	begin

		SELECT CRED.Aval2_Numero NUMERO, COL.Id_Entidad_Federativa,EF.DESCRIPCION ESTADO,COL.Id_Localidad_CNBV,loc.nombre_localidad CNBV_Municipio,CRED.Aval2_Id_Colonia_CNBV Id_Colonia_CNBV,
		COL.Nombre_Colonia+' ('+upper(substring(tipo_colonia,1,1))+substring(lower(tipo_colonia),2,len(tipo_colonia))+')' Nombre_colonia,
		CRED.Aval2_Calle CALLE,CRED.Aval2_Numero_Interior Numero_Interior, CRED.Aval2_Numero_Exterior Numero_Exterior,
		cast(CRED.Aval2_Arraigo as datetime) Arraigo,CRED.Aval2_Nombre_Conyuge Nombre_Conyuge, CRED.Aval2_Apellido_Paterno_Conyuge Apellido_Paterno_Conyuge,
		CRED.Aval2_Apellido_Materno_Conyuge Apellido_Materno_Conyuge,
		--CRED.Aval2_Telefono Telefono, 
		--CRED.Aval2_Tel_Trabajo Tel_Trabajo, 
		--CRED.Aval2_Tel_Celular Tel_Celular, 
		replace(replace(PER.Telefono,')',''),'(','') Telefono, 
		replace(replace(PER.Tel_Trabajo,')',''),'(','') Tel_Trabajo,
		replace(replace(per.Tel_Celular,')',''),'(','') Tel_Celular,
		CRED.Aval2_Ingreso_1 Ingreso_1, CRED.Aval2_Ingreso_2 Ingreso_2, EMP.Puesto, cred.Finalidad_Esp, cred.id_garantia,
		CRED.Id_Mov, CRED.Planx, 
		@ING_BRUTO ING_BRUTO, 
		@ING_EXTRA_BRUTO ING_EXTRA_BRUTO, 
		case when isnull(@ING_NETO,0)=0 then CRED.Aval2_Ingreso_1 else @ING_NETO end ING_NETO, 
		case when isnull(@ING_EXTRA_NETO,0)=0 then CRED.Aval2_Ingreso_2 else @ING_EXTRA_NETO end ING_EXTRA_NETO,
		CRED.Aval2_Id_Puesto_Cred PUESTO_CRED
		,CRED.Aval2_Socio per_socio
		FROM CRED_SOLICITUD_CREDITO CRED
		INNER JOIN PERSONA PER ON CRED.Aval2_Numero=PER.Numero AND PER.Id_Tipo_Persona= CASE WHEN Aval2_Socio='T' then 1 else 3 end
		INNER JOIN CNBV_MNPIO_COL COL ON CRED.Aval2_Id_Colonia_CNBV = COL.Id_Colonia_CNBV
		INNER JOIN CNBV_LOCALIDADES loc on COL.Id_Localidad_CNBV=loc.Id_Localidad_CNBV and COL.Id_Entidad_Federativa=loc.Id_Entidad_Federativa
		INNER JOIN ENTIDAD_FEDERATIVA EF ON EF.ID_ENTIDAD_FEDERATIVA = loc.Id_Entidad_Federativa
		INNER JOIN TBL_BURO_DATOS_EMPLEADOR EMP ON EMP.Num_Ptmo = CRED.id_sol AND EMP.Numero = @NUMERO
		WHERE CRED.id_sol = @ID_SOL AND CRED.Activo = 'T' AND CRED.Aval2_Numero = @NUMERO

	end
					
end	
go
USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_IMAGEN_CONSULTAR_DATOS_SOCIO]    Script Date: 13/02/2020 03:44:24 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		David López Fuentes
-- Create date: 03/04/2017
-- Description:	Regresa los datos personales de un socio
-- Ticket 111111
-- =============================================
ALTER PROCEDURE [dbo].[SP_IMAGEN_CONSULTAR_DATOS_SOCIO] 
@numero int,
@id_tipo_persona int,
@PadreTutor bit=null,
@ValidaImpresionFormatos bit=null,
@ValidaContratoMultiple bit=null,
@solicitud_ingreso bit=null,
@num_usuario int=null				

AS
BEGIN

SET NOCOUNT ON;

begin try

		declare @idPersona int,
		        @saldo_certificado money,
				@nombre_ejec varchar(255),
				@nombre_gte_suc varchar(255),
				@id_de_sucursal int,
				@id_contrato_DPF int,
				@id_tipologia_sucursal int


		select @idPersona = id_persona from PERSONA where Numero = @numero and Id_Tipo_Persona = @id_tipo_persona;

		IF ((@idPersona is null or @idPersona=0) and @PadreTutor=1) 
	       	raiserror('El número de socio del padre o tutor del menor no existe, favor de verificarlo', 12, 0)

		IF (@idPersona is null or @idPersona=0) 
	       	raiserror('El número de socio no existe, favor de verificarlo', 12, 0)

	    select @saldo_certificado = saldo_actual from EDO_DE_CUENTA where numero=@Numero and Id_Tipo_persona=@id_tipo_persona and id_mov=102;

		if (@saldo_certificado < 50) and (@id_tipo_persona=1) 
		  raiserror('El socio no ha cubierto al menos el 10 por ciento de su certificado de aportación', 12, 0)

      	IF (@saldo_certificado < 500) and (@PadreTutor=1)  
	       	raiserror('El padre o tutor del menor no ha cubierto el 100 por ciento de su certificado de aportación, favor de verificarlo', 12, 0)


        if (@ValidaImpresionFormatos=1) 
		begin
				if (select Pendiente from TBL_IMAGEN_ALTA_SOCIOS where numero=@numero and id_tipo_persona=@id_tipo_persona) = 1	
					raiserror('No se han impreso los formatos de alta de este socio', 12, 0)
		end

		if (@ValidaContratoMultiple=1) 
		begin
			if not exists(SELECT 1 FROM TBL_CONTRATOS_HABERES WHERE numero=@numero and id_tipo_persona=@id_tipo_persona and id_tipo_contrato=2)							
					raiserror('Por favor imprima el contrato Múltiple', 12, 1)
		end

      	IF (@solicitud_ingreso=1) and  
		not exists(select 1 from TBL_IMAGEN_INFORMACION_SOLICITUD_SOCIO where id_persona=@idPersona) AND
		NOT EXISTS(SELECT 1 FROM PERSONA WHERE Numero=@numero AND Id_Tipo_Persona=@id_tipo_persona AND DatosActualizados='T')		
	       	raiserror('Por favor actualize los datos del socio', 12, 0)


        --Obtenemos el nombre
		select @nombre_ejec= ISNULL(Nombre_s,'') +' ' + ISNULL(Apellido_paterno,'') + ' ' + ISNULL(Apellido_materno,''),
		       @id_de_sucursal=Id_de_sucursal		
		from claves where Numusuario=@num_usuario

		if @id_tipo_persona=2
			select @id_de_sucursal=Id_de_Sucursal from PERSONA where numero=@numero and Id_Tipo_Persona=@id_tipo_persona

		select @id_tipologia_sucursal= fk_id_tipologia_sucursal from sucursales where id_de_sucursal=@id_de_sucursal

		if @id_tipologia_sucursal=4 
		begin
			select @nombre_gte_suc=ISNULL(Nombre_s,'') +' ' + ISNULL(Apellido_paterno,'') + ' ' + ISNULL(Apellido_materno,'') 
			from claves where usuario like 'enc%' and id_de_sucursal=@id_de_sucursal
		end
		else if @id_tipologia_sucursal=1
		begin
		    select @nombre_gte_suc=ISNULL(Nombre_s,'') +' ' + ISNULL(Apellido_paterno,'') + ' ' + ISNULL(Apellido_materno,'') 
			from claves where usuario like 'cord%' and id_de_sucursal=@id_de_sucursal
		end

		--Obtenemos el id_contrato_dpf en caso de que exists
		set @id_contrato_DPF =(select min(id_contrato) from TBL_CONTRATOS_HABERES where numero=@numero and id_tipo_persona=@id_tipo_persona and id_mov=105) 


		select distinct(pers.numero),
		isnull(pers.Nombre_s,'') + ' ' + isnull(pers.Apellido_Paterno,'') + ' ' + isnull(pers.Apellido_Materno,'') NombreCompleto,
		upper(replace (pers.Calle,'#','')  + ' # ' + pers.Numero_Exterior + case when len(pers.Numero_interior)>0 and pers.NUmero_interior not like 'N/A' then ' INT ' + pers.Numero_interior  else '' end + ' Col.' + col.Nombre_Colonia + ', ' + loc.Nombre_Localidad + ', ' + ent.DESCRIPCION + ', C.P ' + cast(col.Codigo_Postal as varchar(100)) + ', ' + paisDom.descripcion)   Domicilio,
		1 Estatus,
		'' MensajeError, 
		pers.Id_Persona,
		pers.Nombre_s,
		pers.Apellido_Paterno,
		pers.Apellido_Materno,
		pers.Calle,
		pers.Numero_Exterior,
		pers.Numero_Interior,
		--pers.Telefono,
		replace(replace(pers.Telefono,')',''),'(','') Telefono, ---T235161 Se remplazan parentesis
		pers.Fecha_Alta fecha_ingreso_socio,
		pers.Reingreso,
		pers.Fecha_Modifica,
		pers.NumUsuario,
		pers.Id_Colonia,
		pers.Id_Colonia2,
		pers.Id_Tipo_Persona,
		pers.Id_edo_civil,
		pers.Id_ocupacion,
		pers.Id_profesion,
		pers.Id_de_Sucursal,
		--Telefono_adicional,
		replace(replace(pers.Telefono_adicional,')',''),'(','') Telefono_adicional, ---T235161 Se remplazan parentesis		
		Clave,
		Lugar_de_nacimiento,
		Fecha_de_nacimiento,
		Periodicidad_de_compromiso,
		Sexo,
		pers.Bloqueado,
		Domicilio_anterior,
		Fecha_inicio_labores,
		Ingreso_mensual,
		Otro_ingreso,
		Horario,
		Periodicidad_otros_gastos,
		Gastos_mensuales,
		Disponibles,
		Periodicidad_ingresos,
		Gastos,
		Curp,
		Rfc,
		Dependientes_economicos,
		Edades_dependientes_economicos,
		Arraigo,
		pers.Id_empresa,
		pers.Id_vivienda,
		Compromiso_de_ahorro,
		Id_banco,
		pers.Id_medio,
		Id_caja,
		pers.Id_motivo,
		pers.Id_poblacion,
		Expediente,
		pers.Id_de_giro,
		pers.Usuario_alta,
		pers.Activo,
		Id_Puesto,
		Bloqueado_Cobranza,
		Mail,
		Id_Escolaridad,
		Id_Promotor,
		Autoriza,
		Id_Convenio,
		Bloqueado_Exclusion,
		Id_Sieban,
		Id_colegio,
		Id_Promocion,
		Id_Promaf,
		Id_Shif,
		pers.Id_Colonia_CNBV,
		pers.Id_Nomina,
		Actualizado,
		Numusuario_Actualiza,
		Fecha_Actualizacion,
		Compromiso_de_Ahorro_Max,
		--Tel_Trabajo,
		--Tel_Celular,
		replace(replace(pers.Tel_Trabajo,')',''),'(','') Tel_Trabajo,--T235161 Se remplazan parentesis
		replace(replace(pers.Tel_Celular,')',''),'(','') Tel_Celular,--T235161 Se remplazan parentesis	
		ID_GRUPO,
		Id_SAT,
		Numero_ExSocio,
		NombreUsuarioAlta,
		NumEmpleadoAlta,
		CobroLegal,
		DatosActualizados,
		--pers.*,
		--txt.*,
		suc.Descripcion Sucursal,
		paisDom.Id_Pais,
		paisDom.Descripcion Nom_Pais,
		col.Nombre_Colonia,
		col.Codigo_Postal,
		col.CNBV_Municipio,
		ent.ID_ENTIDAD_FEDERATIVA,
		ent.DESCRIPCION Entidad_federativa,
		loc.id_localidad_CNBV,
		loc.Nombre_Localidad,
		nac.DESCRIPCION Nacionalidad,
		nac.activo StatusNac,
		prof.Descripcion Profesion,
		ocupacion.Id_Ocupacion_CNBV,
		OCUPACION.Descripcion Ocupacion,
		CLASIF.Id_Clasif_Ocupacion,
		CLASIF.Descripcion Sector_ocupacion,
		SUBCLASIF.Id_Subclasif_Ocupacion,
		SUBCLASIF.Descripcion Sub_Sector_ocupacion,
		--CASE WHEN len(emp.Nombre_de_la_empresa)>0 or coalesce(EMP.ID_EMPRESA,0)=0 THEN TXT.NOMBRE_EMPRESA ELSE emp.Nombre_de_la_empresa END Empresa,
		CASE WHEN len(TXT.NOMBRE_EMPRESA)>0 or coalesce(EMP.ID_EMPRESA,0)=0 THEN TXT.NOMBRE_EMPRESA ELSE EMP.Nombre_de_la_empresa END Empresa,
		civil.Descripcion Estado_civil,
		viv.Descripcion Vivienda,
		peps.puesto,
		isnull(peps.id_dependencia,0) id_dependencia,
		dependencia,
		motivo.Descripcion Motivo,
		txt.id_medio IdMedioPublic,
		medio.Activo StatusMedio,
		medio.Descripcion DescMedio,
		afil.Numero_filiacion,
		BLOQUEO.Motivo_bloqueo,
		nom.Nombre_Empresa,
		nom.Activo StatusNomina,
		motiv.Descripcion DescMotivo,
		motiv.Activo StatusMotivo,
        
		entNac.ID_ENTIDAD_FEDERATIVA IdEntNac,
		entNac.DESCRIPCION EntNacCat,
		txt.ENTIDAD_FEDERATIVA_DE_NACIMIENTO EntNac,
		paisNac.Descripcion NomPaisNac,
		paisNac.Id_Pais IdPaisNac,
		paisNac.Activo StatusPais,

		paisNif.Descripcion NomPaisNif,
		paisNif.Id_Pais IdPaisNif,
		paisNif.Activo StatusPaisNif,

		paisExt.Descripcion NomPaisExt,
		paisExt.Id_Pais IdPaisExt,
		paisExt.Activo StatusPaisExt,
        upper(replace (txt.Calle_Extranjero,'#','')  + ' # ' + txt.Numero_Exterior_Extranjero + case when len(txt.Numero_Interior_Extranjero)>0 and txt.Numero_Interior_Extranjero not like 'N/A' then ' INT ' + txt.Numero_Interior_Extranjero  else '' end + ' Col.' + txt.Colonia_Extranjero + ', ' + txt.Municipio_Extranjero + ',' +txt.Poblacion_Extranjero + ', ' + txt.Entidad_Federativa_Extranjero + ', C.P ' + cast(txt.Codigo_Postal_Extranjero as varchar(100)) + ', ' + paisExt.descripcion)   DomicilioCompletoExtranjero,
		txt.Domicilio_correspondencia,
		txt.Entre_que_calles,
		txt.Socio_que_lo_presento,
		txt.Propiedades_su_nombre,
		txt.Nombre_propietario,
		txt.Motivo_de_cancelacion,
		txt.Licenciado,
		txt.Notas,
		txt.No_socio_presento,
		txt.Nota_baja,
		txt.Fecha,
		txt.Sueldo,
		txt.Puesto_en_la_empresa,
		txt.Horario_del_trabajo,
		txt.Motivo_Bloqueo_Cobranza,
		txt.Motivo_Bloqueo_Exclusion,
		txt.Clabe_bancaria,
		txt.Id_Nacionalidad,
		txt.Id_Tipo_ID,
		txt.Numero_ID,
		txt.Id_Origen_Recursos,
		txt.PEPS,
		txt.Id_PEPS,
		txt.Reside_Extranjero,
		txt.Domicilio_Extranjero,
		txt.Vinculos_Con_Sociedades,
		txt.Id_Tipo_Moneda,
		txt.Fecha_Visita_Agendada,
		txt.Usuario_Visita_Real,
		txt.Fecha_Visita_Real,
		txt.Id_Retiro_Cant,
		txt.Id_Retiro_Monto,
		txt.Id_Deposito_Cant,
		txt.Id_Deposito_Monto,
		txt.Id_Remesas_Cant,
		txt.Id_Remesas_Monto,
		txt.Riesgo,
		txt.Status_telefono,
		txt.Id_Submotivo_Cancelacion,
		txt.Id_Retiro_Efectivo,
		txt.Folio_cert_aportacion,
		txt.Referencia_domicilio,
		txt.otro_medio,
		txt.Saldo_promedio,
		txt.Firma_Electronica_Avanzada,
		txt.id_localidad_woccu,
		txt.Movimiento_cajas,
		txt.Fecha_autoriza,
		txt.ID_IDENTIFICACION_TUTOR,
		txt.FECHA_COMPROBANTE_MENOR,
		txt.PRINCIPAL_ORIGEN_DE_RECURSOS,
		txt.ACTIVIDAD_ECONOMICA_EXTRANJERO,
		txt.INGRESOS_MENSUALES_EXTRANJERO,
		txt.RESPUESTA_CANCELACION_1,
		txt.RESPUESTA_CANCELACION_2,
		txt.Emancipado,
		txt.ex_menor,
		txt.ingresos_adicionales,
		txt.origen_ingresos_adicionales,
		txt.id_tipo_comercio,
		txt.AdquirioCredencialSocio,
		txt.EntregoCredencialSocio,
		txt.ID_ENTIDAD_FEDERATIVA_DE_NACIMIENTO,
		txt.ENTIDAD_FEDERATIVA_DE_NACIMIENTO,
		txt.ID_PAIS_DE_NACIMIENTO,
		txt.pendiente_aut,
		txt.NIF,
		txt.Id_Pais_NIF,
		txt.Calle_Extranjero,
		txt.Numero_Exterior_Extranjero,
		txt.Numero_Interior_Extranjero,
		txt.Id_Pais_Extranjero,
		txt.Entidad_Federativa_Extranjero,
		txt.Municipio_Extranjero,
		txt.Poblacion_Extranjero,
		txt.Colonia_Extranjero,
		txt.Codigo_Postal_Extranjero,
		txt.Licenciado_mensaje,
		txt.num_menor,
		GETDATE() fecha_firma,
		suc.ciudad lugar_firma,
		@nombre_ejec nombre_ejecutivo,
		@nombre_gte_suc nombre_gerente_sucursal,
		@num_usuario num_usuario_imprimio,
		(select id_version_contrato_multiple 
		from
		TBL_CONTRATOS_HABERES_VERSIONES versiones
		left join (select MAX(id_contrato_version) id_contrato_version,numero,id_tipo_persona from TBL_CONTRATOS_HABERES where id_tipo_contrato=2 group by numero,id_tipo_persona) contrato
		on versiones.id_contrato_version=contrato.id_contrato_version and numero=@numero and id_tipo_persona=@id_tipo_persona
		where activo=case when contrato.id_contrato_version Is null then 1 else activo end
		and id_tipo_contrato=2
		group by id_version_contrato_multiple) id_version_contrato_multiple,
		'' reca,
		@id_contrato_DPF id_contrato_DPF,
		isnull(txt.BECA,cast(0 as bit)) beca,
		@id_tipologia_sucursal id_tipologia_sucursal
		INTO #datos_socio
		from
			PERSONA pers
				join
			TEXTOS txt on pers.Id_Persona = txt.Id_persona
				join
			SUCURSALES suc on pers.Id_de_Sucursal = suc.Id_de_Sucursal
			   join
			CAT_COMERCIAL_MEDIO_ENTERO medio on coalesce(txt.id_medio,0)=medio.id_medio
			  join
			MOTIVO_DE_INGRESO motiv on coalesce(pers.Id_motivo,0)=motiv.Id_Motivo
				left join
			CNBV_MNPIO_COL col on pers.Id_Colonia_CNBV = col.Id_Colonia_CNBV
				LEFT join
			CNBV_LOCALIDADES loc on col.Id_Localidad_CNBV = loc.Id_Localidad_CNBV and col.Id_Entidad_Federativa = loc.Id_Entidad_Federativa
				LEFT join
			ENTIDAD_FEDERATIVA ent on loc.Id_Entidad_Federativa = ent.ID_ENTIDAD_FEDERATIVA
			   left join
			CAT_PAISES paisDom on paisDom.Id_Pais=ent.id_pais
				left join
			NACIONALIDAD nac on txt.Id_Nacionalidad = nac.ID_NACIONALIDAD
				left join
			PROFESION prof on pers.Id_profesion = prof.Id_Profesion
				left join
			CNBV_OCUPACIONES ocupacion on ocupacion.Id_Ocupacion_CNBV=PERS.ID_OCUPACION_CNBV			
				LEFT JOIN 
			CNBV_SUBCLASIF_OCUPACIONES SUBCLASIF ON OCUPACION.Id_Subclasif_Ocupacion=SUBCLASIF.Id_Subclasif_Ocupacion and ocupacion.Id_Clasif_Ocupacion=SUBCLASIF.Id_Clasif_Ocupacion
			   LEFT join
		    CNBV_CLASIF_OCUPACIONES CLASIF ON CLASIF.ID_CLASIF_OCUPACION=SUBCLASIF.ID_CLASIF_OCUPACION
				left join
			EMPRESAS emp on pers.Id_empresa = emp.Id_Empresa
				left join
			ESTADO_CIVIL civil on pers.Id_edo_civil = civil.Id_edo_civil
				left join
			VIVIENDA viv on pers.Id_vivienda = viv.Id_Vivienda
				left join
			LAVADO_DINERO.dbo.lavado_peps peps on txt.id_peps = peps.id_peps
			   left join 
			LAVADO_DINERO.dbo.CAT_LAVADO_DEPENDENCIAS_PEPS depPeps on peps.id_dependencia = depPeps.id_dependencia
				left join
			MOTIVO_DE_INGRESO motivo on pers.id_motivo = motivo.id_motivo
			   left join
			TBL_CREDINOMINA_NUMEROS_FILIACION afil on pers.Numero=afil.Numero 			  
			  left join 
			BLOQUEO on pers.Numero=bloqueo.Numero and pers.Id_Tipo_Persona=bloqueo.Id_Tipo_Persona 
			  left join 
			Nomina_Convenios nom on pers.Id_Nomina=nom.Id_Nomina
			  left join 
			ENTIDAD_FEDERATIVA entNac on txt.ID_ENTIDAD_FEDERATIVA_DE_NACIMIENTO=entNac.ID_ENTIDAD_FEDERATIVA
			  left join 
			CAT_PAISES paisNac on paisNac.Id_Pais= case when txt.id_pais_de_nacimiento=1 then entNac.id_pais else txt.id_pais_de_nacimiento end
			 left join 
			 CAT_PAISES paisNif on paisNif.Id_Pais=txt.Id_Pais_NIF
			left join 
			 CAT_PAISES paisExt on paisExt.Id_Pais=txt.Id_Pais_Extranjero
		where 
			pers.Id_persona = @idPersona;

       --Se valida que si no existe el socio en la tabla de información de la solicitud y que esten actualizados los datos y que sea una actualizacio o una reimpresion de la solicitud para almacenar los registros esto aplica para los socios vigentes.
		if not exists(select 1 from TBL_IMAGEN_INFORMACION_SOLICITUD_SOCIO where id_persona=@idPersona)
		   and exists(select 1 from PERSONA where Id_Persona=@idPersona and DatosActualizados='T')
		   and @solicitud_ingreso in (0,1)
		begin
		   INSERT INTO TBL_IMAGEN_INFORMACION_SOLICITUD_SOCIO
			(
			id_persona,
			numero,
			id_tipo_persona,
			sucursal,
			reingreso,
			nombre_s,
			apellido_paterno,
			apellido_materno,
			sexo,
			Domicilio,
			tel_celular,
			mail,
			nacionalidad,
			id_ent_nac,
			entidad_nac,
			id_pais_nac,
			pais_nac,
			fecha_nac,
			curp,rfc,
			profesion,
			ocupacion,
			sector_ocupacion,
			ingreso_mensual,
			ingresos_adicionales,
			origen_ingresos_adicionales,
			id_edo_civil,
			estado_civil,
			Dependientes_economicos,
			firma_electronica_avanzada,
			NIF,pais_NIF,
			reside_extranjero,
			domicilio_extranjero,
			socio_peps,
			puesto_socio_peps,
			nombre_ejecutivo,
			nombre_gerente,
			num_usuario,
			fecha_alta,
			fecha_firma,
			fecha_ingreso_socio,
			lugar_firma,
			id_contrato_version,
			reca,
			empresa,
			beca
			)
		SELECT 
		@idPersona,
		@numero,
		@id_tipo_persona,
		sucursal,
		Reingreso,
		nombre_s,
		apellido_paterno,
		apellido_materno,
		sexo,
		Domicilio,
		tel_celular,
		mail,
		nacionalidad,
		IdEntNac,
		case when IdEntNac>0 then EntNacCat else EntNac end EntNac,
		IdPaisNac,
		NomPaisNac,
		Fecha_de_nacimiento,
		curp,
		rfc,
		profesion,
		ocupacion,
		sector_ocupacion,
		ingreso_mensual,
		ingresos_adicionales,
		origen_ingresos_adicionales,
		id_edo_civil,
		estado_civil,
		Dependientes_economicos,
		firma_electronica_avanzada,
		NIF,
		NomPaisNif,
		reside_extranjero,
		DomicilioCompletoExtranjero,
		peps,
		puesto,
		nombre_ejecutivo,
		nombre_gerente_sucursal,
		num_usuario_imprimio,
		--nombre_ejecutivo,
		--nombre_gerente,
		--num_usuario,
		GETDATE() fecha_alta,
		GETDATE() fecha_firma,
		fecha_ingreso_socio,
		lugar_firma,
		id_version_contrato_multiple,
		reca,
		Empresa,
		beca		
		FROM #datos_socio


		--Guardamos las referencias
		   EXEC SP_IMAGEN_CONSULTA_REFERENCIAS @idPersona,null,@solicitud_ingreso,1
		end


		if(@solicitud_ingreso=1)
		begin
		  select 
			b.Estatus,
			b.MensajeError,
			b.Id_de_Sucursal,
			isnull(a.Nombre_s,'') + ' ' + isnull(a.Apellido_Paterno,'') + ' ' + isnull(a.Apellido_Materno,'') NombreCompleto,
			a.*,
			b.nombre_gerente_sucursal,
			a.puesto_socio_peps puesto,
            a.domicilio_extranjero DomicilioCompletoExtranjero,
			a.id_pais_nac IdPaisNac,
			a.id_ent_nac IdEntNac,
			a.entidad_nac EntNacCat,
			a.entidad_nac EntNac,
			a.pais_nac NomPaisNac,
			a.fecha_nac Fecha_de_nacimiento,
			a.pais_NIF NomPaisNif,
			a.socio_peps peps,
			b.id_contrato_DPF,
			a.id_contrato_version id_version_contrato_multiple,
			b.id_tipologia_sucursal			
		  from 
		  TBL_IMAGEN_INFORMACION_SOLICITUD_SOCIO a
		  join #datos_socio  b on a.id_persona=b.Id_Persona
		  where a.id_persona=@idPersona	
		end
		else
			select * from #datos_socio		

	end try
	begin catch
		
		select -ERROR_STATE() Estatus,ERROR_MESSAGE() MensajeError
	
	end catch

END

go

USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_CONTRATOS_HABERES_OBTENER_INFO_CONSTANCIA]    Script Date: 12/03/2019 12:57:28 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			2018/10/18
Objetivo		Obtener la información de la constancia
Proyecto		Proyecto
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_CONTRATOS_HABERES_OBTENER_INFO_CONSTANCIA]
	
	@num_dpf int
	
as

	begin -- procedimiento
	
		begin try -- try principal
		
			SELECT 
			--constancia.*,
			constancia.id_constancia,
			constancia.id_contrato,
			constancia.num_dpf,
			constancia.num_poliza,
			constancia.plazo,
			(constancia.rendimientos_antes_impuestos+constancia.retension_isr)rendimientos_antes_impuestos,
			constancia.retension_isr,
			constancia.fecha_vencimiento,
			constancia.monto,
			constancia.num_usuario,
			constancia.id_sucursal,
			constancia.lugar_operacion,
			constancia.tasa_interes,
			constancia.fecha_alta,
			constancia.nombre_usuario,
			suc.Descripcion sucursal,
			upper(replace (Calle,'#','')  + ' # ' + Numero_Exterior + case when len(Numero_interior)>0 and NUmero_interior not like 'N/A' then ' INT ' + Numero_interior  else '' end + ' Col.' + col.Nombre_Colonia + ', ' + loc.Nombre_Localidad + ', ' + ent.DESCRIPCION + ', C.P ' + cast(col.Codigo_Postal as varchar(100)))   direccion_suc,
			cast(constancia.num_poliza as varchar) + RIGHT('00000' + Ltrim(Rtrim(id_constancia)),7) folio_operacion,
			coalesce(movs.id_origen,0) id_origen --T235161 Se obtiene el id_origen 		
			FROM TBL_CONTRATOS_HABERES_CONSTANCIA constancia
			join SUCURSALES suc on constancia.id_sucursal=suc.Id_de_Sucursal
			left join CNBV_MNPIO_COL col on suc.Id_Colonia_CNBV = col.Id_Colonia_CNBV
				LEFT join
			CNBV_LOCALIDADES loc on col.Id_Localidad_CNBV = loc.Id_Localidad_CNBV and col.Id_Entidad_Federativa = loc.Id_Entidad_Federativa
				LEFT join
			ENTIDAD_FEDERATIVA ent on loc.Id_Entidad_Federativa = ent.ID_ENTIDAD_FEDERATIVA
			left join HAPE..MOVIMIENTOS movs on movs.Num_DPF=constancia.num_dpf and movs.Activo='T' and movs.Id_tipomov=41
			WHERE constancia.NUM_DPF=@num_dpf

		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- [selección en caso de que el select del try falle]
		
		end catch -- catch principal
		
	end -- procedimiento
	go
use hape
go

-- se crea procedimiento SP_CMV_VALIDA_MAIL
if exists (select * from sysobjects where name like 'SP_CMV_VALIDA_MAIL' and xtype = 'p' and db_name() = 'hape')
	drop proc SP_CMV_VALIDA_MAIL
go

/*

Autor			EDUARDO LEMUS ZAVALA
UsuarioRed		LEZE667231
Fecha			20190205
Objetivo		VALIDAR QUE EL CORREO INGRESADO NO EXISTA
Proyecto		BANCA
Ticket			

*/

create proc SP_CMV_VALIDA_MAIL
@mail varchar(200),
@numero int
as
begin
	declare @conteo int, @existe bit = 0

	select @conteo = count(1)
	from HAPE.dbo.PERSONA as p	
	where
	Numero<>@numero 
	and	Mail = @mail and Id_Tipo_Persona in(1,3) 

	if(@conteo > 0)
		set @existe = 1

	select @existe as existe
		
end
go

grant exec on SP_CMV_VALIDA_MAIL to public
GO
use hape
go

-- se crea procedimiento SP_CMV_VALIDA_TEL_CELULAR
if exists (select * from sysobjects where name like 'SP_CMV_VALIDA_TEL_CELULAR' and xtype = 'p' and db_name() = 'hape')
	drop proc SP_CMV_VALIDA_TEL_CELULAR
go

/*

Autor			EDUARDO LEMUS ZAVALA
UsuarioRed		LEZE667231
Fecha			20190205
Objetivo		VALIDAR QUE EL TELEFONO CELULAR INGRESADO NO EXISTA
Proyecto		BANCA
Ticket			

*/

create proc SP_CMV_VALIDA_TEL_CELULAR
@TEL_CELULAR VARCHAR(15),
@NUMERO INT
as
begin
		
	declare @conteo int, @existe bit = 0
	select @conteo = count(1) from persona where Numero<>@NUMERO AND Tel_Celular = @tel_celular and Id_Tipo_Persona in(1,3) 

	if(@conteo > 0)
		set @existe = 1

	select @existe as existe

		
end
go

grant exec on SP_CMV_VALIDA_TEL_CELULAR to public
go


USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_CONTRATOS_HABERES_ACTUALIZA_CONTRATO]    Script Date: 09/01/2019 04:50:00 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[SP_CONTRATOS_HABERES_ACTUALIZA_CONTRATO]
@numero int, --numero de socio o menor
@tipoPersona int ,-- tipo persona 1= socio , 2= menor
@idMov int,
@numDPF int = null,
@nombreApoderado varchar (250),
@id_tipo_contrato int=null,
@id_tipo_notificacion int=null,
@monto_maximo_transferencia money=null,
@actualizar bit=0,
@num_usuario int=null,
@imprimio_anexo bit=0
AS
BEGIN
DECLARE 
@id_contrato int
select @id_tipo_contrato=coalesce(@id_tipo_contrato,1) 
	-- ACTUALIZAMOS LA ULTIMA FECHA DE IMPRESION DEL CONTRATO TANTO SI ES AHORRO TAMBIEN ACTUALIZAMOS LA 
	-- TASA DE INVER
	UPDATE  TBL_CONTRATOS_HABERES SET 
		fecha_ultima_impresion = GETDATE(),
		id_tipo_notificacion=coalesce(@id_tipo_notificacion,id_tipo_notificacion),--T235161
		monto_maximo_transferencia=coalesce(@monto_maximo_transferencia,monto_maximo_transferencia),--T235161
		monto_actualizado=case when @imprimio_anexo=1 then 1 else 0 end	--T235161	  
	WHERE 
	numero = @numero AND id_tipo_persona = @tipoPersona and NUM_DPF = @numDPF
	AND id_mov = @idMov and id_tipo_contrato=@id_tipo_contrato
	-- OBTENEMOS EL CONTRATO QUE ACABOS DE ACTUALIZAR
	 select @id_contrato = id_contrato from TBL_CONTRATOS_HABERES
	 WHERE numero = @numero AND id_tipo_persona = @tipoPersona and NUM_DPF = @numDPF
	 AND  id_mov =  @idMov and id_tipo_contrato=@id_tipo_contrato

     --ACTUALIZAMOS EL ID_CONTRATO EN LA CONSTANCIA DE PLAZO FIJO
     if(@numDPF>0 and @idMov=105)		
		UPDATE TBL_CONTRATOS_HABERES_CONSTANCIA set id_contrato=@id_contrato
		where num_dpf=@numDPF

	-- ACTUALIZAMOS EL APODERADO LEGAL
	IF(@actualizar=1)
		INSERT INTO TBL_CONTRATOS_HABERES_APODERADOS values (@id_contrato,@nombreApoderado,GETDATE())
	--T235161
		INSERT INTO TBL_CONTRATOS_HABERES_LOG(id_contrato,id_tipo_contrato,num_usuario,id_tipo_notificacion,monto_maximo_transferencia,imprimio_anexo,fecha_impresion)
		values(@id_contrato,@id_tipo_contrato,@num_usuario,@id_tipo_notificacion,@monto_maximo_transferencia,@imprimio_anexo,GETDATE())
    
	--T235161
	if(@id_tipo_contrato=3) and @imprimio_anexo=1
	begin
		INSERT INTO banca..TBL_BANCA_BITACORA_OPERACIONES 
		(id_tipo_bitacora,numero_socio,fecha_alta,id_origen_operacion,usuario)
        VALUES(44,@numero,getdate(),2,@num_usuario)
	end


END
go
USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_CONTRATOS_HABERES_GUARDA_CONTRATO]    Script Date: 09/01/2019 04:38:07 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[SP_CONTRATOS_HABERES_GUARDA_CONTRATO]
@numero INT,
@id_tipo_persona INT,
@id_mov INT ,
@num_dpf INT = null,
@tasa_anual DECIMAL (18,2),
@calle VARCHAR(250),
@numero_int VARCHAR(10),
@numero_ext VARCHAR(10),
@id_colonia_cnbv INT,
@gat_nominal DECIMAL (18,2),
@gat_real DECIMAL (18,2),
@nombreApoderado varchar(250),
@nombre_tutor VARCHAR(250) = NULL,
@fecha_nacimiento DATETIME,
@lugar_expedicion varchar(500),
--Ticket# ActContHaberes
@version_contrato int,
--MODIFICACION PARA GUARDAR LA FECHA CON LA PRIMERA VEZ QUE SE DA DE ALTA UN PLAZO FIJO
@fechaAltaContratoDPF datetime =  null,
@id_contrato_dpf int=null,
@version_contrato_dpf int=null,
@id_tipo_contrato int=null,
@id_tipo_notificacion int=null, ---T235161
@monto_maximo_transferencia money=null, ---T235161
@num_usuario int=null, ---T235161
@imprimio_anexo bit=0 ---T235161
AS
BEGIN

declare
@idcontrato int 
		
	select @id_tipo_contrato=coalesce(@id_tipo_contrato,1)

	if not exists(select * from 
		TBL_CONTRATOS_HABERES 
		where numero = @numero and id_mov=@id_mov and id_contrato_version = @version_contrato and num_dpf = @num_dpf
		and id_tipo_contrato=@id_tipo_contrato
		)
	begin
		INSERT INTO TBL_CONTRATOS_HABERES (numero,id_tipo_persona,id_mov,num_dpf,tasa_anual,calle,numero_int,
					numero_ext,id_colonia_cnbv,gat_nominal,gat_real,fecha_alta_contrato,nombre_tutor,fecha_ultima_impresion,fecha_nacimiento,
					lugar_expedicion,id_contrato_version,id_contrato_dpf,fecha_alta_caratula,version_contrato_dpf,id_tipo_contrato,id_tipo_notificacion,monto_maximo_transferencia,monto_actualizado) 
		VALUES (@numero,@id_tipo_persona,@id_mov,@num_dpf,@tasa_anual,@calle,@numero_int,@numero_ext,@id_colonia_cnbv,@gat_nominal,@gat_real,coalesce(@fechaAltaContratoDPF, GETDATE()),@nombre_tutor,GETDATE(),@fecha_nacimiento,@lugar_expedicion,@version_contrato,
		       @id_contrato_dpf,GETDATE(),@version_contrato_dpf,@id_tipo_contrato,@id_tipo_notificacion,@monto_maximo_transferencia,case when @imprimio_anexo=1 then 0 else 1 end)
	
		select @idcontrato = max(id_contrato) from TBL_CONTRATOS_HABERES where numero = @numero and num_dpf = @num_dpf and id_tipo_persona = @id_tipo_persona and id_tipo_contrato=@id_tipo_contrato;

		
		INSERT INTO TBL_CONTRATOS_HABERES_APODERADOS VALUES (case when @id_contrato_dpf>0 then @id_contrato_dpf else @idcontrato end,@nombreApoderado,getdate())

		if(@num_dpf>0 and @id_mov=105)		
			UPDATE TBL_CONTRATOS_HABERES_CONSTANCIA set id_contrato=@idcontrato
			where num_dpf=@num_dpf


		INSERT INTO TBL_CONTRATOS_HABERES_LOG(id_contrato,id_tipo_contrato,num_usuario,id_tipo_notificacion,monto_maximo_transferencia,imprimio_anexo,fecha_impresion)
		values(@idcontrato,@id_tipo_contrato,@num_usuario,@id_tipo_notificacion,@monto_maximo_transferencia,@imprimio_anexo,GETDATE())

		---T235161
		if(@id_tipo_contrato=3) and @imprimio_anexo=1
		begin
			INSERT INTO banca..TBL_BANCA_BITACORA_OPERACIONES 
			(id_tipo_bitacora,numero_socio,fecha_alta,id_origen_operacion,usuario)
            VALUES(44,@numero,getdate(),2,@num_usuario)
		end

	end
END

go
USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_CONTRATOS_HABERES_INSERTA_CONSTANCIA]    Script Date: 26/12/2018 01:59:17 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			2018/10/18
Objetivo		Insertar los datos de la constancia, del plazo fijo
Proyecto		
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_CONTRATOS_HABERES_INSERTA_CONSTANCIA]	

		@num_dpf int,
		@num_poliza int,
		@plazo int,
		@rendimientos_antes_impuestos money,
		@retension_isr money,
		@fecha_vencimiento datetime,
		@monto money,
		@num_usuario int,
		@id_sucursal int,
		@tasa_interes float,
		@id_estatus_envio int=0 ---T235161 Se guarda el id_estatus_envio

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@lugar_operacion varchar(255) = '',
						@nombre_usuario varchar(255)=''
	
			
			end -- inicio			

			
			begin -- ámbito de la actualización
			    
				if(@num_usuario>0)
					select @nombre_usuario=isnull(Nombre_s,'') + ' ' + isnull(Apellido_paterno,'') + ' ' + isnull(Apellido_materno,'') from claves where numusuario=@num_usuario


				select @lugar_operacion=upper(replace (Calle,'#','')  + ' # ' + Numero_Exterior + case when len(Numero_interior)>0 and NUmero_interior not like 'N/A' then ' INT ' + Numero_interior  else '' end + ' Col.' + col.Nombre_Colonia + ', ' + loc.Nombre_Localidad + ', ' + ent.DESCRIPCION + ', C.P ' + cast(col.Codigo_Postal as varchar(100)))
				from SUCURSALES suc
				join CNBV_MNPIO_COL col on suc.Id_Colonia_CNBV = col.Id_Colonia_CNBV
				join
			    CNBV_LOCALIDADES loc on col.Id_Localidad_CNBV = loc.Id_Localidad_CNBV and col.Id_Entidad_Federativa = loc.Id_Entidad_Federativa
				join
			    ENTIDAD_FEDERATIVA ent on loc.Id_Entidad_Federativa = ent.ID_ENTIDAD_FEDERATIVA
			    where id_de_sucursal=@id_sucursal

			    if not exists(select 1 from TBL_CONTRATOS_HABERES_CONSTANCIA where num_dpf=@num_dpf)
					INSERT INTO TBL_CONTRATOS_HABERES_CONSTANCIA(num_dpf,num_poliza,plazo,
					rendimientos_antes_impuestos,retension_isr,fecha_vencimiento,monto,
					num_usuario,id_sucursal,lugar_operacion,tasa_interes,fecha_alta,nombre_usuario,id_estatus_envio)
					VALUES(@num_dpf,@num_poliza,@plazo,@rendimientos_antes_impuestos,@retension_isr,@fecha_vencimiento,@monto,@num_usuario,@id_sucursal,@lugar_operacion,@tasa_interes,GETDATE(),@nombre_usuario,@id_estatus_envio)
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
GO
USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_CONTRATOS_HABERES_OBTENER_INFORMACION_SOCIO]    Script Date: 09/01/2019 03:03:53 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[SP_CONTRATOS_HABERES_OBTENER_INFORMACION_SOCIO]
@numero int, --numero de socio o menor
@tipoPersona int ,-- tipo persona 1= socio , 2= menor
@idMov int, -->
--100	AHORRO
--103	INVER DINAMICA
--105	INVER PLUS
--112	DEBITO CMV
--101	AHORRO DE MENORES
@numDPF int = null,
@idTipoContrato int=null,
@idSucursal int=null
AS
BEGIN
	declare  
	@idContratoDFP int = null ,
	@versionContrato int =null,
	@sucursal_impresion varchar(255) ---T235161 Se obtiene la descripcion de la sucursal en donde se esta imprimiendo el contrato

select @idTipoContrato=coalesce(@idTipoContrato,1)
select @sucursal_impresion= Descripcion from SUCURSALES where Id_de_Sucursal=@idSucursal ---T235161

IF EXISTS (SELECT 1 FROM TBL_CONTRATOS_HABERES WHERE numero = @numero AND id_tipo_persona = @tipoPersona and id_mov = @idMov and num_dpf = @numDPF and id_tipo_contrato=@idTipoContrato)
	BEGIN
		SELECT 
			 CH.id_contrato_dpf id_contrato_dpf,
			 coalesce(CH.version_contrato_dpf,CH.id_contrato_version) version_contrato_dpf,
			 coalesce(versionDPF.reca,CHV.reca) reca_contrato_DPF,
		     'EXISTE_REGISTRO'  origen,
		     ISnull(P.Nombre_s,'') +' '+ISNULL(P.Apellido_Paterno,'')+' '+ISNULL(P.Apellido_Materno,'') as nombre,
			 CH.Calle calle,
			 ISNULL(CH.Numero_Ext,'')+' '+ISNULL(CH.Numero_InT,'') as numeroCasa,
			 ISNULL(CH.Numero_Ext,'') as numeroExt,
			 ISNULL(CH.Numero_Int,'') as numeroInt,
			 C.Nombre_Colonia colonia,
			 C.Codigo_Postal cp,
			 L.Nombre_Localidad localidad,
			 E.DESCRIPCION estado,
			 C.Id_Colonia_CNBV  idColonia,
			 ISNULL(CH.fecha_nacimiento,'') as fechaNacimiento,
			 CH.nombre_tutor nombreTutor,
			 A.nombre_apoderado nombreApoderado,
			 CH.fecha_alta_contrato fechaAltaImpresion,
			 CH.lugar_expedicion lugarExpedicion,
			 ISNULL(P.Mail,'') EmailSocio

			 --Ticket# ActContHaberes
			 ,CHV.reca
			 ,CHV.id_contrato_version
			 ,case when @idMov=100 then caratulaInver.id_contrato_version else 0 end id_contrato_versionInverDinamica
			,case when @idMov=100 then caratulaInver.reca else '' end reca_versionInverDinamica,
			@sucursal_impresion sucursal_impresion ---T235161
		FROM TBL_CONTRATOS_HABERES CH  INNER JOIN 
			PERSONA P  ON P.Numero = CH.numero AND P.Id_Tipo_Persona = CH.id_tipo_persona
			LEFT JOIN CNBV_MNPIO_COL C ON C.Id_Colonia_CNBV  = CH.Id_Colonia_CNBV
			LEFT JOIN CNBV_LOCALIDADES L on C.Id_Localidad_CNBV = L.Id_Localidad_CNBV  and L.Id_Entidad_Federativa = C.Id_Entidad_Federativa
			LEFT JOIN ENTIDAD_FEDERATIVA E on E.ID_ENTIDAD_FEDERATIVA = L.Id_Entidad_Federativa  AND E.ID_ENTIDAD_FEDERATIVA = C.Id_Entidad_Federativa
			INNER JOIN TBL_CONTRATOS_HABERES_APODERADOS A ON  A.id_apoderado =(
			SELECT max(id_apoderado) FROM TBL_CONTRATOS_HABERES_APODERADOS WHERE id_contrato IN(	
			SELECT coalesce(id_contrato_dpf,id_contrato) FROM TBL_CONTRATOS_HABERES WHERE  NUMERO = @numero and id_tipo_persona =@tipoPersona AND id_mov = case when @idTipoContrato=2 then id_mov else @idMov end and num_dpf = @numDPF and id_tipo_contrato=@idTipoContrato))
			--Ticket# ActContHaberes
			left join 
				TBL_CONTRATOS_HABERES_VERSIONES CHV on CH.id_contrato_version = CHV.id_contrato_version
			left join 
				TBL_CONTRATOS_HABERES_VERSIONES versionDPF on CH.version_contrato_dpf = versionDPF.id_contrato_version
			left join TBL_CONTRATOS_HABERES contratoInver on contratoInver.id_mov = 103 and  contratoInver.NUMERO = @numero and contratoInver.id_tipo_persona = @tipoPersona and contratoInver.id_tipo_contrato=@idTipoContrato
			LEFT JOIN TBL_CONTRATOS_HABERES_VERSIONES caratulaInver on contratoInver.id_contrato_version=caratulaInver.id_contrato_version 
		WHERE CH.NUMERO = @numero and CH.id_tipo_persona = @tipoPersona and CH.NUM_DPF = @numDPF and CH.id_mov = @idMov and CH.id_tipo_contrato=@idTipoContrato
	END
ELSE
	BEGIN
		-- existe previamente ya un registro de  un id_mov = 105 por la tanto se requiere la primera fecha de alta
		-- y el apoderado legal 
		-- modificaciones para que el contrato DPF solo 
		--esta  validacion solo es para los depositos de plazo fijo si el socio ya tiene un deposito de plazo fijo 
		--se obtiene la fecha de ese contrato y se le asigna al nuevo contrato 
		--modificacion al 08-01-2017
		--if @numDPF is not null
		--BEGIN
		    
			declare  @nombreApoderado varchar(255)

			if(@idSucursal>0)
			select @nombreApoderado=CASE WHEN (JEFSUC.Numemp>0 AND JEFSUC.Comodin=0 AND JEFSUC.Nombre_s Not LIKE 'BAJA LOGICA') THEN JEFSUC.Nombre_s + ' ' + ISNULL(JEFSUC.Apellido_paterno,'') + ' ' + ISNULL(JEFSUC.Apellido_materno,'') 
									ELSE GERREGIONAL.Nombre_s + ' ' + ISNULL(GERREGIONAL.Apellido_paterno,'') + ' ' + ISNULL(GERREGIONAL.Apellido_materno,'') END
										FROM SUCURSALES SUC
										JOIN CLAVES JEFSUC ON SUC.Jef_Sucursal=JEFSUC.Numusuario
										JOIN CLAVES GERREGIONAL ON JEFSUC.Numusuario_Jefe=GERREGIONAL.Numusuario
										WHERE baja_logica=0  and SUC.Id_de_Sucursal=@idSucursal

			IF EXISTS (SELECT 1 FROM TBL_CONTRATOS_HABERES WHERE numero = @numero AND id_tipo_persona = @tipoPersona and id_mov = case when @idTipoContrato=2 then id_mov else @idMov end and id_contrato_version <> 4 and id_tipo_contrato=@idTipoContrato)
			BEGIN
				 select @idContratoDFP = min(id_contrato)  from TBL_CONTRATOS_HABERES where numero = @numero AND id_tipo_persona = @tipoPersona and id_mov = case when @idTipoContrato=2 then id_mov else @idMov end and id_contrato_version <> 4 and id_tipo_contrato=@idTipoContrato
				 		if(@idContratoDFP is not null)
						begin
							declare
							 @fechaAlta datetime,
							 @lugarExpedicion varchar(255),							
							 @recaContratoDPF varchar(100)

							 select @versionContrato = CH.id_contrato_version ,
							 @fechaAlta = fecha_alta_contrato,
							 @lugarExpedicion =  lugar_expedicion,
							 @recaContratoDPF=CHV.reca  
							 from TBL_CONTRATOS_HABERES CH
							 left join 
				             TBL_CONTRATOS_HABERES_VERSIONES CHV on CH.id_contrato_version = CHV.id_contrato_version
							 where id_contrato = @idContratoDFP

							 if exists (select top 1 nombre_Apoderado from TBL_CONTRATOS_HABERES_APODERADOS where id_contrato=@idContratoDFP)
								set @nombreApoderado=(select top 1 nombre_Apoderado from TBL_CONTRATOS_HABERES_APODERADOS where id_contrato=@idContratoDFP order by id_apoderado desc)
						end
			END
		--END 

		SELECT
			'REGISTRO_NUEVO' origen,
			@idContratoDFP id_contrato_dpf,
			@fechaAlta fechaAltaImpresion,
			@lugarExpedicion lugarExpedicion,
			@nombreApoderado nombreApoderado,
			coalesce(@versionContrato,ver.id_contrato_version) version_contrato_dpf,
			coalesce(@recaContratoDPF,ver.reca) reca_contrato_DPF,
			 ISnull(P.Nombre_s,'') +' '+ISNULL(P.Apellido_Paterno,'')+' '+ISNULL(P.Apellido_Materno,'') as nombre,
			 P.Calle calle,
			 ISNULL(P.Numero_Exterior,'')+' '+ISNULL(Numero_Interior,'') as numeroCasa,
			 ISNULL(P.Numero_Exterior,'') as numeroExt,
			 ISNULL(P.Numero_Interior,'') as numeroInt,
			 C.Nombre_Colonia colonia,
			 C.Codigo_Postal cp,
			 L.Nombre_Localidad localidad,
			 E.DESCRIPCION estado,
			 C.Id_Colonia_CNBV  idColonia,
			 ISNULL(P.Fecha_de_Nacimiento,'') as fechaNacimiento,
			 CASE WHEN @idMov = 101 THEN 
					  (SELECT  ISnull(Nombre_Referencia,'') +' '+ISNULL(Apellido_Paterno_Referencia,'')+' '+ISNULL(Apellido_Materno_Referencia,'') as nombreTutor
					   FROM REFERENCIAS WHERE Id_de_Referencia = 6 AND Id_Persona = (select Id_Persona from PERSONA where numero =@numero and Id_Tipo_Persona = @tipoPersona))
			 ELSE ''
			END nombreTutor,
			ISNULL(P.Mail,'') EmailSocio
			--Ticket# ActContHaberes
			,ver.reca
			,ver.id_contrato_version
			,case when @idMov=100 then caratulaInver.id_contrato_version else 0 end id_contrato_versionInverDinamica
			,case when @idMov=100 then caratulaInver.reca else '' end reca_versionInverDinamica,
			@sucursal_impresion sucursal_impresion ---T235161
		FROM PERSONA P
			LEFT JOIN CNBV_MNPIO_COL C ON C.Id_Colonia_CNBV  = P.Id_Colonia_CNBV
			LEFT JOIN CNBV_LOCALIDADES L on C.Id_Localidad_CNBV = L.Id_Localidad_CNBV  and L.Id_Entidad_Federativa = C.Id_Entidad_Federativa
			LEFT JOIN ENTIDAD_FEDERATIVA E on E.ID_ENTIDAD_FEDERATIVA = L.Id_Entidad_Federativa  AND E.ID_ENTIDAD_FEDERATIVA = C.Id_Entidad_Federativa
		    LEFT JOIN TBL_CONTRATOS_HABERES_VERSIONES ver on ver.id_mov=@idMov and id_tipo_contrato=@idTipoContrato AND ver.activo=1
		    LEFT JOIN TBL_CONTRATOS_HABERES_VERSIONES caratulaInver on caratulaInver.id_mov = 103 and caratulaInver.activo = 1 and caratulaInver.id_tipo_contrato=@idTipoContrato
		WHERE NUMERO = @numero and id_tipo_persona = @tipoPersona


		/*
		perc645887
		se hace esta validación fuera del if
			IF (@idMov = 105 )
				SELECT Tasa_DPF tasaIntAnual,Fecha_Mov,dias Plazo,Monto saldo FROM MOVIMIENTOS WHERE Id_tipomov =41 and Saldo >0 and Num_DPF =@numDPF and numero = @numero and activo='T'
		*/
	END

	IF (@idMov = 105 )
				SELECT 
					Tasa_DPF tasaIntAnual,Fecha_Mov,dias Plazo,Monto saldo 
				FROM MOVIMIENTOS 
				WHERE 
					Id_tipomov =41 and Saldo >0 and Num_DPF =@numDPF and numero = @numero and activo='T'

/*	ELSE  IF  (@idMov = 100 OR @idMov = 103 ) BEGIN
		SELECT Tasa tasaIntAnual,Minimo FROM TASAS WHERE Id_mov = 100 and Contador = (SELECT MAX(CONTADOR) from TASAS WHERE Id_mov =100)
		
		SELECT Tasa tasaIntAnual,Minimo FROM TASAS WHERE Id_mov = 103 and Contador = (SELECT MAX(CONTADOR) from TASAS WHERE Id_mov =103)
	   END
	ELSE
		SELECT Tasa tasaIntAnual,Minimo FROM TASAS WHERE Id_mov = @idMov and Contador = (SELECT MAX(CONTADOR) from TASAS WHERE Id_mov =@idMov)
*/

END
GO
USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_CONTRATOS_HABERES_OBTIENE_TIPO_CONTRATO]    Script Date: 07/01/2019 04:54:29 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			2018/12/03
Objetivo		Obtener los tipos de contrato
Proyecto		Proyecto
Ticket			ticket

*/

--// Modificacion T235161 Se agrega filtro de modulo de imagen

ALTER proc

	[dbo].[SP_CONTRATOS_HABERES_OBTIENE_TIPO_CONTRATO]
	
	@numero int=null,
	@id_tipo_persona int=null
	
as

	begin -- procedimiento

	    declare @nombre_socio  varchar(255)

		select @id_tipo_persona=coalesce(@id_tipo_persona,1)
		
		
		if(@numero is null)
			SELECT 1 status,'' mensaje,* FROM CAT_CONTRATOS_HABERES_TIPO_CONTRATO WHERE activo=1
		else
		begin		   
		    if not exists(select 1 from PERSONA where numero=@numero and Id_Tipo_Persona=@id_tipo_persona)
				SELECT 0 estatus,'El socio no existe' mensaje
			else
			begin
			    
				SELECT @nombre_socio= Nombre_s + ' ' + coalesce(Apellido_Paterno,'') + ' ' + coalesce(Apellido_Materno,'') 
				from PERSONA where Numero=@numero and Id_Tipo_Persona=@id_tipo_persona
			    
				select 1 estatus,'' mensaje,@nombre_socio nombre,cat.id_tipo_contrato,tipo_contrato,activo,fecha_alta 
				from TBL_CONTRATOS_HABERES cont
				join CAT_CONTRATOS_HABERES_TIPO_CONTRATO cat on cont.id_tipo_contrato=cat.id_tipo_contrato				
				where cont.numero=@numero and cont.id_tipo_persona=@id_tipo_persona and cat.modulo='IMAGEN' ---T235161
				group by cat.id_tipo_contrato,tipo_contrato,activo,fecha_alta

				UNION

				select 1 estatus,'' mensaje,@nombre_socio nombre,cat.id_tipo_contrato,tipo_contrato,activo,fecha_alta
				FROM CAT_CONTRATOS_HABERES_TIPO_CONTRATO cat WHERE activo=1 and @id_tipo_persona=1 and cat.modulo='IMAGEN' ---T235161
				
				UNION
				--para debito
				select 1 estatus,'' mensaje,@nombre_socio nombre,cat.id_tipo_contrato,tipo_contrato,cat.activo,fecha_alta
				FROM CAT_CONTRATOS_HABERES_TIPO_CONTRATO cat 
				join EDO_DE_CUENTA ed on ed.Numero=@numero and ed.Id_Tipo_persona=1 and ed.Id_mov=112 and ed.Tarjeta_activa='T'
				WHERE id_tipo_contrato=1 and @id_tipo_persona=1

				UNION
				---para menores
				select 1 estatus,'' mensaje,@nombre_socio nombre,cat.id_tipo_contrato,tipo_contrato,activo,fecha_alta
				FROM CAT_CONTRATOS_HABERES_TIPO_CONTRATO cat WHERE id_tipo_contrato=1 and @id_tipo_persona=2 
			end
		end
		
	end -- procedimiento
GO
USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_DIAS_INHABILES_CONSULTA_DPF]    Script Date: 09/01/2019 09:19:53 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Ernesto Aguilar
UsuarioRed		auhl373453
Fecha			2018/09/26
Objetivo		Consuta los plazos fijos vigentes del socio, incluyendo el campo si el dia cae en dia inhabil y calculando su proxima fecha de vencimiento
Proyecto		
Ticket			###

*/

ALTER proc [dbo].[SP_DIAS_INHABILES_CONSULTA_DPF]

	@idPersona		int=null,
	@fecha			datetime,
	@numero			int=null,
	@num_dpf		bigint=null

as

	begin -- principal
	
		begin try

			begin --declaraciones 

				declare @status					int = 1,
						@error_message			varchar(255) = '',
						@error_line				varchar(255) = '',
						@error_severity			varchar(255) = '',
						@error_procedure		varchar(255) = '',
						@hoy					datetime = cast(@fecha as date)
				

				create table 
					#temp_DPF_diasInhabiles
						(
							id									int identity (1,1)	not null,
							fecha_mov							datetime		null,
							fecha_dpf_final						datetime		null,
							num_dpf								int				null,
							tasa_dpf							float			null,
							ultima_tasa_dpf						float			null,
							monto								float			null, 
							saldo								float			null, 
							dias								int				null,
							interes_dpf							float			null,
							folio								int				null,
							tipo_poliza							varchar(1)		null,
							numusuario							int				null,
							id_persona							int				null,
							dpf_en_garantia						varchar(1)		null,
							fecha_vencimiento					datetime		null,
							disp_por_dia_inhabil				datetime		null,
							fecha_prox_venc						datetime		null,
							diff_dias_inhabiles					int				null,
							interes_dias_inhabiles				money			null,
							interes_diario_dpf					money			null,
							isr_a_retener						money			null,
							uma									money			null,
							exencion							money			null,
							posible_cancelar					bit				default 0							
						)

				create table
						#sp_dias_inhabiles_valida_secuencia
							(
								en_secuencia	bit null,
								id_inhabil		bigint null,
								fecha			datetime primary key clustered not null,
								dia_año			int null,
								dia_semana		int null,
								inhabil			bit null,
								habilitado		bit null,
								hoy				bit null,
							)

			end  --declaraciones 

			begin
			   
			   --Validamos que se haya especificado el numero de persona o el numero de socio
			   if(coalesce(@idPersona,0)=0) and (coalesce(@numero,0)=0)
			     raiserror('Por favor especifique el número de socio ó el id persona', 11, 0)

			  --Obtenemos el idPersona
			  if(coalesce(@idPersona,0)=0)
			      select @idPersona=Id_Persona from PERSONA where Numero=@numero and Id_Tipo_Persona=1

			  ---Validamos que exista el socio
			  if(coalesce(@idPersona,0)=0)
				raiserror('El número de socio no existe', 11, 0)

			end

			begin -- principal

				insert into #temp_DPF_diasInhabiles (fecha_mov, fecha_dpf_final, num_dpf, monto, saldo, m.dias, dpf_en_garantia,
													 interes_dpf, folio, tipo_poliza, numusuario, id_persona, isr_a_retener ,tasa_dpf)

				select	cast(m.fecha_mov as date) fecha_mov, cast(m.fecha_dpf_final as date) fecha_dpf_final, 
						m.num_dpf, m.monto, m.saldo, m.dias, 'F' as dpf_en_garantia, m.interes_dpf, m.folio, 
						m.tipo_poliza, m.numusuario, m.id_persona , 0.0 as isr_a_retener ,m.Tasa_DPF
				from	movimientos m
						join TIPOS_DE_OPERACIONES t 
							on m.Id_mov=t.Id_mov
				where	Id_Persona = @idPersona 
					and Id_Tipo_persona = 1
					and id_tipomov = 41
					and activo = 'T'
					and m.num_dpf not in	(
												select	distinct(num_dpf) 
												from	movimientos 
												where	id_tipomov=341 
													and Id_Persona = @idPersona 
													and Id_Tipo_persona=1
													and activo='T'
											)
					and Num_DPF=coalesce(@num_dpf,num_dpf)

				-- actualizamos la fecha de vencimiento
					update	#temp_DPF_diasInhabiles 
					set		fecha_vencimiento = a.fecha_vencimiento
					from	(
								select	num_dpf, 
								case 
									when cast(fecha_mov as date) <> cast(@hoy as date) then dateadd(dd, (round(datediff(dd, fecha_mov, @hoy) / cast(dias as float), 0, 1) )* dias, fecha_mov) + 
																				  case when dateadd(dd, (round(datediff(dd, fecha_mov, @hoy) / cast(dias as float), 0, 1) )* dias, fecha_mov) < cast(@hoy as date)  then dias else 0 end 
									else Fecha_DPF_final
								end as fecha_vencimiento
								from	#temp_DPF_diasInhabiles 
					
							)A
					where	#temp_DPF_diasInhabiles.num_dpf = a.num_dpf


				-- obtenemos la tasa actual de rendimiento y fecha de disposicion por dia inhabil por cada DPF
					declare @min_id int = 0, @max_id int = 0
					select  @min_id = min(id), @max_id = max(id) from #temp_DPF_diasInhabiles


					while @min_id <= @max_id
					begin
							
					--  se obtiene la tasa actual de rendimiento, se pidio que no apareciera la tasa con la que se aperturo el DPF
						declare @monto float = 0.0 ,
								@dias int = 0, 
								@uma money = 0.0,
								@fecha_apertura datetime, 
								@exencion money = 0.0,
								@dias_anio int

						select	@monto = monto,
								@dias = dias
						from	#temp_DPF_diasInhabiles 
						where	id = @min_id

						update	#temp_DPF_diasInhabiles
						set		ultima_tasa_dpf = a.tasa
						from	(
									SELECT	tasa as tasa, @min_id as id_
									FROM	TASAS
									WHERE	ID_MOV = 105 
										and	Minimo <= @monto 
										and Maximo >= @monto
										and Plazo_min <= @dias 
										and Plazo_max >= @dias 
										and	Fecha_cambio = (
																select	max(fecha_cambio) 
																from	TASAS
																WHERE	ID_MOV = 105 
																	and	Minimo <= @monto 
																	and Maximo >= @monto
																	and Plazo_min <= @dias 
																	and Plazo_max >= @dias  
															)
								) A
						where	#temp_DPF_diasInhabiles.id = a.id_
							
					--obtenemos la fecha de disposicion en caso de que sea un dia inhabil CNBV				
						delete #sp_dias_inhabiles_valida_secuencia

						declare @dia_a_evaluar as datetime, @inhabil as bit, @habilitado as bit,@fecha_dpf_final datetime, @dias_ int

						select @fecha_dpf_final=fecha_dpf_final, @dias_=dias from #temp_DPF_diasInhabiles where id = @min_id

						create table #temp_vencimientos_dpfs_ (id int identity(1,1), fecha_mov datetime, Fecha_DPF_final datetime, fecha_vencimiento datetime,dias int )

					-- ultimos dos vencimientos
						insert into #temp_vencimientos_dpfs_ ( fecha_mov,Fecha_DPF_final,fecha_vencimiento,dias )
						select   DATEADD(dd,-dias*2,fecha_vencimiento) fecha_mov1 , @fecha_dpf_final,  DATEADD(dd,-dias,fecha_vencimiento) fecha_vencimiento,@dias_  from #temp_DPF_diasInhabiles where id = @min_id

						insert into #temp_vencimientos_dpfs_ ( fecha_mov,Fecha_DPF_final,fecha_vencimiento,dias )
						select   DATEADD(dd,-dias,fecha_vencimiento) fecha_mov2 , @fecha_dpf_final,fecha_vencimiento,@dias_ from #temp_DPF_diasInhabiles where id = @min_id
							
					-- validamos el vencimiento mas reciente
						--select @dia_a_evaluar = max(fecha_vencimiento) from #temp_vencimientos_dpfs_ where fecha_vencimiento <= cast(@hoy as date)
						select @dia_a_evaluar = case
													when @hoy < @fecha_dpf_final then @fecha_dpf_final
													else (select max(fecha_vencimiento) from #temp_vencimientos_dpfs_ where fecha_vencimiento <= cast(@hoy as date))
												end 
													
						exec sp_dias_inhabiles_valida_secuencia @dia_a_evaluar
						
						select	@inhabil = inhabil,
								@habilitado = habilitado
						from	#sp_dias_inhabiles_valida_secuencia
						where	cast(fecha as date) = cast(@dia_a_evaluar as date)
							and	hoy = cast(1 as bit)

								
						if ( (@inhabil = 1) and (@habilitado = 1)  )
							begin
								--si no ha pasado el dia de disp por inhabil
								if (  
									(select max(fecha) from	#sp_dias_inhabiles_valida_secuencia where inhabil = 0 and habilitado = 0)>=cast(@hoy as date)
								   )
									begin
										update	#temp_DPF_diasInhabiles 
										set		fecha_vencimiento = @dia_a_evaluar,
												disp_por_dia_inhabil =	(
																			select  coalesce(max(fecha), '19000101') 
																			from	#sp_dias_inhabiles_valida_secuencia 
																			where	inhabil = 0 and habilitado = 0	
																		)
										where	id = @min_id										
									end
								else
									begin
										update	#temp_DPF_diasInhabiles 
										set		disp_por_dia_inhabil = '19000101' --'N/A'
										where	id = @min_id
									end									
							end
						else
							begin
								update	#temp_DPF_diasInhabiles 
								set		disp_por_dia_inhabil = '19000101' --'N/A'
								where	id = @min_id
							end
	
						-- actualizamos la uma

						select	@fecha_apertura = fecha_vencimiento
						from	#temp_DPF_diasInhabiles 
						where	id = @min_id

						select	@uma = coalesce(
													(
														select	uma
														from	tbl_cmv_salario_minimo_uma
														where	fecha_entra_vigor =
																(
																	select	max(fecha_entra_vigor)
																	from	tbl_cmv_salario_minimo_uma
																	where	fecha_entra_vigor <= @fecha_apertura
																)
													), 0),
								--20200127 Se obtienen los dias del año de la tabla tbl_cmv_salario_minimo_uma
								@dias_anio = coalesce(
								(
									select	dias_año
									from	tbl_cmv_salario_minimo_uma
									where	fecha_entra_vigor =
											(
												select	max(fecha_entra_vigor)
												from	tbl_cmv_salario_minimo_uma
												where	fecha_entra_vigor <= @fecha_apertura
											)
								), 0)
						
						select @exencion = @dias_anio * 5.0 * cast(@uma as float)				
						
						update	#temp_DPF_diasInhabiles
						set		uma = @uma,
								exencion = @exencion
						where	id = @min_id


						drop table #temp_vencimientos_dpfs_
						select @min_id = min(id) from #temp_DPF_diasInhabiles where id > @min_id 
							
					end  --while @min_id <= @max_id


					-- actualizamos la siguiente fecha de vencimiento
						update	#temp_DPF_diasInhabiles 
						set		fecha_prox_venc = a.sig_fecha_vencimiento
						from	(
									select  NUM_DPF, dateadd(dd, (round(datediff(dd, fecha_mov, fecha_vencimiento) / cast(dias as float), 0, 1) +1)* dias, fecha_mov) + 
										   case when dateadd(dd, (round(datediff(dd, fecha_mov, fecha_vencimiento) / cast(dias as float), 0, 1) +1)* dias, fecha_mov) < fecha_vencimiento then dias else 0 end as sig_fecha_vencimiento 
									from	#temp_DPF_diasInhabiles
								)A
						where	#temp_DPF_diasInhabiles.num_dpf = a.num_dpf

					-- actualizamos el campo si el dpf esta en garantia					
						update	#temp_DPF_diasInhabiles
						set		#temp_DPF_diasInhabiles.dpf_en_garantia = a.EN_GARANTIA
						from	(
									select	dias.id_persona, dias.num_dpf, dias.monto, --dpf.EN_GARANTIA
											case
												when dpf.EN_GARANTIA is null then 'F'
												else dpf.EN_GARANTIA
											end as EN_GARANTIA
									from	#temp_DPF_diasInhabiles dias
											left join DPF_en_garantia dpf
												on dias.num_dpf = dpf.NUM_DPF and dias.monto = dpf.MONTO and dpf.EN_GARANTIA = 'T'
								)A

						where	#temp_DPF_diasInhabiles.id_persona = a.id_persona
							and	#temp_DPF_diasInhabiles.num_dpf = a.num_dpf					

					-- actualizamos la diferencia de dias para obtener el interes no pagado del dpf
						update	#temp_DPF_diasInhabiles	
						set		diff_dias_inhabiles = case
															when disp_por_dia_inhabil <> '19000101' then DATEDIFF(DAY,fecha_vencimiento, cast(@hoy as date))--disp_por_dia_inhabil)
															else 0
													  end


					-- se calcula el interes del dia por dpf esto a 4 decimales por cuestion de precision
						update	#temp_DPF_diasInhabiles
						set		interes_diario_dpf =	case
															when diff_dias_inhabiles > 0 then  round((((ultima_tasa_dpf/100) * monto * 1 ) / 360) ,4 ,0)
															else 0
														end

					 --se calcula el interes que se va a dispersar de su ultima fecha de vencimiento a la fecha de disposicion por dia inhabil
						update	#temp_DPF_diasInhabiles
						set		interes_dias_inhabiles = case
																when diff_dias_inhabiles > 0 then round(interes_diario_dpf * diff_dias_inhabiles ,2 ,0)
																else 0
														 end

					-- actualizamos el monto de isr a retener en caso de aplicar
						update	#temp_DPF_diasInhabiles 
						set		isr_a_retener = a.isr_a_retener
						from	(
									select  num_dpf,
											case 
												when monto > exencion then interes_dias_inhabiles * 0.2 
												else 0 
											end as isr_a_retener
									from	#temp_DPF_diasInhabiles
								)A
						where	#temp_DPF_diasInhabiles.num_dpf = a.num_dpf

					--actualizamos la columna posible_cancelar para aquellos plazos fijos que se puedan cancelar el dia de hoy
					update	#temp_DPF_diasInhabiles 
						set		posible_cancelar = 1
					where dpf_en_garantia='F' and
					(
						(diff_dias_inhabiles=0 and cast(fecha_vencimiento as date)=cast(@hoy as date)) or
						(diff_dias_inhabiles>0 and cast(@fecha as date) between cast(fecha_vencimiento as date) and cast(disp_por_dia_inhabil as date))
					
					)
									
			end -- principal

		end try

		begin catch 
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =	case error_severity()
											when 11 then 'Error en validación'
											when 12 then 'Error en consulta'
											when 13 then 'Error en actualización'
											else 'Error general'
										end
					
		end catch

		begin -- reporte de estatus

		   if(@status=1)
			begin
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,
					id,
					fecha_mov,
					fecha_dpf_final,
					dpf.num_dpf,
					tasa_dpf,
					ultima_tasa_dpf,
					dpf.monto,
					saldo,
					dias,
					interes_dpf,
					folio,
					tipo_poliza,
					numusuario,
					id_persona,
					dpf_en_garantia,
					dpf.fecha_vencimiento,
					disp_por_dia_inhabil,
					fecha_prox_venc,
					diff_dias_inhabiles,
					interes_dias_inhabiles,
					interes_diario_dpf,
					round(isr_a_retener, 2, 1) as isr_a_retener,
					uma,
					exencion,					
					venc.instruccion_venc,
					posible_cancelar
					
			from	#temp_DPF_diasInhabiles dpf
					left join TBL_CONTRATOS_HABERES_INSTRUCCION_VENC_DPF venc 
						on dpf.num_dpf=venc.num_dpf 
			end	
			else
			begin
					select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
			end
		end -- reporte de estatus

	drop table #temp_DPF_diasInhabiles
	drop table #sp_dias_inhabiles_valida_secuencia
	
	end  -- principal
GO
USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_REVOLVENTE_CONSULTA_SOCIO]    Script Date: 31/08/2018 03:28:47 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Mar Mejía Murillo
UsuarioRed		memm373565
Fecha			20170113
Objetivo		Revisar si el socio indicado tiene alguna linea de fondo revolvente activa
Proyecto		Crédito revolvente
Ticket			204020

*/

----------------------------Modificación---------------------------------------------
--Autor: Jessica Almonte Acosta
--Fecha: 04/Abril/2018
--Objetivo: Obtener el numero reca del contrato correspondiente
--Proyecto: Actualización de contratos

ALTER proc

	[dbo].[SP_REVOLVENTE_CONSULTA_SOCIO]

		@numero				int,
		@id_tipo_persona	int = null,
		@fecha				datetime = null
	
as

	begin

		select @id_tipo_persona = coalesce(@id_tipo_persona, 1)
		select @fecha = cast(coalesce(@fecha, getdate()) as date)

		declare @count bit = 0, @actualizado bit = 0, @tasa_incremento decimal (7, 2), @pago_minimo money = 0, @pago_liquidacion money = 0, @limite money

		create table
			#obtiene_limites
				(
				id_linea			bigint null,
				id_estado			bit null,
				pago_minimo			money null,
				pago_liquidacion	money null,
				)
	
		begin try

			exec SP_REVOLVENTE_OBTIENE_LIMITES @numero, @id_tipo_persona, @fecha

--			select * from #obtiene_limites

			select	@pago_minimo = pago_minimo,
					@pago_liquidacion = pago_liquidacion
			from	#obtiene_limites
		
			select	@count = count(1) 
			from	tbl_revolvente_lineas_credito
			where	numero = @numero
					and id_tipo_persona = @id_tipo_persona
					and (id_estado = 1 or id_estado = 2 and @pago_minimo = 0)

			select	@tasa_incremento = porcentaje_incremento / 100.0
			from	TBL_REVOLVENTE_PARAMETROS

			if @count = 1

				begin

				
			
				select	@count activa,
						cast(0 as bit) actualizado,
						nombre_s nombre,
						apellido_paterno paterno,
						apellido_materno materno,
						upper(per.calle) calle,
						upper(per.numero_exterior) numero_exterior,
						upper(per.numero_interior) numero_interior,
						upper(col.nombre_colonia) colonia,
						col.codigo_postal codigo_postal,
						upper(col.cnbv_municipio) municipio,
						ent.descripcion entidad_federativa,
						lc.id_linea,
						lc.numero,
						lc.id_tipo_persona,
						lc.num_ptmo,
						lc.planx,
						lc.id_de_sucursal,
						lc.saldo_actual,
						lc.limite_credito,
						lc.tasa_ord,
						lc.tasa_mor,
						lc.CAT,
						lc.fecha_autorizacion,
						lc.fecha_ultimo_incremento,
						lc.dia_corte,
						lc.dia_limite,
						lc.id_estado,
						cast(case when dateadd(yy, 1, lc.fecha_ultimo_incremento) <= @fecha then lc.limite_credito * @tasa_incremento else 0 end as money) incremento_potencial, ------------------ falta considerar la mora (y ver lo de los MOP)
						cast(@tasa_incremento * 100.0 as decimal(7, 2)) tasa_incremento,
						/* Modificación - 20171005 - memm373565 - ticket 204020 - Se pide que el disponible se conforme por la diferencia de límite de crédito menos saldo actual */
						--case when round(lc.limite_credito - @pago_liquidacion, -2, 1) < 0 then 0 else round(lc.limite_credito - @pago_liquidacion, -2, 1) end disponible,
						case when round(lc.limite_credito - lc.saldo_actual, -2, 1) < 0 then 0 else round(lc.limite_credito - lc.saldo_actual, -2, 1) end disponible,
						cta.saldo_actual saldo_inverdinamica,
						@pago_minimo pago_minimo,
						@pago_liquidacion pago_liquidacion,
						UPPER(pl.LEYENDA) NumReca ,--Modifico aoaj720209 Se agrega el numero de contrato,
						isnull(cc.CUENTA,'') clabe_corresponsalias
				into	#results
				from	persona	per
						join tbl_revolvente_lineas_credito lc
							on lc.numero = per.numero
							and lc.id_tipo_persona = per.id_tipo_persona
						join edo_de_cuenta cta
							on cta.numero = per.numero
							and cta.id_mov = 103
						left join cnbv_mnpio_col col
							on col.id_colonia_cnbv = per.id_colonia_cnbv
						left join entidad_federativa ent
							on ent.id_entidad_federativa = col.id_entidad_federativa
						--Modifico aoaj720209 ActualizacionContratos Se agrega join para obtener el numero reca del contrato correspondiente
						left join TBL_CRED_DATOS_ADICIONALES_SOLICITUD das 
							on lc.num_ptmo=das.id_sol
						left join TBL_CRED_PRODUCTOS_LEYENDAS pl 
							on das.ID_CONTRATO=pl.ID_CONTRATO
						--MODIFICO REXV666480 ATUALIZACION PARA BANCA MOVIL
						left join TBL_CORRESPONSALIAS_CUENTAS cc
						    on cc.NUM_PTMO  = lc.num_ptmo and lc.numero =  cc.NUMERO
				where	per.numero = @numero
						and per.id_tipo_persona = @id_tipo_persona

				if not exists(select * from #results where colonia is null)

					begin

					select @actualizado = 1

					update #results set actualizado = 1

					end

				if @actualizado = 1

					begin

					select	@limite = limite_credito
					from	#results

					select * from #results

					end

				else

					select @count activa, @actualizado actualizado

				end

			else

				select @count activa
		
		end try
		begin catch
		
			-- [selección en caso de que el select del try falle]
			print error_message()
		
		end catch
		
	end
GO
USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_CALLCENTER_OBTENER_CUESTIONARIO]    Script Date: 16/01/2019 09:31:49 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian Pérez
UsuarioRed		pegc837648
Fecha			20181211
Objetivo		Generar Formato de Autenticación
Proyecto		CallCenter
Ticket			ticket

*/
if exists (select * from sysobjects where name like 'SP_CALLCENTER_OBTENER_CUESTIONARIO' and xtype = 'p')
	drop proc SP_CALLCENTER_OBTENER_CUESTIONARIO
go

CREATE proc

	[dbo].[SP_CALLCENTER_OBTENER_CUESTIONARIO]
	
		-- parámetros
		
		@numero_socio int
		

as

	begin -- procedimiento
		
		
	create table #preguntas(
		id_pregunta	bigint,
		descripcion_pregunta varchar(300)
	)

	create table #respuestas(
		respuesta varchar(2000),
		correcta bit,
		id_pregunta bigint
	)

	declare 
		@contador_de_preguntas int = 0,
		@id_pregunta int,
		@id_persona_socio int  = 
		(
			select 
				id_persona 
			from 
				hape..PERSONA 
			where 
				Numero = @numero_socio and Id_Tipo_Persona = 1
		)

	while @contador_de_preguntas < 3
	begin
	
		SELECT TOP 1 @id_pregunta = id_pregunta FROM BANCA..CAT_CALLCENTER_PREGUNTAS_AUTENTICACION 
		--where id_pregunta in (13,14,15)
		where id_pregunta not in(1,5,6,10,11,15,19,21,22,23,24,25) --(1,2,3,4,/*5,6,*/7,8,9,/*10,11,*/12,13,14,/*15,*/16,17,18,/*19,*/20/*,21,22*/) --pruebas para seleccionar q preguntas queremos generar
		ORDER BY NEWID()

		if not exists( select * from #preguntas where id_pregunta = @id_pregunta)
		begin
		print @id_pregunta
			--===========================	inserción a la tabla de #preguntas	===========================
			insert into #preguntas (id_pregunta,descripcion_pregunta)
			select 
				id_pregunta,descripcion_pregunta 
			from BANCA..CAT_CALLCENTER_PREGUNTAS_AUTENTICACION  
			where 
				id_pregunta = @id_pregunta

			---1 ¿Cuál es su nombre completo?
			if(@id_pregunta = 1)
			begin
				insert into #respuestas (respuesta,correcta,id_pregunta)
				SELECT TOP 2 coalesce(nombre_s,'')+' '
					+coalesce(apellido_paterno,'')+' '
					+coalesce(apellido_materno,'') nombre_completo,
					0,@id_pregunta
				FROM hape..persona 
				where
					Numero <> @numero_socio 
				ORDER BY NEWID()

				insert into #respuestas (respuesta,correcta,id_pregunta)
				SELECT coalesce(nombre_s,'')+' '
					+coalesce(apellido_paterno,'')+' '
					+coalesce(apellido_materno,'') nombre_completo,
					1,@id_pregunta
				FROM hape..persona  
				WHERE
					Numero = @numero_socio
					and Id_Tipo_Persona = 1
			end

			---2 ¿A qué sucursal pertenece?
			if(@id_pregunta = 2)
			begin

				declare @id_de_sucursal int
			
				select 
					@id_de_sucursal = Id_de_Sucursal 
				from 
					HAPE..PERSONA 
				where 
					Numero = @numero_socio 
				and 
					Id_Tipo_Persona=1
				---RESPUESTAS INCORRECTAS---
				insert into #respuestas (respuesta,correcta,id_pregunta)
				SELECT TOP 2 
					Descripcion, 0, @id_pregunta
				FROM 
					hape..SUCURSALES  
				WHERE
					Id_de_Sucursal <> @id_de_sucursal
				ORDER BY NEWID()

				---RESPUESTA CORRECTA---
				insert into #respuestas (respuesta,correcta,id_pregunta)
				SELECT TOP 1 Descripcion,
					1,@id_pregunta
				FROM 
					hape..SUCURSALES  
				WHERE
					Id_de_Sucursal = @id_de_sucursal
			end

			--3	¿Cuál es su número de teléfono celular?
			if(@id_pregunta = 3)
			begin

			declare @Socio_Tel_Cel varchar(10) =
			(
			SELECT Tel_Celular
			FROM hape..persona 
			WHERE
				Numero = @numero_socio
				and Id_Tipo_Persona = 1
			)

			insert into #respuestas (respuesta,correcta,id_pregunta)
			SELECT TOP 2 Tel_Celular,
				0,@id_pregunta
			FROM hape..persona 
			where
				Numero <> @numero_socio and Tel_Celular<>@Socio_Tel_Cel and LEN(Tel_Celular) = 10
			ORDER BY NEWID()

			---RESPUESTA CORRECTA---

			insert into #respuestas (respuesta,correcta,id_pregunta)
			SELECT TOP 1 @Socio_Tel_Cel,1,@id_pregunta
		end

			--4	¿Cuál es su dirección? (calle y número, colonia, población, código postal)
			if(@id_pregunta = 4)
			begin

				insert into #respuestas (respuesta,correcta,id_pregunta)
				SELECT TOP 2 
					coalesce(persona.Calle,'')+' '+
					coalesce(persona.Numero_Exterior,'')+' '+ 
					coalesce(municipio.Nombre_Colonia,'')+', '+ 
					coalesce(municipio.CNBV_Municipio,'')+', CP: '+ 
					convert(varchar,municipio.Codigo_Postal) domicilio,
					0,@id_pregunta
				FROM 
					hape..persona persona
				inner join
					HAPE..CNBV_MNPIO_COL municipio on persona.Id_Colonia_CNBV = municipio.Id_Colonia_CNBV
				where
					Numero <> @numero_socio 
				ORDER BY NEWID()

				---RESPUESTA CORRECTA---
				insert into #respuestas (respuesta,correcta,id_pregunta)
				SELECT TOP 1
					coalesce(persona.Calle,'')+' '+
					coalesce(persona.Numero_Exterior,'')+' '+ 
					coalesce(municipio.Nombre_Colonia,'')+', '+ 
					coalesce(municipio.CNBV_Municipio,'')+', CP: '+ 
					convert(varchar,municipio.Codigo_Postal) domicilio,
					1,@id_pregunta
				FROM 
					hape..persona persona
				inner join
					HAPE..CNBV_MNPIO_COL municipio on persona.Id_Colonia_CNBV = municipio.Id_Colonia_CNBV
				WHERE
					Numero = @numero_socio
				and 
					Id_Tipo_Persona = 1
			end

			--5	¿Entre que calles vive?
			if(@id_pregunta = 5)
			begin

				insert into #respuestas (respuesta,correcta,id_pregunta)
				select 
					Entre_que_calles, 1,@id_pregunta
				from 
					hape..TEXTOS 
				where Id_persona=@id_persona_socio and Entre_que_calles<>'' and Entre_que_calles is not null
			
					---------------------------------
				insert into #respuestas (respuesta,correcta,id_pregunta)
				select top 2 
					Entre_que_calles, 0,@id_pregunta
				from 
					hape..TEXTOS 
				where 
					Id_persona<>@id_persona_socio and Entre_que_calles<>'' and Entre_que_calles is not null
				order by NEWID()
				--print ''
			end

			--6 ¿Cuál es el tiempo de residencia en su domicilio?
			if(@id_pregunta = 6)
			begin

				declare @tiempo_arraigo int = 
				(
					select 
						datediff(YEAR,Arraigo,GETDATE()) 
						from 
							HAPE..PERSONA 
						where 
							numero =@numero_socio 
							and Id_Tipo_Persona = 1
				)

				insert into #respuestas(respuesta, correcta, id_pregunta)
				select 
					@tiempo_arraigo,1,@id_pregunta;
			
		
				---RESPUESTAS INCORRECTA----
				WITH 
					arraigos_incorrectos 
				AS (
						SELECT 
							arraigo = 1
						UNION ALL
						SELECT 
							arraigo + 1 
						FROM 
							arraigos_incorrectos 
						WHERE arraigo < 100 
					)
				insert into #respuestas(respuesta, correcta,id_pregunta)
				
				SELECT top 
					2 arraigo, 0,@id_pregunta FROM arraigos_incorrectos 
					where
						arraigo 
					not in (@tiempo_arraigo)
					order by NEWID()
			end

			--7 ¿Cuándo fue su último ingreso a CMV Finanzas?
			if(@id_pregunta = 7)
			begin

				declare
				@fecha_secion_socio varchar(max) = 
				(
				select 
					convert(varchar,coalesce(FORMAT(socio.fecha_ultima_sesion,'dd/MM/yyyy'),'N/A')) 
				FROM 
					banca..TBL_BANCA_SOCIOS socio
				where
					BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_socio 
				)
				declare @dias_dinamicos1 int, @dias_dinamicos2 int, @fecha1 datetime, @fecha2 datetime
				select @dias_dinamicos1 = ROUND(((100 - 1) * RAND() + 1), 0)
				select @dias_dinamicos2 = ROUND(((100 - 2) * RAND() + 1), 0)

				select @fecha1 = DATEADD(day,-@dias_dinamicos1,getdate())
				select @fecha2 = DATEADD(day,-@dias_dinamicos2,getdate())

				---SI NUNCA HA ENTRADO A CMV FINANZAS----
				if @fecha_secion_socio is null or @fecha_secion_socio = 'N/A'
				begin
					---RESPUESTA CORRECTA---
						insert into #respuestas (respuesta,correcta,id_pregunta)
					SELECT TOP 1
						'Nunca ha ingresado a CMV Finanzas',
						1,@id_pregunta
					
					---RESPUESTAS INCORRECTAS---
						insert into #respuestas (respuesta,correcta,id_pregunta)
					SELECT top 1
						convert(varchar,coalesce(FORMAT(@fecha1,'dd/MM/yyyy'),'N/A')),
						0,@id_pregunta
				
					insert into #respuestas (respuesta,correcta,id_pregunta)
					SELECT TOP 1
						convert(varchar,coalesce(FORMAT(@fecha2,'dd/MM/yyyy'),'N/A')),
						0,@id_pregunta					 
				end
				else
				begin

					---RESPUESTA CORRECTA---
					insert into #respuestas (respuesta,correcta,id_pregunta)
					SELECT 
						@fecha_secion_socio,
						1,@id_pregunta


					---RESPUESTAS INCORRECTAS---
					insert into #respuestas (respuesta,correcta,id_pregunta)
					SELECT top 1
						convert(varchar,coalesce(FORMAT(@fecha1,'dd/MM/yyyy'),'N/A')),
						0,@id_pregunta
					where convert(varchar,FORMAT(@fecha1,'dd/MM/yyyy')) <> @fecha_secion_socio 
					and 
						convert(varchar,FORMAT(@fecha1,'dd/MM/yyyy')) <> 'N/A'

					insert into #respuestas (respuesta,correcta,id_pregunta)
					SELECT
						convert(varchar,coalesce(FORMAT(@fecha2,'dd/MM/yyyy'),'N/A')),
						0,@id_pregunta
					where convert(varchar,FORMAT(@fecha2,'dd/MM/yyyy')) <> @fecha_secion_socio					
					and 
						convert(varchar,FORMAT(@fecha2,'dd/MM/yyyy')) <> 'N/A'
				end				
			end

			--8 ¿Cuál es su dirección de correo electrónico?
			if(@id_pregunta = 8)
			begin
				declare @socioMail varchar(max) = 
				(select Mail from HAPE..PERSONA where numero = @numero_socio and Id_Tipo_Persona = 1)
	
				---Respuestas Incorrectas
				insert into #respuestas (respuesta,correcta,id_pregunta)
				SELECT TOP 2 
					persona.Mail,
					0,@id_pregunta
				FROM 
					HAPE..PERSONA persona
				where
					numero <> @numero_socio 
					and Mail is not null and Mail <> '' and Mail like '%@%'
					and Mail <> @socioMail
				ORDER BY NEWID()

				----Respuesta correcta---
				if @socioMail ='' or @socioMail is null or @socioMail not like '%@%'
				begin
					insert into #respuestas (respuesta,correcta,id_pregunta)
					select 'No cuenta con correo electrónico',1,@id_pregunta
				end 
				ELSE
				begin 
					insert into #respuestas (respuesta,correcta,id_pregunta)
					select @socioMail,1,@id_pregunta
				end
			end

			--9 ¿Cuál es su fecha de nacimiento?
			if(@id_pregunta = 9)
			begin

				insert into #respuestas (respuesta,correcta,id_pregunta)
				SELECT TOP 2 
					coalesce(PERSONA.Fecha_de_nacimiento,'N/A'),
					0,@id_pregunta
				FROM 
					HAPE..PERSONA persona
				where
					numero <> @numero_socio 
					and Fecha_de_nacimiento is not null
				ORDER BY NEWID()

				insert into #respuestas (respuesta,correcta,id_pregunta)
				SELECT 
					coalesce(PERSONA.Fecha_de_nacimiento,'N/A'),
					1,@id_pregunta
				FROM 
					HAPE..PERSONA persona
				where
					numero = @numero_socio 
					and Id_Tipo_Persona = 1

				update #respuestas 
				set 
					respuesta = FORMAT(convert(datetime,respuesta) ,'dd/MM/yyyy')
				where
					id_pregunta = @id_pregunta
			end

			--10 ¿Cuál es su edad?
			if(@id_pregunta = 10)
			begin
				DECLARE @edad_Socio int, @FECHA_2 DATETIME = GETDATE(), @FECHA_1 DATETIME = (select Fecha_de_nacimiento from HAPE..persona where numero =@numero_socio)

				set @edad_Socio =
				( select year(@fecha_2) - year(@fecha_1)
				-      case
						when
							substring(convert(varchar, @fecha_1, 112), 5, 4) >
							substring(convert(varchar, @fecha_2, 112), 5, 4)
									then 1
						else 0
				end
				)

				--datediff(YEAR,@fecha_nacimiento,@fecha_hoy)
				insert into #respuestas (respuesta,correcta,id_pregunta)
				SELECT TOP 2 
					datediff(YEAR,persona.Fecha_de_nacimiento,GETDATE()),
					0,@id_pregunta
				FROM 
					HAPE..PERSONA persona
				where
					numero <> @numero_socio 
					and Fecha_de_nacimiento is not null and datediff(YEAR,persona.Fecha_de_nacimiento,GETDATE())<100
				ORDER BY NEWID()

				insert into #respuestas (respuesta,correcta,id_pregunta)
				SELECT 
					@edad_Socio,
					1,@id_pregunta
				FROM 
					HAPE..PERSONA persona
				where
					numero = @numero_socio 
			end

			--11 ¿Cuál es su nacionalidad?
			if(@id_pregunta = 11)
			begin
			declare 
				@id_nacionalidad int,
				@nacionalidad varchar(30)

				select 
					@nacionalidad = nacionalidad.DESCRIPCION,
					@id_nacionalidad = nacionalidad.ID_NACIONALIDAD 
				from 
					hape..PERSONA persona
				inner join 
					HAPE..TEXTOS textos on persona.Id_Persona =  textos.Id_persona
				inner join
					HAPE..NACIONALIDAD nacionalidad on textos.Id_Nacionalidad =  nacionalidad.Id_Nacionalidad
				where
					persona.Numero = @numero_socio
					and persona.Id_Tipo_Persona = 1

				---RESPUESTAS INCORRECTAS---
				insert into #respuestas (respuesta,correcta,id_pregunta)
				SELECT TOP 2 
					DESCRIPCION,0,@id_pregunta 
					from 
						hape..NACIONALIDAD
					where
						ID_NACIONALIDAD <> @id_nacionalidad
					order by NEWID()
								
				insert into #respuestas (respuesta,correcta,id_pregunta)
				values(@nacionalidad,1,@id_pregunta)

			end
		
			--12 ¿en que entidad federativa nacio?
			if(@id_pregunta = 12)
			begin
				declare
					@estado_nacimiento int ,
					@lugar_nacimiento_socio varchar(max)

					select 
						@estado_nacimiento = estado.ID_ENTIDAD_FEDERATIVA,
						@lugar_nacimiento_socio =  (coalesce( estado.descripcion,'')+', ' + coalesce (pais.descripcion,'') + ' ')  
					from 
						HAPE..TEXTOS txt 
					inner join 
						hape..CAT_PAISES pais on pais.Id_Pais = txt.ID_PAIS_DE_NACIMIENTO  
					join 
						HAPE..ENTIDAD_FEDERATIVA estado on estado.ID_ENTIDAD_FEDERATIVA =txt.ID_ENTIDAD_FEDERATIVA_DE_NACIMIENTO 
					where 
						txt.Id_persona = @id_persona_socio
					

					---SI LA ENTIDAD DE NACIMIENTO ES NULL---
					if @lugar_nacimiento_socio is null
					begin
					---RESPUESTA CORRECTA---
						insert into #respuestas (respuesta,correcta,id_pregunta)
						select 'NO TIENE LUGAR DE NACIMIENTO REGISTRADO',1,@id_pregunta
						
					---RESPUESTAS INCORRECTAS---
						insert into #respuestas (respuesta,correcta,id_pregunta)
						select top 2 
							(
								coalesce( estado.descripcion,'')+', ' + 
								coalesce (pais.descripcion,'') + ' '),
								0, @id_pregunta   
						from  
							hape..CAT_PAISES pais 
						join 
							HAPE..ENTIDAD_FEDERATIVA estado on estado.Id_Pais = pais.Id_Pais
						where 
							estado.DESCRIPCION <> 'NINGUNO'
						and 
							estado.DESCRIPCION is not null and pais.Descripcion is not null
						order by NEWID()				
					end

					else
					begin

					---RESPUESTA CORRECTA----
						insert into #respuestas (respuesta,correcta,id_pregunta)
						select @lugar_nacimiento_socio,1,@id_pregunta

					---RESPUESTAS INCORRECTAS---
						insert into #respuestas (respuesta,correcta,id_pregunta)
						select top 2 
							(
								coalesce( estado.descripcion,'')+', ' + 
								coalesce (pais.descripcion,'') + ' '),
								0, @id_pregunta   
						from  
							hape..CAT_PAISES pais 
						join 
							HAPE..ENTIDAD_FEDERATIVA estado on estado.Id_Pais = pais.Id_Pais
						where 
							estado.ID_ENTIDAD_FEDERATIVA <> @estado_nacimiento 
						and 
							estado.DESCRIPCION <> 'NINGUNO'
						and 
							estado.DESCRIPCION is not null and pais.Descripcion is not null
						order by NEWID()
					end
			end
		
			--13 ¿Ha realizado algún movimiento en su banca electrónica en el último mes? En caso afirmativo: ¿Cuál? (Deposito o retiro)
			
			if(@id_pregunta = 13)
			begin
				-----VARIABLES NECESARIAS----------
				declare @movimiento_socio int

				set @movimiento_socio = 
				(
				select top 1 b.id_tipo_bitacora
					from 
						BANCA..TBL_BANCA_BITACORA_OPERACIONES a
					inner join 
						BANCA..CAT_BANCA_TIPOS_BITACORA b on a.id_tipo_bitacora = b.id_tipo_bitacora
					where
						a.id_tipo_bitacora in (15,16,17,19,20,21,22,23,24,50,51,52,53,70,80,81,85,86,88,92,93,96,97)
					and 
						numero_socio = @numero_socio
					order by id_bitacora desc
				)


				declare @fechaTransfSocio varchar(max) = 
				(
				select top 1 
							
					convert(varchar,FORMAT(a.fecha_alta ,'dd/MM/yyyy'))
							
				from 
					BANCA..TBL_BANCA_BITACORA_OPERACIONES a
				inner join 
					BANCA..CAT_BANCA_TIPOS_BITACORA b on a.id_tipo_bitacora = b.id_tipo_bitacora
				where
					a.id_tipo_bitacora in (15,16,17,19,20,21,22,23,24,50,51,52,53,70,80,81,85,86,88,92,93,96,97)
				and 
					numero_socio = @numero_socio
				order by id_bitacora desc

				)

				--------------------------RESPUESTAS INCORRECTAS----------------------------
				declare @dias_dinamicosTrans1 int, @dias_dinamicosTrans2 int, @fechaTrans1 datetime, @fechaTrans2 datetime
				select @dias_dinamicosTrans1 = ROUND(((100 - 1) * RAND() + 1), 0)
				select @dias_dinamicosTrans2 = ROUND(((100 - 2) * RAND() + 2), 0)

				select @fechaTrans1 = DATEADD(day,-@dias_dinamicosTrans1,getdate())
				select @fechaTrans2 = DATEADD(day,-@dias_dinamicosTrans2,getdate())
				
				
					
					if @fechaTransfSocio<>null
					begin
					
						insert into #respuestas (respuesta,correcta,id_pregunta)					
						select top 1 
							(
								convert(varchar,FORMAT(@fechaTrans1,'dd/MM/yyyy'))
							) +' ',0,@id_pregunta
							where @fechaTransfSocio not in(@fechaTrans1,@fechaTrans2)
						
						
						insert into #respuestas (respuesta,correcta,id_pregunta)
					
						select top 1 
							(
								convert(varchar,FORMAT(@fechaTrans2,'dd/MM/yyyy'))
							) +' ',0,@id_pregunta
							where @fechaTransfSocio not in(@fechaTrans1,@fechaTrans2)
						 
					end
					else
					begin
					insert into #respuestas (respuesta,correcta,id_pregunta)					
						select top 1 
							(
								convert(varchar,FORMAT(@fechaTrans1,'dd/MM/yyyy'))
							) +' ',0,@id_pregunta
						
						insert into #respuestas (respuesta,correcta,id_pregunta)
					
						select top 1 
							(
								convert(varchar,FORMAT(@fechaTrans2,'dd/MM/yyyy'))
							) +' ',0,@id_pregunta							
					end	
					
				

				--------------------------RESPUESTA CORRECTAS-------------------------------
			

					if  not exists (select * from BANCA..TBL_BANCA_BITACORA_OPERACIONES where numero_socio = @numero_socio and id_tipo_bitacora in (15,16,17,19,20,21,22,23,24,50,51,52,53,70,80,81,85,86,88,92,93,96,97))
					begin
						insert into #respuestas (respuesta,correcta,id_pregunta)
						select 'No ha realizado ningun movimiento',1,@id_pregunta
					end

					else 
					begin
						insert into #respuestas (respuesta,correcta,id_pregunta)
						select top 1 
							(
								convert(varchar,FORMAT(a.fecha_alta ,'dd/MM/yyyy'))
							) +' ',1,@id_pregunta 
						from 
							BANCA..TBL_BANCA_BITACORA_OPERACIONES a
						inner join 
							BANCA..CAT_BANCA_TIPOS_BITACORA b on a.id_tipo_bitacora = b.id_tipo_bitacora
						where
							a.id_tipo_bitacora in (15,16,17,19,20,21,22,23,24,50,51,52,53,70,80,81,85,86,88,92,93,96,97)
						and 
							numero_socio = @numero_socio
						order by id_bitacora desc
					end
			end

			--14 ¿Cuál es su profesión u ocupación?
			if(@id_pregunta = 14)
			begin

				declare @id_profesion_socio int
			
				select 
					@id_profesion_socio = profesion.Id_Profesion 
				from 
					HAPE..PERSONA persona 
				inner join 
					hape..PROFESION profesion on persona.Id_profesion = profesion.Id_Profesion
				where 
					persona.numero =@numero_socio
				and 
					Id_Tipo_Persona =1
			
				-------RESPUESTA CORRECTA-----------------------------
				insert into #respuestas(respuesta,correcta,id_pregunta)
				select 
					Descripcion,1,@id_pregunta
				from 
					HAPE..PROFESION 
				where 
					id_profesion=@id_profesion_socio
			
				--------REPUESTAS INCORRECTAS---------
				insert into #respuestas(respuesta,correcta,id_pregunta)
			
				select top 2 
					descripcion,0, @id_pregunta
				from 
					hape..PROFESION 
				where 
					Id_Profesion<> @id_profesion_socio
				order by NEWID()
				--------------------------------------
			end

			--15 ¿Cuál es su escolaridad?
			if(@id_pregunta = 15)
			begin			
				declare @id_escolaridad_socio varchar
			
				select 
					@id_escolaridad_socio = escolaridad.Id_Escolaridad 
				from 
					HAPE..PERSONA persona 
				inner join 
					hape..ESCOLARIDAD escolaridad on persona.Id_Escolaridad = escolaridad.Id_Escolaridad
				where 
					persona.numero =@numero_socio
				and
					Id_Tipo_Persona =1
			
				-------RESPUESTA CORRECTA-----------------------------
				insert into #respuestas(respuesta,correcta,id_pregunta)
				select 
					Descripcion,1,@id_pregunta
				from 
					HAPE..ESCOLARIDAD 
				where  
					Id_Escolaridad=@id_escolaridad_socio
			
				--------REPUESTAS INCORRECTAS---------
				insert into #respuestas(respuesta,correcta,id_pregunta)
			
				select top 2 
					descripcion,0, @id_pregunta
				from 
					hape..ESCOLARIDAD 
				where 
					Id_Escolaridad<> @id_escolaridad_socio
				order by NEWID()
			
			end

			--16 ¿Cuál es su estado civil?
			if(@id_pregunta = 16)
			begin
				declare @id_edo_civil_socio varchar
			
				select 
					@id_edo_civil_socio = edo_civil.Id_edo_civil 
				from 
					HAPE..PERSONA persona 
				inner join 
					hape..ESTADO_CIVIL edo_civil on persona.Id_edo_civil = edo_civil.Id_edo_civil
				where 
					persona.numero =@numero_socio
				and 
					Id_Tipo_Persona =1			

				insert into #respuestas(respuesta,correcta,id_pregunta)
				-------RESPUESTA CORRECTA-----------------------------
				select 
					Descripcion,1,@id_pregunta
				from 
					HAPE..ESTADO_CIVIL 
				where  
					Id_edo_civil=@id_edo_civil_socio
			
				--------REPUESTAS INCORRECTAS---------
				insert into #respuestas(respuesta,correcta,id_pregunta)			
				select top 2 
					descripcion,0, @id_pregunta
				from 
					hape..ESTADO_CIVIL 
				where 
						Id_edo_civil<> @id_edo_civil_socio
				order by NEWID()
			
			end

			--17 ¿Tiene algún crédito vigente con CMV, cuál?
			if(@id_pregunta = 17)
			begin

				-------RESPUESTA CORRECTA-----------------------------
				insert into #respuestas(respuesta,correcta,id_pregunta)			
				select ISNULL(STUFF ((
					SELECT ', ' + tipo_operaciones.Desc_prestamo 
					from					
						hape..EDO_DE_CUENTA edo_cuenta 
					inner join
						hape..TIPOS_DE_OPERACIONES tipo_operaciones on edo_cuenta.Id_mov = tipo_operaciones.Id_mov
					where
						Numero = @numero_socio
					and 
						Id_Tipo_persona = 1
					and 
						edo_cuenta.Id_mov < 10
					and 
						edo_cuenta.Saldo_Actual > 0
					and 
						edo_cuenta.Num_ptmo <> '' 
					and 
						edo_cuenta.Num_ptmo is not null
					FOR XML PATH ('')), 1, 1, '' ),'NO CUENTA CON CREDITOS ACTUALMENTE.'),1,@id_pregunta

				-------RESPUESTA INCORRECTA-----------------------------
				insert into #respuestas(respuesta,correcta,id_pregunta)			
				select TOP 2 
					Desc_prestamo,0,@id_pregunta 
				from 
					hape..TIPOS_DE_OPERACIONES tipo_operaciones 
				WHERE
					Id_mov not in (
						select 
							Id_mov 
						from 
							hape..EDO_DE_CUENTA edo_cuenta 
						where
							Numero = @numero_socio
						and 
							Id_Tipo_persona = 1
						and 
							edo_cuenta.Id_mov < 10
						and 
							edo_cuenta.Saldo_Actual > 0
						and 
							edo_cuenta.Num_ptmo <> '' 
						and 
							edo_cuenta.Num_ptmo is not null
					)
					and 
						Id_mov <100
				order by NEWID()
			end

			--18 ¿Cuántos beneficiarios de cuenta tiene?
			if(@id_pregunta = 18)
			begin
				declare @numero_beneficiarios_socio int 
				set @numero_beneficiarios_socio = 
				(
					select count(b.id_persona) 
					from 
						hape..PERSONA a 
					inner join 
						REFERENCIAS b on a.Id_Persona = b.Id_Persona 
					where 
						a.numero = @numero_socio  
					and 
						a.Id_Tipo_Persona = 1 
					and  
						Id_de_Referencia in (1,7,8,9)
				)

				----RESPUESTA CORRECTA------
				insert into #respuestas(respuesta,correcta,id_pregunta)
				VALUES(@numero_beneficiarios_socio, 1, @id_pregunta);
			
				---RESPUESTAS INCORRECTA----
				WITH beneficiarios_incorrectos AS (
						SELECT 
							beneficiario = 1
						UNION ALL
						SELECT 
							beneficiario + 1 
						FROM 
							beneficiarios_incorrectos 
						WHERE 
							beneficiario < 10 
					)
				insert into #respuestas(respuesta, correcta,id_pregunta)
				SELECT top 2 
					beneficiario, 0,@id_pregunta 
				FROM 
					beneficiarios_incorrectos 
				where
					beneficiario not in (@numero_beneficiarios_socio)
				order by NEWID()
			end

			--19 ¿Qué parentesco tiene con su beneficiario principal?
			if(@id_pregunta = 19)
			begin
			-------RESPUESTAS CORRECTAS----
			insert into #respuestas(respuesta,correcta,id_pregunta)
				select 
					top 1
					( 
						coalesce(b.Nombre_Referencia,'SIN BENEFICIARIOS') + ' '
						+ coalesce(b.Apellido_Paterno_Referencia,'') + ' ' 
						+ coalesce(b.Apellido_Materno_Referencia,'') + ' ' 
						+'- PARENTESCO: ' + coalesce(Parentesco,' SIN INFORMACIÓN') 
					), 1,@id_pregunta
				from 
					hape..PERSONA a 
				inner join 
					HAPE..REFERENCIAS b on a.Id_Persona = b.Id_Persona 
				where 
					a.numero = @numero_socio  
					and 
						a.Id_Tipo_Persona = 1 
					and  
						Id_de_Referencia in (1,7,8,9) 
				order by Porcentaje desc

			----RESPUESTAS INCORRECTAS---
			insert into #respuestas(respuesta,correcta,id_pregunta)
				select 
					top 2
					( 
						b.Nombre_Referencia + ' '
						+ coalesce(b.Apellido_Paterno_Referencia,'') + ' ' 
						+ coalesce(b.Apellido_Materno_Referencia,'') + ' ' 
						+'- PARENTESCO: ' + coalesce(Parentesco,' SIN INFORMACIÓN')
					),0, @id_pregunta 
				from 
					hape..PERSONA a 
				inner join 
					REFERENCIAS b on a.Id_Persona = b.Id_Persona 
				where 
					a.numero <> @numero_socio  
					and 
						a.Id_Tipo_Persona = 1 
					and  
						Id_de_Referencia in (1,7,8,9) 
					and 
						b.Nombre_Referencia <> ''
				order by NEWID()
			end

			--20 ¿Cuántos dependientes económicos tiene?
			if(@id_pregunta = 20)
			begin

				declare @dependientes_economicos_socio int 
				set @dependientes_economicos_socio = 
				(
					select top 1 
						Dependientes_economicos 
					from 
						hape..persona 
					where 
						numero = @numero_socio and Id_Tipo_Persona =1
				);

				--------RESPUESTA CORRECTA---------
				if @dependientes_economicos_socio = null
				begin
					set @dependientes_economicos_socio =0
				end

				insert into #respuestas(respuesta,correcta,id_pregunta)
				select @dependientes_economicos_socio,1,@id_pregunta;

				---RESPUESTAS INCORRECTA-----------
				WITH dependientes_incorrectos AS (
						SELECT 
							dependientes_incorrectos = 1
						UNION ALL
						SELECT 
							dependientes_incorrectos + 1 
						FROM 
							dependientes_incorrectos 
						WHERE dependientes_incorrectos < 20 
					)

				insert into #respuestas(respuesta,correcta,id_pregunta)
				SELECT 
				top 
						2 dependientes_incorrectos,0,@id_pregunta 
				FROM 
					dependientes_incorrectos 
				where
					dependientes_incorrectos not in (@dependientes_economicos_socio)
				order by NEWID()
						
			end

			--21 ¿Tiene residencia en otro país?
			if(@id_pregunta = 21)
			begin
				------RESPUESTA CORRECTA-----
				declare @residencia_extranjero_socio varchar =
					(
					select 
						textos.Reside_Extranjero 
					from 
						hape..PERSONA persona
					inner join
						HAPE..TEXTOS textos on persona.Id_persona = textos.Id_persona
					where 
						persona.Numero = @numero_socio
					)

				if @residencia_extranjero_socio ='F'
				begin
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'NO',1,@id_pregunta
				end

				else if @residencia_extranjero_socio ='T'
				begin
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'SI',1,@id_pregunta
				end

				------RESPUESTAS INCORRECTAS-----
				declare @recidencia_incorrecta varchar 
				set @recidencia_incorrecta =
				(
					select top 1 
						Reside_Extranjero 
					from 
						hape..TEXTOS 
					where 
						Reside_Extranjero not in(@residencia_extranjero_socio)
				)

				if @recidencia_incorrecta ='F'
				begin
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'NO', 0, @id_pregunta
					
				end

				else if @recidencia_incorrecta ='T'
				begin
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'SI',0,@id_pregunta

				end

			end

			--22 ¿Ha cumplido con funciones públicas destacadas?
			if(@id_pregunta = 22)
			begin
			 
				declare @estatus_peps_socio varchar = 
				(
					select 
						PEPS 
					from 
						hape..persona p
					join 
						hape..textos tx on p.id_persona=tx.Id_persona
					where 
						p.Id_persona=@id_persona_socio
				)

				-----------RESPUESTA CORRECTA-----------------
				if @estatus_peps_socio ='F'
				begin
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'NO',1,@id_pregunta

					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'SI',0,@id_pregunta
				end

				else if @estatus_peps_socio ='T'
				begin
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'SI',1,@id_pregunta

					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'NO',0,@id_pregunta
				end
			end

			--23 ¿Algún familiar a cumplido con funciones públicas destacadas?
			if(@id_pregunta = 23)
			begin
			
				declare @id_peps_referencia int = 
				(
					select top 1 
						Id_PEPS 
					from 
						hape..REFERENCIAS 
					where 
						Id_Persona = @id_persona_socio
				) 
				----------------RESPUESTA CORRECTA----------------
				if @id_peps_referencia>0 or @id_peps_referencia is not null
				begin
				insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'SI',1,@id_pregunta
				end
					
				else
				begin
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'NO',1,@id_pregunta
				end

				----------RESPUESTAS INCORRECTAS-----------------
				declare @estatus_incorrecto_familiar int 
				set @estatus_incorrecto_familiar =
				(
					select top 1 
						Id_PEPS 
					from 
						hape..TEXTOS 
					where 
						Id_PEPS not in(@id_peps_referencia)
				)

				if @estatus_incorrecto_familiar = 0 or @estatus_incorrecto_familiar is null
				begin
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'SI',0,@id_pregunta
				end

				else
				begin
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'NO', 0, @id_pregunta				
				end
			end 

			--24 ¿Los recursos de su cuenta son de su propiedad?
			if(@id_pregunta = 24)
			begin
				if EXISTS (select Id_de_Referencia from HAPE..REFERENCIAS where Id_Persona = @id_persona_socio and Id_de_Referencia  in(16)) 
				begin
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'SI',1,@id_pregunta
					--INCORRECTA
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'NO',0,@id_pregunta
				end
				else
				begin
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'NO',1,@id_pregunta
					insert into #respuestas(respuesta,correcta,id_pregunta)
					--INCORRECTA
					select 
						'SI',0,@id_pregunta
				end
			end 

			--25 ¿Los recursos provienen de un tercero?
			if(@id_pregunta = 25)
			begin
				if EXISTS (select Id_de_Referencia from HAPE..REFERENCIAS where Id_Persona = @id_persona_socio and Id_de_Referencia not in(16)) 
				begin
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'SI',1,@id_pregunta
					--INCORRECTA
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'NO',0,@id_pregunta
				end
				else
				begin
					insert into #respuestas(respuesta,correcta,id_pregunta)
					select 
						'NO',1,@id_pregunta
					insert into #respuestas(respuesta,correcta,id_pregunta)
					--INCORRECTA
					select 
						'SI',0,@id_pregunta
				end
			end  

			---PASAMOS A LA SIGUIENTE PREGUNTA
			set @contador_de_preguntas = @contador_de_preguntas + 1
		end
	end

	select * from #preguntas
	select * from #respuestas order by NEWID()

	drop table #preguntas
	drop table #respuestas

		
	end -- procedimiento
GO

grant exec on SP_CALLCENTER_OBTENER_CUESTIONARIO to public
go
use hape
go

-- se crea procedimiento SP_BANCA_OBTENER_MOVIMIENTOS_POLIZA
if exists (select * from sysobjects where name like 'SP_BANCA_OBTENER_MOVIMIENTOS_POLIZA' and xtype = 'p' and db_name() = 'hape')
	drop proc SP_BANCA_OBTENER_MOVIMIENTOS_POLIZA
go

/*

Autor			Edson
UsuarioRed		pere713450
Fecha			2018/01/02
Objetivo		Consultar los movimientos  de la poliza de ingresos de banca ( de acuerdo a un usuario y numero de poliza)
Proyecto		Banca Electronica
Ticket			ticket

*/

create proc SP_BANCA_OBTENER_MOVIMIENTOS_POLIZA
	@num_poliza int,
	@fecha datetime=null,
	@tipo_poliza int,
	@proceso_poliza int
	/*
	@proceso_poliza = 17  ---- BANCA_ELECTRONICA
	@proceso_poliza = 18  ---- SPEI
	*/
as

	begin
	
		begin try

			select @fecha=coalesce(@fecha,getdate())

			IF @proceso_poliza = 17 -- BANCA_ELECTRONICA
			BEGIN

				IF(@tipo_poliza = 1)
				BEGIN
					SELECT 
						Ccostos,Num_Poliza,NUMUSUARIO,
						LEFT(Cuenta + '00000000000000000000000000000000000000000000000000', 36) Num_cuenta,
						UPPER(Concepto) concepto,SUM(Monto) monto,
						case 
							when DEBE_HABER = 'H' then 1
							when DEBE_HABER = 'D' then -1
						end operacion
					FROM 
						CAPTURA_lacp 
					WHERE
						Num_Poliza = @num_poliza
						--and ID_mov in (100,103,112)
						and Activo='T'
						and cast(Fecha_mov as date)=cast(@fecha as date)
						and id_origen in (3,4)
						and Id_Tipomov not in(0,961)--se descarga los movimientos en 0 de cajas
						and Tipo_poliza <> 'O'
					group by Ccostos,Num_Poliza,NUMUSUARIO,Cuenta,Concepto,DEBE_HABER
					order by Cuenta
				END

				IF(@tipo_poliza = 2)
				BEGIN
					SELECT 
						Ccostos,Num_Poliza,NUMUSUARIO,
						LEFT(Cuenta + '00000000000000000000000000000000000000000000000000', 36) Num_cuenta,
						UPPER(Concepto) concepto,SUM(Monto) monto,
						case 
							when DEBE_HABER = 'H' then 1
							when DEBE_HABER = 'D' then -1
						end operacion
					FROM 
						CAPTURA_lacp 
					WHERE
						Num_Poliza = @num_poliza
						and Activo='T'
						and cast(Fecha_mov as date)=cast(@fecha as date)
						and id_origen in (3,4)
						and Id_Tipomov not in (0,961)--se descarga los movimientos en 0 de cajas
						and Tipo_poliza= 'O'
					group by Ccostos,Num_Poliza,NUMUSUARIO,Cuenta,Concepto,DEBE_HABER
					order by Cuenta
				END

			END

			IF @proceso_poliza = 18 -- SPEI
			BEGIN
				IF(@tipo_poliza = 1)
				BEGIN
					SELECT 
						Ccostos,Num_Poliza,NUMUSUARIO,
						LEFT(Cuenta + '00000000000000000000000000000000000000000000000000', 36) Num_cuenta,
						UPPER(Concepto) concepto,SUM(Monto) monto,
						case 
							when DEBE_HABER = 'H' then 1
							when DEBE_HABER = 'D' then -1
						end operacion
					FROM 
						CAPTURA_lacp 
					WHERE
						Num_Poliza = @num_poliza
						--and ID_mov in (100,103,112)
						and Activo='T'
						and cast(Fecha_mov as date)=cast(@fecha as date)
						and id_origen in (7)
						and Id_Tipomov not in(0,961)--se descarga los movimientos en 0 de cajas
						and Tipo_poliza <> 'O'
					group by Ccostos,Num_Poliza,NUMUSUARIO,Cuenta,Concepto,DEBE_HABER
					order by Cuenta
				END
			END

		end try
		begin catch
		
			-- [selecci�n en caso de que el select del try falle]
		
		end catch

		
	end
go

grant exec on SP_BANCA_OBTENER_MOVIMIENTOS_POLIZA to public
go

USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTIENE_SOCIO]    Script Date: 29/01/2019 09:53:06 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


if exists (select * from sysobjects where name like 'SP_BANCA_OBTIENE_SOCIO' and xtype = 'p')
	drop proc SP_BANCA_OBTIENE_SOCIO
go
-- =============================================
-- Author:		
-- Create date: 2018-09-04
-- Description:	
--				
-- =============================================
CREATE PROCEDURE [dbo].[SP_BANCA_OBTIENE_SOCIO]
@numeroSocio bigInt,
@noUsuario int = null,
@idTIpoPersona int  =1

AS
BEGIN

begin try
declare
@existeError bit  = 0 ,
@mensajeError varchar(500) = ''

	-- validaciones

	 if ((Select Id_de_Sucursal from PERSONA where Numero = @numeroSocio and Id_Tipo_Persona  =@idTIpoPersona) <> (select Id_de_sucursal from hape..CLAVES where Numusuario = @noUsuario))
			select  @existeError = 1 , @mensajeError  = 'El socio no pertenece a  su sucursal.|' 

	if exists (SELECT 1 FROM HAPE..PERSONA WHERE Numero = @numeroSocio and Id_Tipo_Persona  =@idTIpoPersona and  Bloqueado_Cobranza = 'A')
		select  @existeError = 1 , @mensajeError  = 'El socio  cuenta con bloqueo alto en cobranza.|' 

	if exists (SELECT 1 FROM HAPE..PERSONA WHERE Numero = @numeroSocio and Id_Tipo_Persona  =@idTIpoPersona and  Bloqueado_Exclusion = 'A')
		select  @existeError = 1 , @mensajeError  = @mensajeError +'El socio  cuenta con bloqueo de exclusion.|'
				
	if exists (SELECT 1 FROM HAPE..PERSONA WHERE Numero = @numeroSocio and Id_Tipo_Persona  =@idTIpoPersona and (Mail is null  or  Mail  =''))
			select  @existeError = 1 , @mensajeError  = @mensajeError+'El socio no cuenta con correo electronico por favor actualiza la información.|'
	
	if exists (SELECT 1 FROM HAPE..PERSONA WHERE Numero = @numeroSocio and Id_Tipo_Persona  =@idTIpoPersona and (Tel_Celular is null or  Tel_Celular  like  ''))
		select  @existeError = 1 , @mensajeError  = @mensajeError+'El socio no cuenta con teléfono celular.|'


	if (select len(Tel_Celular) from hape..persona where numero = @numeroSocio and Id_Tipo_Persona = 1)<>10
		select  @existeError = 1 , @mensajeError  = @mensajeError+'El teléfono celular debe de tener 10 digitos, actualice sus datos desde imagen.|'


	if  not exists (SELECT 1 FROM TBL_CONTRATOS_HABERES WHERE 
					Numero = @numeroSocio 
					and Id_Tipo_Persona  =@idTIpoPersona 
					and id_tipo_contrato = 2 
	 )
	 begin
	      declare @nombre_contrato varchar(500)
		  select @nombre_contrato = tipo_contrato from CAT_CONTRATOS_HABERES_TIPO_CONTRATO where activo = 1 and id_tipo_contrato = 2
		 select  @existeError = 1 , @mensajeError  = @mensajeError+'El socio no cuenta con el o los '+@nombre_contrato+' firmados.|'
	end


	if exists (SELECT 1 FROM HAPE..PERSONA WHERE Numero = @numeroSocio and Id_Tipo_Persona  =@idTIpoPersona and (Tel_Celular like '%(%' or  Tel_Celular  like  '%)%'))
		select  @existeError = 1 , @mensajeError  = @mensajeError+'El socio no cuenta con teléfono celular actualizado.|'

	--if exists (select 1 from hape..PERSONA a inner join HAPE..REFERENCIAS b on a.Id_Persona = b.Id_Persona 
	--			where a.Numero = @numeroSocio and a.Id_Tipo_Persona  =@idTIpoPersona and (b.Parentesco is null  or  b.Parentesco  =''))
	--		select  @existeError = 1 , @mensajeError  = @mensajeError+'El beneficiario del socio no cuenta con parentesco por favor actuliza la información.|'
	
	
	--if  not exists (SELECT * FROM TBL_CORRESPONSALIAS_CUENTAS WHERE Numero = @numeroSocio and ACTIVO= 1 AND id_mov in (100,103) )
	--	select  @existeError = 1 , @mensajeError  = @mensajeError+'El socio no cuenta con claves de corresponsalias activadas.|' 
 


	-- VALIDAMOS QUE LOS BENEFICIARIOS TENGAN SUS DATOS ACTUALIZADOS --•	NombrE,Domicilio,Fecha de Nacimiento,Porcentaje
	IF EXISTS ( select 1 from REFERENCIAS where Id_de_Referencia in (1,7,8,9) AND id_persona in (
				select Id_Persona from PERSONA where Numero  = @numeroSocio and Id_Tipo_Persona = 1
				) 
				AND 
					(	ISNULL(Id_Colonia_CNBV,0) = 0 OR
						CONVERT (VARCHAR , Fecha_de_Nacimiento, 112) = '19000101' OR
						ISNULL(Porcentaje,0) = 0 OR
						Nombre_Referencia is null or Nombre_Referencia ='' 
				    ))
	 select  @existeError = 1 , @mensajeError  = @mensajeError+'Por favor actualize la información de los beneficiarios del socio.|'

	 --VALIDAMOS LA ACTUALIZACION DE LOS CAMPOS DE LA NUEVA VERSION DE IMAGEN

	 IF EXISTS (SELECT 1  FROM HAPE..PERSONA WHERE Numero = @numeroSocio AND Id_Tipo_Persona = 1 AND DatosActualizados = 'F')
	 BEGIN
		 select  @existeError = 1 , @mensajeError  = @mensajeError+'El socio no cuenta con su información actualizada.|'
	 END
	

	if exists (select 1 from QUEBRANTOS.dbo.QUEBRANTO_EDO_DE_CUENTA where Numero = @numeroSocio)
		select  @existeError = 1 , @mensajeError  = @mensajeError+'EL socio  ha sido quebrantado, no se puede activar servicios electrónicos por internet “CMV Finanzas”. |'

	 if not exists (select Id_mov,* from HAPE..EDO_DE_CUENTA where Numero = @numeroSocio and Id_Tipo_persona =1 and Id_mov =102 and Saldo_Actual >=500)
		select  @existeError = 1 , @mensajeError  = @mensajeError+'El socio no cuenta con el certificado de aportación completo.|'

	if exists (select id_motivo_bloqueo from banca..tbl_banca_socios where id_motivo_bloqueo =13 and BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio and banca_activa =1)
			select  @existeError = 1 , @mensajeError  = 'El socio tiene un bloqueo por motivo de fraudes.|'

	if exists (SELECT * FROM HAPE..PRECANCELACION_LOG WHERE Id_Status=1 AND Activo='T' AND Numero = @numeroSocio )
		select  @existeError = 1 , @mensajeError  = 'El socio tiene actualmente tiene una preecancelación pendiente.|'

	if exists (SELECT * FROM HAPE..PRECANCELACION_LOG WHERE Id_Status=1 AND Activo='T' AND Numero = @numeroSocio )
		select  @existeError = 1 , @mensajeError  = 'El socio tiene actualmente tiene una preecancelación pendiente.|'

	IF EXISTS (SELECT 1  FROM HAPE..PERSONA WHERE @numeroSocio 
		not in(
		--numeros de consejo
		526124,192344,153419,341905,94975,205910,601805,719814,62418,248166,
		--otros numeros
		837648,770170,730316,616206,627988,633626,693751,167484,214704,187872,325287,654761,766493,742026,810439,29853,715017,740529,589777,879665,720209
		) 
		AND Id_Tipo_Persona = 1)
	 BEGIN
		 select  @existeError = 1 , @mensajeError  = @mensajeError+'El socio ingresado ni existe en el family group.|'
	 END
	/*if not exists (SELECT * FROM HAPE..CLAVES WHERE  Numemp = @numeroSocio )
		select  @existeError = 1 , @mensajeError  = 'El socio ingresado no es empleado.|'*/
	-- fin de validaciones
	
	SELECT 
	1 estatus ,
	@existeError existeError,
	@mensajeError mensajeError,
	isnull(p.Nombre_s,' ')+' '+isnull(p.Apellido_Paterno,' ')+' '+isnull(p.Apellido_Materno,' ') nombreCompleto,
	CASE WHEN BANCA.DBO.FN_BANCA_DESCIFRAR(S.numero_socio) IS NULL THEN 1  ELSE 0 END puedeActivar,
	CASE WHEN S.id_motivo_bloqueo  <> 1 THEN 1  ELSE 0 END bloqueado,
	CASE WHEN CB.numero IS NULL THEN 0 ELSE 1 END tieneContratoBanca,
	isnull(S.banca_activa,0)banca_activa,
	ISNULL(s.id_estatus_banca,0) id_estatus_banca,
	cast(ISNULL(CB.monto_maximo_transferencia,0) as money) monto_maximo_transferencia,
	CB.id_tipo_notificacion,
	p.Mail,
	p.Tel_Celular,
	C.Codigo_Postal,C.Nombre_Colonia , L.Nombre_Localidad, E.DESCRIPCION,
	isnull(p.Calle,'')+' '+isnull(p.Numero_Exterior,'')+', '+ISNULL(C.Nombre_Colonia,' ')+','+isnull(cast(C.Codigo_Postal as varchar),'')+' '+ISNULL(L.Nombre_Localidad,'')+' '+ISNULL(E.DESCRIPCION,' ') domiCompleto,
	s.id_motivo_bloqueo,	
	P.*
	FROM HAPE..PERSONA  P
	LEFT JOIN CNBV_MNPIO_COL C ON P.Id_Colonia_CNBV = C.Id_Colonia_CNBV
	LEFT JOIN CNBV_LOCALIDADES L ON L.Id_Localidad_CNBV = C.Id_Localidad_CNBV AND C.Id_Entidad_Federativa = L.Id_Entidad_Federativa
	LEFT JOIN ENTIDAD_FEDERATIVA E ON E.ID_ENTIDAD_FEDERATIVA  = C.Id_Entidad_Federativa
	LEFT JOIN BANCA..TBL_BANCA_SOCIOS  S ON BANCA.DBO.FN_BANCA_DESCIFRAR(S.NUMERO_SOCIO) = P.Numero AND P.Id_Tipo_Persona = @idTIpoPersona
	LEFT JOIN hape..TBL_CONTRATOS_HABERES CB ON CB.Numero = @numeroSocio  and  id_tipo_contrato = 3
	WHERE P.NUMERO = @numeroSocio 
	AND p.Id_Tipo_Persona =  @idTIpoPersona
	

 
end try
begin catch
	select 0 as estatus , ERROR_MESSAGE() AS mensaje 	
	
end catch

END
GO

GRANT  EXECUTE  ON [dbo].SP_BANCA_OBTIENE_SOCIO  TO [public]
GO

use hape
go

-- se crea procedimiento SP_BANCA_ACTUALIZAR_MONTO_BANDERA
if exists (select * from sysobjects where name like 'SP_BANCA_ACTUALIZAR_MONTO_BANDERA' and xtype = 'p' and db_name() = 'hape')
	drop proc SP_BANCA_ACTUALIZAR_MONTO_BANDERA
go

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20190114
Objetivo		Actualizar la bandera monto_actualizado pra enviar notificaci�n
Proyecto		Admin Banca
Ticket			ticket

*/

create proc

	SP_BANCA_ACTUALIZAR_MONTO_BANDERA
	
		-- par�metros
		
		@numero_socio int,
		@bandera bit,
		@id_tipo_contrato int = 3 

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
						
			
			end -- inicio
			
					begin -- validaciones
			
				if not exists(SELECT * FROM HAPE.DBO.PERSONA WHERE NUMERO = @numero_Socio)
					raiserror('El socio ingresado no existe',11,0)				

				--if exists (SELECT * FROM TBL_BANCA_SOCIOS WHERE numero_socio = @numero_Socio and (id_estatus_banca<6 and banca_activa=0))
				--	raiserror('El socio ingresado no tiene su cuenta de Banca Electr�nica Activa',11,0)
				if not exists(select * from HAPE..TBL_CONTRATOS_HABERES where numero = @numero_socio and id_tipo_contrato = @id_tipo_contrato)
				raiserror('El socio no ha celebrado su contrato',11,0)

				
			end -- validaciones
				update TBL_CONTRATOS_HABERES set 
					monto_actualizado = @bandera
				where numero=@numero_Socio and  id_tipo_contrato =@id_tipo_contrato;

				
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_ACTUALIZAR_MONTO_BANDERA to public

USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_VALIDA_EXISTE_CONTRATO]    Script Date: 16/01/2019 12:23:42 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- se crea procedimiento SP_BANCA_ACTUALIZAR_MONTO_BANDERA
if exists (select * from sysobjects where name like 'SP_BANCA_VALIDA_EXISTE_CONTRATO' and xtype = 'p' and db_name() = 'hape')
	drop proc SP_BANCA_VALIDA_EXISTE_CONTRATO
go


/*

Autor			Cristian Pérez
UsuarioRed		pegc837648
Fecha			20190116
Objetivo		validar si existe el contrato de banca
Proyecto		AdminBanca
Ticket			ticket

*/

create proc

	[dbo].[SP_BANCA_VALIDA_EXISTE_CONTRATO]
	
		-- parámetros
		
		@numero_socio int,
		@id_tipo_contrato int =3

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@contrato_celebrado bit,
						@monto_actualizado bit
						
			
			end -- inicio
			
					
				if not exists(select * from HAPE..TBL_CONTRATOS_HABERES where numero = @numero_socio and id_tipo_contrato = @id_tipo_contrato)
				begin
					select @contrato_celebrado = 0, @monto_actualizado= 0 
				end
				else
				begin
					select @contrato_celebrado = 1, @monto_actualizado = monto_actualizado from HAPE..TBL_CONTRATOS_HABERES where numero = @numero_socio and id_tipo_contrato = @id_tipo_contrato
				end

				
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,
					@contrato_celebrado contrato_celebrado,
					@monto_actualizado monto_actualizado
				
		end -- reporte de status
		
	end -- procedimiento
go
grant exec on SP_BANCA_VALIDA_EXISTE_CONTRATO to public
go
use hape
go

-- se crea procedimiento SP_CMV_OBTENER_GAT_NOMINAL_REAL
if exists (select * from sysobjects where name like 'SP_CMV_OBTENER_GAT_NOMINAL_REAL' and xtype = 'p' and db_name() = 'hape')
	drop proc SP_CMV_OBTENER_GAT_NOMINAL_REAL
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20180114
Objetivo		Obtener gat real y gat n�minal
Proyecto		Banca
Ticket			ticket

*/

create proc

	SP_CMV_OBTENER_GAT_NOMINAL_REAL	

	@numero int,	
	@id_mov int,
	@monto FLOAT,
	@plazo int=0,
	@fecha_apertura datetime null,
	@num_dpf bigint null

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@tasa FLOAT = 0,
						@tasaInflacion FLOAT= 0,
						@comisionDebito FLOAT= 0,
						@interes FLOAT= 0,
						@Pf_GATNominal FLOAT = 0.0,
						@Pf_GATReal FLOAT= 0.0,
						@periodicidad int=0,
						@monto_aux float=0,
						@cont int=0,
						@valores VARCHAR(4000),
						@tir float,
						@gat_nominal float,
						@gat_Real float

						
						create table #tasas(
							status int,
							tasa float,
							tasaInflacion float,
							comisionDebito float,
							minimo float
						)

						create table #tempflujo(
							flujo int,
							valor float
						)
			
			end -- inicio	
			
			
			begin -- �mbito de la actualizaci�n
			
			IF(@id_mov=105)
			begin
				insert into #tasas(status,tasa,tasaInflacion,comisionDebito,minimo)
				EXEC SP_GATREAL_OBTENER_TASAS @id_mov,@monto,@fecha_apertura,@plazo,1,@numero,@num_dpf
			end
			else
			begin   
				insert into #tasas(status,tasa,tasaInflacion,comisionDebito,minimo)
				EXEC SP_GATREAL_OBTENER_TASAS @id_mov,@monto,NULL,NULL,1,@numero, NULL
			end

			  select 
			  @tasaInflacion=tasaInflacion,@comisionDebito=comisionDebito,
			  @tasa=case when @monto<minimo then 0 else tasa end
			  from #tasas

			   if(@tasa<>0)
			   begin
				select @periodicidad=case when @id_mov=105 then Round(365 / @plazo,0) else 12 end


				   while(@cont<=@periodicidad)
				   begin

						insert into #tempflujo 
						values(@cont,0)
         
						select @cont=@cont+1

				   end
			   end
     

			   update #tempflujo set valor=-(@monto+@comisionDebito) where flujo=0

			   select @monto_aux=@monto


			   select @cont=0

   				while(@cont<=@periodicidad)
				begin
					if(@cont+1=@periodicidad)
					begin
						if (@id_mov = 105)
							update #tempflujo set valor=((@monto * ((@tasa / 100) / @periodicidad)) + @monto) where flujo=@cont+1           
						else
						begin
						  select @interes = @monto_Aux * ((@tasa / 100) / 12);
						  update #tempflujo set valor=@monto + @interes where flujo=@cont+1             
						  select @monto_Aux = @monto_Aux;
						end;
					end
					else
					begin
		  
					  if(@id_mov=105)
					  begin
						  update #tempflujo set valor=(@monto * ((@tasa / 100) / @periodicidad)) where flujo=@cont+1
					  end
					  else
					  begin
					   select @interes= @monto_aux * ((@tasa / 100) / 12);
					   update #tempflujo set valor=@interes where flujo=@cont+1
					   select @monto_aux = @monto_aux;
					  end

					end
					select @cont=@cont+1
				end
	

				SELECT @valores= COALESCE(@valores + ', ', '') + cast(valor as varchar) FROM #tempflujo
				select @tir=[dbo].[fn_IRR](@valores) * 100
	

				if(@monto=0)
				begin
				  select @gat_nominal=0
				end
				else
				begin
				 select @gat_nominal=ROUND((Power((1 + (@tir / 100)), @periodicidad) - 1) * 100,2)
				end

				select @gat_Real=Round(((((@gat_nominal / 100) + 1) / ((@tasaInflacion / 100) + 1)) - 1) * 100, 2);
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,
					@gat_nominal gat_nominal,
					@gat_Real gat_real


             drop table #tasas
             drop table #tempflujo
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_CMV_OBTENER_GAT_NOMINAL_REAL to public

use hape
go

-- se crea procedimiento SP_CONTRATOS_ACTUALIZA_ESTATUS_ENVIO_CONSTANCIA
if exists (select * from sysobjects where name like 'SP_CONTRATOS_ACTUALIZA_ESTATUS_ENVIO_CONSTANCIA' and xtype = 'p' and db_name() = 'hape')
	drop proc SP_CONTRATOS_ACTUALIZA_ESTATUS_ENVIO_CONSTANCIA
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20180102
Objetivo		Actualizar el estatus de envio de constancia
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_CONTRATOS_ACTUALIZA_ESTATUS_ENVIO_CONSTANCIA
	
	@num_dpf bigint,
	@id_status int,
	@msg_error varchar(500)

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''

			
			end -- inicio

			begin -- �mbito de la actualizaci�n
			
				UPDATE TBL_CONTRATOS_HABERES_CONSTANCIA SET
				id_estatus_envio=@id_status,
				fecha_envio=case when @id_status=3 then GETDATE() else null end,
				msg_error=@msg_error 
				where num_dpf=@num_dpf

			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_CONTRATOS_ACTUALIZA_ESTATUS_ENVIO_CONSTANCIA to public

use hape
go

-- se crea procedimiento SP_CONTRATOS_CONSULTA_CONSTANCIA_DPF_PENDIENTE_ENVIAR
if exists (select * from sysobjects where name like 'SP_CONTRATOS_CONSULTA_CONSTANCIA_DPF_PENDIENTE_ENVIAR' and xtype = 'p' and db_name() = 'hape')
	drop proc SP_CONTRATOS_CONSULTA_CONSTANCIA_DPF_PENDIENTE_ENVIAR
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20181228
Objetivo		Consultar las constancias pendientes por enviar
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_CONTRATOS_CONSULTA_CONSTANCIA_DPF_PENDIENTE_ENVIAR	
	
	
as

	begin -- procedimiento
	
		declare @id_constancia int=0

		if (select count(*) from TBL_CONTRATOS_HABERES_CONSTANCIA  where  id_estatus_envio=2 ) = 0
		begin

			 select @id_constancia =min (id_constancia) from TBL_CONTRATOS_HABERES_CONSTANCIA  where id_estatus_envio=1

			 select conts.num_dpf,movs.Numero,per.Id_de_Sucursal,suc.Ciudad 
			 from TBL_CONTRATOS_HABERES_CONSTANCIA conts
			 join MOVIMIENTOS movs on conts.num_dpf=movs.Num_DPF and Id_tipomov=41 and Activo='T'
			 join PERSONA per on movs.Numero=per.Numero and movs.Id_Tipo_persona=per.Id_Tipo_Persona 
			 join SUCURSALES suc on per.Id_de_Sucursal=suc.Id_de_Sucursal
			 where id_constancia=@id_constancia

			if @@rowCount > 0
			begin
				update [dbo].TBL_CONTRATOS_HABERES_CONSTANCIA set id_estatus_envio = 2 where id_constancia = @id_constancia
			end
			else
			begin
				update [dbo].TBL_CONTRATOS_HABERES_CONSTANCIA set id_estatus_envio = 4,msg_error='El plazo fijo no esta activo' where id_constancia = @id_constancia
			end
		end
		
	end -- procedimiento
go

grant exec on SP_CONTRATOS_CONSULTA_CONSTANCIA_DPF_PENDIENTE_ENVIAR to public


---------------
---------------  SP_COBRANZA_ACTUALIZA_DVENCIDOS_PAGO_GESTORES
---------------

USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_COBRANZA_ACTUALIZA_DVENCIDOS_PAGO_GESTORES]    Script Date: 17/04/2019 03:41:39 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Blanca Estela González Soto, Jose Adrian Coria
UsuarioRed		GOSB811264
Fecha			20190104
Objetivo		Actualiza los dias vencidos a cero para identificar que un socio ya liquido o esta al corriente con sus pagos
Proyecto		Pago de gestores
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_COBRANZA_ACTUALIZA_DVENCIDOS_PAGO_GESTORES]
	
		-- parametros
		-- [aquí van los parámetros] 
@numero int,
@num_ptmo varchar(16),
@id_mov int,
@fecha date
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',	
					    @id_esquema int, 
						@version_cal int,
						@diasV int,
						@saldo int					
			end -- inicio
			
			begin -- ámbito de la actualización
					select @id_esquema =id_esquema, @diasV=Dias_Vencidos from EDO_DE_CUENTA
					where numero=@numero and Id_mov=@id_mov and Num_ptmo=@num_ptmo

					if @id_esquema =1 and @diasV>0
					begin
						set @version_cal=(select max(version_calendario) from TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES where numero=@numero
						 and id_mov=@id_mov and num_ptmo=@num_ptmo)

						if not exists (select numero from TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES
						 where numero=@numero and id_mov=@id_mov and num_ptmo=@num_ptmo and capital_actual>0 and version_calendario=@version_cal and @fecha>cast(fecha_fin as date))
						 begin
						        if not exists(select Num_ptmo from TBL_COBRANZA_RESPONSABLE_DIAS_VENCIDOS where Num_ptmo=@num_ptmo and Fecha_alta=Cast(GETDATE() as date) and Dias_vencidos=0)
									Insert into TBL_COBRANZA_RESPONSABLE_DIAS_VENCIDOS(Num_ptmo,Dias_vencidos,Clave_responsable,FechaIni_responsable,FechaFin_responsable,Fecha_alta)
									values(@num_ptmo,0,'JC',GETDATE(),'',GETDATE())
						 end
					end

					else if @id_esquema in (2,3) and @diasV>0
					begin

							if not exists (
								select Numero from TBL_AUTOMOTRIZ_PTMOS					
								where Numero=@numero and Id_mov=@id_mov and Num_ptmo=@num_ptmo and Id_status=1 and @fecha>cast(Fecha_pago as date)

								union

								select Numero from TBL_HIPOTECARIO_PTMOS 
								where Numero=@numero
								and Id_mov=@id_mov and Num_ptmo=@num_ptmo and Id_status=1 and @fecha>cast(Fecha_pago as date)

								union

								select numero from TBL_NIVELADOS_PTMOS where numero=@numero
								and id_mov=@id_mov and num_ptmo=@num_ptmo and Id_status=1 and @fecha>cast(Fecha_pago as date)

								union

								select numero from TBL_CREDINOMINA_PTMOS where numero=@numero
								and id_mov=@id_mov and num_ptmo=@num_ptmo and Id_status=1 and @fecha>cast(Fecha_pago as date)

								union

								select numero from TBL_CREDINOMINA_PTMOS_CAJAS where numero=@numero
								and id_mov=@id_mov and num_ptmo=@num_ptmo and Id_status=1 and @fecha>cast(Fecha_pago as date)
	 	 
						 )
						 begin
						      if not exists(select Num_ptmo from TBL_COBRANZA_RESPONSABLE_DIAS_VENCIDOS where Num_ptmo=@num_ptmo and Fecha_alta=Cast(GETDATE() as date) and Dias_vencidos=0)
								Insert into TBL_COBRANZA_RESPONSABLE_DIAS_VENCIDOS(Num_ptmo,Dias_vencidos,Clave_responsable,FechaIni_responsable,FechaFin_responsable,Fecha_alta)
								values(@num_ptmo,0,'JC',GETDATE(),'',GETDATE())
						 end
					end
					else if @id_esquema =4 
					begin

					IF OBJECT_ID('tempdb..#saldos_revolvente') IS NOT NULL DROP TABLE #saldos_revolvente
					begin
					create table
											#saldos_revolvente
												(
												id_linea				int null,
												numero					int null,
												id_mov					int null,
												num_ptmo				varchar(14) null,
												planx					varchar(1) null,
												saldo_actual			money null,
												id_estado				int null,
												cv_diaria				bit null,
												fecha_traspaso_CV		datetime null,
												dias_vencidos			int null,
												periodos_vencidos		int null,
												fecha_ultimo_abono		datetime null,
												fecha_ultimo_int_ord	datetime null,
												fecha_ultimo_int_mor	datetime null,
												moratorios				money null,
												iva_moratorios			money null,
												ordinarios_vencidos		money null,
												iva_ordinarios_vencidos	money null,
												ordinarios_corte		money null,
												iva_ordinarios_corte	money null,
												capital_vencido			money null,
												capital_corte			money null,
												ordinarios_al_hoy		money null,
												iva_ordinarios_al_hoy	money null,
												capital_no_devengado	money null,
												pago_minimo				money null,
												pago_minimo_total		money null,
												pago_liquidacion		money null,
												pago_liquidacion_total	money null,
												gastos_cobranza			money null,
												iva_gastos_cobranza		money null,
												tasa_gastos_cobranza	float null,
												seguro_vida			money null,
												seguro_danos			money null,
												)
					end

							exec SP_REVOLVENTE_OBTIENE_SALDOS @numero,@fecha

							if(select capital_vencido from #saldos_revolvente)=0 and (select dias_vencidos from #saldos_revolvente)>0
							begin
							  if not exists(select Num_ptmo from TBL_COBRANZA_RESPONSABLE_DIAS_VENCIDOS where Num_ptmo=@num_ptmo and Fecha_alta=Cast(GETDATE() as date) and Dias_vencidos=0)
								Insert into TBL_COBRANZA_RESPONSABLE_DIAS_VENCIDOS(Num_ptmo,Dias_vencidos,Clave_responsable,FechaIni_responsable,FechaFin_responsable,Fecha_alta)
								values(@num_ptmo,0,'JC',GETDATE(),'',GETDATE())
							end

					end	
					else
					begin --Checar los liquidados
					
					--select @saldo=Saldo_Actual from EDO_DE_CUENTA where numero=@numero and Id_mov=@id_mov and Num_ptmo=@num_ptmo and Activo='T'
					set @saldo=(select Saldo_Actual from EDO_DE_CUENTA where numero=@numero and Id_mov=@id_mov  and Num_ptmo=@num_ptmo
					union 
					select saldo_actual from TBL_REVOLVENTE_LINEAS_CREDITO where numero=@numero and @id_mov=10)

					if @saldo=0
					  begin
					   if not exists(select Num_ptmo from TBL_COBRANZA_RESPONSABLE_DIAS_VENCIDOS where Num_ptmo=@num_ptmo and Fecha_alta=Cast(GETDATE() as date) and Dias_vencidos=0)
							Insert into TBL_COBRANZA_RESPONSABLE_DIAS_VENCIDOS(Num_ptmo,Dias_vencidos,Clave_responsable,FechaIni_responsable,FechaFin_responsable,Fecha_alta)
							values(@num_ptmo,0,'JC',GETDATE(),'',GETDATE())

					  end

					End				

				
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

---------------
---------------  SP_REVOLVENTE_OBTIENE_SALDOS
---------------


USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_REVOLVENTE_OBTIENE_SALDOS]    Script Date: 17/04/2019 12:54:10 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Mar Mejía Murillo
UsuarioRed		memm373565
Fecha			20181026
Objetivo		Obtiene la cantidad de rubros de pago pendiente de un crédito revolvente
Proyecto		Crédito revolvente
Ticket			______

*/

ALTER proc

	[dbo].[SP_REVOLVENTE_OBTIENE_SALDOS]
	
		@numero	int,
		@fecha	datetime = null
	
as

	begin -- procedimiento
	
		begin try -- try principal

			set nocount on

			begin -- declaraciones

				declare	@sql nvarchar(4000) = 'delete #saldos_revolvente',
						@standalone bit = 1,
						@tasa_iva float =
							(
							select	tasa * 1e-2
							from	tasas
							where	contador =
										(
										select	max(contador)
										from	tasas
										where id_mov = 111
										)
							),
						@id_linea bigint

				select @fecha = cast(coalesce(@fecha, getdate()) as date)

				begin try -- revisar tabla de resultados

					exec (@sql)

					select @standalone = 0

				end try  -- revisar tabla de resultados

				begin catch  -- error al revisar tabla de resultados

					create table
						#saldos_revolvente
							(
							id_linea				int null,
							numero					int null,
							id_mov					int null,
							num_ptmo				varchar(14) null,
							planx					varchar(1) null,
							saldo_actual			money null,
							id_estado				int null,
							cv_diaria				bit null,
							fecha_traspaso_CV		datetime null,
							dias_vencidos			int null,
							periodos_vencidos		int null,
							fecha_ultimo_abono		datetime null,
							fecha_ultimo_int_ord	datetime null,
							fecha_ultimo_int_mor	datetime null,
							moratorios				money null,
							iva_moratorios			money null,
							ordinarios_vencidos		money null,
							iva_ordinarios_vencidos	money null,
							ordinarios_corte		money null,
							iva_ordinarios_corte	money null,
							capital_vencido			money null,
							capital_corte			money null,
							ordinarios_al_hoy		money null,
							iva_ordinarios_al_hoy	money null,
							capital_no_devengado	money null,
							pago_minimo				money null,
							pago_minimo_total		money null,
							pago_liquidacion		money null,
							pago_liquidacion_total	money null,
							gastos_cobranza			money null,
							iva_gastos_cobranza		money null,
							tasa_gastos_cobranza	float null,
							seguro_vida			money null,
							seguro_danos			money null,
							)

				end catch  -- error al revisar tabla de resultados

				create table
					#SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR
						(
						status					int null,
						error_procedure			varchar(255) null,
						error_line				varchar(255) null,
						error_severity			varchar(255) null,
						error_message			varchar(255) null,
						seguro_vida				money null,
						seguro_daños			money null,
						int_mor					money null,
						iva_int_mor				money null,
						int_ord_ven				money null,
						iva_int_ord_ven			money null,
						int_ord_vig				money null,
						iva_int_ord_vig			money null,
						cap_ven					money null,
						cap_vig					money null,
						int_ord_hoy				money null,
						iva_int_ord_hoy			money null,
						cap_no_dev				money null,
						gastos_cobranza			money null,
						iva_gastos_cobranza		money null,
						tasa_gastos_cobranza	float null,
						monto_a_pagar			money null,
						no_asignado				money null,
						saldo_actual			money null,
						saldo_ahorro			money null,
						saldo_inver				money null,
						saldo_debito			money null,
						)

			end -- declaraciones

			begin -- preparacion

				insert	#saldos_revolvente
						(
						id_linea,
						numero,
						id_mov,
						num_ptmo,
						planx,
						saldo_actual,
						id_estado,
						cv_diaria,
						fecha_traspaso_CV,
						dias_vencidos,
						periodos_vencidos,
						fecha_ultimo_abono,
						fecha_ultimo_int_ord,
						fecha_ultimo_int_mor,
						seguro_vida,
						seguro_danos
						)
				select	id_linea,
						numero,
						10,
						num_ptmo,
						planx,
						saldo_actual,
						id_estado,
						cv_diaria,
						fecha_traspaso_CV,
						dias_vencidos,
						periodos_vencidos,
						fecha_ultimo_abono,
						fecha_ultimo_int_ord,
						fecha_ultimo_int_mor,
						seguro_vida = 0,
						seguro_danos = 0
				from	vw_revolvente_lineas with (nolock)
				where	numero = @numero

				update	u
				set		moratorios = _.moratorios,
						iva_moratorios = _.iva_moratorios
				from	(
						select	c.id_linea,
								moratorios = sum(coalesce(int_mor_acum, 0)),
								iva_moratorios = sum(round(coalesce(int_mor_acum, 0) * @tasa_iva, 2))
						from	#saldos_revolvente r
								join vw_revolvente_ciclos c with (nolock)
									on c.id_linea = r.id_linea
									and c.ciclo_activo = 1
									and c.disposicion_activa = 1
									and c.capital > 0
								group by
									c.id_linea
						) _
						join #saldos_revolvente u
							on u.id_linea = _.id_linea

				update	u
				set		ordinarios_vencidos = _.ordinarios_vencidos,
						iva_ordinarios_vencidos = _.iva_ordinarios_vencidos
				from	(
						select	d.id_linea,
								ordinarios_vencidos = sum(coalesce(int_ord_ven_acum, 0)),
								iva_ordinarios_vencidos = sum(round(coalesce(int_ord_ven_acum, 0) * @tasa_iva, 2))
						from	#saldos_revolvente r
								join vw_revolvente_disposiciones d with (nolock)
									on d.id_linea = r.id_linea
									and d.disposicion_activa = 1
									and d.saldo_disposicion > 0
						group by
								d.id_linea
						) _
						join #saldos_revolvente u
							on u.id_linea = _.id_linea

				update	u
				set		ordinarios_corte = _.ordinarios_corte,
						iva_ordinarios_corte = _.iva_ordinarios_corte
				from	(
						select	d.id_linea,
								ordinarios_corte = sum(coalesce(int_ord_corte_acum, 0)),
								iva_ordinarios_corte = sum(round(coalesce(int_ord_corte_acum, 0) * @tasa_iva, 2))
						from	#saldos_revolvente r
								join vw_revolvente_disposiciones d with (nolock)
									on d.id_linea = r.id_linea
									and d.disposicion_activa = 1
									and d.saldo_disposicion > 0
						group by
								d.id_linea
						) _
						join #saldos_revolvente u
							on u.id_linea = _.id_linea

				update	u
				set		ordinarios_al_hoy = _.ordinarios_al_hoy,
						iva_ordinarios_al_hoy = _.iva_ordinarios_al_hoy
				from	(
						select	d.id_linea,
								ordinarios_al_hoy = sum(coalesce(int_ord_vig_acum, 0)),
								iva_ordinarios_al_hoy = sum(round(coalesce(int_ord_vig_acum, 0) * @tasa_iva, 2))
						from	#saldos_revolvente r
								join vw_revolvente_disposiciones d with (nolock)
									on d.id_linea = r.id_linea
									and d.disposicion_activa = 1
									and d.saldo_disposicion > 0
						group by
								d.id_linea
						) _
						join #saldos_revolvente u
							on u.id_linea = _.id_linea

				update	u
				set		capital_vencido = _.capital_vencido
				from	(						
						select	c.id_linea,
								capital_vencido = sum(coalesce(capital, 0))
						from	#saldos_revolvente r
								join vw_revolvente_ciclos c with (nolock)
									on c.id_linea = r.id_linea
									and c.ciclo_activo = 1
									and c.disposicion_activa = 1
									and fecha_limite < @fecha
						group by
								c.id_linea
						) _
						join #saldos_revolvente u
							on u.id_linea = _.id_linea

				update	u
				set		capital_no_devengado = _.capital_no_devengado
				from	(						
						select	c.id_linea,
								capital_no_devengado = sum(coalesce(capital, 0))
						from	#saldos_revolvente r
								join vw_revolvente_ciclos c with (nolock)
									on c.id_linea = r.id_linea
									and c.ciclo_activo = 1
									and c.disposicion_activa = 1
									and @fecha !> fecha_corte
						group by
								c.id_linea
						) _
						join #saldos_revolvente u
							on u.id_linea = _.id_linea

				update	#saldos_revolvente
				set		capital_corte = coalesce(saldo_actual, 0) - (coalesce(capital_vencido, 0) + coalesce(capital_no_devengado, 0))

				update	#saldos_revolvente
				set		pago_minimo =
							coalesce(moratorios, 0)
							+ coalesce(iva_moratorios, 0)
							+ coalesce(ordinarios_vencidos, 0)
							+ coalesce(iva_ordinarios_vencidos, 0)
							+ coalesce(ordinarios_corte, 0)
							+ coalesce(iva_ordinarios_corte, 0)
							+ coalesce(capital_vencido, 0)
							+ coalesce(capital_corte, 0)

				update	#saldos_revolvente
				set		pago_liquidacion =
							coalesce(moratorios, 0)
							+ coalesce(iva_moratorios, 0)
							+ coalesce(ordinarios_vencidos, 0)
							+ coalesce(iva_ordinarios_vencidos, 0)
							+ coalesce(ordinarios_corte, 0)
							+ coalesce(iva_ordinarios_corte, 0)
							+ coalesce(capital_vencido, 0)
							+ coalesce(capital_corte, 0)
							+ coalesce(ordinarios_al_hoy, 0)
							+ coalesce(iva_ordinarios_al_hoy, 0)
							+ coalesce(capital_no_devengado, 0)

				declare @_num_ptmo varchar(14),
						@_int_mor money,
						@_iva_int_mor money,
						@_int_ord_ven money,
						@_iva_int_ord_ven money,
						@_int_ord_vig money,
						@_iva_int_ord_vig money,
						@_cap_ven money,
						@_cap_vig money,
						@_int_ord_hoy money,
						@_iva_int_ord_hoy money,
						@_cap_no_dev money

				

				select	@_num_ptmo = num_ptmo,
						@_int_mor = moratorios,
						@_iva_int_mor = iva_moratorios,
						@_int_ord_ven = ordinarios_vencidos,
						@_iva_int_ord_ven = iva_ordinarios_vencidos,
						@_int_ord_vig = ordinarios_corte,
						@_iva_int_ord_vig = iva_ordinarios_corte,
						@_cap_ven = capital_vencido,
						@_cap_vig = capital_corte,
						@_int_ord_hoy = ordinarios_al_hoy,
						@_iva_int_ord_hoy = iva_ordinarios_al_hoy,
						@_cap_no_dev = capital_no_devengado
				from	#saldos_revolvente

				exec SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR
					@numero = @numero,
					@id_mov = 10,
					@num_ptmo = @_num_ptmo,
					@monto_a_pagar = null,
					@seguro_vida = 0,
					@seguro_daños = 0,
					@int_mor = @_int_mor,
					@iva_int_mor = @_iva_int_mor,
					@int_ord_ven = @_int_ord_ven,
					@iva_int_ord_ven = @_iva_int_ord_ven,
					@int_ord_vig = @_int_ord_vig,
					@iva_int_ord_vig = @_iva_int_ord_vig,
					@cap_ven = @_cap_ven,
					@cap_vig = @_cap_vig,
					@int_ord_hoy = @_int_ord_hoy,
					@iva_int_ord_hoy = @_iva_int_ord_hoy,
					@cap_no_dev = @_cap_no_dev,
					@fecha = @fecha

					--print '>>>>'
					--print	@numero
					--print	@_num_ptmo
					--print	null
					--print	@_int_mor
					--print	@_iva_int_mor
					--print	@_int_ord_ven
					--print	@_iva_int_ord_ven
					--print	@_int_ord_vig
					--print	@_iva_int_ord_vig
					--print	@_cap_ven
					--print	@_cap_vig
					--print	@_int_ord_hoy
					--print	@_iva_int_ord_hoy
					--print	@_cap_no_dev
					--print	'<<<<<<'




--				select * from #SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR-------------

				update	s
				set		gastos_cobranza = d.gastos_cobranza,
						iva_gastos_cobranza = d.iva_gastos_cobranza,
						tasa_gastos_cobranza = d.tasa_gastos_cobranza,
						pago_minimo_total = pago_minimo + d.gastos_cobranza + d.iva_gastos_cobranza,
						pago_liquidacion_total = pago_liquidacion + d.gastos_cobranza + d.iva_gastos_cobranza
				from	#SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR d
						cross join #saldos_revolvente s

			end -- preparacion

		end try -- try principal
		
		begin catch -- catch principal
		
			delete #saldos_revolvente

		end catch -- catch principal

		begin -- resultados

			if @standalone = 1

				select	--id_linea,
						--numero,
						--id_estado,
						--moratorios,
						--iva_moratorios,
						--ordinarios_vencidos,
						--iva_ordinarios_vencidos,
						--ordinarios_corte,
						--iva_ordinarios_corte,
						--capital_vencido,
						--capital_corte,
						--ordinarios_al_hoy,
						--iva_ordinarios_al_hoy,
						--capital_no_devengado,
						--pago_minimo,
						--pago_liquidacion
						*
				from	#saldos_revolvente

		end -- resultados
		
	end -- procedimiento

go


---------------
---------------  SP_REVOLVENTE_VALIDA_CANDADOS_DISPOSICION
---------------

USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_REVOLVENTE_VALIDA_CANDADOS_DISPOSICION]    Script Date: 17/04/2019 11:06:32 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Mar Mejía Murillo
UsuarioRed		memm373565
Fecha			20170106
Objetivo		Realiza las validaciones de negocio necesarias para determinar si una disposición tendría éxito o no antes de proceder con ella
Proyecto		Crédito Revolvente
Ticket			204020

*/

ALTER  proc

	[dbo].[SP_REVOLVENTE_VALIDA_CANDADOS_DISPOSICION]
	
		-- parámetros
		@id_linea			bigint,
		@numero				int,
		@monto				money,
		@fecha				datetime = null,
		@id_tipo_persona	int = null

as

	begin
		
		-- bloque principal
		begin try
		
			-- declaraciones internas
			declare	@status int = 1,
					@error_message varchar(255) = '',
					@error_line varchar(255) = '',
					@error_severity varchar(255) = '',
					@error_procedure varchar(255) = ''
		
			-- valores por defecto
			select	@id_tipo_persona = coalesce(@id_tipo_persona, 1),
					@fecha = coalesce(cast(@fecha as date), getdate())

			-- declaraciones auxiliares

			declare @disponible				money,
					@pago_minimo_completo	money = 0,
					@count					int = 0,
					@avalado				int,
					@pago_liquidacion		money

			declare	@sql nvarchar(4000) = 'delete #RESULTADOS_SP_REVOLVENTE_VALIDA_CANDADOS_DISPOSICION',
					@standalone bit = 1

			create table
				#obtiene_limites
					(
					id_linea			bigint null,
					id_estado			bit null,
					pago_minimo			money null,
					pago_liquidacion	money null,
					)

			create table
				#saldos_revolvente
					(
					id_linea				int null,
					numero					int null,
					id_mov					int null,
					num_ptmo				varchar(14) null,
					planx					varchar(1) null,
					saldo_actual			money null,
					id_estado				int null,
					cv_diaria				bit null,
					fecha_traspaso_CV		datetime null,
					dias_vencidos			int null,
					periodos_vencidos		int null,
					fecha_ultimo_abono		datetime null,
					fecha_ultimo_int_ord	datetime null,
					fecha_ultimo_int_mor	datetime null,
					moratorios				money null,
					iva_moratorios			money null,
					ordinarios_vencidos		money null,
					iva_ordinarios_vencidos	money null,
					ordinarios_corte		money null,
					iva_ordinarios_corte	money null,
					capital_vencido			money null,
					capital_corte			money null,
					ordinarios_al_hoy		money null,
					iva_ordinarios_al_hoy	money null,
					capital_no_devengado	money null,
					pago_minimo				money null,
					pago_minimo_total		money null,
					pago_liquidacion		money null,
					pago_liquidacion_total	money null,
					gastos_cobranza			money null,
					iva_gastos_cobranza		money null,
					tasa_gastos_cobranza	float null,
					seguro_vida				money null,
					seguro_danos			money null,
					)

			begin try -- se revisa si existe tabla de resultados

				exec (@sql)

				select @standalone = 0

			end try-- se revisa si existe tabla de resultados

			begin catch

				create table
					#RESULTADOS_SP_REVOLVENTE_VALIDA_CANDADOS_DISPOSICION
						(
						status			int null,
						error_procedure	varchar(255) null,
						error_line		varchar(255) null,
						error_severity	varchar(255) null,
						error_message	varchar(255) null,
						)

			end catch

			exec SP_REVOLVENTE_OBTIENE_SALDOS @numero, @fecha

			exec sp_revolvente_obtiene_limites @numero, @id_tipo_persona, @fecha

			select	@pago_liquidacion = pago_liquidacion,
					@pago_minimo_completo = pago_minimo
			from	#obtiene_limites

			insert	#obtiene_limites
					(
					id_estado,
					pago_minimo,
					pago_liquidacion
					)
			select	id_estado,
					pago_minimo_total,
					pago_liquidacion_total
			from	#saldos_revolvente

			/* Modificación - 20171005 - memm373565 - ticket 204020 - Se pide que el disponible se conforme por la diferencia de límite de crédito menos saldo actual */
			select	@disponible = round(limite_credito - saldo_actual, -2, 1)
--			select	@disponible = round(limite_credito - @pago_liquidacion, -2, 1)
			from	TBL_REVOLVENTE_LINEAS_CREDITO
			where	id_linea = @id_linea
					and numero = @numero
					and id_tipo_persona = @id_tipo_persona

			declare	@mensaje_1 varchar(255) = 'No existe el @id_linea indicado [ ' + cast(@id_linea as varchar(50)) + ' ] para el @numero de '
						+ case when @id_tipo_persona = 7 then 'persona moral' when @id_tipo_persona = 1 then 'socio' end
						+ ' indicado [ ' + cast(@numero as varchar(50)) + ' ]',
					@mensaje_2 varchar(255) = 'El monto indicado [ ' + cast(@monto as varchar(50)) + ' ] excede el monto disponible [ ' + cast(@disponible as varchar(50)) + ' ]',
					@mensaje_3 varchar(255) = 'El monto indicado [ ' + cast(@monto as varchar(50)) + ' ] no es múltiplo de 100.00;
sugerencias:
	' + cast(round(@monto, -2, 1) as varchar(50)) + '
	' + cast(round(@monto, -2, 1) + 100 as varchar(50)),
					@mensaje_4 varchar(255) = 'No se cumplen políticas para nueva disposición ['
			
			-- validación de parámetros

			-- validar la existencia de la línea
			if not exists (select * from tbl_revolvente_lineas_credito where id_linea = @id_linea and numero = @numero and id_tipo_persona = @id_tipo_persona)
				raiserror (@mensaje_1, 11, 0)

			-- validar que el monto a disponer se encuentre disponible
			if @monto > @disponible
				raiserror (@mensaje_2, 11, 0)

			-- validar que sea multiplo de 100
			if cast(@monto * cast(100 as money) as int) % 10000 != 0
				raiserror (@mensaje_3, 11, 0)

			-- validar que no tenga pago mínimo pendiente
			if coalesce(@pago_minimo_completo, 0) > 0 and exists (select 1 from VW_REVOLVENTE_CICLOS where id_linea = @id_linea and fecha_limite < @fecha and capital > 0)
			--if coalesce(@pago_minimo_completo, 0) > 0 and exists (select 1 from VW_REVOLVENTE_CICLOS where id_linea = @id_linea and fecha_corte !> @fecha and capital > 0)

				begin

					select @mensaje_4 = @mensaje_4 + 'No se ha saldado el pago mínimo]'
					raiserror (@mensaje_4, 11, 0)

				end

			-- validar que la línea no esté suspendida o cancelada
			if not exists (select * from tbl_revolvente_lineas_credito where id_linea = @id_linea and numero = @numero and id_tipo_persona = @id_tipo_persona and (id_estado = 1 or id_estado = 2 and @pago_minimo_completo = 0))

				begin

					select @mensaje_4 = @mensaje_4 + 'La línea se encuentra suspendida o cancelada]'
					raiserror (@mensaje_4, 11, 0)

				end

			-- validar que el socio no tenga mora en sus otros créditos vigentes

			if coalesce((select sum(saldo_actual) from edo_de_cuenta where numero = @numero and id_mov < 10 and dias_vencidos > 0), 0) > 0

				begin

					select @mensaje_4 = @mensaje_4 + 'El socio presenta mora en otros créditos]'
					raiserror (@mensaje_4, 11, 0)

				end

			-- validar que los créditos avalados por el socio no estén en mora ---------------------------- revisar con Roberto

			select	*
			into	#avalados_
			from	edo_de_cuenta
			where	aval1 like 's' + cast(@numero as varchar(10))
					or aval2 like 's' + cast(@numero as varchar(10))

			select	distinct numero, id_tipo_persona, cast(null as varchar(100)) nombre, null dias_vencidos, null ptmos_vencidos
			into	#avalados
			from	#avalados_

			update	a
			set		a.nombre = ltrim(rtrim(ltrim(rtrim(ltrim(rtrim(coalesce(p.Nombre_s, ''))) + ' ' + ltrim(rtrim(coalesce(p.apellido_paterno, ''))))) + ' ' + ltrim(rtrim(coalesce(p.apellido_materno, ''))))),
					a.dias_vencidos = coalesce(_.dias_vencidos, 0),
					a.ptmos_vencidos = coalesce(_.ptmos_vencidos, 0)
			from	#avalados a
					join persona p
						on p.numero = a.numero
						and p.id_tipo_persona = a.id_tipo_persona
					left join
						(
						select	numero,
								id_tipo_persona,
								count(1) ptmos_vencidos,
								sum(coalesce(dias_vencidos, 0)) dias_vencidos
						from	edo_de_cuenta
						where	numero in
									(
									select	numero
									from	#avalados
									)
								and Id_Tipo_persona = @id_tipo_persona
								and id_mov < 100
								and Dias_Vencidos > 0
								and Saldo_Actual > 0
						group by
								numero,
								Id_Tipo_persona
						) _
						on _.numero = a.numero
						and _.Id_Tipo_persona = a.Id_Tipo_persona

			select @count = count(1) from #avalados where dias_vencidos > 0

			if @count > 0

				begin

					if @count = 1

						begin

							select @avalado = min(numero) from #avalados

							select @mensaje_4 = 'Avalado se encuentra en atraso: '

							select @mensaje_4 = @mensaje_4 + (select cast(numero as varchar(10)) + ' ' + nombre + '' from #avalados where numero = @avalado)

							select @mensaje_4 = substring(@mensaje_4, 1, len(@mensaje_4) - 1) + ']'

							raiserror (@mensaje_4, 11, 0)

						end

					else

						begin

							select @avalado = min(numero) from #avalados

							select @mensaje_4 ='Avalados se encuentran en atraso: '

							while @avalado is not null

								begin

									select @mensaje_4 = @mensaje_4 +(select cast(numero as varchar(10)) + ' ' + nombre + '; ' from #avalados where numero = @avalado)

									select @avalado = min(numero) from #avalados where numero > @avalado

								end

							select @mensaje_4 = substring(@mensaje_4, 1, len(@mensaje_4) - 1) + ']'

							raiserror (@mensaje_4, 11, 0)

						end

				end

		

			
		
		end try
		
		-- en caso de error en bloque principal
		begin catch
		
			-- captura del error
			select	@status = 0,
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
						
			
		
		end catch
		
		-- reporte de status
		insert	#RESULTADOS_SP_REVOLVENTE_VALIDA_CANDADOS_DISPOSICION
				(
				status,
				error_procedure,
				error_line,
				error_severity,
				error_message
				)
		select	@status status,
				@error_procedure error_procedure,
				@error_line error_line,
				@error_severity error_severity,
				@error_message error_message--,
				--@id_disposicion id_disposicion

		if @standalone = 1

			select	*
			from	#RESULTADOS_SP_REVOLVENTE_VALIDA_CANDADOS_DISPOSICION
		
	end

go



USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_UNE_REGISTRA_REPORTE]    Script Date: 07/01/2019 12:05:17 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			EDUARDO LEMUS ZAVALA
UsuarioRed		LEZE667231
Fecha			20170629
Objetivo		VALIDAR SI EXISTE UN REGISTRO CON EL MISMO NUMERO DE FOLIO EN LA BASE DE DATOS
Proyecto		UNE
Ticket			

*/

ALTER proc [dbo].[SP_UNE_REGISTRA_REPORTE]
@NUM_FOLIO INT,
@ES_SOCIO INT,
@NUMERO INT = NULL,
@NOMBRE_S VARCHAR(60),
@APELLIDO_PATERNO VARCHAR(60),
@APELLIDO_MATERNO VARCHAR(60),
@TELEFONO VARCHAR(60) = NULL,
@TEL_CELULAR VARCHAR(60) = NULL,
@USUARIO_REGISTRA INT,
@ID_DE_SUCURSAL INT,
@DESCRIPCION_REPORTE VARCHAR(1000),
@ENTIDAD INT,
@IMPORTE_RECLAMACION MONEY,
@IMPORTE_SOLUCION MONEY,
@ID_TIPO_REPORTE INT,
@ID_SUPUESTOS_REPORTE INT,
@ID_MEDIO_CONTACTO INT,
@ID_ESTATUS_REPORTE INT,
@ID_TIPO_CUENTA INT,
@ID_CUENTA INT,
@ID_SUCURSAL_REGISTRO INT,
@DIAS_RESTANTES_GENERAL INT,
@Num_Tarjeta VARCHAR(16),
@DOMICILIO VARCHAR(200)
as
begin
	begin try

		DECLARE @FECHA_ALTA DATETIME = GETDATE(), @FECHA_CANALIZACION DATETIME

		IF(@ID_ESTATUS_REPORTE = 2)
			SET @FECHA_CANALIZACION = @FECHA_ALTA
		ELSE
			SET @FECHA_CANALIZACION = NULL

		DECLARE @ESTATUS INT

		IF((SELECT COUNT(1) FROM TBL_UNE_REPORTE WHERE NUM_FOLIO = @NUM_FOLIO AND NUM_FOLIO > 0) = 0)
		BEGIN
			/*INSERT INTO TBL_UNE_REPORTE VALUES(@NUM_FOLIO, @ES_SOCIO, @NUMERO, @NOMBRE_S, @APELLIDO_PATERNO, @APELLIDO_MATERNO, @TELEFONO, 
			@TEL_CELULAR, @FECHA_ALTA, @USUARIO_REGISTRA, @ID_DE_SUCURSAL, @DESCRIPCION_REPORTE, @ENTIDAD, @IMPORTE_RECLAMACION, @IMPORTE_SOLUCION,
			@ID_TIPO_REPORTE, @ID_SUPUESTOS_REPORTE, @ID_MEDIO_CONTACTO, @ID_ESTATUS_REPORTE, NULL, NULL, @ID_TIPO_CUENTA, @ID_CUENTA, NULL,
			@ID_SUCURSAL_REGISTRO, NULL, @FECHA_CANALIZACION, @DIAS_RESTANTES_GENERAL, NULL, 0,0, @Num_Tarjeta, 0,0,0,@DOMICILIO)*/

			SET @ESTATUS = 1

		END
		ELSE
			SET @ESTATUS = 2


		select @estatus as estatus

		
	end try
	begin catch

		SET	@estatus = 0
		SELECT @ESTATUS AS estatus
		
	end catch

end

go

USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_UNE_ENVIAR_CORREOS]    Script Date: 04/04/2019 01:16:33 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			EDUARDO LEMUS ZAVALA
UsuarioRed		LEZE667231
Fecha			20170210
Objetivo		ENVIAR CORREOS A LOS ENCARGADOS DE LOS FOLIOS QUE ESTEN CERCA DE VENCER O ESTEN VENCIDOS
Proyecto		UNE
Ticket			

*/

if exists (select * from sysobjects where name like 'SP_UNE_ENVIAR_CORREOS' and xtype = 'p')
	drop proc SP_UNE_ENVIAR_CORREOS
go

CREATE proc [dbo].[SP_UNE_ENVIAR_CORREOS]
as
begin

	--variables para guardar la informacion que sera enviada en el correo
	declare @status int = 1,@style nvarchar(max)='',@firma nvarchar(max)='',@subject varchar(100)='',@recipients nvarchar(max)='',
	@recipients_copy nvarchar(max)='',@receptor varchar(100)='',@body nvarchar(max)='',@fondo_correo nvarchar(max)=''

	--fecha del dia
	DECLARE @FECHA DATETIME = GETDATE(), @ANIO INT = DATEPART(YEAR,GETDATE())
	DECLARE @FECHA_INICIAL DATETIME = CONVERT(VARCHAR,DATEPART(YEAR,GETDATE()))+'0101'

	--guardamos los dias festivos del año en curso
	CREATE TABLE #TMP_DIAS_FESTIVOS_ANIO(DIA_FESTIVO DATETIME)
	INSERT INTO #TMP_DIAS_FESTIVOS_ANIO 
	SELECT DISTINCT(Dia_Festivo) FROM DIAS_FESTIVOS 
	WHERE CONVERT(VARCHAR,DIA_FESTIVO,112) >= CONVERT(varchar,@FECHA_INICIAL,112)
	AND DATEPART(dw,CONVERT(VARCHAR,DIA_FESTIVO,101)) NOT in('1','7') ORDER BY Dia_Festivo

	-- validamos si es dia entre semana y verificamos si este dia es dia festivo, para no generar el descuento de dias disponibles
	IF(DATEPART(dw,CONVERT(VARCHAR,@FECHA,101)) in('2','3','4','5','6'))
	begin
		IF((SELECT COUNT(1) FROM #TMP_DIAS_FESTIVOS_ANIO WHERE CONVERT(VARCHAR,DIA_FESTIVO,112)=CONVERT(VARCHAR,@FECHA,112))=0)
		BEGIN
			UPDATE TBL_UNE_REPORTE SET DIAS_RESTANTES_GENERAL = 
			CASE WHEN DIAS_RESTANTES_GENERAL -1 < 0 THEN 0 ELSE DIAS_RESTANTES_GENERAL -1 END WHERE ID_ESTATUS_REPORTE NOT IN(6,7,8,9)
			
			UPDATE TBL_UNE_REPORTE SET DIAS_RESTANTES_AREA_ESPECIALIZADA = 
			case when DIAS_RESTANTES_AREA_ESPECIALIZADA -1 < 0 then 0 else DIAS_RESTANTES_AREA_ESPECIALIZADA -1 end WHERE ID_ESTATUS_REPORTE IN(3,4,10) AND VoBo = 0
		END
	end

	-- borramos tabla temporal
	DROP TABLE #TMP_DIAS_FESTIVOS_ANIO

	-- variables para manejar el ciclo y enviar los corres
	DECLARE @MIN INT = 1, @MAX INT

	-- insertamos los reportes que esten a punto de vencerse y los que ya estan vencidos
	CREATE TABLE #TMP_NOTIFICAR_GENERAL(CONTADOR INT IDENTITY(1,1), FOLIO INT, NUM_FOLIO INT, NUMUSUARIO INT, CORREO VARCHAR(100), DIAS_GENERALES INT, DIAS_AREA_ESP INT, FOLIO_BANCA INT, REPORTE_BANCA BIT, ID_CUENTA INT)
	INSERT INTO #TMP_NOTIFICAR_GENERAL
	SELECT FOLIO, NUM_FOLIO, USUARIO_REGISTRA,NULL,DIAS_RESTANTES_GENERAL, DIAS_RESTANTES_AREA_ESPECIALIZADA, folio_banca, reporte_banca,ID_CUENTA
	FROM TBL_UNE_REPORTE WHERE ID_ESTATUS_REPORTE NOT IN(6,7,8,9) 
	AND (DIAS_RESTANTES_GENERAL IN(1,0) OR (DIAS_RESTANTES_AREA_ESPECIALIZADA IN(1,0) and VoBo = 0) ) AND (reporte_banca = 0 or reporte_banca is null)

	/*REPORTES DE BANCA*/
	INSERT INTO #TMP_NOTIFICAR_GENERAL
	SELECT FOLIO, NUM_FOLIO, USUARIO_REGISTRA,NULL,DIAS_RESTANTES_GENERAL, DIAS_RESTANTES_AREA_ESPECIALIZADA, folio_banca, reporte_banca, ID_CUENTA
	FROM TBL_UNE_REPORTE WHERE ID_ESTATUS_REPORTE NOT IN(6,7,8,9) 
	AND (DIAS_RESTANTES_GENERAL IN(1,0) OR (DIAS_RESTANTES_AREA_ESPECIALIZADA IN(1,0) and VoBo = 0) ) AND reporte_banca = 1
	AND ID_CUENTA IN(33,38,39)
	

	--SE ACTUALIZA EL NUMUSUARIO DE LOS RESPONSABLES DE REPORTES CANALIZADOS A AREAS QUE ESTEN A PUNTO DE VENCERCE
	UPDATE TMP SET TMP.NUMUSUARIO = USR.NUMUSUARIO FROM #TMP_NOTIFICAR_GENERAL TMP INNER JOIN TBL_UNE_USUARIOS_ASIGNADOS USR
	ON TMP.FOLIO = USR.folio WHERE USR.responsable = 1 AND TMP.DIAS_AREA_ESP IN (1,0)

	--actualizamos los correos de los usuarios a los que se les notificara
	UPDATE TMP SET TMP.CORREO = CL.CORREO FROM #TMP_NOTIFICAR_GENERAL TMP INNER JOIN CLAVES CL ON TMP.NUMUSUARIO = CL.NUMUSUARIO

	--obtenemos el numero de envios que se realizaran
	SELECT @MAX = MAX(CONTADOR) FROM #TMP_NOTIFICAR_GENERAL

	-- estilos del mensaje
	set @style=N'<style type="text/css">p,li {text-align:justify;font-family: Century Gothic,CenturyGothic,AppleGothic,sans-serif; font-size: 14px;}</style>'
	set @firma=N'<img src="firma_une.jpg" width=50/><br><br>'+
	N'ACATITA DE BAJAN No. 222, COL. LOMAS DE HIDALGO<br>' +
	N'TEL: (443) 3226-300, EXT. 11020 y 11021, MORELIA, MICH.<br>' + 
	N'LADA SIN COSTO: 01 800 3000 268<br>' +
	N'<a href="http://www.cajamorelia.com.mx/">www.cajamorelia.com.mx</a></p>'

	-- variables para obtener la informacion
	DECLARE @CORREO_USR VARCHAR(100), @DIASGEN INT, @DIASAREA INT, @NUMFOLIO INT, @tipoReporte varchar(100),@numero int, @numusaurio int, @nombre_resp varchar(100)
	,@nombre varchar(150), @supuesto varchar(150), @monto_rec money, @SUCURSAL VARCHAR(100), @estatus varchar(50), @REPORTE_BANCA BIT, @FOLIO_BANCA INT,@ID_CUENTA INT,
	@ENCABEZADO1 VARCHAR(200),@ENCABEZADOpropiedades varchar(200),@ENCABEZADOFOLIO VARCHAR(200), @subjectVencido varchar(200),@ENCABEZADO1Vencido varchar(200)
	-- enviamos el correo de cada caso
	WHILE(@MIN<=@MAX)
	BEGIN
	
		SELECT @CORREO_USR = CORREO, @DIASGEN = DIAS_GENERALES, @DIASAREA = DIAS_AREA_ESP, @NUMFOLIO = NUM_FOLIO, @numusaurio = NUMUSUARIO, @REPORTE_BANCA = REPORTE_BANCA, @FOLIO_BANCA = FOLIO_BANCA, @ID_CUENTA = ID_CUENTA
		FROM #TMP_NOTIFICAR_GENERAL WHERE CONTADOR  = @MIN

		select @tipoReporte=cat.DESCRIPCION,@numero=ISNULL(rep.numero,0),
		@nombre=rep.NOMBRE_S+' '+rep.APELLIDO_PATERNO+' '+rep.APELLIDO_MATERNO ,
		@supuesto = sup.DESCRIPCION, @monto_rec = ISNULL(rep.IMPORTE_RECLAMACION,0), @SUCURSAL = SUC.Descripcion,
		@estatus = EST.DESCRIPCION
		from TBL_UNE_REPORTE rep inner join CAT_UNE_TIPO_REPORTE cat
		on rep.ID_TIPO_REPORTE = cat.ID_TIPO_REPORTE
		inner join CAT_UNE_SUPUESTOS_REPORTE sup ON rep.ID_SUPUESTOS_REPORTE = sup.ID_SUPUESTOS_REPORTE
		INNER JOIN SUCURSALES SUC ON REP.ID_DE_SUCURSAL = SUC.Id_de_Sucursal
		INNER JOIN CAT_UNE_ESTATUS_REPORTE EST ON REP.ID_ESTATUS_REPORTE = EST.ID_ESTATUS_REPORTE
		where NUM_FOLIO = @NUMFOLIO

		SELECT @nombre_resp = NOMBRE_S+' '+APELLIDO_PATERNO+' '+APELLIDO_MATERNO FROM CLAVES
		WHERE Numusuario = @numusaurio

		IF(@REPORTE_BANCA = 1)
		BEGIN
			set @ENCABEZADO1='Por este medio le informamos que tiene un reporte de CMV Finanzas PENDIENTE DE CONCLUIR.<br/>'
			set @ENCABEZADOpropiedades = 'Propiedades del reporte:<br/>'
			SET @ENCABEZADOFOLIO = 'Folio CMV Finanzas: '+CONVERT(varchar,@FOLIO_BANCA)+'<br/>'
			set @subjectVencido = 'REPORTE CMV FINANZAS VENCIDO'
		END
		else
		BEGIN
			set @ENCABEZADO1='Por este medio le informamos que tiene una '+@tipoReporte+' PENDIENTE DE CONCLUIR.<br/>'
			set @ENCABEZADOpropiedades = 'Propiedades de la '+@tipoReporte+':<br/>'
			SET @ENCABEZADOFOLIO='Folio: '+CONVERT(varchar,@NUMFOLIO)+'<br/>'
			set @subjectVencido = 'REPORTE DE LA UNE VENCIDO'
		END


		IF(@DIASGEN = 1)
		BEGIN
			set @body=@fondo_correo+ @style + 'ASESOR ATENCIÓN A SOCIOS 01 800.<br/>';
			set @body=@body+'Presente.<br>'
			set @body=@body+@ENCABEZADO1
			set @body=@body+@ENCABEZADOpropiedades
			set @body=@body+'Sucursal de origén: '+@SUCURSAL+'<br/>'
			set @body=@body+'Nombre: '+@nombre+'<br/>'
			set @body=@body+@ENCABEZADOFOLIO
			set @body=@body+'Causas: '+@supuesto+'<br/>'
			if(@monto_rec>0)
				set @body=@body+'Monto: '+CONVERT(varchar,@monto_rec)+'<br/>'
			set @body=@body+'<br><br>'+@firma+'<br><br>'
			begin try
				EXEC msdb.dbo.sp_send_dbmail 
				@profile_name = 'UNEBANCA',
				--@profile_name = 'UNE',
				@recipients=@CORREO_USR,
				--@copy_recipients =@CorreoAsistente,
				@subject = 'REPORTE A UN DIA DE VENCIMIENTO',
				@body = @body,
				@file_attachments = 'C:\ImgCorreo\firma_une.jpg',
				@body_format = 'HTML';
			end try
			begin catch
				select	@status = 0
				raiserror('No se envió el correo correctamente', 12, 0)
			end catch

		END

		IF(@DIASGEN = 0)
		BEGIN
			--UPDATE TBL_UNE_REPORTE SET ID_ESTATUS_REPORTE = 8 WHERE NUM_FOLIO = @NUMFOLIO
			UPDATE TBL_UNE_REPORTE SET VENCIDO = 1 WHERE NUM_FOLIO = @NUMFOLIO
			set @body=@fondo_correo+ @style + 'ASESOR ATENCIÓN A SOCIOS 01 800.<br/>';
			set @body=@body+'Presente.<br>'
			IF(@REPORTE_BANCA =1)
			begin
				set @body=@body+'Por este medio le informamos que tiene un reporte de '+@tipoReporte+' VENCIDO.<br/>'
			end
			ELSE
			begin
				set @body=@body+'Por este medio le informamos que tiene una '+@tipoReporte+' VENCIDA.<br/>'
			end
			set @body=@body+@ENCABEZADOpropiedades
			if(@numero = 0)
				set @body=@body+'Número de socio: N/A<br/>'
			else
				set @body=@body+'Número de socio: '+CONVERT(varchar,@numero)+'<br/>'
			set @body=@body+'Nombre: '+@nombre+'<br/>'
			set @body=@body+@ENCABEZADOFOLIO
			set @body=@body+'Supuesto: '+@supuesto+'<br/>'
			if(@monto_rec>0)
				set @body=@body+'Monto: '+CONVERT(varchar,@monto_rec)+'<br/>'
			set @body=@body+'Tiempo de respuesta: INMEDIATA <br/>'
			set @body=@body+'<br><br>'+@firma+'<br><br>'
			begin try
				EXEC msdb.dbo.sp_send_dbmail 
				@profile_name = 'UNEBANCA',
				--@profile_name = 'Une',
				@recipients=@CORREO_USR,
				--@copy_recipients =@CorreoAsistente,
				@subject = @subjectVencido,
				@body = @body,
				@file_attachments = 'C:\ImgCorreo\firma_une.jpg',
				@body_format = 'HTML';
			end try
			begin catch
				select	@status = 0
				raiserror('No se envió el correo correctamente', 12, 0)
			end catch

		END

		IF(@DIASAREA = 1)
		BEGIN
			set @body=@fondo_correo+ @style + @nombre_resp+'<br/>';
			set @body=@body+'Presente.<br>'
			set @body=@body+@ENCABEZADO1
			set @body=@body+@ENCABEZADOpropiedades
			if(@numero = 0)
				set @body=@body+'Número de socio: N/A<br/>'
			else
				set @body=@body+'Número de socio: '+CONVERT(varchar,@numero)+'<br/>'
			set @body=@body+'Nombre: '+@nombre+'<br/>'
			set @body=@body+@ENCABEZADOFOLIO
			set @body=@body+'Supuesto: '+@supuesto+'<br/>'
			if(@monto_rec>0)
				set @body=@body+'Monto: '+CONVERT(varchar,@monto_rec)+'<br/>'

			set @body=@body+'Status: '+@estatus+' <br/>'
			set @body=@body+'<br><br>'+@firma+'<br><br>'

			begin try
				EXEC msdb.dbo.sp_send_dbmail 
				@profile_name = 'UNEBANCA',
				--@profile_name = 'une',
				@recipients=@CORREO_USR,
				--@copy_recipients =@CorreoAsistente,
				@subject = 'REPORTE CANALIZADO A AREA ESPECIFICA A UN DIA DE VENCIMIENTO',
				@body = @body,
				@file_attachments = 'C:\ImgCorreo\firma_une.jpg',
				@body_format = 'HTML';
			end try
			begin catch
				select	@status = 0
				raiserror('No se envió el correo correctamente', 12, 0)
			end catch
		END

		IF(@DIASAREA = 0)
		BEGIN
			--UPDATE TBL_UNE_REPORTE SET ID_ESTATUS_REPORTE = 9 WHERE NUM_FOLIO = @NUMFOLIO
			UPDATE TBL_UNE_REPORTE SET VENCIDO = 2 WHERE NUM_FOLIO = @NUMFOLIO
			set @body=@fondo_correo+ @style + @nombre_resp+'<br/>';
			set @body=@body+'Presente.<br>'
			if(@REPORTE_BANCA = 1)
			begin
				set @body=@body+'Por este medio le informamos que tiene un reporte de '+@tipoReporte+' VENCIDO.<br/>'
			end
			else
			begin
				set @body=@body+'Por este medio le informamos que tiene una '+@tipoReporte+' VENCIDA.<br/>'
			end
			
			set @body=@body+@ENCABEZADOpropiedades
			if(@numero = 0)
				set @body=@body+'Número de socio: N/A<br/>'
			else
				set @body=@body+'Número de socio: '+CONVERT(varchar,@numero)+'<br/>'
			set @body=@body+'Nombre: '+@nombre+'<br/>'
			set @body=@body+@ENCABEZADOFOLIO
			set @body=@body+'Supuesto: '+@supuesto+'<br/>'
			if(@monto_rec>0)
				set @body=@body+'Monto: '+CONVERT(varchar,@monto_rec)+'<br/>'
			set @body=@body+'Tiempo de respuesta: INMEDIATA <br/>'
			set @body=@body+'<br><br>'+@firma+'<br><br>'
			begin try
				EXEC msdb.dbo.sp_send_dbmail 
				@profile_name = 'UNEBANCA',
				--@profile_name = 'Une',
				@recipients=@CORREO_USR,
				--@copy_recipients =@CorreoAsistente,
				@subject = @subjectVencido,
				@body = @body,
				@file_attachments = 'C:\ImgCorreo\firma_une.jpg',
				@body_format = 'HTML';
			end try
			begin catch
				select	@status = 0
				raiserror('No se envió el correo correctamente', 12, 0)
			end catch
		END

		SET @MIN = @MIN + 1

	END

	DROP TABLE #TMP_NOTIFICAR_GENERAL
END
GO

grant exec on SP_UNE_ENVIAR_CORREOS to public
GO


use hape
go

-- se crea procedimiento SP_CEDICOOP_OBTENER_PERSONAS
if exists (select * from sysobjects where name like 'SP_CALLCENTER_GENERAR_FECHA_COMPROMISO_REPORTE' and xtype = 'p' and db_name() = 'hape')
	drop proc SP_CALLCENTER_GENERAR_FECHA_COMPROMISO_REPORTE
go

/*

Autor			Cristian Pérez
UsuarioRed		pegc837648
Fecha			20190625
Objetivo		Se genera una fecha de compromiso para el reporte
Proyecto		BANCA
Ticket			ticket

*/

create proc

	SP_CALLCENTER_GENERAR_FECHA_COMPROMISO_REPORTE
	
		-- parámetros
		@dias_resolucion int
		-- [aquí van los parámetros]

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''
				
			
			end -- inicio
			
			begin -- transacción
				declare

					@fecha_reporte datetime = getdate(), --'20191201',

					@fecha_solucion datetime,

					@fin_calculo int = 0
				
				select @fecha_solucion = @fecha_reporte

				while @dias_resolucion > 0

				begin

					if not exists(select * from hape..DIAS_FESTIVOS where convert(varchar,Dia_Festivo,112) = 

					convert(varchar,@fecha_solucion,112))

					begin

						IF(DATEPART(dw,CONVERT(VARCHAR,@fecha_solucion,101)) in('2','3','4','5','6'))

						begin

							select @dias_resolucion = @dias_resolucion - 1

						end

					end

					select @fecha_solucion = DATEADD(DAY,1,@fecha_solucion)

				end

				--select @fecha_solucion = DATEADD(DAY,-1,@fecha_solucion)
				
				select @fecha_solucion as FECHA_COMPROMISO_REPORTE
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
						
			-- revertir transacción si es necesario			
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			print ''
			-- select	@status status,
			--		@error_procedure error_procedure,
			--		@error_line error_line,
			--		@error_severity error_severity,
			--		@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_CALLCENTER_GENERAR_FECHA_COMPROMISO_REPORTE to public
go



USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_CALLCENTER_INSERTAR_REGISTRO_REPORTE]    Script Date: 25/06/2019 08:56:55 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian Pérez
UsuarioRed		pegc837648
Fecha			20181204
Objetivo		Insertar un registro de reporte en callcenter
Proyecto		callcenter
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_CALLCENTER_INSERTAR_REGISTRO_REPORTE' and xtype = 'p')
	drop proc SP_CALLCENTER_INSERTAR_REGISTRO_REPORTE
go

create proc


	[dbo].[SP_CALLCENTER_INSERTAR_REGISTRO_REPORTE]
	
		-- parámetros
		@numero_Socio bigint,
		@ID_SUPUESTOS_REPORTE bigint,
		@detalles_llamada varchar(max),
		@numero_usuario varchar(20) = null,
		@id_tipo_bitacora int
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@id_banca_folio int,						
						@tipo_origen INT = 4,
						@id_reporte int = 0
			
			end -- inicio
			
			begin -- validaciones
			
				if not exists(SELECT * FROM HAPE.DBO.PERSONA WHERE NUMERO = @numero_Socio)
					raiserror('El socio ingresado no existe',11,0)

			end -- validaciones
			
					INSERT INTO TBL_CALLCENTER_REGISTRO_REPORTE 
					(
						numero_socio,						
						detalles_llamada,
						fecha_registro_reporte,
						ID_SUPUESTOS_REPORTE
					) values

					(
						@numero_Socio,						
						@detalles_llamada, 
						getdate(),
						@ID_SUPUESTOS_REPORTE
					)

					SELECT @id_reporte = MAX(id_registro_reporte) FROM TBL_CALLCENTER_REGISTRO_REPORTE

					set @id_reporte = @id_reporte +1
					--WHERE
					--	numero_socio = @numero_Socio 
					--	AND ID_SUPUESTOS_REPORTE = @ID_SUPUESTOS_REPORTE
						

					if @ID_SUPUESTOS_REPORTE in(2172, 2171)
					begin
						update BANCA..TBL_BANCA_SOCIOS set recuperar_contrasena = 1, id_motivo_bloqueo = 6 where numero_socio = @numero_Socio

						IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
						BEGIN
						INSERT INTO 
							TBL_BANCA_BITACORA_OPERACIONES 
							(
									id_tipo_bitacora,
									numero_socio,
									fecha_alta,
									id_origen_operacion,
									usuario
							)
							VALUES 
							(
								 31 ,
								 @numero_socio ,
								 getdate() ,
								 @tipo_origen,
								 @numero_usuario
							)

							INSERT INTO 
							TBL_BANCA_BITACORA_OPERACIONES 
							(
									id_tipo_bitacora,
									numero_socio,
									fecha_alta,
									id_origen_operacion,
									usuario
							)
							VALUES 
							(
								 79 ,
								 @numero_socio ,
								 getdate() ,
								 @tipo_origen,
								 @numero_usuario
							)

						END

					end					
					else
					begin
						update BANCA..TBL_BANCA_SOCIOS set recuperar_contrasena = 0 where numero_socio = @numero_Socio

						IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
						BEGIN
						INSERT INTO 
							TBL_BANCA_BITACORA_OPERACIONES 
							(
									id_tipo_bitacora,
									numero_socio,
									fecha_alta,
									id_origen_operacion,
									usuario
							)
							VALUES 
							(
								 63 ,
								 @numero_socio ,
								 getdate() ,
								 @tipo_origen,
								 @numero_usuario
							)

						END

					end

		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
					
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message,
					@id_reporte as id_reporte
		end -- reporte de status
		
	end -- procedimiento
	go

	grant exec on SP_CALLCENTER_INSERTAR_REGISTRO_REPORTE to public
	go


go
use hape
go

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SP_SORTEO_VALIDA_BOLETO_ENTREGADO]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[SP_SORTEO_VALIDA_BOLETO_ENTREGADO]
GO

-- =============================================
-- Author:		Cristian Pérez García
-- Create date: 02/07/2019
-- Description:	Valida si a un socio ya se le han entregado boletos por actualizar su expediente anteriormente
-- =============================================
CREATE PROCEDURE SP_SORTEO_VALIDA_BOLETO_ENTREGADO
				@Numero int,
				@idTipoOperacion int


AS
BEGIN

	if exists(select * from tbl_sorteo_boletos where numero=@Numero and idEstatus in(2, 3) and idTipoOperacion=@idTipoOperacion)
		select 1 estatus
	else 
		select 0 estatus


END
GO

GRANT EXECUTE ON [dbo].SP_SORTEO_VALIDA_BOLETO_ENTREGADO TO [public] AS [dbo]
GO



USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_ATM_CANCELA_VALIDA_CUENTA]    Script Date: 04/11/2019 10:11:38 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*--------------------------------------------SP_ATM_CANCELA_VALIDA_CUENTA--------------------------------------
Autor:		Gustavo Negrete
Fecha:		25/06/2012
Descripcion:	Procedimiento que valida y consulta la cuenta de debito para su cancelacion.
--------------------------------------------------------------------------------------------------------------------------*/

ALTER   PROCEDURE [dbo].[SP_ATM_CANCELA_VALIDA_CUENTA]

@numero int

AS

declare @tarjeta_activa varchar(1),
	@Num_tarjeta	varchar(16),
	@saldo_actual 	money,
	@comisiones_pend int	
declare @tabla_comisiones table (numero int, fecha datetime, comision varchar(50), saldo_pendiente money)
	

select @tarjeta_activa=tarjeta_activa, @Num_tarjeta=Num_tarjeta, @saldo_actual=saldo_actual from edo_de_cuenta where numero=@numero and id_mov=112

--No tiene tarjeta activa
if @tarjeta_activa is null or @tarjeta_activa<>'T' or @Num_tarjeta is null or @Num_tarjeta=''
	begin
		select 1 as status
		return 1
	end
else if exists (select top 1 1 from hape..TBL_UNE_REPORTE where numero = @numero and ID_ESTATUS_REPORTE not in(6,7,8,9,10,11) and ID_TIPO_CUENTA in(6))
begin
	--select 2 as status, 'Reporte pendiente por resolver en CALL CENTER.' as mensajeBanca

	select 	datos_socio.Numero,
	Nombre_s,
	Apellido_Paterno,
	Apellido_Materno,
	id_de_sucursal,
	sucursal,
	@Num_tarjeta Num_tarjeta,
	@saldo_actual saldo_debito,
	@comisiones_pend as comisiones_pendientes,
	comision,
	fecha,
	isnull(saldo_pendiente , 0) as saldo_pendiente,
	2 as status,
	'Reporte pendiente por resolver en CALL CENTER.' as mensajeBanca
from 	(
	select 	numero,
		Nombre_s,
		Apellido_Paterno,
		Apellido_Materno,
		sucursales.id_dE_sucursal,
		sucursales.descripcion as sucursal,
		@saldo_actual saldo_debito,
		0 as status
	from 	persona inner join sucursales on
			persona.id_dE_sucursal=sucursales.id_de_sucursal
	where persona.numero=@numero and id_tipo_persona=1 
	) datos_socio left outer join @tabla_comisiones comisiones on
		datos_socio.numero=comisiones.numero

	return 2
end


--Comisiones pendientes
Insert into @tabla_comisiones
select 	numero, fecha, tipo_mov.Descripcion, saldo as saldo_pendiente
from 	tbl_atm_pago_de_comisiones inner join tipo_mov on
		tbl_atm_pago_de_comisiones.id_tipomov=tipo_mov.id_tipomov
where 	numero=@numero and pagada='F'

select @comisiones_pend=count(*) from @tabla_comisiones


select 	datos_socio.Numero,
	Nombre_s,
	Apellido_Paterno,
	Apellido_Materno,
	id_de_sucursal,
	sucursal,
	@Num_tarjeta Num_tarjeta,
	@saldo_actual saldo_debito,
	@comisiones_pend as comisiones_pendientes,
	comision,
	fecha,
	isnull(saldo_pendiente , 0) as saldo_pendiente,
	0 as status
from 	(
	select 	numero,
		Nombre_s,
		Apellido_Paterno,
		Apellido_Materno,
		sucursales.id_dE_sucursal,
		sucursales.descripcion as sucursal,
		@saldo_actual saldo_debito,
		0 as status
	from 	persona inner join sucursales on
			persona.id_dE_sucursal=sucursales.id_de_sucursal
	where persona.numero=@numero and id_tipo_persona=1 
	) datos_socio left outer join @tabla_comisiones comisiones on
		datos_socio.numero=comisiones.numero
	





return 0

GO

USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_ATM_MODIFICA_ESTADO_PROCESO_LAYOUT]    Script Date: 04/03/2020 11:58:51 a. m. ******/
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO

/* ----------------------------------SP_ATM_MODIFICA_ESTADO_PROCESO_LAYOUT----------------------------------

	AUTOR: 		MARIA DEL CARMEN ESTRADA IBARRA
	FECHA:			06/06/2012
	DESCRIPCION:		SP QUE REALIZA MODIFICACIONES DEPENDIENDO DEL 
				PROCESO EN EL QUE SE ENCUENTRE LA ACTIVACION DE 
				LA TARJETA DE DEBITO
	PROYECTO:		DEBITO

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

ALTER PROCEDURE [dbo].[SP_ATM_MODIFICA_ESTADO_PROCESO_LAYOUT]
	@NUMERO 		INT,
	@ID_STATUS 		INT,
	@ID_DOCUMENTO 	INT = NULL,
	@NUMUSUARIO 	INT = NULL
	, @idTipoProcesoTarjeta	int = null
 AS

DECLARE
	@MAX_CONTADOR	INT,
	@ID_SOLICITUD	INT,
	@T_STATUS		INT,
	@DESC		VARCHAR(60),
	@STATUS 		INT
		/*
			-10 - ERROR - STATUS INCORRECTO
			-9 - ERROR - NUMERO DE USUARIO INCORRECTO
			-8 - ERROR - IDENTIFICADOR DE DOCUMENTO INCORRECTO
			-7 - ERROR - NUMERO DE SOCIO INCORRECTO
			-6 - EL NOMBRE O LA DIRECCION DEL SOCIO NO EXISTEN (FAVOR DE PASAR CON EJECUTIVO PARA ACTUALIZAR ESTOS DATOS)
			-5 - ERROR AL MODIFICAR EN LOG DEL PROCESO - PAGO
			-4 - NO SE HA ACTIVADO LA SOLICITUD DE TARJETA  
			-3 - YA TIENE TARJETA DE DEBITO ACTIVA
			-2 -  ERROR AL MODIFICAR EN LOG DEL PROCESO - ACTIVA TARJETA
			-1 - ERROR AL INSERTAR LA SOLICITUD
			 0 - LAS MODIFICACIONES SE REALIZARON CORRECTAMENTE

		*/

-- SE VALIDA NUMERO DE SOCIO
IF(@NUMERO) IS NULL
BEGIN
	SET @STATUS = -7
	PRINT 'ERROR - NUMERO DE SOCIO INCORRECTO'
	GOTO EXIT_PROC 
END

--SI EL ID_STATUS NO ES EL CORRECTO, SE MANDA EL MENSAJE Y STATUS DE ERROR
IF(@ID_STATUS) NOT IN  (1,2)
BEGIN
	SET @STATUS = -10
	PRINT 'ERROR: STATUS INCORRECTO'
	GOTO EXIT_PROC
END

--SE OBTIENE EL ID_LOG_PROCESO DE LA ULTIMA SOLICITUD GUARDADA PARA EL SOCIO
SET @MAX_CONTADOR =  (SELECT MAX(TALP.ID_LOG_PROCESO) FROM TBL_ATM_LOG_PROCESO TALP INNER JOIN TBL_ATM_LAYOUT TAL ON TALP.ID_SOLICITUD = TAL.ID_SOLICITUD WHERE TAL.NUMERO = @NUMERO)

--SE OBTIENE LA ETAPA EN LA QUE SE ENCUENTRA EL PROCESO PARA LA SOLICITUD DE TARJETA DEL SOCIO
SELECT @T_STATUS = TALP.ID_STATUS, @DESC = CAT.DESCRIPCION FROM TBL_ATM_LOG_PROCESO TALP
	INNER JOIN TBL_ATM_LAYOUT TAL
		ON TALP.ID_SOLICITUD = TAL.ID_SOLICITUD AND TALP.ID_LOG_PROCESO = @MAX_CONTADOR
	INNER JOIN CAT_ATM_STATUS_TARJETA CAT 
		ON TALP.ID_STATUS = CAT.ID_STATUS
WHERE TAL.NUMERO=@NUMERO

--ACTIVAR TARJETA
IF(@ID_STATUS) = 1
	BEGIN
		--Se agrega inicializacion por migracion a Visa
		set @idTipoProcesoTarjeta = coalesce(@idTipoProcesoTarjeta, 1)
		--SE VALIDA IDENTIFICADOR DE DOCUMENTO
		IF(@ID_DOCUMENTO) IS NULL
		BEGIN
			SET @STATUS = -8
			PRINT 'ERROR - IDENTIFICADOR DE DOCUMENTO INCORRECTO'
			GOTO EXIT_PROC 
		END

		--SE VALIDA NUMERO DE USUARIO
		IF(@NUMUSUARIO) IS NULL
		BEGIN
			SET @STATUS = -9
			PRINT 'ERROR - NUMERO DE USUARIO INCORRECTO'
			GOTO EXIT_PROC 
		END

		--SE VALIDA QUE LOS DATOS DEL SOCIO NO ESTEN EN NULOS
		IF EXISTS(SELECT 1 FROM PERSONA WHERE NUMERO = @NUMERO AND ID_TIPO_PERSONA = 1 AND (ID_COLONIA_CNBV IS NULL OR NOMBRE_S IS NULL OR APELLIDO_PATERNO IS NULL OR APELLIDO_MATERNO IS NULL))
		BEGIN 
			SET @STATUS = -6
			PRINT 'EL NOMBRE O LA DIRECCION DEL SOCIO NO EXISTEN (FAVOR DE PASAR CON EJECUTIVO PARA ACTUALIZAR ESTOS DATOS)'
			GOTO EXIT_PROC
		END
		
		--SE VERIFICA LA ETAPA EN LA QUE SE ENCUENTRA EL PROCESO PARA LA SOLICITUD DE TARJETA DEL SOCIO
		/*
		STATUS
			  1 - ESTE SOCIO YA SOLICITO LA ACTIVACION
			  2 - ESTE SOCIO YA REALIZO EL PAGO DE LA TARJETA
			  3 - LA TARJETA PARA ESTE SOCIO YA AH SIDO SOLICITADA
			  4 - LA TRJETA PARA ESTE SOCIO YA AH SIDO ENVIADA A PAYWARE
			  5 - LA TARJETA PARA ESTE SOCIO YA AH SIDO RECIBIDA
			  7 - CANCELACION DE SOLICITUD DE TARJETA DE DEBITO
			  8 - ENVIADO A REVISION DE NOMBRE
			10 - PENDIENTE ENTREGA DE TARJETA
			13 - ENTREGA DE TARJETA
		*/
		IF(@T_STATUS IN (1,2,3,4,5,7,8,10,13))
		BEGIN
			SET @STATUS = @T_STATUS
			PRINT 'LA ULTIMA ETAPA REALIZADA PARA LA SOLICITUD DE TARJETA DE ESTE SOCIO ES: '+CAST(@T_STATUS AS VARCHAR)+ ' - ' +UPPER(@DESC)


			GOTO EXIT_PROC
		END
		
		--SI NO TIENE ALGUN REGISTRO DE SOLICITUD DE TARJETA O LA ETAPA EN LA QUE SE ENCUENTRA SON CANCELACIONES O DESACTIVACION DE TARJETA, SE INICIA TRANSACCION
		BEGIN TRAN
			--SE INSERTA SOLICITUD
					/*----------------MODIFICACION------------------- 
					AUTOR: MARIA DEL CARMEN ESTRADA IBARRA
					FECHA: 2013-09-03
					TICKET: T95682 CHIP DEBITO
					OBJETIVO: SE CONSIDERA INSERTAR CAMPO ID_TIPO_TARJETA
					*/
			INSERT INTO TBL_ATM_LAYOUT (NUMERO, ID_DOCUMENTO, ID_TIPO_TARJETA
			--Se agrega por migraicon a Visa
			, id_tipo_proceso_tarjeta) 
			VALUES (@NUMERO, @ID_DOCUMENTO, 2
			,@idTipoProcesoTarjeta)
			IF @@ERROR <> 0
				BEGIN
					ROLLBACK TRAN
					SET @STATUS = -1
					PRINT 'ERROR AL INSERTAR LA SOLICITUD'
					GOTO EXIT_PROC
				END

			SELECT @ID_SOLICITUD = MAX(ID_SOLICITUD) FROM TBL_ATM_LAYOUT WHERE NUMERO = @NUMERO AND ID_DOCUMENTO = @ID_DOCUMENTO
			
			--SE INSERTA EL LOG DEL PROCEDIMIENTO
			INSERT INTO TBL_ATM_LOG_PROCESO (ID_SOLICITUD, ID_STATUS,	FECHA_ACTIVACION,NUMUSUARIO_ACTIVA) VALUES (@ID_SOLICITUD, @ID_STATUS,GETDATE(),@NUMUSUARIO)				
			IF @@ERROR <> 0
			BEGIN
				ROLLBACK TRAN
				SET @STATUS = -2
				PRINT  'ERROR AL MODIFICAR EL LOG DEL PROCESO - ACTIVA TARJETA'
				GOTO EXIT_PROC
			END

			/*Se inserta la cuenta de corresponsalias si cuenta con el servicio activo*/
			IF((SELECT COUNT(1) FROM TBL_CORRESPONSALIAS_SERVICIOS WHERE NUMERO = @NUMERO AND ID_ESTATUS_ACTIVACION = 2 AND SERVICIO_ACTIVO = 1)>0)
			BEGIN

				IF((SELECT COUNT(1) FROM TBL_CORRESPONSALIAS_CUENTAS WHERE NUMERO = @NUMERO AND ID_MOV = 112)=0)
				BEGIN

					INSERT INTO TBL_CORRESPONSALIAS_CUENTAS
					VALUES(@NUMERO,'797001112'+RIGHT('0000000' + Ltrim(Rtrim(@NUMERO)),7),GETDATE(),112,null,1,null)

					IF @@ERROR<>0	
					BEGIN
						ROLLBACK TRAN
						SET @STATUS = -2
						PRINT  'ERROR AL INSERTAR LA CUENTA DE CORRESPONSALIAS'
						GOTO EXIT_PROC							
					END

				END

			END

		COMMIT TRAN

	END

--PAGO DE PLASTICO
IF(@ID_STATUS) = 2
	BEGIN
				
		--VALIDA SI EL SOCIO TIENE TARJETA DE DEBITO ACTIVA
		IF(SELECT TARJETA_ACTIVA FROM EDO_DE_CUENTA WHERE NUMERO = @NUMERO AND ID_MOV = 112 AND ID_TIPO_PERSONA = 1) = 'T'
		BEGIN
			SET @STATUS = -3
			PRINT 'YA TIENE TARJETA DE DEBITO ACTIVA'
			GOTO EXIT_PROC
		END 

		--VALIDA SI EL SOCIO NO HA ACTIVADO LA SOLICITUD DE TARJETA
		IF(@T_STATUS) IS NULL OR (@T_STATUS IN (6,9))
		BEGIN
			SET @STATUS = -4
			PRINT 'NO SE HA ACTIVADO LA SOLICITUD DE TARJETA' 
			GOTO EXIT_PROC
		END
		
		--VALIDA SI YA REALIZO EL PAGO DE PLASTICO O SE ENCUENTRE EN OTRA ETAPA PARA LA SOLICITUD DE TARJETA
		IF(@T_STATUS IN (2,3,4,5,6,7,8,9,10,13))
		BEGIN
			SET @STATUS = @T_STATUS
			PRINT 'LA ULTIMA ETAPA REALIZADA PARA LA SOLICITUD DE TARJETA DE ESTE SOCIO ES: '+CAST(@T_STATUS AS VARCHAR)+ ' - ' +UPPER(@DESC)
			GOTO EXIT_PROC
		END

		--Se agrega por migracion Visa
		--Ya que si se elije tarjeta Express se tiene que brincar hasta el estatus 10 para su entrega inmediata
		--Determinar el tipo de proceso de tarjeta que se solicito 
		select @idTipoProcesoTarjeta = coalesce(al.id_tipo_proceso_tarjeta, 0)
		from TBL_ATM_LOG_PROCESO alp
		join TBL_ATM_LAYOUT al
		on alp.id_solicitud = al.Id_solicitud
		where al.numero = coalesce(@numero, 0)
		
		--En caso de que no coincidan los filtros de la consulta para evitar el null
		select @idTipoProcesoTarjeta = coalesce(@idTipoProcesoTarjeta, 0)

		if @idTipoProcesoTarjeta = 2
			select @ID_STATUS = 10 --Estatus para su entrega en caso de que sea Express
		-----------------------------------------------------------------------------------------

		--SI PASA LAS VALIDACIONES ANTERIORES PUEDE COMENZAR CON EL PAGO DE LA TARJETA
		--SE INICIA TRANSACCION
		BEGIN TRAN
			--ACTUALIZA EL LOG DEL PROCESO PARA LA SOLICITUD DE TARJETA 
			UPDATE TALP 
			SET 	TALP.ID_STATUS =  @ID_STATUS,
				TALP.FECHA_PAGO = GETDATE()
			FROM TBL_ATM_LOG_PROCESO TALP
				INNER JOIN TBL_ATM_LAYOUT TAL
					ON TALP.ID_SOLICITUD = TAL.ID_SOLICITUD AND TALP.ID_LOG_PROCESO = @MAX_CONTADOR
			WHERE TAL.NUMERO = @NUMERO
			IF @@ERROR <> 0
			BEGIN
				ROLLBACK TRAN
				SET @STATUS = -5
				PRINT 'ERROR AL MODIFICAR EN LOG DEL PROCESO - PAGO'
				GOTO EXIT_PROC
			END		
		COMMIT TRAN
		
	END

SET @STATUS = 0
PRINT 'LAS MODIFICACIONES SE REALIZARON CORRECTAMENTE'		

EXIT_PROC:
SELECT @NUMERO AS SOCIO, @ID_STATUS AS STATUS_PROCESO,  @STATUS AS STATUS

SET ANSI_NULLS OFF

GO


USE [HAPE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian Pérez García
UsuarioRed		pegc837648
Fecha			20190729
Objetivo		Obtiene los prestamos actuales de un socio con respecto a un reporte de cmv finanzas
Proyecto		Banca/Poliza de diario (Actualizado)
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_BANCA_OBTENER_PRESTAMOS_SOCIO' and xtype = 'p')
	drop proc SP_BANCA_OBTENER_PRESTAMOS_SOCIO
go

create proc

	[dbo].[SP_BANCA_OBTENER_PRESTAMOS_SOCIO]
	
		-- parametros		
		@numero_socio int
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@fecha_actual datetime
						
					
			end -- inicio
			
			
			
			begin -- ámbito de la actualización
				
				print '' 
			
			end -- ámbito de la actualización

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DINÁMICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validación'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualización'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
		if @error_message<>''
		begin
			select	@estatus status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
		end
		else
		select @estatus estatus,
					edoCuenta.Id_mov, 
					tiposOperaciones.Desc_prestamo,
					corresponsalias.CUENTA, 
					edoCuenta.Ultimo_Abono,
					edoCuenta.Id_Esquema
				from 
					EDO_DE_CUENTA edoCuenta 
				inner join 
					TIPOS_de_OPERACIONES tiposOperaciones 
				on 
					(edoCuenta.Id_mov = tiposOperaciones.Id_mov)
				inner join
					TBL_CORRESPONSALIAS_CUENTAS corresponsalias
				on
					(edoCuenta.Id_mov = corresponsalias.ID_MOV)
				where 
					edoCuenta.Id_mov < 10
				and 
					edoCuenta.Saldo_Actual >0
				and 
					corresponsalias.NUMERO = edoCuenta.numero --839489
				and
					edoCuenta.numero = @numero_socio --839489 --848345
					
		end -- reporte de estatus
		
	end -- procedimiento
	go

	grant exec on SP_BANCA_OBTENER_PRESTAMOS_SOCIO to public
	go


USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_IMAGEN_VALIDA_PRECANCELACION]    Script Date: 11/09/2019 01:47:25 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			David López Fuentes
UsuarioRed		aaaa111111
Fecha			yyyymmdd
Objetivo		Valida que un socio cumpla con las codiciones para pre cancelarlo
Proyecto		Reingeneria Imagen
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_IMAGEN_VALIDA_PRECANCELACION]
	
		-- parametros
		@Numero int,
		@Id_tipo_persona int,
		@numusuario int	

as

	begin
		
		-- bloque principal
		begin try
		
			-- declaraciones internas
			declare @status int = 1,
					@error_message varchar(255) = ''						
			

        	CREATE TABLE #TempValidaciones (
			Motivo  varchar(250), 
			Descripcion varchar(250),
			Status int null
		    );

			create table #Coacreditado(
			NUMERO	int null,
			ID_PERSONA	int null,
			NOMBRE_SOCIO varchar(250) null, 
			ID_DE_SUCURSAL	int null,	
			SUCURSAL	varchar(100) null,	
			NUM_PTMO	varchar(14) null,	
			TIPO_REGISTRO	varchar(100) null,
			ID_MOV	int null,
			PUEDE_AVALAR BIT
		    );
			
			-- validación
			-- Se verifica si el socio existe en persona
			if not exists(select * from PERSONA where Numero=@Numero and Id_Tipo_Persona=@Id_tipo_persona)
				raiserror('El número de socio no existe', 11, 0)
            
			if ((select id_de_sucursal from persona where numero=@numero and id_tipo_persona=@id_tipo_persona) <>
			   (select id_de_sucursal from claves where numusuario=@numusuario))
			   raiserror('El socio no pertenece a tu sucursal', 11, 0)

			-- Se verifica que el socio que se intenta eliminar no sea el socio utilitario de la sucursal
			if exists(select * from Sucursales where socioutilitario=@numero and @Id_tipo_persona=1)
				raiserror('El numero de socio es un socio utilitario', 11,0);

		    -- Se verifica si el socio tiene bloqueo por exclusión
			if ((select bloqueado_exclusion from persona where numero=@Numero and id_tipo_persona=@Id_tipo_persona) = 'A')
				raiserror('El socio tiene bloqueo por exclusión', 11,0);

			--Se verifica que el socio no haya sido precancelado
			if exists (select 1	from precancelacion_log	where	numero =@Numero	and id_tipo_persona = @Id_tipo_persona	and activo = 'T' and id_status = 1)
			   raiserror('El socio ya fue precancelado', 11,0);

			--Se verifica que el socio no tenga CMV Finanzas activa
			--if exists (select 1 from BANCA..TBL_BANCA_SOCIOS where numero_socio = @Numero and id_estatus_banca<>9)
			--   raiserror('El socio tiene su cuenta de CMV Finanzas activa, se debe de cancelar su cuenta', 11,0);

			-- Inician Validaciones especificas
			begin try
			  
			 -- Se verifica si el socio tiene tarjeta de debito activa
            insert #TempValidaciones(Motivo, Descripcion)
			select 'Tiene tarjeta de Débito Activa',Num_tarjeta from edo_de_cuenta where numero=@numero and id_mov=112 and Tarjeta_activa='T' 

            -- Se verifica si el socio tiene comisones de debito
			insert #TempValidaciones(Motivo, Descripcion) 
			select 'Tiene comisiones pendientes de débito', '$' + cast(isnull(sum(MONTO),0) as varchar)
			from TBL_ATM_PAGO_DE_COMISIONES where NUMERO=@Numero and PAGADA='F' and @Id_tipo_persona=1
			having isnull(sum(MONTO),0)>0

			-- Se verifica si el socio no tiene algun proceso de débito pendiente
            insert #TempValidaciones(Motivo, Descripcion)
			SELECT 'Tiene el siguiente proceso pendiente de tarjeta de débito: ',CST.descripcion   
            FROM 
				TBL_ATM_LOG_PROCESO LP 
			INNER JOIN 
				TBL_ATM_LAYOUT AL  ON LP.id_solicitud = AL.Id_solicitud 
			INNER JOIN 
				CAT_ATM_STATUS_TARJETA CST ON LP.id_status = CST.id_status
			WHERE 
				AL.numero = @numero AND LP.id_status NOT IN (6,13) and @Id_tipo_persona=1;
            
			-- Se verifica que el socio no tenga inversion vigente
			insert #TempValidaciones(Motivo, Descripcion)
			select 'Tiene inversiones activas con un saldo de:','$' + cast(saldo_actual as varchar)
			from EDO_DE_CUENTA where numero=@numero and id_mov=105 and id_tipo_persona=@id_tipo_persona and Saldo_Actual>0

		   -- Se verifica si el socio no tiene algun prestamo
           insert #TempValidaciones(Motivo, Descripcion)
		   select 'Tiene el siguiente prestamo activo',op.Desc_prestamo
		   from EDO_DE_CUENTA ed
		   join TIPOS_DE_OPERACIONES op on ed.Id_mov=op.Id_mov
		    where numero=@numero and ed.id_mov<11 and Id_Tipo_persona=@Id_tipo_persona and Saldo_Actual>0

			insert #TempValidaciones(Motivo, Descripcion)
			select 'Tiene el siguiente menor relacionado:',
			isnull(per.Nombre_s, '') + ' ' + isnull(per.Apellido_Paterno, '') + ' ' + isnull(per.Apellido_Materno, '') 
			from 
				REFERENCIAS ref
					join 
				PERSONA per on ref.Id_Persona=per.Id_Persona
				  join
				TEXTOS on per.Id_Persona=TEXTOS.Id_persona
			where 
				ref.Numero=@Numero and ref.Id_de_Referencia=6 and @Id_tipo_persona=1
				and TEXTOS.Motivo_bloqueo<>'FALLECIMIENTO DEL TUTOR' and
				per.Numero not in (select numero from precancelacion_log
					where	numero = per.Numero
							and id_tipo_persona = per.Id_Tipo_Persona
							and activo = 'T'
							and id_status = 1) 
			order by ref.id_persona;

			-- se verifica si el socio escoacreditado

			--En base a SP de Garantias que busca cuando eres aval de algun credito
			--se obtienen estos incluyendo aquellos que vengan de un proceso de reestructuras o renovaciones
	
			insert into #Coacreditado 
			exec SP_VALIDAGARANTIA_BUSCAR_AVAL @Id_tipo_persona, @Numero;
	
			--Solo se deja aquel que coincida con el numero enviado para dejar solo coacreditados
			delete from #Coacreditado where NUMERO = @Numero;		

			--Se verifica que ese prestamo venga de un subproducto con descripcion coacreditado.
			insert #TempValidaciones(Motivo, Descripcion)
			SELECT 'El socio es coacreditado del siguiente numero de prestamo',coa.Num_ptmo
			from #Coacreditado coa
			join CRED_SOLICITUD_CREDITO csc
			on coa.Numero = csc.Numero and coa.Id_mov = csc.Id_Mov
			and coa.Num_ptmo collate traditional_spanish_ci_as = csc.id_sol collate traditional_spanish_ci_as 
			where csc.id_subproducto in (select Contador from CRED_PARAMS_PTMO where Descripcion like '%Coacreditado%')

			end try
			begin catch			    
				-- levantar error
				raiserror ('Error al realizar las validaciones', 12, 0)

			end catch
		
		end try
		
		-- en caso de error en bloque principal
		begin catch
		
			-- captura del error
			select	@status = 0,
					@error_message = error_message()

			delete #TempValidaciones
			insert into #TempValidaciones values (error_message(),'',0)

		
		end catch
		
		declare @nombre_socio varchar(255),@sucursal varchar(100)

		select @nombre_socio= nombre_s + ' ' + apellido_paterno + ' ' + apellido_materno ,
		       @sucursal=suc.Descripcion
		from 
		PERSONA per
		join SUCURSALES suc on per.Id_de_Sucursal=suc.Id_de_Sucursal
		where Numero=@Numero and Id_Tipo_Persona=@Id_tipo_persona

	
		-- reporte de status
		select Motivo,Descripcion,ISNULL(Status,1) Status ,@nombre_socio Nombre_socio,@sucursal sucursal
		from #TempValidaciones

		drop table #TempValidaciones
		drop table #Coacreditado;
		
	end

GO


USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_UNE_CARGA_COMENTARIO]    Script Date: 31/10/2019 12:39:06 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			EDUARDO LEMUS ZAVALA
UsuarioRed		LEZE667231
Fecha			20170224
Objetivo		OBTENER ULTIMO REGISTRO DE UN COMENTARIO SEGUN SEA EL CASO
				
				CASO 1: ULTIMO COMENTARIO GENERAL
				CASO 2: ULTIMO COMENTARIO DEL USUARIO QUE REALIZO EL REGISTRO DEL REPORTE
				CASO 3: PRIMERO COMENTARIO UNE
				CASO 5: ULTIMO COMENTARIO UNE
				CASO 6: COMENTARIO DE APROBACIÓN DE UNE
				CASO 7: COMENTARIO DE RECHAZO
				CASO 8: COMENTARIO DE CANCELACIÓN
				CASO 9: ULTIMO COMENTARIO DEL AREA ESPECIALIZADA
				CASO 10: COMENTARIO DE FINALIZACIÓN DE REPORTE
				CASO 11: COMENTARIO DE CIERRE DE REPORTE SIN PASAR POR UNE
				CASO 12: NOTIFICACION SOCIO/USUARIO

Proyecto		UNE
Ticket			

*/

ALTER proc [dbo].[SP_UNE_CARGA_COMENTARIO]
@FOLIO INT,
@CASO INT
as
begin
	DECLARE @MAX INT, @NUMUSUARIO INT

	IF(@CASO = 1)
	BEGIN
		--SELECT @NUMUSUARIO = NUMUSUARIO FROM TBL_UNE_USUARIOS_ASIGNADOS WHERE FOLIO = @FOLIO AND responsable = 1

		SELECT  
			@NUMUSUARIO =  can.NUMUSUARIO 
		FROM 
			TBL_UNE_USUARIOS_ASIGNADOS usu
		 inner join 
			TBL_UNE_CANALIZACIONES can on(usu.folio = can.FOLIO)
		 WHERE 
			usu.FOLIO = @FOLIO AND usu.responsable = 1 
		 and
			can.fecha_alta = (select MAX(fecha_alta) from TBL_UNE_CANALIZACIONES where folio = @FOLIO)
	

		IF(@NUMUSUARIO IS NULL)
		BEGIN
			SELECT @NUMUSUARIO = USUARIO_REGISTRA FROM TBL_UNE_REPORTE WHERE FOLIO = @FOLIO
		END

		SELECT @MAX= MAX(ID_CANALIZACION) FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND NUMUSUARIO = @NUMUSUARIO
		SELECT * FROM TBL_UNE_CANALIZACIONES WHERE ID_CANALIZACION = @MAX
	END

	IF(@CASO = 2)
	BEGIN
		SELECT @NUMUSUARIO = USUARIO_REGISTRA FROM TBL_UNE_REPORTE WHERE FOLIO = @FOLIO
		SELECT @MAX= MAX(ID_CANALIZACION) FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND NUMUSUARIO = @NUMUSUARIO
		SELECT * FROM TBL_UNE_CANALIZACIONES WHERE ID_CANALIZACION = @MAX
	END

	IF(@CASO = 3)
	BEGIN
		SELECT @MAX= MIN(ID_CANALIZACION) FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 2
		SELECT * FROM TBL_UNE_CANALIZACIONES WHERE ID_CANALIZACION = @MAX
	END

	IF(@CASO = 4)
	BEGIN
		SELECT @NUMUSUARIO = USUARIO_REGISTRA FROM TBL_UNE_REPORTE WHERE FOLIO = @FOLIO
		SELECT @MAX= MIN(ID_CANALIZACION) FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO
		SELECT * FROM TBL_UNE_CANALIZACIONES WHERE ID_CANALIZACION = @MAX
	END

	IF(@CASO = 5)
	BEGIN
		SELECT @MAX= MAX(ID_CANALIZACION) FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO
		SELECT * FROM TBL_UNE_CANALIZACIONES WHERE ID_CANALIZACION = @MAX
	END

	IF(@CASO = 6)
	BEGIN
		SELECT * FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 4
	END

	IF(@CASO = 7)
	BEGIN
		SELECT @MAX = MAX(ID_CANALIZACION) FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 5
		SELECT * FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 5 AND ID_CANALIZACION = @MAX
	END

	IF(@CASO = 8)
	BEGIN
		SELECT @MAX = MAX(ID_CANALIZACION) FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 8
		SELECT * FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 8 AND ID_CANALIZACION = @MAX
	END

	IF(@CASO = 9)
	BEGIN
		SELECT @MAX = MAX(ID_CANALIZACION) FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 3
		SELECT * FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 3 AND ID_CANALIZACION = @MAX
	END

	IF(@CASO = 10)
	BEGIN
		SELECT @MAX = MAX(ID_CANALIZACION) FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 7
		SELECT * FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 7 AND ID_CANALIZACION = @MAX
	END

	IF(@CASO = 11)
	BEGIN
		SELECT @MAX = MAX(ID_CANALIZACION) FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 9
		SELECT * FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 9 AND ID_CANALIZACION = @MAX
	END

	IF(@CASO = 12)
	BEGIN
		SELECT @MAX = MAX(ID_CANALIZACION) FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 6
		SELECT * FROM TBL_UNE_CANALIZACIONES WHERE FOLIO = @FOLIO AND ID_TIPO_COMENTARIO = 6 AND ID_CANALIZACION = @MAX
	END

end

GO


USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_ATM_VALIDA_NOMBRE]    Script Date: 30/08/2019 02:16:05 p. m. ******/
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO

/*

	AUTOR: DAVID LOPEZ FUENTES
	
	FECHA MODIFICACION: 20/06/2012
	
	OBJETIVO: VALIDA QUE EL NOMBRE DEL SOCIO CUMPLA CON LOS CRITERIOS PARA SOLICITAR
	UNA TARJETA DE DEBITO, Y ACTUALIZA LAS TABLAS TBL_ATM_LAYOUT, TBL_ATM_LOG_PROCESO Y EDO_DE_CUENTA
	
	PROYECTO: DEBITO

*/

ALTER PROCEDURE [dbo].[SP_ATM_VALIDA_NOMBRE] 
				@NUMERO INT,
				@NUMUSUARIO INT


AS


DECLARE 
@NOMBRE_S VARCHAR(30), 	 @APELLIDO_PATERNO VARCHAR(20), @APELLIDO_MATERNO VARCHAR(20), 
@STATUS INT, @NOMBRE_COMPLETO VARCHAR(72), @ID_SOLICITUD INT




/*
	@STATUS = 0 ERROR EN LA BD
	@STATUS = 1 NOMBRE CORRECTO
	@STATUS = 2 EL NOMBRE CONTIENE ALGUN CARACTER INVALIDO
	@STATUS = 3 NO FUE POSIBLE REDUCIR EL NOMBRE A 27 CARACTERES
	@STATUS = 4 EL SOCIO NO HA REALIZADO EL PAGO O EL ID_STATUS NO COINCIDE CON LA SECUENCIA DEL PROCESO
	@STATUS = 5 EL NOMBRE, APELLIDO_PATERNO O APELLIDO_MATERNO ESTA VACIO
*/


-- SE OBTIENE EL NOMBRE DE LA TABLA PERSONA
SELECT @NOMBRE_S = UPPER(NOMBRE_S), @APELLIDO_PATERNO = UPPER(APELLIDO_PATERNO), @APELLIDO_MATERNO = UPPER(APELLIDO_MATERNO)
FROM PERSONA WHERE NUMERO = @NUMERO AND ID_TIPO_PERSONA = 1


SET @NOMBRE_S = LTRIM(RTRIM(@NOMBRE_S))
SET @APELLIDO_PATERNO = LTRIM(RTRIM(@APELLIDO_PATERNO))
SET @APELLIDO_MATERNO = LTRIM(RTRIM(@APELLIDO_MATERNO))


/*
		 	SE VALIDA EL NOMBRE
*/



IF(@NOMBRE_S IS NOT NULL AND @APELLIDO_PATERNO IS NOT NULL AND @APELLIDO_MATERNO IS NOT NULL AND
	@NOMBRE_S NOT LIKE '' AND @APELLIDO_PATERNO NOT LIKE '' AND @APELLIDO_MATERNO NOT LIKE '')
	BEGIN
				
		-- SE REEMPLAZAN LOS CARACTERES NO VÁLIDOS
		SET @NOMBRE_S = REPLACE(@NOMBRE_S, 'Ñ', 'N')
		SET @NOMBRE_S = REPLACE(@NOMBRE_S, 'Á', 'A')
		SET @NOMBRE_S = REPLACE(@NOMBRE_S, 'É', 'E')
		SET @NOMBRE_S = REPLACE(@NOMBRE_S, 'Í', 'I')
		SET @NOMBRE_S = REPLACE(@NOMBRE_S, 'Ó', 'O')
		SET @NOMBRE_S = REPLACE(@NOMBRE_S, 'Ú', 'U')
		SET @NOMBRE_S = REPLACE(@NOMBRE_S, '.', '')
		SET @NOMBRE_S = REPLACE(@NOMBRE_S, 'Ü', 'U')  
		
		SET @APELLIDO_PATERNO = REPLACE(@APELLIDO_PATERNO, 'Ñ', 'N')
		SET @APELLIDO_PATERNO = REPLACE(@APELLIDO_PATERNO, 'Á', 'A')
		SET @APELLIDO_PATERNO = REPLACE(@APELLIDO_PATERNO, 'É', 'E')
		SET @APELLIDO_PATERNO = REPLACE(@APELLIDO_PATERNO, 'Í', 'I')
		SET @APELLIDO_PATERNO = REPLACE(@APELLIDO_PATERNO, 'Ó', 'O')
		SET @APELLIDO_PATERNO = REPLACE(@APELLIDO_PATERNO, 'Ú', 'U')
		SET @APELLIDO_PATERNO = REPLACE(@APELLIDO_PATERNO, '.', '')
		SET @APELLIDO_PATERNO = REPLACE(@APELLIDO_PATERNO, 'Ü', 'U')  
		
		SET @APELLIDO_MATERNO = REPLACE(@APELLIDO_MATERNO, 'Ñ', 'N')
		SET @APELLIDO_MATERNO = REPLACE(@APELLIDO_MATERNO, 'Á', 'A')
		SET @APELLIDO_MATERNO = REPLACE(@APELLIDO_MATERNO, 'É', 'E')
		SET @APELLIDO_MATERNO = REPLACE(@APELLIDO_MATERNO, 'Í', 'I')
		SET @APELLIDO_MATERNO = REPLACE(@APELLIDO_MATERNO, 'Ó', 'O')
		SET @APELLIDO_MATERNO = REPLACE(@APELLIDO_MATERNO, 'Ú', 'U')
		SET @APELLIDO_MATERNO = REPLACE(@APELLIDO_MATERNO, '.', '')
		SET @APELLIDO_MATERNO = REPLACE(@APELLIDO_MATERNO, 'Ü', 'U')  
		
		

		SET @NOMBRE_COMPLETO = @NOMBRE_S + ' ' + @APELLIDO_PATERNO + ' ' + @APELLIDO_MATERNO
		
		
		-- SE VERIFICA QUE EL NOMBRE ESTE FORMADO SOLO POR LETRAS
		IF(DBO.FN_ATM_VALIDA_CADENA_DE_LETRAS(@NOMBRE_COMPLETO) = 1)
			BEGIN
						
				IF(LEN(@NOMBRE_COMPLETO) <= 27)
					BEGIN
						SET @STATUS = 1			
						PRINT 'NOMBRE CORRECTO'
					END
		
				ELSE
					BEGIN
		
						PRINT 'EL NOMBRE SOBREPASA LOS 27 CARACTERES'
		
						IF (@NOMBRE_S LIKE '% %' )
							BEGIN
								SET @NOMBRE_S = (SELECT SUBSTRING(@NOMBRE_S, 1, CHARINDEX(' ', @NOMBRE_S) - 1))
								SET @NOMBRE_COMPLETO = @NOMBRE_S + ' ' + @APELLIDO_PATERNO + ' ' + @APELLIDO_MATERNO
								PRINT 'SE REDUCE EL NOMBRE, SE DEJA SOLAMENTE EL PRIMER NOMBRE DEL SOCIO'
							END				
		
						
							
						IF(LEN(@NOMBRE_COMPLETO) <= 27)
							BEGIN
								SET @STATUS = 1
								PRINT 'NOMBRE CORRECTO'
							END
		
						ELSE
							BEGIN
								SET @APELLIDO_MATERNO = SUBSTRING(@APELLIDO_MATERNO, 1, 1)
								SET @NOMBRE_COMPLETO = @NOMBRE_S + ' ' + @APELLIDO_PATERNO + ' ' + @APELLIDO_MATERNO
								PRINT 'SE REDUCE EL NOMBRE, SE DEJA LA PRIMER LETRA DEL SEGUNDO APELLIDO DEL SOCIO'						
		
								IF(LEN(@NOMBRE_COMPLETO) <= 27)
									BEGIN
										SET @STATUS = 1
										PRINT 'NOMBRE CORRECTO'
									END
					
								ELSE
									BEGIN
										SET @STATUS = 3
										SELECT @NOMBRE_COMPLETO = NOMBRE_S + ' ' + APELLIDO_PATERNO + ' ' + APELLIDO_MATERNO
										FROM PERSONA WHERE NUMERO = @NUMERO AND ID_TIPO_PERSONA = 1
										
										PRINT 'NO FUE POSIBLE REDUCIR EL NOMBRE A 27 CARACTERES'
									END
		
							END	
							
					END
		
			END
		
		ELSE
			BEGIN
				SET @STATUS = 2 
				PRINT 'EL NOMBRE CONTIENE ALGUN CARACTER INVALIDO'
		
			END

	END

ELSE
	BEGIN
		SET @STATUS = 5
		PRINT 'EL NOMBRE, APELLIDO_PATERNO O APELLIDO_MATERNO ESTA VACIO'

	END



/*

SE HACE LA AFECTACION EN LA BASE DE DATOS

*/


-- SE OBTIENE EL MAXIMO ID_SOLICITUD DEL SOCIO EN LA TABLA TBL_ATM_LAYOUT
SET @ID_SOLICITUD = (SELECT MAX(ID_SOLICITUD) FROM TBL_ATM_LAYOUT WHERE NUMERO = @NUMERO)

-- SE VERIFICA QUE EL @STATUS = 1, ES DECIR QUE EL NOMBRE SEA VÁLIDO
IF(@STATUS = 1)
	BEGIN
	
		-- SE VERIFICA QUE EL REGISTRO EN TBL_ATM_LOG_PROCESO ESTE EN ID_STATUS = 2
		IF((SELECT ID_STATUS FROM TBL_ATM_LOG_PROCESO WHERE ID_SOLICITUD = @ID_SOLICITUD) = 2)
			BEGIN

				BEGIN TRAN

				-- SE ACTUALIZA LA TABLA TBL_ATM_LAYOUT
				UPDATE TBL_ATM_LAYOUT
					SET NOMBRE_S = @NOMBRE_S, APELLIDO_PATERNO = @APELLIDO_PATERNO, APELLIDO_MATERNO = @APELLIDO_MATERNO
				WHERE ID_SOLICITUD = @ID_SOLICITUD
		
				IF @@ERROR<>0	
					BEGIN
						SET @STATUS = 0 
					 	ROLLBACK TRAN
						GOTO FINAL
										
					END

				
				-- SE ACTUALIZA LA TABLA TBL_ATM_LOG_PROCESO
				UPDATE TBL_ATM_LOG_PROCESO
					SET ID_STATUS = 3, FECHA_SOLICITUD = GETDATE(), NUMUSUARIO_SOLICITUD = @NUMUSUARIO
				WHERE ID_SOLICITUD = @ID_SOLICITUD
				
				IF @@ERROR<>0	
					BEGIN
						SET @STATUS = 0 
					 	ROLLBACK TRAN
						GOTO FINAL
										
					END

				
				-- SE ACTUALIZA LA TABLA EDO_DE_CUENTA
				UPDATE EDO_DE_CUENTA
					SET TARJETA_ACTIVA = 'T'
				WHERE NUMERO = @NUMERO AND ID_MOV = 112
				

				--Se agrega cuenta de corresponsalias al momento de liberar la tarjeta de debito
				declare 
					@tarjeta_activa char(1) = '',
					@numero_socio varchar(7) = '',
					@cuenta_debito varchar(16) = ''
				
				select @tarjeta_activa = Tarjeta_activa from EDO_DE_CUENTA where Numero = @NUMERO and Id_mov = 112
				select @numero_socio = RIGHT('0000000' + Ltrim(Rtrim(@numero)),7)

				if (@tarjeta_activa <> 'F' or (SELECT COUNT(1) FROM TBL_ATM_LAYOUT  WHERE numero = @NUMERO)>0)
				begin
					select @cuenta_debito = ('797001112' + @numero_socio)

					IF((SELECT COUNT(1) FROM TBL_CORRESPONSALIAS_CUENTAS WHERE NUMERO = @NUMERO AND ID_MOV = 112)=0)
					BEGIN
						INSERT INTO TBL_CORRESPONSALIAS_CUENTAS (NUMERO,CUENTA,FECHA_ALTA,ID_MOV,ACTIVO) VALUES (@NUMERO,@cuenta_debito,GETDATE(),112,0)
					END
				end



				--Se inserta la clabe interbancaria para su cuenta de debito
				if exists(select 1 from [BANCA].[DBO].TBL_BANCA_SOCIOS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @NUMERO AND id_estatus_banca not in(1,9) /*banca_activa =1*/)
				begin
					exec banca.dbo.SP_CMV_INSERTAR_CUENTA_INTERBANCARIA @NUMERO
				end

				IF @@ERROR<>0	
					BEGIN
						SET @STATUS = 0 
					 	ROLLBACK TRAN
						GOTO FINAL
										
					END

				ELSE 
					BEGIN
						-- SET @STATUS = 1
	 					COMMIT TRAN	
					
					END

			END

		ELSE
			BEGIN
				SET @STATUS = 4
				PRINT 'EL SOCIO NO HA REALIZADO EL PAGO O EL ID_STATUS NO COICIDE CON LA SECUENCIA DEL PROCESO'
				
			END

	END


/*
AUTOR MODIFICACION: DAVID LÓPEZ FUENTES
FECHA MODIFICACIÓN: 03/04/2012
OBJETIVO: SE AGREGO LA VALIDACION, PARA QUE CUANDO EL NOMBRE, APELLIDO_PATERNO O APELLIDO_MATERNO ESTEN VACIOS
SE MANDE A REVISION
PROYECTO: DEBITO	
*/
ELSE IF(@STATUS IN(2, 3, 5))
	BEGIN

		-- SE ACTUALIZA LA TABLA TBL_ATM_LOG_PROCESO
		UPDATE TBL_ATM_LOG_PROCESO
			SET ID_STATUS = 8, FECHA_ENVIO_NOMBRE = GETDATE(), NUMUSUARIO_ENVIO_NOMBRE = @NUMUSUARIO
		WHERE ID_SOLICITUD = @ID_SOLICITUD	

		IF @@ERROR<>0	
			BEGIN
				SET @STATUS = 0 
				GOTO FINAL
						
			END		

	END
	

FINAL:
SELECT @STATUS AS STATUS, @NOMBRE_COMPLETO AS NOMBRE_COMPLETO
GO