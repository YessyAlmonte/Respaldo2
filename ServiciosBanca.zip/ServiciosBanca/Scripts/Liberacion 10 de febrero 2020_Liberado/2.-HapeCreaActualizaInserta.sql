use HAPE
-- se incrementa la longitud de concepto para pago de servicio
alter table HAPE..captura alter column concepto varchar(250)
alter table HAPE..captura_LACP alter column concepto varchar(250)
GO

use HISTORICO
-- se incrementa la longitud de concepto para pago de servicio
alter table HISTORICO..captura alter column concepto varchar(250)
alter table HISTORICO..captura_LACP alter column concepto varchar(250)

GO

USE[HAPE]
GO	
	IF  NOT EXISTS(SELECT * FROM sys.columns
	WHERE Name = N'id_tipo_bloqueo_tarjeta' AND OBJECT_ID = OBJECT_ID(N'tbl_corresponsalias_cuentas'))
	BEGIN
		ALTER TABLE tbl_corresponsalias_cuentas add id_tipo_bloqueo_tarjeta int null 
		--ALTER TABLE TBL_BANCA_SOCIOS drop column id_origen_operacion 
	END
GO

-- INICIO AGREGAR COLUMNA  id_tipo_notificacion EN LA TABLA TBL_CONTRATOS_HABERES
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'id_tipo_notificacion' AND OBJECT_ID = OBJECT_ID(N'TBL_CONTRATOS_HABERES'))
BEGIN
		ALTER TABLE TBL_CONTRATOS_HABERES ADD id_tipo_notificacion int
END
go

-- INICIO AGREGAR COLUMNA  id_tipo_notificacion EN LA TABLA TBL_CONTRATOS_HABERES
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'monto_maximo_transferencia' AND OBJECT_ID = OBJECT_ID(N'TBL_CONTRATOS_HABERES'))
BEGIN
		ALTER TABLE TBL_CONTRATOS_HABERES ADD monto_maximo_transferencia int
END
go

-- INICIO AGREGAR COLUMNA  id_tipo_notificacion EN LA TABLA TBL_CONTRATOS_HABERES
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'monto_actualizado' AND OBJECT_ID = OBJECT_ID(N'TBL_CONTRATOS_HABERES'))
BEGIN
		ALTER TABLE TBL_CONTRATOS_HABERES ADD monto_actualizado bit
END
go

if not exists (select * from information_schema.columns where table_name like 'TBL_CONTRATOS_HABERES_CONSTANCIA' and column_name like 'id_estatus_envio')
	alter table TBL_CONTRATOS_HABERES_CONSTANCIA add id_estatus_envio int default 0 null
GO

if not exists (select * from information_schema.columns where table_name like 'TBL_CONTRATOS_HABERES_CONSTANCIA' and column_name like 'fecha_envio')
	alter table TBL_CONTRATOS_HABERES_CONSTANCIA add fecha_envio datetime null
GO

if not exists (select * from information_schema.columns where table_name like 'TBL_CONTRATOS_HABERES_CONSTANCIA' and column_name like 'msg_error')
	alter table TBL_CONTRATOS_HABERES_CONSTANCIA add msg_error varchar(500) null
GO

update TBL_CONTRATOS_HABERES_CONSTANCIA set id_estatus_envio=0



if not exists (select * from information_schema.columns where table_name like 'CAT_CONTRATOS_HABERES_TIPO_CONTRATO' and column_name like 'modulo')
	alter table CAT_CONTRATOS_HABERES_TIPO_CONTRATO add modulo varchar(255) null

GO
update CAT_CONTRATOS_HABERES_TIPO_CONTRATO set modulo='IMAGEN' where id_tipo_contrato in (1,2)

GO

IF NOT EXISTS(SELECT 1 FROM CAT_CONTRATOS_HABERES_TIPO_CONTRATO WHERE id_tipo_contrato=3)
	INSERT INTO CAT_CONTRATOS_HABERES_TIPO_CONTRATO (id_tipo_contrato,tipo_contrato,activo,modulo)  values(3,'CONTRATO BANCA',0,'BANCA')

GO

IF NOT EXISTS(SELECT 1 FROM TBL_CONTRATOS_HABERES_VERSIONES WHERE id_mov=0 AND activo=1 AND id_tipo_contrato=3) 
	INSERT INTO TBL_CONTRATOS_HABERES_VERSIONES(id_mov,reca,activo,id_tipo_contrato,fecha_alta)
	values(0,'0000-000-000000/00-00000-0000',0,3,GETDATE())


/*===========================================================================================================*/
/*=====================================	NUMERO DE POLIZAS	=================================================*/
/*===========================================================================================================*/
USE HAPE
GO

DECLARE
	@id_proceso_poliza int

---BANCA ELECTRONICA
if not exists (select * from CAT_CMV_PROCESOS_POLIZAS where descripcion = 'BANCA ELECTRONICA')
begin
	insert into CAT_CMV_PROCESOS_POLIZAS (descripcion)
	values 
		('BANCA ELECTRONICA')

	select @id_proceso_poliza = max(idProcesoPoliza) from CAT_CMV_PROCESOS_POLIZAS


	insert into TBL_CMV_FOLIOS_POLIZAS_PROCESOS (numPoliza,dia,idProcesoPoliza)
	values 
		('102629',1,@id_proceso_poliza),
		('102630',2,@id_proceso_poliza),
		('102631',3,@id_proceso_poliza),
		('102632',4,@id_proceso_poliza),
		('102633',5,@id_proceso_poliza),
		('102634',6,@id_proceso_poliza),
		('102635',7,@id_proceso_poliza),
		('102636',8,@id_proceso_poliza),
		('102637',9,@id_proceso_poliza),
		('102638',10,@id_proceso_poliza),
		('102639',11,@id_proceso_poliza),
		('102640',12,@id_proceso_poliza),
		('102641',13,@id_proceso_poliza),
		('102642',14,@id_proceso_poliza),
		('102643',15,@id_proceso_poliza),
		('102644',16,@id_proceso_poliza),
		('102645',17,@id_proceso_poliza),
		('102646',18,@id_proceso_poliza),
		('102647',19,@id_proceso_poliza),
		('102648',20,@id_proceso_poliza),
		('102649',21,@id_proceso_poliza),
		('102650',22,@id_proceso_poliza),
		('102651',23,@id_proceso_poliza),
		('102652',24,@id_proceso_poliza),
		('102653',25,@id_proceso_poliza),
		('102654',26,@id_proceso_poliza),
		('102655',27,@id_proceso_poliza),
		('102656',28,@id_proceso_poliza),
		('102657',29,@id_proceso_poliza),
		('102658',30,@id_proceso_poliza),
		('102659',31,@id_proceso_poliza)

	select * 
		from TBL_CMV_FOLIOS_POLIZAS_PROCESOS
	where 
		idProcesoPoliza = @id_proceso_poliza
end

---SPEI
if not exists (select * from CAT_CMV_PROCESOS_POLIZAS where descripcion = 'SPEI')
begin
	insert into CAT_CMV_PROCESOS_POLIZAS (descripcion)
	values 
		('SPEI')

	select @id_proceso_poliza = max(idProcesoPoliza) from CAT_CMV_PROCESOS_POLIZAS

	insert into TBL_CMV_FOLIOS_POLIZAS_PROCESOS (numPoliza,dia,idProcesoPoliza)
	values 
		('102567',1,@id_proceso_poliza),
		('102568',2,@id_proceso_poliza),
		('102569',3,@id_proceso_poliza),
		('102570',4,@id_proceso_poliza),
		('102571',5,@id_proceso_poliza),
		('102572',6,@id_proceso_poliza),
		('102573',7,@id_proceso_poliza),
		('102574',8,@id_proceso_poliza),
		('102575',9,@id_proceso_poliza),
		('102576',10,@id_proceso_poliza),
		('102577',11,@id_proceso_poliza),
		('102578',12,@id_proceso_poliza),
		('102579',13,@id_proceso_poliza),
		('102580',14,@id_proceso_poliza),
		('102581',15,@id_proceso_poliza),
		('102582',16,@id_proceso_poliza),
		('102583',17,@id_proceso_poliza),
		('102584',18,@id_proceso_poliza),
		('102585',19,@id_proceso_poliza),
		('102586',20,@id_proceso_poliza),
		('102587',21,@id_proceso_poliza),
		('102588',22,@id_proceso_poliza),
		('102589',23,@id_proceso_poliza),
		('102590',24,@id_proceso_poliza),
		('102591',25,@id_proceso_poliza),
		('102592',26,@id_proceso_poliza),
		('102593',27,@id_proceso_poliza),
		('102594',28,@id_proceso_poliza),
		('102595',29,@id_proceso_poliza),
		('102596',30,@id_proceso_poliza),
		('102597',31,@id_proceso_poliza)

	select * 
		from TBL_CMV_FOLIOS_POLIZAS_PROCESOS
	where 
		idProcesoPoliza = @id_proceso_poliza
end

go
-- se crea cat�logo CAT_ESTATUS_ENVIO
if exists (select * from sysobjects where name like 'CAT_ESTATUS_ENVIO' and xtype = 'u' and db_name() = 'hape')
	drop table CAT_ESTATUS_ENVIO

create table
	CAT_ESTATUS_ENVIO
		(
		id_estatus int constraint PK_TBL_ESTATUS_ENVIO primary key clustered not null, -- llave primaria
		estatus varchar(200)
		)

grant select, insert, update, delete on CAT_ESTATUS_ENVIO to public

if not exists(select 1 from CAT_ESTATUS_ENVIO where id_estatus=0)
INSERT INTO CAT_ESTATUS_ENVIO(id_estatus,estatus) SELECT 0,'NO APLICA ENVIO'

if not exists(select 1 from CAT_ESTATUS_ENVIO where id_estatus=1)
INSERT INTO CAT_ESTATUS_ENVIO(id_estatus,estatus) SELECT 1,'PENDIENTE'

if not exists(select 1 from CAT_ESTATUS_ENVIO where id_estatus=2)
INSERT INTO CAT_ESTATUS_ENVIO(id_estatus,estatus) SELECT 2,'PROCESO'

if not exists(select 1 from CAT_ESTATUS_ENVIO where id_estatus=3)
INSERT INTO CAT_ESTATUS_ENVIO(id_estatus,estatus) SELECT 3,'ENVIADO'

if not exists(select 1 from CAT_ESTATUS_ENVIO where id_estatus=4)
INSERT INTO CAT_ESTATUS_ENVIO(id_estatus,estatus) SELECT 4,'ERROR'

USE[HAPE]

-- se crea tabla TBL_CONTRATOS_HABERES_LOG
if exists (select * from sysobjects where name like 'TBL_CONTRATOS_HABERES_LOG' and xtype = 'u' and db_name() = 'hape')
	drop table TBL_CONTRATOS_HABERES_LOG

create table
	TBL_CONTRATOS_HABERES_LOG
		(
		id	bigint identity (1, 1) constraint PK_TBL_CONTRATOS_HABERES_LOG primary key clustered not null, -- llave primaria
		id_contrato int,
		id_tipo_contrato int,		
		num_usuario int,
		id_tipo_notificacion int,
		monto_maximo_transferencia money,
		imprimio_anexo bit,
		fecha_impresion datetime,
		)

grant select, insert, update, delete on TBL_CONTRATOS_HABERES_LOG to public


use hape
go

-- se crea cat�logo CAT_UNE_TIPO_CUENTA_BANCA
if exists (select * from sysobjects where name like 'CAT_UNE_TIPO_CUENTA_BANCA' and xtype = 'u' and db_name() = 'hape')
	drop table CAT_UNE_TIPO_CUENTA_BANCA

create table CAT_UNE_TIPO_CUENTA_BANCA
(
	ID_TIPO_CUENTA_BANCA INT IDENTITY(1,1) PRIMARY KEY,
	DESCRIPCION VARCHAR(100)
)

grant select, insert, update, delete on CAT_UNE_TIPO_CUENTA_BANCA to public
GO


use BANCA
go
-- se crea cat�logo CAT_CALLCENTER_TIPO_CUENTA
if exists (select * from sysobjects where name like 'CAT_CALLCENTER_TIPO_CUENTA_NO_AFECTADA' and xtype = 'u' and db_name() = 'banca')
	drop table CAT_CALLCENTER_TIPO_CUENTA_NO_AFECTADA

create table CAT_CALLCENTER_TIPO_CUENTA_NO_AFECTADA
(
	ID_CUENTA_NO_AFECTADA INT IDENTITY(1,1) PRIMARY KEY,
	DESCRIPCION VARCHAR(100)
)

grant select, insert, update, delete on CAT_CALLCENTER_TIPO_CUENTA_NO_AFECTADA to public
GO




USE HAPE
GO
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'requiere_autentificacion' AND OBJECT_ID = OBJECT_ID(N'CAT_UNE_SUPUESTOS_REPORTE'))
BEGIN
	ALTER TABLE CAT_UNE_SUPUESTOS_REPORTE ADD requiere_autentificacion BIT
END
go

IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'id_accion_causa' AND OBJECT_ID = OBJECT_ID(N'CAT_UNE_SUPUESTOS_REPORTE'))
BEGIN
	ALTER TABLE CAT_UNE_SUPUESTOS_REPORTE ADD id_accion_causa int
END
go

IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'folio_banca' AND OBJECT_ID = OBJECT_ID(N'TBL_UNE_REPORTE'))
BEGIN
	ALTER TABLE TBL_UNE_REPORTE ADD folio_banca int
END
GO

IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'id_medio_deteccion_movimiento' AND OBJECT_ID = OBJECT_ID(N'TBL_UNE_REPORTE'))
BEGIN
	ALTER TABLE TBL_UNE_REPORTE ADD id_medio_deteccion_movimiento int
END
GO

IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'folio_autorizacion_banca' AND OBJECT_ID = OBJECT_ID(N'TBL_UNE_REPORTE'))
BEGIN
	ALTER TABLE TBL_UNE_REPORTE ADD folio_autorizacion_banca int
END
GO

IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'reporte_banca' AND OBJECT_ID = OBJECT_ID(N'TBL_UNE_REPORTE'))
BEGIN
	ALTER TABLE TBL_UNE_REPORTE ADD reporte_banca bit
END
GO

IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'id_tipo_cuenta_banca' AND OBJECT_ID = OBJECT_ID(N'TBL_UNE_REPORTE'))
BEGIN
	ALTER TABLE TBL_UNE_REPORTE ADD id_tipo_cuenta_banca int
END
GO


IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'USUARIO_CALL_CENTER' AND OBJECT_ID = OBJECT_ID(N'TBL_UNE_PERMISOS_ADMIN'))
BEGIN
	ALTER TABLE TBL_UNE_PERMISOS_ADMIN ADD USUARIO_CALL_CENTER BIT
END
GO

IF NOT EXISTS(SELECT 1 FROM sys.columns WHERE Name = N'ADMINISTRADOR_CALL_CENTER' AND OBJECT_ID = OBJECT_ID(N'TBL_UNE_PERMISOS_ADMIN'))
BEGIN
	ALTER TABLE TBL_UNE_PERMISOS_ADMIN ADD ADMINISTRADOR_CALL_CENTER BIT
	
END
GO

UPDATE TBL_UNE_PERMISOS_ADMIN SET ADMINISTRADOR_CALL_CENTER = 0
go

-- INICIO AGREGAR COLUMNA  USUARIO_SUCURSAL EN LA TABLA TBL_UNE_PERMISOS_ADMIN
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'USUARIO_SUCURSAL' AND OBJECT_ID = OBJECT_ID(N'TBL_UNE_PERMISOS_ADMIN'))
BEGIN
		ALTER TABLE TBL_UNE_PERMISOS_ADMIN ADD USUARIO_SUCURSAL bit default 0
END
go

--SELECT * FROM HAPE..TBL_UNE_REPORTE

IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'fecha_compromiso_reporte' AND OBJECT_ID = OBJECT_ID(N'TBL_UNE_REPORTE'))
BEGIN
	ALTER TABLE TBL_UNE_REPORTE ADD fecha_compromiso_reporte DATETIME default null
END

IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'id_cuenta_no_afectada_banca' AND OBJECT_ID = OBJECT_ID(N'TBL_UNE_REPORTE'))
BEGIN
	ALTER TABLE TBL_UNE_REPORTE ADD id_cuenta_no_afectada_banca int default null
END

IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'usuario_deposito_procedente' AND OBJECT_ID = OBJECT_ID(N'TBL_UNE_REPORTE'))
BEGIN
	ALTER TABLE TBL_UNE_REPORTE ADD usuario_deposito_procedente int default null
END


use hape
go

select * from TBL_UNE_PERMISOS_ADMIN WHERE ID_ROL = 39 and NOM_ROL = ''
if not exists (select * from TBL_UNE_PERMISOS_ADMIN where NOM_ROL = 'ANALISTA DE CREDITO')
	insert into TBL_UNE_PERMISOS_ADMIN (ID_ROL, NOM_ROL,FECHA_ALTA,ACTIVO,USUARIO_UNE,
		PERMISO_CONDUSEF,PERMISO_REGISTRAR,PERMISO_DEBITO,PERMISO_OPERAR_DETALLE,
		USUARIO_CALL_CENTER,ADMINISTRADOR_CALL_CENTER, USUARIO_SUCURSAL) values(39,'ANALISTA DE CREDITO',getdate(),1,0,0,1,0,0,1,0, null)
GO

--Se agregan permisos a los usuarios de sucursal--
--IF NOT EXISTS (SELECT * FROM TBL_UNE_PERMISOS_ADMIN WHERE ID_ROL in (210,211,212,213,214,215,216,217,218,282,315))
--BEGIN
--	insert into TBL_UNE_PERMISOS_ADMIN 
--		(NOM_ROL,ID_ROL,FECHA_ALTA,ACTIVO,USUARIO_UNE,
--		PERMISO_CONDUSEF,PERMISO_REGISTRAR,PERMISO_DEBITO,PERMISO_OPERAR_DETALLE,
--		USUARIO_CALL_CENTER,ADMINISTRADOR_CALL_CENTER,USUARIO_SUCURSAL)
--	select 
--		Nom_Rol,Id_Rol,GETDATE(),1,0,0,1,0,0,1,0,1
--	from HAPE..SICORP_ROLES
--	where 
--		Id_Rol in (210,211,212,213,214,215,216,217,218,282,315)

--END

use HAPE
go

IF NOT EXISTS (SELECT 1 FROM CAT_CMV_ORIGEN_TRANSACCION WHERE origen = 'ATM')
 INSERT INTO CAT_CMV_ORIGEN_TRANSACCION (origen) VALUES ('ATM' )


IF NOT EXISTS (SELECT 1 FROM CAT_CMV_ORIGEN_TRANSACCION WHERE origen = 'SPEI')
 INSERT INTO CAT_CMV_ORIGEN_TRANSACCION (origen) VALUES ('SPEI' )

 go


if not exists (select * from CAT_UNE_ESTATUS_REPORTE where DESCRIPCION ='Fallo de autenticaci�n (CMV Finanzas)')
	INSERT INTO CAT_UNE_ESTATUS_REPORTE VALUES('Fallo de autenticaci�n (CMV Finanzas)')
GO

if not exists (select * from CAT_UNE_ESTATUS_REPORTE where DESCRIPCION ='Reporte procedente pendiente de dep�sito (CMV Finanzas)')
	INSERT INTO CAT_UNE_ESTATUS_REPORTE VALUES('Reporte procedente pendiente de dep�sito (CMV Finanzas)')
GO

if not exists (select * from CAT_UNE_TIPO_REPORTE where DESCRIPCION = 'CMV Finanzas')
	INSERT INTO CAT_UNE_TIPO_REPORTE VALUES('CMV Finanzas')
GO

-- SET IDENTITY_INSERT to ON.  
SET IDENTITY_INSERT dbo.CAT_UNE_TIPO_CUENTA ON;  
GO 

if not exists (select * from CAT_UNE_TIPO_CUENTA where DESCRIPCION = 'Asesoria')
	INSERT INTO CAT_UNE_TIPO_CUENTA(ID_TIPO_CUENTA,DESCRIPCION) VALUES(4,'Asesoria')
GO

if not exists (select * from CAT_UNE_TIPO_CUENTA where DESCRIPCION = 'Soporte t�cnico')
	INSERT INTO CAT_UNE_TIPO_CUENTA(ID_TIPO_CUENTA,DESCRIPCION) VALUES(5,'Soporte t�cnico')
GO

if not exists (select * from CAT_UNE_TIPO_CUENTA where DESCRIPCION = 'Incidencias')
	INSERT INTO CAT_UNE_TIPO_CUENTA(ID_TIPO_CUENTA,DESCRIPCION) VALUES(6,'Incidencias')
GO

-- SET IDENTITY_INSERT to ON.  
SET IDENTITY_INSERT dbo.CAT_UNE_TIPO_CUENTA OFF;  
GO 

if not exists (select * from CAT_UNE_CUENTAS where DESCRIPCION = 'Guia de usuario')
	INSERT INTO CAT_UNE_CUENTAS VALUES('Guia de usuario',4,0,0)
GO

if not exists (select * from CAT_UNE_CUENTAS where DESCRIPCION = 'Promociones')
	INSERT INTO CAT_UNE_CUENTAS VALUES('Promociones',4,0,0)
GO

if not exists (select * from CAT_UNE_CUENTAS where DESCRIPCION = 'Bloqueos')
	INSERT INTO CAT_UNE_CUENTAS VALUES('Bloqueos',4,0,0)
GO

if not exists (select * from CAT_UNE_CUENTAS where DESCRIPCION = 'Informaci�n de sucursales')
INSERT INTO CAT_UNE_CUENTAS VALUES('Informaci�n de sucursales',4,0,0)
GO

if not exists (select * from CAT_UNE_CUENTAS where DESCRIPCION = 'Seguimiento')
	INSERT INTO CAT_UNE_CUENTAS VALUES('Seguimiento',4,0,0)
GO

if not exists (select * from CAT_UNE_CUENTAS where DESCRIPCION = 'Acciones no reconocidas')
	INSERT INTO CAT_UNE_CUENTAS VALUES('Acciones no reconocidas',5,0,0)
GO

if not exists (select * from CAT_UNE_CUENTAS where DESCRIPCION = 'Suspensi�n Cuenta')
	INSERT INTO CAT_UNE_CUENTAS VALUES('Suspensi�n Cuenta',5,0,0)
GO

if not exists (select * from CAT_UNE_CUENTAS where DESCRIPCION = 'Desbloqueo de Cuenta')
	INSERT INTO CAT_UNE_CUENTAS VALUES('Desbloqueo de Cuenta',5,0,0)
GO

if not exists (select * from CAT_UNE_CUENTAS where DESCRIPCION = 'Envio Liga')
	INSERT INTO CAT_UNE_CUENTAS VALUES('Envio Liga',5,0,0)
GO

if not exists (select * from CAT_UNE_CUENTAS where DESCRIPCION = 'Modificaciones')
INSERT INTO CAT_UNE_CUENTAS VALUES('Modificaciones',5,0,0)
GO

if not exists (select * from CAT_UNE_CUENTAS where DESCRIPCION = 'Operaci�n no reconocida')
	INSERT INTO CAT_UNE_CUENTAS VALUES('Operaci�n no reconocida',6,0,0)
GO

if not exists (select * from CAT_UNE_CUENTAS where DESCRIPCION = 'Operaciones no aplicadas')
	INSERT INTO CAT_UNE_CUENTAS VALUES('Operaciones no aplicadas',6,0,0)
GO

UPDATE CAT_UNE_SUPUESTOS_REPORTE SET requiere_autentificacion = 0, id_accion_causa = 0 where ID_SUPUESTOS_REPORTE <=2158
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Guias')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,4,28,'Guias',30,1,0,290,390,0,1)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Promociones')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,4,29,'Promociones',30,1,0,290,390,0,2)
GO
if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'N/A')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,4,30,'N/A',30,1,0,290,390,0,3)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Informaci�n de sucursales')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,4,31,'Informaci�n de sucursales',30,1,0,290,390,0,4)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Seguimiento de reclamaci�n')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,4,32,'Seguimiento de reclamaci�n',30,1,0,290,390,0,5)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Cambio no reconocido de imagen antiphishing')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,5,33,'Cambio no reconocido de imagen antiphishing',30,1,0,290,390,1,6)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Cambio no reconocido de Contrase�a')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,5,33,'Cambio no reconocido de Contrase�a',30,1,0,290,390,1,6)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Cambio no reconocido de respuesta y pregunta')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,5,33,'Cambio no reconocido de respuesta y pregunta',30,1,0,290,390,1,6)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Activaci�n de CMV Finanzas no reconocida')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,5,33,'Activaci�n de CMV Finanzas no reconocida',30,1,0,290,390,0,6)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Cuenta a tercero no reconocida')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,5,33,'Cuenta a tercero no reconocida',30,1,0,290,390,1,6)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Suspensi�n temporal del servicio')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,5,34,'Suspensi�n temporal del servicio',30,1,0,290,390,1,6)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Reporte de robo o extrav�o de medios de los dispositivos de acceso')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,5,34,'Reporte de robo o extrav�o de medios de los dispositivos de acceso',30,1,0,290,390,1,6)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Reactivaci�n del servicio de CMV Finanza')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,5,35,'Reactivaci�n del servicio de CMV Finanzas',30,1,0,290,390,1,7)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Contrase�a de registro')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,5,36,'Contrase�a de registro',30,1,0,290,390,1,8)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Caducidad de URL del Token')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,5,36,'Caducidad de URL del Token',30,1,0,290,390,1,9)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Disminuci�n de l�mites de monto de operaci�n')
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,5,37,'Disminuci�n de l�mites de monto de operaci�n',30,1,0,290,390,1,10)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Transferencias, Inversiones o pagos a cr�ditos' and id_cuenta = 38)
	INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,6,38,'Transferencias, Inversiones o pagos cr�ditos',30,1,1,290,390,1,11)
GO

if not exists (select * from CAT_UNE_SUPUESTOS_REPORTE where DESCRIPCION = 'Transferencias, Inversiones o pagos a cr�ditos')
INSERT INTO CAT_UNE_SUPUESTOS_REPORTE VALUES(4,6,39,'Transferencias, Inversiones o pagos a cr�ditos',30,1,1,290,390,1,11)
GO


--UPDATE TBL_UNE_PERMISOS_ADMIN SET USUARIO_CALL_CENTER = 0
--GO

if not exists (select * from CAT_UNE_TIPO_CUENTA_BANCA where DESCRIPCION = 'Haberes')
	INSERT INTO CAT_UNE_TIPO_CUENTA_BANCA VALUES('Haberes')
GO

if not exists (select * from CAT_UNE_TIPO_CUENTA_BANCA where DESCRIPCION = 'Pr�stamos')
	INSERT INTO CAT_UNE_TIPO_CUENTA_BANCA VALUES('Pr�stamos')
GO


use HAPE
go

UPDATE 
	TBL_UNE_PERMISOS_ADMIN 
set 
	PERMISO_REGISTRAR =1,
	USUARIO_CALL_CENTER = 1,
	ADMINISTRADOR_CALL_CENTER = 1
where 
	ID_ROL 
in 
	(15,219, 238)
GO

update 
	HAPE..CAT_UNE_ESTATUS_REPORTE 
set 
	DESCRIPCION = 'Fallo de autenticaci�n (CMV Finanzas)' 
where 
	ID_ESTATUS_REPORTE =11
GO

update 
	CAT_UNE_SUPUESTOS_REPORTE 
set 
	DESCRIPCION = 'Transferencias, Inversiones o pagos a cr�ditos' 
where 
	ID_SUPUESTOS_REPORTE =2175
go

update 
	CAT_UNE_SUPUESTOS_REPORTE 
set 
	DIAS_Requeridos =3 
where 
	ID_CUENTA = 33
go

update 
	CAT_UNE_SUPUESTOS_REPORTE 
set 
	DIAS_Requeridos =0
where 
	ID_TIPO_CUENTA = 4
go


update 
	CAT_UNE_SUPUESTOS_REPORTE 
set 
	DIAS_Requeridos =0
where 
	id_cuenta in (34,35,36,37)
go


							---------------------------------------------------------------
							-------------INSERTAMOS LOS MOVIMIENTOS PARA SPEI--------------
							---------------------------------------------------------------

declare
	@id_tipomov int,
	@id_Mov int = 112

	select @id_tipomov  =  max(Id_tipomov)+15 from hape..TIPO_MOV

	-- insertamos el movimiento Dep�sito a DEBITO CMV por Transferencia SPEI
	insert into hape..TIPO_MOV (Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
	values(@id_tipomov , 'Dep�sito a DEBITO CMV por Transferencia SPEI',1,@id_Mov,'H',1 )
	
	-- se incremente el valor de id_tipomov
	set @id_tipomov = @id_tipomov +1
	

	-- insertamos el movimiento Dep�sito a DEBITO CMV por operaci�n rechazada SPEI
	insert into hape..TIPO_MOV (Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
	values(@id_tipomov , 'Dep�sito a DEBITO CMV por operaci�n rechazada SPEI',1,@id_Mov,'H',1 )

	-- se incremente4 el valor de id_tipomov
	set @id_tipomov = @id_tipomov +1

	insert into hape..TIPO_MOV (Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
	values(@id_tipomov , 'Dep�sito a DEBITO CMV por aclaraci�n procedente SPEI',1,@id_Mov,'H',1 )

	-- se incremente4 el valor de id_tipomov
	set @id_tipomov = @id_tipomov +1

	--Retiro de DEBITO CMV por Transferencia SPEI
	insert into hape..TIPO_MOV (Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
	values(@id_tipomov , 'Retiro de DEBITO CMV por Transferencia SPEI',-1,@id_Mov,'D',2 )



						---------------------------------------------------------------
						-------------INSERTAMOS LOS MOVIMIENTOS PARA SPEI--------------
						---------------------------------------------------------------


						---------------------------------------------------------------
						-------------INSERTAMOS LOS MOVIMIENTOS PARA PAGO DE SERVICIOS--------------
						---------------------------------------------------------------
--BEGIN TRAN
IF NOT EXISTS (SELECT * FROM hape..TIPO_MOV WHERE Descripcion = 'Dep�sito a AHORRO CMV por operaci�n rechazada de Pago de Servicio')
BEGIN
declare
	@id_tipomov_ int,
	@id_Mov_ int = 100

	select @id_tipomov_  =  max(id_tipomov)+15 from hape..TIPO_MOV

	-- insertamos el movimiento Dep�sito a AHORRO CMV por operaci�n rechazada de Pago de Servicio
	insert into hape..TIPO_MOV (Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
	values(@id_tipomov_ , 'Dep�sito a AHORRO CMV por operaci�n rechazada de Pago de Servicio',1,@id_Mov_,'H',1 )

	-- se incremente el valor de id_tipomov
	set @id_tipomov_ = @id_tipomov_ +1

	insert into hape..TIPO_MOV (Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
	values(@id_tipomov_ , 'Dep�sito a AHORRO CMV por aclaraci�n procedente de Pago de Servicio',1,@id_Mov_,'H',0 )

	-- se incremente el valor de id_tipomov
	set @id_tipomov_ = @id_tipomov_ +1

	--Retiro de AHORRO CMV por Pago de Servicio
	insert into hape..TIPO_MOV (Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
	values(@id_tipomov_ , 'Retiro de AHORRO CMV por Pago de Servicio',-1,@id_Mov_,'D',2 )

	--------------------------------	INVER	----------------------
	select @id_Mov_  = 103
	select @id_tipomov_  =  max(id_tipomov)+1 from hape..TIPO_MOV
	
	-- insertamos el movimiento Dep�sito a DEBITO CMV por operaci�n rechazada de Pago de Servicio
	insert into hape..TIPO_MOV (Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
	values(@id_tipomov_ , 'Dep�sito a INVERDIN�MICA CMV por operaci�n rechazada de Pago de Servicio',1,@id_Mov_,'H',1 )

	-- se incremente el valor de id_tipomov
	set @id_tipomov_ = @id_tipomov_ +1

	insert into hape..TIPO_MOV (Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
	values(@id_tipomov_ , 'Dep�sito a INVERDIN�MICA CMV por aclaraci�n procedente de Pago de Servicio',1,@id_Mov_,'H',0 )

	-- se incremente el valor de id_tipomov
	set @id_tipomov_ = @id_tipomov_ +1

	--Retiro de DEBITO CMV por Pago de Servicio
	insert into hape..TIPO_MOV (Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
	values(@id_tipomov_ , 'Retiro de INVERDIN�MICA CMV por Pago de Servicio',-1,@id_Mov_,'D',2 )


	--------------------------------	DEPOSITO DEBITO	----------------------
	select @id_Mov_  = 112
	select @id_tipomov_  =  max(id_tipomov)+1 from hape..TIPO_MOV

	-- insertamos el movimiento Dep�sito a DEBITO CMV por operaci�n rechazada de Pago de Servicio
	insert into hape..TIPO_MOV (Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
	values(@id_tipomov_ , 'Dep�sito a DEBITO CMV por operaci�n rechazada de Pago de Servicio',1,@id_Mov_,'H',1 )

	-- se incremente el valor de id_tipomov
	set @id_tipomov_ = @id_tipomov_ +1

	insert into hape..TIPO_MOV (Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
	values(@id_tipomov_ , 'Dep�sito a DEBITO CMV por aclaraci�n procedente de Pago de Servicio',1,@id_Mov_,'H',0 )

	-- se incremente el valor de id_tipomov
	set @id_tipomov_ = @id_tipomov_ +1

	--Retiro de DEBITO CMV por Pago de Servicio
	insert into hape..TIPO_MOV (Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
	values(@id_tipomov_ , 'Retiro de DEBITO CMV por Pago de Servicio',-1,@id_Mov_,'D',2 )

END
SELECT max(id_tipomov)+15 from hape..TIPO_MOV
--SELECT * FROM hape..TIPO_MOV ORDER BY ID_TIPOMOV DESC

--ROLLBACK TRAN
						---------------------------------------------------------------
						-------------INSERTAMOS LOS MOVIMIENTOS PARA SPEI--------------
						---------------------------------------------------------------

