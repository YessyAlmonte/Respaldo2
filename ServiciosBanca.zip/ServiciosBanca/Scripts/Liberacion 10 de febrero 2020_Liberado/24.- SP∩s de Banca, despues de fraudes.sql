USE BANCA
GO


/****** Object:  StoredProcedure [dbo].[SP_BANCA_INSERTAR_SOCIO]    Script Date: 20/01/2020 09:55:27 a. m. ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_BANCA_INSERTAR_SOCIO]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SP_BANCA_INSERTAR_SOCIO]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_CANCELAR_SERVICIO_BANCA]    Script Date: 20/01/2020 09:55:27 a. m. ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_BANCA_CANCELAR_SERVICIO_BANCA]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SP_BANCA_CANCELAR_SERVICIO_BANCA]
GO

/****** Object:  StoredProcedure [dbo].[SP_BANCA_INSERTAR_SOCIO]    Script Date: 04/02/2020 01:59:27 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_BANCA_INSERTAR_SOCIO]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[SP_BANCA_INSERTAR_SOCIO] AS' 
END
GO

ALTER proc

	[dbo].[SP_BANCA_INSERTAR_SOCIO]
	 
		-- par�metros
		@numero_Socio Int,
		@contrasenaTemp varchar(max),
		@contrasenaEdoCuenta  varchar(max),
		@numero_usuario varchar(20) = null,
		@tipo_origen INT = 2
		-- [aqu� van los par�metros]

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@id_banca_folio int,
						@id_tipo_bitacora int  = 40,
						@socio_edad int
						
			
			end -- inicio
			
			begin -- validaciones
			
				if not exists(SELECT * FROM HAPE.DBO.PERSONA WHERE NUMERO = @numero_Socio)
					raiserror('El socio ingresado no existe',11,0)

				if exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE numero_socio = @numero_Socio and id_estatus_banca != 9)
					raiserror('El socio ingresado ya esta registrado en �CMV finanzas�',11,0)
				--if exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE numero_socio = @numero_Socio)
				--raiserror('El monto ingresado es m�s del que dispone en la institucion',11,0)
				--if exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE numero_socio = @numero_Socio )
				--	raiserror('El socio ya tiene una solicitud pendiente en Banca Electr�nica' ,11,0)

				
			end -- validaciones
			if exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE numero_socio = @numero_Socio and id_estatus_banca = 9 )
				begin
						update TBL_BANCA_SOCIOS 
						set
							id_estatus_banca = 4, 
							id_motivo_bloqueo=1,
							banca_activa = 0,
							fecha_alta_solicitud =GETDATE(),
							viene_de_bloqueo = 0,
							contrasena =null,
							fecha_contrasena_temporal = GETDATE(),
							contrasena_temp = @contrasenaTemp,
							fecha_alta_contrasena = null,
							id_pregunta_secreta = null,
							respuesta = null,
							fecha_motivo_bloqueo = null,
							id_imagen_antiphishing = null,
							vigencia_contrasena_temporal = null,
							id_ultima_sesion = null,
							fecha_ultima_sesion =null,
							intentos_sesion = null,
							intentos_respuesta = null,
							fecha_de_desbloqueo = null,
							contrasena_estado_cuenta = @contrasenaEdoCuenta
						where numero_socio=@numero_Socio;
						/* Actualizacion a tabla de UNE donde se valida si el socio existe*/
						update UNE..TBL_CALLCENTER_SOCIOS
						set							
							banca_registrado = 1,
							fecha_alta = getdate()
							where numero_socio = @numero_Socio
				end

				else if not exists(SELECT * FROM TBL_BANCA_SOCIOS WHERE numero_socio = @numero_Socio)
				begin

				INSERT INTO TBL_BANCA_SOCIOS 
				(
					id_persona,
					numero_socio,
					contrasena,
					fecha_alta_contrasena,
					contrasena_temp,
					fecha_contrasena_temporal,
					fecha_alta_persona,
					id_estatus_banca,
					id_pregunta_secreta,
					respuesta,
					id_motivo_bloqueo,
					banca_activa,
					fecha_alta_solicitud,
					contrasena_estado_cuenta
				)
				SELECT  
					s.Id_Persona,
					S.NUMERO,
					null            /*contrase�a*/,
					null            /*fecha_alta_contrasena*/,
					@contrasenaTemp /*contrasena_temp*/,
					GETDATE(),
					S.Fecha_Alta /*fecha_alta_persona*/,
					4    /* 1 = registro de solicitud id_estatus_banca select * from cat_banca_estatus_banca*/,
					null /*id_pregunta_secreta*/,
					null /* respuesta*/,
					1    /* id_motivo_bloqueo cart motivo bloque*/,
					0    /*banca_activa*/,
					GETDATE(), /*fecha_alta_solicitud*/
					@contrasenaEdoCuenta
					
				FROM HAPE..PERSONA s WHERE s.Numero = @numero_Socio and  s.Id_Tipo_Persona = 1

				/* Actualizacion a tabla de UNE donde se valida si el socio existe*/
				INSERT INTO UNE..TBL_CALLCENTER_SOCIOS
				(				
					numero_socio,
					banca_registrado,
					fecha_alta
				)
				select 
				@numero_Socio,
				1,
				getdate()
				
				end


				IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
					BEGIN
					INSERT INTO 
						TBL_BANCA_BITACORA_OPERACIONES 
						(
								id_tipo_bitacora,
								numero_socio,
								fecha_alta,
								id_origen_operacion,
								usuario
						)
						VALUES 
						(
							 @id_tipo_bitacora ,
							 @numero_socio ,
							 getdate() ,
							 @tipo_origen,
							 @numero_usuario
						)


						--SE VALIDA SI EL SOCIO TIENE DEBITO SE LE AGREGA SU CUNETA CLABE
						if exists(select 1 from hape..EDO_DE_CUENTA where Id_mov = 112 and numero = @numero_Socio and Tarjeta_activa = 'T')
							begin
								if exists(select 1 from TBL_BANCA_CUENTAS_INTERBANCARIAS where numero_socio = @numero_Socio and activo = 0)
								begin
									update TBL_BANCA_CUENTAS_INTERBANCARIAS set activo = 1 where numero_socio = @numero_Socio
								end
								else
								begin
									exec banca.dbo.SP_CMV_INSERTAR_CUENTA_INTERBANCARIA @numero_Socio
								end
							end
					END

					-------------------------------------------------------------------------------------------------------------
					------ VALIDAMOS SI EXISTEN CUENTAS EN LA TABLA DE CORRESPONSALIAS LAS ACTIVAMOS TANT DE PRESTAMOS Y HABERES--
					-------------------------------------------------------------------------------------------------------------

					--IF EXISTS (SELECT 1 FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE ID_MOV = 10 AND NUMERO = @numero_Socio)
					--BEGIN
					--    UPDATE cc
					--	SET CC.ACTIVO = 1 
					--	FROM
					--	HAPE..TBL_CORRESPONSALIAS_CUENTAS cc
					--	JOIN HAPE..TBL_REVOLVENTE_LINEAS_CREDITO LC 
					--	ON  
					--		LC.Numero =  CC.numero 
					--		and cc.ID_MOV = 10
					--		and lc.num_ptmo = cc.NUM_PTMO
						   
					--	WHERE
					--			CC.Numero = @numero_Socio
					--			--and Saldo_Actual > 0
					--END
				
					--IF EXISTS (SELECT 1 FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE ID_MOV BETWEEN 1 AND 9 AND NUMERO = @numero_Socio)
					--BEGIN
					--    UPDATE cc
					--	SET CC.ACTIVO = 1 
					--	FROM
					--	HAPE..TBL_CORRESPONSALIAS_CUENTAS cc
					--	JOIN HAPE..EDO_DE_CUENTA EDC ON  EDC.Numero =  CC.numero  AND EDC.Id_mov = CC.ID_MOV and edc.Id_Tipo_persona  = 1
					--	WHERE
					--			CC.Numero = @numero_Socio
					--			and edc.Id_Tipo_persona  = 1
					--			and edc.Num_ptmo is not null
					--			and Saldo_Actual > 0
					--END

					--IF EXISTS (SELECT 1 FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE ID_MOV IN (100,103,112)  AND NUMERO = @numero_Socio)
					--BEGIN
					--    UPDATE cc
					--	SET CC.ACTIVO = 1 
					--	FROM
					--	HAPE..TBL_CORRESPONSALIAS_CUENTAS cc
					--	JOIN HAPE..EDO_DE_CUENTA EDC ON  EDC.Numero =  CC.numero  AND EDC.Id_mov = CC.ID_MOV and edc.Id_Tipo_persona  = 1
					--	WHERE
					--			CC.Numero = @numero_Socio
					--			and edc.Id_Tipo_persona  = 1
					--			and 1 = ( case when edc.Tarjeta_activa = 'T' and edc.Id_mov =112 then 1
					--					  when edc.id_mov in (100,103) then 1  end)
					--END

					--	--------------------------------------------------------------
					--	---- INSERTAMOS LOS PRESTAMOS EN TBL_CORRESPONSALIAS_CUENTAS--
					--	--------------------------------------------------------------

					
					--	INSERT INTO HAPE..TBL_CORRESPONSALIAS_CUENTAS  (NUMERO,CUENTA,FECHA_ALTA,ID_MOV,NUM_PTMO,ACTIVO)
					--	SELECT 
					--	s.numero ,
					--	'797'+'002'+REPLACE(STR(edc.Id_mov, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')  AS CLABE,
					--	getdate(),
					--	edc.Id_mov , 
					--	EDC.Num_ptmo , 
					--	1
					--	FROM  HAPE..PERSONA S  
					--	JOIN HAPE..EDO_DE_CUENTA EDC ON  EDC.Numero =  S.numero  AND EDC.Id_mov  IN (1,2,3,4,5,6,7,8,9) and edc.Id_Tipo_persona  = 1
					--	where
					--		s.Numero = @numero_Socio
					--		and s.Id_Tipo_Persona = 1
					--		and '797'+'002'+REPLACE(STR(edc.Id_mov, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')  not in 
					--	(
					--		SELECT CUENTA FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS 
					--	)
					--	and edc.Id_Tipo_persona  = 1
					--	and edc.Num_ptmo is not null
					--	and Saldo_Actual > 0
						


					--------------------------------------------------------------------------------------------------------
					----------------insertamos revolvente CORRESPONSALIAS---------------------------------------------------
					-------------------------------------------------------------------------------------------------------
					--	INSERT INTO HAPE..TBL_CORRESPONSALIAS_CUENTAS  (NUMERO,CUENTA,FECHA_ALTA,ID_MOV,NUM_PTMO,ACTIVO)
					--	SELECT 
					--	s.numero,
					--	'797'+'002'+REPLACE(STR(10, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')  AS CLABE,
					--	getdate(),
					--	10, 
					--	lc.num_ptmo , 
					--	1
					--	FROM  HAPE..PERSONA S JOIN
					--	HAPE..TBL_REVOLVENTE_LINEAS_CREDITO LC ON  lc.numero =  S.numero  
					--	 where
					--		s.Numero = @numero_Socio
					--		and s.Id_Tipo_Persona = 1 and '797'+'002'+REPLACE(STR(10, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')
					--		not in (   SELECT CUENTA FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS )


					--------------------------------------------------------------------------------------------------
					---- INSERTAMOS LOS HABERES EN TBL_CORRESPONSALIAS_CUENTAS----------------------------------------
					--------------------------------------------------------------------------------------------------

					--INSERT INTO HAPE..TBL_CORRESPONSALIAS_CUENTAS  (NUMERO,CUENTA,FECHA_ALTA,ID_MOV,NUM_PTMO,ACTIVO)
					--SELECT 
					--s.numero ,
					--'797'+'001'+REPLACE(STR(edc.Id_mov, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')  AS CLABE,
					--getdate(),
					--edc.Id_mov , 
					--EDC.Num_ptmo , 
					--1
					--FROM  HAPE..PERSONA S  
					--	JOIN HAPE..EDO_DE_CUENTA EDC ON  EDC.Numero =  S.numero  AND EDC.Id_mov  in (100,103,112) and edc.Id_Tipo_persona = 1
					--	where
					--	s.Numero = @numero_Socio
					--	and s.Id_Tipo_Persona = 1
					--	and ('797'+'001'+cast(edc.Id_mov as varchar)+REPLACE(STR(S.numero , 7), SPACE(1), '0') ) not in 
					--	(
					--	SELECT CUENTA FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS 
					--	)
					--and 1 = (case when edc.Tarjeta_activa = 'T' and edc.Id_mov =112 then 1
					--				when edc.id_mov in (100,103) then 1  end)
					--and edc.Id_Tipo_persona  = 1


					---- INSERTAMOS LAS CUENTAS INTERBANCARIAS EN TBL_CORRESPONSALIAS_INTERBANCARIAS
					--INSERT INTO TBL_BANCA_CUENTAS_INTERBANCARIAS (numero_socio,clabe,FECHA_ALTA,ID_MOV,NUM_PTMO,ACTIVO)
					--SELECT 
					--s.numero ,
					--'01797'+'001'+REPLACE(STR(edc.Id_mov, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')  AS CLABE,
					--getdate(),
					--edc.Id_mov , 
					--edc.Num_ptmo , 
					--1
					--FROM  HAPE..PERSONA S   
					--JOIN HAPE..EDO_DE_CUENTA EDC ON  EDC.Numero =  s.numero  AND EDC.Id_mov  in (100,103,112,1,2,3,4,5,6,7,8,9) and edc.Id_Tipo_persona = 1
					--	where
					--	s.Numero = @numero_Socio
					--	and s.Id_Tipo_Persona = 1
					--	and '01797'+'001'+REPLACE(STR(edc.Id_mov, 3), SPACE(1), '0')+REPLACE(STR(s.numero, 7), SPACE(1), '0')  not in 
					--	(
					--	SELECT clabe FROM TBL_BANCA_CUENTAS_INTERBANCARIAS 
					--	)

					--and 1 = (case when edc.Tarjeta_activa = 'T' and edc.Id_mov =112 then 1
					--			when edc.id_mov in (100,103) then 1  
					--			when EDC.Id_mov in (1,2,3,4,5,6,7,8,9) and EDC.Saldo_Actual>0 AND EDC.Num_ptmo IS NOT NULL then 1
					--			end)
					--and edc.Id_Tipo_persona  = 1


		---SE INSERTA UNA ALERTA DE FRAUDE CUANDO EL SOCIO TENGA UNA EDAD MAYOR A LA DE @socio_edad--

					--EXEC SP_BANCA_FRAUDE_SIN_MOVIMIENTOS @numero_Socio
					exec SP_BANCA_FRAUDE_CREACION_PERFIL_TRANSACCIONAL_SOCIO @numero_Socio, @numero_usuario


					DECLARE @edad_Socio int, @FECHA_2 DATETIME = GETDATE(), @FECHA_1 DATETIME = (select Fecha_de_nacimiento from HAPE..persona where numero = @numero_Socio and Id_Tipo_Persona=1)

					set @edad_Socio =
					(select year(@fecha_2) - year(@fecha_1)
					-      case
							when
								substring(convert(varchar, @fecha_1, 112), 5, 4) >
								substring(convert(varchar, @fecha_2, 112), 5, 4)
										then 1
							else 0
					end
					)

					--select * from banca..TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS

					/*select  
						@socio_edad =  cast(Valor as int)
					from 
						banca..TBL_BANCA_FRAUDE_ADMINISTRADOR_PARAMETROS 
					where 
						Id_parametro = 2
					and 
						Nombre_parametro 
					like 
						'%Alerta por Edad%'

					if(@edad_Socio>=@socio_edad)
					begin
					print''
						--EXEC SP_BANCA_FRAUDE_ALERTA_SOCIOS_MAYORES_DE_60 @numero_Socio
						if not exists(select * 	from  TBL_BANCA_FRAUDE_ALERTA where NUMERO_SOCIO = @numero_Socio and ID_TIPO_ALERTA = 5) 
							
							insert into TBL_BANCA_FRAUDE_ALERTA 
							(
								Fecha_alerta,
								NUMERO_SOCIO,
								ID_TIPO_ALERTA,
								ID_ALERTA_RECURRENTE,
								ID_ESTATUS
							)
							values
							(
								getdate(),
								@numero_Socio,
								4,
								0,
								1
							)

					end*/

					exec SP_BANCA_FRAUDE_ALERTA_EDAD @numero_socio


		--SE INSERTA UNA ALERTA DE FRAUDE CUANDO EL SOCIO QUE SE REGISTRO EN BANCA NO TIENE MOVIMIENTOS EN MAS DE UN A�O--
					exec SP_BANCA_FRAUDE_SIN_MOVS_ANIO_TST @numero_Socio

					

		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
				
		end -- reporte de status
		
	end -- procedimiento


GO
GRANT EXECUTE ON [dbo].[SP_BANCA_INSERTAR_SOCIO] TO [public] AS [dbo]
GO

/****** Object:  StoredProcedure [dbo].[SP_BANCA_CANCELAR_SERVICIO_BANCA]    Script Date: 04/02/2020 01:59:27 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_BANCA_CANCELAR_SERVICIO_BANCA]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[SP_BANCA_CANCELAR_SERVICIO_BANCA] AS' 
END
GO

ALTER proc

	 [dbo].[SP_BANCA_CANCELAR_SERVICIO_BANCA]
	
		-- par�metros
		@numero_Socio Int,
		@tipo_origen int = null,
		@numero_usuario varchar(20) = null,
		@descripcion_cancelar varchar(max)
		-- [aqu� van los par�metros]

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@id_banca_folio int,
						@id_tipo_bitacora int  = 40
						
			
			end -- inicio
			
		  ---SELECT * FROM CAT_BANCA_ESTATUS_BANCA

			update TBL_BANCA_SOCIOS set
				id_estatus_banca = 9, 
				id_motivo_bloqueo=5,
				banca_activa = 0,
				descripcion_cancelacion=@descripcion_cancelar,
				fecha_alta_solicitud =GETDATE(),
				viene_de_bloqueo = 0,
				contrasena =null,
				fecha_contrasena_temporal = null,
				contrasena_temp = null,
				fecha_alta_contrasena = null,
				id_pregunta_secreta = null,
				respuesta = null,
				fecha_motivo_bloqueo = null,
				id_imagen_antiphishing = null,
				vigencia_contrasena_temporal = null,
				id_ultima_sesion = null,
				fecha_ultima_sesion =null,
				intentos_sesion = null,
				intentos_respuesta = null,
				fecha_de_desbloqueo = null,
				contrasena_estado_cuenta = null,
				recuperar_contrasena = 0
			where numero_socio=@numero_Socio;
			delete from hape..tbl_contratos_haberes where numero = @numero_Socio and id_tipo_contrato = 3

			/*Se desactiva el socio en la tabla de UNE*/
			--select * from une..tbl_callcenter_socios
			
			update 
				une..tbl_callcenter_socios 
			set 
				banca_registrado = 0 
			where
				numero_socio = @numero_Socio 
			
			--select * from BANCA..CAT_BANCA_ESTATUS_TRANSFERENCIAS

			update  TBL_BANCA_TRANSFERENCIAS_INTERNAS
			set
				id_estatus_transferencia = 3
			where 
				numero_socio = @numero_Socio 
			and 
				programada = 1 
			and 
				id_estatus_transferencia = 1
				


			update
				TBL_BANCA_CUENTAS_INTERNAS  
			set
				activo = 0
			where
				numero_socio = @numero_Socio

			--ACTALIZACION QUE DESACTIVA LA CLABE DEL SOCIO SI ES QUE TIENE UNA
			if exists(select 1 from TBL_BANCA_CUENTAS_INTERBANCARIAS where numero_socio = @numero_Socio)
			begin
				update TBL_BANCA_CUENTAS_INTERBANCARIAS set activo = 0 where numero_socio = @numero_Socio
			end

		
			--delete from tbl_banca_cuentas_internas where numero_socio  = @numero_Socio
			--DELETE FROM BANCA..TBL_BANCA_CONTRATOS_BANCA WHERE numero = @numero_Socio
			--------------------	BITACORA	--------------------
			IF @numero_usuario IS NOT NULL AND @numero_usuario <> ''
			BEGIN
				--se inserta a la bitacora directa ya que no es una accion de tansaccionalidad
				INSERT INTO TBL_BANCA_BITACORA_OPERACIONES (id_tipo_bitacora,numero_socio,fecha_alta,id_origen_operacion,usuario)
				VALUES (13/*Cancelacion de servicio*/ , @numero_socio , getdate() , @tipo_origen,@numero_usuario)
			
				------- LLAMADO DE SPS DE  FRAUDES-------
					
				create table #FraudesAlertasBaja
				(
					status int, 
					error_procedure varchar(max), 
					error_line varchar(max), 
					error_severity varchar(max),
					error_message varchar(max)
				)

				insert into #FraudesAlertasBaja
				EXEC SP_BANCA_FRAUDES_DEPURACION_ALERTAS_BAJA_SERVICIO @numero_socio,@numero_usuario

				drop table #FraudesAlertasBaja
				------- LLAMADO DE SPS DE  FRAUDES FIN-------
			END
			-------------------- FIN BITACORA-------------------
			
			IF @@ERROR = 0
				SELECT 200 estatus , 'OK' mensaje
			else
				SELECT -1 estatus , 'OK' mensaje

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end

			select	@status as estatus ,@error_procedure as mensaje


		end catch -- catch principal
		
	end -- procedimiento

GO
GRANT EXECUTE ON [dbo].[SP_BANCA_CANCELAR_SERVICIO_BANCA] TO [public] AS [dbo]
GO