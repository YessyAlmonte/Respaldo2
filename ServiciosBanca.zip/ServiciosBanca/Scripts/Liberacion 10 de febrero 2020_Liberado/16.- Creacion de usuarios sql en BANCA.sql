USE master
GO
--Verificar si existen los store procedures para eliminarlos
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SP_DIG_CREAR_USUARIOS_BASE_DATOS]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[SP_DIG_CREAR_USUARIOS_BASE_DATOS]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[ClavesProcesarPermisos]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[ClavesProcesarPermisos]
GO


--Creaci�n de store procedures
/*
   Autor	Mar Mej�a Murillo
   Fecha	20140925
Objetivo	Restaurar permisos de usuario a bases
Proyecto	Alta de usuarios
*/
CREATE proc [dbo].[ClavesProcesarPermisos]
@usuario	varchar(50)
as
declare @cur_db int, @cur_dbname varchar(256), @sql nvarchar(4000), @status int, @status_desc varchar(255)
set nocount on
create table	#tmp_claves_databases
	(
	dbid	int identity(1, 1),
	dbname	varchar(256)
	)
insert	#tmp_claves_databases
select	name
from	master.dbo.sysdatabases
where	name in ('BANCA')
if @@error <> 0 goto error_0
select	@cur_db = min(dbid)
from	#tmp_claves_databases
while	@cur_db is not null
	begin
	select @cur_dbname = dbname from #tmp_claves_databases where dbid = @cur_db
	select @sql = 'if exists (select 1 from ' + @cur_dbname + '.dbo.sysusers where ltrim(rtrim(name)) like ''' + @usuario + ''') exec '
		+ @cur_dbname + '.dbo.sp_change_users_login ''auto_fix'', ''' + @usuario + '''' + 'else exec ' + @cur_dbname
		+ '.dbo.sp_adduser ''' + @usuario +  ''', ''' + @usuario + ''', ''public'''
	exec sp_executesql @sql
	if @@error <> 0 goto error_0
	select @cur_db = min(dbid) from #tmp_claves_databases where dbid > @cur_db
	end
select @status = 1, @status_desc = 'Permisos restablecidos con �xito para el usuario ' + @usuario
goto EXIT_
ERROR_0:	select @status = 0, @status_desc = 'Error al reestablecer permisos para el usuario ' + @usuario
goto exit_
EXIT_:	set nocount off
drop table #tmp_claves_databases
GO

/*

Autor			PICHARDO HURTADO OSCAR
UsuarioRed		PIHO666482
Fecha			20160322
Objetivo		DAR DE ALTA USUARIOS EN UNA BASE DE DATOS EN PARTICULAR
Proyecto		DIGITALIZADOR
Ticket			170130

*/
CREATE proc

	[dbo].[SP_DIG_CREAR_USUARIOS_BASE_DATOS]
as
	begin
		
		-- bloque principal
		begin try
		
			-- declaraciones internas
			declare @status int = 1,
					@error_message varchar(255) = '',
					@error_line varchar(255) = '',
					@error_severity varchar(255) = '',
					@error_procedure varchar(255) = '',
					@usuario varchar (50)
				
			--Declaraci�n del cursor
			DECLARE permisos_usuarios CURSOR FOR

			select name from sys.syslogins where dbname like 'HAPE' 

			-- Apertura del cursor

			OPEN permisos_usuarios

			-- Lectura de la primera fila del cursor

			FETCH permisos_usuarios INTO @usuario

			WHILE (@@FETCH_STATUS = 0)
				BEGIN
				exec dbo.ClavesProcesarPermisos @usuario
				-- Lectura de la siguiente fila del cursor
				FETCH permisos_usuarios INTO @usuario
				END

			-- Cierre del cursor

			CLOSE permisos_usuarios

			-- Liberar los recursos

			DEALLOCATE permisos_usuarios
		
		end try
		
		-- en caso de error en bloque principal
		begin catch
		
			-- captura del error
			select	@status = 0,
					@error_procedure = coalesce(error_procedure(), 'AGREGAR USUARIOS'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
			DEALLOCATE permisos_usuarios
		
		end catch
		
		-- reporte de status
		select	@status status,
				@error_procedure error_procedure,
				@error_line error_line,
				@error_severity error_severity,
				@error_message error_message
		
	end
GO

--PERMISOS
GRANT  EXEC  ON [dbo].SP_DIG_CREAR_USUARIOS_BASE_DATOS  TO [public]
GO

GRANT  EXEC  ON [dbo].ClavesProcesarPermisos  TO [public]
GO

--EXECUTAR SCRIPTS
EXEC [dbo].SP_DIG_CREAR_USUARIOS_BASE_DATOS 
GO