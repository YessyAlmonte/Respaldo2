USE[HAPE]


IF NOT EXISTS (SELECT name FROM master.sys.databases WHERE name = N'BANCA')
	CREATE DATABASE BANCA
	collate Traditional_Spanish_CI_AS
GO

use BANCA
go
