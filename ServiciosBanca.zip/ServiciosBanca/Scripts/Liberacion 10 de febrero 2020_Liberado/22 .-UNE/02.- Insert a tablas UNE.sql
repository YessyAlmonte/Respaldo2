use une
go

if not exists (select * from CAT_MODULO_ATENCION where MODULO_ATENCION = 'CALL CENTER')
begin

	INSERT INTO 
		CAT_MODULO_ATENCION (MODULO_ATENCION,ACTIVO)
	VALUES
		('CALL CENTER',1)
end

-----------select * from CAT_MODULO_ATENCION

if not exists (select * from CAT_MODULO_ATENCION where MODULO_ATENCION = 'FRAUDES')
begin

	INSERT INTO 
		CAT_MODULO_ATENCION (MODULO_ATENCION,ACTIVO)
	VALUES
		('FRAUDES',1)
end

--select * from CAT_MODULO_ATENCION



if not exists (select * from CAT_MODULO_ATENCION where MODULO_ATENCION = 'UNE')
begin

	INSERT INTO 
		CAT_MODULO_ATENCION (MODULO_ATENCION,ACTIVO)
	VALUES
		('UNE',1)
end

--select * from CAT_MODULO_ATENCION

if not exists (select * from CAT_UNE_LIMITE_LLAMADAS where id_limite = 1)
begin
	insert into CAT_UNE_LIMITE_LLAMADAS (numero_llamada, fecha_actualizacion_catalogo) values
	(
		0,
		FORMAT(GETDATE(),'yyyy-MM') --'2019-11' --FORMAT(GETDATE(),'yyyy-MM')
	)
end