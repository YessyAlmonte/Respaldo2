USE [UNE]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_VALIDA_FOLIO_SOCIO]    Script Date: 20/11/2019 10:11:50 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

if exists (select * from sysobjects where name like 'SP_CALLCENTER_ACTUALIZAR_GRABACION_DATOS' and xtype = 'p')
	drop proc SP_CALLCENTER_ACTUALIZAR_GRABACION_DATOS
go

create proc


	[dbo].[SP_CALLCENTER_ACTUALIZAR_GRABACION_DATOS]
	
		-- parametros
		@contactID varchar(max),
		@crmFolio int = null, 		
		@folioAtencion int = null
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = ''

					
			end -- inicio
			
			/*					
			*/
			
			begin -- �mbito de la actualizaci�n
				
				if exists(select 1 from CMV_REC_DATA where INB_OUT_ID = @contactID)
				begin
					update CMV_REC_DATA set CRM_FOLIO = @crmFolio, FOLIO_ATENCION = @folioAtencion where INB_OUT_ID = @contactID
					select @estatus = 200;
					select @mensaje = 'Regisitro Actualizado';
				end
				else
				begin
					select @error_message = 'El folio ingresado no existe';
					select @estatus = -1;
				end
				
							
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			else
			begin
				select @estatus estatus, @mensaje as mensaje
			end			
		end -- reporte de estatus
		
	end -- procedimiento
	go
	grant exec on SP_CALLCENTER_ACTUALIZAR_GRABACION_DATOS to public
	go

USE [UNE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20191203
Objetivo		insertar en la tabla de CMV_DATA_REC
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_CALLCENTER_REGISTRAR_LLAMADA' and xtype = 'p')
	drop proc SP_CALLCENTER_REGISTRAR_LLAMADA
go

create proc

	[dbo].[SP_CALLCENTER_REGISTRAR_LLAMADA]
	
		-- parametros		
		
		@vContactID int = null,
		@vCallType int = null,
		@vPhone varchar(50) = null,
		@vServiceID int = null,
		@vAgenteID int =null,
		@folio int = null,
		@moduloAtencion int = null,
		@nombreAgente varchar(50) = null,
		@idSeguimiento varchar (150) = null


		--INB_OUT_ID, CALLTYPE, PHONE, SERVICEID, USER_LOGIN
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''										
											
					
			end -- inicio
			
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		

		if not exists (select 1 from CMV_REC_DATA where INB_OUT_ID = @vContactID)
			begin

				insert into 
				CMV_REC_DATA 
				(
					INB_OUT_ID, 
					CALLTYPE, 
					PHONE, 
					SERVICEID, 
					USER_LOGIN,
					FOLIO_ATENCION,
					RDATE,
					ID_MODULO_ATENCION,
					N_AGENT,
					ID_SEGUIMIENTO
				) 
				values
				(
					@vContactID,
					@vCallType, 
					@vPhone, 
					@vServiceID, 
					@vAgenteID,
					@folio,
					GETDATE(),
					@moduloAtencion,
					@nombreAgente,
					@idSeguimiento
				)



				select @estatus = 1;

			end
			else
			begin
				select  @error_message = 'El reporte ya se inserto anteriormente.', @estatus = 0
				select @estatus = -1;
			end


		begin -- reporte de estatus
		if @error_message<>''
		begin
			select	
				@estatus estatus,
				@error_procedure error_procedure,
				@error_line error_line,
				@error_severity error_severity,
				@error_message error_message
			
		end
		else
		select 
			@estatus estatus
		end -- reporte de estatus
		
	end -- procedimiento
	go

	grant exec on SP_CALLCENTER_REGISTRAR_LLAMADA to public
	go

	USE [UNE]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_VALIDA_FOLIO_SOCIO]    Script Date: 20/11/2019 10:11:50 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

if exists (select * from sysobjects where name like 'SP_FRAUDES_GENERAR_URL_LLAMADA' and xtype = 'p')
	drop proc SP_FRAUDES_GENERAR_URL_LLAMADA
go

create proc


	[dbo].[SP_FRAUDES_GENERAR_URL_LLAMADA]
	
		-- parametros
		@name varchar(max), -- = 'Cristian',
		@phone varchar(max) -- ='7861021588'
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = '',

						@ultimoFolio varchar(max),
						@estructuraSource int,
						@url varchar(max) = 'http://localhost:6080/InsertOutboundRecord?',
						@serviceID int = 31205,
						@loadID int = 1000,
						@sourceID varchar(max),
						@status bit = 1,
						@priority int = 100
					
			end -- inicio
			
			/*					
			*/
			
			begin -- �mbito de la actualizaci�n
				
				if(@name = '' or @phone = '')
				begin
					select @error_message = 'Algun parametro de entrada esta vacio'
					select @estatus = 0
				end
				
				else
				begin

					if exists (select 1 from CAT_UNE_LIMITE_LLAMADAS where id_limite = 1 and fecha_actualizacion_catalogo <> FORMAT(GETDATE(),'yyyy-MM')) 
					begin
						print 'se actualiza tabla'
						update CAT_UNE_LIMITE_LLAMADAS set fecha_actualizacion_catalogo = FORMAT(GETDATE(),'yyyy-MM'), numero_llamada = 0 where id_limite = 1
					end
					

					select @ultimoFolio = (REPLACE(STR((select max(numero_llamada) +1 from CAT_UNE_LIMITE_LLAMADAS),6),SPACE(1),'0')) --max(id_tbl_int) +1 from cmv_rec_data
					select @estructuraSource = CONCAT(RIGHT(YEAR(GetDate()), 2), MONTH(GETDATE())) 
					SELECT @sourceID = CONCAT(@estructuraSource, @ultimoFolio);
					--http://localhost:6080/InsertOutboundRecord?ServiceId=31222&LoadId=1000&SourceId=201912121&Name=Pedro_Infante&Phone=931010201&Status=1&Priority=100
					select @url = CONCAT(@url,'ServiceId=',@serviceID,'&LoadId=', @loadID,'&SourceId=',@sourceID,'&Name=',@name,'&Phone=',@phone,'&Status=',@status,'&Priority=',@priority)
					select @estatus = 200
				end
				
							
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			else
			begin
				select @estatus estatus, @mensaje as mensaje, @url as url_llamada
				update CAT_UNE_LIMITE_LLAMADAS set numero_llamada = numero_llamada+1 where id_limite = 1
			end			
		end -- reporte de estatus
		
	end -- procedimiento
	go
	grant exec on SP_FRAUDES_GENERAR_URL_LLAMADA to public
	go

