use BANCA
go

-- se crea procedimiento SP_BANCA_FRAUDE_BLOQUEO_SOCIOS_ALERTADOS
if exists (select * from sysobjects where name like 'SP_BANCA_FRAUDE_BLOQUEO_SOCIOS_ALERTADOS' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_FRAUDE_BLOQUEO_SOCIOS_ALERTADOS
go

/*

Autor			Luis Arturo G�lvez Macias
UsuarioRed		GAML841262
Fecha			20190806
Objetivo		Bloquear a los usuarios que han sido alertados en las  alertas de  Deposito,Retiro,Anzuelo,Tiempo Minimo y Alerta Ciclica
Proyecto		Modulo de Fraudes
Ticket			ticket

*/

create proc

	SP_BANCA_FRAUDE_BLOQUEO_SOCIOS_ALERTADOS
	
		-- parametros
		-- [aqu� van los par�metros]

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@XML XML,
						@motivobloqueo varchar(255)

				declare	@tran_name varchar(32) = 'Bloqueo_Socios',
						@tran_count int = @@trancount,
						@tran_scope bit = 0
										
			end -- inicio

			begin -- transacci�n

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio
				
				begin -- componente de la transacci�n
				
					set  @XML=(
					select 
						Alerta.Fecha_Alerta,alerta.NUMERO_SOCIO,tipo_alerta.DESCRIPCION
					from 
						TBL_BANCA_FRAUDE_ALERTA alerta
						join CAT_BANCA_FRAUDE_TIPO_ALERTA tipo_alerta on alerta.ID_TIPO_ALERTA =  tipo_alerta.ID_TIPO_ALERTA
						where
						cast(alerta.Fecha_Alerta as date) =CAST(GETDATE() as date) 
						and
							alerta.ID_TIPO_ALERTA in (1,2,3,6,7)
						for xml raw('Numeros_alertados'), elements,root('Bloqueo_Fraudes')) 
	 
					select
						@motivobloqueo=motivo_bloqueo 
					from 
						CAT_BANCA_MOTIVOS_BLOQUEO 
					where  
						id_motivo_bloqueo= 13	
						and motivo_bloqueo like '%Bloqueo autom�tico por motivos de fraudes%'/*descripcion_bloqueo*/

					exec SP_BANCA_BLOQUEAR_SOCIO null,null,null,@motivobloqueo,13,7,@xml

					select @XML
				end -- componente de la transacci�n
				
				begin -- commit
					if @tran_count = 0
						begin -- si la transacci�n se inici� dentro de este �mbito
							commit tran @tran_name
							select @tran_scope = 0
						end -- si la transacci�n se inici� dentro de este �mbito
					end -- commit
			end
						
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
			-- revertir transacci�n si es necesario
			if @tran_scope = 1
				rollback tran @tran_name

		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status status,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message error_message
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_FRAUDE_BLOQUEO_SOCIOS_ALERTADOS to public
go