--declare @sql nvarchar(max), @u nvarchar(max)='UNE' 
--select @sql=
--'USE HAPE DROP SCHEMA '+@u+' DROP USER '+@u+' CREATE USER '+@u+' FOR LOGIN '+@u+ 
--' USE QUEBRANTOS DROP SCHEMA '+@u+' DROP USER '+@u+' CREATE USER '+@u+' FOR LOGIN '+@u+ 
--' USE UNE DROP SCHEMA '+@u+' DROP USER '+@u+' CREATE USER '+@u+' FOR LOGIN '+@u+ 
--' USE BANCA DROP SCHEMA '+@u+' DROP USER '+@u+' CREATE USER '+@u+' FOR LOGIN '+@u
--EXEC SP_EXECUTESQL @sql 

USE [HAPE]
GO
if (select COUNT(*) from sys.schemas where name='UNE')>0 drop schema UNE
if (select COUNT(*) from sys.sysusers where name='UNE')>0 drop user UNE
CREATE USER [UNE] FOR LOGIN [UNE]
GO
USE [QUEBRANTOS]
GO
if (select COUNT(*) from sys.schemas where name='UNE')>0 drop schema UNE
if (select COUNT(*) from sys.sysusers where name='UNE')>0 drop user UNE
CREATE USER [UNE] FOR LOGIN [UNE]
GO
USE [BANCA]
GO
if (select COUNT(*) from sys.schemas where name='UNE')>0 drop schema UNE
if (select COUNT(*) from sys.sysusers where name='UNE')>0 drop user UNE
CREATE USER [UNE] FOR LOGIN [UNE]
GO

USE [UNE]
GO
if (select COUNT(*) from sys.schemas where name='UNE')>0 drop schema UNE
if (select COUNT(*) from sys.sysusers where name='UNE')>0 drop user UNE
CREATE USER [UNE] FOR LOGIN [UNE]
GO