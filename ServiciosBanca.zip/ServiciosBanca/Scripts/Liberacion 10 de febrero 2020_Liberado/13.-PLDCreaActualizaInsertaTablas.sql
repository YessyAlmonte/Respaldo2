use LAVADO_DINERO
go

-- se crea tabla TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA
if exists (select * from sysobjects where name like 'TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA' and xtype = 'u' and db_name() = 'LAVADO_DINERO')
	drop table TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA

create table
	TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA
		(
		id_transferencia	bigint constraint PK_TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA primary key clustered not null,
		id_cuenta_interna	bigint,
		monto	varchar	(255),
		fecha_alta_transferencia	datetime,
		fecha_transferencia_realizada	datetime,
		id_estatus_transferencia	int,
		numero_socio	int,
		fecha_programada	datetime,
		id_banca_folio	bigint,
		clave_corresponsalias_origen	varchar(16),
		clave_corresponsalias_destino	varchar	(16),
		programada	char(1)		
		)

grant select, insert, update, delete on TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA to public


GO

if exists (select 1 from sysindexes where name = 'IX_TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA_numero_socio')
   drop index TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA.IX_TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA_numero_socio

create nonclustered index IX_TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA_numero_socio on TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA (numero_socio)

GO

if exists (select 1 from sysindexes where name = 'IX_TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA_fecha_transferencia_realizada')
   drop index TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA.IX_TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA_fecha_transferencia_realizada

create nonclustered index IX_TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA_fecha_transferencia_realizada on TBL_LAVADO_DINERO_TRANSFERENCIAS_INTERNAS_BANCA (numero_socio)
go
USE[LAVADO_DINERO]

if not exists (select * from information_schema.columns where table_name like 'LAVADO_MOVIMIENTOS' and column_name like 'id_origen')
	alter table LAVADO_MOVIMIENTOS add id_origen int null

GO

if exists (select 1 from sysindexes where name = 'IX_LAVADO_MOVIMIENTOS_ID_ORIGEN')
   drop index LAVADO_MOVIMIENTOS.IX_LAVADO_MOVIMIENTOS_ID_ORIGEN

create nonclustered index IX_LAVADO_MOVIMIENTOS_ID_ORIGEN on LAVADO_MOVIMIENTOS (ID_ORIGEN)



