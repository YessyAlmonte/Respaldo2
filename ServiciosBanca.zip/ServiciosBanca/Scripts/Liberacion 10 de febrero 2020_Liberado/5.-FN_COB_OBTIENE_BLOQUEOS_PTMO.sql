USE [HAPE]
GO

/****** Object:  UserDefinedFunction [dbo].[FN_COB_OBTIENE_BLOQUEOS_PTMO]    Script Date: 28/01/2019 01:06:18 p. m. ******/
if exists (SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'dbo'
                    AND specific_name = 'FN_COB_OBTIENE_BLOQUEOS_PTMO'
                    AND Routine_Type = 'FUNCTION')
	DROP FUNCTION [dbo].[FN_COB_OBTIENE_BLOQUEOS_PTMO]
GO

/****** Object:  UserDefinedFunction [dbo].[FN_COB_OBTIENE_BLOQUEOS_PTMO]    Script Date: 28/01/2019 01:06:18 p. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*

Autor			Mar Mej�a Murillo
UsuarioRed		memm373565
Fecha			20181122
Objetivo		Obtener la tasa vigente a la fecha de revisi�n de un plazo fijo con las caracter�sticas indicadas
Proyecto		Inter�s diario de haberes
Ticket			______

*/

create function

	[dbo].[FN_COB_OBTIENE_BLOQUEOS_PTMO]	(@numero int,@idMov int)
	RETURNS @BLOQUEOS_PTMO table
	(
		id_Bloqueo_Ptmo	int null ,
		num_ptmo	varchar(20) null ,
		numero	int null ,
		id_mov	int null ,
		Fecha_modifica	datetime null ,
		cobro_Legal	bit null ,
		id_comision	int null ,
		fecha_alta	datetime null ,
		id_tipo_bloqueo	int null ,
		licenciado varchar(500) null 
	)
		

	begin -- inicio de la funci�n

		declare @licenciado varchar(200) 

		select @licenciado = RTRIM(LTRIM(REPLACE(REPLACE(t.Licenciado_mensaje, 'lic. ',''), 'lic: ','')))
		from PERSONA p
		left join TEXTOS t
		on p.Id_Persona = t.Id_persona
		where numero = @numero
		and Id_Tipo_Persona = 1

		insert into @BLOQUEOS_PTMO (id_Bloqueo_Ptmo,num_ptmo,numero,id_mov,Fecha_modifica,cobro_Legal,id_comision,fecha_alta,id_tipo_bloqueo,licenciado)

	    select 
		cb.id_Bloqueo_Ptmo,cb.num_ptmo,cb.numero,cb.id_mov,cb.Fecha_modifica,cb.cobro_Legal,cb.id_comision,cb.fecha_alta,cb.id_tipo_bloqueo, @licenciado
		from EDO_DE_CUENTA edc
		join TBL_COB_BLOQUEOS_PRESTAMO cb
		on edc.numero = cb.numero
		and edc.Id_mov = cb.id_mov
		and edc.Num_ptmo collate traditional_spanish_ci_as = cb.num_ptmo collate traditional_spanish_ci_as
		where edc.numero = @numero
		and edc.id_mov = @idMov
		union 
		select 
		cb.id_Bloqueo_Ptmo,cb.num_ptmo,cb.numero,cb.id_mov,cb.Fecha_modifica,cb.cobro_Legal,cb.id_comision,cb.fecha_alta,cb.id_tipo_bloqueo, @licenciado
		from TBL_REVOLVENTE_LINEAS_CREDITO lc
		join TBL_COB_BLOQUEOS_PRESTAMO cb
		on lc.numero = cb.numero
		and lc.Num_ptmo collate traditional_spanish_ci_as = cb.num_ptmo collate traditional_spanish_ci_as
		where lc.numero = @numero
		and @idMov = 10

		return
		

	end -- fin de la funci�n


GO

--grant exec on FN_COB_OBTIENE_BLOQUEOS_PTMO to public
go

