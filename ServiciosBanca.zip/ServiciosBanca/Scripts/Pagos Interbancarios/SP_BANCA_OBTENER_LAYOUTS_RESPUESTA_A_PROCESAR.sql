USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_LAYOUTS_RESPUESTA_A_PROCESAR]    Script Date: 24/01/2020 02:18:08 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20200828
Objetivo		Generar Layout para pagos interbancarios 
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_BANCA_OBTENER_LAYOUTS_RESPUESTA_A_PROCESAR' and xtype = 'p')
	drop proc SP_BANCA_OBTENER_LAYOUTS_RESPUESTA_A_PROCESAR
go

create proc

	[dbo].[SP_BANCA_OBTENER_LAYOUTS_RESPUESTA_A_PROCESAR]
	
		-- parametros
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = ''

					
			end -- inicio
			
			/*					
			*/
			
			begin -- �mbito de la actualizaci�n

				SELECT id_layout, nombre_layout, nombre_layout_respuesta FROM TBL_BANCA_LOG_LAYOUTS_PAGOS_INTERBANCARIOS WHERE layout_procesado = 0 OR layout_procesado IS NULL
						
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			
		end -- reporte de estatus
		
	end -- procedimiento
	go

	grant exec on SP_BANCA_OBTENER_LAYOUTS_RESPUESTA_A_PROCESAR to public
	go