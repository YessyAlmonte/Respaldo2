use BANCA
go

-- se crea procedimiento SP_BANCA_VALIDAR_LIMITES_TRANSFERENCIAS
if exists (select * from sysobjects where name like 'SP_BANCA_VALIDAR_LIMITES_TRANSFERENCIAS' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_VALIDAR_LIMITES_TRANSFERENCIAS
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20200928
Objetivo		Validar los limites de horarios de las transferencias
Proyecto		CMVFinanzas
Ticket			ticket

*/

create proc

	SP_BANCA_VALIDAR_LIMITES_TRANSFERENCIAS

	@id_limite_transferencia int,
	@monto money=null,
	@numero bigint=0
	
as

	begin -- procedimiento
		
			begin -- inicio

				-- declaraciones
				declare @status int = 0,
						@mensaje varchar(255) = '',
						@valido bit=0,
						@tipoTransferencia int=0
											
				
			end -- inicio
			
			begin -- validaciones

			   if(@id_limite_transferencia=12)
			     select @tipoTransferencia=8 --PAGOS INTERBANCARIOS
			
			   if(coalesce(@monto,0)=0)
			   begin
			     
				 if(@tipoTransferencia=8)			      
				  select @monto = minimo from BANCA..TBL_BANCA_LIMITES_TRANSFERENCIAS where id_limite_transferencia=13 and activo = 1

			   end		 

			end -- validaciones
			
			begin 

			select 
					@status = estatus, @mensaje = msj from  BANCA.dbo.FN_VALIDAR_LIMITES_TRANSFERENCIAS_DIARIO (@tipoTransferencia,@numero,@monto,null,0)
			
			if (@status=200)
				select @status estatus,'' mensaje,cast(1 as bit) valido
			else
			begin
			   select @status estatus,@mensaje mensaje,cast(0 as bit) valido
			end
			
			end


		
	end -- procedimiento
	
go

grant exec on SP_BANCA_VALIDAR_LIMITES_TRANSFERENCIAS to public

