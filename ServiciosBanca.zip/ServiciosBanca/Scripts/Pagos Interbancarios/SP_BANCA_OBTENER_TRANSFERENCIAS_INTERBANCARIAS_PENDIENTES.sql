USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_TRANSFERENCIAS_INTERBANCARIAS_PENDIENTES]    Script Date: 24/01/2020 02:18:08 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20200828
Objetivo		Se obtienen transferencias en estatus "pendientes" 
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_BANCA_OBTENER_TRANSFERENCIAS_INTERBANCARIAS_PENDIENTES' and xtype = 'p')
	drop proc SP_BANCA_OBTENER_TRANSFERENCIAS_INTERBANCARIAS_PENDIENTES
go

create proc

	[dbo].[SP_BANCA_OBTENER_TRANSFERENCIAS_INTERBANCARIAS_PENDIENTES]
	
		-- parametros
		 @idLayout bigint 
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = ''

					
			end -- inicio
			
			/*					
			*/
			
			begin -- �mbito de la actualizaci�n

				if exists(select 1 from BANCA..TBL_BANCA_LOG_LAYOUTS_PAGOS_INTERBANCARIOS where id_layout = @idLayout)
				begin
					SELECT 
						banca.dbo.fn_banca_descifrar(numero_socio) numero_socio,
						monto,
						fecha_alta_transferencia,
						id_estatus_transferencia,
						id_banca_folio,
						numero_tarjeta,
						cuenta_corresponsalias_retiro,
						programado,
						fecha_programada,
						fecha_transferencia_realizada,
						mensaje_error,
						id_cuenta_externa,
						concepto_pago,
						generado_en_layout,
						fecha_generado_en_layout,
						id_layout 
					FROM  
						BANCA..TBL_BANCA_TRANSFERENCIAS_PAGOS_INTERBANCARIOS where id_estatus_transferencia = 1 and id_layout = @idLayout
					
					select @estatus = 200, @mensaje = 'OK'
				end	
				else
				begin
					select @estatus = -1, @error_message = 'el layout proporcionado no existe'
				end
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			
		end -- reporte de estatus
		
	end -- procedimiento
	go

	grant exec on SP_BANCA_OBTENER_TRANSFERENCIAS_INTERBANCARIAS_PENDIENTES to public
	go