use BANCA
go

-- se crea procedimiento SP_BANCA_REALIZA_TRANSFERENCIA_EXTERNA_TDC
if exists (select * from sysobjects where name like 'SP_BANCA_REALIZA_TRANSFERENCIA_EXTERNA_TDC' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_REALIZA_TRANSFERENCIA_EXTERNA_TDC
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20201005
Objetivo		Realiza una transferencia de pago de tarjeta de cr�dito
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_BANCA_REALIZA_TRANSFERENCIA_EXTERNA_TDC
	
	@numero int,
	@monto money,
	@clabe_corresponsalias_retiro varchar(20),
	@numero_tarjeta varchar(20),
	@fecha_programada datetime,
	@programado bit,
	@tipo_origen int, --
	@concepto_pago varchar(300)	

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 0,
						@error_message varchar(255),
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''

                
				--variables internas
				declare 
				@id_bitacora int=105,
				@num_poliza int,
				@fecha_operacion datetime,
				@id_mov int,
				@id_tipomov int,
				@saldo_cuenta_retiro money,
				@id_tipo_persona int=1,
				@id_folio_banca bigint,
				@id_cuenta_externa bigint,
				@id_transferencia bigint,
				@id_persona bigint,
				@nombre_socio varchar(100),
				@Ap_paterno_socio varchar(100),
				@Ap_materno_socio varchar(100),
				@rfc_socio varchar(20),
				@ccostos_origen varchar(10),
				@ccostos_compensacion varchar(10),
				@Num_cuentaContable_sucursal varchar(100),
				@numusuario int  = 1024,
				@id_origen int=case when @tipo_origen=1 then 4 else 3 end,
				@tipo_poliza char(1)='M'


			    select @concepto_pago = RTRIM(@concepto_pago)			
				--extraer datos generales
				select @fecha_operacion = getdate()

				---Se obtiene el numero de poliza de banca
				select @num_poliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
				select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'SPEI')
				and dia = DAY(GETDATE())

				select 
					@id_cuenta_externa = id_cuenta_externa					
				from BANCA..TBL_BANCA_CUENTAS_EXTERNAS 
				where clabe_interbancaria = @numero_tarjeta and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero

						
				declare	@tran_name varchar(32) = 'REGISTRA_PAGO_INTERBANCARIO',
						@tran_count int = @@trancount,
						@tran_scope bit = 0
						
				
			end -- inicio
			
			begin -- validaciones

				--validaciones generales de cmv finanzas
				select @error_message =msj, @status = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@numero,1)
				
				IF(@error_message is not null)
					 raiserror (@error_message, 11, 0)
			    
				--- se valida que exista la clabe de corresponsalias
				if not exists(select * from HAPE..TBL_CORRESPONSALIAS_CUENTAS   
					where NUMERO=@numero and cuenta = @clabe_corresponsalias_retiro and activo = 1)
				begin
					select @status=305
					select @error_message = 'La clabe[' + @clabe_corresponsalias_retiro + '] de corresponsalias proporcionada no existe'
					raiserror (@error_message, 11, 0)
				end	

				--- se valida que la clabe corresponsalias pertenecezca a un haber
				if not exists(select 1 from HAPE..TBL_CORRESPONSALIAS_CUENTAS where NUMERO=@numero and cuenta = @clabe_corresponsalias_retiro and activo = 1 and ID_MOV in (100,103,112))
				begin
					select @status=379
					select @error_message = 'La clabe[' + @clabe_corresponsalias_retiro + '] de corresponsalias proporcionada no est� asociada a una cuenta de haberes'
					raiserror (@error_message, 11, 0)
				end	

				---No existe la cuenta externa destino asociada al socio
				if not exists(select 1 from BANCA..TBL_BANCA_CUENTAS_EXTERNAS  where clabe_interbancaria = @numero_tarjeta and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero)
				begin
					select 
					@status = 328,
					@error_message = 'No existe la cuenta destino, asociada al socio.'
					raiserror (@error_message, 11, 0)
				end					

				--se valida que la cuenta destino este dada de alta como cuenta de tarjeta de credito
				if not exists(select 1 from BANCA..TBL_BANCA_CUENTAS_EXTERNAS  where clabe_interbancaria = @numero_tarjeta and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero and id_tipo_cuenta_externa=2)
				begin
					select 
					@status = 328,
					@error_message = 'La cuenta destino no pertencene a una cuenta de tarjeta de cr�dito.'
					raiserror (@error_message, 11, 0)
				end

				--Uso de cuenta despues de los 30 min. de registro
				if not exists(select 1 from TBL_BANCA_CUENTAS_EXTERNAS where 
					clabe_interbancaria=@numero_tarjeta and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero and activa = 1
					and DATEDIFF(MINUTE,fecha_alta,getdate()) > 30
				)
				begin -- validar que la cuenta deposito tenga un periodo mayor a 30 minutos despues de haber sido dada de alta
					select @status=339
					select @error_message = 'Espere el tiempo de registro de la cuenta para poder hacer uso de ella'
					raiserror (@error_message, 11, 0)
				end -- -- validar que la cuenta de deposito tenga un periodo mayor a 30 minutos despues de haber sido dada de alta
					

				if @monto !> 0
				begin -- validar monto
					select @status=346
					select @error_message = 'El monto indicado debe ser mayor a 0.00'
					raiserror(@error_message, 11, 0)

				end -- validar monto

				if coalesce(@num_poliza, 0) = 0
				begin -- validar p�liza

					select @status=347
					select @error_message = 'El n�mero de p�liza indicado no es v�lido'
					raiserror (@error_message, 11, 0)

				end -- validar p�liza

				if(@programado=1)
				begin
					if ( (convert(varchar, @fecha_programada, 112)<convert(varchar, getdate(), 112)) or (convert(varchar, @fecha_programada, 112)=convert(varchar, getdate(), 112) and convert(char(8), @fecha_programada, 108)<=convert(char(8), getdate(), 108)) )
					begin -- validar fecha de programacion

						select @status=384
						select @error_message = 'Fecha programada invalida'
						raiserror (@error_message, 11, 0)

					end -- validar fecha de programacion
				end

				--===================================	VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS	===============================
			
				if @monto > (select monto_maximo from TBL_BANCA_CUENTAS_EXTERNAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)=@numero 
					and clabe_interbancaria=@numero_tarjeta)
				begin -- validar monto maximo de transaccion					
					select @status=321
					select @error_message = 'El monto m�ximo de transferencia de la cuenta es excedido.'
					raiserror (@error_message, 11, 0)

				end -- validar monto maximo de transaccion


				declare 
						@fecha_ datetime,
						@tipoTransferencia int
					 
				if(@programado = 0)
					select @fecha_ = @fecha_operacion
				else
					select @fecha_ = @fecha_programada

				select @tipoTransferencia = 8	---8.- PAGOS INTERBANCARIOS

				select 
					@status = estatus, @error_message = msj  
				from  
					FN_VALIDAR_LIMITES_TRANSFERENCIAS_DIARIO (@tipoTransferencia,@numero,@monto,@fecha_,@programado)

				if @status <> 200
				begin
					raiserror (@error_message, 11, 0)
				end

				
			end -- validaciones

			begin -- preparaci�n
			
				print '[aqu� van la preparaci�n previa que sea necesaria antes de actualizar]'
			
			end -- preparaci�n
			
			begin -- transacci�n

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio
				
				begin -- componente de la transacci�n

				
					---se obtienen los datos de la cuenta de retiro
					select @id_mov=ID_MOV from HAPE..TBL_CORRESPONSALIAS_CUENTAS where NUMERO=@numero and cuenta = @clabe_corresponsalias_retiro and activo = 1

					Select @id_tipomov = case when @id_mov=100 then 1204 --Retiro de AHORRO CMV por pago interbancario
											  when @id_mov=103 then 1207 --Retiro de INVERDIN�MICA CMV por pago interbancario
											  when @id_mov=112 then 1210 --Retiro de DEBITO CMV por Transferencia pago interbancario
										  end
								                            

					select @saldo_cuenta_retiro = HAPE.DBO.FN_OBTENER_SALDO_DISPONIBLE_CTA_HABER(@numero,@id_mov,@id_tipo_persona)
								
					if @saldo_cuenta_retiro < @monto and @programado = 0 ---se valida siempre y cuando ya se valla a afectar
					begin -- validar fondos suficientes

						select @status=329
						select @error_message = 'Saldo insuficiente'
						raiserror(@error_message, 11, 0)

					end -- validar fondos suficientes

					
					----se obtienen los datos del socio
					select 
						@id_persona = p.Id_Persona,
						@nombre_socio = p.Nombre_s,
						@Ap_paterno_socio = p.Apellido_Paterno,
						@Ap_materno_socio = p.Apellido_Materno,
						@ccostos_origen = s.Ccostos,
						@Num_cuentaContable_sucursal = nSuc.Num_Cuenta_Compensacion,
						@rfc_socio = rfc
					from HAPE..PERSONA p
					join HAPE.dbo.sucursales s
						on s.id_de_sucursal = p.id_de_sucursal
					join HAPE..NUM_SUCURSAL nSuc 
						on s.Num_Sucursal = nSuc.Num_Sucursal
					where Numero = @numero and Id_Tipo_Persona = @id_tipo_persona

					select @ccostos_compensacion = Ccostos from HAPE..NUM_SUCURSAL
					WHERE
						Num_Sucursal = 99 --'MEDIOS DE PAGO%'


					---- Generacion de folio de banca
					insert into BANCA..TBL_BANCA_FOLIOS (numero_socio,fecha_alta)
					values (@numero,@fecha_programada)

					select @id_folio_banca = MAX (id_banca_folio) from BANCA..TBL_BANCA_FOLIOS where
					numero_socio = @numero
					--=========== end Generacion de folio de banca

					if @programado = 0
					begin
						set @fecha_programada = null
					end

					---- insercion de transferencia
					insert into BANCA..TBL_BANCA_TRANSFERENCIAS_PAGOS_INTERBANCARIOS 
						(monto,id_estatus_transferencia,numero_socio,fecha_programada,
						programado,fecha_alta_transferencia,id_banca_folio,cuenta_corresponsalias_retiro,
						numero_tarjeta,id_cuenta_externa,concepto_pago
						)
					values
						(@monto,1/*pendiente*/,BANCA.dbo.FN_BANCA_CIFRAR(@numero),@fecha_programada,
						@programado,@fecha_operacion,@id_folio_banca,@clabe_corresponsalias_retiro,
						@numero_tarjeta,@id_cuenta_externa,@concepto_pago)

					select @id_transferencia = max (id_transferencia) from BANCA..TBL_BANCA_TRANSFERENCIAS_PAGOS_INTERBANCARIOS 
					where
						BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero and id_cuenta_externa = @id_cuenta_externa and numero_tarjeta = @numero_tarjeta
					--=========== insercion de transferencia

					---- Afectaci�n de saldos
					if(@programado = 0)
					begin
						/*========================================	RETIRO DE DEBITO CMV	=======================================
						==============================================================================================================*/
						INSERT	HAPE..MOVIMIENTOS
							(
							NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
							NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
							ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR,id_origen
							)
						VALUES	(
							@numero, 'T', @fecha_operacion, @monto,round((@saldo_cuenta_retiro - @monto),2), 'D',
							@num_poliza, @id_folio_banca, GETDATE(), @id_persona, @numusuario,
							@id_tipomov, @id_mov,1, 'S',@id_origen
							)					


						begin -- preparar captura
						
							--movimiento de cuenta
							insert	HAPE..CAPTURA
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	@id_persona,
									'T',
									@numero,
									@nombre_socio,
									@Ap_paterno_socio,
									@Ap_materno_socio,
									total_movs = 1,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion,
									fecha_mov = @fecha_operacion,
									monto = abs(@monto),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @id_folio_banca,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									planx = null,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha_operacion as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'D',
									numusuario = @numusuario,
									numero_fin = null,
									plazo = null,
									interes_ord = null,
									interes_mor = null,
									contador_provision = null,
									@ccostos_origen,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = null,
									id_esquema = null,
									titular = 'S',
									num_ptmo = null,
									id_amortizacion = null,
									id_renovado = null,
									reestructura = null,
									id_origen = @id_origen
								from	HAPE.dbo.tipo_mov tm
								join HAPE.dbo.cuentas_contables cc
									on tm.id_mov = @id_mov and
									tm.id_tipomov = @id_tipomov 
									and cc.concepto like '%DEBITO%'
									and cc.Num_cuenta like '2160000000%'
							--Medios de pago		
							insert	HAPE..CAPTURA
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	@id_persona,
									'T',
									@numero,
									@nombre_socio,
									@Ap_paterno_socio,
									@Ap_materno_socio,
									total_movs = 1,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = cc.Concepto,
									fecha_mov = @fecha_operacion,
									monto = abs(@monto),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @id_folio_banca,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									planx = null,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha_operacion as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'H',
									numusuario = @numusuario,
									numero_fin = null,
									plazo = null,
									interes_ord = null,
									interes_mor = null,
									contador_provision = null,
									@ccostos_origen,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = null,
									id_esquema = null,
									titular = 'S',
									num_ptmo = null,
									id_amortizacion = null,
									id_renovado = null,
									reestructura = null,
									id_origen = @id_origen
								from	HAPE.dbo.tipo_mov tm
								join HAPE.dbo.cuentas_contables cc
									on tm.id_mov = @id_mov and
									tm.id_tipomov = @id_tipomov 
									and cc.concepto like '%MEDIOS%'
									and cc.Num_cuenta like '1410100099%'	
							--sucursal del socio
							insert	HAPE..CAPTURA
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	@id_persona,
									'T',
									@numero,
									@nombre_socio,
									@Ap_paterno_socio,
									@Ap_materno_socio,
									total_movs = 1,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = cc.Concepto,
									fecha_mov = @fecha_operacion,
									monto = abs(@monto),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @id_folio_banca,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									planx = null,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha_operacion as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'D',
									numusuario = @numusuario,
									numero_fin = null,
									plazo = null,
									interes_ord = null,
									interes_mor = null,
									contador_provision = null,
									@ccostos_compensacion,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = null,
									id_esquema = null,
									titular = 'S',
									num_ptmo = null,
									id_amortizacion = null,
									id_renovado = null,
									reestructura = null,
									id_origen = @id_origen
								from	HAPE.dbo.tipo_mov tm
								join HAPE.dbo.cuentas_contables cc
									on tm.id_mov = @id_mov and
									tm.id_tipomov = @id_tipomov 
									and cc.Num_cuenta = @Num_cuentaContable_sucursal
							--SPEI
							insert	HAPE..CAPTURA
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	@id_persona,
									'T',
									@numero,
									@nombre_socio,
									@Ap_paterno_socio,
									@Ap_materno_socio,
									total_movs = 1,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = cc.Concepto,
									fecha_mov = @fecha_operacion,
									monto = abs(@monto),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @id_folio_banca,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									planx = null,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha_operacion as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'H',
									numusuario = @numusuario,
									numero_fin = null,
									plazo = null,
									interes_ord = null,
									interes_mor = null,
									contador_provision = null,
									@ccostos_compensacion,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = null,
									id_esquema = null,
									titular = 'S',
									num_ptmo = null,
									id_amortizacion = null,
									id_renovado = null,
									reestructura = null,
									id_origen = @id_origen
								from	HAPE.dbo.tipo_mov tm
								join HAPE.dbo.cuentas_contables cc
									on tm.id_mov = @id_mov and
									tm.id_tipomov = @id_tipomov 
									and cc.Num_cuenta = '14100611940000'

						end	-- preparar captura

						begin -- preparar captura_lacp
						
							--movimiento de cuenta
							insert	HAPE..CAPTURA_lacp
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	@id_persona,
									'T',
									@numero,
									@nombre_socio,
									@Ap_paterno_socio,
									@Ap_materno_socio,
									total_movs = 1,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = tm.descripcion,
									fecha_mov = @fecha_operacion,
									monto = abs(@monto),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @id_folio_banca,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									planx = null,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha_operacion as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'D',
									numusuario = @numusuario,
									numero_fin = null,
									plazo = null,
									interes_ord = null,
									interes_mor = null,
									contador_provision = null,
									@ccostos_origen,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = null,
									id_esquema = null,
									titular = 'S',
									num_ptmo = null,
									id_amortizacion = null,
									id_renovado = null,
									reestructura = null,
									id_origen = @id_origen
								from	HAPE.dbo.tipo_mov tm
								join HAPE.dbo.cuentas_contables cc
									on tm.id_mov = @id_mov and
									tm.id_tipomov = @id_tipomov 
									and cc.concepto like '%DEBITO%'
									and cc.Num_cuenta like '2160000000%'
							--Medios de pago		
							insert	HAPE..CAPTURA_lacp
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	@id_persona,
									'T',
									@numero,
									@nombre_socio,
									@Ap_paterno_socio,
									@Ap_materno_socio,
									total_movs = 1,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = cc.Concepto,
									fecha_mov = @fecha_operacion,
									monto = abs(@monto),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @id_folio_banca,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									planx = null,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha_operacion as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'H',
									numusuario = @numusuario,
									numero_fin = null,
									plazo = null,
									interes_ord = null,
									interes_mor = null,
									contador_provision = null,
									@ccostos_origen,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = null,
									id_esquema = null,
									titular = 'S',
									num_ptmo = null,
									id_amortizacion = null,
									id_renovado = null,
									reestructura = null,
									id_origen = @id_origen
								from	HAPE.dbo.tipo_mov tm
								join HAPE.dbo.cuentas_contables cc
									on tm.id_mov = @id_mov and
									tm.id_tipomov = @id_tipomov 
									and cc.concepto like '%MEDIOS%'
									and cc.Num_cuenta like '1410100099%'	
							--sucursal del socio
							insert	HAPE..CAPTURA_lacp
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	@id_persona,
									'T',
									@numero,
									@nombre_socio,
									@Ap_paterno_socio,
									@Ap_materno_socio,
									total_movs = 1,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = cc.Concepto,
									fecha_mov = @fecha_operacion,
									monto = abs(@monto),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @id_folio_banca,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									planx = null,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha_operacion as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'D',
									numusuario = @numusuario,
									numero_fin = null,
									plazo = null,
									interes_ord = null,
									interes_mor = null,
									contador_provision = null,
									@ccostos_compensacion,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = null,
									id_esquema = null,
									titular = 'S',
									num_ptmo = null,
									id_amortizacion = null,
									id_renovado = null,
									reestructura = null,
									id_origen = @id_origen
								from	HAPE.dbo.tipo_mov tm
								join HAPE.dbo.cuentas_contables cc
									on tm.id_mov = @id_mov and
									tm.id_tipomov = @id_tipomov 
									and cc.Num_cuenta = @Num_cuentaContable_sucursal
							--SPEI
							insert	HAPE..CAPTURA_lacp
									(
									id_persona,
									activo,
									numero,
									nombre_s,
									apellido_paterno,
									apellido_materno,
									total_movs,
									total_ficha,
									id_tipomov,
									cuenta,
									concepto,
									fecha_mov,
									monto,
									id_mov,
									num_poliza,
									tipo_poliza,
									folio,
									id_tipo_persona,
									num_cheq,
									desc1,
									desc2,
									planx,
									desc3,
									fecha_dpf_final,
									num_dpf,
									tasa,
									interes,
									dias,
									debe_haber,
									numusuario,
									numero_fin,
									plazo,
									interes_ord,
									interes_mor,
									contador_provision,
									ccostos,
									nombre_beneficiario,
									parentesco_beneficiario,
									porcentaje_beneficiario,
									nombre_beneficiario2,
									parentesco_beneficiario2,
									porcentaje_beneficiario2,
									numero_fin_lacp,
									id_esquema,
									titular,
									num_ptmo,
									id_amortizacion,
									id_renovado,
									reestructura,
									id_origen
									)

							select	@id_persona,
									'T',
									@numero,
									@nombre_socio,
									@Ap_paterno_socio,
									@Ap_materno_socio,
									total_movs = 1,
									total_ficha = 0,
									tm.id_tipomov,
									cuenta = cc.num_cuenta,
									concepto = cc.Concepto,
									fecha_mov = @fecha_operacion,
									monto = abs(@monto),
									tm.id_mov,
									num_poliza = @num_poliza,
									tipo_poliza = @tipo_poliza,
									folio = @id_folio_banca,
									id_tipo_persona = 1,
									num_cheq = 0,
									desc1 = 0,
									desc2 = 0,
									planx = null,
									desc3 = 0,
									fecha_dpf_final = cast(@fecha_operacion as date),
									num_dpf = 0,
									tasa = 0,
									interes = 0,
									dias = 0,
									debe_haber = 'H',
									numusuario = @numusuario,
									numero_fin = null,
									plazo = null,
									interes_ord = null,
									interes_mor = null,
									contador_provision = null,
									@ccostos_compensacion,
									nombre_beneficiario = '',
									parentesco_beneficiario = '',
									porcentaje_beneficiario = 0,
									nombre_beneficiario2 = '',
									parentesco_beneficiario2 = '',
									porcentaje_beneficiario2 = 0,
									numero_fin_lacp = null,
									id_esquema = null,
									titular = 'S',
									num_ptmo = null,
									id_amortizacion = null,
									id_renovado = null,
									reestructura = null,
									id_origen = @id_origen
								from	HAPE.dbo.tipo_mov tm
								join HAPE.dbo.cuentas_contables cc
									on tm.id_mov = @id_mov and
									tm.id_tipomov = @id_tipomov 
									and cc.Num_cuenta = '14100611940000'

						end	-- preparar CAPTURA_lacp
					
						/*========================================	ACTUALIZACI�N DE ESTADO DE CUENTA	================================
						==============================================================================================================*/
						UPDATE	HAPE..EDO_DE_CUENTA
						SET	SALDO_ACTUAL = round(SALDO_ACTUAL - @monto,2),
							FECHA = @fecha_operacion
						WHERE	
							numero = @numero
							and id_mov = @id_mov
							AND Id_Tipo_persona = 1

					end
					--=========== end Afectaci�n de saldos

						
					begin-- INSERCI�N DE BITACORA
						if(@programado = 0 ) --transferencia para realizar
						begin
							print('==========================	PROCESO DE REGISTRO DE BITACORA	=============================')
							select @id_bitacora = case  when @id_mov=112 then 53 --Retiro de D�bito  
														when @id_mov=100 then 52 --Retiro de Ahorro  
														when @id_mov=103 then 51 --Retiro de Inverdinamica 
												  end

							insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							values(@id_folio_banca, @id_bitacora, @numero, getdate(), @tipo_origen)


						end
						else ---Transferencias programadas
						begin
							select @id_bitacora = 107 -- Pago InterBancario Programado

							insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							values(@id_folio_banca, @id_bitacora, @numero, getdate(), @tipo_origen)

						end
					end

					select @status=200,@error_message='El pago se ver� reflejado en la Tarjeta de Cr�dito a mas tardar en los siguientes 2 d�as h�biles bancarios'

				
				end -- componente de la transacci�n
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	--@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
						
			-- revertir transacci�n si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@status estatus,
					case when @status=200 then @id_transferencia else null end IdTransferenciaCMV,
					case when @status=200 then @id_folio_banca else null end folio,
					case when @status=200 then @fecha_operacion else null end HoraTransaccion,
					case when @status=200 then @monto else null end Monto,				
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message mensaje
				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_REALIZA_TRANSFERENCIA_EXTERNA_TDC to public

