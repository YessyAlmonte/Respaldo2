USE[BANCA]

----------------------------------------Limites de horarios para pagos interbancarios
if not exists(select 1 from CAT_BANCA_LIMITES_TRANSFERENCIAS where descripcion like 'Limites de horarios para pagos interbancarios')
INSERT INTO CAT_BANCA_LIMITES_TRANSFERENCIAS(descripcion) values('Limites de horarios para pagos interbancarios')

declare @id_limite_transferencia int

select @id_limite_transferencia=id_limite_transferencia from CAT_BANCA_LIMITES_TRANSFERENCIAS where descripcion like 'Limites de horarios para pagos interbancarios'

IF NOT EXISTS(SELECT 1 FROM TBL_BANCA_LIMITES_TRANSFERENCIAS where id_limite_transferencia=@id_limite_transferencia)
INSERT INTO TBL_BANCA_LIMITES_TRANSFERENCIAS(id_limite_transferencia,minimo,maximo,activo,fecha_alta)
select @id_limite_transferencia,'06:00:00','22:00:00',1,getdate()

go
-------L�mites  m�ximos y m�nimos de montos en pagos interbancarios
if not exists(select 1 from CAT_BANCA_LIMITES_TRANSFERENCIAS where descripcion like 'L�mites  m�ximos y m�nimos de montos en pagos interbancarios')
INSERT INTO CAT_BANCA_LIMITES_TRANSFERENCIAS(descripcion) values('L�mites  m�ximos y m�nimos de montos en pagos interbancarios')

declare @id_limite_transferencia int

select @id_limite_transferencia=id_limite_transferencia from CAT_BANCA_LIMITES_TRANSFERENCIAS where descripcion like 'L�mites  m�ximos y m�nimos de montos en pagos interbancarios'

IF NOT EXISTS(SELECT 1 FROM TBL_BANCA_LIMITES_TRANSFERENCIAS where id_limite_transferencia=@id_limite_transferencia)
INSERT INTO TBL_BANCA_LIMITES_TRANSFERENCIAS(id_limite_transferencia,minimo,maximo,activo,fecha_alta)
select @id_limite_transferencia,1,50000,1,getdate()

go

if not exists(select 1 from CAT_BANCA_LIMITES_TRANSFERENCIAS where descripcion like 'Limite acumulado pagos interbancarios')
INSERT INTO CAT_BANCA_LIMITES_TRANSFERENCIAS(descripcion) values('Limite acumulado pagos interbancarios')

declare @id_limite_transferencia int

select @id_limite_transferencia=id_limite_transferencia from CAT_BANCA_LIMITES_TRANSFERENCIAS where descripcion like 'Limite acumulado pagos interbancarios'

IF NOT EXISTS(SELECT 1 FROM TBL_BANCA_LIMITES_TRANSFERENCIAS where id_limite_transferencia=@id_limite_transferencia)
INSERT INTO TBL_BANCA_LIMITES_TRANSFERENCIAS(id_limite_transferencia,minimo,maximo,activo,fecha_alta)
select @id_limite_transferencia,1,50000,1,getdate()


select * from CAT_BANCA_LIMITES_TRANSFERENCIAS
select * from TBL_BANCA_LIMITES_TRANSFERENCIAS


use BANCA
go

--BITACORAS DE PAGO DE TARJETAS DE CREDITO--

if not exists(select 1 from cat_banca_tipos_bitacora where descripcion = 'Pago interbancario')
begin
	insert into cat_banca_tipos_bitacora (descripcion)
	values('Pago interbancario')
end

if not exists(select 1 from cat_banca_tipos_bitacora where descripcion = 'Devoluci�n pago interbancario rechazado')
begin
	insert into cat_banca_tipos_bitacora (descripcion)
	values('Devoluci�n pago interbancario rechazado')
end

if not exists(select 1 from cat_banca_tipos_bitacora where descripcion = 'Pago interbancario programado')
begin
	insert into cat_banca_tipos_bitacora (descripcion)
	values('Pago interbancario programado')
end
		
--CAT_BANCA_ORIGEN_OPERACION--	

--ATM DUAL
if not exists(select 1 from CAT_BANCA_ORIGEN_OPERACION where descripcion = 'ATM DUAL')
begin
	insert into CAT_BANCA_ORIGEN_OPERACION (descripcion, activo)
	values('ATM DUAL', 1)
end

if not exists(select 1 from CAT_BANCA_ORIGEN_OPERACION where descripcion = 'Robot pagos interbancarios')
begin
	insert into CAT_BANCA_ORIGEN_OPERACION (descripcion, activo)
	values('Robot pagos interbancarios', 1)
end

--NOTIFICACIONES DE PAGO DE TARJETAS DE CREDITO--

--Pago de tarjeta de credito
--sms
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 105)
begin
	insert into TBL_BANCA_NOTIFICACIONES_SMS(id_tipo_bitacora, cuerpo, fecha_alta,activo)
	values
	(
		105,
		'CMV Finanzas, Retiro por pago interbancario por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 8003000268 opc 5',	
		GETDATE(),
		1
	)
end

--MAIL
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 105)
begin
	insert into TBL_BANCA_NOTIFICACIONES_CORREO(id_tipo_bitacora, cuerpo, asunto, url_img_operacion, fecha_alta,activo)
	values
	(
		105,		
		'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p>La operaci�n de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
														<p>se realiz� exitosamente</p>
													</div>
													
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio </b></span>
															<span>@folio</span>
														</p>
													</div>

													<!-- INICIO  SI ES UNA TRANSFERENCIA -->
													<div id="content-transferencia">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
															<span style="font-weight:500; ">@CuentaRetiro</span>
														</p>
														
													</div>
													<!-- FIN  SI ES UNA TRANSFERENCIA -->

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si t� no realizaste esta operaci�n</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">800 3000 268 opci�n "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedir� informaci�n adicional de tus cuentas</li>
																	<li>No Compartas tu contrase�a de acceso y c�mbiala peri�dicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>',
		'Pago interbancario',
		'',
		GETDATE(),
		1
	)
end

--Pago rechazado de tarjeta de credito
--sms
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 106)
begin
	insert into TBL_BANCA_NOTIFICACIONES_SMS(id_tipo_bitacora, cuerpo, fecha_alta,activo)
	values
	(
		106,
		'CMV Finanzas, Deposito por pago interbancario rechazado por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 8003000268 opc 5',	
		GETDATE(),
		1
	)
end

--MAIL
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 106)
begin
	insert into TBL_BANCA_NOTIFICACIONES_CORREO(id_tipo_bitacora, cuerpo, asunto, url_img_operacion, fecha_alta,activo)
	values
	(
		106,		
		'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p>La operaci�n de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
														<p>se realiz� exitosamente</p>
													</div>
													
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio </b></span>
															<span>@folio</span>
														</p>
													</div>

													<!-- INICIO  SI ES UNA TRANSFERENCIA -->
													<div id="content-transferencia">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
															<span style="font-weight:500; ">@CuentaRetiro</span>
														</p>
														
													</div>
													<!-- FIN  SI ES UNA TRANSFERENCIA -->

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si t� no realizaste esta operaci�n</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">800 3000 268 opci�n "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedir� informaci�n adicional de tus cuentas</li>
																	<li>No Compartas tu contrase�a de acceso y c�mbiala peri�dicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>',
		'Devoluci�n pago interbancario rechazado',
		'',
		GETDATE(),
		1
	)
end
