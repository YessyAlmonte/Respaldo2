USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_GENERAR_LAYOUT_PAGOS_INTERBANCARIOS]    Script Date: 24/01/2020 02:18:08 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20200828
Objetivo		Generar Layout para pagos interbancarios 
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_BANCA_GENERAR_LAYOUT_PAGOS_INTERBANCARIOS' and xtype = 'p')
	drop proc SP_BANCA_GENERAR_LAYOUT_PAGOS_INTERBANCARIOS
go

create proc

	[dbo].[SP_BANCA_GENERAR_LAYOUT_PAGOS_INTERBANCARIOS]
	
		-- parametros
		 @ActualizarRegistros bit = null
		
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @estatus int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@mensaje varchar(max) = '',

						--VARIABLES HEADER--
						@header varchar(110),
						@codigoTipoRegistroHeader varchar(1) = '0',
						@numInstitucion varchar(2) ='39',
						@fechaProceso varchar(6) = 
							concat
							(
								Right(Cast(Year(GETDATE()) As Char(4)),2),
								concat(REPLACE(STR('', 2-len(MONTH(GETDATE()))), SPACE(1), '0'), MONTH(GETDATE())),
								concat(REPLACE(STR('', 2-len(DAY(GETDATE()))), SPACE(1), '0'), DAY(GETDATE()))
							),
						@fechaJulianaProceso varchar(5) = 
						/*Dia Juliano*/
						(right(cast((1 + datediff(dd, cast(convert(char(4), getdate(), 112) + '0101' as date), convert(char(8), getdate(), 112))) as varchar(3)), 3))
						/*A�o Juliano*/
						+Right(Cast(Year(getdate()) As Char(4)),2),
						@institucionSiglas varchar(3) = 'CMV',
						@numArchivo varchar(3) = '001', --siempre sera 001 ya que solo se genera 1 archivo al dia
						@numFuente varchar(3) = '565',
						@numProcedencia varchar(3) = '023',

						--VARIABLES HEADER COMERCIO--
						@headerComercio varchar(110),
						@codigoTipoRegistroComercio varchar(1) = '1',
						@codigoTipoTransacionesAOperar varchar(2) = '20',
						@numeroDeComercio varchar(9) = '000000000', --(REPLACE(STR('', 9), SPACE(1), '0') ),
						@numeroBancoAdquirienteTransacion varchar(2) = '39',
						@sumaImportes varchar(13),
						@sumaImportesMenosComision varchar(13) = '0000000000000', --(REPLACE(STR('', 13), SPACE(1), '0') ),
						@importeComisionAfiliacion varchar(13) = '0000000000000', --(REPLACE(STR('', 13), SPACE(1), '0') ),
						@totalTransaciones varchar(5),
						@numBatchCaptura varchar(10) = '0000000000', --(REPLACE(STR('', 10), SPACE(1), '0') ),
						@sucursalDeposito varchar(5) = '00001', --siempre sera 1 ya que la transferencia saldra de Corporativo (CMV Finazas)
						@numCuentaAfiliacionProsa varchar(15) = '000000000000000', --(REPLACE(STR('', 15), SPACE(1), '0') ),
						
						--VARIABLES REGISTRO DETALLE --
						@codigoTipoRegistroDetalle varchar(1) = '2',
						@extencionNumCuenta varchar(3) = '   ',
						@reservado varchar(2) = '00',						
						@reservadoEspacios varchar(2) = '  ',
						@valorPOS varchar(2) = '  ',
						@valorObtenidoPOSENTRYMODE varchar(2) = '  ',
						@ABM VARCHAR(12) = '            ', -- (REPLACE(STR('', 12), SPACE(1), ' ') ),
						@indicadorPagoInterbancario varchar(1) ='0',

						--VARIABLES TRAILER TRANSACIONAL--
						@trailerTransaccional varchar(110),
						@codigoTipoRegistroTrailerTransaccional varchar(1) = '4',
						@totalTransacciones varchar(6) = '000000',
						@sumaImporteTransacciones varchar(15) = '000000000000000',

						--VARIABLES REGISTRO TRAILER ARCHIVO--
						@registroTrailerArchivo varchar(110),
						@codigoTipoRegistroTrailerArchivo varchar(1) = '9',
						@totalTransacionesCargos varchar(7) = '0000000',
						@sumaImporteTransaccionesCargos varchar(17) = '00000000000000000',
						--VARIABLES NOMBRE ARCHIVO--
						@nombreArchivo varchar(max),
						@numLayoutDia bigint
					
			end -- inicio
			
			/*					
			*/
			
			begin -- �mbito de la actualizaci�n

				--SE GENERA HEADER--
	
				
				select @header = 
					CONCAT
					(
						@codigoTipoRegistroHeader, 
						@numInstitucion, 
						@fechaProceso, 
						concat((REPLACE(STR('', 5-len(@fechaJulianaProceso)), SPACE(1), '0') ), @fechaJulianaProceso), 
						@institucionSiglas, 
						@numArchivo, 
						@numFuente, 
						@numProcedencia
					)								

				--SE GENERA HEADER COMERCIO
				create table #TransferenciasDeHoy
				(
					num_consecutivo bigint IDENTITY,
					monto money,
					fecha_alta_transferencia datetime,
					id_estatus_transferencia int,
					numero_socio varbinary(max),					
					id_banca_folio bigint,
					numero_tarjeta varchar(16)
				)

				INSERT INTO #TransferenciasDeHoy
				SELECT
					CONVERT (money, monto),
					fecha_alta_transferencia,
					id_estatus_transferencia,
					numero_socio,
					id_banca_folio,
					numero_tarjeta
				FROM 
					TBL_BANCA_TRANSFERENCIAS_PAGOS_INTERBANCARIOS
				WHERE generado_en_layout is null --CAST(CONVERT(NVARCHAR, getdate(),112) AS DATE) = CAST(CONVERT(NVARCHAR, fecha_alta_transferencia,112) AS DATE)
				AND id_estatus_transferencia = 1;

				select @sumaImportes =  cast(sum(cast(monto as money)) as varchar(max)) from #TransferenciasDeHoy				
				select @sumaImportes = REPLACE(@sumaImportes, '.', '') 
				select @sumaImportes = (REPLACE(STR('', 13-len(@sumaImportes)), SPACE(1), '0') ) + @sumaImportes				

				select @totalTransaciones = count(*) from #TransferenciasDeHoy
				select @totalTransaciones = (REPLACE(STR('', 5-len(@totalTransaciones)), SPACE(1), '0')) + @totalTransaciones

				select @headerComercio = CONCAT(@codigoTipoRegistroComercio, @codigoTipoTransacionesAOperar, @numeroDeComercio, @numeroBancoAdquirienteTransacion, @sumaImportes, @sumaImportesMenosComision, @importeComisionAfiliacion, @totalTransaciones, @numBatchCaptura, @sucursalDeposito, @numCuentaAfiliacionProsa)				
				
				--GENERAR TRAILER TRANSACCIONAL--
				SELECT 
				@trailerTransaccional =
				concat
				(
					@codigoTipoRegistroTrailerTransaccional, 
					@totalTransacciones,
					@sumaImporteTransacciones,
					concat((REPLACE(STR('', 6-len(@totalTransaciones)), SPACE(1), '0')) , @totalTransaciones),
					concat((REPLACE(STR('', 15-len(@sumaImportes)), SPACE(1), '0') ), @sumaImportes),
					@totalTransacciones,
					@sumaImporteTransacciones
				)

				

				--GENERAR REGISTRO TRAILER ARCHIVO--
				select @registroTrailerArchivo =
					concat
					(
						@codigoTipoRegistroTrailerArchivo,
						@totalTransacionesCargos,
						concat((REPLACE(STR('', 7-len(@totalTransaciones)), SPACE(1), '0')) , @totalTransaciones),
						@sumaImporteTransaccionesCargos,
						concat((REPLACE(STR('', 17-len(@sumaImportes)), SPACE(1), '0') ), @sumaImportes)
					)

				--GENERAR NOMBRE ARCHIVO--
				select 
					@nombreArchivo = 
						concat
							(
								'1565', 
								Right(Cast(Year(getdate()) As Char(4)),2),
								concat(REPLACE(STR('', 2-len(MONTH(GETDATE()))), SPACE(1), '0'), MONTH(GETDATE())),
								concat(REPLACE(STR('', 2-len(DAY(GETDATE()))), SPACE(1), '0'), DAY(GETDATE())),
								'_'
								--,'001'
							)
				
				


				--GENERAR REGISTROS DETALLE--

				select 
					CONCAT(
						@codigoTipoRegistroDetalle,
						case 
							when 
								(len(numero_tarjeta)<16) then ((REPLACE(STR('', 16-len(numero_tarjeta)), SPACE(1), '0')) + numero_tarjeta) 							
							else 
								numero_tarjeta
						end
						,
						@extencionNumCuenta,
						@reservado,
						@numeroDeComercio,
						@codigoTipoTransacionesAOperar,
						@numInstitucion,
						(REPLACE(STR('', 13-len(REPLACE(monto, '.', ''))), SPACE(1), '0') ) + REPLACE(monto, '.', ''),
						(REPLACE(STR('', 13-len(REPLACE(monto, '.', ''))), SPACE(1), '0') ) + REPLACE(monto, '.', ''),
						concat(REPLACE(STR('', 11-len(num_consecutivo)), SPACE(1), '0'), num_consecutivo ),
						@reservadoEspacios,
						@valorPOS,
						@valorObtenidoPOSENTRYMODE,
						concat(REPLACE(STR('', 6-len(id_banca_folio)), SPACE(1), '0'), id_banca_folio ),
						concat
							(
								concat(REPLACE(STR('', 2-len(DAY(GETDATE()))), SPACE(1), '0'), DAY(GETDATE())),
								concat(REPLACE(STR('', 2-len(MONTH(GETDATE()))), SPACE(1), '0'), MONTH(GETDATE())),
								Right(Cast(Year(GETDATE()) As Char(4)),2)
							),						
						@ABM,
						@indicadorPagoInterbancario 
					) registro_detalle
				from 
					#TransferenciasDeHoy

					if @ActualizarRegistros is not null
					begin

						select @numLayoutDia =  case when  max(num_layout_dia) is null then 1 else max(num_layout_dia) +1 end
						from  TBL_BANCA_LOG_LAYOUTS_PAGOS_INTERBANCARIOS where cast(fecha_alta as date) = cast(getdate() as date)

						insert into TBL_BANCA_LOG_LAYOUTS_PAGOS_INTERBANCARIOS
						(
							num_layout_dia,
							fecha_alta,
							nombre_layout,
							nombre_layout_respuesta
						)
						values
						(
							@numLayoutDia,
							getdate(),
							concat(@nombreArchivo, concat((REPLACE(STR('', 3-len(@numLayoutDia)), SPACE(1), '0')) , @numLayoutDia)),
							CONCAT('PMTADQP739D', @fechaProceso, 'DE', concat((REPLACE(STR('', 2-len(@numLayoutDia)), SPACE(1), '0')) , @numLayoutDia))
							
						)

						select 
							@header header, 
							@headerComercio header_comercio, 
							@trailerTransaccional trailer_transaccional,
							@registroTrailerArchivo registro_trailer_archivo,
							@nombreArchivo nombre_archivo,
							@numLayoutDia num_archivo

						UPDATE
							PAI
						SET
							PAI.generado_en_layout = 1,
							PAI.fecha_generado_en_layout = getdate(),
							pai.id_layout = (SELECT MAX(id_layout) FROM BANCA..TBL_BANCA_LOG_LAYOUTS_PAGOS_INTERBANCARIOS)
						FROM
							TBL_BANCA_TRANSFERENCIAS_PAGOS_INTERBANCARIOS PAI
						INNER JOIN 
							#TransferenciasDeHoy TH
						ON 
							PAI.id_banca_folio = TH.id_banca_folio
					end

				drop table #TransferenciasDeHoy
						
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus
			if @error_message<>''
			begin
				select	@estatus estatus,
						@error_procedure error_procedure,
						@error_line error_line,
						@error_severity error_severity,
						@error_message error_message
			end
			
		end -- reporte de estatus
		
	end -- procedimiento
	go

	grant exec on SP_BANCA_GENERAR_LAYOUT_PAGOS_INTERBANCARIOS to public
	go