use hape
go

 
 --INSERT'S A TABLA--
IF NOT EXISTS(select 1 from tipo_mov where id_tipomov=1202)    
INSERT INTO tipo_mov(Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
VALUES(1202,'Dep�sito a AHORRO CMV por operaci�n rechazada pago interbancario',1,100,'H',1)


IF NOT EXISTS(select 1 from tipo_mov where id_tipomov=1203)    
INSERT INTO tipo_mov(Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
VALUES(1203,'Dep�sito a AHORRO CMV por aclaraci�n procedente pago interbancario',1,100,'H',1)
 

IF NOT EXISTS(select 1 from tipo_mov where id_tipomov=1204)    
INSERT INTO tipo_mov(Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
VALUES(1204,'Retiro de AHORRO CMV por pago interbancario',-1,100,'D',2)


IF NOT EXISTS(select 1 from tipo_mov where id_tipomov=1205)    
INSERT INTO tipo_mov(Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
VALUES(1205,'Dep�sito a INVERDIN�MICA CMV por operaci�n rechazada pago interbancario',1,103,'H',1)


IF NOT EXISTS(select 1 from tipo_mov where id_tipomov=1206)    
INSERT INTO tipo_mov(Id_tipomov,Descripcion,Operacion,Id_mov,Debe_haber,id_operacion_pld)
VALUES(1206,'Dep�sito a INVERDIN�MICA CMV por aclaraci�n procedente pago interbancario',1,103,'H',1)


--UPDATE'S A TABLA--
UPDATE HAPE..TIPO_MOV set descripcion = 'Retiro de INVERDIN�MICA CMV por pago interbancario', Operacion=-1,Id_mov=103,Debe_haber='D',id_operacion_pld=2 where Id_tipomov=1207
update HAPE..TIPO_MOV set descripcion = 'Dep�sito a DEBITO CMV por operaci�n rechazada pago interbancario' where id_tipomov = 1208
update HAPE..TIPO_MOV set descripcion = 'Dep�sito a DEBITO CMV por aclaraci�n procedente pago interbancario' where id_tipomov = 1209
update HAPE..TIPO_MOV set descripcion = 'Retiro de DEBITO CMV por pago interbancario' where id_tipomov = 1210

/*
select * from HAPE..TIPO_MOV where Id_tipomov in 
(
1166,
1167,
1168,
1169,
--TRANSFERENCIAS PAGOS INTERBANCARIOS--
1207,
1208,
1209,
1210
)
*/