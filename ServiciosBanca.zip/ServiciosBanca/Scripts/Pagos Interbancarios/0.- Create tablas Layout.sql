use banca
go

IF NOT EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'TBL_BANCA_TRANSFERENCIAS_PAGOS_INTERBANCARIOS')
BEGIN
create table 
	TBL_BANCA_TRANSFERENCIAS_PAGOS_INTERBANCARIOS
	(		
		id_transferencia int IDENTITY,
		numero_socio varbinary(max),
		monto varchar(255),
		fecha_alta_transferencia datetime,
		id_estatus_transferencia int,
		id_banca_folio bigint,
		numero_tarjeta varchar(16),
		cuenta_corresponsalias_retiro varchar(20),
		programado bit,
		fecha_programada datetime,
		fecha_transferencia_realizada datetime,
		mensaje_error varchar(max),
		id_cuenta_externa bigint, 
		concepto_pago varchar(300)
	)
end

IF NOT EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'TBL_BANCA_LOG_LAYOUTS_PAGOS_INTERBANCARIOS')
BEGIN
create table 
	TBL_BANCA_LOG_LAYOUTS_PAGOS_INTERBANCARIOS
	(		
		id_layout int IDENTITY,
		num_layout_dia bigint,
		fecha_alta datetime,
		layout_procesado bit,
		fecha_proceso_layout datetime,
		nombre_layout varchar(50),
		nombre_layout_respuesta varchar(50)
	)
end


--drop table TBL_BANCA_LOG_LAYOUTS_PAGOS_INTERBANCARIOS