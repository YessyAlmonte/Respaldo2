use BANCA
go

-- se crea procedimiento SP_BANCA_ALTA_CUENTA_EXTERNA_CREDITO
if exists (select * from sysobjects where name like 'SP_BANCA_ALTA_CUENTA_EXTERNA_CREDITO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_ALTA_CUENTA_EXTERNA_CREDITO
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20200930
Objetivo		Registrar una alta de cuenta externa de credito
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_BANCA_ALTA_CUENTA_EXTERNA_CREDITO
	
	@Numero varchar(20),
	@numero_tarjeta varchar  (30),
	@alias varchar(255),
	@titular_cuenta varchar(255),
	@monto_maximo money,
	@correo varchar(255),	
	@id_banco int,	
	@id_cuenta_externa int	

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				Declare 
					@mensaje_validacion varchar(500),
					@estatus int=1000 , 
					@numero_int int ,
					@FechaAlta datetime,
					@id_tipo_bitacora int,
					@id_tipo_cuenta_externa int=2 ,--Tarjeta de cr�dito
					@id_origen_operacion int=11

					/*	======	SE QUITAN ESPACIOS DE LA DERECHA EN BLANCO	======	*/
					set @numero_tarjeta = RTRIM(@numero_tarjeta)
					set @alias = RTRIM(@alias)
					set @titular_cuenta = RTRIM(@titular_cuenta)
					set @correo = RTRIM(@correo)
	
					select  @numero_int = CAST(@NUMERO as int ) , 
							@FechaAlta = getdate()
						
	
			end -- inicio
			
			begin -- validaciones
			
				select @mensaje_validacion =msj, @estatus = estatus 
				from  dbo.FN_BANCA_VALIDA_SOCIO(@numero_int,1)

				-- -- se realiza la validaci�n 1 = 0
				if(@mensaje_validacion is not null)				
				 	raiserror(@mensaje_validacion, 11, 0)				

				if(len(@numero_tarjeta) not in (15,16))
				begin
					SELECT  @estatus = 371 , @mensaje_validacion= 'La longitud del numero de tarjeta es incorrecta'
					raiserror(@mensaje_validacion, 11, 0)

				end

			
			
			end -- validaciones
			
			begin -- preparaci�n
			
				IF OBJECT_ID('tempdb..#Bitacora') IS NOT NULL
					DROP TABLE #Bitacora
					
				CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));

			end -- preparaci�n
			
			begin -- �mbito de la actualizaci�n
			
				IF (@id_cuenta_externa IS NULL OR @id_cuenta_externa  = 0) --REGISTRO DE CUENTA
				BEGIN
					IF NOT EXISTS(SELECT *  FROM TBL_BANCA_CUENTAS_EXTERNAS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int and clabe_interbancaria = @numero_tarjeta)
					BEGIN
						INSERT INTO TBL_BANCA_CUENTAS_EXTERNAS 
							(numero_socio, id_tipo_cuenta_externa,titular_cuenta,alias,monto_maximo,correo,clabe_interbancaria,id_banco, fecha_alta,activa)
						VALUES
							(BANCA.dbo.FN_BANCA_CIFRAR(@numero_int),@id_tipo_cuenta_externa,@titular_cuenta,@alias,@monto_maximo,@correo,@numero_tarjeta,@id_banco , @FechaAlta,1)
						
						SELECT  @estatus = 200 , @mensaje_validacion= 'Registro de cuenta exitoso' , @id_tipo_bitacora  =  89
					END
					ELSE
					BEGIN
						IF (SELECT Activa FROM TBL_BANCA_CUENTAS_EXTERNAS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int AND clabe_interbancaria = @numero_tarjeta)=0
						BEGIN
							UPDATE TBL_BANCA_CUENTAS_EXTERNAS
							SET 
								titular_cuenta=@titular_cuenta,
								alias=@alias,
								monto_maximo=@monto_maximo,
								correo=@correo,
								id_banco=@id_banco,
								fecha_alta=@FechaAlta,
								activa=1
							WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int AND clabe_interbancaria = @numero_tarjeta
							
							SELECT  @estatus = 200 , @mensaje_validacion= 'Registro de cuenta exitoso' , @id_tipo_bitacora  =  89
						END
						ELSE
						BEGIN
							SELECT @estatus=id_excepcion,@mensaje_validacion=descripcion
							FROM CAT_BANCA_EXCEPTIONS
							WHERE id_excepcion = 320
						END
					END
				END
				ELSE
				BEGIN ---ACTUALIZACI�N DE CUENTA
					IF EXISTS(SELECT *  FROM TBL_BANCA_CUENTAS_EXTERNAS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int 	and clabe_interbancaria = @numero_tarjeta and id_cuenta_externa = @id_cuenta_externa )
					BEGIN
						UPDATE TBL_BANCA_CUENTAS_EXTERNAS SET
							titular_cuenta = @titular_cuenta,
							alias = @alias,
							monto_maximo = @monto_maximo,
							correo = @correo,
							id_banco = @id_banco
						WHERE
							id_cuenta_externa = @id_cuenta_externa

						SELECT  @estatus = 200 , @mensaje_validacion= 'Registro de cuenta exitoso' , @id_tipo_bitacora  =  91
					END
					ELSE
					BEGIN
						SELECT @estatus=id_excepcion,@mensaje_validacion='La cuenta que desea actualizar no existe' 
						FROM CAT_BANCA_EXCEPTIONS
						WHERE id_excepcion = 320
					END
				END

				-- INSERT EN BITACORRA --
				IF @estatus = 200
				BEGIN
									
					INSERT INTO #Bitacora
					EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero, @id_tipo_bitacora, @id_origen_operacion
					
				END
			
			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@mensaje_validacion =  error_message()					
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select @estatus as estatus , @mensaje_validacion AS mensaje 
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_ALTA_CUENTA_EXTERNA_CREDITO to public

