USE[HAPE]

IF NOT EXISTS(SELECT 1 FROM CAT_CMV_PROCESOS_CRITICOS WHERE proceso LIKE 'ROBOT DE PAGOS PROGRAMADOS')
INSERT INTO CAT_CMV_PROCESOS_CRITICOS(proceso,tipo_proceso,proceso_haberes,proceso_credito)
VALUES('ROBOT DE PAGOS PROGRAMADOS','ROBOT',1,1)
GO

DECLARE @ID_PROCESO INT

SELECT @ID_PROCESO=id_proceso FROM CAT_CMV_PROCESOS_CRITICOS WHERE proceso LIKE 'ROBOT DE PAGOS PROGRAMADOS'

IF NOT EXISTS (SELECT 1 FROM TBL_CMV_DEPENDENCIAS_PROCESOS_CRITICOS WHERE id_proceso=@ID_PROCESO)
INSERT INTO TBL_CMV_DEPENDENCIAS_PROCESOS_CRITICOS(id_proceso,id_proceso_requerido)
select @ID_PROCESO,id_proceso 
from [dbo].[CAT_CMV_PROCESOS_CRITICOS] WHERE id_proceso IN (4,5,6)


select    d.id_proceso,
        p1.proceso,
        d.id_proceso_requerido,
        proceso_requerido = p2.proceso
from    TBL_CMV_DEPENDENCIAS_PROCESOS_CRITICOS d
        join CAT_CMV_PROCESOS_CRITICOS p1
            on p1.id_proceso = d.id_proceso
        join CAT_CMV_PROCESOS_CRITICOS p2
            on p2.id_proceso = d.id_proceso_requerido
		WHERE P1.id_proceso=@ID_PROCESO

