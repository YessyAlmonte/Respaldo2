USE [HAPE]
GO
/****** Object:  StoredProcedure [dbo].[SP_INTERES_DIARIO_OBTIENE_SALDOS]    Script Date: 25/08/2020 10:02:22 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Adrian Coria
UsuarioRed		cofa616206
Fecha			2018/01/04
Objetivo		Obtener los saldos pendientes del socio
Proyecto		Interes diario
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_INTERES_DIARIO_OBTIENE_SALDOS]

		@numero			int,
		@id_mov			int,
		@fecha			datetime = null,
		@tipoConsulta	int = null  -- null o 0 --> default para consulta de cajas al mostrar lo adeudado,
								  -- 1 --> para los resumenes de saldo, mostrar todo lo adeudado

as

	begin -- procedimiento

		begin -- declaraciones

			create table
				#SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR
					(
					status					int null,
					error_procedure			varchar(255) null,
					error_line				varchar(255) null,
					error_severity			varchar(255) null,
					error_message			varchar(255) null,
					seguro_vida				money null,
					seguro_da�os			money null,
					int_mor					money null,
					iva_int_mor				money null,
					int_ord_ven				money null,
					iva_int_ord_ven			money null,
					int_ord_vig				money null,
					iva_int_ord_vig			money null,
					cap_ven					money null,
					cap_vig					money null,
					int_ord_hoy				money null,
					iva_int_ord_hoy			money null,
					cap_no_dev				money null,
					gastos_cobranza			money null,
					iva_gastos_cobranza		money null,
					tasa_gastos_cobranza	float null,
					monto_a_pagar			money null,
					no_asignado				money null,
					saldo_actual			money null,
					saldo_ahorro			money null,
					saldo_inver				money null,
					saldo_debito			money null,
					)

			create table
				#CALENDARIO_OS
					(
					id						int null,
					contador				int null,
					numero					int null,
					id_mov					int null,
					id_esquema				int null,
					monto_inicial			money null,
					saldo_actual			money null,
					tasa_ordinarios			float null,
					tasa_moratorios			float null,
					aplica_iva				bit null,
					cv_diaria				int null,
					fecha_traspaso_CV		datetime null,
					plazo					int null,
					planx					varchar(1) null,
					fecha_inicio			datetime null,
					fecha_fin				datetime null,
					fecha_fin_original		datetime null,
					capital_inicial			money null,
					capital_actual			money null,
					interes					money null,
					iva						money null,
					seguro_vida				money null,
					seguro_da�os			money null,
					total					money null,
					fecha_pago_cajas		datetime null,
					numusuario				int null,
					id_status				int null,
					fecha_alta				datetime null,
					num_ptmo				varchar(14) null,
					num_corte				int null,
					folio					int null,
					fecha_ptmo				datetime null,
					devengado				bit default 0 null,
					vencido					bit default 0 null,
					dias_vencido			int default 0 null,
					moratorios				money default 0 null,
					iva_moratorios			money default 0 null,
					ordinarios_vencidos		money default 0 null,
					iva_ordinarios_vencidos	money default 0 null,
					ordinarios_corte		money default 0 null,
					iva_ordinarios_corte	money default 0 null,
					capital_vencido			money default 0 null,
					capital_corte			money default 0 null,
					ordinarios_al_hoy		money default 0 null,
					iva_ordinarios_al_hoy	money default 0 null,
					capital_no_devengado	money default 0 null,
					interes_diferido_actual money default 0 null,
					)

			declare	@saldo_actual money = 0.0,
					@tasa_mor float = 3.0,
					@saldo_adelanto money = 0.0,
					@id_esquema int,
					@today datetime,
					@plan varchar(1),
					@montoCapAmort money,
					@numPtmo varchar(15),
					@aplicaIVA bit,
					@tasaIVA money,
					@int_mor_quita money = 0.0,
					@iva_int_mor_quita money = 0.0,
					@int_ord_quita money = 0.0,
					@iva_int_ord_quita money = 0.0,
					@reserva_capital money = 0.0,
					@reserva_interes money = 0.0,
					@intMorDespuesVencimiento money = 0.0,
					@ivaMorDespuesVencimiento money = 0.0,
					@intMor money = 0.0,
					@ivaMor money = 0.0,
					@intOrdVen money = 0.0,
					@ivaOrdVen money = 0.0,
					@intOrd money = 0.0,
					@ivaOrd money = 0.0,
					@capitalVencido money = 0.0,
					@capitalVigente money = 0.0,
					@capitalNoDevengado money = 0.0,
					@verCalenda int = 0,
					@tasaIntOrd float = 0.0,
					@ultimoAbono datetime,
					@fechaPtmo datetime,
					@ultimoAbonoConTiempo datetime,
					@intOrdPagadoPostUltAbono money = 0.0,
					@intMorPagadoPostUltAbono money = 0.0,
					@numCorteVigenteCurso int = 0,
					@plazo int = 1,
					@ptmoConCobroLegal bit = 0,
					@ptmoConCondonacionGastosCob bit = 0,
					@primer_corte_vigente money = 0,
					@CV_diaria int,
					@fecha_traspaso_CV datetime,
					@ordinarios_corte money,
					@iva_ordinarios_corte money,
					@ordinarios_al_hoy money,
					@iva_ordinarios_al_hoy money,
					@amortizacion_seguro_vida money,
					@amortizacion_seguro_da�os money,
					@gastos_cobranza money,
					@iva_gastos_cobranza money,
					@tasa_gastos_cobranza money,
					@standalone bit,
					@monto_a_pagar_amortizacion money,
					@fin_periodo_gracia date,
					@int_ord_diferido_vig money = 0.0,
					@int_ord_diferido_ven money = 0.0,
					@int_ord_diferido_no_dev money = 0.0

			select	@today = coalesce(@fecha, cast(getdate() as date)),
					@tipoConsulta = coalesce(@tipoConsulta, 0)
		 
			select	@today = cast(@today as date)

		end -- declaraciones
	
		begin try

			begin -- try principal
		
				if not exists(select numero from persona with (nolock) where numero = @numero and id_tipo_persona = 1)
					raiserror('El numero de socio ingresado no existe', 11, 0)
		
				select	@tasaIVA = tasa / 100.00
				from	tasas 
				where	contador =
							(
							select	max(contador)
							from	tasas
							where	id_mov = 111
							)
							
				select	@saldo_actual = coalesce(saldo_actual, 0),
						@id_esquema = Id_Esquema,
						@saldo_adelanto = coalesce(saldo_adelanto,0),
						@tasa_mor = Int_Mor,
						@plan = PlanX,
						@numPtmo = Num_ptmo,
						@aplicaIVA = aplica_IVA,
						@tasaIntOrd = Int_Ord,
						@ultimoAbono = CAST(Ultimo_Abono as date),
						@fechaPtmo = Fecha_Ptmo,
						@ultimoAbonoConTiempo = Ultimo_Abono,
						@plazo = Plazo,
						@fin_periodo_gracia=fin_periodo_gracia						
				from	edo_de_cuenta with (nolock)
				where	numero = @numero
						and id_mov = @id_mov
						and saldo_actual > 0
		
				-------------------------------------------------------------------------------------------
				begin -- para quitas

					--moratorio que debe pagar
					select	@int_mor_quita = total_pagar,
							@iva_int_mor_quita = round((coalesce(total_pagar, 0)) * @tasaiva * cast(@aplicaiva as int), 2, 0)
					from	tbl_quitas_creditos_movimientos with (nolock)
					where	id_quita =
								(
								select	top 1 id_quita
								from	tbl_quitas_creditos
								where	num_ptmo = @numptmo
										and id_estatus_quita = 2
								)
							and id_tipomov like '86_'

					--ordinario que debe pagar
					select	@int_ord_quita = total_pagar,
							@iva_int_ord_quita = round((coalesce(total_pagar, 0)) * @tasaiva * cast(@aplicaiva as int), 2, 0)
					from	tbl_quitas_creditos_movimientos with (nolock)
					where	id_quita =
								(
								select	top 1 id_quita
								from	tbl_quitas_creditos with (nolock)
								where	num_ptmo = @numptmo
										and id_estatus_quita = 2
								)
							and id_tipomov like '84_'

				end -- para quitas

				if @saldo_actual is null
					or @saldo_actual = 0
					
					raiserror('El cr�dito especificado no tiene saldo pendiente',11,0)
				
				select	@reserva_capital = reserva_capital,
						@reserva_interes = reserva_interes_vigente
				from	tbl_declaracion_cartera with (nolock)
				where	numero = @numero
						and id_mov = @id_mov

			if @id_esquema = 1

				begin -- decrecientes

					begin -- Se obtiene maxima version de calendario vigente del ptmo

						select	@verCalenda = coalesce(MAX(version_calendario), 0)
						from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES with (nolock)
						where	numero = @numero
								and id_mov = @id_mov
								and num_ptmo = @numPtmo
						group by
								numero, id_mov, num_ptmo

						if @verCalenda = 0
							raiserror('El calendario del cr�dito especificado no existe',11,0)

					end -- Se obtiene maxima version de calendario vigente del ptmo
				 
					--Se obtiene el primer numero de corte vigente (amortizacion vigente en curso)

					if CAST(@fechaPtmo as date) = CAST(@today as date) or CAST(@today as date)<=cast(@fin_periodo_gracia as date) -- para creditos nuevos es la primera

						begin

							select @numCorteVigenteCurso = 0

						end

					else

						begin

							if not exists
								(
								select	num_corte
								from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES with (nolock)
								where	numero = @numero
										and id_mov = @id_mov
										and num_ptmo = @numPtmo
										and @today between (fecha_inicio + 1) and fecha_fin
										and version_calendario = @verCalenda
								)

								set @numCorteVigenteCurso = @plazo + 1

							else

								select	@numCorteVigenteCurso = coalesce(num_corte, @plazo + 1)
								from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES with (nolock)
								where	numero = @numero
										and id_mov = @id_mov
										and num_ptmo = @numPtmo
										and @today between (fecha_inicio + 1) and fecha_fin
										and version_calendario = @verCalenda

						end

			

					--Se obtiene al momento los intereses moratorios, ordinario vencido y capital vencido
					if exists
						(
						select	numero
						from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES with (nolock)
						where	numero = @numero
								and id_mov = @id_mov
								and num_ptmo = @numPtmo
								and cast(fecha_fin_original as date) < @today
								and capital_actual > 0
								and version_calendario = @verCalenda
						)

						begin

							select	@intMor = --SUM(coalesce(round((capital_actual * (@tasa_mor / 3e3) * (DATEDIFF(DAY, case when @ultimoAbono > fecha_fin then @ultimoAbono else fecha_fin end, @today))), 2), 0))
											round(coalesce(sum((capital_actual * (@tasa_mor / 3e3) * (DATEDIFF(DAY, case when @ultimoAbono > fecha_fin then @ultimoAbono else fecha_fin end, @today)))), 0),2)
									, @intOrdVen =-- SUM(coalesce(round((capital_actual * (@tasaIntOrd / 3e3) * (DATEDIFF(DAY, case when @ultimoAbono > fecha_fin then @ultimoAbono else fecha_fin end, @today))), 2), 0))
											round(coalesce(sum((capital_actual * (@tasaIntOrd / 3e3) * (DATEDIFF(DAY, case when @ultimoAbono > fecha_fin then @ultimoAbono else fecha_fin end, @today)))), 0),2)
									, @capitalVencido = SUM(capital_actual)
							from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES with (nolock)
							where	numero = @numero
									and id_mov = @id_mov
									and num_ptmo = @numPtmo
									--and cast(fecha_fin_original as date) < @today
									and cast(fecha_fin as date) < @today
									and capital_actual > 0
									and version_calendario = @verCalenda

						end
			
					-- Se obtienen los interes diferidos del ptmo
					if ( (cast(@today as date)) > (cast(@fin_periodo_gracia as date)) )
						begin

							select	@int_ord_diferido_ven = coalesce(sum(interes_diferido_actual), 0)
							from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES with (nolock)
							where	numero = @numero
									and id_mov = @id_mov
									and num_ptmo = @numPtmo
									and cast(fecha_fin as date) < @today
									and capital_actual > 0
									and version_calendario = @verCalenda

							if( @numCorteVigenteCurso = @plazo ) -- si es la ultima amortizacion
								begin
									select	@int_ord_diferido_vig = coalesce(sum(interes_diferido_actual), 0)
									from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES with (nolock)
									where	numero = @numero
											and id_mov = @id_mov
											and num_ptmo = @numPtmo
											and cast(fecha_fin as date) >= @today
											and	@today >= cast(fecha_inicio as date)
											and capital_actual > 0
											and version_calendario = @verCalenda
								end
							else
								begin
									select	@int_ord_diferido_vig = coalesce(sum(interes_diferido_actual), 0)
									from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES with (nolock)
									where	numero = @numero
											and id_mov = @id_mov
											and num_ptmo = @numPtmo
											and cast(fecha_fin as date) > @today
											and	@today >= cast(fecha_inicio as date)
											and capital_actual > 0
											and version_calendario = @verCalenda
								end

						end


					-- Se obtienen los interes diferidos no devengados del ptmo
					select	@int_ord_diferido_no_dev = coalesce(sum(interes_diferido_actual), 0)
					from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES with (nolock)
					where	numero = @numero
							and id_mov = @id_mov
							and num_ptmo = @numPtmo
							and cast(fecha_inicio as date) > @today
							and capital_actual > 0
							and version_calendario = @verCalenda


					--Se obtiene el capital del corte vigente en curso
					select	*
					into	#capital_vigente
					from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES with (nolock)
					where	numero = @numero
							and id_mov = @id_mov
							and num_ptmo = @numPtmo
							and capital_actual > 0
							and version_calendario = @verCalenda
							--and num_corte = @numCorteVigenteCurso
							and (fecha_inicio + 1) <= @today
							and @today <= fecha_fin

					select	@capitalVigente = sum(coalesce(capital_actual, 0))
					from	#capital_vigente

					-- inicia modificacion 20181210
					if (select COUNT(1) from #capital_vigente) = 1

						begin

							select @primer_corte_vigente = capital_actual from #capital_vigente

							if @primer_corte_vigente != @saldo_actual
								and
									(
									select	count(1)
									from	tbl_interes_diario_calendarios_decrecientes
									where	numero = @numero
											and id_mov = @id_mov
											and num_ptmo = @numptmo
											and capital_actual > 0
											and version_calendario = @verCalenda
									) = 1

								select @primer_corte_vigente = @saldo_actual

						end
					-- termina modificacion 20181210

					else if
						(
						select	COUNT(1)
						from	#capital_vigente
						) > 1

						select	@primer_corte_vigente = sum(coalesce(capital_actual, 0))
						from	#capital_vigente
						where	num_corte != @numCorteVigenteCurso

					else

						select @primer_corte_vigente = 0

					--Se obtiene el capital por amortizacion
					select	@montoCapAmort =
								case
									when coalesce(capital_inicial, @saldo_actual) > @saldo_actual --si ya es la ultima y le falta menos del capital completo
										then @saldo_actual
									else coalesce(capital_inicial, @saldo_actual)
								end 			
					from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES cal with (nolock)
					join
						(
						select	numero, id_mov, num_ptmo, version_calendario, min(num_corte) numcorte
						from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES with (nolock)
						where	numero = @numero
								and id_mov = @id_mov
								and num_ptmo = @numPtmo
								and capital_actual > 0
								and version_calendario = @verCalenda
						group by
								numero, id_mov, num_ptmo, version_calendario
						) adeuda
						on cal.numero = adeuda.numero
						and cal.id_mov = adeuda.id_mov
						and cal.num_ptmo = adeuda.num_ptmo
						and cal.version_calendario = adeuda.version_calendario
						and cal.num_corte = adeuda.numCorte						

					--Se obtiene el capital no devengado
					select	@capitalNoDevengado = SUM(coalesce(capital_actual, 0))			
					from	TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES with (nolock)
					where	numero = @numero
							and id_mov = @id_mov
							and num_ptmo = @numPtmo
							and capital_actual > 0
							and version_calendario = @verCalenda
							--and num_corte > @numCorteVigenteCurso
							and fecha_inicio >= @today

					--se calcula el interes ordinario total adeudado
					select @intOrd = round(@saldo_actual * (@tasaIntOrd / 3e3) * (DATEDIFF(DAY, @ultimoAbono, @today)), 2) - coalesce(@intOrdVen, 0)

					-- se suma el interes diferido al odrinario 
					if ( (cast(@today as date)) > (cast(@fin_periodo_gracia as date)) )
						begin 
							select @intOrd = @intOrd + @int_ord_diferido_vig
							select @intOrdVen = @intOrdVen + @int_ord_diferido_ven
						end

					if coalesce(@numCorteVigenteCurso,0) > @plazo -- si ya esta vencido no existe el vigente
					
						begin

							select	@intOrdVen = @intOrdVen + @intOrd,
									@intOrd = 0

						end

			
					--Ordinario pagado despues de ultimo Abono
					select	@intOrdPagadoPostUltAbono = coalesce(SUM(Monto), 0)
					from	MOVIMIENTOS with (nolock)
					where	numero = @numero
							and id_mov = @id_mov
							and activo = 'T'
							and cast(Fecha_Mov as date) > cast(@fechaPtmo as date)
							and cast(Fecha_Mov as date) > cast(@ultimoAbonoConTiempo as date)
							and (Id_tipomov like '6_'
							or Id_tipomov like '26_')

					--Moratorio pagado despues de ultimo Abono
					select	@intMorPagadoPostUltAbono = coalesce(sum(Monto), 0)
					from	MOVIMIENTOS with (nolock)
					where	numero = @numero
							and id_mov = @id_mov
							and activo = 'T'
							and cast(Fecha_Mov as date) > cast(@fechaPtmo as date)
							and cast(Fecha_Mov as date) > cast(@ultimoAbonoConTiempo as date)
							and (Id_tipomov like '7_'
							or Id_tipomov like '27_')

					--se obtiene el interes moratorio adeudado por si pago algo parcial
					select @intMor = @intMor - @intMorPagadoPostUltAbono
					
					--se obtiene el interes ordinario adeudado por si pago algo parcial
					if (@intOrdPagadoPostUltAbono >= (coalesce(@intOrdVen, 0) + coalesce(@intOrd, 0)))

						begin

							select	@intOrdVen = 0.0,
									@intOrd = 0.0

						end

					else
					
						begin

							if (@intOrdPagadoPostUltAbono >= @intOrdVen)

								begin

									select	@intOrdPagadoPostUltAbono = @intOrdPagadoPostUltAbono - @intOrdVen,
											@intOrdVen = 0.0

									select	@intOrd = @intOrd - @intOrdPagadoPostUltAbono
								end

							else

								begin

									select @intOrdVen = @intOrdVen - @intOrdPagadoPostUltAbono

								end
						end 
			
					--Se calcula Ivas
					select	@ivaMor = round(coalesce(@intMor, 0) * @tasaIVA * CAST(@aplicaIVA as int), 2),
							@ivaOrdVen = round(coalesce(@intOrdVen, 0) * @tasaIVA * CAST(@aplicaIVA as int), 2),
							@ivaOrd = round(coalesce(@intOrd, 0) * @tasaIVA * CAST(@aplicaIVA as int), 2) 

					if coalesce(@numCorteVigenteCurso,0)>@plazo -- si ya esta vencido no existe el vigente

						begin

							set @capitalVencido = @saldo_actual

						end

					else -- casos donde el calendario no cuadra con estado de cuenta y es la ultima mensualidad en la version actual

						if
							(
							select	COUNT(*)
							from	tbl_interes_diario_calendarios_decrecientes with (nolock)
							WHERE	numero = @numero
									and id_mov = @id_mov
									and num_ptmo = @numPtmo
									and version_calendario = @verCalenda
									and capital_actual > 0
							) = 1

							begin

								if @capitalVencido>0

									select @capitalVencido = @saldo_actual

								else if	@capitalVigente>0

									select @capitalVigente = @saldo_actual

										--print 'entro'
										--print 'vigente' + cast(@capitalVigente as varchar(100))
										--print 'vencido' + cast(@capitalVencido as varchar(100))
							end

						else -- casos donde el calendario no cuadra con estado de cuenta 

							if coalesce(@numCorteVigenteCurso,0) = @plazo

								begin
			
									select @capitalVigente=@saldo_actual-coalesce(@capitalVencido,0)

								end

					-- Se revisa si el ptmo en cuestion esta en cobro legal ya que este caso es para liquidar 
					if exists
						(
						select	numero
						from	TBL_COB_BLOQUEOS_PRESTAMO
						where	numero = @numero
								and id_mov = @id_mov
								and num_ptmo = @numPtmo
								and id_Bloqueo_Ptmo = 3 --bloqueo en cobro legal
						)

						set @ptmoConCobroLegal = 1

					-- Se revisa si el ptmo en cuestion esta en condonacion de gastos de cobranza ya que este caso es para liquidar 
					if exists
						(
						select	numero
						from	TBL_COBRANZA_CONDONACION_GASTOS_COBRANZA
						where	numero = @numero
								and id_mov = @id_mov
								and num_ptmo = @numPtmo
								and id_status = 1 --estatus Por procesar
						)

						set @ptmoConCondonacionGastosCob = 1

					if @ptmoConCobroLegal = 1 or @ptmoConCondonacionGastosCob = 1

						begin

							select	@capitalVigente = @saldo_actual - @capitalVencido,
									@primer_corte_vigente = 0

						end
				
				
					select	1 as status,
							@saldo_actual as saldo_actual,
							coalesce(@intMor, 0) interes_moratorio,
							coalesce(@intOrdVen, 0) interes_ord_vencido,
							coalesce(@intOrd, 0) interes_ordinario_vigente,
							coalesce(@capitalVencido, 0) capital_vencido,
							coalesce(@capitalVigente, 0) capital_corte,
                            case when CAST(@today as date)<=cast(@fin_periodo_gracia as date) and (@tipoConsulta = 1)
								then @saldo_actual
								else coalesce(@capitalNoDevengado, 0) 
								end capital_no_devengado_fin,  
							(coalesce(@intMor, 0) +
							coalesce(@ivaMor, 0) +
							coalesce(@intOrdVen, 0) +
							coalesce(@ivaOrdVen, 0) +
							coalesce(@intOrd, 0) +
							coalesce(@ivaOrd, 0) +
							coalesce(@capitalVencido, 0) +
							coalesce(@capitalVigente, 0) 
							) pago_al_corriente,
							@saldo_adelanto saldo_adelanto,
							0.0 as seguro_vida,
							0.0 as seguro_danos,				
							coalesce(@montoCapAmort, 0) capitalAmort,
							coalesce(@ivaMor, 0) ivaIntMoratorio,
							coalesce(@ivaOrdVen, 0) ivaIntOrdinarioVencido,
							coalesce(@ivaOrd, 0) ivaIntOrdinarioVigente,
							@int_mor_quita as int_moratorio_quitas,
							@iva_int_mor_quita as int_moratorio_quitas_iva,
							@int_ord_quita as int_ordinario_quitas,
							@iva_int_ord_quita as int_ordinario_quitas_iva,
							@reserva_capital reserva_capital,
							@reserva_interes reserva_interes,
							cast(0 as money) gastos_cobranza,
							cast(0 as money) iva_gastos_cobranza,
							cast(0 as float) tasa_gastos_cobranza,
							primer_corte_vigente = @primer_corte_vigente,
							int_ord_diferido_no_dev = @int_ord_diferido_no_dev
					into	#return

					exec SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR

						@numero = @numero,
						@id_mov = @id_mov,
						@num_ptmo = @numPtmo,
						@monto_a_pagar = null,
						@seguro_vida = 0,
						@seguro_da�os = 0,
						@int_mor = @intMor,
						@iva_int_mor = @ivaMor,
						@int_ord_ven = @intOrdVen,
						@iva_int_ord_ven = @ivaOrdVen,
						@int_ord_vig = @intOrd,
						@iva_int_ord_vig = @ivaOrd,
						@cap_ven = @capitalVencido,
						@cap_vig = @capitalVigente,
						@int_ord_hoy = 0,
						@iva_int_ord_hoy = 0,
						@cap_no_dev = @capitalNoDevengado,
						@fecha = @today

					update	r
					set		gastos_cobranza = d.gastos_cobranza,
							iva_gastos_cobranza = d.iva_gastos_cobranza,
							tasa_gastos_cobranza = d.tasa_gastos_cobranza,
							pago_al_corriente += (d.gastos_cobranza + d.iva_gastos_cobranza)
					from	#return r
							cross join #SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR d

					
					--if exists(select * from TBL_CMV_CONTINGENCIA WHERE numero=@numero and id_mov=@id_mov and activo=1)
					--begin
					--	update #return
					--	SET pago_al_corriente=0
					--end


					select	*
					from	#return

				end -- decrecientes

			else

				begin -- nivelados
				
					CREATE TABLE
						#datos
							(
							status						int null,
							saldo_actual				money null,
							interes_moratorio			money null,
							interes_ord_vencido			money null, 
							interes_ordinario_vigente	money null,
							capital_vencido				money null,
							capital_corte				money null,
							seguro_vida					money null,
							seguro_danos				money null,
							saldo_adelanto				money null,
							pago_al_corriente			money null,
							capital_no_devengado_fin	money null, 
							capitalAmort				money null,
							ivaIntMoratorio				money null,
							ivaIntOrdinarioVencido		money null,
							ivaIntOrdinarioVigente		money null,
							int_moratorio_quitas		money null,
							int_moratorio_quitas_iva	money null,
							int_ordinario_quitas		money null,
							int_ordinario_quitas_iva	money null,
							reserva_capital				money null,
							reserva_interes				money null,
							gastos_cobranza				money null,
							iva_gastos_cobranza			money null,
							tasa_gastos_cobranza		float null,
							primer_corte_vigente		money null,
							int_ord_diferido_no_dev		money null
							)

					begin -- nuevo bloque para resolver nivelados

						begin -- recopilar datos del cr�dito

							select	@id_esquema = id_esquema,
									@plan = planx,
									@saldo_actual = saldo_actual,
									@saldo_adelanto = saldo_adelanto,
									@numPtmo = num_ptmo,
									@aplicaIVA = aplica_iva,
									@cv_diaria = cv_diaria,
									@fecha_traspaso_cv = fecha_traspaso_cv
							from	edo_de_cuenta with (nolock)
							where	numero = @numero
									and id_mov = @id_mov

							select	@reserva_capital = reserva_capital,
									@reserva_interes = reserva_interes_vigente
							from	tbl_declaracion_cartera with (nolock)
							where	numero = @numero
									and id_mov = @id_mov

							if @aplicaIVA = 1

								select @tasaIVA =
									(
									select	tasa * 1e-2
									from	tasas
									where	contador =
												(
												select	max(contador)
												from	tasas
												where id_mov = 111
												)
									)

							if @numPtmo is null

								select	@id_esquema = 4,
										@plan = planx,
										@saldo_actual = saldo_actual,
										@saldo_adelanto = 0,
										@numPtmo = num_ptmo
								from	vw_revolvente_lineas with (nolock)
								where	numero = @numero

							--select @numero, @id_mov, @id_esquema, @plan, @saldo_actual, @saldo_adelanto, @today, @tipoConsulta

						end -- recopilar datos del cr�dito
		
						begin -- recuperar calendario fuera de tbl_nivelados_ptmos

							insert	#CALENDARIO_OS
									(
									id,
									contador,
									numero,
									id_mov,
									id_esquema,
									monto_inicial,
									saldo_actual,
									tasa_ordinarios,
									tasa_moratorios,
									aplica_iva,
									cv_diaria,
									fecha_traspaso_cv,
									plazo,
									planx,
									fecha_fin,
									fecha_fin_original,
									capital_inicial,
									capital_actual,
									interes,
									iva,
									seguro_vida,
									seguro_da�os,
									total,
									fecha_pago_cajas,
									numusuario,
									id_status,
									fecha_alta,
									num_ptmo,
									num_corte,
									folio,
									fecha_ptmo,
									interes_diferido_actual
									)
							select	id = row_number() over (order by numero, num_ptmo, num_pago),
									contador,
									numero,
									id_mov,
									Id_esquema,
									Monto_inicial,
									Saldo_actual,
									tasa_ordinarios = int_ord * 1e-2,
									tasa_moratorios = 3e-2,
									aplica_iva = @aplicaIVA,
									cv_diaria = @cv_diaria,
									fecha_traspaso_cv = @fecha_traspaso_cv,
									plazo,
									planx,
									Fecha_pago,
									fecha_fin_original,
									capital,
									capital,
									interes,
									iva,
									seguro_vida = 0,
									seguro_da�os = 0,
									total,
									cast(fecha_pago_cajas as date),
									numusuario,
									id_status,
									cast(fecha_alta as date),
									num_ptmo,
									num_pago,
									folio,
									cast(fecha_ptmo as date),
									interes_diferido_actual
							from	tbl_automotriz_ptmos with (nolock)
							where	numero = @numero
									and id_mov = @id_mov
									and planx = @plan
									and num_ptmo = @numPtmo

							union

							select	id = row_number() over (order by numero, num_ptmo, num_pago),
									contador,
									numero,
									id_mov,
									Id_esquema,
									Monto_inicial,
									Saldo_actual,
									int_ord,
									tasa_moratorios = 3e-2,
									aplica_iva = @aplicaIVA,
									cv_diaria = @cv_diaria,
									fecha_traspaso_cv = @fecha_traspaso_cv,
									plazo,
									planx,
									Fecha_pago,
									fecha_fin_original,
									capital,
									capital,
									interes,
									iva = 0,
									seguro_vida,
									seguro_da�os = seguro_danos,
									total,
									cast(fecha_pago_cajas as date),
									numusuario,
									id_status,
									cast(fecha_alta as date),
									num_ptmo,
									num_pago,
									folio,
									fecha_ptmo,
									interes_diferido_actual
							from	tbl_hipotecario_ptmos with (nolock)
							where	numero = @numero
									and id_mov = @id_mov
									and planx = @plan
									and num_ptmo = @numPtmo

							union

							select	id = row_number() over (order by numero, num_ptmo, num_pago),
									contador,
									numero,
									id_mov,
									Id_esquema,
									Monto_inicial,
									Saldo_actual,
									int_ord,
									tasa_moratorios = 3e-2,
									aplica_iva = @aplicaIVA,
									cv_diaria = @cv_diaria,
									fecha_traspaso_cv = @fecha_traspaso_cv,
									plazo,
									planx,
									Fecha_pago,
									fecha_fin_original,
									capital,
									capital,
									interes,
									iva = 0,
									seguro_vida = 0,
									seguro_da�os = 0,
									total,
									fecha_pago_cajas = cast(fecha_dispersion as date), -----------
									numusuario,
									id_status,
									cast(fecha_alta as date),
									num_ptmo,
									num_pago,
									folio = null,
									fecha_ptmo,
									0 as interes_diferido_actual
							from	tbl_credinomina_ptmos with (nolock)
							where	numero = @numero
									and id_mov = @id_mov
									and planx = @plan
									and num_ptmo = @numPtmo

							union

							select	id = row_number() over (order by numero, num_ptmo, num_pago),
									contador,
									numero,
									id_mov,
									Id_esquema,
									Monto_inicial,
									Saldo_actual,
									int_ord,
									tasa_moratorios = 3e-2,
									aplica_iva = @aplicaIVA,
									cv_diaria = @cv_diaria,
									fecha_traspaso_cv = @fecha_traspaso_cv,
									plazo,
									planx,
									Fecha_pago,
									fecha_fin_original,
									capital,
									capital,
									interes,
									iva = 0,
									seguro_vida = 0,
									seguro_da�os = 0,
									total,
									cast(fecha_pago_cajas as date),
									numusuario,
									id_status,
									cast(fecha_alta as date),
									num_ptmo,
									num_pago,
									folio = null,
									fecha_ptmo,
									0 as interes_diferido_actual
							from	tbl_credinomina_ptmos_cajas with (nolock)
							where	numero = @numero
									and id_mov = @id_mov
									and planx = @plan
									and num_ptmo = @numPtmo

						end -- recuperar calendario fuera de tbl_nivelados_ptmos

						begin -- recuperar calendario en tbl_nivelados_ptmos

							insert	#CALENDARIO_OS
									(
									id,
									contador,
									numero,
									id_mov,
									id_esquema,
									monto_inicial,
									saldo_actual,
									tasa_ordinarios,
									tasa_moratorios,
									aplica_iva,
									cv_diaria,
									fecha_traspaso_cv,
									plazo,
									planx,
									fecha_fin,
									fecha_fin_original,
									capital_inicial,
									capital_actual,
									interes,
									iva,
									seguro_vida,
									seguro_da�os,
									total,
									fecha_pago_cajas,
									numusuario,
									id_status,
									fecha_alta,
									num_ptmo,
									num_corte,
									folio,
									fecha_ptmo,
									interes_diferido_actual
									)
							select	id = row_number() over (order by numero, num_ptmo, num_pago),
									contador,
									numero,
									id_mov,
									id_esquema,
									monto_inicial,
									saldo_actual,
									tasa_ordinarios = int_ord * 1e-2,
									tasa_moratorios = 3e-2,
									aplica_iva = @aplicaIVA,
									cv_diaria = @cv_diaria,
									fecha_traspaso_cv = @fecha_traspaso_cv,
									plazo,
									planx,
									fecha_pago,
									fecha_fin_original,
									capital,
									capital,
									interes,
									iva,
									seguro_vida,
									seguro_da�os = seguro_danos,
									total,
									cast(fecha_pago_cajas as date),
									numusuario,
									id_status,
									cast(fecha_alta as date),
									num_ptmo,
									num_pago,
									folio,
									cast(fecha_ptmo as date),
									interes_diferido_actual
							from	tbl_nivelados_ptmos with (nolock)
							where	numero = @numero
									and id_mov = @id_mov
									and planx = @plan
									and num_ptmo = @numPtmo

						end -- recuperar calendario en tbl_nivelados_ptmos

						begin -- reconstruir datos

							update	c1
							set		c1.fecha_inicio = c2.fecha_fin_original
							from	#CALENDARIO_OS c1
									join #CALENDARIO_OS c2
										on c2.id = c1.id - 1

							update	#CALENDARIO_OS
							set		fecha_inicio = fecha_ptmo
							where	id = 1

							update	#CALENDARIO_OS
							set		devengado = 1
							where	fecha_inicio < @today
									and id_status = 1

							update	#CALENDARIO_OS
							set		vencido = 1
							where	fecha_fin < @today
									and id_status = 1

							update	#CALENDARIO_OS
							set		dias_vencido = datediff(dd, fecha_fin, @today)
							where	vencido = 1

							update	#CALENDARIO_OS
							set		moratorios = round(capital_actual * tasa_moratorios / 3e1 * dias_vencido, 2),
									iva_moratorios = round(round(capital_actual * tasa_moratorios / 3e1 * dias_vencido, 2) * @tasaIVA, 2) * aplica_iva
							where	dias_vencido > 0

							update	#CALENDARIO_OS
							set		ordinarios_vencidos = interes + interes_diferido_actual,
									iva_ordinarios_vencidos = iva + ( interes_diferido_actual * case when @aplicaIVA = 1 then @tasaIVA else 0 end),
									capital_vencido = capital_actual
							where	dias_vencido > 0

							update	#CALENDARIO_OS
							set		ordinarios_corte = interes + interes_diferido_actual,
									iva_ordinarios_corte = iva + ( interes_diferido_actual * case when @aplicaIVA = 1 then @tasaIVA else 0 end),
									capital_corte = capital_actual
							where	devengado = 1
									and dias_vencido = 0

							update	#CALENDARIO_OS
							set		capital_no_devengado = capital_actual
							where	devengado = 0
									and id_status = 1

							select	@montoCapAmort = total
							from	#CALENDARIO_OS
							where	id in
										(
										select	min(id)
										from	#CALENDARIO_OS
										where	id_status = 1
										)

							-- se agrega el interes ordinario diferido no devengado para los ptmos nivelados
							select	@int_ord_diferido_no_dev = coalesce( sum(interes_diferido_actual), 0) 
							from	#CALENDARIO_OS 
							where	devengado = 0
							

							if @tipoConsulta = 1

								select	@intMor = sum(moratorios),
										@ivaMor = sum(iva_moratorios),
										@intOrdVen = sum(ordinarios_vencidos),
										@ivaOrdVen = sum(iva_ordinarios_vencidos),
										@ordinarios_corte = sum(ordinarios_corte),
										@iva_ordinarios_corte = sum(iva_ordinarios_corte),
										@capitalVencido = sum(capital_vencido),
										@capitalVigente = sum(capital_corte),
										@ordinarios_al_hoy = sum(ordinarios_al_hoy),
										@iva_ordinarios_al_hoy = sum(iva_ordinarios_al_hoy),
										@capitalNoDevengado = sum(capital_no_devengado)
								from	#CALENDARIO_OS

							else

								select	@intMor = moratorios,
										@ivaMor = iva_moratorios,
										@intOrdVen = ordinarios_vencidos,
										@ivaOrdVen = iva_ordinarios_vencidos,
										@ordinarios_corte = ordinarios_corte,
										@iva_ordinarios_corte = iva_ordinarios_corte,
										@capitalVencido = capital_vencido,
										@capitalVigente = capital_corte,
										@ordinarios_al_hoy = ordinarios_al_hoy,
										@iva_ordinarios_al_hoy = iva_ordinarios_al_hoy,
										@capitalNoDevengado = capital_no_devengado
								from	#CALENDARIO_OS
								where	id = 
											(
											select	min(id)
											from	#CALENDARIO_OS
											where	id_status = 1
											)

							select	@amortizacion_seguro_vida = max(seguro_vida),
									@amortizacion_seguro_da�os = max(seguro_da�os)
							from	#CALENDARIO_OS

							begin -- revisar saldado

								exec SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR_NIVELADOS
									@numero = @numero,
									@id_mov = @id_mov,
									@num_ptmo = @numPtmo,
									@monto_a_pagar = null,
									@seguro_vida = @amortizacion_seguro_vida,
									@seguro_da�os = @amortizacion_seguro_da�os,
									@fecha = @today

								select	@gastos_cobranza = gastos_cobranza,
										@iva_gastos_cobranza = iva_gastos_cobranza,
										@tasa_gastos_cobranza = tasa_gastos_cobranza
								from	#SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR

							end -- revisar saldado

							begin -- actualizar resultados

								insert	#datos
									(
									status,
									saldo_actual,
									interes_moratorio,
									interes_ord_vencido,
									interes_ordinario_vigente,
									capital_vencido,
									capital_corte,
									seguro_vida,
									seguro_danos,
									saldo_adelanto,
									pago_al_corriente,
									capital_no_devengado_fin,
									capitalAmort,
									ivaIntMoratorio,
									ivaIntOrdinarioVencido,
									ivaIntOrdinarioVigente,
									int_moratorio_quitas,
									int_moratorio_quitas_iva,
									int_ordinario_quitas,
									int_ordinario_quitas_iva,
									reserva_capital,
									reserva_interes,
									gastos_cobranza,
									iva_gastos_cobranza,
									tasa_gastos_cobranza,
									primer_corte_vigente,
									int_ord_diferido_no_dev
									)
							select	
									status = 1,
									saldo_actual = @saldo_actual,
									interes_moratorio = @intMor,
									interes_ord_vencido = @intOrdVen,
									interes_ordinario_vigente = @ordinarios_corte + @ordinarios_al_hoy,
									capital_vencido = @capitalVencido,
									capital_corte = @capitalVigente,
									seguro_vida = @amortizacion_seguro_vida,
									seguro_danos = @amortizacion_seguro_da�os,
									saldo_adelanto = @saldo_adelanto,
									pago_al_corriente = @intMor + @ivaMor + @intOrdVen + @ivaOrdVen + @ordinarios_corte + @iva_ordinarios_corte + @ordinarios_al_hoy + @iva_ordinarios_al_hoy + @capitalVencido + @capitalVigente + @amortizacion_seguro_vida + @amortizacion_seguro_da�os,
									capital_no_devengado_fin = @capitalNoDevengado,
									capitalAmort = case when @tipoConsulta = 0 then @capitalVigente else @ordinarios_corte + @iva_ordinarios_corte + @capitalVigente end,
									ivaIntMoratorio = @ivaMor,
									ivaIntOrdinarioVencido = @ivaOrdVen,
									ivaIntOrdinarioVigente = @iva_ordinarios_corte + @iva_ordinarios_al_hoy,
									int_moratorio_quitas = @int_mor_quita,
									int_moratorio_quitas_iva = @iva_int_mor_quita,
									int_ordinario_quitas = @int_ord_quita,
									int_ordinario_quitas_iva = @iva_int_ord_quita,
									reserva_capital = @reserva_capital,
									reserva_interes = @reserva_interes,
									gastos_cobranza = @gastos_cobranza,
									iva_gastos_cobranza = @iva_gastos_cobranza,
									tasa_gastos_cobranza = @tasa_gastos_cobranza,
									primer_corte_vigente = 0, --null
									int_ord_diferido_no_dev = @int_ord_diferido_no_dev

									if @tipoConsulta = 1

										update	#datos
										set		capital_corte += capital_no_devengado_fin,
												capital_no_devengado_fin = 0

							end -- actualizar resultados

						end -- reconstruir datos

					end -- nuevo bloque para resolver nivelados

					UPDATE	#datos
					SET		interes_moratorio = 0,
							ivaIntMoratorio = 0
					WHERE	interes_moratorio < 0
			
					-- para periodos de gracia
					if CAST(@today as date)<=cast(@fin_periodo_gracia as date)
					begin
					                update #datos set 
									saldo_actual = @saldo_actual,
									interes_moratorio = 0,
									interes_ord_vencido = 0,
									interes_ordinario_vigente = 0,
									capital_vencido = 0,
									capital_corte = case when @tipoConsulta = 1 then @saldo_actual else 0 end,
									seguro_vida = 0,
									seguro_danos = 0,
									saldo_adelanto = @saldo_adelanto,
									pago_al_corriente = 0 ,
									capital_no_devengado_fin = case when @tipoConsulta = 1 then 0 else @saldo_actual end,
									capitalAmort = 0,
									ivaIntMoratorio = 0,
									ivaIntOrdinarioVencido = 0,
									ivaIntOrdinarioVigente = 0,
									int_moratorio_quitas = 0,
									int_moratorio_quitas_iva = 0,
									int_ordinario_quitas = 0,
									int_ordinario_quitas_iva = 0,
									reserva_capital = 0,
									reserva_interes = 0,
									gastos_cobranza = 0,
									iva_gastos_cobranza = 0,
									tasa_gastos_cobranza = 0,
									primer_corte_vigente = 0--null
					end
						
					

					if not exists(select * from #datos)

						begin -- o esta al corriente o no tiene un calendario de pagos

							if exists(select * from TBL_HIPOTECARIO_PTMOS with (nolock) where Numero=@numero and Id_status=1) OR
								exists(select * from TBL_NIVELADOS_PTMOS with (nolock) where Numero=@numero and Id_status=1) OR
								exists(select * from TBL_AUTOMOTRIZ_PTMOS with (nolock) where Numero=@numero and Id_status=1) OR
								exists(select * from TBL_CREDINOMINA_PTMOS_CAJAS with (nolock) where Numero=@numero and Id_status=1) OR
								exists(select * from TBL_CREDINOMINA_PTMOS with (nolock) where Numero=@numero and Id_status=1)

								begin -- esta al corriente
						
									insert	#datos
											(
											status,
											saldo_actual,
											interes_moratorio,
											interes_ord_vencido,
											interes_ordinario_vigente,
											capital_vencido,
											capital_corte,
											seguro_vida,
											seguro_danos,
											saldo_adelanto,
											pago_al_corriente,
											capital_no_devengado_fin,
											capitalAmort,
											ivaIntMoratorio,
											ivaIntOrdinarioVencido,
											ivaIntOrdinarioVigente,
											int_moratorio_quitas,
											int_moratorio_quitas_iva,
											int_ordinario_quitas,
											int_ordinario_quitas_iva,
											reserva_capital,
											reserva_interes,
											primer_corte_vigente,
											int_ord_diferido_no_dev
											)

									SELECT 1,@saldo_actual,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,@int_ord_diferido_no_dev

									select * from #datos

								end -- esta al corriente

								else

									raiserror('No se encontro calendario de pagos', 11, 0)

						end -- o esta al corriente o no tiene un calendario de pagos

					else

						begin -- tiene pago pendiente

							update	#datos
							set		seguro_danos = 0,
									seguro_vida = 0,
									pago_al_corriente = 0
							where	capital_corte + capital_vencido = 0

							declare	@_seguro_vida		money = null,
									@_seguro_da�os		money = null,
									@_int_mor			money = null,
									@_iva_int_mor		money = null,
									@_int_ord_ven		money = null,
									@_iva_int_ord_ven	money = null,
									@_int_ord_vig		money = null,
									@_iva_int_ord_vig	money = null,
									@_cap_ven			money = null,
									@_cap_vig			money = null,
									@_cap_no_dev		money = null

							select	@_seguro_vida = seguro_vida,
									@_seguro_da�os = seguro_danos,
									@_int_mor = interes_moratorio,
									@_iva_int_mor = ivaIntMoratorio,
									@_int_ord_ven = interes_ord_vencido,
									@_iva_int_ord_ven = ivaIntOrdinarioVencido,
									@_int_ord_vig = interes_ordinario_vigente,
									@_iva_int_ord_vig = ivaIntOrdinarioVigente,
									@_cap_ven = capital_vencido,
									@_cap_vig = capital_corte,
									@_cap_no_dev = capital_no_devengado_fin
							from	#datos

							select	@monto_a_pagar_amortizacion =
										+ @_seguro_vida
										+ @_seguro_da�os
										+ @_int_mor
										+ @_iva_int_mor
										+ @_int_ord_ven
										+ @_iva_int_ord_ven
										+ @_int_ord_vig
										+ @_iva_int_ord_vig
										+ @_cap_ven
										+ @_cap_vig
										+ ceiling((@_int_mor + @_int_ord_ven + @_cap_ven) * @tasa_gastos_cobranza * (1 + @tasaIVA) * 1e2) / 1e2 + 1

							exec sp_cred_obtiene_desglose_monto_a_pagar_nivelados

								@numero = @numero,
								@id_mov = @id_mov,
								@num_ptmo = @numPtmo,
								@monto_a_pagar = @monto_a_pagar_amortizacion,
								@seguro_vida = @_seguro_vida,
								@seguro_da�os = @_seguro_da�os,
								@fecha = @today

							update	da
							set		gastos_cobranza = d.gastos_cobranza,
									iva_gastos_cobranza = d.iva_gastos_cobranza,
									tasa_gastos_cobranza = d.tasa_gastos_cobranza,
									pago_al_corriente += (d.gastos_cobranza + d.iva_gastos_cobranza)
							from	#datos da
									cross join #SP_CRED_OBTIENE_DESGLOSE_MONTO_A_PAGAR d

							select * from #datos

						end -- tiene pago pendiente
					
				end -- nivelados

			end -- try principal

		end try

		begin catch

				select	0 status, 
						error_message() error_desc

		end catch -- end try
		
	end -- procedimiento
