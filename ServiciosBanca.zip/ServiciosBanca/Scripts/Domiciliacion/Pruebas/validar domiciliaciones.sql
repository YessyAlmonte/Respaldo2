DECLARE 
@NUMERO INT=601805,
@fecha date='20200729'

EXEC SP_BANCA_OBTENER_PAGOS_DOMICILIADOS '20200729'

SELECT numero_socio,* FROM TBL_BANCA_DOMICILIACIONES WHERE BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio)=@NUMERO


SELECT * FROM TBL_BANCA_DOMICILIACIONES where id_domiciliacion=7

--update TBL_BANCA_DOMICILIACIONES set fecha_ultimo_pago=null WHERE BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio)=720209

select * from TBL_BANCA_PAGOS_DOMICILIADOS where id_domiciliacion=1


SELECT * FROM TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS WHERE  BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio)=@NUMERO AND CAST(fecha_alta_pago AS date)>=CAST(@fecha as date)
select * from HAPE..MOVIMIENTOS where Activo='T' and Numero=@NUMERO AND CAST(Fecha_Mov AS date)>=CAST(@fecha as date)
select * from HAPE..CAPTURA where Activo='T' and Numero=@NUMERO AND CAST(Fecha_Mov AS date)>=CAST(@fecha as date)
select * from HAPE..CAPTURA_lacp where Activo='T' and Numero=@NUMERO AND CAST(Fecha_Mov AS date)>=CAST(@fecha as date)

select Ultimo_Abono,* from HAPE..EDO_DE_CUENTA where numero=@NUMERO and id_tipo_persona=1 and id_mov<10 and Saldo_Actual>0

--exec SP_BANCA_OBTENER_CUENTAS @NUMERO=N'601805',@tipo_cuenta=0

--ordinario
exec SP_BANCA_OBTENER_DETALLE_PRESTAMO @numeroSocio=N'601805',@ClabeCorresponsalias=N'7970020010601805',@tipoOrigen=3
EXEC HAPE..SP_INTERES_DIARIO_OBTIENE_SALDOS 601805,9,'20200816'

--automotriz
exec SP_BANCA_OBTENER_DETALLE_PRESTAMO @numeroSocio=N'601805',@ClabeCorresponsalias=N'7970020090601805',@tipoOrigen=3
EXEC HAPE..SP_INTERES_DIARIO_OBTIENE_SALDOS 601805,9,'20200816'

--select e.Numero from tbl_banca_socios s
--join hape..edo_de_cuenta e on BANCA.dbo.FN_BANCA_DESCIFRAR(s.numero_socio)=e.numero and e.id_mov<10 and e.saldo_actual>0
--group by e.Numero
--having COUNT(1)>2

