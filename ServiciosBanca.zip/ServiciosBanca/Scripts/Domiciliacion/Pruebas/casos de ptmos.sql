--decrecientes

--exec SP_BANCA_OBTENER_DETALLE_PRESTAMO @numeroSocio=N'601805',@ClabeCorresponsalias=N'7970020010601805',@tipoOrigen=3

---cuando el monto fijo excede el pago del dia de hoy
exec BANCA.DBO.SP_BANCA_PAGAR_PRESTAMO @clabeCorresponsaliasRetiro =N'7970011030601805',@clabeCorresponsaliasDeposito =N'7970020010601805',@Monto =2000.00,@TipoAnticipo =3,@TipoOrigen =3,@programada=0,@horaProgramada='2020-08-05 00:00:00'

--cuando el monto fijo es menor al pago requerido
exec SP_BANCA_PAGAR_PRESTAMO @clabeCorresponsaliasRetiro =N'7970011030601805',@clabeCorresponsaliasDeposito =N'7970020010601805',@Monto =1000.00,@TipoAnticipo =1,@TipoOrigen =3,@programada=0,@horaProgramada='2020-08-05 00:00:00'

--cuando se paga el monto requerido
exec SP_BANCA_PAGAR_PRESTAMO @clabeCorresponsaliasRetiro =N'7970011030601805',@clabeCorresponsaliasDeposito =N'7970020010601805',@Monto =1531.19,@TipoAnticipo =1,@TipoOrigen =3,@programada=0,@horaProgramada='2020-08-05 00:00:00'

--se liquida el ptmo pagoParaLiquidar
exec SP_BANCA_PAGAR_PRESTAMO @clabeCorresponsaliasRetiro =N'7970011030601805',@clabeCorresponsaliasDeposito =N'7970020010601805',@Monto =40420.07,@TipoAnticipo =1,@TipoOrigen =3,@programada=0,@horaProgramada='2020-08-05 00:00:00'

--Nivelados corriente no se puede pagar menos que el monto requerido

--exec SP_BANCA_OBTENER_DETALLE_PRESTAMO @numeroSocio=N'601805',@ClabeCorresponsalias=N'7970020050601805',@tipoOrigen=3

--cuando se paga el monto requerido
exec SP_BANCA_PAGAR_PRESTAMO @clabeCorresponsaliasRetiro =N'7970011030601805',@clabeCorresponsaliasDeposito =N'7970020050601805',@Monto =1806.98,@TipoAnticipo =1,@TipoOrigen =3,@programada=0,@horaProgramada='2020-08-05 00:00:00'

--cuando se aplica un anticipo con reduccion de plazo
exec SP_BANCA_PAGAR_PRESTAMO @clabeCorresponsaliasRetiro =N'7970011030601805',@clabeCorresponsaliasDeposito =N'7970020050601805',@Monto =2500.00,@TipoAnticipo =2,@TipoOrigen =3,@programada=0,@horaProgramada='2020-08-05 00:00:00'

--se liquida el ptmo pagoParaLiquidar
exec SP_BANCA_PAGAR_PRESTAMO @clabeCorresponsaliasRetiro =N'7970011030601805',@clabeCorresponsaliasDeposito =N'7970020050601805',@Monto =70391.35,@TipoAnticipo =1,@TipoOrigen =3,@programada=0,@horaProgramada='2020-08-05 00:00:00'

--******************Decreciente vencido

--Pago al dia de hoy intereses + capital vencido + capital vigente 1218.83

--exec SP_BANCA_OBTENER_DETALLE_PRESTAMO @numeroSocio=N'099300',@ClabeCorresponsalias=N'7970020010099300',@tipoOrigen=3

--Pago minimo (intereses + iva + capital vencido) () 802.16
--EXEC HAPE..SP_INTERES_DIARIO_OBTIENE_SALDOS 99300, 1

--pago menor al minimo

--exec SP_BANCA_PAGAR_PRESTAMO @clabeCorresponsaliasRetiro =N'7970011000099300',@clabeCorresponsaliasDeposito =N'7970020010099300',@Monto =800.00,@TipoAnticipo =1,@TipoOrigen =3,@programada=0,@horaProgramada='2020-08-05 00:00:00'


--****Nivelados vencidos

--amortizacion vencidad mas amortizacion vigente +  moratorios 9,132.98
exec SP_BANCA_OBTENER_DETALLE_PRESTAMO @numeroSocio=N'523780',@ClabeCorresponsalias=N'7970020090523780',@tipoOrigen=3


--amortizacion vencida mas intereses moratorios 4568.92 --pago_al_corriente
EXEC HAPE..SP_INTERES_DIARIO_OBTIENE_SALDOS 523780, 9

--exec hape.dbo.SP_INTERES_DIARIO_OBTIENE_SALDOS_BANCA_NIVELADOS 523780, 9, @fecha

select * from HAPE..TBL_AUTOMOTRIZ_PTMOS where Numero=523780 and Id_status=1
--update HAPE..EDO_DE_CUENTA set Saldo_Actual=100000 where Numero=601805 and Id_mov=103