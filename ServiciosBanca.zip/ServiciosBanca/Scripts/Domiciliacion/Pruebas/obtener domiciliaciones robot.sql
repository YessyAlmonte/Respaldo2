USE[BANCA]

declare @fecha date=getdate()


---por dia especifico de pago indefinidos 
select d.* 
from TBL_BANCA_DOMICILIACIONES  d
where activo=1 and (por_dia_especifico_de_pago=1 or por_dia_pago=1) and DAY(@fecha)=dia_pago and 
indefinido=1

union

---por dia especifico de pago con fecha de vencimiento
select d.* 
from TBL_BANCA_DOMICILIACIONES d
where activo=1 and (por_dia_especifico_de_pago=1 or por_dia_pago=1) and DAY(@fecha)=dia_pago and 
 con_vigencia=1 and cast(@fecha as date)<=cast(fecha_vencimiento as date)

 union

--servicios por periodicidad
select d.* 
from TBL_BANCA_DOMICILIACIONES  d
where activo=1 and por_periodicidad=1 and
CAST(@fecha AS date)=case when id_periodicidad_pago=1 then  CAST(DATEADD(DAY,1,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
						  when id_periodicidad_pago=2 then  CAST(DATEADD(DAY,15,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
						  when id_periodicidad_pago=3 then  CAST(DATEADD(month,1,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
						  when id_periodicidad_pago=4 then  CAST(DATEADD(month,2,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
						  when id_periodicidad_pago=5 then  CAST(DATEADD(month,3,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
						  when id_periodicidad_pago=6 then  CAST(DATEADD(month,6,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
						  when id_periodicidad_pago=7 then  CAST(DATEADD(year,1,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
                     end
and id_tipo_domiciliacion=3

union

---prestamos revolvente por fecha limite de pago
select d.*
from TBL_BANCA_DOMICILIACIONES d 
join hape..TBL_REVOLVENTE_LINEAS_CREDITO l on d.num_ptmo=l.num_ptmo
where activo=1 and id_tipo_domiciliacion=1 and por_dia_limite_de_pago=1
and l.saldo_actual>0 and cast(HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(d.num_ptmo,d.id_mov,l.Numero,4,1) as date)=CAST(@fecha AS date) 

union

---prestamos por dia fecha de pago
select d.*
from TBL_BANCA_DOMICILIACIONES d
join hape..EDO_DE_CUENTA edo on edo.Numero=banca.dbo.FN_BANCA_DESCIFRAR(d.numero_socio) and d.num_ptmo=edo.num_ptmo
where d.activo=1 and id_tipo_domiciliacion=1 and por_dia_limite_de_pago=1
and edo.saldo_actual>0.01  and cast(HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(d.num_ptmo,edo.id_mov,edo.Numero,edo.Id_Esquema,1) as date)=CAST(@fecha AS date)       


---obtenemos los pagos que quedaron pendientes
--select * from TBL_BANCA_PAGOS_DOMICILIADOS where id_estatus_pago_banca=1



