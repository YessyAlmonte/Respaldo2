USE[BANCA]
go

-- se crea cat�logo TBL_BANCA_DOMICILIACIONES
if exists (select * from sysobjects where name like 'TBL_BANCA_DOMICILIACIONES' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_DOMICILIACIONES

create table
	TBL_BANCA_DOMICILIACIONES
		(
		id_domiciliacion bigint identity(1,1) constraint PK_TBL_BANCA_DOMICILIACIONES primary key clustered not null, -- llave primaria
		numero_socio VARBINARY(MAX),
		id_tipo_domiciliacion int,
		alias	varchar(500),
		clabe_corresponsalias_retiro varchar(20),
		clabe_corresponsalias_deposito	varchar(20),
		id_producto	int,
		id_servicio	int,		
		num_ptmo	varchar(20),
		id_mov	int,
		indefinido	bit,		
		con_vigencia	bit,
		fecha_vencimiento datetime,
		por_monto_requerido	bit,
		por_monto_fijo	bit,
		monto	decimal(18,2),
		por_dia_limite_de_pago	bit,
		por_dia_especifico_de_pago	bit,
		dia_pago	int,
		por_periodicidad bit,
		id_periodicidad_pago int,
		numero_referencia	varchar(150),
		telefono	varchar(20),
		activo	bit,
		folio_autorizacion	bigint,
		folio_cancelacion	bigint,				
		fecha_alta	datetime,
		fecha_ultimo_pago datetime			
		--por_dia_pago	bit,	
		--monto_maximo decimal(18,2),		
		)

grant select, insert, update, delete on TBL_BANCA_DOMICILIACIONES to public

use BANCA
go

-- se crea cat�logo CAT_BANCA_ESTATUS_PAGO_DOMICILIACION
if exists (select * from sysobjects where name like 'CAT_BANCA_ESTATUS_PAGO_DOMICILIACION' and xtype = 'u' and db_name() = 'BANCA')
	drop table CAT_BANCA_ESTATUS_PAGO_DOMICILIACION

create table
	CAT_BANCA_ESTATUS_PAGO_DOMICILIACION
		(
		id	int constraint PK_TBL_BANCA_ESTATUS_PAGO_DOMICILIACION primary key clustered not null, -- llave primaria
		estatus_pago_domiciliacion varchar(250)
		)

grant select, insert, update, delete on CAT_BANCA_ESTATUS_PAGO_DOMICILIACION to public

go

use BANCA
go

-- se crea cat�logo TBL_BANCA_HISTORIAL_PAGOS_DOMICILIADOS
if exists (select * from sysobjects where name like 'TBL_BANCA_HISTORIAL_PAGOS_DOMICILIADOS' and xtype = 'u' and db_name() = 'BANCA')
	drop table TBL_BANCA_HISTORIAL_PAGOS_DOMICILIADOS

create table
	TBL_BANCA_HISTORIAL_PAGOS_DOMICILIADOS
		(
		id_historial_pago_domiciliado	bigint identity(1,1) constraint PK_TBL_BANCA_HISTORIAL_PAGOS_DOMICILIADOS primary key clustered not null, -- llave primaria
		id_pago_domiciliado	bigint,
		id_banca_folio	bigint,
		fecha_alta	datetime,
		numero_autorizacion_servicio	varchar(50),
		clabe_corresponsalias_retiro	varchar(20),
		clabe_corresponsalias_deposito	varchar(20),
		id_producto	int,
		id_servicio	int,
		numero_referencia varchar(150),
		monto money,
		monto_pagado money,
		id_estatus_gesto_pago varchar(100),
		id_estatus_pago_banca int,
		decripcion_mensaje_pago	varchar(1000),	
		id_tipo_domiciliacion int,
		id_domiciliacion bigint,
		telefono	varchar(20)
		)

grant select, insert, update, delete on TBL_BANCA_HISTORIAL_PAGOS_DOMICILIADOS to public

go

if not exists (select * from information_schema.columns where table_name like 'TBL_BANCA_TRANSFERENCIAS_INTERNAS' and column_name like 'id_domiciliacion')
   alter table TBL_BANCA_TRANSFERENCIAS_INTERNAS add id_domiciliacion int null

if not exists (select * from information_schema.columns where table_name like 'TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS' and column_name like 'id_domiciliacion')
   alter table TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS add id_domiciliacion int null

if not exists (select * from information_schema.columns where table_name like 'TBL_BANCA_PAGOS_DOMICILIADOS' and column_name like 'fecha_aplicacion')
	alter table TBL_BANCA_PAGOS_DOMICILIADOS add fecha_aplicacion datetime null

if not exists (select * from information_schema.columns where table_name like 'TBL_BANCA_PAGOS_DOMICILIADOS' and column_name like 'id_tipo_domiciliacion')
	alter table TBL_BANCA_PAGOS_DOMICILIADOS add id_tipo_domiciliacion int null


ALTER TABLE TBL_BANCA_PAGOS_DOMICILIADOS DROP COLUMN id_domiciliacion

if not exists (select * from information_schema.columns where table_name like 'TBL_BANCA_PAGOS_DOMICILIADOS' and column_name like 'id_domiciliacion')
	alter table TBL_BANCA_PAGOS_DOMICILIADOS add id_domiciliacion bigint null

if not exists (select * from information_schema.columns where table_name like 'TBL_BANCA_PAGOS_DOMICILIADOS' and column_name like 'telefono')
	alter table TBL_BANCA_PAGOS_DOMICILIADOS add telefono varchar(20) null

if not exists (select * from information_schema.columns where table_name like 'TBL_BANCA_PAGOS_DOMICILIADOS' and column_name like 'monto_pagado')
	alter table TBL_BANCA_PAGOS_DOMICILIADOS add monto_pagado money null

go


INSERT INTO CAT_BANCA_ESTATUS_PAGO_DOMICILIACION(id,estatus_pago_domiciliacion)
values(1,'Pendiente'),(2,'Aplicado'),(3,'No Aplicado'),(4,'Cancelado'),(5,'Error')


if not exists(select 1 from CAT_BANCA_ORIGEN_OPERACION where descripcion like 'Robot Domiciliacion')
INSERT INTO CAT_BANCA_ORIGEN_OPERACION(descripcion,activo)
VALUES('Robot Domiciliacion',1)

if not exists(select 1 from [dbo].[CAT_BANCA_EXCEPTIONS] where descripcion like 'El pr�stamo se encuentra vencido')
INSERT INTO [CAT_BANCA_EXCEPTIONS]
VALUES(420,'El pr�stamo se encuentra vencido')