use[hape]


IF NOT EXISTS(SELECT 1 FROM hape.dbo.CAT_CMV_PROCESOS_CRITICOS where proceso like 'ROBOT DOMICILIACION')
INSERT INTO hape.dbo.CAT_CMV_PROCESOS_CRITICOS(proceso,tipo_proceso,proceso_haberes,proceso_credito)
values('ROBOT DOMICILIACION','ROBOT',1,1)

declare @idProceso int,
@id_proceso_requerido int=10 --ROBOT DE PAGOS PROGRAMADOS

select @idProceso=id_Proceso FROM hape.dbo.CAT_CMV_PROCESOS_CRITICOS where proceso like 'ROBOT DOMICILIACION'

IF NOT EXISTS(select 1 from HAPE.DBO.TBL_CMV_DEPENDENCIAS_PROCESOS_CRITICOS where id_proceso=@idProceso and id_proceso_requerido=@id_proceso_requerido)
INSERT INTO HAPE.DBO.TBL_CMV_DEPENDENCIAS_PROCESOS_CRITICOS(id_proceso,id_proceso_requerido)
VALUES(@idProceso,@id_proceso_requerido)

select * from CAT_CMV_PROCESOS_CRITICOS where id_proceso=@idProceso
			select	pca.proceso,p.*,
								proceso_requerido = pc.proceso
						
						from	TBL_CMV_DEPENDENCIAS_PROCESOS_CRITICOS p								
								join CAT_CMV_PROCESOS_CRITICOS pc
									on pc.id_proceso = p.id_proceso_requerido
								join CAT_CMV_PROCESOS_CRITICOS pca
									on pca.id_proceso = p.id_proceso
						where	p.id_proceso = @idProceso
