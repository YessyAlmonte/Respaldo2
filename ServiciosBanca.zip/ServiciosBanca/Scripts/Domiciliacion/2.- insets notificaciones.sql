use BANCA
go

----------------------PAGO DOMICILIACION----------------------

begin

	DELETE from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 25
	DELETE from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 25

--SMS
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 25)
begin
	insert into TBL_BANCA_NOTIFICACIONES_SMS(id_tipo_bitacora, cuerpo, fecha_alta,activo)
	values
	(
		25,
		'CMV Finanzas, Retiro por pago de servicio domiciliado de @descServicio por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 8003000268 opc 5',	
		GETDATE(),
		1
	)
end

	--MAIL
	if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 25)
	begin
		insert into TBL_BANCA_NOTIFICACIONES_CORREO(id_tipo_bitacora, cuerpo, asunto, url_img_operacion, fecha_alta,activo)
		values
		(
			25,		
			'<html>
												<head>
													<style>

													.md-100{
														width: 100%;
														margin: auto;
													}

													.md-80{
														width: 80%;
														margin: auto;
													}

													.md-70{
														width: 70%;
														margin: auto;
													}

													.md-20{
														width: 20%;
														margin: auto;
													}


													/*------------------------------------*/
													#content-principal{
														width:800px; 
														margin: auto;
													}
													/*------------------------------------*/
													#content-header{
														border-bottom: 20px solid #89BA27;
													}

													#content-header img{
														margin: 0;
													}

													/*------------------------------------*/
													#content-nombre{
														margin-top: 10px; 
														font-size: 25px; 
														color:#89BA27;
													}
													/*------------------------------------*/
													#content-operacion{
														margin-top: 10px; 
														text-align: center;
													}

													#content-operacion p{
														color:#595959;
														font-size: 25px;
														padding: 0;
														margin: 5px;
														display: inline-table;
    													width: 100%;
													}

													#operacion{
														font-weight:900 !important;
													}

													#operacion span{
														height: 25px;
														display: inline-block; 
													}

													#operacion img{
														height: 100%;
													}

													#operacion-icono {
														margin-top: 15px;
														margin-bottom: 10px;
														text-align: center;
													}

													/*------------------------------------*/
													#content-transferencia{
														margin-top: 10px; 
														font-size: 20px; 
														color:#595959;
														text-align: center;
													}

													/*------------------------------------*/
													#content-detalle{
														margin: auto;
														margin-top: 30px;
														background-color: #e4e4e4; 	
														text-align:center;
														padding: 5px;
													}
													#content-detalle p{
														font-size: 23px;
														color:#595959;
														margin: 10px;
													}
													/*------------------------------------*/
													#content-aclaracion{
														margin-top: 20px;
														text-align: center;
														font-size: 25px; 
														color:#595959;
													}
													/*------------------------------------*/
													#footer{
														background-color:#e4e4e4;
													}

													#footer-content-tips{
														display: inline-flex;
													}

													#tips-content-img{
														text-align: center;
													}

													#tips-content-tips{
														font-size: 30px; 
														color:#595959;
													}

													#tips-content-tips ul{
														font-size: 20px;
													}

													@media only screen and (max-width: 600px) {

														p, span, li{
	  														font-size: 15px !important;
	  													}

														#content-header,
														#content-nombre,
														#content-operacion,
														#content-detalle,
														#content-aclaracion,
														#footer{
															width: 90%;
															margin: auto;
														}

	  													/*------------------------------------*/
	  													#content-principal{
															width:100%; 
															margin: auto;
														}

														/*------------------------------------*/
														#content-header{
															border-bottom: 10px solid #89BA27;			
														}

														/*------------------------------------*/
														#operacion{
															font-size: 15px;	
															font-weight:900 !important;
														}

														#operacion span{
															height: 15px;
														}

														#operacion-icono img{
															width: 40px;
															height: 50px;
														}

														/*------------------------------------*/
														#content-transferencia p:last-child{
															border-bottom: 2px solid #89BA27 !important;
														}
														/*------------------------------------*/
														#footer-content-tips{
															display: block;
															padding: 10px 10px 0px 0px;
														}

														#tips-content-img,
														#tips-content-tips{
															width: 95%;
															text-align: center;
														}

														#tips-content-img img{
															width: 40px;
															height: 50px;
														}

													}
												</style>
													<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
												</head>
												<body>
													<div id="content-principal">

														<div id="content-header" class="md-100">
															<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
														</div>

														<div id="content-nombre" class="md-100">
															<p style="font-weight:900; ">@Nombre</p>
														</div>

														<div id="content-operacion" class="md-100">
															<p>La operaci�n de</p>
															<p id="operacion">
																<span>
																	<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																	&nbsp;@operacion&nbsp;
																	<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
																</span>
															</p>
															<p>se realiz� exitosamente</p>
														</div>
													
														<div id="content-detalle" class="md-70">
															<p>
																<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
																<span>@fecha_hora_operacion</span>
															</p>
															<p>
																<span><b style="color: rgba(0,0,0,.7)">Folio </b></span>
																<span>@folio</span>
															</p>
														</div>

														<!-- INICIO  SI ES UNA TRANSFERENCIA -->
														<div id="content-transferencia">
															<p>
																<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
																<span style="font-weight:500; ">@CuentaRetiro</span>
															</p>
														
														</div>
														<!-- FIN  SI ES UNA TRANSFERENCIA -->

														<div id="content-aclaracion" class="md-100">
															<p>
																<span style="font-weight:900; ">Si t� no realizaste esta operaci�n</span> 
																<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
																<span style="font-weight:900; ">800 3000 268 opci�n "5"</span>
																<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
															</p>
														</div>

														<!-- FOOTER -->
														<div id="footer" class="md-100">
															<div id="footer-content-tips" class="md-100">
																<div id="tips-content-img" class="md-20">
	        														<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        													</div>
																<div id="tips-content-tips" class="md-80">
		        													<p style="font-weight:900;">Tips de Seguridad:</p> 
																	<ul>
																		<li>Caja Morelia Valladolid nunca te pedir� informaci�n adicional de tus cuentas</li>
																		<li>No Compartas tu contrase�a de acceso y c�mbiala peri�dicamente</li>
																	</ul>
																</div>
															</div>
	        
															<div class="md-100">
																<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																	<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
																</a>
															</div>

														</div>
													</div>
												</body>
												</html>',
			'Pago de servicio domiciliado',
			'',
			GETDATE(),
			1
		)
	end

end

----------------------ALTA DOMICILIACION----------------------

begin
DELETE TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 28
DELETE TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 28

--SMS
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 28)
begin
	insert into TBL_BANCA_NOTIFICACIONES_SMS(id_tipo_bitacora, cuerpo, fecha_alta,activo)
	values
	(
		28,
		'CMV Finanzas, Alta de domiciliaci�n de @alias, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 8003000268 opc 5',	
		GETDATE(),
		1
	)
end

--MAIL
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 28)
begin
	insert into TBL_BANCA_NOTIFICACIONES_CORREO(id_tipo_bitacora, cuerpo, asunto, url_img_operacion, fecha_alta,activo)
	values
	(
		28,
		'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p>La operaci�n de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
														<p>se realiz� exitosamente</p>
													</div>
		
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
															<span>@folio</span>
														</p>
													</div>

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si t� no realizaste esta operaci�n</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">800 3000 268 opci�n "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedir� informaci�n adicional de tus cuentas</li>
																	<li>No Compartas tu contrase�a de acceso y c�mbiala peri�dicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>',
		'Ata de domiciliaci�n',
		'',
		GETDATE(),
		1
	)
end

end

----------------------CANCELAR DOMICILIACION----------------------
DELETE from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 29
DELETE from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 29
--SMS
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 29)
begin
	insert into TBL_BANCA_NOTIFICACIONES_SMS(id_tipo_bitacora, cuerpo, fecha_alta,activo)
	values
	(
		29,
		'CMV Finanzas,Domiciliaci�n cancelada de @alias, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 8003000268 opc 5',	
		GETDATE(),
		1
	)
end

--MAIL
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 29)
begin
	insert into TBL_BANCA_NOTIFICACIONES_CORREO(id_tipo_bitacora, cuerpo, asunto, url_img_operacion, fecha_alta,activo)
	values
	(
		29,
		'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p>La operaci�n de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
														<p>se realiz� exitosamente</p>
													</div>
		
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
															<span>@folio</span>
														</p>
													</div>

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si t� no realizaste esta operaci�n</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">800 3000 268 opci�n "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedir� informaci�n adicional de tus cuentas</li>
																	<li>No Compartas tu contrase�a de acceso y c�mbiala peri�dicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>',
		'Domiciliaci�n Cancelada',
		'',
		GETDATE(),
		1
	)
end

----------------------ACTUALIZAR DOMICILIACION----------------------

delete from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 100
delete from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 100

--SMS
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 100)
begin
	insert into TBL_BANCA_NOTIFICACIONES_SMS(id_tipo_bitacora, cuerpo, fecha_alta,activo)
	values
	(
		100,
		'CMV Finanzas, Actualizacion de domiciliaci�n de @alias, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 8003000268 opc 5',	
		GETDATE(),
		1
	)
end


--MAIL
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 100)
begin
	insert into TBL_BANCA_NOTIFICACIONES_CORREO(id_tipo_bitacora, cuerpo, asunto, url_img_operacion, fecha_alta,activo)
	values
	(
		100,
		'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p>La operaci�n de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
														<p>se realiz� exitosamente</p>
													</div>
		
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
															<span>@folio</span>
														</p>
													</div>

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si t� no realizaste esta operaci�n</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">800 3000 268 opci�n "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedir� informaci�n adicional de tus cuentas</li>
																	<li>No Compartas tu contrase�a de acceso y c�mbiala peri�dicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>',
		'Actualizacion de domiciliaci�n',
		'',
		GETDATE(),
		1
	)
end


----------------------PAGO DOMICILIACION SERVICIO RECHAZADO----------------------

delete TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 101
delete from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 101

--SMS
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 101)
begin
	insert into TBL_BANCA_NOTIFICACIONES_SMS(id_tipo_bitacora, cuerpo, fecha_alta,activo)
	values
	(
		101,
		'CMV Finanzas, Pago domiciliado @descServicio rechazado: @leyenda ,@fecha_hora_operacion, Folio: @folio, Atenci�n a socios 8003000268 opc 5',	

		GETDATE(),
		1
	)
end

--MAIL
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 101)
begin
	insert into TBL_BANCA_NOTIFICACIONES_CORREO(id_tipo_bitacora, cuerpo, asunto, url_img_operacion, fecha_alta,activo)
	values
	(
		101,		
		'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p style="display:none">La operaci�n de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;Pago de servicio domiciliado rechazado | @descServicio&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
													       </p>@leyenda</p>
													</div>
		
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
															<span>@folio</span>
														</p>
													</div>

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si t� no realizaste esta operaci�n</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">800 3000 268 opci�n "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedir� informaci�n adicional de tus cuentas</li>
																	<li>No Compartas tu contrase�a de acceso y c�mbiala peri�dicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>',
		'Pago de servicio domiciliado rechazado',
		'',
		GETDATE(),
		1
	)
end

------------PAGO DOMICILIADO DE PREST�MO--------------------------------


DELETE from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 102
DELETE from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 102

--SMS
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 102)
begin
	insert into TBL_BANCA_NOTIFICACIONES_SMS(id_tipo_bitacora, cuerpo, fecha_alta,activo)
	values
	(
		102,
		'CMV Finanzas, Pago domiciliado realizado a @producto por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 8003000268 opc 5',	
		GETDATE(),
		1
	)
end

--MAIL
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 102)
begin
	insert into TBL_BANCA_NOTIFICACIONES_CORREO(id_tipo_bitacora, cuerpo, asunto, url_img_operacion, fecha_alta,activo)
	values
	(
		102,		
		'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operaci�n de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realiz�  exitosamente</p>
		</div>
		
		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<!-- INICIO  SI ES UNA TRANSFERENCIA -->
		<div id="content-transferencia">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
				<span style="font-weight:500; ">@CuentaRetiro</span>
			</p>
			<p style="display: block !important; margin-top: -15px;">
				<span><b style="color: rgba(0,0,0,.7)">Cuenta Dep�sito:</b></span>
				<span style="font-weight:500; ">@CuentaDeposito</span>
			</p>
			<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
				<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
				<span style="font-weight:500;">@Importe</span>
			</p>	
		</div>
		<!-- FIN  SI ES UNA TRANSFERENCIA -->

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si t� no realizaste esta operaci�n</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">800 3000 268 opci�n "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedir� informaci�n adicional de tus cuentas</li>
	                    <li>No Compartas tu contrase�a de acceso y c�mbiala peri�dicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>',
		'Pago a pr�stamo domiciliado',
		'',
		GETDATE(),
		1
	)
end

------------PAGO DOMICILIADO DE PREST�MO RECHAZADO--------------------------------

delete TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 103
delete from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 103

--SMS
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 103)
begin
	insert into TBL_BANCA_NOTIFICACIONES_SMS(id_tipo_bitacora, cuerpo, fecha_alta,activo)
	values
	(
		103,
		'CMV Finanzas, Pago domiciliado @producto rechazado: @leyenda ,@fecha_hora_operacion, Atenci�n a socios 8003000268 opc 5',	
		GETDATE(),
		1
	)
end

--MAIL
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 103)
begin
	insert into TBL_BANCA_NOTIFICACIONES_CORREO(id_tipo_bitacora, cuerpo, asunto, url_img_operacion, fecha_alta,activo)
	values
	(
		103,		
		'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p style="display:none">La operaci�n de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;Pago de pr�stamo domiciliado rechazado | @producto&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
													       </p>@leyenda</p>
													</div>
		
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>														
													</div>

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si t� no realizaste esta operaci�n</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">800 3000 268 opci�n "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedir� informaci�n adicional de tus cuentas</li>
																	<li>No Compartas tu contrase�a de acceso y c�mbiala peri�dicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>',
		'Pago de pr�stamo domiciliado rechazado',
		'',
		GETDATE(),
		1
	)
end

------------REGISTRO DE ACLARACI�N DE DOMICILIADO --------------------------------

delete TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 104
delete from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 104

--SMS
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_SMS where id_tipo_bitacora = 104)
begin
	insert into TBL_BANCA_NOTIFICACIONES_SMS(id_tipo_bitacora, cuerpo, fecha_alta,activo)
	values
	(
		104,
		'CMV Finanzas, Registro de Aclaraci�n por Domiciliaci�n, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 8003000268 opc 5',	
		GETDATE(),
		1
	)
end

--MAIL
if not exists (select 1 from TBL_BANCA_NOTIFICACIONES_CORREO where id_tipo_bitacora = 104)
begin
	insert into TBL_BANCA_NOTIFICACIONES_CORREO(id_tipo_bitacora, cuerpo, asunto, url_img_operacion, fecha_alta,activo)
	values
	(
		104,		
		'<html>  
			<head>   
				<style>     
					.md-100{    width: 100%;    margin: auto;   }     
					.md-80{    width: 80%;    margin: auto;   }     
					.md-70{    width: 70%;    margin: auto;   }     
					.md-20{    width: 20%;    margin: auto;   }       
					/*------------------------------------*/   
					#content-principal{    width:800px;     margin: auto;   }   
					/*------------------------------------*/   
					#content-header{    border-bottom: 20px solid #89BA27;   }     
					#content-header img{    margin: 0;   }     
					/*------------------------------------*/   
					#content-nombre{    margin-top: 10px;     font-size: 25px;     color:#89BA27;   }   
					/*------------------------------------*/   
					#content-operacion{    margin-top: 10px;     text-align: center;   }     
					#content-operacion p{    color:#595959;    font-size: 25px;    padding: 0;    margin: 5px;    display: inline-table;       width: 100%;   }     
					#operacion{    font-weight:900 !important;   }     
					#operacion span{    height: 25px;    display: inline-block;    }     
					#operacion img{    height: 100%;   }     
					#operacion-icono {    margin-top: 15px;    margin-bottom: 10px;    text-align: center;   }     
					/*------------------------------------*/   
					#content-transferencia{    margin-top: 10px;     font-size: 20px;     color:#595959;    text-align: center;   }     
					/*------------------------------------*/   
					#content-detalle{    margin: auto;    margin-top: 30px;    background-color: #e4e4e4;      text-align:center;    padding: 5px;   }   
					#content-detalle p{    font-size: 23px;    color:#595959;    margin: 10px;   }   
					/*------------------------------------*/   
					#content-aclaracion{    margin-top: 20px;    text-align: center;    font-size: 25px;     color:#595959;   }   
					/*------------------------------------*/   
					#footer{    background-color:#e4e4e4;   }     
					#footer-content-tips{    display: inline-flex;   }     
					#tips-content-img{    text-align: center;   }     
					#tips-content-tips{    font-size: 30px;     color:#595959;   }     
					#tips-content-tips ul{    font-size: 20px;   }     @media only screen and (max-width: 600px) {      p, span, li{       font-size: 15px !important;      }      #content-header,    #content-nombre,    #content-operacion,    #content-detalle,    #content-aclaracion,    #footer{     width: 90%;     margin: auto;    }        /*------------------------------------*/      #content-principal{     width:100%;      margin: auto;    }      /*------------------------------------*/    #content-header{     border-bottom: 10px solid #89BA27;       }      /*------------------------------------*/    #operacion{     font-size: 15px;      font-weight:900 !important;    }      #operacion span{     height: 15px;    }      #operacion-icono img{     width: 40px;     height: 50px;    }      /*------------------------------------*/    #content-transferencia p:last-child{     border-bottom: 2px solid #89BA27 !important;    }    /*------------------------------------*/    #footer-content-tips{     display: block;     padding: 10px 10px 0px 0px;    }      #tips-content-img,    #tips-content-tips{     width: 95%;     text-align: center;    }      #tips-content-img img{     width: 40px;     height: 50px;    }     }  
				</style>  
			</head>  
			<body>   
				<div id="content-principal">      
					<div id="content-header" class="md-100">           
						<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>     
					</div>      
					<div id="content-nombre" class="md-100">     
						<p style="font-weight:900; ">@Nombre</p>    
					</div>      
					<div id="content-operacion" class="md-100">     
						<p>La operaci�n de</p>     
						<p id="operacion">      
							<span>       
								<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />       &nbsp;@operacion&nbsp;       <img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />      
							</span>     
						</p>     
						<p>se realiz�  exitosamente</p>    
					</div>      
					<div id="content-detalle" class="md-70">     
						<p>      
							<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>      <span>@fecha_hora_operacion</span>     
						</p>     
						<p>      
							<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>      <span>@folio</span>     
						</p>    
					</div>      
				<div id="content-aclaracion" class="md-100">     
					<p>      
						<span style="font-weight:900; ">Si t� no realizaste esta operaci�n</span>       
						<span style="font-weight:500; "> acude a tu sucursal o llama al</span>      
						<span style="font-weight:900; ">800 3000 268 opci�n "5"</span>      
						<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>     
					</p>    
				</div>      
				<!-- FOOTER -->    
				<div id="footer" class="md-100">     
					<div id="footer-content-tips" class="md-100">      
						<div id="tips-content-img" class="md-20">             
							<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />            
						</div>            
						<div id="tips-content-tips" class="md-80">             
							<p style="font-weight:900;">Tips de Seguridad:</p>                    
							<ul>                       
								<li>Caja Morelia Valladolid nunca te pedir� informaci�n adicional de tus cuentas</li>                       
								<li>No Compartas tu contrase�a de acceso y c�mbiala peri�dicamente</li>                   
							</ul>            
						</div>     
					</div>                      
					<div class="md-100">      
						<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">       
							<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>      
						</a>     
					</div>      
				</div>   
			</div>  
		</body>  
	</html>',
		
		'Registro de Aclaraci�n por Domiciliaci�n',
		'',
		GETDATE(),
		1
	)
end

