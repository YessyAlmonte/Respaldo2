USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_DOMICILIACION_OBTENER_SERVICIOS_DOMICILIADOS]    Script Date: 11/06/2020 12:52:23 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20200612
Objetivo		domiciliaciones obtener servicios domiciliados
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_DOMICILIACION_OBTENER_SERVICIOS_DOMICILIADOS' and xtype = 'p')
	drop proc SP_DOMICILIACION_OBTENER_SERVICIOS_DOMICILIADOS
go

create proc
[dbo].[SP_DOMICILIACION_OBTENER_SERVICIOS_DOMICILIADOS]
@numeroSocio AS VARCHAR(20),
@tipoOrigen int,
@activo bit,
@tipoDomiciliacion int = 3,
@TipoSolicitado int = 3

AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int,
@numero_int int 

select @mensaje_validacion =msj ,@estatus = estatus  from  dbo.FN_BANCA_VALIDA_SOCIO(@numeroSocio,0)

  if(@mensaje_validacion is  null )
  BEGIN
  SET @numero_int = CAST(@numeroSocio as int )
		-- VALIDACIONES --
		-- FIN DE VALIDACIONES -

			SELECT 200 estatus,  'OK' mensaje

			SELECT
			d.id_domiciliacion,
			banca.dbo.FN_BANCA_DESCIFRAR(numero_socio) numero_socio,	
			d.clabe_corresponsalias_retiro clabe_corresponsalias,
			d.alias,
			d.monto monto_maximo,
			d.numero_referencia,
			d.con_vigencia,
			d.fecha_vencimiento,
			d.indefinido es_indefinido,
			d.id_periodicidad_pago id_Periodicidad,
			pp.descripcion descripcion_Periodicidad,
			d.id_tipo_domiciliacion Tipo_Domiciliacion,
			d.fecha_alta,			
			p.tipo_front,
			d.id_producto,
			d.id_servicio,
			d.telefono,						
			200 estatus,  
			'OK' mensaje,			
			@TipoSolicitado Tipo_Solicitado,
			P.descripcion,
			D.por_dia_especifico_de_pago por_dia_pago,
			D.por_periodicidad,
			D.dia_pago fecha_pago			
			FROM TBL_BANCA_DOMICILIACIONES D
			LEFT  JOIN  
				CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO AS P 
			ON 
				D.id_producto = P.id_producto AND D.id_servicio = P.id_servicios_pago
			LEFT JOIN 
				CAT_BANCA_PERIODICIDAD_PAGO PP 
			on
				pp.id_periodicidad_pago = d.id_periodicidad_pago
			
			WHERE 
				BANCA.dbo.FN_BANCA_DESCIFRAR(D.numero_socio) = @numero_int and d.activo = @activo and d.id_tipo_domiciliacion = @tipoDomiciliacion
				
  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje
end try
begin catch
	select -1 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

grant exec on SP_DOMICILIACION_OBTENER_SERVICIOS_DOMICILIADOS to public
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_DOMICILIACION_OBTENER_SERVICIOS]    Script Date: 11/06/2020 12:52:23 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20200612
Objetivo		domiciliaciones obtener servicios
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_DOMICILIACION_OBTENER_SERVICIOS' and xtype = 'p')
	drop proc SP_DOMICILIACION_OBTENER_SERVICIOS
go

create proc
[dbo].[SP_DOMICILIACION_OBTENER_SERVICIOS]
@numeroSocio AS VARCHAR(20),
@tipoOrigen int,
@tipoDomiciliacion int = 3,
@TipoSolicitado int = 1,
@activo bit = 1


AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int,
@numero_int int 

select @mensaje_validacion =msj ,@estatus = estatus  from  dbo.FN_BANCA_VALIDA_SOCIO(@numeroSocio,0)

  if(@mensaje_validacion is  null )
  BEGIN
  SET @numero_int = CAST(@numeroSocio as int )
		-- VALIDACIONES --
		-- FIN DE VALIDACIONES -	

			SELECT 200 estatus,  'OK' mensaje
			select 
				p.tipo_front,
				p.id_producto,
				p.id_servicios_pago id_servicio,
				p.descripcion Descripcion,
				p.precio,
				p.tipo_referencia,
				p.id_cat_tipo_servicio,
				p.has_digito_verificador,
				p.comision_cmv monto_comision,
				p.leyenda,
				200 estatus,  
				'OK' mensaje,			
				@TipoSolicitado Tipo_Solicitado,
				@numero_int numero_socio

			from 
				banca..CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO P
			join BANCA..CAT_BANCA_SERVICIOS_PAGO s on P.id_servicios_pago=s.id_servicios_pago
			where 
				p.activo = 1  and s.activo=1
			and 
				tipo_front not in (4)
			and P.id_servicios_pago in (select id_servicios_pago from banca..CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO  where tipo_front=4 and activo=1)
			

			/*
			select				
				p.tipo_front,
				ss.id_producto,
				ss.id_servicio,
				P.descripcion descProducto,
				p.precio,
				p.tipo_referencia,
				p.id_cat_tipo_servicio,
				p.has_digito_verificador,
				p.comision_cmv,
				p.leyenda,
				200 estatus,  
				'OK' mensaje,			
				@TipoSolicitado TipoSolicitado				
			from 
				BANCA..TBL_BANCA_SERVICIOS_SOCIOS SS 
			left join 
				banca..TBL_BANCA_DOMICILIACIONES D			
			on 
				SS.numero_socio = banca.dbo.FN_BANCA_DESCIFRAR(D.numero_socio) and SS.id_producto = D.id_producto and SS.id_servicio = d.id_servicio and SS.numero_referencia = D.numero_referencia
			LEFT  JOIN  
				CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO AS P 
			ON 
				SS.id_producto = P.id_producto AND SS.id_servicio = P.id_servicios_pago
			where 
				SS.numero_socio = 837648 and d.id_servicio is null and ss.activo = 1*/

			/*
			SELECT 			
			p.tipo_front,			
			D.id_producto,
			D.id_servicio,
			P.descripcion descProducto,
			p.precio,
			p.tipo_referencia,
			p.id_cat_tipo_servicio,
			p.has_digito_verificador,
			p.comision_cmv,
			p.leyenda,
			200 estatus,  
			'OK' mensaje,			
			@TipoSolicitado TipoSolicitado
			
			FROM TBL_BANCA_DOMICILIACIONES D
			LEFT  JOIN  
				CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO AS P 
			ON 
				D.id_producto = P.id_producto AND D.id_servicio = P.id_servicios_pago
			
			WHERE 
				BANCA.dbo.FN_BANCA_DESCIFRAR(D.numero_socio) = @numero_int and d.activo = @activo and d.id_tipo_domiciliacion = @tipoDomiciliacion
				*/
 
  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje
end try
begin catch
	select -1 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

grant exec on SP_DOMICILIACION_OBTENER_SERVICIOS to public
go

use BANCA
go

-- se crea procedimiento SP_DOMICILIACION_OBTENER_INFO_REPORTE
if exists (select * from sysobjects where name like 'SP_DOMICILIACION_OBTENER_INFO_REPORTE' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_DOMICILIACION_OBTENER_INFO_REPORTE
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20200619
Objetivo		Obtener la informaci�n para el reporte
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_DOMICILIACION_OBTENER_INFO_REPORTE
	
	@Id_domiciliacion bigint,
	@numero_socio bigint
	
as

	begin -- procedimiento

	      if(coalesce(@Id_domiciliacion,0)=0)
		    select @Id_domiciliacion=max(id_domiciliacion) from TBL_BANCA_DOMICILIACIONES where BANCA.DBO.FN_BANCA_DESCIFRAR(numero_socio)=@numero_socio

		    DECLARE @periodicidad_pago varchar(30),@num_ptmo varchar(20),@id_mov int,@monto_requerido money,@dia_pago int=0

			SELECT @num_ptmo=num_ptmo,@id_mov=id_mov
			FROM TBL_BANCA_DOMICILIACIONES where id_domiciliacion=@Id_domiciliacion

			--consultamos la periodicidad del ptmo
			if(@id_mov>0)
			begin
			   
			   if(@id_mov=10)
			     select @periodicidad_pago='Mensual',
				        @monto_requerido=HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(Num_ptmo,10,@numero_socio,4,2),
						@dia_pago=day(HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(Num_ptmo,10,@numero_socio,4,1))
				 from hape.dbo.tbl_revolvente_lineas_credito where numero=@numero_socio and num_ptmo=@num_ptmo
				 				 
			   else
				select @periodicidad_pago=case when id_periodicidad=3 then case when a.id_amortizacion=1 then 'cada' + substring(lower(b.DESCRIPCION_SEMANAS),4,10) else 'cada ' + lower(b.DESCRIPCION_SEMANAS) end
										  else 
												  case when a.id_amortizacion=1 then 'cada' + substring(lower(b.Descripcion),3,6) else 'cada ' + lower(b.Descripcion) end
										  end,
					   @monto_requerido=HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(Num_ptmo,id_mov,numero,id_esquema,2),
					   @dia_pago=day(HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(Num_ptmo,id_mov,numero,id_esquema,1))
				from hape..edo_de_cuenta a
				join hape.dbo.AMORTIZACIONES b on a.id_amortizacion=b.id_amortizacion
				where numero=@numero_socio and id_mov=@id_mov and num_ptmo=@num_ptmo			

			end
	
			SELECT 
			s.Ciudad,
			case when D.id_tipo_domiciliacion=1 then 'CAJA MORELIA VALLADOLID, S.C. DE A.P. DE R.L. DE C.V.' else servicio.descripcion end nombre_proveedor_destino,
			case when D.id_tipo_domiciliacion=1 then BANCA.DBO.FN_BANCA_OBTENER_NOMBRE_COMERCIAL(d.num_ptmo) else producto.descripcion end nombre_producto,
			case when D.id_tipo_domiciliacion=1 then d.clabe_corresponsalias_deposito else d.numero_referencia end referencia,
			case when D.id_tipo_domiciliacion=1 then @periodicidad_pago else coalesce(periodicidad.descripcion,'') end periodicidad_pago,
			case when D.por_dia_especifico_de_pago=1 then D.dia_pago else @dia_pago end dia_pago,
			'CAJA MORELIA VALLADOLID, S.C. DE A.P. DE R.L. DE C.V.' nombre_proveedor_origen,
			coalesce(ed.Num_tarjeta,'') Num_tarjeta,
			coalesce(ci.clabe,'') clabe_interbancaria,
			p.Tel_Celular,
			case when D.id_tipo_domiciliacion=1 and por_monto_requerido=1 then @monto_requerido else d.monto end monto_maximo, 
			case when por_monto_fijo=1 then monto else CAST(0 AS decimal) end monto_fijo,
			por_monto_fijo,
			por_monto_requerido,
			indefinido,
			D.fecha_vencimiento,
			id_tipo_domiciliacion,
			p.Nombre_s + ' ' + coalesce(p.Apellido_Paterno,'') + ' ' + coalesce(p.Apellido_Materno,'') nombre_completo_socio,
			d.activo,
			clabe_corresponsalias_retiro,
			folio_autorizacion
			FROM TBL_BANCA_DOMICILIACIONES D
			JOIN HAPE..PERSONA p on BANCA.DBO.FN_BANCA_DESCIFRAR(d.numero_socio)=p.Numero AND p.Id_Tipo_Persona=1
			JOIN HAPE..SUCURSALES s on p.Id_de_Sucursal=s.Id_de_Sucursal 
			LEFT JOIN HAPE..TIPOS_DE_OPERACIONES o ON d.ID_MOV=o.Id_mov
			LEFT JOIN CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO producto on D.id_producto=producto.id_producto
			LEFT JOIN CAT_BANCA_SERVICIOS_PAGO servicio on D.id_servicio=servicio.id_servicios_pago
			LEFT JOIN CAT_BANCA_PERIODICIDAD_PAGO periodicidad on D.id_periodicidad_pago=periodicidad.id_periodicidad_pago
			LEFT JOIN HAPE..EDO_DE_CUENTA ed on p.Numero=ed.Numero and p.Id_Tipo_Persona=ed.Id_Tipo_persona and ed.Id_mov=112 and ed.Tarjeta_activa='T'
			LEFT JOIN TBL_BANCA_CUENTAS_INTERBANCARIAS ci on p.Numero=BANCA.DBO.FN_BANCA_DESCIFRAR(ci.numero_socio) and ci.activo=1			
			WHERE  id_domiciliacion=@Id_domiciliacion
		
	end -- procedimiento
go

grant exec on SP_DOMICILIACION_OBTENER_INFO_REPORTE to public

go

use BANCA
go

-- se crea procedimiento SP_DOMICILIACION_OBTENER_CREDITOS_DOMICILIADOS
if exists (select * from sysobjects where name like 'SP_DOMICILIACION_OBTENER_CREDITOS_DOMICILIADOS' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_DOMICILIACION_OBTENER_CREDITOS_DOMICILIADOS
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			2020/06/12
Objetivo		Consultar los creditos domiciliados del socio
Proyecto		Proyecto
Ticket			ticket

*/

create proc

	SP_DOMICILIACION_OBTENER_CREDITOS_DOMICILIADOS
	
	@numero bigint,
	@activo bit
	
as

	begin -- procedimiento

	   	Declare 
		@mensaje_validacion varchar(500),
		@estatus int
	
		begin try -- try principal

		select @mensaje_validacion =msj ,@estatus = estatus  from  dbo.FN_BANCA_VALIDA_SOCIO(@numero,0)
		
		IF(@mensaje_validacion IS NULL)
		BEGIN
			SELECT 
			id_domiciliacion,e.Numero numero_socio,
			clabe_corresponsalias_retiro,con_vigencia,
			fecha_vencimiento,indefinido,
			id_tipo_domiciliacion,d.fecha_alta,
			HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(d.Num_ptmo,e.id_mov,@numero,e.id_esquema,2) monto_requerido,
			HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(d.Num_ptmo,e.id_mov,@numero,e.id_esquema,1) fecha_limite_pago,
			clabe_corresponsalias_deposito,
			por_dia_especifico_de_pago,
			por_dia_limite_de_pago,
			dia_pago fecha_pago,
			case when d.por_monto_fijo=1 then monto else 0 end monto,
			id_esquema,
			e.id_mov,
			e.num_ptmo,
			alias,
			por_dia_especifico_de_pago por_dia_pago,
            d.por_periodicidad,
			d.por_monto_fijo,
			d.por_monto_requerido,
			BANCA.[dbo].FN_BANCA_OBTENER_NOMBRE_COMERCIAL(E.num_ptmo) descripcion,
			e.id_esquema Tipo_Esquema
			INTO #PTMOS_DOMICILIADOS
			FROM TBL_BANCA_DOMICILIACIONES d
			join HAPE..EDO_DE_CUENTA e on BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)=e.numero and d.num_ptmo=e.num_ptmo		
			--LEFT  JOIN	HAPE..TIPOS_DE_OPERACIONES AS TDO ON TDO.Id_mov = e.ID_MOV
			where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)=@numero and id_tipo_domiciliacion=1 and e.saldo_actual>0
			and d.activo=@activo 
			--and not (interes_ordinario_diferido is not null and cast(GETDATE() as date)>=cast(inicio_periodo_gracia as date) and cast(GETDATE() as date)<=cast(fin_periodo_gracia as date))

			UNION 

			SELECT 
			id_domiciliacion,e.Numero numero_socio,
			clabe_corresponsalias_retiro,con_vigencia,
			fecha_vencimiento,indefinido,
			id_tipo_domiciliacion,d.fecha_alta,
			HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(d.Num_ptmo,10,@numero,4,2) monto_requerido,
			HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(d.Num_ptmo,10,@numero,4,1) fecha_limite_pago,
			clabe_corresponsalias_deposito,
			por_dia_especifico_de_pago,
			por_dia_limite_de_pago,
			dia_pago fecha_pago,
			monto,
			4 id_esquema,
			10 id_mov,
			e.num_ptmo,
			alias,
			por_dia_especifico_de_pago por_dia_pago,
            d.por_periodicidad,
			d.por_monto_fijo,
			d.por_monto_requerido,
			BANCA.[dbo].FN_BANCA_OBTENER_NOMBRE_COMERCIAL(E.num_ptmo) descripcion,
			4 Tipo_Esquema 
			FROM TBL_BANCA_DOMICILIACIONES d
			join HAPE..TBL_REVOLVENTE_LINEAS_CREDITO e on BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)=e.numero and d.num_ptmo=e.num_ptmo		
			--LEFT  JOIN	HAPE..TIPOS_DE_OPERACIONES AS TDO ON TDO.Id_mov = d.ID_MOV
			where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)=@numero and id_tipo_domiciliacion=1 and e.saldo_actual>0
			and d.activo=@activo  
			--and not (interes_ordinario_diferido is not null and cast(GETDATE() as date)>=cast(inicio_periodo_gracia as date) and cast(GETDATE() as date)<=cast(fin_periodo_gracia as date))

			SELECT 200 AS estatus , '' mensaje 

			SELECT * FROM #PTMOS_DOMICILIADOS
	   


		 
		END
		ELSE
		BEGIN
		  SELECT @estatus AS estatus , @mensaje_validacion mensaje
		END				
		
		end try -- try principal
		
		begin catch -- catch principal
		
			select -1 as estatus , ERROR_MESSAGE() AS mensaje 		
		
		end catch -- catch principal
		
	end -- procedimiento
go

grant exec on SP_DOMICILIACION_OBTENER_CREDITOS_DOMICILIADOS to public

go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_DOMICILIACION_OBTENER_CREDITOS]    Script Date: 11/06/2020 12:52:23 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20200612
Objetivo		domiciliaciones obtener servicios
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_DOMICILIACION_OBTENER_CREDITOS' and xtype = 'p')
	drop proc SP_DOMICILIACION_OBTENER_CREDITOS
go

create proc
[dbo].[SP_DOMICILIACION_OBTENER_CREDITOS]
@numeroSocio AS VARCHAR(20),
@tipoOrigen int,
@tipoDomiciliacion int =1,
--@TipoCuenta int,
@TipoSolicitado int = 2,
@activo bit = 1


AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int,
@numero_int int 

select @mensaje_validacion =msj ,@estatus = estatus  from  dbo.FN_BANCA_VALIDA_SOCIO(@numeroSocio,0)

  if(@mensaje_validacion is  null )
  BEGIN
  SET @numero_int = CAST(@numeroSocio as int )
		-- VALIDACIONES --
		-- FIN DE VALIDACIONES -
	--IF EXISTS (SELECT 1 FROM TBL_BANCA_DOMICILIACIONES  WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_int)
	--BEGIN

			SELECT 200 estatus,  'OK' mensaje


			--otros ptmos
			select 
				CC.CUENTA clabe_corresponsalias, 
				CI.clabe clabe_spei,
				coalesce(EC.ultimo_abono,ec.fecha_ptmo) fecha_ultimo_abono,
				CC.ID_MOV,
				BANCA.[dbo].FN_BANCA_OBTENER_NOMBRE_COMERCIAL(Ec.num_ptmo) nombre_cuenta,
				EC.Num_ptmo numero_contrato,
				EC.Saldo_Actual saldo,
				3 tipo_cuenta, --tipo_cuenta = 3 (PRESTAMOS)
				EC.Id_Esquema Tipo_Esquema,
				EC.Dias_Vencidos,
				case 
					EC.Dias_Vencidos 
				when 
					 0 
				then 
					'Vigente' 
				else
					'Vencido' 					
				end
				as estatus_credito,
				--FechaCorte, --Dia corte del sp
				hape.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(EC.Num_ptmo,CC.ID_MOV,CC.NUMERO,EC.Id_Esquema,1) fecha_limite_pago, --FechaLimitePago aun queda pendiente				
				HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(EC.Num_ptmo,CC.ID_MOV,CC.NUMERO,EC.Id_Esquema,3) fecha_corte,
				EC.Fecha_Ptmo fecha_prestamo,
				coalesce(case 
				when
					EC.ultimo_abono>EC.Ultimo_Int_Ord
				then
					EC.ultimo_abono
				when	
					EC.ultimo_abono<EC.Ultimo_Int_Ord
				then	
					EC.Ultimo_Int_Ord


				when
					EC.ultimo_abono>EC.Ultimo_Int_Mor
				then
					EC.ultimo_abono
				when
					EC.ultimo_abono<EC.Ultimo_Int_Mor 
				then
					EC.Ultimo_Int_Mor

				when 
					EC.Ultimo_Int_Ord>EC.Ultimo_Int_Mor
				then
					EC.Ultimo_Int_Ord
				else
					EC.Ultimo_Int_Mor 
				end,ec.fecha_ptmo)
					as fecha_ultimo_pago,
				0 limite_credito,
				EC.saldo_actual monto_disponible,
				EC.Monto_Inicial monto_inicial,
				--PagoHoy,			--regresa sp
				ec.Periodos_Atrasados periodos_atrasados,
				CC.CUENTA referencia_corresponsales,
				--SaldoAdelantado,	-- sp saldo_adelanto				
				 HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(ec.Num_ptmo,ec.id_mov,@numeroSocio,ec.id_esquema,2) monto_requerido,    

				@TipoSolicitado tipo_solicitado,

				CC.NUMERO numero_socio
			from 
				HAPE..EDO_DE_CUENTA EC
			join 
				hape..tbl_corresponsalias_cuentas CC 
			on 
				EC.numero = CC.numero and EC.Num_ptmo = CC.NUM_PTMO 
			left join 
				banca..TBL_BANCA_DOMICILIACIONES D
			on 
				EC.numero = banca.dbo.FN_BANCA_DESCIFRAR(D.numero_socio) and EC.Num_ptmo = D.num_ptmo and D.activo=1
			left join 
				banca..TBL_BANCA_CUENTAS_INTERBANCARIAS as CI 
			ON 
				BANCA.DBO.FN_BANCA_DESCIFRAR(CI.numero_socio) = EC.NUMERO AND CI.ACTIVO =1
			--LEFT  JOIN 
				--HAPE..TIPOS_DE_OPERACIONES AS TDO 
			--ON 
				--TDO.Id_mov = CC.ID_MOV
			where 
				EC.Numero=@numeroSocio 
			and 
				EC.Id_Tipo_persona=1 
			and 
				EC.Id_mov<10 
			and 
				EC.Saldo_Actual>0.01 
			and 
				D.num_ptmo is null
			
			--and not (ec.interes_ordinario_diferido is not null and cast(GETDATE() as date)>=cast(ec.inicio_periodo_gracia as date) and cast(GETDATE() as date)<=cast(ec.fin_periodo_gracia as date))


			UNION
			--revolvente
			select 
				CC.CUENTA clabe_corresponsalias,
				CI.clabe clabe_spei,
				coalesce(LR.fecha_ultimo_abono,LR.fecha_autorizacion) fecha_ultimo_abono,
				10 ID_MOV,
				BANCA.[dbo].FN_BANCA_OBTENER_NOMBRE_COMERCIAL(LR.num_ptmo) nombre_cuenta,
				LR.Num_ptmo numero_contrato,
				LR.saldo_actual saldo,
				3 tipo_cuenta, --tipo_cuenta = 3 (PRESTAMOS)
				4 Tipo_Esquema,
				LR.dias_vencidos,
				case 
					LR.dias_vencidos
				when 
					0 
				then 
					'Vigente'
					
				else 
					'Vencido'
				end
				as estatus_credito,
				hape.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(LR.Num_ptmo,10,cc.NUMERO,4,1) fecha_limite_pago, --FechaLimitePago aun queda pendiente
				hape.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(LR.Num_ptmo,10,cc.NUMERO,4,3) fecha_corte,
				LR.fecha_autorizacion fecha_prestamo,				
				coalesce(case 
				when
					LR.fecha_ultimo_abono>LR.fecha_ultimo_int_ord
				then
					LR.fecha_ultimo_abono
				when	
					LR.fecha_ultimo_abono<LR.fecha_ultimo_int_ord
				then	
					LR.fecha_ultimo_int_ord


				when
					LR.fecha_ultimo_abono>LR.fecha_ultimo_int_mor
				then
					LR.fecha_ultimo_abono
				when
					LR.fecha_ultimo_abono<LR.fecha_ultimo_int_mor 
				then
					LR.fecha_ultimo_int_mor


				when 
					LR.fecha_ultimo_int_ord>LR.fecha_ultimo_int_mor
				then
					LR.fecha_ultimo_int_ord
				else
					LR.fecha_ultimo_int_mor 
				end,LR.fecha_autorizacion)
					as fecha_ultimo_pago,
				LR.limite_credito limite_credito,
				LR.saldo_actual monto_disponible,
				LR.Limite_credito monto_inicial,
				LR.periodos_vencidos periodos_atrasados,
				CC.CUENTA referencia_corresponsales,
				hape.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(LR.Num_ptmo,10,cc.NUMERO,4,2) monto_requerido,
				@TipoSolicitado tipo_solicitado,

				cc.NUMERO numero_socio 
					
			from 
				hape..VW_REVOLVENTE_LINEAS LR
			join 
				hape..tbl_corresponsalias_cuentas CC 
			on 
				LR.numero = CC.numero and LR.Num_ptmo = CC.NUM_PTMO 
			left join 
				banca..TBL_BANCA_DOMICILIACIONES D
			on 
				LR.numero = banca.dbo.FN_BANCA_DESCIFRAR(D.numero_socio) and LR.Num_ptmo = D.num_ptmo and D.activo=1
			left join 
				banca..TBL_BANCA_CUENTAS_INTERBANCARIAS as CI 
			ON 
				BANCA.DBO.FN_BANCA_DESCIFRAR(CI.numero_socio) = LR.NUMERO AND CI.ACTIVO =1
			--LEFT  JOIN 
				--HAPE..TIPOS_DE_OPERACIONES AS TDO 
			--ON 
				--TDO.Id_mov = CC.ID_MOV
			join 
				hape..TBL_REVOLVENTE_LINEAS_CREDITO RLC
			on 
				RLC.numero = lr.numero
			where 
				LR.numero=@numeroSocio 
			and 
				LR.Saldo_Actual>0.01 
			and 
				LR.id_tipo_persona=1 
			and 
				cc.ID_MOV = 10 
			and 
				D.num_ptmo is null						
			
			--and not (RLC.interes_ordinario_diferido is not null and cast(GETDATE() as date)>=cast(RLC.inicio_periodo_gracia as date) and cast(GETDATE() as date)<=cast(RLC.fin_periodo_gracia as date))


			/*	
			SELECT
			D.clabe_corresponsalias_deposito, -- clabe corresponsalias de 
			CI.clabe,
			EC.ultimo_abono  FechaUltimoAbono, 
			CC1.Id_mov,
			TDO1.Desc_prestamo,
			EC.Num_ptmo,
			--NumeroContrato, -- 
			EC.Saldo_Actual,
			@TipoCuenta TipoCuenta,
			EC.Id_Esquema,
			EC.Dias_Vencidos,
			--EstatusCredito,
			--FechaCorte, --Dia corte del sp
			--FechaLimitePago, --
			--FechaPrestamo, --edo de cuenta
			--FechaUltimoPago, --frcha ultimo abono, cual es la diferencia ?  -- la mayor de entre ultimo abono/interes ordinario/ interes moratorio
			--LimiteCredito, --saldo actual + intereses. que va en este campo?- -----------------------------
			--MontoDisponible, --solo aplica para revolvente --saldo actual
			--MontoInicial, --saldo inicial, edo de cuenta
			--PagoHoy,      --regresa sp
			--PeriodosAtrasados, --edo de cuenta periodos atrasados
			--ReferenciaCorresponsales, --cual es ?
			--SaldoAdelantado, -- de donde se obtiene ?
			--MontoRequerido --sp montoMaximo
			--FechaLimitePago	 -- se obtendra de declaracion cartera ?					

						
			200 estatus,
			'OK' mensaje,
			@TipoSolicitado TipoSolicitado  
		
			FROM TBL_BANCA_DOMICILIACIONES D
			
			LEFT  JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS AS CC ON CC.CUENTA = D.clabe_corresponsalias_retiro AND CC.NUMERO = BANCA.dbo.FN_BANCA_DESCIFRAR(D.NUMERO_SOCIO) 			
			LEFT  JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS AS CC1 ON CC1.CUENTA = D.clabe_corresponsalias_deposito AND CC.NUMERO = BANCA.dbo.FN_BANCA_DESCIFRAR(D.NUMERO_SOCIO) 
			LEFT  JOIN HAPE..TIPOS_DE_OPERACIONES AS TDO1 ON TDO1.Id_mov = CC1.ID_MOV AND CC.NUMERO = BANCA.dbo.FN_BANCA_DESCIFRAR(D.NUMERO_SOCIO)
			INNER JOIN CAT_BANCA_TIPOS_DOMICILIACION AS TD ON TD.id_tipo_domiciliacion = D.id_tipo_domiciliacion
			INNER JOIN CAT_BANCA_PERIODICIDAD_PAGO  AS PP ON PP.id_periodicidad_pago = D.id_periodicidad_pago

			inner join TBL_BANCA_CUENTAS_INTERBANCARIAS as CI ON BANCA.DBO.FN_BANCA_DESCIFRAR(CI.numero_socio) = BANCA.dbo.FN_BANCA_DESCIFRAR(D.NUMERO_SOCIO) AND CI.ACTIVO =1
			inner join hape..edo_de_cuenta EC  on CC1.numero = EC.numero and CC1.id_mov = EC.id_mov and CC1.cuenta = D.clabe_corresponsalias_deposito
			
			WHERE 
				BANCA.dbo.FN_BANCA_DESCIFRAR(D.numero_socio) = @numero_int 
			and
			 
				d.activo = @activo
			and 
				d.id_tipo_domiciliacion = @tipoDomiciliacion
				*/
  --END
  /*ELSE
  BEGIN
		SELECT id_excepcion AS estatus , descripcion as mensaje 
		FROM CAT_BANCA_EXCEPTIONS
		WHERE id_excepcion = 372
  END*/
  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje
end try
begin catch
	select -1 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch

END
go

grant exec on SP_DOMICILIACION_OBTENER_CREDITOS to public
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_DOMICILIACION_CANCELAR_DOMICILIACION]    Script Date: 11/06/2020 12:52:23 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*

Autor			Cristian P�rez Garc�a
UsuarioRed		pegc837648
Fecha			20200612
Objetivo		cancelar domiciliacion
Proyecto		Banca
Ticket			ticket

*/

if exists (select * from sysobjects where name like 'SP_DOMICILIACION_CANCELAR_DOMICILIACION' and xtype = 'p')
	drop proc SP_DOMICILIACION_CANCELAR_DOMICILIACION
go

create proc
[dbo].[SP_DOMICILIACION_CANCELAR_DOMICILIACION]
@idDomiciliacion int,
@numeroSocio AS bigint,
@tipoOrigen int
--@tipoDomiciliacion int



AS
BEGIN

begin 
try
Declare 
@mensaje_validacion varchar(500),
@estatus int,
@numero_int int,
@Folio int ,
@id_banca_folio int

select @mensaje_validacion =msj ,@estatus = estatus  from  dbo.FN_BANCA_VALIDA_SOCIO(@numeroSocio,0)

  if(@mensaje_validacion is  null )
  BEGIN
  SET @numero_int = CAST(@numeroSocio as int )
		-- VALIDACIONES --
		-- FIN DE VALIDACIONES -	
		if exists(select 1 from tbl_banca_domiciliaciones where banca.dbo.fn_banca_descifrar(numero_socio) = @numeroSocio and id_domiciliacion = @idDomiciliacion /*and id_tipo_domiciliacion = @tipoDomiciliacion*/ and activo =1)
			begin
			
			INSERT INTO TBL_BANCA_FOLIOS 
			(
				numero_socio,
				fecha_alta
			) 
			values 
			(
				@numeroSocio,
				GETDATE()
			)

				select @id_banca_folio = max(id_banca_folio)from TBL_BANCA_FOLIOS where numero_socio = @numeroSocio
					
				create table #BitacoraResult(estatus int, mensaje varchar(max),folioBitacora int, descripcion varchar (max))
				insert into #BitacoraResult
					exec  SP_BANCA_INSERTA_BITACORA_OPERACIONES @numeroSocio, 29, @tipoOrigen
				
				SELECT @Folio  =  MAX(id_bitacora) FROM TBL_BANCA_BITACORA_OPERACIONES
				WHERE numero_socio = @numeroSocio AND id_tipo_bitacora = 29
				
				update tbl_banca_domiciliaciones set activo = 0, folio_cancelacion=@Folio  where banca.dbo.fn_banca_descifrar(numero_socio) = @numeroSocio and id_domiciliacion = @idDomiciliacion --and id_tipo_domiciliacion = @tipoDomiciliacion
				
				update TBL_BANCA_PAGOS_DOMICILIADOS set id_estatus_pago_banca=4 where id_domiciliacion=@idDomiciliacion and id_estatus_pago_banca=1
	
				drop table #BitacoraResult
				SELECT 200 estatus,  'OK' mensaje
			end
			else
			begin
				SELECT id_excepcion AS estatus ,'La domiciliacion ya se encuentra cancelada' as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 373
			end

  END
  ELSE
	  SELECT @estatus AS estatus , @mensaje_validacion mensaje
end try
begin catch
	select -1 as estatus , ERROR_MESSAGE() AS mensaje 		
end catch	
END
go

grant exec on SP_DOMICILIACION_CANCELAR_DOMICILIACION to public
go

use BANCA
go

-- se crea procedimiento SP_BANCA_OBTENER_PAGOS_DOMICILIADOS
if exists (select * from sysobjects where name like 'SP_BANCA_OBTENER_PAGOS_DOMICILIADOS' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_OBTENER_PAGOS_DOMICILIADOS
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20200721
Objetivo		Obtener pagos domiciliados
Proyecto		Domiciliacion
Ticket			ticket

*/

create proc

	SP_BANCA_OBTENER_PAGOS_DOMICILIADOS
	
	@fecha date=null,
	@id_tipo_domiciliacion int,
	@pendiente bit=0 --bandera para identificar si se requieren consultar las domiciliaciones pendientes de aplicar o que les falta aplicar el monto
	
as

	begin -- procedimiento
	   
	    select @fecha=coalesce(@fecha,getdate())

		--*************************** SERVICIOS DOMICILIADOS *************************************************

		select BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) numero_socio,d.id_domiciliacion,d.clabe_corresponsalias_retiro,d.monto monto_maximo,d.id_tipo_domiciliacion
		,d.id_servicio,d.id_producto,d.alias,p.tipo_front,d.numero_referencia,d.telefono,p.comision_cmv,cast(p.precio as money) precio
		,'' num_ptmo,0 id_mov,0 monto,p.activo,cast(0 as bit) por_monto_requerido,@fecha fecha_pago,d.clabe_corresponsalias_deposito,
		cast(1 as bit) requiere_pago_completo,c.id_mov id_mov_cuenta_retiro,
		d.por_dia_especifico_de_pago,d.dia_pago,por_periodicidad,fecha_ultimo_pago,d.fecha_alta,
		d.indefinido,d.con_vigencia,d.fecha_vencimiento,d.por_dia_limite_de_pago,0 id_esquema,id_periodicidad_pago
		INTO #DOMIILIACIONES 
		from TBL_BANCA_DOMICILIACIONES  d
		join CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO p on d.id_producto=p.id_producto and d.id_servicio=p.id_servicios_pago
		join HAPE..TBL_CORRESPONSALIAS_CUENTAS c on banca.dbo.FN_BANCA_DESCIFRAR(d.numero_socio)=c.numero and d.clabe_corresponsalias_retiro=c.cuenta
		where d.activo=1 and d.id_tipo_domiciliacion=3 and (cast(fecha_ultimo_pago as date) is null or cast(fecha_ultimo_pago as date)<>cast(@fecha as date))
		and @id_tipo_domiciliacion=3

		--************************ PREST�MOS DOMICILIADOS ********************************
		union 

		select BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) numero_socio,d.id_domiciliacion,d.clabe_corresponsalias_retiro,0 monto_maximo,d.id_tipo_domiciliacion
		,0 id_servicio,0 id_producto,d.alias,0 tipo_front,'' numero_referencia,'' telefono,0 comision_cmv,0 precio
		,d.num_ptmo num_ptmo,d.id_mov id_mov,monto,cast(1 as bit) activo,por_monto_requerido,@fecha fecha_pago,d.clabe_corresponsalias_deposito   
		,case when p.Id_Esquema=1 then cast(0 as bit) else  cast(1 as bit) end requiere_pago_completo,c.id_mov id_mov_cuenta_retiro,
		d.por_dia_especifico_de_pago,d.dia_pago,por_periodicidad,fecha_ultimo_pago,d.fecha_alta,
		d.indefinido,d.con_vigencia,d.fecha_vencimiento,d.por_dia_limite_de_pago,p.id_esquema,id_periodicidad_pago  
		from TBL_BANCA_DOMICILIACIONES  d
		join HAPE..TBL_CORRESPONSALIAS_CUENTAS c on banca.dbo.FN_BANCA_DESCIFRAR(d.numero_socio)=c.numero and d.clabe_corresponsalias_retiro=c.cuenta
		join HAPE..EDO_DE_CUENTA p on banca.dbo.FN_BANCA_DESCIFRAR(numero_socio)=p.Numero and d.num_ptmo=p.Num_ptmo and p.Saldo_Actual>0
		where d.activo=1 and id_tipo_domiciliacion=1
		and (cast(fecha_ultimo_pago as date) is null or cast(fecha_ultimo_pago as date)<>cast(@fecha as date))
		and @id_tipo_domiciliacion=1

		union

		select BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) numero_socio,d.id_domiciliacion,d.clabe_corresponsalias_retiro,0 monto_maximo,d.id_tipo_domiciliacion
		,0 id_servicio,0 id_producto,d.alias,0 tipo_front,'' numero_referencia,'' telefono,0 comision_cmv,0 precio
		,d.num_ptmo num_ptmo,d.id_mov id_mov,monto,cast(1 as bit) activo,por_monto_requerido,@fecha fecha_pago,d.clabe_corresponsalias_deposito   
		,cast(1 as bit) requiere_pago_completo,c.id_mov id_mov_cuenta_retiro,
		d.por_dia_especifico_de_pago,d.dia_pago,por_periodicidad,fecha_ultimo_pago,d.fecha_alta,
		d.indefinido,d.con_vigencia,d.fecha_vencimiento,d.por_dia_limite_de_pago,4 id_esquema,id_periodicidad_pago  
		from TBL_BANCA_DOMICILIACIONES  d
		join HAPE..TBL_CORRESPONSALIAS_CUENTAS c on banca.dbo.FN_BANCA_DESCIFRAR(d.numero_socio)=c.numero and d.clabe_corresponsalias_retiro=c.cuenta
		join hape..TBL_REVOLVENTE_LINEAS_CREDITO r on banca.dbo.FN_BANCA_DESCIFRAR(numero_socio)=r.numero and d.num_ptmo=r.num_ptmo and r.saldo_actual>0	
		where d.activo=1 and id_tipo_domiciliacion=1
		and (cast(fecha_ultimo_pago as date) is null or cast(fecha_ultimo_pago as date)<>cast(@fecha as date))
		and @id_tipo_domiciliacion=1

		if(@pendiente=0)
		begin


		IF(@id_tipo_domiciliacion=3)
		BEGIN 

				--servicios por dia especifico de pago
				select *
				from #DOMIILIACIONES  d
				where (por_dia_especifico_de_pago=1) 
				and DAY(@fecha)=CASE WHEN dia_pago>DAY(EOMONTH(@fecha)) AND day(@fecha)=DAY(EOMONTH(@fecha)) then DAY(@fecha) else dia_pago end 
				and (indefinido=1 or (con_vigencia=1 and cast(@fecha as date)<=cast(fecha_vencimiento as date))) and id_tipo_domiciliacion=3
		
				union

				--servicios por periodicidad
				select *     
				from #DOMIILIACIONES  d
				where por_periodicidad=1 and
				CAST(@fecha AS date)=case when id_periodicidad_pago=1 then  CAST(DATEADD(DAY,1,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
											when id_periodicidad_pago=2 then  CAST(DATEADD(DAY,15,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
											when id_periodicidad_pago=3 then  CAST(DATEADD(month,1,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
											when id_periodicidad_pago=4 then  CAST(DATEADD(month,2,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
											when id_periodicidad_pago=5 then  CAST(DATEADD(month,3,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
											when id_periodicidad_pago=6 then  CAST(DATEADD(month,6,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
											when id_periodicidad_pago=7 then  CAST(DATEADD(year,1,coalesce(fecha_ultimo_pago,fecha_alta)) AS date)
										end
				and id_tipo_domiciliacion=3 and (indefinido=1 or (con_vigencia=1 and cast(@fecha as date)<=cast(fecha_vencimiento as date)))
		

		END

		IF(@id_tipo_domiciliacion=1)
		BEGIN    

		--ptmos por dia especifico de pago
		select * from #DOMIILIACIONES  d
		where (por_dia_especifico_de_pago=1) 
		and DAY(@fecha)=CASE WHEN dia_pago>DAY(EOMONTH(@fecha)) AND day(@fecha)=DAY(EOMONTH(@fecha)) then DAY(@fecha) else dia_pago end 
		and (indefinido=1  or (con_vigencia=1 and  cast(@fecha as date)<=cast(fecha_vencimiento as date))) and id_tipo_domiciliacion=1

		union

		---prestamos por fecha limite de pago
		select *from #DOMIILIACIONES  d 
		where id_tipo_domiciliacion=1 and por_dia_limite_de_pago=1
		and cast(HAPE.dbo.FN_OBTENER_FECHA_LIMITE_PAGO(d.num_ptmo,id_mov,numero_socio,Id_Esquema,1) as date)=CAST(@fecha AS date)
		and id_tipo_domiciliacion=1	and (indefinido=1 or (con_vigencia=1 and cast(@fecha as date)<=cast(fecha_vencimiento as date)))

		END

		end

		----consultamos los pendientes
		if(@pendiente=1)
		begin

		select fecha_pago_domiciliado fecha_pago,
		case when coalesce(d.por_monto_requerido,0)=0 then coalesce(p.monto,0) - coalesce(p.monto_pagado,0) else p.monto end monto ,
		d.*
		from TBL_BANCA_PAGOS_DOMICILIADOS p
		join #DOMIILIACIONES d on p.id_domiciliacion=d.id_domiciliacion
		where id_estatus_pago_banca=1 and d.id_tipo_domiciliacion=@id_tipo_domiciliacion

		end

		DROP TABLE #DOMIILIACIONES
	
	  
	end -- procedimiento
go

grant exec on SP_BANCA_OBTENER_PAGOS_DOMICILIADOS to public

go

use BANCA
go

-- se crea procedimiento SP_BANCA_INSERTA_PAGO_DOMICILIADO
if exists (select * from sysobjects where name like 'SP_BANCA_INSERTA_PAGO_DOMICILIADO' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_INSERTA_PAGO_DOMICILIADO
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20200720
Objetivo		Insertar el pago domiciliado y el estatus
Proyecto		Domiciliacion
Ticket			ticket

*/

create proc

	SP_BANCA_INSERTA_PAGO_DOMICILIADO
	
	@id_domiciliacion bigint,
	@id_banca_folio	bigint=null,
	@fecha_pago_domiciliado	datetime,
	@numero_autorizacion_servicio	varchar(50)=null,
	@clabe_corresponsalias_retiro	varchar(20),
	@clabe_corresponsalias_deposito	varchar(20)=null,
	@id_producto	int,
	@id_servicio	int,
	@numero_referencias varchar(150)=null,
	@monto decimal(18,2),
	@id_tipo_domiciliacion int,
	@id_estatus_gesto_pago	varchar(100)=null,
	@id_estatus_pago_banca	int,
	@decripcion_mensaje_pago	varchar(1000)=null,
	@telefono varchar(20)=null,
	@monto_pagado money=null,
	@numero_socio int=null,
	@id_mov_retiro int=null,
	@tipoOrigen int=null
	

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio

				-- declaraciones
				declare @status int = 200,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@id_pago_domiciliado bigint,
						@id_tipo_bitacora int=0,
						@id_tipo_bitacora_retiro int
												

			
			end -- inicio
			
			begin -- validaciones
			
				print '[aqu� se realizan las validaciones]'

				-- -- se realiza la validaci�n 1 = 0
				-- if 1 = 0
				-- 	raiserror('1 igual a 0', 11, 0)
				
			end -- validaciones
			
			begin -- preparaci�n
			
				print '[aqu� van la preparaci�n previa que sea necesaria antes de actualizar]'
			
			end -- preparaci�n
			
			begin -- �mbito de la actualizaci�n

			    IF NOT EXISTS(SELECT 1 FROM TBL_BANCA_PAGOS_DOMICILIADOS WHERE id_domiciliacion=@id_domiciliacion and cast(fecha_pago_domiciliado as date)=cast(@fecha_pago_domiciliado as date))
			    begin

				INSERT INTO TBL_BANCA_PAGOS_DOMICILIADOS(id_domiciliacion,id_banca_folio,fecha_pago_domiciliado,
				numero_autorizacion_servicio,clabe_corresponsalias_retiro,clabe_corresponsalias_deposito,id_producto,id_servicio,numero_referencias,
				monto,id_estatus_gesto_pago,id_estatus_pago_banca,decripcion_mensaje_pago,fecha_aplicacion,id_tipo_domiciliacion,telefono,monto_pagado)
				VALUES (@id_domiciliacion,@id_banca_folio,@fecha_pago_domiciliado,
				@numero_autorizacion_servicio,@clabe_corresponsalias_retiro,@clabe_corresponsalias_deposito,@id_producto,@id_servicio,
				@numero_referencias,@monto,@id_estatus_gesto_pago,@id_estatus_pago_banca,@decripcion_mensaje_pago,case when @id_estatus_gesto_pago=2 then GETDATE() else null end,@id_tipo_domiciliacion,@telefono,@monto_pagado)
			   
			    select @id_pago_domiciliado=MAX(id_pago_domiciliado) from TBL_BANCA_PAGOS_DOMICILIADOS where id_domiciliacion=@id_domiciliacion

			    UPDATE TBL_BANCA_DOMICILIACIONES set fecha_ultimo_pago=@fecha_pago_domiciliado where id_domiciliacion=@id_domiciliacion 

			    end
				
				else
				begin

				select @id_pago_domiciliado=id_pago_domiciliado FROM TBL_BANCA_PAGOS_DOMICILIADOS WHERE id_domiciliacion=@id_domiciliacion and cast(fecha_pago_domiciliado as date)=cast(@fecha_pago_domiciliado as date)

				UPDATE TBL_BANCA_PAGOS_DOMICILIADOS set id_estatus_pago_banca=@id_estatus_pago_banca, fecha_aplicacion=case when @id_estatus_pago_banca=2 then GETDATE() else null end,
				monto_pagado=coalesce(monto_pagado,0) + coalesce(@monto_pagado,0)
				where id_domiciliacion=@id_domiciliacion and cast(fecha_pago_domiciliado as date)=cast(@fecha_pago_domiciliado as date)
				
				end 

				INSERT INTO TBL_BANCA_HISTORIAL_PAGOS_DOMICILIADOS(id_pago_domiciliado,id_banca_folio,fecha_alta,numero_autorizacion_servicio,
				clabe_corresponsalias_retiro,clabe_corresponsalias_deposito,id_producto,id_servicio,numero_referencia,monto,monto_pagado,id_estatus_gesto_pago,id_estatus_pago_banca,
				decripcion_mensaje_pago,id_tipo_domiciliacion,id_domiciliacion,telefono)
				values(@id_pago_domiciliado,@id_banca_folio,GETDATE(),@numero_autorizacion_servicio,
				@clabe_corresponsalias_retiro,@clabe_corresponsalias_deposito,@id_producto,@id_servicio,@numero_referencias,@monto,@monto_pagado,@id_estatus_gesto_pago,@id_estatus_pago_banca,
				@decripcion_mensaje_pago,@id_tipo_domiciliacion,@id_domiciliacion,@telefono)

				---Bit�cotas
				begin

				--pago de servicio domiciliado exitoso 
				if(@id_tipo_domiciliacion=3) and (@id_estatus_pago_banca=2)
				    select @id_tipo_bitacora=25
				--pago de servicio domiciliado rechazado
				if(@id_tipo_domiciliacion=3) and (@id_estatus_pago_banca!=2)
					select @id_tipo_bitacora=101

				--pago de ptmo domiciliado exitoso
				if((@id_tipo_domiciliacion=1) and ((@id_estatus_pago_banca=2) or (@id_estatus_pago_banca=1 and @monto_pagado>0)))
					select @id_tipo_bitacora=102
				--pago de ptmo domiciliado rechazado
				if(@id_tipo_domiciliacion=1) and (@id_estatus_pago_banca!=2) and @monto_pagado=0
					select @id_tipo_bitacora=103
                
				IF(@id_tipo_bitacora>0)
				BEGIN
					insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
					values(@id_Banca_Folio, @id_tipo_bitacora, @numero_socio, getdate(), @tipoOrigen)

					--insertamos los retiros de las cuentas de haberes
					if(coalesce(@monto_pagado,0)>0)
					begin
						---bitacora para indicar de donde se realizo el retiro de dinero
						select @id_tipo_bitacora_retiro = case
							when @id_mov_retiro = 100 then 52
							when @id_mov_retiro = 103 then 51
							when @id_mov_retiro = 112 then 53
						end

						insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
						values(@id_Banca_Folio, @id_tipo_bitacora_retiro, @numero_socio, getdate(), @tipoOrigen)
					end
				END

				end
				

			end -- �mbito de la actualizaci�n

		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
		
		end catch -- catch principal
		
		begin -- reporte de estatus

			select	@status estatus,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message mensaje,
					@id_tipo_bitacora id_tipo_bitacora
					
		end -- reporte de estatus
		
	end -- procedimiento
	
go

grant exec on SP_BANCA_INSERTA_PAGO_DOMICILIADO to public

use BANCA
go

-- se crea procedimiento SP_BANCA_ALTA_DOMICILIACION
if exists (select * from sysobjects where name like 'SP_BANCA_ALTA_DOMICILIACION' and xtype = 'p' and db_name() = 'BANCA')
	drop proc SP_BANCA_ALTA_DOMICILIACION
go

/*

Autor			Jessica Almonte Acosta
UsuarioRed		aoaj720209
Fecha			20200611
Objetivo		Regitrar o editar la domiciliaci�n
Proyecto		CMV FINANZAS
Ticket			ticket

*/

create proc

	SP_BANCA_ALTA_DOMICILIACION
	
	@numero_socio bigint,
	@alias	varchar(500),
	@id_tipo_domiciliacion int,
	@clabe_corresponsalias_retiro varchar(20),
	@id_origen_operacion int,
	@indefinido	bit,
	@clabe_corresponsalias_deposito	varchar(20)=null,
	@id_domiciliacion bigint=null,	
	@id_producto	int	=null,
	@id_periodicidad_pago int=null,
	@fecha_vencimiento	datetime=null,
	@monto_maximo float=null,	
	@dia_pago	int=null,	
	@id_servicio int=null,
	@numero_referencia	varchar	(150)=null,	
	@monto float=null,
	@con_vigencia bit,
	@por_periodicidad bit,
	@por_dia_pago bit,
	@por_dia_especifico_de_pago bit,
	@por_dia_limite_de_pago bit,
	@por_monto_requerido bit,
	@por_monto_fijo bit,
	@telefono varchar(20)=null

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@estatus int = 1000,
						@mensaje_validacion varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',						
						@num_ptmo varchar(20),
						@idTipoBloqueo int,
						@id_mov int,
						@id_banca_folio bigint,
						@fecha_limite_pago datetime,
						@fechaOperacion datetime
						
				declare	@tran_name varchar(32) = 'DOMICILIACION',
						@tran_count int = @@trancount,
						@tran_scope bit = 0					
			
			end -- inicio
			
			begin -- validaciones

			    select @fechaOperacion=getdate()
			
				select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@numero_socio,1)

				if(@mensaje_validacion!=null)
					raiserror(@mensaje_validacion, 11, 0)

				SELECT @estatus=362,@mensaje_validacion='Por el momento no se puede domiciliar' 
					raiserror(@mensaje_validacion, 11, 0)

				if not exists((SELECT * FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE CUENTA = @clabe_corresponsalias_retiro))
				begin 
					SELECT @estatus=362,@mensaje_validacion='No existe clabe corresponsal�as de retiro' 
					raiserror(@mensaje_validacion, 11, 0)
				end

				if exists((SELECT * FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE CUENTA = @clabe_corresponsalias_retiro and NUMERO!=@numero_socio))
				begin 
					SELECT @estatus=381,@mensaje_validacion='Clabe corresponsal�as de retiro no est� asociada al socio' 
					raiserror(@mensaje_validacion, 11, 0)
				end

				if not exists((SELECT * FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE CUENTA = @clabe_corresponsalias_retiro and ID_MOV in (100,103,112) ))
				begin 
					SELECT @estatus=379,@mensaje_validacion='Clabe corresponsal�as de retiro no est� asociada a una cuenta de haberes' 
					raiserror(@mensaje_validacion, 11, 0)
				end

				if(coalesce(@con_vigencia,0)=1 and cast(@fecha_vencimiento as date)<= cast(GETDATE() as date) )
				begin
					    SELECT @estatus=335,@mensaje_validacion='La fecha de vigencia debe ser mayor a la fecha actual' 
						raiserror(@mensaje_validacion, 11, 0)
				end

				if(@id_tipo_domiciliacion=1)
				begin
				
					if not exists((SELECT 1 FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE CUENTA = @clabe_corresponsalias_deposito))
					begin 
						SELECT @estatus=362,@mensaje_validacion='No existe clabe corresponsal�as de deposito' 
						raiserror(@mensaje_validacion, 11, 0)
					end

					if exists((SELECT 1 FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE CUENTA = @clabe_corresponsalias_deposito and NUMERO!=@numero_socio))
					begin 
						SELECT @estatus=381,@mensaje_validacion='Clabe corresponsal�as de deposito no est� asociada al socio' 
						raiserror(@mensaje_validacion, 11, 0)
					end

					if not exists((SELECT 1 FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE CUENTA = @clabe_corresponsalias_deposito and ID_MOV in (select Id_mov from HAPE..TIPOS_DE_OPERACIONES where id_tipo_cuenta=2)))
					begin 
						SELECT @estatus=359,@mensaje_validacion='Clabe corresponsal�as no est� asociada a un pr�stamo' 
						raiserror(@mensaje_validacion, 11, 0)
					end

					if(coalesce(@por_dia_limite_de_pago,0)=0 and coalesce(@por_dia_especifico_de_pago,0)=0)
					begin
					    SELECT @estatus=335,@mensaje_validacion='Debe de seleccionar si es por dia limite de pago o por dia especifico de pago' 
						raiserror(@mensaje_validacion, 11, 0)
					end

                    if(coalesce(@por_dia_especifico_de_pago,0)=1 and coalesce(@dia_pago,0)=0)
					begin
					    SELECT @estatus=335,@mensaje_validacion='Debe de especificar el dia de pago' 
						raiserror(@mensaje_validacion, 11, 0)
					end

					if(coalesce(@por_monto_requerido,0)=0 and coalesce(@por_monto_fijo,0)=0)
					begin
					    SELECT @estatus=335,@mensaje_validacion='Debe de seleccionar si es por monto requerido o por monto fijo' 
						raiserror(@mensaje_validacion, 11, 0)
					end

					if(coalesce(@por_monto_fijo,0)=0 and coalesce(@monto,0)=0)
					begin
					    SELECT @estatus=335,@mensaje_validacion='Debe de especificar el monto fijo' 
						raiserror(@mensaje_validacion, 11, 0)
					end

					if(coalesce(@por_dia_especifico_de_pago,0)=1 and coalesce(@dia_pago,0)=0)
					begin
					    SELECT @estatus=335,@mensaje_validacion='Debe de especificar el dia de pago' 
						raiserror(@mensaje_validacion, 11, 0)
					end

					 --obtenemos el num_ptmo
				   select @num_ptmo=num_ptmo,@id_mov=ID_MOV from HAPE..TBL_CORRESPONSALIAS_CUENTAS where NUMERO=@numero_socio and CUENTA = @clabe_corresponsalias_deposito
				
					if ((not exists(select 1 from HAPE..EDO_DE_CUENTA where Numero=@numero_socio and Num_ptmo=@num_ptmo and Saldo_Actual>0)) and
					   (not exists(select 1 from HAPE..TBL_REVOLVENTE_LINEAS_CREDITO where numero=@numero_socio and num_ptmo=@num_ptmo and saldo_Actual>0)))
					begin
					    SELECT @estatus=335,@mensaje_validacion='El prest�mo no existe' 
						raiserror(@mensaje_validacion, 11, 0)
					end

					
					select @idTipoBloqueo = id_tipo_bloqueo	 from hape.dbo.FN_COB_OBTIENE_BLOQUEOS_PTMO (@numero_socio , @id_mov)
				 
					if @idTipoBloqueo = 3 --el prestamo se encuentra en Cobro Legal y cualquier pago es liquidacion
					begin				
						
						SELECT @estatus=id_excepcion,@mensaje_validacion=descripcion 
						FROM CAT_BANCA_EXCEPTIONS
						WHERE id_excepcion = 399
						raiserror(@mensaje_validacion, 11, 0)

					end

					if(@id_mov=10)
					  select @fecha_limite_pago=HAPE.DBO.FN_OBTENER_FECHA_LIMITE_PAGO(Num_ptmo,10,Numero,4,1)
					  from hape..TBL_REVOLVENTE_LINEAS_CREDITO where numero=@numero_socio and num_ptmo=@num_ptmo and Saldo_Actual>0
				   else
				      select @fecha_limite_pago=HAPE.DBO.FN_OBTENER_FECHA_LIMITE_PAGO(Num_ptmo,Id_mov,Numero,Id_Esquema,1)
					  from hape..EDO_DE_CUENTA where numero=@numero_socio and Num_ptmo=@num_ptmo and Saldo_Actual>0
			 
					if(coalesce(@por_dia_especifico_de_pago,0)=1 and @dia_pago>day(@fecha_limite_pago))
					begin
					    SELECT @estatus=335,@mensaje_validacion='El d�a especifico de pago no debe de ser mayor al dia limite de pago' 
						raiserror(@mensaje_validacion, 11, 0)
					end

					if(coalesce(@con_vigencia,0)=1 and cast(@fecha_vencimiento as date)> cast((select HAPE.DBO.FN_OBTENER_FECHA_venc_ptmo(@numero_socio,@id_mov)) as date) )
					begin
					    SELECT @estatus=335,@mensaje_validacion='La fecha de vigencia no debe de ser mayor a la fecha de vencimiento del prest�mo' 
						raiserror(@mensaje_validacion, 11, 0)
					end

					if(@id_mov=10) and exists(select 1 from HAPE..tbl_revolvente_lineas_credito where Numero=@numero_socio
					and interes_ordinario_diferido is not null and cast(@fechaOperacion as date)>=cast(inicio_periodo_gracia as date) and cast(@fechaOperacion as date)<=cast(fin_periodo_gracia as date)
					)
					begin
							select @estatus = 408, @mensaje_validacion  = 'Por el momento no se puede domiciliar este pr�stamo, ya que se encuentra en periodo de gracia.'
							raiserror (@mensaje_validacion, 11, 0)
					end

					--Modificaci�n COVIDFase3 se valida que el socio no se encuentre en periodo de gracia con interes diferido
					if (@id_mov!=10) and exists(select 1 from HAPE..EDO_DE_CUENTA where Numero=@numero_socio and Id_mov=@id_mov and Saldo_Actual>0 
					and interes_ordinario_diferido is not null and cast(@fechaOperacion as date)>=cast(inicio_periodo_gracia as date) and cast(@fechaOperacion as date)<=cast(fin_periodo_gracia as date))
					begin
							select @estatus = 408, @mensaje_validacion  = 'Por el momento no se puede domiciliar este pr�stamo, ya que se encuentra en periodo de gracia.'
							raiserror (@mensaje_validacion, 11, 0)
					end

					--Modifaci�n para ptmos con interes diferidos
					if(@id_mov=10) and exists(select 1 from HAPE..tbl_revolvente_lineas_credito where Numero=@numero_socio	and coalesce(interes_ordinario_diferido,0)>0)
					begin
							select @estatus = 408, @mensaje_validacion  = 'Este prestamo no se puede domiciliar, ya que cuenta con intereses diferidos.'
							raiserror (@mensaje_validacion, 11, 0)
					end

					--Modificaci�n COVIDFase3 se valida que el socio no se encuentre en periodo de gracia con interes diferido
					if (@id_mov!=10) and exists(select 1 from HAPE..EDO_DE_CUENTA where Numero=@numero_socio and Id_mov=@id_mov and Saldo_Actual>0  and coalesce(interes_ordinario_diferido,0)>0)
					begin
							select @estatus = 408, @mensaje_validacion  = 'Este prestamo no se puede domiciliar, ya que cuenta con intereses diferidos.'
							raiserror (@mensaje_validacion, 11, 0)
					end

					if exists(select 1 from TBL_BANCA_DOMICILIACIONES where clabe_corresponsalias_deposito=@clabe_corresponsalias_deposito and id_tipo_domiciliacion=@id_tipo_domiciliacion and coalesce(@id_domiciliacion,0)=0 and activo=1)
					begin 
						SELECT @estatus=320,@mensaje_validacion='El prest�mo ya se encuentra domiciliado' 
						raiserror(@mensaje_validacion, 11, 0)
					end


				end

				if(@id_tipo_domiciliacion=3)
				begin

					if not exists(select * from CAT_BANCA_SERVICIOS_PAGO where id_servicios_pago=@id_servicio and activo=1)
					begin
						SELECT @estatus=335,@mensaje_validacion='El servicio que desea domiciliar no existe' 
						raiserror(@mensaje_validacion, 11, 0)
					end

					if not exists(select * from CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO where id_servicios_pago=@id_servicio and id_producto=@id_producto and activo=1)
					begin
						SELECT @estatus=335,@mensaje_validacion='El servicio que desea domiciliar no existe o no se encuentra activo' 
						raiserror(@mensaje_validacion, 11, 0)
					end

					if(@por_periodicidad=1) and (@id_periodicidad_pago is null)
					begin
						SELECT @estatus=335,@mensaje_validacion='Debe de especificar la periodicidad de pago' 
						raiserror(@mensaje_validacion, 11, 0)
					end

					if exists(select 1 from TBL_BANCA_DOMICILIACIONES where id_tipo_domiciliacion=@id_tipo_domiciliacion and coalesce(numero_referencia,'')=coalesce(@numero_referencia,'') and id_servicio=@id_servicio and id_producto=@id_producto and coalesce(@id_domiciliacion,0)=0 and activo=1)
					begin 
						SELECT @estatus=320,@mensaje_validacion='El servicio ya se encuentra domiciliado' 
						raiserror(@mensaje_validacion, 11, 0)
					end
				end

			
			end -- validaciones

			begin
				CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500))
			end
			
			begin -- transacci�n

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio
				
				begin -- componente de la transacci�n
				  
					IF(COALESCE(@id_domiciliacion,0)=0)
					BEGIN

						INSERT INTO TBL_BANCA_FOLIOS 
						(
							numero_socio,
							fecha_alta
						) 
						values 
						(
							@numero_socio,
							GETDATE()
						)

				        select @id_banca_folio = max(id_banca_folio)from TBL_BANCA_FOLIOS where numero_socio = @numero_socio

						INSERT INTO TBL_BANCA_DOMICILIACIONES(
						id_tipo_domiciliacion,
						id_producto,
						id_periodicidad_pago,
						fecha_vencimiento,
						--monto_maximo,
						indefinido,
						fecha_alta,
						clabe_corresponsalias_retiro,
						clabe_corresponsalias_deposito,
						id_servicio,
						numero_referencia,
						alias,
						numero_socio,
						activo,
						monto,
						con_vigencia,
						por_periodicidad,
						--por_dia_pago,
						num_ptmo,
						por_dia_especifico_de_pago,
						por_dia_limite_de_pago,
						por_monto_requerido,
						por_monto_fijo,
						dia_pago,
						telefono,
						id_mov,
						folio_autorizacion
						)
						SELECT 
						@id_tipo_domiciliacion,
						@id_producto,
						@id_periodicidad_pago,
						@fecha_vencimiento,
						--@monto_maximo,
						@indefinido,
						GETDATE(),
						@clabe_corresponsalias_retiro,
						@clabe_corresponsalias_deposito,
						@id_servicio,
						@numero_referencia,
						@alias,
						BANCA.dbo.FN_BANCA_CIFRAR(@numero_socio),
						1 Activo,
						case when @id_tipo_domiciliacion=3 then @monto_maximo  else @monto end monto,
						@con_vigencia,
						@por_periodicidad,						
						@num_ptmo,
						case when @id_tipo_domiciliacion=3 then @por_dia_pago else @por_dia_especifico_de_pago end por_dia_especifico_de_pago,
						@por_dia_limite_de_pago,
						@por_monto_requerido,
						@por_monto_fijo,
						@dia_pago,
						@telefono,
						@id_mov,
						@id_banca_folio


						INSERT INTO #Bitacora
						EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_socio, 28, @id_origen_operacion
	
						--OBTENER EL DETALLE DE LA DOMICILIACION PARA PODER GENERAR EL PDF
						SELECT @id_domiciliacion =  MAX(id_domiciliacion) FROM TBL_BANCA_DOMICILIACIONES  WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)=@numero_socio

						SELECT @ESTATUS=200
					END
					ELSE
					BEGIN

						UPDATE TBL_BANCA_DOMICILIACIONES set
						id_producto=@id_producto,
						id_periodicidad_pago=@id_periodicidad_pago,
						fecha_vencimiento=@fecha_vencimiento,
						--monto_maximo=@monto_maximo,
						indefinido=@indefinido,
						clabe_corresponsalias_retiro=@clabe_corresponsalias_retiro,
						id_servicio=@id_servicio,
						numero_referencia=@numero_referencia,
						alias=@alias,						
						monto=case when @id_tipo_domiciliacion=3 then @monto_maximo  else @monto end,
						con_vigencia=@con_vigencia,
						por_periodicidad=@por_periodicidad,
						--por_dia_pago=@por_dia_pago,
						por_dia_especifico_de_pago=case when @id_tipo_domiciliacion=3 then @por_dia_pago else @por_dia_especifico_de_pago end,
						por_dia_limite_de_pago=@por_dia_limite_de_pago,
						por_monto_requerido=@por_monto_requerido,
						por_monto_fijo=@por_monto_fijo,
						dia_pago=@dia_pago,
						telefono=@telefono
						WHERE id_domiciliacion=@id_domiciliacion

						INSERT INTO #Bitacora
						EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_socio, 100, @id_origen_operacion
	

						SELECT @ESTATUS=200


					END


				end -- componente de la transacci�n
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@estatus = 1000,
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					--@mensaje_validacion = 'Error desconocido',
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
						
			-- revertir transacci�n si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
		
		end catch -- catch principal
		
		begin -- reporte de status
		
			select	@estatus estatus,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@mensaje_validacion mensaje,
					@id_domiciliacion  id_domiciliacion     

				
		end -- reporte de status
		
	end -- procedimiento
go

grant exec on SP_BANCA_ALTA_DOMICILIACION to public

