use BANCA
go

update cat_banca_tipos_bitacora set descripcion = 'Pago de servicio domiciliado' where id_tipo_bitacora = 25
--update cat_banca_tipos_bitacora set descripcion = 'Domiciliaci�n actualizada' where id_tipo_bitacora = 100

if not exists(select 1 from cat_banca_tipos_bitacora where descripcion = 'Domiciliaci�n actualizada')
begin
	insert into cat_banca_tipos_bitacora (descripcion)values('Domiciliaci�n actualizada')
end

if not exists(select 1 from cat_banca_tipos_bitacora where descripcion = 'Pago de servicio domiciliado rechazado')
begin
	insert into cat_banca_tipos_bitacora (descripcion)
	values('Pago de servicio domiciliado rechazado')
end

if not exists(select 1 from cat_banca_tipos_bitacora where descripcion = 'Pago de pr�stamo domiciliado')
begin
	insert into cat_banca_tipos_bitacora (descripcion)
	values('Pago de pr�stamo domiciliado')
end

if not exists(select 1 from cat_banca_tipos_bitacora where descripcion = 'Pago de pr�stamo domiciliado rechazado')
begin
	insert into cat_banca_tipos_bitacora (descripcion)
	values('Pago de pr�stamo domiciliado rechazado')
end

if not exists(select 1 from cat_banca_tipos_bitacora where descripcion = 'Pago de servicio domiciliado rechazado')
begin
	insert into cat_banca_tipos_bitacora (descripcion)
	values('Pago de servicio domiciliado rechazado')
end

if not exists(select 1 from cat_banca_tipos_bitacora where descripcion = 'Registro de Aclaraci�n por Domiciliaci�n')
begin
	insert into cat_banca_tipos_bitacora (descripcion)
	values('Registro de Aclaraci�n por Domiciliaci�n')
end

UPDATE 	P SET frecuente_domiciliado=1
from 
	banca..CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO P
join BANCA..CAT_BANCA_SERVICIOS_PAGO s on P.id_servicios_pago=s.id_servicios_pago
where 
	p.activo = 1  and s.activo=1
and 
	tipo_front not in (4)
and P.id_servicios_pago in (select id_servicios_pago from banca..CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO  where tipo_front=4 and activo=1)
and p.id_producto in(190,271,597,598,215)



