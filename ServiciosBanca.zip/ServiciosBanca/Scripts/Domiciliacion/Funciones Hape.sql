USE[HAPE]
GO

IF object_id('FN_OBTENER_SALDO_DISPONIBLE_CTA_HABER') IS NOT NULL
BEGIN
       DROP FUNCTION [dbo].[FN_OBTENER_SALDO_DISPONIBLE_CTA_HABER]
END
GO

CREATE FUNCTION [dbo].[FN_OBTENER_SALDO_DISPONIBLE_CTA_HABER]
(
    @numero bigint,
	@id_mov int,
	@id_tipo_persona int
)
RETURNS MONEY
AS
BEGIN

    declare @saldo_disponible money,@ahorro_base money

	select @saldo_disponible=saldo_actual from hape..edo_de_cuenta where numero=@numero and id_mov=@id_mov and Id_Tipo_persona = @id_tipo_persona

	if @id_mov = 100
	begin

		select	@ahorro_base = sum(ahorro_base)
		from	(
				select	ahorro_base = cast(coalesce(ahorro_base, 0) as money)
				from	hape.dbo.edo_de_cuenta
				where	numero = @numero
						and id_mov < 100
						and saldo_actual > 0
				) _

		select @ahorro_base = coalesce(@ahorro_base, 0)

		if @ahorro_base > 0

			select @saldo_disponible -= @ahorro_base

		if @saldo_disponible < 0

			select @saldo_disponible = 0

	end


    RETURN coalesce(@saldo_disponible, 0)

END
go


USE[HAPE]
go

IF object_id('FN_OBTENER_FECHA_VENC_PTMO') IS NOT NULL
BEGIN
       DROP FUNCTION [dbo].[FN_OBTENER_FECHA_VENC_PTMO]
END
GO

CREATE FUNCTION [dbo].[FN_OBTENER_FECHA_VENC_PTMO]
(
   @numero BIGINT,
   @id_mov int
)
RETURNS DATE
AS
BEGIN

	declare @num_ptmo varchar(20),
	@fecha_fin date,
	@id_linea int,
	@id_esquema int,
	@version int

	
	if(@id_mov=10)
		 select @num_ptmo=num_ptmo,
		 @id_linea=id_linea,
		 @id_esquema=4
		 from tbl_revolvente_lineas_credito where numero=@numero and saldo_actual>0
	else
		  select @num_ptmo=num_ptmo,@id_esquema=id_esquema
		  from edo_de_cuenta where numero=@numero and id_mov=@id_mov and saldo_actual>0

	if(@id_mov=10)
	begin
		 SELECT @fecha_fin=MAX(FECHA_LIMITE) FROM [dbo].[TBL_REVOLVENTE_CICLOS_FACTURACION] c
		 join [dbo].[TBL_REVOLVENTE_DISPOSICIONES] d on c.id_disposicion=d.id_disposicion
		 where id_linea=@id_linea
	end
	else
	begin

		if (@id_esquema=1)
		begin 

			select @version=min(version_Calendario) FROM TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES
			WHERE numero=@numero and id_mov=@id_mov and num_ptmo=@num_ptmo

			select @fecha_fin=max(fecha_fin) from TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES
			WHERE version_calendario=@version and numero=@numero and id_mov=@id_mov and num_ptmo=@num_ptmo

		end
		else
		begin
			select @fecha_fin=fecha FROM(
				select max(Fecha_pago) fecha from tbl_automotriz_ptmos
				where numero=@numero and id_mov=@id_mov and Num_ptmo=@num_ptmo
				union
				select max(Fecha_pago) fecha from TBL_HIPOTECARIO_PTMOS
				where numero=@numero and id_mov=@id_mov and Num_ptmo=@num_ptmo
				union
				select max(Fecha_pago) fecha from tbl_nivelados_ptmos
				where numero=@numero and id_mov=@id_mov and Num_ptmo=@num_ptmo)
				fechas
		end
	end

RETURN @fecha_fin  

END
go

USE[HAPE]
go

--DROP FUNCTION [dbo].[FN_OBTENER_FECHA_LIMITE_PAGO]
--go

IF object_id('FN_OBTENER_FECHA_LIMITE_PAGO') IS NOT NULL
BEGIN
       DROP FUNCTION [dbo].[FN_OBTENER_FECHA_LIMITE_PAGO]
END
GO

CREATE FUNCTION [dbo].[FN_OBTENER_FECHA_LIMITE_PAGO]
(
    @numPtmo varchar(20),
	@idMov int,
	@numero bigint,
	@idEsquema int,
	@idTipoConsulta int --1 fecha limite pago,2--montoRequerido,3--fecha corte
)
RETURNS varchar(100)
AS
BEGIN

    declare @fecha_limite_pago date,@fecha_actual date,@monto_requerido money=0,@interes_ord money,@result varchar(100),
	@aplica_IVA bit,@tasa_iva decimal(7, 4),@saldo_actual money,@int_ord float

	select @fecha_actual=GETDATE()
	select @tasa_iva = (select tasa from tasas where contador in (select max(contador) from tasas where id_mov = 111))
		

	if(@idMov=10) --revolvente
	begin 

	--calculamos la fecha limite de pago o la fecha corte
	if(@idTipoConsulta in (1,3))
	begin

	 declare @dia_limite int,@fecha date

	 SELECT @dia_limite=case when @idTipoConsulta=3 then dia_corte else dia_limite end
	 FROM tbl_revolvente_lineas_credito where numero=@numero

	 if(DAY(@fecha_actual)<=@dia_limite)
		select @fecha=@fecha_actual
	else
		select @fecha=DATEADD(MONTH,1,@fecha_actual)

	select @fecha_limite_pago=cast(YEAR(@fecha) as varchar) + case when MONTH(@fecha)<10 then '0' else '' end +  cast(MONTH(@fecha) as varchar) + case when @dia_limite<10 then '0' else '' end + cast(@dia_limite as varchar)
	
	end

	---calcumalos el monto requerido
	if(@idTipoConsulta=2)
	begin

		SELECT @monto_requerido=SUM(C.capital) 
		FROM TBL_REVOLVENTE_CICLOS_FACTURACION  C
		JOIN(
		select MIN(id_ciclo) id_ciclo 
		from TBL_REVOLVENTE_LINEAS_CREDITO l
		join TBL_REVOLVENTE_DISPOSICIONES d on l.id_linea=d.id_linea
		join TBL_REVOLVENTE_CICLOS_FACTURACION  c on d.id_disposicion=c.id_disposicion
		where capital>0 and cast(fecha_limite as date)>=cast(getdate() as date) and numero=@numero
		group by c.id_disposicion ) pago on C.id_ciclo=pago.id_ciclo


	  if(coalesce(@monto_requerido,0)=0) 
		select @monto_requerido=saldo_actual from TBL_REVOLVENTE_LINEAS_CREDITO where Numero=@numero

	 select @interes_ord=(coalesce(int_ord_dia_balance,0) + coalesce(int_ord_dia_orden,0)) from TBL_DECLARACION_CARTERA where Numero=@numero and Id_mov=@idMov and Num_ptmo=@numPtmo

	 select @monto_requerido=@monto_requerido + coalesce((@interes_ord * 30),0) + round((coalesce((@interes_ord * 30),0))* (@tasa_iva/100), 2)

	end


	end
    else if(@idEsquema=1)--decreciente
	begin

	select @aplica_IVA=aplica_IVA,@saldo_actual=saldo_actual,@int_ord=case when int_ord=0 then coalesce(tasa_original_periodo_gracia,0) else int_ord end from EDO_DE_CUENTA where Numero=@numero and Id_mov=@idMov and Num_ptmo=@numPtmo

	declare @version int

	select @version = max(version_calendario) 
						FROM TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES
						where numero = @numero 
						and id_mov = @idMov 
						and num_ptmo = @numPtmo

	select top 1 @fecha_limite_pago=fecha_fin,@monto_requerido=capital_actual
							FROM TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES
							where numero = @numero 
							and id_mov = @idMov 
							and num_ptmo = @numPtmo					
							and capital_actual > 0
							and version_calendario = @version
							and cast(fecha_fin as date)>=cast(@fecha_actual as date)
							order by fecha_fin asc

	if(@fecha_limite_pago is null) and (@idTipoConsulta in(1,3))
	begin

		select @fecha_limite_pago=MAX(fecha_fin)
							FROM TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES
							where numero = @numero 
							and id_mov = @idMov 
							and num_ptmo = @numPtmo					
							and capital_actual > 0
							and version_calendario = @version							

	end

	---calcumalos el monto requerido
	if(@idTipoConsulta=2)
	begin

	  if(coalesce(@monto_requerido,0)=0) 
		select @monto_requerido=@saldo_actual

	 --select @interes_ord_dia=(coalesce(int_ord_dia_balance,0) + coalesce(int_ord_dia_orden,0)) from TBL_DECLARACION_CARTERA where Numero=@numero and Id_mov=@idMov and Num_ptmo=@numPtmo
	 select @interes_ord=round((@saldo_actual*30*(@int_ord/3000)),2,0)
	 select @monto_requerido=@monto_requerido + coalesce(@interes_ord,0) + case when @aplica_IVA=1 then round((@interes_ord)* (@tasa_iva/100), 2) else 0 end
    end

	end
	else
	begin---nivelado

	    select top 1 @fecha_limite_pago=Fecha_pago,@monto_requerido=Total
		from (

		select top 1 fecha_pago,Capital,Total 
		from 
			hape.dbo.TBL_CREDINOMINA_PTMOS 
		where 
		numero=@numero and id_mov=@idMov and Num_ptmo=@numPtmo and id_status=1 
		and cast(Fecha_pago as date)>=cast(@fecha_actual as date)
		order by Fecha_pago

        union

		select top 1 fecha_pago,Capital,Total 
		from TBL_AUTOMOTRIZ_PTMOS
		where numero = @numero 
		and id_mov = @idMov 
		and num_ptmo = @numPtmo 
		and Id_status = 1
		and cast(Fecha_pago as date)>=cast(@fecha_actual as date)
		order by Fecha_pago

		union

		select top 1 fecha_pago,Capital,Total 
		from TBL_HIPOTECARIO_PTMOS
		where numero = @numero 
		and id_mov = @idMov 
		and num_ptmo = @numPtmo 
		and Id_status = 1
		and cast(Fecha_pago as date)>=cast(@fecha_actual as date)
		order by Fecha_pago

		union

		select top 1 fecha_pago,Capital,Total  
		from TBL_NIVELADOS_PTMOS
		where numero = @numero 
		and id_mov = @idMov 
		and num_ptmo = @numPtmo 
		and Id_status = 1
		and cast(Fecha_pago as date)>=cast(@fecha_actual as date)
		order by Fecha_pago
		) f
		where f.fecha_pago is not null
		order by f.Fecha_pago

		--se obtiene la ultima fecha del calendario
		if(@fecha_limite_pago is null) and (@idTipoConsulta in(1,3))
		begin

			   	select @fecha_limite_pago=MAX(fecha_pago)
				from (
				select MAX(Fecha_pago) fecha_pago 
				from TBL_AUTOMOTRIZ_PTMOS
				where numero = @numero 
				and id_mov = @idMov 
				and num_ptmo = @numPtmo 
				and Id_status = 1

				union

				select MAX(Fecha_pago) fecha_pago
				from TBL_HIPOTECARIO_PTMOS
				where numero = @numero 
				and id_mov = @idMov 
				and num_ptmo = @numPtmo 
				and Id_status = 1

				union

				select MAX(Fecha_pago) fecha_pago 
				from TBL_NIVELADOS_PTMOS
				where numero = @numero 
				and id_mov = @idMov 
				and num_ptmo = @numPtmo 
				and Id_status = 1
				) f
				where f.fecha_pago is not null

		end

		if(coalesce(@monto_requerido,0)=0) and (@idTipoConsulta=2)
		begin
		  select @monto_requerido=saldo_actual from EDO_DE_CUENTA where Numero=@numero and Id_mov=@idMov and Num_ptmo=@numPtmo
		end

	end
	
	if(@idTipoConsulta in(1,3)) --retornamos fecha limite de pago o la fecha corte
	select @result=@fecha_limite_pago


	if(@idTipoConsulta=2) --retornamos monto requerido
	select @result=@monto_requerido

    RETURN @result

END
