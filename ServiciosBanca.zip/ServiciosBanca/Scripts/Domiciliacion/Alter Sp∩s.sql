USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_REALIZA_PAGO_SERVICIO]    Script Date: 13/07/2020 12:17:47 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			MAXIMILIANO GONZALEZ BETANCOURT
UsuarioRed		GOBM391548
Fecha			20180417
Objetivo		OBTIENE EL CATALOGO DE PREGUNTAS PARA QUE EL SOCIO SELECCIONE UNA 
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc
	[dbo].[SP_BANCA_REALIZA_PAGO_SERVICIO]
		-- par�metros
		@ClabeCorresponsaliasRetiro varchar(20),
		@NumeroSocio varchar(10),
		@monto decimal(18,2),
		@IdProducto int ,
		@idServicio int,
		@numeroReferencia varchar(50) = null ,
		@telefono varchar (20) = null,
		@idTipoPersona int = 1,
		@idTipoFront int,
		@tipo_origen int = 3, -- banca web 
		@esConsulta bit = 0,
		@id_domiciliacion int=null

		-- [aqu� van los par�metros]
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@estatus int = 1,
						@error_message varchar(255) = '',
						@validacion varchar(255),
						@idTransferencia int,
						@SaldoActual decimal(18,2),
						@AhorroBase decimal (18,2),
						@SaldoDisponible decimal(18,2),
						@IdCuentaRetiro int,
						@mensaje_validacion varchar (100),
						@numero_int int,
						@fechaTransaccion datetime =  getDate(),
						@id_folio_banca bigint,
						@idEstatusTransfenrecia int = 1, --Pendiente por aplicar,
						@id_origen_operacion int = 3

				declare	@tran_name varchar(32) = 'REALIZA_PAGO_SERVICIO',
						@tran_count int = @@trancount,
						@tran_scope bit = 0
			
			end -- inicio

			--validaciones generales de cmv finanzas
			select @mensaje_validacion =msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@NumeroSocio,1)
			IF(@mensaje_validacion is not null)
				 raiserror (@mensaje_validacion, 11, 0)
			
			select @id_origen_operacion = case when @tipo_origen = 1 then 3 else @tipo_origen end

			set @numero_int = CAST(@NumeroSocio as int )


			IF @esConsulta = 1
			begin
			 ---- Generacion de folio de banca
				insert into BANCA..TBL_BANCA_FOLIOS (numero_socio,fecha_alta)
				values (@numero_int,@fechaTransaccion)

				select @id_folio_banca = MAX (id_banca_folio) from BANCA..TBL_BANCA_FOLIOS where
				numero_socio = @numero_int
			--=========== end Generacion de folio de banca
						
					---INSERTAMOS LA TRABSFERENCIAS REFERENTE AL PAGO 
				INSERT INTO TBL_BANCA_TRANSFERENCIAs_PAGO_SERVICIOS
					(id_producto,id_servicio,numero_socio,monto,numero_referencia,fecha_alta_pago,
					id_estatus_transferencia,id_origen,clabe_corresponsalias_retiro, telefono,id_banca_folio,id_domiciliacion)
				VALUES(@idProducto,@idServicio,BANCA.dbo.FN_BANCA_CIFRAR(@numeroSocio),@monto,@numeroReferencia,GETDATE(),@idEstatusTransfenrecia, @tipo_origen,@ClabeCorresponsaliasRetiro,@telefono, @id_folio_banca,@id_domiciliacion)

				goto RESULT

			end
			--obtener el id_mov de la cuenta de retiro
			select @IdCuentaRetiro = ID_MOV from HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE NUMERO = @numeroSocio  and CUENTA = @ClabeCorresponsaliasRetiro
			/*if (@IdCuentaRetiro is null or @IdCuentaRetiro = '')
			begin
					SELECT id_excepcion AS estatus , descripcion as mensaje 
					FROM CAT_BANCA_EXCEPTIONS
					WHERE id_excepcion =362
					return
			end*/

			
				-- obtenes el saldo actual de estado de cuenta para despues validar que no este corruto al momento de afectarlo
				select @SaldoActual = Saldo_Actual 
				from HAPE..EDO_DE_CUENTA
				where Numero = @NumeroSocio and Id_mov = @IdCuentaRetiro

				-- SE VALIDA QUE EL SALDO ACTUAL SEA MAYOR A CERO PARA PODER EFECTUAR EL MOVIMIENTO
				if @SaldoActual <= 0 --or @SaldoActual is null
				begin
					SELECT id_excepcion AS estatus , descripcion as mensaje 
					FROM CAT_BANCA_EXCEPTIONS
					WHERE id_excepcion =346
					return
				end


				--  SI EL PAGO SE QUIERE REALIZAR DESDE  SU CUENTA DE AHORRO HAY QUE VALIDAR EL AHORRO BASE
				IF(@IdCuentaRetiro = 100)
				BEGIN

					SELECT @AhorroBase = isnull(sum(isnull(Ahorro_Base,0)),0) 
					FROM HAPE..EDO_DE_CUENTA 
					WHERE  Numero = @NumeroSocio and Id_Tipo_persona = @idTipoPersona and Saldo_Actual  >0
					SET @SaldoDisponible = @SaldoActual - @AhorroBase

					  --print '@idTipoPersona: '+ cast(@idTipoPersona as varchar)
				--      print 'saldo actual: '+ cast(@SaldoActual as varchar)
				--      print '@SaldoDisponible_ '+ cast(@SaldoDisponible as varchar)
					  --print '@@AhorroBase '+ cast(@AhorroBase as varchar)

					IF @SaldoDisponible <=0 
					BEGIN
				 
						SELECT id_excepcion AS estatus , descripcion as mensaje 

						FROM CAT_BANCA_EXCEPTIONS
						WHERE id_excepcion =346
						  return
					END
				END
				ELSE -- ASIGNAMOS EL SALDO ACTUAL AL SALDO DISPONIBLE  PARA SEGUIR RELIZANDO OPERACION CUANDO LA CUENTA DE RETIRO NO ES AHORRO
					SET @SaldoDisponible = @SaldoActual
           

				-- VALIDA QUE EL MONTO DE LA OPERACION SEA MENOR AL SALDO DISPONIBLE PARA PODER EFECTUAR LA OPERACION
				if @monto > @SaldoDisponible
				begin	
					SELECT id_excepcion AS estatus , descripcion as mensaje 
					FROM CAT_BANCA_EXCEPTIONS
					WHERE id_excepcion =346
					return
				end
		 

			--===================================	VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS	===============================
				BEGIN
					declare 
						@fecha_ datetime = getdate(),
						@tipoTransferencia int
					
					select @tipoTransferencia = 7	---7.- PAGO DE SERVICIOS

					select 
						@estatus = estatus, @mensaje_validacion = msj  
					from  
						FN_VALIDAR_LIMITES_TRANSFERENCIAS_DIARIO (@tipoTransferencia,@numeroSocio,@monto,@fecha_,0)

					if @estatus <> 200
					begin
						SELECT @estatus AS estatus , @mensaje_validacion as mensaje 
						return
						--raiserror (@mensaje_validacion, 11, 0)
					end
				END ---VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS

			----------------------  QUERYS PARA EFECTUAR EL PAGO , MOVIMIENTOS , CAPTURA , ------------------------------------------------
			

			DECLARE 

				@SaldoDespuesDeOperacion decimal (18,2),
				@NumPoliza bigint  = 0000,
				@TipoPoliza varchar(1) ='D',
				@NumUsuarioBanca int = 1012 ,
				@IdPersona int,
				@IdTipoMov int,							
				@CuentaContable varchar(14) =	'',
				@CuentaContableSucursal varchar(14) =	'',
				@NomreS varchar(50),
				@ApellidoPaterno varchar(50),
				@ApellidoMaterno varchar(50),
				@TotalMovs int = 1,
				@ConceptoCaptura  varchar(1000)='',
				@DebeHaber varchar(1)='D',
				@id_bitacora int = 21, --pago de servicio
				@ccostos_socio varchar(20),
				@ccostos_compensacion varchar(20)

				-- OBTENEMOS EL ID_TIPOMOV
				if @IdCuentaRetiro = 100   -- AHORRO
					SET @IdTipoMov  = 1186
				else if @IdCuentaRetiro = 103-- INVER
					SET @IdTipoMov  = 1189
				else if @IdCuentaRetiro = 112 -- DEBITO
					SET @IdTipoMov  = 1192



				-- OBTENEMOS EL ID PERSONA
				SELECT
					@IdPersona = p.Id_Persona , 
					@NomreS = p.Nombre_s , @ApellidoPaterno =ISNULL(p.Apellido_Paterno,''), @ApellidoMaterno = ISNULL(p.Apellido_Materno,' '),
					@CuentaContableSucursal = nSuc.Num_Cuenta_Compensacion,
					@ccostos_socio = s.Ccostos
				FROM HAPE..PERSONA p
				join HAPE.dbo.sucursales s
					on s.id_de_sucursal = p.id_de_sucursal
				join HAPE..NUM_SUCURSAL nSuc 
					on s.Num_Sucursal = nSuc.Num_Sucursal
				WHERE Numero = @NumeroSocio AND Id_Tipo_Persona  = @idTipoPersona

				---Se obtiene el numero de poliza de banca
				select @NumPoliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
				select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'BANCA ELECTRONICA')
				and dia = DAY(GETDATE())

				select @ccostos_compensacion = Ccostos from HAPE..NUM_SUCURSAL
				WHERE
					Num_Sucursal = 99 --'MEDIOS DE PAGO%'

				--REGRESAMOS EL SALDO QUE SE VE REFLEJADO  EN ESTADO DE CUENTA PARA PODER EFECTUAR LA OPERACION
				IF @IdCuentaRetiro = 100
					SET @SaldoDisponible = @SaldoDisponible + @AhorroBase


				--OBTENEMOS SALDO DESPUES DE LA OPERACION
				SET @SaldoDespuesDeOperacion = @SaldoDisponible - @monto


			
				
				BEGIN --SE INICIALIZA LA TRANZACION PERO PRIMERO SE VALIDA SI EXISTTE UNA TRANSACCION PADRE

							if @tran_count = 0
								begin tran @tran_name
							else
								save tran @tran_name
				
							select @tran_scope = 1
				
						
					     --- SE REVISA QUE EL SALDO ACTUAL  DE EDO DE CUENTA SIGUE SIENDO EL MISMO CON EL QUE HICIMOS LOS CALCULOS ---
						 IF exists (select 1 from HAPE..EDO_DE_CUENTA where numero = @NumeroSocio and id_mov = @IdCuentaRetiro and saldo_actual != @SaldoActual)
						 BEGIN
							raiserror ('Transferencia incorrecta.Los saldos obtenidos al inicio de la transacci�n han sido modificados por otra transacci�', 11, 0)
						 END
						 ---
						 ---- Generacion de folio de banca
							insert into BANCA..TBL_BANCA_FOLIOS (numero_socio,fecha_alta)
							values (@numero_int,@fechaTransaccion)

							select @id_folio_banca = MAX (id_banca_folio) from BANCA..TBL_BANCA_FOLIOS where
							numero_socio = @numero_int
						--=========== end Generacion de folio de banca
						
						 ---INSERTAMOS LA TRABSFERENCIAS REFERENTE AL PAGO 
						INSERT INTO TBL_BANCA_TRANSFERENCIAs_PAGO_SERVICIOS
							(id_producto,id_servicio,numero_socio,monto,numero_referencia,fecha_alta_pago,
							id_estatus_transferencia,id_origen,clabe_corresponsalias_retiro, telefono,id_banca_folio,id_domiciliacion)
						VALUES(@idProducto,@idServicio,BANCA.dbo.FN_BANCA_CIFRAR(@numeroSocio),@monto,@numeroReferencia,GETDATE(),@idEstatusTransfenrecia, @tipo_origen,@ClabeCorresponsaliasRetiro,@telefono, @id_folio_banca,@id_domiciliacion)

				        ------------ UPDATE A ESTADO DE CUENTA -------------
						
						UPDATE HAPE..EDO_DE_CUENTA
						SET Saldo_Actual = @SaldoDespuesDeOperacion,
							Fecha =@fechaTransaccion
						WHERE 
						Numero = @NumeroSocio and Id_mov = @IdCuentaRetiro and Id_Tipo_persona = @idTipoPersona


						----------- FIN DE UPDATE A ESTADO DE CUENTA --------
						--
						--
						--
						------------ INSERT A MOVIMIENTOS--------------------
						print 'antes de movimientos'
						INSERT INTO HAPE.dbo.MOVIMIENTOS 
							(Numero,Activo,Fecha_Mov,
							Monto,Saldo,Tipo_Poliza,
							Num_Poliza,	Folio,Fecha_Alta,
							Id_Persona,	Numusuario,Id_tipomov,
							id_mov,	Id_Tipo_persona,id_origen,Titular)
						VALUES
						(   @NumeroSocio, 'T' , @fechaTransaccion,
							@monto,@SaldoDespuesDeOperacion,@TipoPoliza ,
							@NumPoliza , @id_folio_banca , @fechaTransaccion,
							@IdPersona , @NumUsuarioBanca,@IdTipoMov,
							@IdCuentaRetiro,@idTipoPersona,@id_origen_operacion,'S'
			 			)
						print 'despues de movimientos'
						---- FIN DE INSERT MOVIMIENTOS
						--
						--
						--
						--============================ INSERT CAPTURA ============================
						print 'antes de CAPTURA'
						begin
						--******	INSERCI�N DEL MOVIMIENTO		******
						select @ConceptoCaptura ='',@CuentaContable=''
						SELECT @ConceptoCaptura = Descripcion FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov
						select @CuentaContable =  Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like 
						case 
							when @IdCuentaRetiro = 100 then '2120000000%'
							when @IdCuentaRetiro = 103 then '2110000000%'
							when @IdCuentaRetiro = 112 then '2160000000%'
						end
						select @DebeHaber = 'D'
						INSERT INTO HAPE..CAPTURA
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCION SERVICIO DE BANCA	(HABER - ABONO)	******
						--obtenemos la descripcion del  movimiento
						select @ConceptoCaptura ='',@CuentaContable=''
						SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov
						print'@IdTipoMov'+ cast(@IdTipoMov as varchar)
						-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
						SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
						WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

						select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
						select @DebeHaber = 'H'

						INSERT INTO HAPE..CAPTURA
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCION SERVICIO DE BANCA	(DEBE - CARGO)	******
						--obtenemos la descripcion del  movimiento
						select @ConceptoCaptura ='',@CuentaContable=''
						SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

						-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
						SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
						WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto
																											   
						select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
						select @DebeHaber = 'D'

						INSERT INTO HAPE..CAPTURA
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCI�N MEDIOS DE PAGO	ABONO	******
						select @ConceptoCaptura ='',@CuentaContable=''
						select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
						from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14101000990000%'
						select @DebeHaber = 'H'

						INSERT INTO HAPE..CAPTURA
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCI�N SUCURSAL DEL SOCIO CARGO	******
						select @ConceptoCaptura ='',@CuentaContable=''
						select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
						from HAPE..CUENTAS_CONTABLES  where Num_cuenta = @CuentaContableSucursal
						select @DebeHaber = 'D'

						INSERT INTO HAPE..CAPTURA
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_compensacion
						)

						--******	INSERCI�N GESTO PAGO ABONO	******
						select @ConceptoCaptura ='',@CuentaContable=''
						select 
							@CuentaContable =   Num_cuenta, 
							@ConceptoCaptura = 'GESTO PAGO'--Concepto (Se forzo a que diga gesto pago, ya que al darse de alta en productivo no la registraron como debia ser)
						from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14100611950000%'
						select @DebeHaber = 'H'

						INSERT INTO HAPE..CAPTURA
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_compensacion
						)

						print 'despues de CAPTURA'
						end
						--- FIN DEL INSERT DE CAPTURA  ---

						--============================ INSERT CAPTURA_lacp ============================
						print 'antes de CAPTURA_lacp'
						begin
						--******	INSERCI�N DEL MOVIMIENTO		******
						select @ConceptoCaptura ='',@CuentaContable=''
						SELECT @ConceptoCaptura = Descripcion FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov
						select @CuentaContable =  Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like 
						case 
							when @IdCuentaRetiro = 100 then '2120000000%'
							when @IdCuentaRetiro = 103 then '2110000000%'
							when @IdCuentaRetiro = 112 then '2160000000%'
						end
						select @DebeHaber = 'D'
						INSERT INTO HAPE..CAPTURA_lacp
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCION SERVICIO DE BANCA	(HABER - ABONO)	******
						--obtenemos la descripcion del  movimiento
						select @ConceptoCaptura ='',@CuentaContable=''
						SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

						-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
						SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
						WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

						select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
						select @DebeHaber = 'H'
						INSERT INTO HAPE..CAPTURA_lacp
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCION SERVICIO DE BANCA	(DEBE - CARGO)	******
						--obtenemos la descripcion del  movimiento
						select @ConceptoCaptura ='',@CuentaContable=''
						SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

						-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
						SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
						WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

						select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
						select @DebeHaber = 'D'
						INSERT INTO HAPE..CAPTURA_lacp
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCI�N MEDIOS DE PAGO	ABONO	******
						select @ConceptoCaptura ='',@CuentaContable=''
						select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
						from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14101000990000%'
						select @DebeHaber = 'H'

						INSERT INTO HAPE..CAPTURA_lacp
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_socio
						)

						--******	INSERCI�N SUCURSAL DEL SOCIO CARGO	******
						select @ConceptoCaptura ='',@CuentaContable=''
						select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
						from HAPE..CUENTAS_CONTABLES  where Num_cuenta = @CuentaContableSucursal
						select @DebeHaber = 'D'

						INSERT INTO HAPE..CAPTURA_lacp
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_compensacion
						)

						--******	INSERCI�N GESTO PAGO ABONO	******
						select @ConceptoCaptura ='',@CuentaContable=''
						select 
							@CuentaContable =  Num_cuenta, 
							@ConceptoCaptura = 'GESTO PAGO'--Concepto (Se forzo a que diga gesto pago, ya que al darse de alta en productivo no la registraron como debia ser)
						from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14100611950000%'
						select @DebeHaber = 'H'

						INSERT INTO HAPE..CAPTURA_lacp
						(Id_persona,Activo,Numero,
						Nombre_s,Apellido_paterno,Apellido_materno,
						Total_movs,Total_ficha,Id_Tipomov,
						Cuenta,Concepto,Fecha_mov,Monto,
						Num_Poliza,Tipo_Poliza,	Folio,
						Id_tipo_persona,debe_haber,numUsuario,
						FECHA_ALTA,id_origen,ID_mov,Ccostos)
						values
						(   @IdPersona , 'T',@NumeroSocio,
							@NomreS,@ApellidoPaterno,@ApellidoMaterno,
							@TotalMovs,@monto,@IdTipoMov,
							@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
							@NumPoliza,@TipoPoliza,@id_folio_banca,
							@idTipoPersona,@DebeHaber,@NumUsuarioBanca,
							@fechaTransaccion,@id_origen_operacion,@IdCuentaRetiro,@ccostos_compensacion
						)

						print 'despues de CAPTURA_lacp'

						end
						--- FIN DEL INSERT DE CAPTURA_lacp  ---

		
			   BEGIN -- commit
				
					if @tran_count = 0

						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
			   END -- commit	
				  	
			  END -- FIN DE SE INICIALIZA LA TRANZACION PERO PRIMERO SE VALIDA SI EXISTTE UNA TRANSACCION PADRE 


			  RESULT:
			  	  BEGIN		
					--SELECT 200 estatus , 'OK' mensaje , @id_folio_banca as id_folio_banca
					declare 
					@necesitaPin bit = 0,
					@leyenda varchar(max) = '',
					@id_tipo_bitacora int

					select @leyenda = leyenda from CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO where id_producto = @IdProducto and id_servicios_pago = @idServicio

					if exists(SELECT id_cat_tipo_servicio FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO WHERE id_producto = @IdProducto and id_servicios_pago = @idServicio  and id_cat_tipo_servicio in (10,11))
					set @necesitaPin = 1

					--******	INSERCI�N DE BITACORA	******
					/*select @id_tipo_bitacora = 38 --Alta de pago de servicio
					insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
					values(@id_folio_banca, @id_tipo_bitacora, @numero_int, getdate(), @tipo_origen)

					select * from CAT_BANCA_TIPOS_BITACORA order by 
					*/


					/*se extrae informacion adicional para  validaciones en el front y regresamos el folio generado*/
					Select 200 estatus , @necesitaPin as necesitaPin ,'OK'   mensaje , @id_folio_banca as id_folio_banca,@leyenda as leyenda, * 
					from CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO 
					where id_producto  = @IdProducto and id_servicios_pago = @idServicio
				 END 

		end try -- try principal
		
		begin catch -- catch principal

		   if @tran_scope = 1
				rollback tran @tran_name
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@estatus=0  
		
			select ERROR_LINE() , @error_message as mensaje, @estatus as estatus
		
		end catch -- catch principal
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_PAGAR_PRESTAMO]    Script Date: 07/08/2020 12:33:14 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Mar Mej�a Murillo
UsuarioRed		memm373565
Fecha			20190110
Objetivo		Realiza el pago de un cr�dito a trav�s de Banca en L�nea
Proyecto		Banca en L�nea
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_PAGAR_PRESTAMO]
	
		@clabeCorresponsaliasRetiro varchar(16),
		@clabeCorresponsaliasDeposito varchar(16),
		@Monto decimal(18,2),
		@TipoAnticipo int = null,
		@TipoOrigen int = null,
		@programada bit = null,
		@horaProgramada datetime = null,
		@fechaOperacion datetime = null,
		@id_transferencia bigint = null,
		@id_domiciliacion int=null

as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				begin -- declaraciones

					declare	@status int = 200,
							@error_message varchar(255) = '',
							@error_line varchar(255) = '',
							@error_severity varchar(255) = '',
							@error_procedure varchar(255) = '',
							@sql nvarchar(4000) = 'delete #SP_BANCA_PAGAR_PRESTAMO',
					        @standalone	bit = 1
						
					declare	@tran_name varchar(32) = 'REALIZA_PAGO_PRESTAMO',
							@tran_count int = @@trancount,
							@tran_scope bit = 0,
							@estatus_sp_interno int = 1,
							@mensaje_sp_interno varchar(500)

					--declare
					--		@numusuario int = 6012,
					--		@num_poliza bigint,
					--		@id_persona_origen int,
					--		@id_persona_destino int,
					--		@saldo_adelanto_destino money,
					--		@aplica_iva_destino money,
					--		@retiro_ahorro_total money,
					--		@retiro_inver_total money,
					--		@retiro_debito_total money,
					--		@retiro_adelanto_total money = 0,
					--		@num_ptmo_destino varchar(14),
					--		@gastos_cobranza_destino money,
					--		@iva_gastos_cobranza_destino money,
					--		@gastos_cobranza_mas_iva_destino money,
					--		@tasa_gastos_cobranza_destino float,
					--		@monto_liquidacion_destino money,
					--		@no_asignado_destino money,
					--		@titular_destino varchar(1) = 'T',
					--		@plazo_destino int,
					--		@reestructura_destino varchar(1),
					--		@diferencia_redondeo money

					declare	@numero_origen int,
							@numero_destino int,
							@es_decreciente_destino bit = 0,
							@es_nivelado_destino bit = 0,
							@es_revolvente_destino bit = 0,
							@pago_liquidacion_destino money = 0,
							@pago_al_corriente_destino money = 0,
							@tipo_poliza varchar(1) = 'M',
							@message varchar(255),
							@total_efectivo money = 0,
							@num_poliza bigint,
							@id_mov_origen int,
							@id_mov_destino int,
							@saldo_origen money,
							@saldo_destino money,
							@id_esquema_destino int,
							@saldo_adelanto_destino money,
							@aplica_iva_destino bit,
							@num_ptmo_destino varchar(14),
							@planx_destino varchar(1),
							@numero_fin_destino int,
							@id_persona_origen int,
							@id_persona_destino int,
							@plazo_destino int,
							@id_tipo_persona_origen int = 1,
							@id_tipo_persona_destino int = 1,
							@tasa_ord_destino float,
							@tasa_mor_destino float,
							@numero_fin_lacp_destino int,
							@id_amortizacion_destino int,
							@id_renovado_destino int,
							@reestructura_destino varchar(1),
							@nombre_s_destino varchar(100),
							@apellido_paterno_destino varchar(100),
							@apellido_materno_destino varchar(100),
							@seguro_vida_destino money,
							@seguro_da�os_destino money,
							@int_mor_destino money,
							@iva_int_mor_destino money,
							@int_ord_ven_destino money,
							@iva_int_ord_ven_destino money,
							@int_ord_vig_destino money,
							@iva_int_ord_vig_destino money,
							@cap_ven_destino money,
							@cap_vig_destino money,
							@int_ord_hoy_destino money,
							@iva_int_ord_hoy_destino money,
							@cap_no_dev_destino money,
							@gastos_cobranza_destino money,
							@iva_gastos_cobranza_destino money,
							@fecha_sistema datetime = getdate(),
							@folio bigint,
							@folio_previo bigint,
							@id_tipo_bitacora int = 23,
							@id_cuenta_origen bigint,
							@id_cuenta_destino bigint,
							@saldo_ahorro_origen money,
							@saldo_inver_origen money,
							@saldo_debito_origen money,
							@liquida_destino bit,
							@hay_excedente_destino bit,
							@al_corriente_destino bit,
							@monto_necesario money,
							@seguro_vida_saldado money = 0,
							@seguro_da�os_saldado money = 0,
							@int_mor_saldado money = 0,
							@iva_int_mor_saldado money = 0,
							@moratorios_mas_iva_saldado money = 0,
							@int_ord_ven_saldado money,
							@iva_int_ord_ven_saldado money,
							@int_ord_vig_saldado money,
							@iva_int_ord_vig_saldado money,
							@cap_ven_saldado money,
							@cap_vig_saldado money,
							@int_ord_hoy_saldado money,
							@iva_int_ord_hoy_saldado money,
							@cap_no_dev_saldado money,
							@gastos_cobranza_saldado money,
							@iva_gastos_cobranza_saldado money,
							@gastos_cobranza_mas_iva_saldado money,
							@no_asignado_destino money,
							@ahorro_base_origen money = 0,
							@respaldo_ahorro money = 0,
							@numusuario int = 6012,
							@monto_tomado_ahorro money = 0,
							@monto_tomado_inver money = 0,
							@monto_tomado_debito money = 0,
							@monto_tomado_efectivo money = 0,
							@monto_tomado_adelanto money = 0,
							@titular_pago varchar(1) = 'T',
							@id_linea_destino bigint,
							@ccostos_origen varchar(10),
							@ccostos_destino varchar(10),
							@pago_mismo_socio bit = 0,
							@MontoOriginalTransaccion decimal(18,2) =0

					-- se agrego para incidencia de compensaciones pagos entre socios de diferentes sucursales - 01/04/2019
					declare  @fecha_ini datetime
							,@fecha_fin datetime		
							,@ccostos_medpa varchar (10) = 'MEDPA'
							,@cta_contable_suc_duena varchar(50)
							,@des_contable_suc_duena varchar(255)
							,@cta_contable_suc_destino varchar(50)
							,@des_contable_suc_destino varchar(255)

					select	identity (int, 1, 1) contador,
							id_persona,
							activo,
							numero,
							nombre_s,
							apellido_paterno,
							apellido_materno,
							total_movs,
							total_ficha,
							id_tipomov,
							cuenta,
							concepto,
							fecha_mov,
							monto,
							id_mov,
							num_poliza,
							tipo_poliza,
							folio,
							id_tipo_persona,
							num_cheq,
							desc1,
							desc2,
							planx,
							desc3,
							fecha_dpf_final,
							num_dpf,
							tasa,
							interes,
							dias,
							debe_haber,
							numusuario,
							numero_fin,
							plazo,
							interes_ord,
							interes_mor,
							contador_provision,
							ccostos,
							nombre_beneficiario,
							parentesco_beneficiario,
							porcentaje_beneficiario,
							nombre_beneficiario2,
							parentesco_beneficiario2,
							porcentaje_beneficiario2,
							numero_fin_lacp,
							id_esquema,
							titular,
							num_ptmo,
							id_amortizacion,
							id_renovado,
							reestructura,
							id_origen,
							id_tipo_pago_prestamo
					into	#captura_previo
					from	hape.dbo.captura
					where	1 = 0

					create table
						#procedimiento_pago_credito
							(
							status			int null,
							error_procedure	varchar(255) null,
							error_line		varchar(255) null,
							error_severity	varchar(255) null,
							error_message	varchar(255) null,
							)

					create table
						#actualiza_edo_de_cuenta_haberes_previo
							(
							numero			int null,
							id_mov			int null,
							saldo_anterior	money null,
							diferencia		money null,
							saldo_posterior	money null,
							fecha			datetime null,
							)

					create table
						#obtiene_saldos
							(
							status						int null,
							saldo_actual				money null,
							interes_moratorio			money null,
							interes_ord_vencido			money null,
							interes_ordinario_vigente	money null,
							capital_vencido				money null,
							capital_corte				money null,
							capital_no_devengado_fin	money null,
							pago_al_corriente			money null,
							saldo_adelanto				money null,
							seguro_vida					money null,
							seguro_danos				money null,
							capitalAmort				money null,
							ivaIntMoratorio				money null,
							ivaIntOrdinarioVencido		money null,
							ivaIntOrdinarioVigente		money null,
							int_moratorio_quitas		money null,
							int_moratorio_quitas_iva	money null,
							int_ordinario_quitas		money null,
							int_ordinario_quitas_iva	money null,
							reserva_capital				money null,
							reserva_interes				money null,
							gastos_cobranza				money null,
							iva_gastos_cobranza			money null,
							tasa_gastos_cobranza		money null,
							primer_corte_vigente		money null,
							int_ord_diferido_no_dev		money null
							)

					create table
						#obtiene_saldos_revolvente
							(
							id_linea				bigint null,
							numero					int null,
							id_mov					int null,
							num_ptmo				varchar(14) null,
							planx					varchar(1) null,
							saldo_actual			money null,
							id_estado				int null,
							cv_diaria				bit null,
							fecha_traspaso_CV		datetime null,
							dias_vencidos			int null,
							periodos_vencidos		int null,
							fecha_ultimo_abono		datetime null,
							fecha_ultimo_int_ord	datetime null,
							fecha_ultimo_int_mor	datetime null,
							moratorios				money null,
							iva_moratorios			money null,
							ordinarios_vencidos		money null,
							iva_ordinarios_vencidos	money null,
							ordinarios_corte		money null,
							iva_ordinarios_corte	money null,
							capital_vencido			money null,
							capital_corte			money null,
							ordinarios_al_hoy		money null,
							iva_ordinarios_al_hoy	money null,
							capital_no_devengado	money null,
							pago_minimo				money null,
							pago_minimo_total		money null,
							pago_liquidacion		money null,
							pago_liquidacion_total	money null,
							gastos_cobranza			money null,
							iva_gastos_cobranza		money null,
							tasa_gastos_cobranza	float null,
							seguro_vida				money null,
							seguro_da�os			money null,
							int_ord_diferido_no_dev	money null
							)

					create table
						#sp_cred_obtiene_desglose_monto_a_pagar
							(
							status					int null,
							error_procedure			varchar(255) null,
							error_line				varchar(255) null,
							error_severity			varchar(255) null,
							error_message			varchar(255) null,
							seguro_vida				money null,
							seguro_da�os			money null,
							int_mor					money null,
							iva_int_mor				money null,
							int_ord_ven				money null,
							iva_int_ord_ven			money null,
							int_ord_vig				money null,
							iva_int_ord_vig			money null,
							cap_ven					money null,
							cap_vig					money null,
							int_ord_hoy				money null,
							iva_int_ord_hoy			money null,
							cap_no_dev				money null,
							gastos_cobranza			money null,
							iva_gastos_cobranza		money null,
							tasa_gastos_cobranza	float null,
							monto_a_pagar			money null,
							no_asignado				money null,
							saldo_actual			money null,
							saldo_ahorro			money null,
							saldo_inver				money null,
							saldo_debito			money null,
							)
            
			begin try -- revisar tabla de resultados

				exec (@sql)

				select @standalone = 0

			end try -- revisar tabla de resultados

			begin catch -- revisar tabla de resultados

			     	CREATE TABLE #SP_BANCA_PAGAR_PRESTAMO
					(
							estatus int,
							folio bigint,
							HoraTransaccion datetime,
							Monto money,
							error_procedur varchar(500),
							error_lin varchar(500),
							error_severit varchar(500),
							error_messag varchar(500)
					)

			end catch -- revisar tabla de resultados



				end -- declaraciones
						
				begin -- valores por defecto

					select	@fechaOperacion = coalesce(@fechaOperacion, getdate()),
							@TipoOrigen = coalesce(@TipoOrigen, 3),
							@tipo_poliza = coalesce(@tipo_poliza, 'M'),
							@total_efectivo = -coalesce(@total_efectivo, 0),
							@programada = coalesce(@programada, 0),
							@MontoOriginalTransaccion =@Monto

				end -- valores por defecto

			end -- inicio
			
			begin -- validaciones de par�metros

			
			
				if not exists(select 1 from hape.dbo.tbl_corresponsalias_cuentas where cuenta = @clabeCorresponsaliasRetiro )

					begin -- validar clabe de retiro
											
							select @status = 339
							select @message = 'La clabe [' + @clabeCorresponsaliasRetiro + '] de corresponsal�as proporcionada no existe'
							raiserror (@message, 11, 0)

					end -- validar clabe de retiro

				if not exists(select 1 from hape.dbo.tbl_corresponsalias_cuentas where cuenta = @clabeCorresponsaliasDeposito )

					begin -- validar clabe de dep�sito

							select @status = 339
							select @message = 'La clabe [' + @clabeCorresponsaliasDeposito + '] de corresponsal�as proporcionada no existe'
							raiserror (@message, 11, 0)

					end -- validar clabe de dep�sito
					

				declare
					@id_mov int,
					@numeroSocioDestino int,
					@numeroSocioOrigen int,
					@monto_transferencias_al_dia money,
					@limite_monto_al_dia money 

				SELECT @id_mov = id_mov ,@numeroSocioDestino=  NUMERO FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE  cuenta = @clabeCorresponsaliasDeposito 
				SELECT @numeroSocioOrigen =  NUMERO FROM HAPE..TBL_CORRESPONSALIAS_CUENTAS WHERE  cuenta = @clabeCorresponsaliasRetiro 
				---

				IF EXISTS(select * from HAPE..PERSONA where numero = @numeroSocioDestino AND Id_Tipo_Persona = 1 and 
					(Bloqueado_Cobranza = 'A' OR Bloqueado_Exclusion = 'A'))
				begin
						select @status = id_excepcion, @message  = descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 408
						raiserror (@message, 11, 0)
				end
				
				if(@id_mov=10) and exists(select 1 from HAPE..tbl_revolvente_lineas_credito where Numero=@numeroSocioDestino
				and interes_ordinario_diferido is not null and cast(@fechaOperacion as date)>=cast(inicio_periodo_gracia as date) and cast(@fechaOperacion as date)<=cast(fin_periodo_gracia as date))
				begin
						select @status = 408, @message  = 'Por el momento no se puede realizar un pago a este pr�stamo, ya que se encuentra en periodo de gracia.'
						raiserror (@message, 11, 0)
				end

				--Modificaci�n COVIDFase3 se valida que el socio no se encuentre en periodo de gracia con interes diferido
				if (@id_mov!=10) and exists(select 1 from HAPE..EDO_DE_CUENTA where Numero=@numeroSocioDestino and Id_mov=@id_mov and Saldo_Actual>0 
				and interes_ordinario_diferido is not null and cast(@fechaOperacion as date)>=cast(inicio_periodo_gracia as date) and cast(@fechaOperacion as date)<=cast(fin_periodo_gracia as date))
				begin
						select @status = 408, @message  = 'Por el momento no se puede realizar un pago a este pr�stamo, ya que se encuentra en periodo de gracia.'
						raiserror (@message, 11, 0)
				end
			

				--===================================	VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS	===============================
					BEGIN
						
						if @monto > (select monto_maximo from TBL_BANCA_CUENTAS_INTERNAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio)=@numeroSocioOrigen and clabe_corresponsalias=@clabeCorresponsaliasDeposito and activo=1) 
						begin -- validar monto maximo de transaccion
							select @status = id_excepcion, @message  = descripcion from CAT_BANCA_EXCEPTIONS where  id_excepcion = 321
							raiserror (@message, 11, 0)

						end -- validar monto maximo de transaccion

						declare 
							@fecha_ datetime, 
							@tipoTransferencia int 
							

						if(@programada = 0)
							select @fecha_ = @fechaOperacion
						else
							select @fecha_ = @horaProgramada

						select	@numero_origen = numero,
								@id_mov_origen = id_mov
						from	hape.dbo.tbl_corresponsalias_cuentas
						where	cuenta = @clabeCorresponsaliasRetiro

						select @tipoTransferencia = case 
							when @numero_origen = @numero_destino then 3	---3.- PAGO DE PRESTAMOS CMV MIS CUENTAS
							else 4 end										---4.- PAGO DE PRESTAMOS CMV OTRAS CUENTAS

						select 
							@status = estatus, @message = msj  
						from  
							FN_VALIDAR_LIMITES_TRANSFERENCIAS_DIARIO (@tipoTransferencia,@numero_origen,@monto,@fecha_,@programada)

						if @status <> 200
						begin
							raiserror (@message, 11, 0)
						end
					END ---VALIDACIONES DE LIMITES DE MONTOS DE TRANSFERENCIAS


				/*
				select @limite_monto_al_dia = coalesce(maximo,0) from TBL_BANCA_LIMITES_TRANSFERENCIAS where id_limite_transferencia =  1 and activo = 1
					
				---Calculo del monto de transferencia generado al dia de transferencia
				select  @monto_transferencias_al_dia = sum(convert(money,isnull(monto,0)))
				from TBL_BANCA_TRANSFERENCIAS_INTERNAS
				where
					numero_socio = @numeroSocioOrigen
					--and id_estatus_transferencia = 2 --Realizada
					and 
					(
						(convert(varchar,fecha_transferencia_realizada,112) = CONVERT(varchar,@fechaOperacion,112) and @programada=0)
					or 
						(convert(varchar,fecha_programada,112) = CONVERT(varchar,@horaProgramada,112) and @programada=1 )
					)
					--convert(varchar,GETDATE(),112)
				group by numero_socio

				  print '@numero_origen: '+cast( @numeroSocioOrigen as varchar)
				  print '@fechaOperacion: '+  CONVERT(varchar,@fechaOperacion,112)
				  print '@horaProgramada: '+ CONVERT(varchar,@horaProgramada,112) 
				  print '@monto_transferencias_al_dia'+ cast(isnull(@monto_transferencias_al_dia,0) as varchar)
				  print '@monto'+ cast(@monto as varchar)
				  print '@limite_monto_al_dia'+ cast(@limite_monto_al_dia as varchar)

				if (@monto_transferencias_al_dia + isnull(@monto,0)) > @limite_monto_al_dia and 
				(@id_transferencia = 0 OR @id_transferencia is null)--- es para cuando se ejecuta los pagos programados ya no los contemple
					begin -- validar monto maximo de transaccion
					  
						select @status=321
						select @message = descripcion from CAT_BANCA_EXCEPTIONS where id_excepcion =321 --'321|El monto m�ximo de transferencia de la cuenta es excedido.'
						raiserror (@message, 11, 0)
					end -- validar monto maximo de transaccion
				*/

				if(@id_mov between 1 and 9)
				begin
					if not EXISTS (select 1	from hape.dbo.edo_de_cuenta where 	numero=@numeroSocioDestino and id_mov=@id_mov and saldo_actual > 0)
					BEGIN
						select @status = 405
						SELECT @message = descripcion FROM CAT_BANCA_EXCEPTIONS	WHERE id_excepcion = 405
						raiserror (@message, 11, 0)
					END
				END
				

				IF (@numeroSocioDestino  = @numeroSocioOrigen )
					SET @pago_mismo_socio =1
				ELSE
					SET @pago_mismo_socio =0

				print '@pago_mismo_socio = '+cast(@pago_mismo_socio as varchar)
				print '@numeroSocioOrigen = '+cast(@numeroSocioOrigen as varchar)
				print '@@numeroSocioDestino = '+cast(@numeroSocioDestino as varchar)

				if @pago_mismo_socio = 0
				begin -- si el pago es a otro socio del mismo banco
					
					if not exists(select * from TBL_BANCA_CUENTAS_INTERNAS where 
								clabe_corresponsalias=@clabeCorresponsaliasDeposito and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocioOrigen and activo = 1
								and DATEDIFF(MINUTE,fecha_alta,getdate()) > 30
							)
						begin -- validar que la clave corresponsalia de deposito tenga un periodo mayor a 30 minutos despues de haber sido dada de alta

							select @status=339
							select @message = 'Espere el tiempo de registro de la cuenta para poder hacer uso de ella'
							raiserror (@message, 11, 0)

						end -- validar que la clave corresponsalia de deposito tenga un periodo mayor a 30 minutos despues de haber sido dada de alta


					if (@id_mov = 10) and  EXISTS(select 1 from HAPE..TBL_REVOLVENTE_LINEAS_CREDITO where numero  = @numeroSocioDestino and saldo_actual = limite_credito)
					begin
					
						  select @status = id_excepcion , @message = descripcion from CAT_BANCA_EXCEPTIONS where id_excepcion = 408
						  raiserror (@message, 11, 0)
					end

				end 
				else  -- si el pago del prestamo es del mismo socio
				begin
				    print 'no tiene sentido esta validacion'
					--if (@id_mov = 10) and  EXISTS(select 1 from HAPE..TBL_REVOLVENTE_LINEAS_CREDITO where numero  = @numeroSocioOrigen and saldo_actual = limite_credito)
					--	begin
					
					--		  select @status = id_excepcion , @message = descripcion from CAT_BANCA_EXCEPTIONS where id_excepcion = 408
					--		  raiserror (@message, 11, 0)
					--	end
				end

				--if (@id_mov = 10 and @TipoAnticipo != 1)
				--begin -- validar que no se puede realizar un ReduccionPlazo,ReduccionAmortizacion,PagoParaAdelantar
				--	select @status = id_excepcion ,@message = descripcion 	from  CAT_BANCA_EXCEPTIONS 	where id_excepcion = 407
				--	raiserror (@message, 11, 0)
				--end -- validar que no se puede realizar un ReduccionPlazo,ReduccionAmortizacion,PagoParaAdelantar

				
				
				if (@TipoAnticipo = 4 )

					begin -- validar que sea un pago para adelantar

							select @status = id_excepcion ,@message = descripcion 
							from  CAT_BANCA_EXCEPTIONS 
							where id_excepcion = 404
							raiserror (@message, 11, 0)

					end -- validar que sea un pago para adelantar
				
			end -- validaciones de par�metros

			begin -- preparaci�n
			
				begin -- obtener n�mero de p�liza de banca para el d�a

					select	@num_poliza = numpoliza
					from	hape.dbo.tbl_cmv_folios_polizas_procesos
					where	idProcesoPoliza =
								(
								select	idprocesopoliza
								from	hape.dbo.cat_cmv_procesos_polizas
								where	descripcion = 'BANCA ELECTRONICA'
								)
							and dia = day(@fechaOperacion)

				end -- obtener n�mero de p�liza de banca para el d�a

				begin -- recopilar datos de las cuentas				
							

					insert	#actualiza_edo_de_cuenta_haberes_previo
							(
							numero,
							id_mov,
							saldo_anterior,
							fecha
							)
					select	numero,
							id_mov,
							saldo_actual,
							fecha
					from	hape.dbo.edo_de_cuenta
					where	numero = @numero_origen
							and id_mov in (100, 103, 112)

					select	id_persona,
							numero,
							nombre_s,
							apellido_paterno,
							apellido_materno,
							s.id_de_sucursal,
							ccostos_origen = s.ccostos,
							ccostos_destino = s.ccostos
					into	#persona_
					from	hape.dbo.persona p
								join hape.dbo.sucursales s
									on s.id_de_sucursal = p.id_de_sucursal
					where	numero = @numero_origen
							and id_tipo_persona = 1

					select	@ccostos_origen = ccostos_origen
					from	#persona_

					select	@numero_destino = numero,
							@id_mov_destino = id_mov
					from	hape.dbo.tbl_corresponsalias_cuentas
					where	cuenta = @clabeCorresponsaliasDeposito
							

					select	@saldo_origen = saldo_anterior
					from	#actualiza_edo_de_cuenta_haberes_previo
					where	numero = @numero_origen
							and id_mov = @id_mov_origen

					select	@saldo_ahorro_origen = saldo_anterior,
							@respaldo_ahorro = saldo_anterior
					from	#actualiza_edo_de_cuenta_haberes_previo
					where	id_mov = 100

					select	@saldo_inver_origen = saldo_anterior
					from	#actualiza_edo_de_cuenta_haberes_previo
					where	id_mov = 103

					select	@saldo_debito_origen = saldo_anterior
					from	#actualiza_edo_de_cuenta_haberes_previo
					where	id_mov = 112

					select	@saldo_destino = saldo_actual,
							@id_esquema_destino = id_esquema,
							@saldo_adelanto_destino = saldo_adelanto,
							@aplica_iva_destino = aplica_iva,
							@num_ptmo_destino = num_ptmo,
							@planx_destino = planx,
							@numero_fin_destino = numero_fin,
							@plazo_destino = plazo,
							@tasa_ord_destino = int_ord,
							@tasa_mor_destino = int_mor,
							@numero_fin_lacp_destino = numero_fin_lacp,
							@id_amortizacion_destino = id_amortizacion,
							@id_renovado_destino = id_renovado,
							@reestructura_destino = reestructurado
					from	hape.dbo.edo_de_cuenta
					where	numero = @numero_destino
							and id_mov = @id_mov_destino

					select	@id_persona_origen = id_persona
					from	hape.dbo.persona
					where	numero = @numero_origen
							and id_tipo_persona = @id_tipo_persona_origen

					select	@ccostos_destino = s.Ccostos
					from	hape.dbo.persona p
							join hape.dbo.sucursales s
								on s.Id_de_Sucursal = p.Id_de_Sucursal
					where	numero = @numero_destino
							and Id_Tipo_Persona = 1

					update	#persona_
					set		ccostos_destino = @ccostos_destino

					select	@id_persona_destino = id_persona,
							@nombre_s_destino = Nombre_s,
							@apellido_paterno_destino = Apellido_Paterno,
							@apellido_materno_destino = Apellido_Materno					
					from	hape.dbo.persona
					where	numero = @numero_destino
							and id_tipo_persona = @id_tipo_persona_destino

					if @id_mov_destino = 10

						select	@id_esquema_destino = 4,
								@saldo_adelanto_destino = 0,
								@aplica_iva_destino = 1

				-- obtenemos la cuenta contable de la sucursal del socio origen para compensaciones - 01/04/2019
					select	@cta_contable_suc_duena =	n.Num_Cuenta_Compensacion,
							@des_contable_suc_duena =	n.Concepto
														from	hape.dbo.SUCURSALES s 
																inner join hape.dbo.NUM_SUCURSAL n
																	on n.Num_Sucursal = s.Num_Sucursal
																inner join hape.dbo.PERSONA c
																	on c.Id_de_sucursal = s.Id_de_Sucursal
														where	c.Numero = @numero_origen
															and	c.Id_Tipo_Persona = 1

				-- obtenemos la cuenta contable de la sucursal del socio destino para compensaciones - 01/04/2019
					select	@cta_contable_suc_destino =		n.Num_Cuenta_Compensacion,
							@des_contable_suc_destino =		n.Concepto
															from	hape.dbo.SUCURSALES s 
																	inner join hape.dbo.NUM_SUCURSAL n
																		on n.Num_Sucursal = s.Num_Sucursal
																	inner join hape.dbo.PERSONA c
																		on c.Id_de_sucursal = s.Id_de_Sucursal
															where	c.Numero = @numero_destino
																and	c.Id_Tipo_Persona = 1

				end -- recopilar datos de las cuentas

				begin -- remapear el tipo de anticipo

					select @TipoAnticipo =
						case
							when @TipoAnticipo = 1 -- normal
								then 0
							when @TipoAnticipo = 3 -- reducci�n de amortizaci�n
								then 1
							when @TipoAnticipo = 4 -- adelanto
								then 3
							else
								2 -- anticipo
						end

				end -- remapear el tipo de anticipo

				begin -- determinar tipo de pr�stamo

					if @id_esquema_destino = 1

						select @es_decreciente_destino = 1

					else if @id_esquema_destino in (2, 3)

						select @es_nivelado_destino = 1

					else if @id_esquema_destino = 4

						select @es_revolvente_destino = 1

				end -- determinar tipo de pr�stamo

				begin try -- obtiene saldos

					if @es_decreciente_destino = 1

						begin -- decrecientes

							insert	#obtiene_saldos
									(
									status,
									saldo_actual,
									interes_moratorio,
									interes_ord_vencido,
									interes_ordinario_vigente,
									capital_vencido,
									capital_corte,
									capital_no_devengado_fin,
									pago_al_corriente,
									saldo_adelanto,
									seguro_vida,
									seguro_danos,
									capitalamort,
									ivaintmoratorio,
									ivaintordinariovencido,
									ivaintordinariovigente,
									int_moratorio_quitas,
									int_moratorio_quitas_iva,
									int_ordinario_quitas,
									int_ordinario_quitas_iva,
									reserva_capital,
									reserva_interes,
									gastos_cobranza,
									iva_gastos_cobranza,
									tasa_gastos_cobranza,
									primer_corte_vigente,
									int_ord_diferido_no_dev
									)
							exec	hape.dbo.sp_interes_diario_obtiene_saldos
									@numero_destino,
									@id_mov_destino,
									@fechaOperacion,
									1

							select	@seguro_vida_destino = coalesce(seguro_vida, 0),
									@seguro_da�os_destino = coalesce(seguro_danos, 0),
									@int_mor_destino = coalesce(interes_moratorio, 0),
									@iva_int_mor_destino = coalesce(ivaIntMoratorio, 0),
									@int_ord_ven_destino = coalesce(interes_ord_vencido, 0),
									@iva_int_ord_ven_destino = coalesce(ivaIntOrdinarioVencido, 0),
									@int_ord_vig_destino = coalesce(interes_ordinario_vigente, 0),
									@iva_int_ord_vig_destino = coalesce(ivaIntOrdinarioVigente, 0),
									@cap_ven_destino = coalesce(capital_vencido, 0),
									@cap_vig_destino = coalesce(capital_corte, 0),
									@int_ord_hoy_destino = 0,
									@iva_int_ord_hoy_destino = 0,
									@cap_no_dev_destino = coalesce(capital_no_devengado_fin, 0),
									@saldo_adelanto_destino = coalesce(saldo_adelanto, 0)
							from	#obtiene_saldos

						end -- decrecientes

					else if @es_nivelado_destino = 1

						begin -- nivelados
							insert	#obtiene_saldos
									(
									status,
									saldo_actual,
									interes_moratorio,
									interes_ord_vencido,
									interes_ordinario_vigente,
									capital_vencido,
									capital_corte,
									seguro_vida,
									seguro_danos,
									saldo_adelanto,
									pago_al_corriente,
									capital_no_devengado_fin,
									capitalamort,
									ivaintmoratorio,
									ivaintordinariovencido,
									ivaintordinariovigente,
									int_moratorio_quitas,
									int_moratorio_quitas_iva,
									int_ordinario_quitas,
									int_ordinario_quitas_iva,
									reserva_capital,
									reserva_interes,
									gastos_cobranza,
									iva_gastos_cobranza,
									tasa_gastos_cobranza,
									primer_corte_vigente,
									int_ord_diferido_no_dev
									)
							exec	hape.dbo.sp_interes_diario_obtiene_saldos_banca_nivelados
									@numero_destino,
									@id_mov_destino,
									@fechaOperacion,
									1


							select	@seguro_vida_destino = coalesce(seguro_vida, 0),
									@seguro_da�os_destino = coalesce(seguro_danos, 0),
									@int_mor_destino = coalesce(interes_moratorio, 0),
									@iva_int_mor_destino = coalesce(ivaIntMoratorio, 0),
									@int_ord_ven_destino = coalesce(interes_ord_vencido, 0),
									@iva_int_ord_ven_destino = coalesce(ivaIntOrdinarioVencido, 0),
									@int_ord_vig_destino = coalesce(interes_ordinario_vigente, 0),
									@iva_int_ord_vig_destino = coalesce(ivaIntOrdinarioVigente, 0),
									@cap_ven_destino = coalesce(capital_vencido, 0),
									@cap_vig_destino = coalesce(capital_corte, 0),
									@int_ord_hoy_destino = 0,
									@iva_int_ord_hoy_destino = 0,
									@cap_no_dev_destino = coalesce(capital_no_devengado_fin, 0),
									@saldo_adelanto_destino = coalesce(saldo_adelanto, 0)
							from	#obtiene_saldos

							
							
						end -- nivelados

					else if @es_revolvente_destino = 1

						begin -- revolventes

							insert	#obtiene_saldos_revolvente
									(
									id_linea,
									numero,
									id_mov,
									num_ptmo,
									planx,
									saldo_actual,
									id_estado,
									cv_diaria,
									fecha_traspaso_CV,
									dias_vencidos,
									periodos_vencidos,
									fecha_ultimo_abono,
									fecha_ultimo_int_ord,
									fecha_ultimo_int_mor,
									moratorios,
									iva_moratorios,
									ordinarios_vencidos,
									iva_ordinarios_vencidos,
									ordinarios_corte,
									iva_ordinarios_corte,
									capital_vencido,
									capital_corte,
									ordinarios_al_hoy,
									iva_ordinarios_al_hoy,
									capital_no_devengado,
									pago_minimo,
									pago_minimo_total,
									pago_liquidacion,
									pago_liquidacion_total,
									gastos_cobranza,
									iva_gastos_cobranza,
									tasa_gastos_cobranza,
									seguro_vida,
									seguro_da�os,
									int_ord_diferido_no_dev
									)
							exec	hape.dbo.sp_revolvente_obtiene_saldos
									@numero_destino,
									@fechaOperacion

							select	@id_linea_destino = id_linea,
									@pago_liquidacion_destino = pago_liquidacion_total,
									@pago_al_corriente_destino = pago_minimo_total,
									@saldo_adelanto_destino = 0,
									@num_ptmo_destino = num_ptmo,
									@seguro_vida_destino = coalesce(seguro_vida, 0),
									@seguro_da�os_destino = coalesce(seguro_da�os, 0),
									@int_mor_destino = coalesce(moratorios, 0),
									@iva_int_mor_destino = coalesce(iva_moratorios, 0),
									@int_ord_ven_destino = coalesce(ordinarios_vencidos, 0),
									@iva_int_ord_ven_destino = coalesce(iva_ordinarios_vencidos, 0),
									@int_ord_vig_destino = coalesce(ordinarios_corte, 0),
									@iva_int_ord_vig_destino = coalesce(iva_ordinarios_corte, 0),
									@cap_ven_destino = coalesce(capital_vencido, 0),
									@cap_vig_destino = coalesce(capital_corte, 0),
									@int_ord_hoy_destino = coalesce(ordinarios_al_hoy, 0),
									@iva_int_ord_hoy_destino = coalesce(iva_ordinarios_al_hoy, 0),
									@cap_no_dev_destino = coalesce(capital_no_devengado, 0)
							from	#obtiene_saldos_revolvente

							--if (/*(@pago_al_corriente_destino < @monto or @pago_al_corriente_destino = 0) and*/ @pago_liquidacion_destino != @monto) and @programada = 0

							--	begin

							--		select @status = 407
							--		select @message = descripcion from CAT_BANCA_EXCEPTIONS where id_excepcion = @status
							--		raiserror (@message, 11, 0)

							--	end

						end -- revolventes

				end try 
				begin catch 
					print '**Error en obtiene saldos----'
					select @status = 339
					select @message = 'Error al procesar el pago, intente mas tarde.'
					raiserror (@message, 11, 0)
				end catch  -- obtiene saldos

				begin try -- obtiene desglose de monto a pagar inicial para recuperar pago de liquidaci�n y pago al corriente

					if @es_decreciente_destino = 1

						begin -- decrecientes

							exec hape.dbo.sp_cred_obtiene_desglose_monto_a_pagar

								@numero = @numero_destino,
								@id_mov = @id_mov_destino,
								@num_ptmo = @num_ptmo_destino,
								@monto_a_pagar = null,
								@seguro_vida = @seguro_vida_destino,
								@seguro_da�os = @seguro_da�os_destino,
								@int_mor = @int_mor_destino,
								@iva_int_mor = @iva_int_mor_destino,
								@int_ord_ven = @int_ord_ven_destino,
								@iva_int_ord_ven = @iva_int_ord_ven_destino,
								@int_ord_vig = @int_ord_vig_destino,
								@iva_int_ord_vig = @iva_int_ord_vig_destino,
								@cap_ven = @cap_ven_destino,
								@cap_vig = @cap_vig_destino,
								@int_ord_hoy = @int_ord_hoy_destino,
								@iva_int_ord_hoy = @iva_int_ord_hoy_destino,
								@cap_no_dev = @cap_no_dev_destino,
								@fecha = @fechaOperacion

							select	@seguro_vida_destino = coalesce(seguro_vida, 0),
									@seguro_da�os_destino = coalesce(seguro_da�os, 0),
									@int_mor_destino = coalesce(int_mor, 0),
									@iva_int_mor_destino = coalesce(iva_int_mor, 0),
									@int_ord_ven_destino = coalesce(int_ord_ven, 0),
									@iva_int_ord_ven_destino = coalesce(iva_int_ord_ven, 0),
									@int_ord_vig_destino = coalesce(int_ord_vig, 0),
									@iva_int_ord_vig_destino = coalesce(iva_int_ord_vig, 0),
									@cap_ven_destino = coalesce(cap_ven, 0),
									@cap_vig_destino = coalesce(cap_vig, 0),
									@int_ord_hoy_destino = int_ord_hoy,
									@iva_int_ord_hoy_destino = iva_int_ord_hoy,
									@cap_no_dev_destino = coalesce(cap_no_dev, 0),
									@gastos_cobranza_destino = coalesce(gastos_cobranza, 0),
									@iva_gastos_cobranza_destino = coalesce(iva_gastos_cobranza, 0),
									@pago_liquidacion_destino = coalesce(monto_a_pagar, 0)-- + coalesce(saldo_actual, 0)--,
--									@saldo_ahorro_origen = coalesce(saldo_ahorro, 0),
--									@respaldo_ahorro = coalesce(saldo_ahorro, 0),
--									@saldo_inver_origen = coalesce(saldo_inver, 0),
--									@saldo_debito_origen = coalesce(saldo_debito, 0)
							from	#sp_cred_obtiene_desglose_monto_a_pagar

							select	@pago_al_corriente_destino = @seguro_vida_destino + @seguro_da�os_destino + @int_mor_destino + @iva_int_mor_destino
									+ @int_ord_ven_destino + @iva_int_ord_ven_destino + @int_ord_vig_destino + @iva_int_ord_vig_destino + @cap_ven_destino
									+ @cap_vig_destino + @gastos_cobranza_destino + @iva_gastos_cobranza_destino

						end -- decrecientes

					else if @es_nivelado_destino = 1

						begin -- nivelados

							exec hape.dbo.sp_cred_obtiene_desglose_monto_a_pagar_nivelados
								@numero = @numero_destino,
								@id_mov = @id_mov_destino,
								@num_ptmo = @num_ptmo_destino,
								@monto_a_pagar = null,
								@seguro_vida = @seguro_vida_destino,
								@seguro_da�os = @seguro_da�os_destino,
								@fecha = @fechaOperacion

							select	@seguro_vida_destino = coalesce(seguro_vida, 0),
									@seguro_da�os_destino = coalesce(seguro_da�os, 0),
									@int_mor_destino = coalesce(int_mor, 0),
									@iva_int_mor_destino = coalesce(iva_int_mor, 0),
									@int_ord_ven_destino = coalesce(int_ord_ven, 0),
									@iva_int_ord_ven_destino = coalesce(iva_int_ord_ven, 0),
									@int_ord_vig_destino = coalesce(int_ord_vig, 0),
									@iva_int_ord_vig_destino = coalesce(iva_int_ord_vig, 0),
									@cap_ven_destino = coalesce(cap_ven, 0),
									@cap_vig_destino = coalesce(cap_vig, 0),
									@int_ord_hoy_destino = coalesce(int_ord_hoy, 0),
									@iva_int_ord_hoy_destino = coalesce(iva_int_ord_hoy, 0),
									@cap_no_dev_destino = coalesce(cap_no_dev, 0),
									@gastos_cobranza_destino = coalesce(gastos_cobranza, 0),
									@iva_gastos_cobranza_destino = coalesce(iva_gastos_cobranza, 0),
									@pago_liquidacion_destino = coalesce(monto_a_pagar, 0)--,
									--@saldo_ahorro_origen = coalesce(saldo_ahorro, 0),
									--@respaldo_ahorro = coalesce(saldo_ahorro, 0),
									--@saldo_inver_origen = coalesce(saldo_inver, 0),
									--@saldo_debito_origen = coalesce(saldo_debito, 0)
							from	#sp_cred_obtiene_desglose_monto_a_pagar

							select	@pago_al_corriente_destino = @seguro_vida_destino + @seguro_da�os_destino + @int_mor_destino + @iva_int_mor_destino
									+ @int_ord_ven_destino + @iva_int_ord_ven_destino + @int_ord_vig_destino + @iva_int_ord_vig_destino + @cap_ven_destino
									+ @cap_vig_destino + @gastos_cobranza_destino + @iva_gastos_cobranza_destino

						end -- nivelados

					else if @es_revolvente_destino = 1

						begin -- revolventes

							exec hape.dbo.sp_cred_obtiene_desglose_monto_a_pagar

								@numero = @numero_destino,
								@id_mov = @id_mov_destino,
								@num_ptmo = @num_ptmo_destino,
								@monto_a_pagar = null,
								@seguro_vida = @seguro_vida_destino,
								@seguro_da�os = @seguro_da�os_destino,
								@int_mor = @int_mor_destino,
								@iva_int_mor = @iva_int_mor_destino,
								@int_ord_ven = @int_ord_ven_destino,
								@iva_int_ord_ven = @iva_int_ord_ven_destino,
								@int_ord_vig = @int_ord_vig_destino,
								@iva_int_ord_vig = @iva_int_ord_vig_destino,
								@cap_ven = @cap_ven_destino,
								@cap_vig = @cap_vig_destino,
								@int_ord_hoy = @int_ord_hoy_destino,
								@iva_int_ord_hoy = @iva_int_ord_hoy_destino,
								@cap_no_dev = @cap_no_dev_destino,
								@fecha = @fechaOperacion

							select	@seguro_vida_destino = coalesce(seguro_vida, 0),
									@seguro_da�os_destino = coalesce(seguro_da�os, 0),
									@int_mor_destino = coalesce(int_mor, 0),
									@iva_int_mor_destino = coalesce(iva_int_mor, 0),
									@int_ord_ven_destino = coalesce(int_ord_ven, 0),
									@iva_int_ord_ven_destino = coalesce(iva_int_ord_ven, 0),
									@int_ord_vig_destino = coalesce(int_ord_vig, 0),
									@iva_int_ord_vig_destino = coalesce(iva_int_ord_vig, 0),
									@cap_ven_destino = coalesce(cap_ven, 0),
									@cap_vig_destino = coalesce(cap_vig, 0),
									@int_ord_hoy_destino = coalesce(int_ord_hoy, 0),
									@iva_int_ord_hoy_destino = coalesce(iva_int_ord_hoy, 0),
									@cap_no_dev_destino = coalesce(cap_no_dev, 0),
									@gastos_cobranza_destino = coalesce(gastos_cobranza, 0),
									@iva_gastos_cobranza_destino = coalesce(iva_gastos_cobranza, 0),
									@pago_liquidacion_destino = coalesce(monto_a_pagar, 0)--,
									--@saldo_ahorro_origen = coalesce(saldo_ahorro, 0),
									--@respaldo_ahorro = coalesce(saldo_ahorro, 0),
									--@saldo_inver_origen = coalesce(saldo_inver, 0),
									--@saldo_debito_origen = coalesce(saldo_debito, 0)
							from	#sp_cred_obtiene_desglose_monto_a_pagar

							select	@pago_al_corriente_destino = @seguro_vida_destino + @seguro_da�os_destino + @int_mor_destino + @iva_int_mor_destino
									+ @int_ord_ven_destino + @iva_int_ord_ven_destino + @int_ord_vig_destino + @iva_int_ord_vig_destino + @cap_ven_destino
									+ @cap_vig_destino + @gastos_cobranza_destino + @iva_gastos_cobranza_destino

						end -- revolventes 
				end try 
				begin catch 
					print '**Error en obtiene desglose de monto a pagar inicial para recuperar pago de liquidaci�n y pago al corriente----'
					select @status = 339
					select @message = 'Error al procesar el pago, intente mas tarde.'
					raiserror (@message, 11, 0)
				end catch  -- obtiene desglose de monto a pagar inicial para recuperar pago de liquidaci�n y pago al corriente

				begin -- determinantes

					begin -- excedente de liquidaci�n

						if @monto + @saldo_adelanto_destino > @pago_liquidacion_destino

							select @monto = @pago_liquidacion_destino - @saldo_adelanto_destino

					end -- excedente de liquidaci�n

					begin -- liquidaci�n

						if @monto + @saldo_adelanto_destino = @pago_liquidacion_destino

							select @liquida_destino = 1

						else

							select @liquida_destino = 0

					end -- liquidaci�n

					begin -- hay excedente sobre pago al corriente

						if @monto > @pago_al_corriente_destino

							select	@hay_excedente_destino = 1,
									@al_corriente_destino = 1

						else

							select @hay_excedente_destino = 0

					end -- hay excedente sobre pago al corriente


					begin -- pago al corriente

						if @monto !< @pago_al_corriente_destino

							select @al_corriente_destino = 1

						else

							select @al_corriente_destino = 0

					end -- paga justo al corriente

					begin -- ajustar tipo de anticipo si es necesario

						if @liquida_destino = 1

							begin -- ajustar para liquidaci�n

								if @cap_no_dev_destino > 0

									select @TipoAnticipo = 2

								else

									select @TipoAnticipo = 0

							end -- ajustar para liquidaci�n

						else if @hay_excedente_destino = 1 and @TipoAnticipo not in (1, 2, 3)

							begin -- ajustar para excedente no reconocido por default

								select @TipoAnticipo = 1 -------------------- default recorte de amortizaci�n?

							end -- ajustar para excedente no reconocido por default

						else if @hay_excedente_destino = 0 and @TipoAnticipo in (1, 2)

							begin -- ajustar para pago normal

								select @TipoAnticipo = 0

							end -- ajustar para pago normal

					end -- ajustar tipo de anticipo si es necesario

					begin -- ajustar monto necesario que considere el saldo de adelanto para liquidaciones

						select @monto_necesario = @monto + case when @liquida_destino = 1 then @saldo_adelanto_destino else 0 end

					end -- ajustar monto necesario que considere el saldo de adelanto para liquidaciones

					--select	monto = @monto,
					--		monto_necesario = @monto_necesario,
					--		saldo_adelanto = @saldo_adelanto_destino,
					--		pago_liquidacion = @pago_liquidacion_destino,
					--		liquida = @liquida_destino,
					--		hay_excedente_destino = @hay_excedente_destino,
					--		al_corriente_destino = @al_corriente_destino,
					--		tipo_anticipo = @TipoAnticipo
					--		-----------------------------------------------

					------------------------- aqu� me qued�

					--select @monto, @monto_necesario, @saldo_adelanto_destino----------------

				end -- determinantes

				begin try -- obtiene desglose de monto a pagar con proyecci�n del saldado

					if @es_decreciente_destino = 1

						begin -- decrecientes

							exec hape.dbo.sp_cred_obtiene_desglose_monto_a_pagar

								@numero = @numero_destino,
								@id_mov = @id_mov_destino,
								@num_ptmo = @num_ptmo_destino,
								@monto_a_pagar = @monto_necesario,
								@seguro_vida = @seguro_vida_destino,
								@seguro_da�os = @seguro_da�os_destino,
								@int_mor = @int_mor_destino,
								@iva_int_mor = @iva_int_mor_destino,
								@int_ord_ven = @int_ord_ven_destino,
								@iva_int_ord_ven = @iva_int_ord_ven_destino,
								@int_ord_vig = @int_ord_vig_destino,
								@iva_int_ord_vig = @iva_int_ord_vig_destino,
								@cap_ven = @cap_ven_destino,
								@cap_vig = @cap_vig_destino,
								@int_ord_hoy = @int_ord_hoy_destino,
								@iva_int_ord_hoy = @iva_int_ord_hoy_destino,
								@cap_no_dev = @cap_no_dev_destino,
								@fecha = @fechaOperacion

							select	@seguro_vida_saldado = coalesce(seguro_vida, 0),
									@seguro_da�os_saldado = coalesce(seguro_da�os, 0),
									@int_mor_saldado = coalesce(int_mor, 0),
									@iva_int_mor_saldado = coalesce(iva_int_mor, 0),
									@int_ord_ven_saldado = coalesce(int_ord_ven, 0),
									@iva_int_ord_ven_saldado = coalesce(iva_int_ord_ven, 0),
									@int_ord_vig_saldado = coalesce(int_ord_vig, 0),
									@iva_int_ord_vig_saldado = coalesce(iva_int_ord_vig, 0),
									@cap_ven_saldado = coalesce(cap_ven, 0),
									@cap_vig_saldado = coalesce(cap_vig, 0),
									@int_ord_hoy_saldado = int_ord_hoy,
									@iva_int_ord_hoy_saldado = iva_int_ord_hoy,
									@cap_no_dev_saldado = coalesce(cap_no_dev, 0),
									@gastos_cobranza_saldado = coalesce(gastos_cobranza, 0),
									@iva_gastos_cobranza_saldado = coalesce(iva_gastos_cobranza, 0),
									--@saldo_ahorro_origen = coalesce(saldo_ahorro, 0),
									--@respaldo_ahorro = coalesce(saldo_ahorro, 0),
									--@saldo_inver_origen = coalesce(saldo_inver, 0),
									--@saldo_debito_origen = coalesce(saldo_debito, 0),
									@no_asignado_destino = coalesce(no_asignado, 0)
							from	#sp_cred_obtiene_desglose_monto_a_pagar

						end -- decrecientes

					else if @es_nivelado_destino = 1

						begin -- nivelados

							exec hape.dbo.sp_cred_obtiene_desglose_monto_a_pagar_nivelados
								@numero = @numero_destino,
								@id_mov = @id_mov_destino,
								@num_ptmo = @num_ptmo_destino,
								@monto_a_pagar = @monto_necesario,
								@seguro_vida = @seguro_vida_destino,
								@seguro_da�os = @seguro_da�os_destino,
								@fecha = @fechaOperacion

							select	@seguro_vida_saldado = coalesce(seguro_vida, 0),
									@seguro_da�os_saldado = coalesce(seguro_da�os, 0),
									@int_mor_saldado = coalesce(int_mor, 0),
									@iva_int_mor_saldado = coalesce(iva_int_mor, 0),
									@int_ord_ven_saldado = coalesce(int_ord_ven, 0),
									@iva_int_ord_ven_saldado = coalesce(iva_int_ord_ven, 0),
									@int_ord_vig_saldado = coalesce(int_ord_vig, 0),
									@iva_int_ord_vig_saldado = coalesce(iva_int_ord_vig, 0),
									@cap_ven_saldado = coalesce(cap_ven, 0),
									@cap_vig_saldado = coalesce(cap_vig, 0),
									@int_ord_hoy_saldado = int_ord_hoy,
									@iva_int_ord_hoy_saldado = iva_int_ord_hoy,
									@cap_no_dev_saldado = coalesce(cap_no_dev, 0),
									@gastos_cobranza_saldado = coalesce(gastos_cobranza, 0),
									@iva_gastos_cobranza_saldado = coalesce(iva_gastos_cobranza, 0),
									--@saldo_ahorro_origen = coalesce(saldo_ahorro, 0),
									--@respaldo_ahorro = coalesce(saldo_ahorro, 0),
									--@saldo_inver_origen = coalesce(saldo_inver, 0),
									--@saldo_debito_origen = coalesce(saldo_debito, 0),
									@no_asignado_destino = coalesce(no_asignado, 0)
							from	#sp_cred_obtiene_desglose_monto_a_pagar

							IF @no_asignado_destino != 0 and @programada  = 0 /*  incidencia 1011 12 de marzo 2019*/
							BEGIN
								SELECT @message = descripcion , @status = id_excepcion FROM CAT_BANCA_EXCEPTIONS	WHERE id_excepcion = 406
								raiserror (@message, 11, 0)
					
							END

--						select @monto, @monto_necesario -----------


							begin -- ajustar a pagos completos si no hay excedente para anticipar en nivelados

							if @no_asignado_destino > 0 and @liquida_destino = 0 and @hay_excedente_destino = 0 and @TipoAnticipo != 3

								select @monto -= @no_asignado_destino, @monto_necesario -= @no_asignado_destino

							end -- ajustar a pagos completos si no hay excedente para anticipar en nivelados



						end -- nivelados

					else if @es_revolvente_destino = 1

						begin -- revolventes

							exec hape.dbo.sp_cred_obtiene_desglose_monto_a_pagar

								@numero = @numero_destino,
								@id_mov = @id_mov_destino,
								@num_ptmo = @num_ptmo_destino,
								@monto_a_pagar = @monto_necesario,
								@seguro_vida = @seguro_vida_destino,
								@seguro_da�os = @seguro_da�os_destino,
								@int_mor = @int_mor_destino,
								@iva_int_mor = @iva_int_mor_destino,
								@int_ord_ven = @int_ord_ven_destino,
								@iva_int_ord_ven = @iva_int_ord_ven_destino,
								@int_ord_vig = @int_ord_vig_destino,
								@iva_int_ord_vig = @iva_int_ord_vig_destino,
								@cap_ven = @cap_ven_destino,
								@cap_vig = @cap_vig_destino,
								@int_ord_hoy = @int_ord_hoy_destino,
								@iva_int_ord_hoy = @iva_int_ord_hoy_destino,
								@cap_no_dev = @cap_no_dev_destino,
								@fecha = @fechaOperacion

							select	@seguro_vida_saldado = coalesce(seguro_vida, 0),
									@seguro_da�os_saldado = coalesce(seguro_da�os, 0),
									@int_mor_saldado = coalesce(int_mor, 0),
									@iva_int_mor_saldado = coalesce(iva_int_mor, 0),
									@int_ord_ven_saldado = coalesce(int_ord_ven, 0),
									@iva_int_ord_ven_saldado = coalesce(iva_int_ord_ven, 0),
									@int_ord_vig_saldado = coalesce(int_ord_vig, 0),
									@iva_int_ord_vig_saldado = coalesce(iva_int_ord_vig, 0),
									@cap_ven_saldado = coalesce(cap_ven, 0),
									@cap_vig_saldado = coalesce(cap_vig, 0),
									@int_ord_hoy_saldado = int_ord_hoy,
									@iva_int_ord_hoy_saldado = iva_int_ord_hoy,
									@cap_no_dev_saldado = coalesce(cap_no_dev, 0),
									@gastos_cobranza_saldado = coalesce(gastos_cobranza, 0),
									@iva_gastos_cobranza_saldado = coalesce(iva_gastos_cobranza, 0),
									--@saldo_ahorro_origen = coalesce(saldo_ahorro, 0),
									--@respaldo_ahorro = coalesce(saldo_ahorro, 0),
									--@saldo_inver_origen = coalesce(saldo_inver, 0),
									--@saldo_debito_origen = coalesce(saldo_debito, 0),
									@no_asignado_destino = coalesce(no_asignado, 0)
							from	#sp_cred_obtiene_desglose_monto_a_pagar

						end -- revolventes

				end try 
				begin catch 
					print '**Obtiene desglose de monto a pagar con proyecci�n del saldado----'
					select @status = 339
					select @message = 'Error al procesar el pago, intente mas tarde.'
					raiserror (@message, 11, 0)
				end catch -- obtiene desglose de monto a pagar con proyecci�n del saldado

--						select @monto, @monto_necesario -----------


				begin -- revisar ahorro comprometido del origen en caso que sea retiro del ahorro

					if @id_mov_origen = 100

						begin

							select	@ahorro_base_origen = sum(ahorro_base)
							from	(
									select	ahorro_base = cast(coalesce(ahorro_base, 0) as money)
									from	hape.dbo.edo_de_cuenta
									where	numero = @numero_origen
											and id_mov < 100
											and saldo_actual > 0
									) _

							select @ahorro_base_origen = coalesce(@ahorro_base_origen, 0)

							if @ahorro_base_origen > 0

								select @saldo_ahorro_origen -= @ahorro_base_origen

							if @saldo_ahorro_origen < 0

								select @saldo_ahorro_origen = 0

							select @saldo_origen = @saldo_ahorro_origen

						end


				end -- revisar ahorro comprometido del origen en caso que sea retiro del ahorro

				begin -- determinar cantidades a tomar en haberes

					if @id_persona_origen = @id_persona_destino

						begin -- si son cuentas de la misma persona

							select	@monto_tomado_ahorro = 0,
									@monto_tomado_inver = 0,
									@monto_tomado_debito = 0,
									@monto_tomado_efectivo = 0,
									@monto_tomado_adelanto = case when @liquida_destino = 1 then -@saldo_adelanto_destino else 0 end

							if @id_mov_origen = 100

								select	@monto_tomado_ahorro = -@monto
										
							else if @id_mov_origen = 103

								select	@monto_tomado_inver = -@monto

							else if @id_mov_origen = 112

								select	@monto_tomado_debito = -@monto

						end -- si son cuentas de la misma persona

					else

						begin -- no son cuentas de la misma persona

							select	@monto_tomado_ahorro = 0,
									@monto_tomado_inver = 0,
									@monto_tomado_debito = 0,
									@monto_tomado_efectivo = -@monto,
									@monto_tomado_adelanto = case when @liquida_destino = 1 then -@saldo_adelanto_destino else 0 end

						end -- no son cuentas de la misma persona

				end -- determinar cantidades a tomar en haberes

				begin -- determinar gastos de cobranza saldados con inva

					select @gastos_cobranza_mas_iva_saldado = @gastos_cobranza_saldado + @iva_gastos_cobranza_saldado

					select @moratorios_mas_iva_saldado = @int_mor_saldado + @iva_int_mor_saldado

				end -- determinar gastos de cobranza saldados con inva

				begin -- preparar captura adicional en caso de que sea al pago de un socio distinto

					if @id_persona_origen != @id_persona_destino

						begin -- ajuste del titular para el pago a cr�dito

							select @titular_pago = 'F'

						end -- ajuste del titular para el pago a cr�dito

						begin -- si cuenta de origen y cuenta de destino son de distintas personas

							if @programada = 0

								begin -- si no est� programada

									if @id_mov_origen = 100

										begin -- ahorro

											insert	#captura_previo
													(
													id_persona,
													activo,
													numero,
													nombre_s,
													apellido_paterno,
													apellido_materno,
													total_movs,
													total_ficha,
													id_tipomov,
													cuenta,
													concepto,
													fecha_mov,
													monto,
													id_mov,
													num_poliza,
													tipo_poliza,
													folio,
													id_tipo_persona,
													num_cheq,
													desc1,
													desc2,
													planx,
													desc3,
													fecha_dpf_final,
													num_dpf,
													tasa,
													interes,
													dias,
													debe_haber,
													numusuario,
													numero_fin,
													plazo,
													interes_ord,
													interes_mor,
													contador_provision,
													ccostos,
													nombre_beneficiario,
													parentesco_beneficiario,
													porcentaje_beneficiario,
													nombre_beneficiario2,
													parentesco_beneficiario2,
													porcentaje_beneficiario2,
													numero_fin_lacp,
													id_esquema,
													titular,
													num_ptmo,
													id_amortizacion,
													id_renovado,
													reestructura,
													id_origen
													)

											select	id_persona,
													'T',
													p.numero,
													nombre_s,
													apellido_paterno,
													apellido_materno,
													total_movs = 0,
													total_ficha = 0,
													tm.id_tipomov,
													cuenta = cc.num_cuenta,
													concepto = tm.descripcion,
													fecha_mov = @fechaOperacion,
													monto = abs(@monto),
													tm.id_mov,
													num_poliza = @num_poliza,
													tipo_poliza = @tipo_poliza,
													folio = @folio_previo,
													id_tipo_persona = 1,
													num_cheq = 0,
													desc1 = 0,
													desc2 = 0,
													planx = @planx_destino,
													desc3 = 0,
													fecha_dpf_final = cast(@fechaOperacion as date),
													num_dpf = 0,
													tasa = 0,
													interes = 0,
													dias = 0,
													debe_haber = 'D',
													numusuario = @numusuario,
													numero_fin = @numero_fin_destino,
													plazo = @plazo_destino,
													interes_ord = @tasa_ord_destino,
													interes_mor = @tasa_mor_destino,
													contador_provision = 0,
													p.ccostos_origen,
													nombre_beneficiario = '',
													parentesco_beneficiario = '',
													porcentaje_beneficiario = 0,
													nombre_beneficiario2 = '',
													parentesco_beneficiario2 = '',
													porcentaje_beneficiario2 = 0,
													numero_fin_lacp = @numero_fin_lacp_destino,
													id_esquema = 1,
													titular = 'T',
													num_ptmo = @num_ptmo_destino,
													id_amortizacion = @id_amortizacion_destino,
													id_renovado = @id_renovado_destino,
													reestructura = @reestructura_destino,
													id_origen = 3
											from	#persona_ p
													join hape.dbo.tipo_mov tm
														on tm.id_mov = 100
														and tm.id_tipomov = 310
													join hape.dbo.cuentas_contables cc
														on cc.concepto like '%ahorro%socios'
														and cc.num_cuenta like '212%'
										end -- ahorro

									else if @id_mov_origen = 103

										begin -- inverdin�mica

											insert	#captura_previo
													(
													id_persona,
													activo,
													numero,
													nombre_s,
													apellido_paterno,
													apellido_materno,
													total_movs,
													total_ficha,
													id_tipomov,
													cuenta,
													concepto,
													fecha_mov,
													monto,
													id_mov,
													num_poliza,
													tipo_poliza,
													folio,
													id_tipo_persona,
													num_cheq,
													desc1,
													desc2,
													planx,
													desc3,
													fecha_dpf_final,
													num_dpf,
													tasa,
													interes,
													dias,
													debe_haber,
													numusuario,
													numero_fin,
													plazo,
													interes_ord,
													interes_mor,
													contador_provision,
													ccostos,
													nombre_beneficiario,
													parentesco_beneficiario,
													porcentaje_beneficiario,
													nombre_beneficiario2,
													parentesco_beneficiario2,
													porcentaje_beneficiario2,
													numero_fin_lacp,
													id_esquema,
													titular,
													num_ptmo,
													id_amortizacion,
													id_renovado,
													reestructura,
													id_origen
													)

											select	id_persona,
													'T',
													p.numero,
													nombre_s,
													apellido_paterno,
													apellido_materno,
													total_movs = 0,
													total_ficha = 0,
													tm.id_tipomov,
													cuenta = cc.num_cuenta,
													concepto = tm.descripcion,
													fecha_mov = @fechaOperacion,
													monto = abs(@monto),
													tm.id_mov,
													num_poliza = @num_poliza,
													tipo_poliza = @tipo_poliza,
													folio = @folio_previo,
													id_tipo_persona = 1,
													num_cheq = 0,
													desc1 = 0,
													desc2 = 0,
													planx = @planx_destino,
													desc3 = 0,
													fecha_dpf_final = cast(@fechaOperacion as date),
													num_dpf = 0,
													tasa = 0,
													interes = 0,
													dias = 0,
													debe_haber = 'D',
													numusuario = @numusuario,
													numero_fin = @numero_fin_destino,
													plazo = @plazo_destino,
													interes_ord = @tasa_ord_destino,
													interes_mor = @tasa_mor_destino,
													contador_provision = 0,
													p.ccostos_origen,
													nombre_beneficiario = '',
													parentesco_beneficiario = '',
													porcentaje_beneficiario = 0,
													nombre_beneficiario2 = '',
													parentesco_beneficiario2 = '',
													porcentaje_beneficiario2 = 0,
													numero_fin_lacp = @numero_fin_lacp_destino,
													id_esquema = 1,
													titular = 'T',
													num_ptmo = @num_ptmo_destino,
													id_amortizacion = @id_amortizacion_destino,
													id_renovado = @id_renovado_destino,
													reestructura = @reestructura_destino,
													id_origen = 3
											from	#persona_ p
													join hape.dbo.tipo_mov tm
														on tm.id_mov = 103
														and tm.id_tipomov = 350
													join hape.dbo.cuentas_contables cc
														on cc.concepto like '%vista'
														and cc.num_cuenta like '211%'

										end -- inverdin�mica

									else if @id_mov_origen = 112

										begin -- d�bito

											insert	#captura_previo
													(
													id_persona,
													activo,
													numero,
													nombre_s,
													apellido_paterno,
													apellido_materno,
													total_movs,
													total_ficha,
													id_tipomov,
													cuenta,
													concepto,
													fecha_mov,
													monto,
													id_mov,
													num_poliza,
													tipo_poliza,
													folio,
													id_tipo_persona,
													num_cheq,
													desc1,
													desc2,
													planx,
													desc3,
													fecha_dpf_final,
													num_dpf,
													tasa,
													interes,
													dias,
													debe_haber,
													numusuario,
													numero_fin,
													plazo,
													interes_ord,
													interes_mor,
													contador_provision,
													ccostos,
													nombre_beneficiario,
													parentesco_beneficiario,
													porcentaje_beneficiario,
													nombre_beneficiario2,
													parentesco_beneficiario2,
													porcentaje_beneficiario2,
													numero_fin_lacp,
													id_esquema,
													titular,
													num_ptmo,
													id_amortizacion,
													id_renovado,
													reestructura,
													id_origen
													)

											select	id_persona,
													'T',
													p.numero,
													nombre_s,
													apellido_paterno,
													apellido_materno,
													total_movs = 0,
													total_ficha = 0,
													tm.id_tipomov,
													cuenta = cc.num_cuenta,
													concepto = tm.descripcion,
													fecha_mov = @fechaOperacion,
													monto = abs(@monto),
													tm.id_mov,
													num_poliza = @num_poliza,
													tipo_poliza = @tipo_poliza,
													folio = @folio_previo,
													id_tipo_persona = 1,
													num_cheq = 0,
													desc1 = 0,
													desc2 = 0,
													planx = @planx_destino,
													desc3 = 0,
													fecha_dpf_final = cast(@fechaOperacion as date),
													num_dpf = 0,
													tasa = 0,
													interes = 0,
													dias = 0,
													debe_haber = 'D',
													numusuario = @numusuario,
													numero_fin = @numero_fin_destino,
													plazo = @plazo_destino,
													interes_ord = @tasa_ord_destino,
													interes_mor = @tasa_mor_destino,
													contador_provision = 0,
													p.ccostos_origen,
													nombre_beneficiario = '',
													parentesco_beneficiario = '',
													porcentaje_beneficiario = 0,
													nombre_beneficiario2 = '',
													parentesco_beneficiario2 = '',
													porcentaje_beneficiario2 = 0,
													numero_fin_lacp = @numero_fin_lacp_destino,
													id_esquema = 1,
													titular = 'T',
													num_ptmo = @num_ptmo_destino,
													id_amortizacion = @id_amortizacion_destino,
													id_renovado = @id_renovado_destino,
													reestructura = @reestructura_destino,
													id_origen = 3
											from	#persona_ p
													join hape.dbo.tipo_mov tm
														on tm.id_mov = 112
														and tm.id_tipomov = 1001
													join hape.dbo.cuentas_contables cc
														on cc.concepto like 'debito%'
														and cc.num_cuenta like '216%'

										end -- d�bito

									begin -- cajas
										-- se comenta por que no deberia haber flujo de efectivo en las transacciones de banca
										--insert	#captura_previo
										--		(
										--		id_persona,
										--		activo,
										--		numero,
										--		nombre_s,
										--		apellido_paterno,
										--		apellido_materno,
										--		total_movs,
										--		total_ficha,
										--		id_tipomov,
										--		cuenta,
										--		concepto,
										--		fecha_mov,
										--		monto,
										--		id_mov,
										--		num_poliza,
										--		tipo_poliza,
										--		folio,
										--		id_tipo_persona,
										--		num_cheq,
										--		desc1,
										--		desc2,
										--		planx,
										--		desc3,
										--		fecha_dpf_final,
										--		num_dpf,
										--		tasa,
										--		interes,
										--		dias,
										--		debe_haber,
										--		numusuario,
										--		numero_fin,
										--		plazo,
										--		interes_ord,
										--		interes_mor,
										--		contador_provision,
										--		ccostos,
										--		nombre_beneficiario,
										--		parentesco_beneficiario,
										--		porcentaje_beneficiario,
										--		nombre_beneficiario2,
										--		parentesco_beneficiario2,
										--		porcentaje_beneficiario2,
										--		numero_fin_lacp,
										--		id_esquema,
										--		titular,
										--		num_ptmo,
										--		id_amortizacion,
										--		id_renovado,
										--		reestructura,
										--		id_origen
										--		)

										--select	id_persona,
										--		'T',
										--		p.numero,
										--		nombre_s,
										--		apellido_paterno,
										--		apellido_materno,
										--		total_movs = 0,
										--		total_ficha = 0,
										--		id_tipomov = 961,
										--		cuenta = cc.num_cuenta,
										--		concepto = 'Cajas',
										--		fecha_mov = @fechaOperacion,
										--		monto = 0.0,--abs(@monto),
										--		id_mov = null,
										--		num_poliza = @num_poliza,
										--		tipo_poliza = @tipo_poliza,
										--		folio = @folio_previo,
										--		id_tipo_persona = 1,
										--		num_cheq = 0,
										--		desc1 = 0,
										--		desc2 = 0,
										--		planx = @planx_destino,
										--		desc3 = 0,
										--		fecha_dpf_final = cast(@fechaOperacion as date),
										--		num_dpf = 0,
										--		tasa = 0,
										--		interes = 0,
										--		dias = 0,
										--		debe_haber = 'H',
										--		numusuario = @numusuario,
										--		numero_fin = @numero_fin_destino,
										--		plazo = @plazo_destino,
										--		interes_ord = @tasa_ord_destino,
										--		interes_mor = @tasa_mor_destino,
										--		contador_provision = 0,
										--		p.ccostos_origen,
										--		nombre_beneficiario = '',
										--		parentesco_beneficiario = '',
										--		porcentaje_beneficiario = 0,
										--		nombre_beneficiario2 = '',
										--		parentesco_beneficiario2 = '',
										--		porcentaje_beneficiario2 = 0,
										--		numero_fin_lacp = @numero_fin_lacp_destino,
										--		id_esquema = 1,
										--		titular = 'T',
										--		num_ptmo = @num_ptmo_destino,
										--		id_amortizacion = @id_amortizacion_destino,
										--		id_renovado = @id_renovado_destino,
										--		reestructura = @reestructura_destino,
										--		id_origen = 3
										--from	#persona_ p
										--		join hape.dbo.cuentas_contables cc
										--			on concepto like 'caja'
										--			and num_cuenta like '111%'
										
										-- cta compensacion sucursal destino en lugar del registro de flujo de efectivo
										insert	#captura_previo
												(
												id_persona,
												activo,
												numero,
												nombre_s,
												apellido_paterno,
												apellido_materno,
												total_movs,
												total_ficha,
												id_tipomov,
												cuenta,
												concepto,
												fecha_mov,
												monto,
												id_mov,
												num_poliza,
												tipo_poliza,
												folio,
												id_tipo_persona,
												num_cheq,
												desc1,
												desc2,
												planx,
												desc3,
												fecha_dpf_final,
												num_dpf,
												tasa,
												interes,
												dias,
												debe_haber,
												numusuario,
												numero_fin,
												plazo,
												interes_ord,
												interes_mor,
												contador_provision,
												ccostos,
												nombre_beneficiario,
												parentesco_beneficiario,
												porcentaje_beneficiario,
												nombre_beneficiario2,
												parentesco_beneficiario2,
												porcentaje_beneficiario2,
												numero_fin_lacp,
												id_esquema,
												titular,
												num_ptmo,
												id_amortizacion,
												id_renovado,
												reestructura,
												id_origen
												)

										select	id_persona,
												'T',
												p.numero,
												nombre_s,
												apellido_paterno,
												apellido_materno,
												total_movs = 0,
												total_ficha = 0,
												id_tipomov = 0,
												cuenta = @cta_contable_suc_destino,
												concepto = @des_contable_suc_destino,--'Dep�sito al  Ahorro CMV',
												fecha_mov = @fechaOperacion,
												monto = abs(@monto),
												id_mov = null,
												num_poliza = @num_poliza,
												tipo_poliza = @tipo_poliza,
												folio = @folio_previo,
												id_tipo_persona = 1,
												num_cheq = 0,
												desc1 = 0,
												desc2 = 0,
												planx = @planx_destino,
												desc3 = 0,
												fecha_dpf_final = cast(@fechaOperacion as date),
												num_dpf = 0,
												tasa = 0,
												interes = 0,
												dias = 0,
												debe_haber = 'H',
												numusuario = @numusuario,
												numero_fin = @numero_fin_destino,
												plazo = @plazo_destino,
												interes_ord = @tasa_ord_destino,
												interes_mor = @tasa_mor_destino,
												contador_provision = 0,
												p.ccostos_origen,
												nombre_beneficiario = '',
												parentesco_beneficiario = '',
												porcentaje_beneficiario = 0,
												nombre_beneficiario2 = '',
												parentesco_beneficiario2 = '',
												porcentaje_beneficiario2 = 0,
												numero_fin_lacp = @numero_fin_lacp_destino,
												id_esquema = 1,
												titular = 'T',
												num_ptmo = @num_ptmo_destino,
												id_amortizacion = @id_amortizacion_destino,
												id_renovado = @id_renovado_destino,
												reestructura = @reestructura_destino,
												id_origen = 3
										from	#persona_ p

									end -- cajas


									begin -- actualizar totales

										update	c
										set		c.total_movs = _.count_,
												c.total_ficha = abs(@monto)
										from	(
												select	count(1) count_
												from	#captura_previo
												) _
												cross join #captura_previo c

									end -- actualizar totales

								end -- si no est� programada

						end -- si cuenta de origen y cuenta de destino son de distintas personas

				end -- preparar captura adicional en caso de que sea al pago de un socio distinto

				--select * from #captura_previo

				-- BREAKPOINT

				--select	pago_al_corriente = @pago_al_corriente_destino, pago_liquidacion = @pago_liquidacion_destino,
				--		numero = @numero_destino, id_mov = @id_mov_destino, num_ptmo = @num_ptmo_destino,
				--		seguro_vida = @seguro_vida_destino, seguro_da�os = @seguro_da�os_destino, int_mor = @int_mor_destino,
				--		iva_int_mor = @iva_int_mor_destino, int_ord_ven = @int_ord_ven_destino, iva_int_ord_ven = @iva_int_ord_ven_destino,
				--		int_ord_vig = @int_ord_vig_destino, iva_int_ord_vig = @iva_int_ord_vig_destino, cap_ven = @cap_ven_destino,
				--		cap_vig = @cap_vig_destino, int_ord_hoy = @int_ord_hoy_destino, iva_int_ord_hoy = @iva_int_ord_hoy_destino,
				--		cap_no_dev = @cap_no_dev_destino, gastos_cobranza = @gastos_cobranza_destino, iva_gastos_cobranza = @iva_gastos_cobranza_destino,
				--		fecha = @fechaOperacion, saldo_adelanto_destino = @saldo_adelanto_destino, saldo_ahorro_disponible_origen = @saldo_ahorro_origen,
				--		saldo_ahorro_comprometido_origen = @ahorro_base_origen, saldo_inver_origen = @saldo_inver_origen, saldo_debito_origen = @saldo_debito_origen,
				--		seguro_vida_saldado = @seguro_vida_saldado, seguro_da�os_saldado = @seguro_da�os_saldado, int_mor_saldado = @int_mor_saldado,
				--		iva_int_mor_saldado = @iva_int_mor_saldado, int_ord_ven_saldado = @int_ord_ven_saldado, iva_int_ord_ven_saldado = @iva_int_ord_ven_saldado,
				--		int_ord_vig = @int_ord_vig_destino, iva_int_ord_vig = @iva_int_ord_vig_destino, cap_ven = @cap_ven_destino,
				--		cap_vig_saldado = @cap_vig_saldado, int_ord_hoy_saldado = @int_ord_hoy_saldado, iva_int_ord_hoy_saldado = @iva_int_ord_hoy_saldado,
				--		cap_no_dev_saldado = @cap_no_dev_saldado, gastos_cobranza_saldado = @gastos_cobranza_saldado,
				--		iva_gastos_cobranza_saldado = @iva_gastos_cobranza_saldado, no_asignado_destino = @no_asignado_destino,
				--		monto = @monto, monto_necesario = @monto_necesario, liquida = @liquida_destino, hay_excedente = @hay_excedente_destino,
				--		al_corriente = @al_corriente_destino, tipo_anticipo = @TipoAnticipo,
				--		monto_tomado_ahorro = @monto_tomado_ahorro, monto_tomado_inver = @monto_tomado_inver, monto_tomado_debito = @monto_tomado_debito,
				--		monto_tomado_efectivo = @monto_tomado_efectivo, monto_tomado_adelanto = @monto_tomado_adelanto
				--		----------------------------------------------------

				--select dec = @es_decreciente, niv = @es_nivelado, rev = @es_revolvente

				--begin -- preparar montos de cuentas de haberes

				--	if @id_mov_origen = 100

				--		begin -- del ahorro

				--			select	@retiro_ahorro_total = -@monto,
				--					@retiro_inver_total = 0,
				--					@retiro_debito_total = 0

				--		end -- del ahorro

				--	else if @id_mov_origen = 103

				--		begin -- de inverdin�mica

				--			select	@retiro_ahorro_total = 0,
				--					@retiro_inver_total = -@monto,
				--					@retiro_debito_total = 0

				--		end -- de inverdin�mica

				--	else if @id_mov_origen = 112

				--		begin -- de d�bito

				--			select	@retiro_ahorro_total = 0,
				--					@retiro_inver_total = 0,
				--					@retiro_debito_total = -@monto

				--		end -- de d�bito

				--	if @numero_origen != @numero_destino

				--		begin -- si es dep�sito a otro socio

				--			select	@retiro_ahorro_total = 0,
				--					@retiro_inver_total = 0,
				--					@retiro_debito_total = 0,
				--					@efectivo = -@monto,
				--					@titular_destino = 'F'

				--		end -- si es dep�sito a otro socio

				--	else

				--		select	@efectivo = 0

				--	--select @retiro_ahorro_total, @retiro_inver_total, @retiro_debito_total, @efectivo, @id_mov_origen, @id_mov_destino, @monto

				--end -- preparar montos de cuentas de haberes

			end -- preparaci�n

			begin -- validaciones de preparaci�n
			
				if @id_mov_origen not in(100, 103, 112)

					begin 

						select @status = 379
						select @message = 'La clabe [' + @clabeCorresponsaliasRetiro + '] de corresponsal�as no est� asociada a una cuenta de haberes'
						raiserror (@message, 11, 0)

					end 

				if @id_mov_destino !< 100

					begin 

						select @status = 359
						select @message = 'La clabe [' + @clabeCorresponsaliasDeposito + '] de corresponsal�as no est� asociada a un pr�stamo'
						raiserror (@message, 11, 0)

					end

				--select @saldo_origen, @monto------------------------

				if @saldo_origen < @monto and @programada = 0

					begin

						select @status = 329
						select @message = 'Saldo insuficiente'
						raiserror (@message, 11, 0)

					end

				if @saldo_destino < 0.01

					begin

						select @status = 380
						select @message = 'El pr�stamo no esta vigente'
						raiserror (@message, 11, 0)

					end

			end -- validaciones de preparaci�n
			
			begin -- transacci�n

				begin -- inicio

					if @tran_count = 0
						begin tran @tran_name
					else
						save tran @tran_name
				
					select @tran_scope = 1
				
				end -- inicio

				begin -- revisar saldos de haberes

					if not exists (select 1 from hape.dbo.edo_de_cuenta where numero = @numero_origen and id_mov = @id_mov_origen and saldo_actual = case when @id_mov_origen = 100 then @respaldo_ahorro else @saldo_origen end)

						begin

							select @status = 329-------------------------- qu� status le doy a este error?

							raiserror ('Una transacci�n previa ha afectado los saldos, revise los saldos y en caso necesario, aplique nuevamente la transacci�n', 11, 0)

						end

				end -- revisar saldos de haberes
				
				begin -- generar folio

					if (@id_transferencia is null)
					begin
						insert	tbl_banca_folios
								(numero_socio, fecha_alta)
						values	(@numero_origen, @fecha_sistema)
											
						/*if @numero_origen != @numero_destino
							begin

								select	@folio_previo = max(id_banca_folio)
								from	tbl_banca_folios	
								where	numero_socio = @numero_origen

								insert	tbl_banca_folios
										(numero_socio, fecha_alta)
								values	(@numero_origen, @fecha_sistema)

							end
						*/
						select	@folio = max(id_banca_folio)
						from	tbl_banca_folios	
						where	numero_socio = @numero_origen
					end
					else
					begin
						SELECT @folio = id_banca_folio FROM TBL_BANCA_TRANSFERENCIAS_INTERNAS WHERE id_transferencia = @id_transferencia
					end
						
					set @folio_previo =@folio

				end -- generar folio

				--Modifico aoaj720209 Se registra en la bitacora solamente si el pago no viene de una domicilicion
				if(coalesce(@id_domiciliacion,0)=0)
				begin 
		
				begin -- registrar en bit�cora

					if @pago_mismo_socio = 0 -- si el pago del prestamo es a otro socio
						set @id_tipo_bitacora =50

					IF @programada = 1
						set @id_tipo_bitacora =24

                    if (@id_transferencia is null or @id_transferencia = 0) -- se anexa para q solo lo haga una ocasion
					begin

						select @id_tipo_bitacora =  case 
														when @pago_mismo_socio = 1 and @programada  = 0 then  23
														when @pago_mismo_socio = 1 and @programada  = 1 then  24
														when @pago_mismo_socio = 0 and @programada  = 0 then  50
														when @pago_mismo_socio = 0 and @programada  = 1 then  86
													end

						insert	tbl_banca_bitacora_operaciones
								(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
						values	(@folio, @id_tipo_bitacora, @numero_origen, @fecha_sistema, @tipoOrigen)

					    if (@programada = 0)
						begin 
							--- PARA NOTIFICAR DEL RETIRO  AL SOCIO DE LA CUENTA ORIGEN
							select @id_tipo_bitacora = case when  @id_mov_origen = 100 then  52
															when  @id_mov_origen = 103 then  51
															when  @id_mov_origen = 112 then  53
														end
					
							insert	tbl_banca_bitacora_operaciones
									(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							values	(@folio, @id_tipo_bitacora, @numero_origen, @fecha_sistema, @tipoOrigen)
					  end
					end
					else
					begin
							select @id_tipo_bitacora =  case 
															when @pago_mismo_socio = 1 and @programada  = 0 then  23
															when @pago_mismo_socio = 0 and @programada  = 0 then  50
														end							
						  

							insert	tbl_banca_bitacora_operaciones
									(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							values	(@folio, @id_tipo_bitacora, @numero_origen, @fecha_sistema, @tipoOrigen)

							select @id_tipo_bitacora = case 
															when  @id_mov_origen = 100 then  52
															when  @id_mov_origen = 103 then  51
															when  @id_mov_origen = 112 then  53
													   end
							insert	tbl_banca_bitacora_operaciones
									(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							values	(@folio, @id_tipo_bitacora, @numero_origen, @fecha_sistema, @tipoOrigen)
					end

				end -- registrar en bit�cora

				end

				begin -- recopilar cuentas internas

					select	@id_cuenta_origen = id_cuenta_interna
					from	tbl_banca_cuentas_internas
					where	clabe_corresponsalias = @clabeCorresponsaliasRetiro

					select	@id_cuenta_destino =
								case
									when @numero_origen != @numero_destino
										then id_cuenta_interna
									else
										null
								end
					from	tbl_banca_cuentas_internas
					where	clabe_corresponsalias = @clabeCorresponsaliasDeposito
					and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero_origen

				end -- recopilar cuentas internas

				begin -- insertar en tbl_banca_transferencias_internas

					if @id_transferencia is null

						begin

							insert tbl_banca_transferencias_internas	
								(
								id_cuenta_interna,
								monto,
								fecha_alta_transferencia,
								fecha_transferencia_realizada,
								id_estatus_transferencia,
								numero_socio,
								fecha_programada,
								id_banca_folio,
								clave_corresponsalias_origen,
								clave_corresponsalias_destino,
								programada,
								id_domiciliacion
								)
							values
								(
								@id_cuenta_destino,
							   case when @programada = 1  /*incidencia 1012  12 de marzo 2019*/
										then @MontoOriginalTransaccion 
									 else @monto 
							    end,
								@fecha_sistema,
								case
									when @programada = 1
										then null
									else @fecha_sistema
								end,
								case
									when @programada = 1
										then 1
									else 2
								end,
								BANCA.dbo.FN_BANCA_CIFRAR(@numero_origen),
								case
									when @programada = 1
										then @horaProgramada
									else null
								end,
								@folio,
								@clabeCorresponsaliasRetiro,
								@clabeCorresponsaliasDeposito,
								@programada,
								@id_domiciliacion
								)

						end

				end -- insertar en tbl_banca_transferencias_internas

				if @programada = 0

					begin -- si no est� programada, se aplica de inmediato

						if @id_persona_origen != @id_persona_destino

							begin -- afectar haberes de socio distinto

								begin -- captura

									insert	hape.dbo.captura
											(
											id_persona,
											activo,
											numero,
											nombre_s,
											apellido_paterno,
											apellido_materno,
											total_movs,
											total_ficha,
											id_tipomov,
											cuenta,
											concepto,
											fecha_mov,
											monto,
											id_mov,
											num_poliza,
											tipo_poliza,
											folio,
											id_tipo_persona,
											num_cheq,
											desc1,
											desc2,
											planx,
											desc3,
											fecha_dpf_final,
											num_dpf,
											tasa,
											interes,
											dias,
											debe_haber,
											numusuario,
											numero_fin,
											plazo,
											interes_ord,
											interes_mor,
											contador_provision,
											ccostos,
											nombre_beneficiario,
											parentesco_beneficiario,
											porcentaje_beneficiario,
											nombre_beneficiario2,
											parentesco_beneficiario2,
											porcentaje_beneficiario2,
											numero_fin_lacp,
											id_esquema,
											titular,
											num_ptmo,
											id_amortizacion,
											id_renovado,
											reestructura,
											id_origen,
											id_tipo_pago_prestamo
											)
									select	id_persona,
											activo,
											numero,
											nombre_s,
											apellido_paterno,
											apellido_materno,
											total_movs,
											total_ficha,
											id_tipomov,
											cuenta,
											concepto,
											fecha_mov,
											monto,
											id_mov,
											num_poliza,
											tipo_poliza,
											@folio_previo,
											id_tipo_persona,
											num_cheq,
											desc1,
											desc2,
											planx,
											desc3,
											fecha_dpf_final,
											num_dpf,
											tasa,
											interes,
											dias,
											debe_haber,
											numusuario,
											numero_fin,
											plazo,
											interes_ord,
											interes_mor,
											contador_provision,
											ccostos,
											nombre_beneficiario,
											parentesco_beneficiario,
											porcentaje_beneficiario,
											nombre_beneficiario2,
											parentesco_beneficiario2,
											porcentaje_beneficiario2,
											numero_fin_lacp,
											id_esquema,
											titular,
											num_ptmo,
											id_amortizacion,
											id_renovado,
											reestructura,
											id_origen,
											id_tipo_pago_prestamo
									from	#captura_previo
									order by
											contador

								end -- captura

								begin -- captura_lacp

									insert	hape.dbo.captura_lacp
											(
											id_persona,
											activo,
											numero,
											nombre_s,
											apellido_paterno,
											apellido_materno,
											total_movs,
											total_ficha,
											id_tipomov,
											cuenta,
											concepto,
											fecha_mov,
											monto,
											id_mov,
											num_poliza,
											tipo_poliza,
											folio,
											id_tipo_persona,
											num_cheq,
											desc1,
											desc2,
											planx,
											desc3,
											fecha_dpf_final,
											num_dpf,
											tasa,
											interes,
											dias,
											debe_haber,
											numusuario,
											numero_fin,
											plazo,
											interes_ord,
											interes_mor,
											contador_provision,
											ccostos,
											nombre_beneficiario,
											parentesco_beneficiario,
											porcentaje_beneficiario,
											nombre_beneficiario2,
											parentesco_beneficiario2,
											porcentaje_beneficiario2,
											numero_fin_lacp,
											id_esquema,
											titular,
											num_ptmo,
											id_amortizacion,
											id_renovado,
											reestructura,
											id_origen,
											id_tipo_pago_prestamo
											)
									select	id_persona,
											activo,
											numero,
											nombre_s,
											apellido_paterno,
											apellido_materno,
											total_movs,
											total_ficha,
											id_tipomov,
											cuenta,
											concepto,
											fecha_mov,
											monto,
											id_mov,
											num_poliza,
											tipo_poliza,
											@folio_previo,
											id_tipo_persona,
											num_cheq,
											desc1,
											desc2,
											planx,
											desc3,
											fecha_dpf_final,
											num_dpf,
											tasa,
											interes,
											dias,
											debe_haber,
											numusuario,
											numero_fin,
											plazo,
											interes_ord,
											interes_mor,
											contador_provision,
											ccostos,
											nombre_beneficiario,
											parentesco_beneficiario,
											porcentaje_beneficiario,
											nombre_beneficiario2,
											parentesco_beneficiario2,
											porcentaje_beneficiario2,
											numero_fin_lacp,
											id_esquema,
											titular,
											num_ptmo,
											id_amortizacion,
											id_renovado,
											reestructura,
											id_origen,
											id_tipo_pago_prestamo
									from	#captura_previo
									order by
											contador

								end -- captura_lacp

								begin -- insertar en movimientos

									insert	hape.dbo.movimientos
											(
											numero,
											activo,
											fecha_mov,
											monto,
											saldo,
											tipo_poliza,
											num_poliza,
											folio,
											fecha_alta,
											interes_ord,
											interes_mor,
											plazo,
											numero_fin,
											id_persona,
											numusuario,
											id_tipomov,
											fecha_dpf_final,
											num_dpf,
											tasa_dpf,
											interes_dpf,
											dias,
											id_mov,
											id_tipo_persona,
											numero_fin_lacp,
											reestructura,
											id_motivo_reestructura,
											id_esquema,
											id_convenio,
											id_amortizacion,
											titular,
											planx,
											num_ptmo,
											id_nomina,
											id_esquema_nomina,
											id_renovado,
											id_origen,
											id_tipo_pago_prestamo
											)
									select	c.numero,
											c.activo,
											fecha_mov,
											monto,
											saldo = 0,
											tipo_poliza,
											num_poliza,
											folio = @folio_previo,
											fecha_alta = @fechaOperacion,
											interes_ord,
											interes_mor,
											c.plazo,
											c.numero_fin,
											c.id_persona,
											numusuario,
											id_tipomov,
											fecha_dpf_final,
											num_dpf,
											tasa_dpf = 0,
											interes_dpf = 0,
											dias,
											c.id_mov,
											c.id_tipo_persona,
											c.numero_fin_lacp,
											reestructura,
											id_motivo_reestructura = null,
											c.id_esquema,
											id_convenio = null,
											c.id_amortizacion,
											titular,
											c.planx,
											c.num_ptmo,
											null id_nomina,
											null id_esquema_nomina,
											c.id_renovado,
											id_origen,
											id_tipo_pago_prestamo
									from	#captura_previo c
									where	id_tipomov not in (961, 701, 702, 0)

								end -- insertar en movimientos

								begin -- actualizar saldo en movimientos

									select	identity(int, 1, 1) id,
											cast(m.contador as int) contador,
											m.numero,
											m.id_mov,
											monto,
											saldo_antes = cast(null as money),
											saldo_despues = cast(null as money),
											operacion = -1
									into	#saldos_movimientos_previo
									from	hape.dbo.movimientos m
									where	numusuario = @numusuario
											and folio = @folio_previo
											and cast(fecha_mov as date) = cast(@fechaOperacion as date)
											and num_poliza = @num_poliza
											and m.id_mov !< 100

									update	u
									set		saldo_antes = __.saldo,
											saldo_despues = __.saldo + operacion * monto
									from	(
											select	_.*, cta.saldo_actual saldo
											from	hape.dbo.edo_de_cuenta cta
													join
														(							
														select	min(sm.contador) contador, sm.numero, sm.id_mov
														from	#saldos_movimientos_previo sm
														group by sm.numero, sm.id_mov
														) _
														on _.numero = cta.numero
														and _.id_mov = cta.id_mov
											) __
											join #saldos_movimientos_previo u
												on u.contador = __.contador

									while exists
										(
										select	1
										from	#saldos_movimientos_previo sm1
												join #saldos_movimientos_previo sm2
													on sm2.id = sm1.id + 1
													and sm2.numero = sm1.numero
													and sm2.id_mov = sm1.id_mov
													and sm2.saldo_antes is null
										)

									update	sm2
									set		saldo_antes = sm1.saldo_despues,
											saldo_despues = sm1.saldo_despues + sm2.operacion * sm2.monto
									from	#saldos_movimientos_previo sm1
											join #saldos_movimientos_previo sm2
												on sm2.id = sm1.id + 1
												and sm2.numero = sm1.numero
												and sm2.id_mov = sm1.id_mov
												and sm2.saldo_antes is null

									update	m
									set		saldo = sm.saldo_despues
									from	hape.dbo.movimientos m
											join #saldos_movimientos_previo sm
												on sm.numero = m.numero
												and sm.contador = m.contador

								end -- actualizar saldo en movimientos

								begin -- actualizar edo_de_cuenta

									if @id_mov_origen = 100

										update	#actualiza_edo_de_cuenta_haberes_previo
										set		diferencia = -@monto_necesario,
												saldo_posterior = saldo_anterior - @monto_necesario
										where	id_mov = 100

									if @id_mov_origen = 103

										update	#actualiza_edo_de_cuenta_haberes_previo
										set		diferencia = -@monto_necesario,
												saldo_posterior = saldo_anterior - @monto_necesario
										where	id_mov = 103

									if @id_mov_origen = 112

										update	#actualiza_edo_de_cuenta_haberes_previo
										set		diferencia = -@monto_necesario,
												saldo_posterior = saldo_anterior - @monto_necesario
										where	id_mov = 112

									update	#actualiza_edo_de_cuenta_haberes_previo
									set		diferencia = coalesce(diferencia, 0),
											saldo_posterior = coalesce(saldo_posterior, 0)

									update	cta
									set		saldo_actual = ae.saldo_posterior,
											fecha = ae.fecha
									from	#actualiza_edo_de_cuenta_haberes_previo ae
											join hape.dbo.edo_de_cuenta cta
												on cta.numero = ae.numero
												and cta.id_mov = ae.id_mov
												and ae.diferencia != 0

								end -- actualizar edo_de_cuenta

							end -- afectar afectar haberes de socio distinto

						begin -- afectar pago a cr�dito

							--select @es_nivelado_destino ----------------------------
							print '@es_decreciente_destino :'+ cast(@es_decreciente_destino as varchar)
							if @es_decreciente_destino = 1

								begin try -- decrecientes

									if @TipoAnticipo != 3

										begin -- no es adelanto

											--select  numero = @numero_destino,
											--		id_mov = @id_mov_destino,
											--		int_mor = @int_mor_saldado,
											--		iva_int_mor = @iva_int_mor_saldado,
											--		int_ord_ven = @int_ord_ven_saldado,
											--		iva_int_ord_ven = @iva_int_ord_ven_saldado,
											--		int_ord_vig = @int_ord_vig_saldado,
											--		iva_int_ord_vig = @iva_int_ord_vig_saldado,
											--		capital_vencido = @cap_ven_saldado,
											--		capital_vigente = @cap_vig_saldado,
											--		capital_no_devengado = @cap_no_dev_saldado,
											--		numusuario = @numusuario,
											--		num_poliza = @num_poliza,
											--		folio = @folio,
											--		tipo_poliza = @tipo_poliza,
											--		contador_provision = 0,
											--		titular = @titular_pago,
											--		ahorro = @monto_tomado_ahorro,
											--		inverdinamica = @monto_tomado_inver,
											--		debito = @monto_tomado_debito,
											--		saldo_adelanto = @monto_tomado_adelanto,
											--		saldo_cuenta_contable = 0,
											--		cuenta_contable = '',
											--		efectivo = @monto_tomado_efectivo,
											--		gastos_cobranza = @gastos_cobranza_mas_iva_saldado,
											--		id_origen = 3,
											--		id_tipo_persona = 1,
											--		fecha = @fechaOperacion,
											--		id_tipo_pago_prestamo = @TipoAnticipo
											
											-----------------------

											exec hape.dbo.SP_INTERES_DIARIO_REALIZA_PAGO_DECRECIENTE 

												@numero = @numero_destino,
												@id_mov = @id_mov_destino,
												@int_mor = @int_mor_saldado,
												@iva_int_mor = @iva_int_mor_saldado,
												@int_ord_ven = @int_ord_ven_saldado,
												@iva_int_ord_ven = @iva_int_ord_ven_saldado,
												@int_ord_vig = @int_ord_vig_saldado,
												@iva_int_ord_vig = @iva_int_ord_vig_saldado,
												@capital_vencido = @cap_ven_saldado,
												@capital_vigente = @cap_vig_saldado,
												@capital_no_devengado = @cap_no_dev_saldado,
												@numusuario = @numusuario,
												@num_poliza = @num_poliza,
												@folio = @folio,
												@tipo_poliza = @tipo_poliza,
												@contador_provision = 0,
												@titular = @titular_pago,
												@ahorro = @monto_tomado_ahorro,
												@inverdinamica = @monto_tomado_inver,
												@debito = @monto_tomado_debito,
												@saldo_adelanto = @monto_tomado_adelanto,
												@saldo_cuenta_contable = 0,
												@cuenta_contable = '',
												@efectivo = @monto_tomado_efectivo,
												@gastos_cobranza = @gastos_cobranza_mas_iva_saldado,
												@id_origen = 3,
												@id_tipo_persona = 1,
												@fecha = @fechaOperacion,
												@id_tipo_pago_prestamo = @TipoAnticipo

										end -- no es adelanto

								else if @TipoAnticipo = 3

									begin -- es adelanto

										exec hape.dbo.SP_INTERES_DIARIO_REALIZA_PAGO_DECRECIENTE 

											@numero = @numero_destino,
											@id_mov = @id_mov_destino,
											@int_mor = 0,
											@iva_int_mor = 0,
											@int_ord_ven = 0,
											@iva_int_ord_ven = 0,
											@int_ord_vig = 0,
											@iva_int_ord_vig = 0,
											@capital_vencido = 0,
											@capital_vigente = 0,
											@capital_no_devengado = 0,
											@numusuario = @numusuario,
											@num_poliza = @num_poliza,
											@folio = @folio,
											@tipo_poliza = @tipo_poliza,
											@contador_provision = 0,
											@titular = @titular_pago,
											@ahorro = @monto_tomado_ahorro,
											@inverdinamica = @monto_tomado_inver,
											@debito = @monto_tomado_debito,
											@saldo_adelanto = @monto_necesario,
											@saldo_cuenta_contable = 0,
											@cuenta_contable = '',
											@efectivo = @monto_tomado_efectivo,
											@gastos_cobranza = @gastos_cobranza_mas_iva_saldado,
											@id_origen = 3,
											@id_tipo_persona = 1,
											@fecha = @fechaOperacion,
											@id_tipo_pago_prestamo = @TipoAnticipo

									end -- es adelanto

								end try 
								begin catch 
									print '**Error en SP_INTERES_DIARIO_REALIZA_PAGO_DECRECIENTE ----'
									select @status = 339
									select @message = 'Error al procesar el pago, intente mas tarde.'
									raiserror (@message, 11, 0)
								end catch -- decrecientes

							else if @es_nivelado_destino = 1

								begin try -- es nivelado

									--select @TipoAnticipo-----------------------

									if @TipoAnticipo != 3

										begin -- no es adelanto

											exec HAPE.dbo.sp_interes_diario_realiza_pago_nivelado
												@numero = @numero_destino,
												@id_mov = @id_mov_destino,
												@pago_total = @monto_necesario,
												@numusuario = @numusuario,
												@num_poliza = @num_poliza,
												@folio = @folio,
												@tipo_poliza = @tipo_poliza,
												@contador_provision = 0,
												@titular = @titular_pago,
												@ahorro = @monto_tomado_ahorro,
												@inverdinamica = @monto_tomado_inver,
												@debito = @monto_tomado_debito,
												@saldo_adelanto = @monto_tomado_adelanto,
												@saldo_cuenta_contable = 0,
												@cuenta_contable = '',
												@efectivo = @monto_tomado_efectivo,
												@gastos_cobranza = @gastos_cobranza_mas_iva_saldado,
												@id_origen = 3,
												@id_tipo_persona = 1,
												@fecha = @fechaOperacion,
												@id_tipo_pago_prestamo = @TipoAnticipo,
												@moratorios_e_iva = @moratorios_mas_iva_saldado

										end -- no es adelanto

									else if @TipoAnticipo = 3

										begin -- es adelanto

											--select 'ENTRA' ----------------------

											--select
											--	[@numero] = @numero_destino,
											--	[@id_mov] = @id_mov_destino,
											--	[@pago_total] = 0,
											--	[@numusuario] = @numusuario,
											--	[@num_poliza] = @num_poliza,
											--	[@folio] = @folio,
											--	[@tipo_poliza] = @tipo_poliza,
											--	[@contador_provision] = 0,
											--	[@titular] = @titular_pago,
											--	[@ahorro] = @monto_tomado_ahorro,
											--	[@inverdinamica] = @monto_tomado_inver,
											--	[@debito] = @monto_tomado_debito,
											--	[@saldo_adelanto] = @monto_necesario,
											--	[@saldo_cuenta_contable] = 0,
											--	[@cuenta_contable] = '',
											--	[@efectivo] = @monto_tomado_efectivo,
											--	[@gastos_cobranza] = @gastos_cobranza_mas_iva_saldado,
											--	[@id_origen] = 3,
											--	[@id_tipo_persona] = 1,
											--	[@fecha] = @fechaOperacion,
											--	[@id_tipo_pago_prestamo] = @TipoAnticipo,
											--	[@moratorios_e_iva] = 0,
											--	[@monto] = @monto
												
												----------------------

											exec HAPE.dbo.sp_interes_diario_realiza_pago_nivelado
												@numero = @numero_destino,
												@id_mov = @id_mov_destino,
												@pago_total = 0,
												@numusuario = @numusuario,
												@num_poliza = @num_poliza,
												@folio = @folio,
												@tipo_poliza = @tipo_poliza,
												@contador_provision = 0,
												@titular = @titular_pago,
												@ahorro = @monto_tomado_ahorro,
												@inverdinamica = @monto_tomado_inver,
												@debito = @monto_tomado_debito,
												@saldo_adelanto = @monto_necesario,
												@saldo_cuenta_contable = 0,
												@cuenta_contable = '',
												@efectivo = @monto_tomado_efectivo,
												@gastos_cobranza = @gastos_cobranza_mas_iva_saldado,
												@id_origen = 3,
												@id_tipo_persona = 1,
												@fecha = @fechaOperacion,
												@id_tipo_pago_prestamo = @TipoAnticipo,
												@moratorios_e_iva = 0

										end -- es adelanto

								end try
								begin catch 
									print '**Error en sp_interes_diario_realiza_pago_nivelado ----'
									select @status = 339
									select @message = 'Error al procesar el pago, intente mas tarde.'
									raiserror (@message, 11, 0)
								end catch -- es nivelado

							else if @es_revolvente_destino = 1

								begin try -- revolvente

									if (@TipoAnticipo = 3)

										raiserror ('Los pr�stamos revolventes no permiten adelantos', 13, 0)

									exec hape.dbo.sp_revolvente_realiza_pago

										@id_linea = @id_linea_destino,
										@numero = @numero_destino,
										@pago_total = @monto_necesario,
										@numusuario = @numusuario,
										@num_poliza = @num_poliza,
										@folio = @folio,
										@contador_provision = 0,
										@titular = @titular_pago,
										@ahorro = @monto_tomado_ahorro,
										@inverdinamica = @monto_tomado_inver,
										@debito = @monto_tomado_debito,
										@efectivo = @monto_tomado_efectivo,
										@id_tipo_persona = 1,
										@fecha = @fechaOperacion,
										@gastos_cobranza = @gastos_cobranza_mas_iva_saldado,
										@id_origen = 3

								end try
								begin catch 
									print '**Error en sp_revolvente_realiza_pago ----'
									select @status = 339
									select @message = 'Error al procesar el pago, intente mas tarde.'
									raiserror (@message, 11, 0)
								end catch -- revolvente

							if exists (select * from #procedimiento_pago_credito where status != 1)

								begin

									--select * from #procedimiento_pago_credito -------------------

									select	@message = error_message
									from	#procedimiento_pago_credito

									select @status = 378

									raiserror(@message, 13, 0)

								end

							-- se actualiza la cuenta de cajas por la cuenta de compensacion de la sucursal due�a si los socios son de diferente sucursal
							-- CAPTURA_lacp
								update	hape.dbo.CAPTURA_lacp
								set		Cuenta = a.cta_contable_suc_duena,
										Concepto = a.des_contable_suc_duena,
										Id_Tipomov = 0

								from	(
											select	Contador,
													Ccostos,
													@numero_destino as numero_destino, 
													@cta_contable_suc_duena cta_contable_suc_duena,
													@des_contable_suc_duena des_contable_suc_duena,
														
													cuenta
											from	hape.dbo.CAPTURA_lacp 
											where	folio = @folio 
												and Num_Poliza = @num_poliza 
												and numero = @numero_destino 
												and id_origen = 3 
												and Cuenta like '111%' 
												and Id_Tipomov = 961 
												and Activo = 'T'

										)A
								where	folio = @folio 
									and Num_Poliza = @num_poliza 
									and numero = @numero_destino 
									and id_origen = 3 
									and hape.dbo.CAPTURA_lacp.Cuenta like '111%' 
									and Id_Tipomov = 961 
									and Activo = 'T'

							-- se actualiza la cuenta de cajas por la cuenta de compensacion de la sucursal due�a si los socios son de diferente sucursal
							-- CAPTURA
								update	hape.dbo.CAPTURA
								set		Cuenta = a.cta_contable_suc_duena,
										Concepto = a.des_contable_suc_duena,
										Id_Tipomov = 0

								from	(
											select	Contador,
													Ccostos,
													@numero_destino as numero_destino, 
													@cta_contable_suc_duena cta_contable_suc_duena,
													@des_contable_suc_duena des_contable_suc_duena,
														
													cuenta
											from	hape.dbo.CAPTURA 
											where	folio = @folio 
												and Num_Poliza = @num_poliza 
												and numero = @numero_destino 
												and id_origen = 3 
												and Cuenta like '111%' 
												and Id_Tipomov = 961 
												and Activo = 'T'

										)A
								where	folio = @folio 
									and Num_Poliza = @num_poliza 
									and numero = @numero_destino 
									and id_origen = 3 
									and hape.dbo.CAPTURA.Cuenta like '111%' 
									and Id_Tipomov = 961 
									and Activo = 'T'

	
						end -- afectar pago a cr�dito

					end -- si no est� programada, se aplica de inmediato

				--begin  -- compensaciones

				--	if ( @ccostos_origen <> @ccostos_destino ) 
				--		begin

				--			select @fecha_ini = convert(datetime,CONVERT(varchar(10), @fechaOperacion, 103),103) 
				--			select @fecha_fin = dateadd(dd, 1, @fecha_ini) 

				--			create table 
				--				#temp_ccostos
				--					(
				--						 ccostos_destino varchar(10)
				--						,ccostos_origen varchar(10)
				--						,id_de_sucursal int
				--						,num_cuenta_compensacion_origen varchar(50)
				--						,num_cuenta_compensacion_destino varchar(50)
				--						,monto money
				--						,folio int
				--						,num_poliza int
				--					)

				--			create table 
				--				#cuentas_compensadas 
				--					( 
				--						 cuenta varchar(50) 
				--						,ccostos varchar(10)
				--						,total_haber money 
				--						,total_debe money
				--						,origen varchar(50)
				--						,monto money
				--						,folio int
				--						,num_poliza int
				--					)

				--			create table 
				--				#tbl_poliza
				--					(
				--						cuenta varchar(50), 
				--						ccostos varchar(10), 
				--						monto money, 
				--						tipo_asiento int, folio int
				--					)


				--			-- obtenemos la cuenta contable de la sucursal del socio origen para compensaciones
				--				select	@cta_contable_suc_duena =	n.Num_Cuenta_Compensacion
				--													from	hape.dbo.SUCURSALES s 
				--															inner join hape.dbo.NUM_SUCURSAL n
				--																on n.Num_Sucursal = s.Num_Sucursal
				--															inner join hape.dbo.PERSONA c
				--																on c.Id_de_sucursal = s.Id_de_Sucursal
				--													where	c.Numero = @numero_origen
				--														and	c.Id_Tipo_Persona = 1

				--			-- obtenemos todos los centros de costos que no son de la sucursal del socio origen
				--				insert into #temp_ccostos (ccostos_destino, ccostos_origen, id_de_sucursal,num_cuenta_compensacion_origen, num_cuenta_compensacion_destino,monto,folio,num_poliza)
				--				SELECT	c.CCOSTOS, @ccostos_origen, Num_Sucursal, @cta_contable_suc_duena, Num_Cuenta_Compensacion, Monto, Folio, Num_Poliza 
				--				FROM	hape.dbo.captura_lacp c
				--						inner join hape.dbo.NUM_SUCURSAL n
				--							on c.Ccostos collate SQL_Latin1_General_CP1_CI_AS = n.Ccostos collate SQL_Latin1_General_CP1_CI_AS
				--				WHERE	FECHA_MOV>@fecha_ini AND FECHA_MOV<@fecha_fin AND ID_TIPOMOV<>-1 AND ID_TIPOMOV<>961 
				--						AND c.ACTIVO='T' AND NUMUSUARIO=@numusuario AND TIPO_POLIZA='M'
				--						and c.Ccostos <> @ccostos_origen and c.Ccostos <> @ccostos_medpa and c.id_origen not in (2)
				--						and c.Folio = @folio
								
				--			-- compensaciones de cuentas q no son de la sucursal del socio origen
				--			-- monto que se debe de compensar de operaciones que se hicieron en la sucural que no es el ccostos del socio origen
				--				insert into #cuentas_compensadas (cuenta, ccostos, total_haber, total_debe, origen, monto,folio,num_poliza)
				--				SELECT	CUENTA, c.ccostos, 
				--						case
				--							when DEBE_HABER = 'H' then abs(monto)
				--							else 0
				--						end as total_haber,
				--						case
				--							when DEBE_HABER = 'D' then abs(monto)
				--							else 0
				--						end as total_debe
				--						,'otras' as origen, monto,folio,num_poliza
				--				FROM	hape.dbo.captura_lacp c		
				--				WHERE	Fecha_mov>=@fecha_ini 
				--					AND FECHA_MOV<@fecha_fin 
				--					AND ID_TIPOMOV<>-1 
				--					AND ID_TIPOMOV<>961
				--					AND ACTIVO = 'T' 
				--					and c.ccostos  <> @ccostos_origen
				--					AND c.ccostos <> @ccostos_medpa 
				--					AND NUMUSUARIO = @numusuario 
				--					AND TIPO_POLIZA = 'M'
				--					AND CUENTA <> '11100700000000' AND  CUENTA <> '14101000990000' AND  CUENTA <> '23201100010000'  --   //se elemina las compensasciones de estas cuentas debido al ticket 36773
				--					and c.id_origen not in (2)
				--					and Folio = @folio
							
							
				--			-----------------------------------------------------------------------
				--			-- se insertan 4 registros por cuenta para hacer la compensacion 
				--			-----------------------------------------------------------------------
				--			---- cancelacion de saldo en sucursal origen
				--			--	insert into #tbl_poliza(monto, tipo_asiento, cuenta, ccostos, folio)
				--			--	select  distinct 
				--			--			--'compensa_1',
				--			--			case when total_debe > 0 then total_debe else total_haber end as monto,
				--			--			case when total_debe > 0 then 1 else -1 end as tipo, 
				--			--			---1 as tipo, 
				--			--			case 
				--			--				when total_debe > 0 then temp.num_cuenta_compensacion_destino 								
				--			--				else comp.cuenta 
				--			--			end as cuenta_,
				--			--			temp.ccostos_destino as ccostos,comp.folio
				--			--	from	#cuentas_compensadas comp 
				--			--			inner join #temp_ccostos temp 
				--			--				on comp.ccostos = temp.ccostos_destino
				--			--	--where 1 = case when comp.origen = 'divisas' then 0 else 1 end -- los primeros dos asientos de las divisas aplica diferente la compensacion

				--			---- cuenta compensacion 141_ en cuenta origen
				--			--	insert into #tbl_poliza(monto, tipo_asiento, cuenta, ccostos, folio)
				--			--	select  distinct
				--			--			--'compensa_2', --141x
				--			--			case when total_debe > 0 then total_debe else total_haber end as monto ,
				--			--			case when total_debe > 0 then -1 else 1 end as tipo, 
				--			--			---1 as tipo_,
				--			--			case 
				--			--				when total_debe > 0 then comp.cuenta 
				--			--				else temp.num_cuenta_compensacion_destino 
				--			--			end as cuenta_,
				--			--			temp.ccostos_origen as ccostos,comp.folio
				--			--	from	#cuentas_compensadas comp 
				--			--			inner join #temp_ccostos temp 
				--			--				on comp.ccostos = temp.ccostos_destino
				--			--	--where 1 = case when comp.origen = 'divisas' then 0 else 1 end -- los primeros dos asientos de las divisas aplica diferente la compensacion

				--			---- cuenta compensacion 141_ en cuenta destino
				--			--	insert into #tbl_poliza(monto, tipo_asiento, cuenta, ccostos, folio)
				--			--	select  distinct
				--			--			--'compensa_3', --141xx
				--			--			case when total_debe > 0 then total_debe else total_haber end as monto,
				--			--			case when total_debe > 0 then 1 else -1 end as tipo, 
				--			--			case 
				--			--				when total_debe > 0 then comp.cuenta 
				--			--				else temp.num_cuenta_compensacion_origen 
				--			--			end as cuenta_,
				--			--			temp.ccostos_destino as ccostos,comp.folio
				--			--	from	#cuentas_compensadas comp 
				--			--			inner join #temp_ccostos temp 
				--			--				on comp.ccostos = temp.ccostos_destino

				--			---- inserta el saldo en cuenta destino
				--			--	insert into #tbl_poliza(monto, tipo_asiento, cuenta, ccostos, folio)
				--			--	select  distinct
				--			--			--'compensa_4',
				--			--			case when total_debe > 0 then total_debe else total_haber end as monto,
				--			--			case when total_debe > 0 then -1 else 1 end as tipo, 
				--			--			--1 as tipo_,
				--			--			case 
				--			--				when total_debe > 0 then temp.num_cuenta_compensacion_origen 
				--			--				else comp.cuenta 
				--			--			end as cuenta_,
				--			--			temp.ccostos_origen as ccostos,comp.folio
				--			--	from	#cuentas_compensadas comp 
				--			--			inner join #temp_ccostos temp 
				--			--				on comp.ccostos = temp.ccostos_destino
									
				--			-- insercion a captura_lacp 
				--			 --se inserta la informacion en captura_lacp para el num_poliza del cajero
				--				insert into  
				--					hape.dbo.CAPTURA_lacp (	Id_persona,Activo,Numero,Nombre_s,Apellido_paterno,Apellido_materno,Total_movs,Total_ficha,
				--											Id_Tipomov,Cuenta,Concepto,Fecha_mov,Monto,Neto,ID_mov,Banco,clave_Local,Linea,Num_Poliza,Tipo_poliza,
				--											Folio,Id_Tipo_persona,Num_cheq,Desc1,Desc2,planx,Aval1_socio,Aval1_numero,Aval2_socio,Aval2_numero,
				--											Desc3,Desc4,FECHA_DPF_final,NUM_DPF,TASA,INTERES,DIAS,DEBE_HABER,NUMUSUARIO,PROCESADO,FECHA_ALTA,
				--											numero_Fin,numero_fin2,Plazo,Interes_ord,Interes_mor,Monto2,Plazo2,Interes_ord2,Interes_mor2,Aval1_avalados,
				--											Aval2_avalados,Fec_inicio,Fec_prog,Contador_provision,Ccostos,NOMBRE_BENEFICIARIO,PARENTESCO_BENEFICIARIO,
				--											PORCENTAJE_BENEFICIARIO,NOMBRE_BENEFICIARIO2,PARENTESCO_BENEFICIARIO2,PORCENTAJE_BENEFICIARIO2,Id_Sol,
				--											Numero_Fin_LACP,Reestructura,Id_Motivo_Reestructura,Id_Esquema,Id_Convenio,Id_Amortizacion,Ent_Federativa,
				--											Cve_Municipio,Cve_Localidad,Identificador,Transferencia,Fecha_Pago,Bimestre,Referencia,Cve_Archivo,Impreso,
				--											Folio_Impresion,Documentacion,dpf_en_garantia,Titular,Id_Nomina,Id_Esquema_Nomina,Id_Leyenda,Num_ptmo,
				--											Id_Renovado,Ahorro_Base,Tasa_Pasiva,Id_Fondeador,Numero_Fondeo,id_origen--,id_tipo_pago_prestamo
				--											)

				--				select	0 as Id_persona,'T' as Activo,0 as Numero,'' as Nombre_s,'' as Apellido_paterno, '' as Apellido_materno,0 as Total_movs,
				--						0 as Total_ficha,0 as Id_Tipomov,
				--						Cuenta,c.Concepto,
				--						getdate() as Fecha_mov, p.monto,0 as Neto,0 as ID_mov,0 as Banco,0 as clave_Local,0 as Linea,
				--						@num_poliza,'M' as Tipo_poliza,p.folio as Folio,0 as Id_Tipo_persona,0 as Num_cheq,0 as Desc1,0 as Desc2,
				--						0 as planx,0 as Aval1_socio,0 as Aval1_numero,0 as Aval2_socio,0 as Aval2_numero,0 as Desc3,
				--						0 as Desc4,0 as FECHA_DPF_final,0 as NUM_DPF,0 as TASA,0 as INTERES,0 as DIAS,
				--						case when p.tipo_asiento = -1 then 'D' else 'H' end as DEBE_HABER,
				--						@numusuario as  NUMUSUARIO,0 as PROCESADO,getdate() as FECHA_ALTA,0 as numero_Fin,0 as numero_fin2,
				--						0 as Plazo,0 as Interes_ord,0 as Interes_mor,0 as Monto2,0 as Plazo2,0 as Interes_ord2,
				--						0 as Interes_mor2,0 as Aval1_avalados,0 as Aval2_avalados,0 as Fec_inicio,0 as Fec_prog,
				--						0 as Contador_provision,p.ccostos,'' as NOMBRE_BENEFICIARIO,'' as PARENTESCO_BENEFICIARIO,
				--						0 as PORCENTAJE_BENEFICIARIO,'' as NOMBRE_BENEFICIARIO2,'' as PARENTESCO_BENEFICIARIO2,
				--						0 as PORCENTAJE_BENEFICIARIO2,'' as Id_Sol,0 as Numero_Fin_LACP,0 as Reestructura,
				--						0 as Id_Motivo_Reestructura,0 as Id_Esquema,0 as Id_Convenio,0 as Id_Amortizacion,
				--						0 as Ent_Federativa,0 as Cve_Municipio,0 as Cve_Localidad,0 as Identificador,0 as Transferencia,
				--						0 as Fecha_Pago,0 as Bimestre,0 as Referencia,0 as Cve_Archivo,0 as Impreso,0 as Folio_Impresion,
				--						0 as Documentacion,0 as dpf_en_garantia,0 as Titular,0 as Id_Nomina,0 as Id_Esquema_Nomina,
				--						0 as Id_Leyenda,'' as Num_ptmo,0 as Id_Renovado,0 as Ahorro_Base,0 as Tasa_Pasiva,
				--						0 as Id_Fondeador,0 as Numero_Fondeo,@TipoOrigen--,id_tipo_pago_prestamo
				--				from	#tbl_poliza p
				--						left join hape.dbo.CUENTAS_CONTABLES c on p.cuenta collate SQL_Latin1_General_CP1_CI_AS = c.Num_cuenta collate SQL_Latin1_General_CP1_CI_AS

				--			drop table #tbl_poliza
				--			drop table #temp_ccostos
				--			drop table #cuentas_compensadas

				--		end --if ( @ccostos_origen <> @ccostos_destino )
					
				--end  -- compensaciones


				begin -- componente N de la transacci�n
				
					print '[aqu� va un componente de la transacci�n]'
				
				end -- componente N de la transacci�n

				begin -- actualizar estatus transferencia interna

					if @id_transferencia is not null and @programada = 0

						update	tbl_banca_transferencias_internas
						set		id_estatus_transferencia = 2,
								fecha_transferencia_realizada = @fechaOperacion
						where	id_transferencia = @id_transferencia

				end -- actualizar estatus transferencia interna
				
				begin -- commit
				
					if @tran_count = 0
					
						begin -- si la transacci�n se inici� dentro de este �mbito
						
							commit tran @tran_name
							select @tran_scope = 0
						
						end -- si la transacci�n se inici� dentro de este �mbito
				
				end -- commit
			
			end
		
		end try -- try principal
		
		begin catch -- catch principal

			-- captura del error
			select	--@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
						
			print @error_message

			-- revertir transacci�n si es necesario
			if @tran_scope = 1
				rollback tran @tran_name
			
			if @status = 200
				select @status = -1, @error_message = 'Error al procesar el pago, intente mas tarde.'

		end catch -- catch principal
		
		--begin -- reporte de status
		
		--	select	@status status,
		--			@error_procedure error_procedure,
		--			@error_line error_line,
		--			@error_severity error_severity,
		--			@error_message error_message
				
		--end -- reporte de status

		begin -- reporte de status
		    
			insert into #SP_BANCA_PAGAR_PRESTAMO(estatus,folio,HoraTransaccion,Monto,error_procedur,error_lin,error_severit,error_messag)
			select	estatus = @status,
					case when @status = 200 then @folio else null end Folio,
					case when @status = 200 then @fecha_sistema else null end HoraTransaccion,
					case when @status = 200 then @monto else null end Monto,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message mensaje

			if @standalone = 1
				select * from #SP_BANCA_PAGAR_PRESTAMO
				
		end -- reporte de status
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_PRODUCTOS_PAGO_SERVICIOS_FRECUENTES]    Script Date: 02/09/2020 08:47:19 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			MAXIMILIANO GONZALEZ BETANCOURT
UsuarioRed		GOBM391548
Fecha			20180417
Objetivo		OBTIENE EL CATALOGO DE BANCOS
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_OBTENER_PRODUCTOS_PAGO_SERVICIOS_FRECUENTES]
	
	@id_tipo_servicio_frecuente int=null --1 domiciliacion
	--@id_origen_operacion int=null
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@estatus int = 1,
						@error_message varchar(255) = ''
			
			end -- inicio	
			
			    --if(@id_origen_operacion=13)
				if(@id_tipo_servicio_frecuente=1)
				begin
					SELECT * from CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO WHERE activo = 1 and frecuente_domiciliado = 1
				end
				else
					SELECT * from CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO WHERE activo = 1 and frecuente = 1
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@estatus=0
		
			select @error_message as error_message, @estatus as status
		
		end catch -- catch principal
		
	end -- procedimiento

go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_PRODUCTOS_PAGO_SERVICIOS]    Script Date: 23/07/2020 11:29:32 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			MAXIMILIANO GONZALEZ BETANCOURT
UsuarioRed		GOBM391548
Fecha			20180417
Objetivo		OBTIENE EL CATALOGO DE BANCOS
Proyecto		BANCA ELECTRONICA
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_OBTENER_PRODUCTOS_PAGO_SERVICIOS]
	
		-- par�metros
		@IdServicio int = null,
		@tipo_front int=null
		-- [aqu� van los par�metros]
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = '',
						@descripcion_estatus varchar(255),
						@validacion varchar(255)
			
			end -- inicio			
			IF EXISTS(SELECT * from CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO WHERE activo = 1 and id_servicios_pago = @IdServicio and tipo_front=coalesce(@tipo_front,tipo_front))
			BEGIN
				SELECT 
					200 estatus, 'Productos encontrados' mensaje

				SELECT 
					* 
				from CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO 
				WHERE 
					activo = 1 and id_servicios_pago = coalesce(@IdServicio,id_servicios_pago) and tipo_front=coalesce(@tipo_front,tipo_front)
			END
			ELSE
				SELECT 335 estatus, 'Id del servicio no existe' mensaje
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- MANEJO DE ERRORES
			SELECT @error_message =error_message(),@status=0
		
			select @error_message as error_message, @status as estatus
		
		end catch -- catch principal
		
	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_NOTIFICACION]    Script Date: 19/06/2020 08:28:46 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Cristian P�rez
UsuarioRed		pegc837648
Fecha			20181107
Objetivo		Mostrar el cuerpo de las notificaiones 
Proyecto		Banca
Ticket			ticket

*/

ALTER proc

	[dbo].[SP_BANCA_OBTENER_NOTIFICACION]
	
		-- par�metros
		@numeroSocio bigint,
		@id_tipo_bitacora int,
	    @id_tipo_notificacion int = null,
		@noCel varchar(10) = null,
		@correo varchar(500) =null,
		@idMov int =null,
		@numDPF int =  null,
		@ticket_banca int = null,
		@fecha_compromiso datetime = null,
		@medio_reporte varchar(200) = null,
		@fecha_apertura_reporte datetime = null,
		@IdServicioSocio bigint =  null,
		@IdDomiciliacionSocio bigint =  null,
		@claveRastreoDeError varchar(15) = null
as

	begin -- procedimiento
		
		begin try -- try principal
		
			begin -- inicio
			
				-- declaraciones
				declare	@status int = 1,
						@error_message varchar(255) = '',
						@error_line varchar(255) = '',
						@error_severity varchar(255) = '',
						@error_procedure varchar(255) = ''

				declare @ultimaCuentaSocio int
				select top 1 @ultimaCuentaSocio =id_cuenta from TBL_BANCA_CUENTAS_INTERBANCARIAS where BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio order by fecha_alta desc

			end -- inicio
			
			BEGIN -- validaciones
			
				IF (@id_tipo_notificacion is null)
				BEGIN
					
					IF exists (SELECT 1 FROM  hape..TBL_CONTRATOS_HABERES WHERE numero =@numeroSocio and id_tipo_contrato = 3)
					BEGIN
						SELECT @id_tipo_notificacion = id_tipo_notificacion FROM  hape..TBL_CONTRATOS_HABERES WHERE numero =@numeroSocio and id_tipo_contrato = 3
					END
					ELSE
					BEGIN
						SELECT 'El socio no tiene definido un medio de notificaci�n' mensaje , '-1' estatus
						return
					END
				END

				if ((@ticket_banca is not null or @ticket_banca>0) and @id_tipo_bitacora in (63))
				begin
					update hape..TBL_UNE_REPORTE set fecha_compromiso_reporte = @fecha_compromiso where folio_banca = @ticket_banca
				end

			END -- validaciones
					
			IF OBJECT_ID('tempdb..#notificaciones') IS NOT NULL
			DROP TABLE #notificaciones

			create table #notificaciones
			(
				idTipoNotificacion int , 
				celular varchar(10),
				correo varchar(500),
				cuerpo varchar(max),
				asunto varchar(500),
				ordenby int ,
				
			)

			IF OBJECT_ID('tempdb..#notificaciones_sms') IS NOT NULL
			DROP TABLE #notificaciones_sms

			create table #notificaciones_sms
			(
			    id int identity(1,1),
				idTipoBitacora int,
				cuerpo varchar(max),
				idMov int,
				importeCuentaRetiro money,
				cuentaRetiro varchar(500),
				cuentaRetiroMascara varchar(500),
				cuentaRetiroCorreo varchar(500)
			)

			declare 
				@nota VARCHAR(max), 
				@folio  bigint  = null, 
				@fecha varchar(10) ,
				@hora varchar (11),
				@importe money,
				@cuentaOrigen varchar(500),
				@cuentaDestino varchar(500),
				@clabeOrigenMascara varchar(500),
				@clabeDestinoMascara varchar(500),
				@operacion varchar(500),
				@nombreSocio varchar(1000),
				@descPrestamo Varchar(1000),
				@link varchar(max) = '',
				@esProgramado char(1)='0',
				@nombreComercial varchar(500),
				@numPtmo varchar(20),
				@idEstatusTransferencia  int,
				@claveRastreo varchar(500),
				@descServicio varchar(1000),
				@descripcionDevolucion varchar(1000),
				@alias varchar(max),
				@TipoDomiciliacionDesc varchar(max) = ''
				
			    -- OBTENEMOS LOS DATOS GENERALES DE LA NOTIFICACION
				if (@numDPF is null)
				begin
					SELECT TOP 1 
						@folio = COALESCE(id_banca_folio, id_bitacora) ,
						@fecha = CONVERT(varchar , fecha_alta,103) ,
						@hora =  RIGHT(CONVERT(VARCHAR,fecha_alta, 22), 11) ,
						@operacion  = b.descripcion
										
					FROM 
						TBL_BANCA_BITACORA_OPERACIONES  BO JOIN
						CAT_BANCA_TIPOS_BITACORA B ON BO.id_tipo_bitacora = B.id_tipo_bitacora
					WHERE 
						numero_socio = @numeroSocio and b.id_tipo_bitacora = @id_tipo_bitacora order by fecha_alta desc

				end
				else-- ESTE CODIGO LO USA EL ROBOT QUE ENVIA LAS CONSTANCIAS DE DPF ES UN ROBOT QUE DESARROLLO JESSY
				begin
					print'num dpf'+cast(@numDPF as varchar)

					SELECT TOP 1 
							@folio = COALESCE(id_banca_folio, id_bitacora) ,
							@fecha = CONVERT(varchar , BO.fecha_alta,103) ,
							@hora =  FORMAT(CONVERT(datetime, BO.fecha_alta), 'hh:mm:ss tt') ,
							@operacion  = b.descripcion
										
						FROM 
							TBL_BANCA_BITACORA_OPERACIONES  BO JOIN
							CAT_BANCA_TIPOS_BITACORA B ON BO.id_tipo_bitacora = B.id_tipo_bitacora JOIN 
							HAPE..MOVIMIENTOS M ON M.Activo ='T' 
							AND M.Id_tipomov = 41 
							AND M.Num_DPF = @numDPF 
							AND M.id_origen in(3,4)
							AND M.Folio = BO.id_banca_folio
							
						WHERE 
							numero_socio = @numeroSocio 
							and b.id_tipo_bitacora = @id_tipo_bitacora 
							AND M.Num_DPF = @numDPF 
							AND M.Id_tipomov = 41 
							AND M.Numero = @numeroSocio
							order by BO.fecha_alta desc
				end

				/*if  @IdDomiciliacionSocio is not null
				begin 
					select @folio =  max(id_banca_folio) from TBL_BANCA_FOLIOS where numero_socio = @numeroSocio
				end*/



				print 'FOLIO:' + cast(@folio as varchar)

				--OBTENEMOS EL NOMRBE DE LA PERSONA PARA LOS CORREOS
				SELECT 
					@nombreSocio = ISNULL(Nombre_s,'')+' '+ISNULL(Apellido_Paterno,'')+' '+ISNULL(Apellido_Materno,''),
					@noCel = case when  @noCel  is null or @noCel = '' then Tel_Celular else @noCel end,
					@correo = case when  @correo  is null or  @correo =''  then Mail else @correo end 
				FROM HAPE..PERSONA 
				WHERE Numero =@numeroSocio and id_tipo_persona = 1
			


			--1	SMS,--2	Correo electr�nico,--3	Ambos medios

			if(@folio is not null or @folio < > '')
				BEGIN
				      -- PREGUNTAMOS SI ES UN DEPOSITO DE PLAZO FIJO ENTONCES OBTENEMOS EL NUMDPF
					  IF (@id_tipo_bitacora = 19)
					  BEGIN
						  SELECT 
								@numDPF = Num_DPF,
								@importe = ISNULL(Monto,'0')
						  FROM HAPE..MOVIMIENTOS 
						  WHERE Folio = @folio AND Numero = @numeroSocio AND Activo ='T' AND Id_tipomov = 41
					  END

					   -- PREGUNTAMOS SI ES UNA CANCELACION DE  DEPOSITO DE PLAZO FIJO ENTONCES OBTENEMOS EL NUMDPF Y EL IMPORTE
					  IF (@id_tipo_bitacora = 20)
					  BEGIN
						  SELECT 
								@numDPF = Num_DPF,
								@importe = ISNULL(Monto,'0')
						  FROM HAPE..MOVIMIENTOS 
						  WHERE Folio = @folio AND Numero = @numeroSocio AND Id_tipomov = 341
					  END

					  -- PREGUNTAMOS SI ES UN  PAGO A PRESTAMO OBTENEMOS EL MONTO DEL PAGO Y LA DESCRIPCION DEL PRODUCTO
					  IF (@id_tipo_bitacora in(23,102))
					  BEGIN
						  SELECT 
								@numDPF = Num_DPF,
								@importe = ISNULL(Monto,'0')
						  FROM HAPE..MOVIMIENTOS 
						  WHERE Folio = @folio AND 
						  Numero = @numeroSocio
						  AND Activo ='T' 
						  and id_origen in(3,4)
					  END

					  -- OBTENER CUENTA ORIGEN Y DESTINO PARA TRANSFERENCIAS
					  /*
						  15	transferencia realizada |entre cuentras propias
						  16	transferencia realizada |cuentas de misma instituci�n (entre socios)
						  23	pago realizado|Pago a Prestamo|Entre cuentas propias
						  50	pago realizado|Pago a Prestamo|cuentas mismo banco (entre socios)
						  51	Retiro de Inverdinamica 
						  52	Retiro de Ahorro 
						  53	Retiro de D�bito 
						  19	dep�sito de Inverplus CMV
						  24	Pago programado|Pago a Pr�stamo
						  85	Transferencia Programada | cuentas misma instituci�n (entre socios)
                          70	Transferencia Programada | Entre cuentas propias
					  */
					  IF (@id_tipo_bitacora IN (15,16,23,50,24,70,85,86,102))
					  BEGIN
							
							SELECT 
								@cuentaOrigen =  TDO.Desc_prestamo,
								@cuentaDestino = TDOD.Desc_prestamo,
								@clabeOrigenMascara =  SUBSTRING(TI.clave_corresponsalias_origen,7,3)+'****'+RIGHT(TI.clave_corresponsalias_origen,4),
								@clabeDestinoMascara = SUBSTRING(TI.clave_corresponsalias_destino,7,3)+'****'+RIGHT(TI.clave_corresponsalias_destino,4),
								@importe = ISNULL(TI.monto,'0'),
								@esProgramado = programada,
								@fecha = isnull(CONVERT(varchar , TI.fecha_programada,103) , CONVERT(varchar , TI.fecha_transferencia_realizada,103)) ,
								--@hora =  isnull(FORMAT(CONVERT(datetime, TI.fecha_programada), 'hh:mm:ss tt') ,FORMAT(CONVERT(datetime, TI.fecha_transferencia_realizada), 'hh:mm:ss tt')  ) ,
								@hora = ISNULL(RIGHT(CONVERT(VARCHAR,TI.fecha_programada, 22), 11),RIGHT(CONVERT(VARCHAR,TI.fecha_transferencia_realizada, 22), 11) ),
								@numPtmo = c1.NUM_PTMO,
								@idEstatusTransferencia = isnull(TI.id_estatus_transferencia,0)

						    FROM TBL_BANCA_TRANSFERENCIAS_INTERNAS TI JOIN
							HAPE..TBL_CORRESPONSALIAS_CUENTAS  C  ON TI.clave_corresponsalias_origen = C.CUENTA and BANCA.dbo.FN_BANCA_DESCIFRAR(TI.numero_socio) = @numeroSocio JOIN
							HAPE..TBL_CORRESPONSALIAS_CUENTAS  C1  ON TI.clave_corresponsalias_destino = C1.CUENTA JOIN
							HAPE..TIPOS_DE_OPERACIONES TDO ON TDO.ID_MOV  = C.ID_MOV JOIN
							HAPE..TIPOS_DE_OPERACIONES TDOD ON TDOD.ID_MOV  = C1.ID_MOV
							WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(TI.numero_socio) = @numeroSocio AND id_banca_folio = @folio

					  END
					   --  SI ES UN SPEI ENVIADO
					  if(@id_tipo_bitacora in (92,17,88, 96))
					  BEGIN
					    if(@id_tipo_bitacora = 96 and @claveRastreoDeError is not null)
						begin
							SELECT 
						        @claveRastreo = TI.clave_rastreo,
								@cuentaOrigen = CASE WHEN @id_tipo_bitacora = 93 THEN  TDO.Desc_prestamo ELSE ' ' END,
								@cuentaDestino =  CASE WHEN @id_tipo_bitacora = 92 THEN  TDO.Desc_prestamo ELSE ' ' END,
								@clabeOrigenMascara =   SUBSTRING(TI.clabe_spei_origen,7,3)+'****'+RIGHT(TI.clabe_spei_origen,4) ,
								@clabeDestinoMascara =  SUBSTRING(TI.clabe_spei_destino,7,3)+'****'+RIGHT(TI.clabe_spei_destino,4) ,
								@importe = ISNULL(TI.monto,'0'),
								@esProgramado = programado,
								@fecha = isnull(CONVERT(varchar , TI.fecha_programada,103) , CONVERT(varchar , TI.fecha_transferencia_realizada,103)) ,
								@hora= ISNULL(RIGHT(CONVERT(VARCHAR,TI.fecha_programada, 22), 11),RIGHT(CONVERT(VARCHAR,TI.fecha_transferencia_realizada, 22), 11) ),
								@idEstatusTransferencia = isnull(TI.id_estatus_transferencia,0),
								@folio = id_banca_folio

						    FROM TBL_BANCA_TRANSFERENCIAS_EXTERNAS TI LEFT JOIN
							TBL_BANCA_CUENTAS_INTERBANCARIAS  C  ON TI.clabe_spei_destino = C.clabe and c.id_cuenta = @ultimaCuentaSocio  LEFT JOIN
							HAPE..TIPOS_DE_OPERACIONES TDO ON TDO.ID_MOV  = C.ID_MOV 
							WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(TI.numero_socio) = @numeroSocio AND ti.clave_rastreo = @claveRastreoDeError
						end
						else
						begin					     
					      SELECT 
						        @claveRastreo = TI.clave_rastreo,
								@cuentaOrigen = CASE WHEN @id_tipo_bitacora = 93 THEN  TDO.Desc_prestamo ELSE ' ' END,
								@cuentaDestino =  CASE WHEN @id_tipo_bitacora = 92 THEN  TDO.Desc_prestamo ELSE ' ' END,
								@clabeOrigenMascara =   SUBSTRING(TI.clabe_spei_origen,7,3)+'****'+RIGHT(TI.clabe_spei_origen,4) ,
								@clabeDestinoMascara =  SUBSTRING(TI.clabe_spei_destino,7,3)+'****'+RIGHT(TI.clabe_spei_destino,4) ,
								@importe = ISNULL(TI.monto,'0'),
								@esProgramado = programado,
								@fecha = isnull(CONVERT(varchar , TI.fecha_programada,103) , CONVERT(varchar , TI.fecha_transferencia_realizada,103)) ,
								@hora= ISNULL(RIGHT(CONVERT(VARCHAR,TI.fecha_programada, 22), 11),RIGHT(CONVERT(VARCHAR,TI.fecha_transferencia_realizada, 22), 11) ),
								@idEstatusTransferencia = isnull(TI.id_estatus_transferencia,0)

						    FROM TBL_BANCA_TRANSFERENCIAS_EXTERNAS TI LEFT JOIN
							TBL_BANCA_CUENTAS_INTERBANCARIAS  C  ON TI.clabe_spei_destino = C.clabe and c.id_cuenta = @ultimaCuentaSocio  LEFT JOIN
							HAPE..TIPOS_DE_OPERACIONES TDO ON TDO.ID_MOV  = C.ID_MOV 
							WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(TI.numero_socio) = @numeroSocio AND id_banca_folio = @folio
						end
					  END

					   --  SI ES UN SPEI RECIBIDO
					  if(@id_tipo_bitacora in (92))
					  BEGIN
					      SELECT 
						        @claveRastreo = TI.clave_rastreo,
								@cuentaOrigen = CASE WHEN @id_tipo_bitacora = 93 THEN  TDO.Desc_prestamo ELSE ' ' END,
								@cuentaDestino =  CASE WHEN @id_tipo_bitacora = 92 THEN  TDO.Desc_prestamo ELSE ' ' END,
								@clabeOrigenMascara =   SUBSTRING(TI.cuenta_ordenante,7,3)+'****'+RIGHT(TI.cuenta_ordenante,4) ,
								@clabeDestinoMascara =  SUBSTRING(TI.cuenta_beneficiario,7,3)+'****'+RIGHT(TI.cuenta_beneficiario,4) ,
								@importe = ISNULL(TI.monto,'0'),
								@idEstatusTransferencia = isnull(TI.id_estatus_transferencia,0)

						    FROM TBL_BANCA_TRANSFERENCIAS_EXTERNAS_RECIBIDAS TI LEFT JOIN
							TBL_BANCA_CUENTAS_INTERBANCARIAS  C  ON TI.cuenta_beneficiario = C.clabe and c.id_cuenta = @ultimaCuentaSocio  LEFT JOIN
							HAPE..TIPOS_DE_OPERACIONES TDO ON TDO.ID_MOV  = C.ID_MOV 
							WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(TI.numero_socio) = @numeroSocio AND id_banca_folio = @folio
						 
					  END

					   --  SI ES UN PAGO DE SERVICIO
					  if(@id_tipo_bitacora in (21,93,25))
					  BEGIN
					      SELECT 
								@cuentaOrigen = TDO.Desc_prestamo ,
								@clabeOrigenMascara =   SUBSTRING(PS.clabe_corresponsalias_retiro,7,3)+'****'+RIGHT(PS.clabe_corresponsalias_retiro,4) ,
								@importe = ISNULL(PS.monto,'0'),
								@fecha = isnull(CONVERT(varchar , PS.fecha_pago_realizado,103),'') ,
								--@hora =  isnull(FORMAT(CONVERT(datetime, PS.fecha_pago_realizado), 'hh:mm:ss tt'),'')  ,
								@hora =  isnull(RIGHT(CONVERT(VARCHAR,PS.fecha_pago_realizado, 22), 11),''),
								@idEstatusTransferencia = isnull( PS.id_estatus_transferencia,0),
								@descServicio= /* S.descripcion +' | '+*/P.descripcion,
								@descripcionDevolucion = mensaje_error

						    FROM TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS PS LEFT JOIN
							TBL_BANCA_CUENTAS_INTERBANCARIAS  C  ON PS.clabe_corresponsalias_retiro = C.clabe and id_cuenta = @ultimaCuentaSocio  LEFT JOIN
							HAPE..TIPOS_DE_OPERACIONES TDO ON TDO.ID_MOV  = C.ID_MOV join
							CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO P ON P.id_producto = PS.id_producto AND P.id_servicios_pago = PS.id_servicio JOIN
							CAT_BANCA_SERVICIOS_PAGO S ON S.id_servicios_pago = PS.id_servicio
							WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(PS.numero_socio) = @numeroSocio AND id_banca_folio = @folio
						 
					  END


					    --  SI ES UNA ALTA DE SERVICIO o UNA ACTUALIZACION o BAJA DE SERVICIO
					  if(@id_tipo_bitacora in (38,39,94))
					  BEGIN
					      SELECT 
								@descServicio= /* S.descripcion +' | '+*/P.descripcion
						    FROM TBL_BANCA_SERVICIOS_SOCIOS ss LEFT JOIN
							CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO P ON P.id_producto = ss.id_producto AND P.id_servicios_pago = ss.id_servicio JOIN
							CAT_BANCA_SERVICIOS_PAGO S ON S.id_servicios_pago = ss.id_servicio
							WHERE ss.id_servicio_socio= @IdServicioSocio
						 
					  END

					  --  SI ES UN PAGO DE PTMO DOMICILIACION RECHAZADO
					  if(@id_tipo_bitacora in (103,101))
					  BEGIN						   			     
						 SELECT top 1 @numPtmo=num_ptmo,
						 @descripcionDevolucion=h.decripcion_mensaje_pago,
						 @descServicio=s.descripcion
						 FROM TBL_BANCA_DOMICILIACIONES d						
						 join TBL_BANCA_HISTORIAL_PAGOS_DOMICILIADOS h on d.id_domiciliacion=h.id_domiciliacion
						 left join CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO s on h.id_producto=s.id_producto and h.id_servicio=s.id_servicios_pago
						 WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(d.numero_socio) = @numeroSocio AND d.id_domiciliacion = @IdDomiciliacionSocio
						 and h.id_banca_folio=@folio
						 order by id_historial_pago_domiciliado desc			
				
					  END
					    --  SI ES UNA ALTA, ACTUALIZACION, o BAJA DE UNA DOMICILIACION
					  if(@id_tipo_bitacora in (28,29,100))
					  BEGIN
				
					        SELECT 
							    --@numPtmo=num_ptmo,
								--@descServicio=s.descripcion,
								@alias=case when d.id_tipo_domiciliacion=1 then 'Prest�mo ' + coalesce(BANCA.[dbo].FN_BANCA_OBTENER_NOMBRE_COMERCIAL (num_ptmo),'') 
										else 'Servicio ' + coalesce(s.descripcion,'') end
						    FROM TBL_BANCA_DOMICILIACIONES d 
							left join CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO s on d.id_producto=s.id_producto and d.id_servicio=s.id_servicios_pago												
							WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(d.numero_socio) = @numeroSocio AND d.id_domiciliacion = @IdDomiciliacionSocio
					 	 
					  END

					

					  IF(@id_tipo_bitacora in (23,24,102,103))
					  BEGIN
						select @nombreComercial = BANCA.[dbo].FN_BANCA_OBTENER_NOMBRE_COMERCIAL (@numPtmo)
					  END
					  
					  IF (@id_tipo_bitacora IN (79))
					  BEGIN
						SELECT  @folio = codigo_contrasena FROM TBL_BANCA_SOCIOS WHERE BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numeroSocio
					  END

					  IF (@id_tipo_bitacora IN (31))
					  BEGIN
						SELECT  @link = 'https://auth.cajamorelia.com.mx/ValidaNumero/ValidaNumero?n=@Numero'
					  END
					  					  
					  IF (@id_tipo_bitacora IN (20))
					  BEGIN
					  --@clabeOrigenMascara =  SUBSTRING(TI.clave_corresponsalias_origen,7,3)+'****'+RIGHT(TI.clave_corresponsalias_origen,4),
						  select 
						  @clabeDestinoMascara =  SUBSTRING(A.CUENTA,7,3)+'****'+RIGHT(A.CUENTA,4),
						  @cuentaDestino = b.Desc_prestamo from hape..TBL_CORRESPONSALIAS_CUENTAS A join
						  hape..TIPOS_DE_OPERACIONES B on A.ID_MOV = B.Id_mov where A.Id_mov = 103  AND A.NUMERO = @numeroSocio
					  END

					    --OBTENEMOS EL ID DE NOTIFICACIONES QUE TIENE EL MISMO FOLIO
					   -- YA QUE DEBEMOS NOTIFICAR  LOS HABERES AFECTADOS POR OPERACION
							INSERT INTO #notificaciones_sms (idTipoBitacora , idMov)
							SELECT id_tipo_bitacora ,  CASE WHEN id_tipo_bitacora =51 THEN 103
															WHEN id_tipo_bitacora =52 THEN 100
															WHEN id_tipo_bitacora =53 THEN 112
														 END id_Mov
						    from  tbl_banca_bitacora_operaciones
							where 
								id_banca_folio = @folio 
								and @id_tipo_bitacora not in (93,96,101,103)-- 93 pago de servicio rechazaso si es un pago de servicio rechazo no se notifica de donde se tomo 

							
						--SI NO EXISTE REGISTRO EN ESTA TABLA QUIERE DECIR QUE NO SON NOTIFIACIONES   DE TRANSFERENCIAS O PAGOS POR LO TANTO
						--NO TIENEN REGISTRO EN LA TABLA tbl_banca_bitacora_operaciones Y NECESITAMOS INSERTAR LA NOTIFICACIONES DE MANERA MANUAL
							IF NOT EXISTS (SELECT 1 FROM #notificaciones_sms)
							BEGIN
								INSERT INTO #notificaciones_sms (idTipoBitacora , idMov) VALUES (@id_tipo_bitacora , 0)
							END
							

						--ACTUALIZAMOS LOS VALORES  DE LAS CUENTAS DE RETIRO EN CASO DE QUE EXISTA ALGUNA 
							UPDATE	A
							SET
								A.importeCuentaRetiro = isnull(Monto,0),
								A.cuentaRetiro = TDO.Desc_prestamo,
								A.cuentaRetiroMascara = SUBSTRING(CC.CUENTA,7,3)+'****'+RIGHT(CC.CUENTA,4),
								A.cuentaRetiroCorreo =N'<span style="font-weight:500; ">'+TDO.Desc_prestamo+' '+SUBSTRING(CC.CUENTA,7,3)+'****'+RIGHT(CC.CUENTA,4)+N'</span><br/>'
							FROM   
								#notificaciones_sms A
								JOIN HAPE..MOVIMIENTOS M on A.idMov = M.id_mov and M.Numero  = @numeroSocio
								JOIN HAPE..TBL_CORRESPONSALIAS_CUENTAS CC ON  CC.ID_MOV = M.ID_MOV and CC.NUMERO = @numeroSocio
								JOIN HAPE..TIPOS_DE_OPERACIONES TDO on TDO.Id_mov = M.id_mov
							WHERE 
								M.Numero = @numeroSocio AND
								Folio = @folio AND
								M.id_mov  = CC.id_mov

													
								PRINT'@cuentaOrigen '+ @cuentaOrigen
								PRINT'@clabeOrigenMascara '+  @clabeOrigenMascara 
								PRINT'@importe '+  CAST(@importe  AS VARCHAR)
								PRINT'@esProgramado '+  @esProgramado 
								PRINT'@fecha '+  @fecha
								PRINT'@hora '+  @hora 
								PRINT'@idEstatusTransferencia '+ CAST(@idEstatusTransferencia AS VARCHAR)

					  -- VALIDAMOS SI EL TIPO DE NOTIFICACION ES POR CELULAR O AMBOS
					  IF @id_tipo_notificacion = 1 OR @id_tipo_notificacion  = 3
						BEGIN				
							
							-- ACTUALIZAMOS EL TEXTO QUE SE VA A MANDAR DEPENDIENDO
							-- DEL ID DE LA NOTIFICACION
							UPDATE	A
							SET 	A.cuerpo = B.cuerpo
							FROM	#notificaciones_sms A join TBL_BANCA_NOTIFICACIONES_SMS B
							on A.idTipoBitacora = B.id_tipo_bitacora

							
							
							-- DECLARACION VARIABLES 
							declare
								  @indiceMin int ,
							      @indiceMax int ,
								  @id_tipo_bitacora_retiro int ,
								  @importeCuentaRetiro money=0,
								  @cuentaRetiro varchar(500),
								  @cuentaRetiroMascara varchar(500)

							-- SI ES UN PAGO PROGRAMADO , UNA TRANSFERENCIA SE ELIMINAN LAS ID DE id_tipo_bitacora
							-- YA QUE EL ROBOT DE LOS PAGOS PROGRAMADOS SE ENCARGAR DE NOTIFICAR LOS RETIROS
							-- DE LAS CUENTAS DE HABERES
						    IF @esProgramado = '1'
								DELETE FROM #notificaciones_sms where idTipoBitacora in (51,52,53)
							
	
							SELECT @indiceMin = isnull(min(id),0) ,@indiceMax = isnull(max(id),0)
						    FROM   #notificaciones_sms
							
							WHILE (@indiceMin <= @indiceMax)
								BEGIN -- INICIO DEL WHILE
									
									-- OBTENEMOS LA ESTRUCTURA DE LA NOTIFICACION PARA COMENZAR
									-- REEMPLAZAR LOS PARAMETROS	
								
									 SELECT 
										@nota = cuerpo,
										@id_tipo_bitacora_retiro = idTipoBitacora,
										@cuentaRetiro = cuentaRetiro ,
										@cuentaRetiroMascara= cuentaRetiroMascara,
										@importeCuentaRetiro = importeCuentaRetiro
									FROM   #notificaciones_sms
									WHERE  id = @indiceMin


									print '@id_tipo_bitacora'+cast(@id_tipo_bitacora as varchar)
									print '@esProgramado'+cast(@esProgramado as varchar)
									print '@nota'+cast(@nota as varchar)
									 --
									/*IF @esProgramado = '1' and @id_tipo_bitacora IN (15,16,23,50)
									BEGIN
									  
										SET @nota = REPLACE(@nota ,'Deposito','Deposito programado') 
										SET @nota = REPLACE(@nota ,'Pago realizado','Pago programado') 
									END
									*/

									-- REMPLAZO DE PARAMETROS--
									SET @nota = REPLACE(@nota ,'@numDPF',isnull(@numDPF,'')) -- SET @numDPF
									SET @nota = REPLACE(@nota ,'@fecha_hora_operacion',@fecha+' '+ CASE WHEN @idEstatusTransferencia = 1 AND @esProgramado = '1' THEN '' ELSE @hora END ) -- SET DE HORA Y FECHA
									SET @nota = REPLACE(@nota ,'@folio',isnull(@folio,'')) 
									SET @nota = REPLACE(@nota ,'@link',isnull(@link,''))
									SET @nota = REPLACE(@nota ,'@ticket_banca',isnull(@ticket_banca,'')) -- TICKET DE REPORTE DE BANCA
									SET @nota = REPLACE(@nota ,'@fecha_compromiso',Convert(varchar,isnull(@fecha_compromiso,''), 103)) -- TICKET DE REPORTE DE BANCA 
									SET @nota = REPLACE(@nota ,'@medio_reporte',isnull(@medio_reporte,''))
									SET @nota = REPLACE(@nota ,'@fecha_apertura_reporte',Convert(varchar,isnull(@fecha_apertura_reporte,''), 103)) -- TICKET DE REPORTE DE BANCA 
					
						
									-- VALIDAMOS SI LAS NOTIFICACIONES SON RETIROS DE LAS CUENTAS DE HABERES
									-- TAMBIEN VALIDA QUE NO SEA UNA PAGO PROGAMADO YA QUE SI ES PROGRAMADO NO ES NECESARIO ENVIAR 
									IF (@id_tipo_bitacora_retiro IN (51,52,53) AND (@esProgramado = '0' OR @id_tipo_bitacora = 19))
									BEGIN -- INICIO DE VALIDAMOS SI LAS NOTIFICACIONES SON RETIROS DE LAS CUENTAS DE HABERES
									   
										SET @nota = REPLACE(@nota ,'@numeroReferencia',(iSNULL(@cuentaRetiro,'')+' '+ISNULL(@cuentaRetiroMascara,'') )) 
										SET @nota = REPLACE(@nota ,'@importe','$'+ CONVERT(varchar, CAST(ISNULL(@importeCuentaRetiro,'') AS money), 1))

									END -- FIN DE VALIDAMOS SI LAS NOTIFICACIONES SON RETIROS DE LAS CUENTAS DE HABERES
									ELSE
									BEGIN
										IF (@id_tipo_bitacora = 20 and ISNULL( @importe, '0') <1)
										BEGIN
											print 'vALIDACION DE BITACORA = 20 SMS' 											 
											SET @nota = REPLACE(@nota ,'D�posito a  @numeroReferencia por @importe',/*(select descripcion from banca..CAT_BANCA_TIPOS_BITACORA where id_tipo_bitacora = @id_tipo_bitacora)*/ 'Cancelaci�n de Inverplus CMV')
											--SET @nota = REPLACE(@nota ,'','')												 
										END
										else
										begin
											SET @nota = REPLACE(@nota ,'@importe','$'+ CONVERT(varchar, CAST(ISNULL(@importe,'') AS money), 1)) -- SET DE IMPORTE
											SET @nota = REPLACE(@nota ,'@numeroReferencia',(CASE WHEN @id_tipo_bitacora in (15,20) THEN ISNULL(@cuentaDestino,'')+' '+ISNULL(@clabeDestinoMascara,'') ELSE ISNULL(@clabeDestinoMascara,'') END))
										end
									END
							
									----PARA PRESTAMOS OBTENEMOS  SE REALIZA EL SET DEL NOMBRE COMERCIAL ----
									SET @nota = REPLACE(@nota ,'@producto',isnull(@nombreComercial,'')) 
									SET @nota = REPLACE(@nota ,'@claveRastreo',ISNULL(@claveRastreo,'')) 

									----PARA PAGO DE SERVICIOS  SE REALIZA EL SET DE LA DESCRIPCION DEL PAGO DE SERVICIO ----
									SET @nota = REPLACE(@nota ,'@descServicio',ISNULL(@descServicio,'')) 
									SET @nota = REPLACE(@nota ,'@leyenda',ISNULL(@descripcionDevolucion,'')) 

									----PARA PAGO DE DOMICILIACION SE REALIZA EL SET DEL ALIAS DE LA DOMICILIACION ----
									SET @nota = REPLACE(@nota ,'@alias',ISNULL(@alias,'')) 
									
							       
								    -- INSERTA A LA TABLA GENERAL DE NOTIFICACION YA CON LOS PARAMETROS REEMPLAZDOS
									--INSERT INTO #notificaciones VALUES(1,@noCel ,@correo,@nota ,'',1)

									if(len(@nota)>160)
									begin
										
										INSERT INTO #notificaciones VALUES(1,@noCel ,@correo,SUBSTRING(@nota,1,CHARINDEX(', Atenci�n a socios 8003000268 opc 5',@nota)-1) ,'',1)

						                --El atencion a socios lo enviamos en un segundo msg
										INSERT INTO #notificaciones VALUES(1,@noCel ,@correo,REPLACE(SUBSTRING(@nota,CHARINDEX(', Atenci�n a socios 8003000268 opc 5',@nota),len(@nota)),', ','') ,'',2)
									end
									else
									begin
										 -- INSERTA A LA TABLA GENERAL DE NOTIFICACION YA CON LOS PARAMETROS REEMPLAZDOS
										INSERT INTO #notificaciones VALUES(1,@noCel ,@correo,@nota ,'',1)
									end
									
									SET @indiceMin = @indiceMin +1

							END -- FIN DEL WHILE

							
						END

						---- VALIDAMOS SI EL TIPO DE NOTIFICACION ES POR CORREO O AMBOS
						IF @id_tipo_notificacion = 2 OR @id_tipo_notificacion  = 3
						BEGIN

							declare 
							@img varchar(max) ='',
							@asunto varchar(500)

									SELECT 
										@nota = cuerpo , 
										@img= url_img_operacion,
										@asunto = asunto
									FROM 
										TBL_BANCA_NOTIFICACIONES_CORREO 
									WHERE
											id_tipo_bitacora = @id_tipo_bitacora
							
							--ACTUALIZAMOS LAS VARIABLES
							if @esProgramado = '1' and @id_tipo_bitacora IN (15,16,50,70)
							begin
								print '@esProgramado: '+@esProgramado
								SET @operacion = REPLACE(@operacion ,'realizada','')
								SET @nota = REPLACE(@nota ,'@operacion',@operacion) -- SET DE OPERACION
								SET @nota = REPLACE(@nota ,'La operaci�n de','Operaci�n programada') -- SET DE OPERACION
								SET @nota = REPLACE(@nota ,'Fecha y Hora','Fecha Programada:') -- SET DE OPERACION
								SET @asunto = REPLACE(@asunto ,'realizada','programada')
								SET @asunto = REPLACE(@asunto ,'Pago a pr�stamo|Cuentas entre socios','programada')
							end
							else IF (@id_tipo_bitacora in (21,25,38,39,93,94))-- si es pago de servicio o alta de servicio, o actualicacion de servicio , o baja de pago de servicio
							BEGIN
								declare @codigoActivacion varchar(max)
								select @codigoActivacion = coalesce(pin,'') from banca..TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS WHERE id_banca_folio = @folio

								set @nota = REPLACE(@nota,'@codigoActivacion', @codigoActivacion)
								SET @nota = REPLACE(@nota ,'@operacion',ISNULL(@operacion+' | '+@descServicio,'')) 								
								
							END
							ELSE IF (@id_tipo_bitacora in (28,29,100))-- si es alta de domiciliacion, o actualicacion de domiciliacion , o baja de pago de domiciliacion
							BEGIN		
								SET @nota = REPLACE(@nota ,'@operacion',ISNULL(@operacion+' | '+@alias,'')) 							
							END
							else
							BEGIN
								SET @nota = REPLACE(@nota ,'@operacion',ISNULL(@operacion,'')) -- SET DE OPERACION
							END


							-- VALIDAMOS SI ES UNA APERTURA DE PLAZO FIJO 
							-- SE CONCATENAN LAS CUENTAS DE HABERES INVOLUCRADAS EN LA APERTURA
							IF (@id_tipo_bitacora = 19)
							BEGIN
							      DECLARE
								  @cuentasRetiro varchar(1000) ='' 
									   SELECT @cuentasRetiro = STUFF((
											SELECT ' '+ sms.cuentaRetiroCorreo
											FROM  #notificaciones_sms sms 
											FOR XML PATH('')
											),1,1, '')
								 select @cuentasRetiro = replace(replace(@cuentasRetiro,'&lt;','<'),'&gt;','>')
								 -- 
								 SET @nota = REPLACE(@nota ,'@cuentas',ISNULL(@cuentasRetiro,''))
							END 

																					

							SET @nota = REPLACE(@nota ,'@imagen',ISNULL(@img,'')) -- SET DE HORA Y FECHA
							SET @nota = REPLACE(@nota ,'@fecha_hora_operacion',@fecha+' '+CASE WHEN @idEstatusTransferencia = 1 AND @esProgramado = '1' THEN '' ELSE @hora END ) -- SET DE HORA Y FECHA
							SET @nota = REPLACE(@nota ,'@folio',ISNULL(@folio,'')) -- SET DE HORA Y FECHA
							SET @nota = REPLACE(@nota ,'@CuentaRetiro',ISNULL(@cuentaOrigen,'')+' '+ISNULL(@clabeOrigenMascara,'')) -- SET cuentaRetiro
							SET @nota = REPLACE(@nota ,'@CuentaDeposito',(CASE WHEN @id_tipo_bitacora in (15,70) THEN ISNULL(@cuentaDestino,'')+' '+ISNULL(@clabeDestinoMascara,'') ELSE ISNULL(@clabeDestinoMascara,'') END))
							SET @nota = REPLACE(@nota ,'@Importe','$'+ CONVERT(varchar, CAST(ISNULL(@importe,'') AS money), 1))--  SET IMPORTE
							SET @nota = REPLACE(@nota ,'@Nombre', ISNULL(@nombreSocio,''))--  SET @importe
							SET @nota = REPLACE(@nota ,'@link', ISNULL(@link,''))
							SET @nota = REPLACE(@nota ,'@ticket_banca', ISNULL(@ticket_banca,'')) 
							SET @nota = REPLACE(@nota ,'@fecha_compromiso', Convert(varchar,isnull(@fecha_compromiso,''), 103)) 
							SET @nota = REPLACE(@nota ,'@medio_reporte', ISNULL(@medio_reporte,''))
							SET @nota = REPLACE(@nota ,'@fecha_apertura_reporte', Convert(varchar,isnull(@fecha_apertura_reporte,''), 103)) 
							SET @nota = REPLACE(@nota ,'@claveRastreo',ISNULL(@claveRastreo,'')) 
							SET @nota = REPLACE(@nota ,'@leyenda',ISNULL(@descripcionDevolucion,'')) 
							SET @nota = REPLACE(@nota ,'@alias',ISNULL(@alias,'')) 

							if(@id_tipo_bitacora in (103,101))
							begin
							  SET @nota = REPLACE(@nota ,'@producto',isnull(@nombreComercial,'')) 
							  SET @nota = REPLACE(@nota ,'@descServicio',ISNULL(@descServicio,'')) 
							end
							
							IF (@id_tipo_bitacora = 20)
							BEGIN
							print 'vALIDACION DE BITACORA = 20'
								 SET @nota = REPLACE(@nota ,'@CuentaRetiro',(ISNULL(@cuentaDestino,'')+' '+ISNULL(@clabeDestinoMascara,'')))
								 if( ISNULL( @importe, '0') <1)
								 begin
									declare @desInversion varchar(max)
									select @desInversion = descripcion from CAT_BANCA_TIPOS_BITACORA where id_tipo_bitacora = @id_tipo_bitacora
									print @desInversion

									if exists(select 1 where @nota like concat('%',@desInversion,'%'))
									begin
									print @desInversion
										SET @nota = REPLACE(@nota ,@desInversion,'Cancelaci�n de Inverplus CMV')	
									end
									--select descripcion from CAT_BANCA_TIPOS_BITACORA where id_tipo_bitacora = @id_tipo_bitacora
									
									SET @nota = REPLACE(@nota ,'Importe:','')
									SET @nota = REPLACE(@nota ,'$0.00','')
									SET @nota = REPLACE(@nota ,'Cuenta Dep�sito:','')
								 end
							END

							
						
							INSERT INTO #notificaciones VALUES(2,@noCel ,@correo,@nota ,@asunto,3)
							PRINT 'CUENTA DESTINO: '+(@cuentaDestino)
						END
				END

            print 'folio: '+cast(isnull(@folio, ' ') as varchar)
			print '@cuentaOrigen: '+cast(isnull(@cuentaOrigen, ' ') as varchar)

			
		    select 200 estatus , 'OK' mensaje
			SELECT * FROM #notificaciones order by ordenby
			
			
		
		end try -- try principal
		
		begin catch -- catch principal
		
			-- captura del error
			select	@status = -error_state(),
					@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
					@error_line = error_line(),
					@error_message = error_message(),
					@error_severity =
						case error_severity()
							when 11 then 'Error en validaci�n'
							when 12 then 'Error en consulta'
							when 13 then 'Error en actualizaci�n'
							else 'Error general'
						end
				select	@status estatus,
					@error_procedure error_procedure,
					@error_line error_line,
					@error_severity error_severity,
					@error_message mensaje
		end catch -- catch principal
		
		--begin -- reporte de status
		
		
				
		--end -- reporte de status
		
	end -- procedimiento

go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_OBTENER_DETALLE_PRESTAMO]    Script Date: 14/08/2020 12:00:24 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		David L�pez Fuentes
-- Create date: 06/09/2018
-- Description:	Obtiene el detalle de un prestamo
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_OBTENER_DETALLE_PRESTAMO] 
				@ClabeCorresponsalias varchar(16),
				@tipoOrigen int,
				@numeroSocio varchar(20)	
AS
BEGIN
	
	SET NOCOUNT ON;

	Declare 
	@mensaje_validacion varchar(500),
	@estatus int , 
	@numero_int int,
	@id_tipo_bitacora int,
	@fecha datetime,
	@id_mov int,
	@total money,
	@id_amortizacion int,
	@num_ptmo varchar(14),
	@version_calendario int,
	@id_esquema int,
	@fecha_corte datetime,
	@capital_actual money,
	@planx char(1),
	@id_tipo_persona int,
	@idTipoBloqueo int,
	@aplicaIVA bit,
	@tasaIVA  money

	
	begin try

		select @fecha = getdate()
		select @id_tipo_persona = 1
		select @mensaje_validacion = msj, @estatus = estatus from  dbo.FN_BANCA_VALIDA_SOCIO(@numeroSocio,0)
		set @numero_int = CAST(@numeroSocio as int)		


		if(@mensaje_validacion is null)
		begin --@mensaje_validacion

				if exists(select * from hape.dbo.TBL_CORRESPONSALIAS_CUENTAS where cuenta=@ClabeCorresponsalias)
				begin -- validacion clabe corresponsalias
						
					
						select 
							@id_mov=ID_MOV, 
							@num_ptmo=num_ptmo 
						from 
							hape.dbo.TBL_CORRESPONSALIAS_CUENTAS 
						where 
							cuenta=@ClabeCorresponsalias 

						-- validamos que el prestamo aun tenga saldo en  estado de cuenta 
						-- para revolvente no lo validamos ya que siempre esta activo
						if(@id_mov between 1 and 9)
						begin
							if not EXISTS (select 1	from hape.dbo.edo_de_cuenta where 	numero=@numero_int and id_mov=@id_mov and saldo_actual > 0)
							BEGIN
								SELECT id_excepcion AS estatus , descripcion as mensaje 
								FROM CAT_BANCA_EXCEPTIONS
								WHERE id_excepcion = 391
								return
							END
						end


						select @idTipoBloqueo = id_tipo_bloqueo	 
						from hape.dbo.FN_COB_OBTIENE_BLOQUEOS_PTMO (@numero_int , @id_mov)
				 
						if @idTipoBloqueo = 3 --el prestamo se encuentra en Cobro Legal y cualquier pago es liquidacion
						begin
							SELECT id_excepcion AS estatus , descripcion as mensaje 
							FROM CAT_BANCA_EXCEPTIONS
							WHERE id_excepcion = 399
							return
						end


						select 
							@id_amortizacion=id_amortizacion,
							@id_esquema=id_esquema,
							@planx=planx,
							@aplicaIVA=aplica_IVA 
						from 
							hape.dbo.edo_de_cuenta 
						where 
							numero=@numero_int and id_mov=@id_mov and saldo_actual>0

						select @tasaIVA = tasa / 100.00
						from hape.dbo.tasas 
						where contador = (select max(contador) from hape.dbo.tasas where id_mov = 111)


						print 'esquema: '+cast(isnull(@id_esquema,0) as varchar)
						if @id_mov = 10
						begin -- revolvente
								
								/*create table #saldosRevolvente
								(
									id_linea int,
									id_estado int,
									pago_minimo money,
									pago_liquidacion money
								)
								*/
								


								create table
										    #saldosRevolvente
											(
											id_linea				int null,
											numero					int null,
											id_mov					int null,
											num_ptmo				varchar(14) null,
											planx					varchar(1) null,
											saldo_actual			money null,
											id_estado				int null,
											cv_diaria				bit null,
											fecha_traspaso_CV		datetime null,
											dias_vencidos			int null,
											periodos_vencidos		int null,
											fecha_ultimo_abono		datetime null,
											fecha_ultimo_int_ord	datetime null,
											fecha_ultimo_int_mor	datetime null,
											moratorios				money null,
											iva_moratorios			money null,
											ordinarios_vencidos		money null,
											iva_ordinarios_vencidos	money null,
											ordinarios_corte		money null,
											iva_ordinarios_corte	money null,
											capital_vencido			money null,
											capital_corte			money null,
											ordinarios_al_hoy		money null,
											iva_ordinarios_al_hoy	money null,
											capital_no_devengado	money null,
											pago_minimo				money null,
											pago_minimo_total		money null,
											pago_liquidacion		money null,
											pago_liquidacion_total	money null,
											gastos_cobranza			money null,
											iva_gastos_cobranza		money null,
											tasa_gastos_cobranza	float null,
											seguro_vida				money null,
											seguro_danos			money null,
											int_ord_diferido_no_dev	money null
							                )


								insert #saldosRevolvente
								exec hape.dbo.SP_REVOLVENTE_OBTIENE_SALDOS @numero_int, @fecha

								select 
								    200 AS estatus,
									'ok' as mensaje,
									pago_liquidacion_total PagoParaLiquidar,
									pago_minimo_total PagoAlDiaDeHoy,
									(select Aplica_adelanto from TBL_BANCA_APLICA_ADELANTOS where id_mov=@id_mov) PuedeAdelantar,
									@id_amortizacion IdPeriodicidad,

									(select 
										case 
										when day(getdate())<=dia_corte then dateadd(day, (dia_corte - day(getdate())), getdate())
										end
										from 
										hape.dbo.TBL_REVOLVENTE_LINEAS_CREDITO 
										where numero=@numero_int and num_ptmo=@num_ptmo
									) DiaCorte,

									pago_liquidacion_total MontoMaximo,
									pago_minimo_total PagoMinimoPeriodo,
									pago_minimo_total PagoParaNoGenerarInt,
									pago_minimo_total MontoFijo,
									4 TipoEsquema, /* 4 CON BASE A LA TABLA SELECT * FROM HAPE..ESQUEMA_DE_PAgo
*/									0 saldo_adelanto,
									coalesce(capital_vencido,0) capital_vencido,									
									case when capital_vencido>0 then (pago_minimo_total)-(coalesce(capital_corte,0)) 
									else pago_minimo_total end pago_minimo

								from
									#saldosRevolvente


						end -- revolvente
						
						else if @id_mov < 10
						begin -- si no es revolvente



								create table #saldos
								(
									estatus int null, 
									saldo_actual money null,
									interes_moratorio money null,
									interes_ord_vencido money null,
									interes_ord_vigente money null,
									capital_vencido money null,
									capital_corte money null,	
									capital_no_devengado_fin money null,									
									pago_al_corriente money null,	
									saldo_adelanto money null,
									seguro_vida money null,
									seguro_danos money null,								
									capital_amort money null,
									iva_int_moratorio money null,
									iva_int_ord_vencido money null,
									iva_int_ord_vigente money null,
									int_moratorio_quitas money null,
									int_moratorio_quitas_iva money null,
									int_ordinario_quitas money null,
									int_ordinario_quitas_iva money null,
									reserva_capital money null,
									reserva_interes money null,
									gastos_cobranza money null,
									iva_gastos_cobranza money null,
									tasa_gastos_cobranza money null,
									capital_primer_corte money null,
									int_ord_diferido_no_dev money null
								)

							

								--insert into #saldos (estatus,saldo_actual,interes_moratorio,interes_ord_vencido,interes_ord_vigente,capital_vencido,
								--capital_corte,capital_no_devengado_fin,pago_al_corriente,saldo_adelanto,seguro_vida,seguro_danos,capital_amort,
								--iva_int_moratorio,iva_int_ord_vencido,iva_int_ord_vigente,int_moratorio_quitas,int_moratorio_quitas_iva,int_ordinario_quitas,int_ordinario_quitas_iva,reserva_capital,reserva_interes)
								
								--EXEC hape.dbo.SP_INTERES_DIARIO_OBTIENE_SALDOS @numero_int, @id_mov, @fecha


							if @id_esquema=1
							begin
								
								insert into #saldos (estatus,saldo_actual,interes_moratorio,interes_ord_vencido,interes_ord_vigente,capital_vencido,
								capital_corte,capital_no_devengado_fin,pago_al_corriente,saldo_adelanto,seguro_vida,seguro_danos,capital_amort,
								iva_int_moratorio,iva_int_ord_vencido,iva_int_ord_vigente,int_moratorio_quitas,int_moratorio_quitas_iva,int_ordinario_quitas,
								int_ordinario_quitas_iva,reserva_capital,reserva_interes,
								gastos_cobranza ,
								iva_gastos_cobranza ,
								tasa_gastos_cobranza,							
								capital_primer_corte,
								int_ord_diferido_no_dev)
								
								EXEC hape.dbo.SP_INTERES_DIARIO_OBTIENE_SALDOS @numero_int, @id_mov, @fecha

								
								
							end											
							else
							begin									
								

								insert into #saldos(estatus,saldo_actual,interes_moratorio,interes_ord_vencido,interes_ord_vigente,capital_vencido,
								capital_corte,seguro_vida,seguro_danos,saldo_adelanto,pago_al_corriente,capital_no_devengado_fin,capital_amort,
								iva_int_moratorio,iva_int_ord_vencido,iva_int_ord_vigente,int_moratorio_quitas,int_moratorio_quitas_iva,int_ordinario_quitas,
								int_ordinario_quitas_iva,reserva_capital,reserva_interes,
								gastos_cobranza,
								iva_gastos_cobranza ,
								tasa_gastos_cobranza,							
								capital_primer_corte,
								int_ord_diferido_no_dev)
								exec hape.dbo.SP_INTERES_DIARIO_OBTIENE_SALDOS_BANCA_NIVELADOS @numero_int, @id_mov, @fecha

								
								--update #saldos
								--set pago_al_corriente=coalesce(interes_moratorio,0)+coalesce(iva_int_moratorio,0)+coalesce(interes_ord_vencido,0)+
								--coalesce(iva_int_ord_vencido,0)+coalesce(interes_ord_vigente,0)+coalesce(iva_int_ord_vigente,0)+
								--coalesce(capital_vencido,0)+coalesce(capital_corte,0)+coalesce(seguro_vida,0)+coalesce(seguro_danos,0)
								
							
							
							end

														
								print 'esquema: '+cast(isnull(@id_esquema,0) as varchar)
								print '@fecha: '+cast(isnull(@fecha,0) as varchar)
								print '@numero_int: '+cast(isnull(@numero_int,0) as varchar)
								print '@id_mov: '+cast(isnull(@id_mov,0) as varchar)
								--select * from #saldos
								if @id_esquema=1
								begin --esquema 1

										select @version_calendario=max(version_calendario) from hape.dbo.TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES where Numero=@numero_int and id_mov=@id_mov and num_ptmo=@num_ptmo

										select @fecha_corte=fecha_fin, @capital_actual=capital_actual
										from
										(
											select top 1
											fecha_fin, capital_actual
											from 
											hape.dbo.TBL_INTERES_DIARIO_CALENDARIOS_DECRECIENTES 
											where Numero=@numero_int and id_mov=@id_mov and num_ptmo=@num_ptmo and version_calendario=@version_calendario and convert(varchar, fecha_fin, 112)>=convert(varchar, getdate(), 112)
											order by num_corte
										) t_

								end --esquema 1

								else if @id_esquema in(2, 3)
								begin -- esquema2, 3

										if(@id_mov=1 and @planx='E')
											select @fecha_corte=fecha_pago, @capital_actual=capital
											from
											(
												select top 1 * 
												from 
													hape.dbo.TBL_CREDINOMINA_PTMOS 
												where 
												numero=@numero_int and id_mov=@id_mov and Num_ptmo=@num_ptmo and id_status=1 
												and convert(varchar, Fecha_pago, 112)>=convert(varchar, getdate(), 112)
												order by Contador
											) tc_

										if(@id_mov=5)
											select @fecha_corte=fecha_pago, @capital_actual=capital
											from
											(
												select top 1 * 
												from 
													hape.dbo.TBL_HIPOTECARIO_PTMOS	 
												where 
												numero=@numero_int and id_mov=@id_mov and Num_ptmo=@num_ptmo and id_status=1 
												and convert(varchar, Fecha_pago, 112)>=convert(varchar, getdate(), 112)
												order by Contador
											) th_

										if(@id_mov=9)
											select @fecha_corte=fecha_pago, @capital_actual=capital
											from
											(
												select top 1 * 
												from 
													hape.dbo.TBL_AUTOMOTRIZ_PTMOS	 
												where 
												numero=@numero_int and id_mov=@id_mov and Num_ptmo=@num_ptmo and id_status=1 
												and convert(varchar, Fecha_pago, 112)>=convert(varchar, getdate(), 112)
												order by Contador
											) ta_

										if((@id_mov=1 and @planx<>'E') or (@id_mov=2))
											select @fecha_corte=fecha_pago, @capital_actual=capital
											from
											(
												select top 1 * 
												from 
													hape.dbo.TBL_NIVELADOS_PTMOS	 
												where 
												numero=@numero_int and id_mov=@id_mov and Num_ptmo=@num_ptmo and id_status=1 
												and convert(varchar, Fecha_pago, 112)>=convert(varchar, getdate(), 112)
												order by Contador
											) tn_

								end -- esquema2, 3


								select 
									200 AS estatus,
									'ok' as mensaje,

									(coalesce(saldo_actual,0) + 
									coalesce(interes_moratorio,0) + 
									coalesce(interes_ord_vencido,0) + 
									coalesce(interes_ord_vigente,0) + 
									coalesce(seguro_vida,0) + coalesce(seguro_danos,0) + 
									coalesce(iva_int_moratorio,0) + 									
									coalesce(iva_int_ord_vencido,0) +
									coalesce(iva_int_ord_vigente,0) +
									coalesce(gastos_cobranza,0) +
									coalesce(iva_gastos_cobranza,0) + 
									coalesce(int_ord_diferido_no_dev,0) +
									round((coalesce(int_ord_diferido_no_dev, 0) )*@tasaIVA * CAST(@aplicaIVA as int),2,0)
									)-coalesce(saldo_adelanto,0) 
									PagoParaLiquidar,
									pago_al_corriente PagoAlDiaDeHoy,
									(select Aplica_adelanto from TBL_BANCA_APLICA_ADELANTOS where id_mov=@id_mov) PuedeAdelantar,
									@id_amortizacion IdPeriodicidad,
									@fecha_corte DiaCorte,
									@capital_actual MontoMaximo,
									null PagoMinimoPeriodo,
									null PagoParaNoGenerarInt,
									null MontoFijo,
									@id_esquema TipoEsquema,
									saldo_adelanto,
									coalesce(capital_vencido,0) capital_vencido,
									case when capital_vencido>0 then (pago_al_corriente)-(coalesce(capital_amort,0)) 
									else pago_al_corriente end pago_minimo
								from
									#saldos


						end -- si no es revolvente

						
						CREATE TABLE #Bitacora (estatus int, mensaje varchar(200) , folio bigint , descripcionOperacion varchar(500));
						INSERT INTO #Bitacora
						EXEC SP_BANCA_INSERTA_BITACORA_OPERACIONES @numero_int, 35, @tipoOrigen

				end -- validacion clabe corresponsalias

			else -- validacion clabe corresponsalias
				SELECT id_excepcion AS estatus , descripcion as mensaje 
				FROM CAT_BANCA_EXCEPTIONS
				WHERE id_excepcion = 339

		end	-- @mensaje_validacion
		
		else
			SELECT @estatus AS estatus , @mensaje_validacion mensaje	

	end try

	begin catch
		select 1000 as estatus , ERROR_MESSAGE() AS mensaje  , ERROR_LINE() linea		
	end catch


END

go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_ACTUALIZA_ESTATUS_PAGO_SERVICIO]    Script Date: 27/07/2020 04:56:47 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

Autor			Mar Mej�a Murillo
UsuarioRed		memm373565
Fecha			20180607
Objetivo		Actualiza el estatus de una transferencia interna dado su id_transferencia
Proyecto		Banca en l�nea
Ticket			______

*/

ALTER proc
	[dbo].[SP_BANCA_ACTUALIZA_ESTATUS_PAGO_SERVICIO]
	
		@idBancaFolio			bigint,
		@codigo		int,
		@folioAutorizacion		varchar(100)=null,
		@mensaje		varchar(5000),
		@pin		varchar(50) = null,
		@monto money,
		@request varchar(max)=null,
		@response varchar(max)=null,
		@signed varchar(max) = null,
		@tipoOrigen int = null,
		@estatusTransferencia int = null,
		@silent bit=0,
		@id_domiciliacion int=null
		
as

	begin -- procedimiento

		begin try -- try principal

			begin -- inicio

				begin -- declaraciones

					declare @status int = 200,
							@error_message varchar(255) = '',
							@error_line varchar(255) = '',
							@error_severity varchar(255) = '',
							@error_procedure varchar(255) = '',
							
								
							@tran_name varchar(32) = 'SP_BANCA_ACTUALIZA_ESTATUS_PAGO_SERVICIO',
							@tran_count int = @@trancount,
							@tran_scope bit = 0,
							@fecha_operacion datetime,
			
							@id_tipo_bitacora int,
							@id_origen_transaccion int = 3 --
					-- declare de variables
							declare
								@id_mov int,
								@num_poliza int,
								@saldo_actual money,
								--@id_persona bigint,
								@numero bigint,
								@id_tipo_persona int = 1,

								--- son muy necesarias para la poliza
								@ccostos_compensacion varchar(20),
								@ccostos_socio varchar(20),
								--@NumPoliza bigint  = 0000,
								@TipoPoliza varchar(1) ='D',
								@NumUsuarioBanca int = 1024 ,
								@IdPersona int,
								@IdTipoMov int,							
								@CuentaContable varchar(14) =	'',
								@CuentaContableSucursal varchar(14) =	'',
								@NomreS varchar(50),
								@ApellidoPaterno varchar(50),
								@ApellidoMaterno varchar(50),
								@TotalMovs int = 1,
								@ConceptoCaptura  varchar(1000)='',
								@DebeHaber varchar(1)='H',
								@fechaTransaccion datetime =  getDate(),
								@idServicio int,
								@idProducto int 


					select @fecha_operacion = coalesce(@fecha_operacion, getdate())

				end -- declaraciones

			end -- inicio

			begin -- �mbito de la actualizaci�n

					select @estatusTransferencia = case when @codigo =1 then  2 else 3  end
					select @status = case when @codigo =1 then  200 else 410 /*Pago de servicio rechazado*/  end
					
					select @numero = banca.dbo.fn_banca_descifrar(numero_socio),  @id_mov = cc.id_mov from tbl_banca_transferencias_pago_servicios S
					left join hape..tbl_corresponsalias_cuentas CC on S.clabe_corresponsalias_retiro = CC.cuenta
					where s.id_banca_folio = @idBancaFolio

					

					select @saldo_actual = Saldo_Actual 
					from 
						HAPE..EDO_DE_CUENTA 
					where 
						Numero = @numero 
						and Id_mov = @id_mov 
						and Id_Tipo_persona = @id_tipo_persona

					select 
						@idServicio = id_servicio, @idProducto = id_producto 
					from 
						BANCA..TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS
					where
						id_banca_folio= @idBancaFolio and BANCA.dbo.FN_BANCA_DESCIFRAR(numero_socio) = @numero

					update	TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS
					set		
		
						fecha_pago_realizado = @fecha_operacion,
						folio_autorizacion =  @folioAutorizacion,
						pin =@pin,
						mensaje_error = @mensaje,
						codigo = @codigo,
						id_estatus_transferencia = @estatusTransferencia,
						request =@request,
						response  = @response,
						signed = @signed
					where	
						id_banca_folio = @idBancaFolio
					
					if @codigo = 1 -- si el ws regresa 1 de operacion realizada exitosamente o 6 operacion confirma exitosamente
					begin 
					    
						--Modifico aoaj720209 Se realiza modificacion para que no inserte a la bitacora si el pago viene de una domiciliacion
						if(coalesce(@id_domiciliacion,0)=0)
						begin
						 
							select @id_tipo_bitacora = 21 --Pago de servicios						
						

							insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @tipoOrigen)

							---bitacora para indicar de donde se realizo el retiro de dinero
							select @id_tipo_bitacora = case
								when @id_mov = 100 then 52
								when @id_mov = 103 then 51
								when @id_mov = 112 then 53
							end

							insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
							values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @tipoOrigen)

							-- VALIDAMOS SI EL PAGO DE SERVICIO NECESITA CODIGO DE ACTIVACION						
							if exists(SELECT id_cat_tipo_servicio FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO WHERE id_producto = @IdProducto and id_servicios_pago = @idServicio  and id_cat_tipo_servicio in (10,11))
							BEGIN
								select @id_tipo_bitacora = 97 --Pago de Servicio + Codigo de Activacion
								insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
								values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @tipoOrigen)
							END

						end
					end

					-- proceso para  realizar la devolucion del monto del pago de serivicio cuando este es rechazado
					 if @codigo not in(1)  
					 begin
						begin-- se obtienes los datos para el proceso de devolucion  y la poliza
											  						
							  set @mensaje= case when @codigo = -1 then 'Espere un momento y vuelva a intentarlo' else @mensaje end
								--insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
								--values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @id_origen_transaccion)
										
								---Se obtiene el numero de poliza de banca
								select @num_poliza = numPoliza  from HAPE..TBL_CMV_FOLIOS_POLIZAS_PROCESOS where idProcesoPoliza = (
								select idProcesoPoliza from HAPE..CAT_CMV_PROCESOS_POLIZAS where descripcion = 'BANCA ELECTRONICA')
								and dia = DAY(GETDATE())

								-- OBTENEMOS EL ID_TIPOMOV
								if @id_mov = 100   -- 1184	Dep�sito a AHORRO CMV por operaci�n rechazada de Pago de Servicio
									SET @IdTipoMov  = 1184
								else if @id_mov = 103-- 1187	Dep�sito a INVERDIN�MICA CMV por operaci�n rechazada de Pago de Servicio
									SET @IdTipoMov  = 1187
								else if @id_mov = 112 -- 1190	Dep�sito a DEBITO CMV por operaci�n rechazada de Pago de Servicio
									SET @IdTipoMov  = 1190

									--- se obtienen datos del socio 
								select 
									@IdPersona = p.Id_Persona,
									@NomreS = p.Nombre_s,
									@ApellidoPaterno = p.Apellido_Paterno,
									@ApellidoMaterno = p.Apellido_Materno,
									@ccostos_socio = s.Ccostos,
									@CuentaContableSucursal = nSuc.Num_Cuenta_Compensacion
								from HAPE..PERSONA p
								join HAPE.dbo.sucursales s
									on s.id_de_sucursal = p.id_de_sucursal
								join HAPE..NUM_SUCURSAL nSuc 
									on s.Num_Sucursal = nSuc.Num_Sucursal
								where Numero = @numero and Id_Tipo_Persona = @id_tipo_persona
								
								
								select @ccostos_compensacion = Ccostos from HAPE..NUM_SUCURSAL
								WHERE
									Num_Sucursal = 99 --'MEDIOS DE PAGO%'
						end


						begin -- Transaccionalidad

								print 'paso 03 (inicio de transacci�n)'
								if @tran_count = 0
									begin tran @tran_name
								else
									save tran @tran_name
				
								select @tran_scope = 1	
									/*========================================	ACTUALIZACI�N DE MOVIMIENTOS ==============================
									======================================================================================================*/
								
								print 'antes de MOVIMIENTOS'
								print '@numero:'+ cast(@numero as varchar )
								print '@id_tipo_persona:'+ cast(@id_tipo_persona as varchar )
								print '@id_persona:'+ cast(@idPersona as varchar )
								INSERT	HAPE..MOVIMIENTOS
									(
									NUMERO, ACTIVO, FECHA_MOV, MONTO, SALDO, TIPO_POLIZA,
									NUM_POLIZA, FOLIO, FECHA_ALTA, ID_PERSONA, NUMUSUARIO,
									ID_TIPOMOV, ID_MOV, ID_TIPO_PERSONA, TITULAR, id_origen
									)
								VALUES(
									@numero, 'T', @fecha_operacion, @monto,round((@saldo_actual + @monto),2), 'D',
									@num_poliza, @idBancaFolio, GETDATE(), @IdPersona, @NumUsuarioBanca,
									@IdTipoMov, @id_mov, 1, 'S', @id_origen_transaccion)

								print 'despues de MOVIMIENTOS'

								/*========================================	ACTUALIZACI�N DE ESTADO DE CUENTA	================================
								==============================================================================================================*/
								UPDATE	HAPE..EDO_DE_CUENTA
								SET	SALDO_ACTUAL = round(@saldo_actual + @monto,2),
									FECHA = @fecha_operacion
								WHERE	
									numero = @numero
									and id_mov = @id_mov
									AND Id_Tipo_persona = 1

							    print 'antes de CAPTURA'
								begin
								--******	INSERCI�N DEL MOVIMIENTO		******
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov
								select @CuentaContable =  Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like 
								case 
									when @id_mov = 100 then '2120000000%'
									when @id_mov = 103 then '2110000000%'
									when @id_mov = 112 then '2160000000%'
								end
								select @DebeHaber = 'H'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@num_poliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)
								--select top 1  * from hape..CAPTURA order by Contador desc
								
								
								
								--******	INSERCION SERVICIO DE BANCA	(DEBE - CARGO)	******
								--obtenemos la descripcion del  movimiento
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

								-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
								SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
								WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

								select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@num_poliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCION SERVICIO DE BANCA	(HABER - ABONO)	******
								--obtenemos la descripcion del  movimiento
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

								-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
								SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
								WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

								select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
								select @DebeHaber = 'H'
								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@num_poliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCI�N MEDIOS DE PAGO	CARGO	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14101000990000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@num_poliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCI�N SUCURSAL DEL SOCIO HABER	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta = @CuentaContableSucursal
								select @DebeHaber = 'H'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@num_poliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_compensacion
								)

								--******	INSERCI�N GESTO PAGO CARGO	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select 
									@CuentaContable =  Num_cuenta, 
									@ConceptoCaptura = 'GESTO PAGO'--Concepto (Se forzo a que diga gesto pago, ya que al darse de alta en productivo no la registraron como debia ser)
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14100611950000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@num_poliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_compensacion
								)

								print 'despues de CAPTURA'
								end
								--- FIN DEL INSERT DE CAPTURA  ---

								--============================ INSERT CAPTURA_lacp ============================
								print 'antes de CAPTURA_lacp'
								begin
								--******	INSERCI�N DEL MOVIMIENTO		******
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov
								select @CuentaContable =  Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like 
								case 
									when @id_mov = 100 then '2120000000%'
									when @id_mov = 103 then '2110000000%'
									when @id_mov = 112 then '2160000000%'
								end
								select @DebeHaber = 'H'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@num_poliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCION SERVICIO DE BANCA	(DEBE - CARGO)	******
								--obtenemos la descripcion del  movimiento
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

								-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
								SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
								WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

								select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@num_poliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCION SERVICIO DE BANCA	(HABER - ABONO)	******
								--obtenemos la descripcion del  movimiento
								select @ConceptoCaptura ='',@CuentaContable=''
								SELECT @ConceptoCaptura = Descripcion  FROM HAPE..TIPO_MOV WHERE Id_tipomov = @IdTipoMov

								-- obtenenos y concatenamos la descripcion del producto a la descripcion del movimiento
								SELECT @ConceptoCaptura=@ConceptoCaptura+' '+descripcion FROM CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
								WHERE id_servicios_pago = @idServicio AND id_producto = @IdProducto

								select @CuentaContable = Num_cuenta from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '23200900250000%'
								select @DebeHaber = 'H'
								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@num_poliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCI�N MEDIOS DE PAGO	CARGO	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14101000990000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@num_poliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_socio
								)

								--******	INSERCI�N SUCURSAL DEL SOCIO HABER	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select @CuentaContable =  Num_cuenta, @ConceptoCaptura = Concepto 
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta = @CuentaContableSucursal
								select @DebeHaber = 'H'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@num_poliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_compensacion
								)

								--******	INSERCI�N GESTO PAGO CARGO	******
								select @ConceptoCaptura ='',@CuentaContable=''
								select 
									@CuentaContable =  Num_cuenta, 
									@ConceptoCaptura = 'GESTO PAGO'--Concepto (Se forzo a que diga gesto pago, ya que al darse de alta en productivo no la registraron como debia ser)
								from HAPE..CUENTAS_CONTABLES  where Num_cuenta like '14100611950000%'
								select @DebeHaber = 'D'

								INSERT INTO HAPE..CAPTURA_lacp
								(Id_persona,Activo,Numero,
								Nombre_s,Apellido_paterno,Apellido_materno,
								Total_movs,Total_ficha,Id_Tipomov,
								Cuenta,Concepto,Fecha_mov,Monto,
								Num_Poliza,Tipo_Poliza,	Folio,
								Id_tipo_persona,debe_haber,numUsuario,
								FECHA_ALTA,id_origen,ID_mov,Ccostos)
								values
								(   @IdPersona , 'T',@numero,
									@NomreS,@ApellidoPaterno,@ApellidoMaterno,
									@TotalMovs,@monto,@IdTipoMov,
									@CuentaContable,@ConceptoCaptura,@fechaTransaccion,@monto,
									@num_poliza,@TipoPoliza,@idBancaFolio,
									@id_tipo_persona,@DebeHaber,@NumUsuarioBanca,
									@fechaTransaccion,@id_origen_transaccion,@id_mov,@ccostos_compensacion
								)

								print 'despues de CAPTURA_lacp'
								end

								--============================ INSERT DE BITACORA ============================
								if(coalesce(@id_domiciliacion,0)=0)
								begin								
									select @id_tipo_bitacora = 93 --Pago de servicio rechazado										

									insert TBL_BANCA_BITACORA_OPERACIONES(id_banca_folio, id_tipo_bitacora, numero_socio, fecha_alta, id_origen_operacion)
									values(@idBancaFolio, @id_tipo_bitacora, @numero, getdate(), @id_origen_transaccion)
								end
						end

						commit tran
					 end

			end -- �mbito de la actualizaci�n

		end try -- try principal

		begin catch -- catch principal

				select @status=coalesce(@status, 0)

				select	--@status=@status,
						--@status =error_state(),	
						@error_procedure = coalesce(error_procedure(), 'CONSULTA DIN�MICA'),
						@error_line = error_line(),
						@error_message = error_message(),
						@error_severity =
							case error_severity()
								when 11 then 'Error en validaci�n'
								when 12 then 'Error en consulta'
								when 13 then 'Error en actualizaci�n'
								else 'Error general'
							end

						--select @status=coalesce(@status, 0)
				-- revertir transacci�n si es necesario
				if @tran_scope = 1
				begin
					rollback tran @tran_name
				end

		end catch -- catch principal

		begin -- reporte de estatus

				if(@silent=0)
				begin
					select 
						@status as estatus , 
						@mensaje as mensaje,
						CONVERT(varchar , @fecha_operacion ,103) as fecha_transaccion, 
						FORMAT(CONVERT(datetime, @fecha_operacion),'hh:mm:ss tt') as hora_transaccion,
						* 
					from 
						TBL_BANCA_TRANSFERENCIAS_PAGO_SERVICIOS where id_banca_folio = @idBancaFolio
				end

		end -- reporte de estatus

	end -- procedimiento
go

USE [BANCA]
GO
/****** Object:  StoredProcedure [dbo].[SP_BANCA_INSERTA_SERVICIOS_PRODUCTOS_GESTO_PAGO]    Script Date: 17/11/2020 10:58:22 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ERNESTO AGUILAR
-- Create date: 2017-00-00
-- Description:	
--				
-- =============================================
ALTER PROCEDURE [dbo].[SP_BANCA_INSERTA_SERVICIOS_PRODUCTOS_GESTO_PAGO]
	@var_xml xml

	AS
	BEGIN

	IF OBJECT_ID ('tempdb..#productosGestoPago') IS NOT NULL  
			DROP TABLE #productosGestoPago;

	BEGIN TRY
			BEGIN TRAN
				delete from CAT_BANCA_CATEGORIAS_SERVICIOS_PAGO
				delete from CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
				delete from CAT_BANCA_SERVICIOS_PAGO
				SELECT 
					idServicio = XTbl.value('(idServicio)[1]', 'int'),
					servicio = XTbl.value('(servicio)[1]', 'varchar(100)'),
					idProducto = XTbl.value('(idProducto)[1]', 'int'),
					producto = XTbl.value('(productoMember)[1]', 'varchar(100)'),
					idCatTipoServicio = XTbl.value('(idCatTipoServicio)[1]', 'int'),
					tipoFront = XTbl.value('(tipoFront)[1]', 'int'),
					hasDigitoVerificador = XTbl.value('(hasDigitoVerificador)[1]', 'bit'),
					precio = XTbl.value('(precio)[1]', 'decimal(18,2)'),
					showAyuda = XTbl.value('(showAyuda)[1]', 'bit'),
					tipoReferencia = XTbl.value('(tipoReferencia)[1]', 'varchar(5)'),
					legend = XTbl.value('legend[1]', 'varchar(5000)')
					
					INTO #productosGestoPago
				FROM 
					@var_xml.nodes('/ResponseConsultaProductos/PRODUCTOS/producto') AS XD(XTbl)

					--select * from #productosGestoPago

				----------------------- CATEGORIAS ------------------------------------------------------
				            
				INSERT INTO CAT_BANCA_CATEGORIAS_SERVICIOS_PAGO (id_categoria_servicios_pago,descripcion,activo,id_grupo_categoria_servicios_pago)
				SELECT p.idCatTipoServicio id_categoria_servicios_pago ,
				case 
					when   p.idCatTipoServicio = 1 then 'Movistar'
					when   p.idCatTipoServicio = 2 then 'Telcel'
					when   p.idCatTipoServicio = 3 then 'AT&T'
					when   p.idCatTipoServicio = 4 then 'Unefon'
					when   p.idCatTipoServicio = 5 then 'Pago de Servicios'
					when   p.idCatTipoServicio = 6 then 'Nextel'
					when   p.idCatTipoServicio = 7 then 'Pago de Impuestos / Gobierno'
					when   p.idCatTipoServicio = 8 then 'Productos Financieros'
					when   p.idCatTipoServicio = 9 then 'Productos por Cat�logo'
					when   p.idCatTipoServicio = 10 then 'Servicios de Prepago'
					when   p.idCatTipoServicio = 11 then 'Entretenimiento'
					when   p.idCatTipoServicio = 12 then 'Virgin'
					when   p.idCatTipoServicio = 13 then 'Otras Recargas'
					when   p.idCatTipoServicio = 14 then 'Venta de Seguros'
					when   p.idCatTipoServicio = 15 then 'Pago de Derechos de Agua'
					when   p.idCatTipoServicio = 16 then 'Juegos y Sorteos'
					when   p.idCatTipoServicio = 17 then 'MazTiempo'
					when   p.idCatTipoServicio = 18 then 'Servicios de Autopistas y Transportes'
				end descripcion,1 activo ,
				
				case 
					when   p.idCatTipoServicio = 1 then 1
					when   p.idCatTipoServicio = 2 then 1
					when   p.idCatTipoServicio = 3 then 1
					when   p.idCatTipoServicio= 4 then  1
					when   p.idCatTipoServicio = 5 then 0
					when   p.idCatTipoServicio = 6 then 0
					when   p.idCatTipoServicio = 7 then 0
					when   p.idCatTipoServicio = 8 then 0
					when   p.idCatTipoServicio = 9 then 0
					when   p.idCatTipoServicio = 10 then 0
					when   p.idCatTipoServicio = 11 then 0
					when   p.idCatTipoServicio = 12 then 0
					when   p.idCatTipoServicio = 13 then 0
					when   p.idCatTipoServicio = 14 then 0
					when   p.idCatTipoServicio = 15 then 0
					when   p.idCatTipoServicio = 16 then 0
					when   p.idCatTipoServicio = 17 then 0
					when   p.idCatTipoServicio = 18 then 0
				end idGrupoCategoria
				FROM  #productosGestoPago p
				where p.idCatTipoServicio not in (select id_categoria_servicios_pago from  CAT_BANCA_CATEGORIAS_SERVICIOS_PAGO)
				group by  p.idCatTipoServicio



				---------------------------------------- SERVICIOS ---------------------------------------
				insert into  CAT_BANCA_SERVICIOS_PAGO (id_servicios_pago,id_categoria_servicios_pago,descripcion,activo)
				select p.idServicio id_servicios_pago ,
						p.idCatTipoServicio id_categoria_servicios_pago ,
						p.servicio descripcion,
						1 activo
				FROM  #productosGestoPago p
				where p.idServicio not in (select idServicio from  CAT_BANCA_SERVICIOS_PAGO)
				group by  p.idServicio, p.idCatTipoServicio, p.servicio
				

				----------------------- PRODUCTOS ---------------------------------------------------------------------

				INSERT INTO  CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO (id_producto,id_servicios_pago,descripcion,tipo_front,precio,tipo_referencia,activo,id_cat_tipo_servicio,has_digito_verificador,comision_cmv,leyenda, comision_gestopago)
				SELECT 
						p.idProducto,
						p.idServicio,
						p.producto,
						p.tipoFront,
						case when  p.tipoFront = 2 then 0 else  p.precio end,
						--0 as precio,
						p.tipoReferencia,
						1 activo,
						p.idCatTipoServicio,
						p.hasDigitoVerificador,
						0.0 as comision,
						p.legend,
						case when  p.tipoFront = 2 then p.precio else 0 end
						--case when  p.idCatTipoServicio = 5 then p.precio else 0 end
				FROM  #productosGestoPago p
				where p.idProducto not in (select id_producto from  CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO)

				/****** CAMBIO SERVICIOS DESTACADOS  ******/
				
				update [BANCA].[dbo].[CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO]
					   set frecuente=0
				where id_producto in (453,454,456,457,458)

				update [BANCA].[dbo].[CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO]
					   set frecuente=1
				where id_producto in (271,597,598,628,640)

				/****** CAMBIO SERVICIOS DESTACADOS DOMICILIADOS  ******/
				update [BANCA].[dbo].[CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO]
					   set frecuente_domiciliado=0
				where id_producto in(190,271,597,598,215)


				--Validaci�n de ids existentes--
				declare @productos_desactivar table (id int)
				declare @ids_existentes table (id int)
				insert into @productos_desactivar 
				VALUES (656), (276), (621), (655), (5882), (5968), (5763), (5944), (194), (277), (236), (623), (654), (183), (390), (584), (585), (586), (587), (588), (6418), (6421), (6424), (193), (244), (184), (622), (5434), (658), (212), (620), (616), (618), (270)

				insert into  @ids_existentes SELECT
					pd.id as idInexistente
				FROM
					banca..CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO AS A
					RIGHT JOIN @productos_desactivar AS pd
						ON A.id_producto = pd.id
				WHERE
					A.id_producto IS NOT NULL

				--Update bandera de los productos
				update
					banca..CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO
					set activo = 0
					where id_producto in (select * from @ids_existentes)


				update [dbo].[CAT_BANCA_SERVICIOS_PAGO] set activo = 0
				where id_servicios_pago in 
				(
					54,
					55 ,
					56,
					64 ,
					65 ,
					82 ,
					94 ,
					97 ,
					105,
					111,
					112,
					126,
					164,
					164,
					164,
					164,
					164,
					105,
					105,
					174,
					175,
					176,
					177,
					185,
					186,
					187,
					189,
					706,
					706,
					756,
					706,
					895,
					895,
					895
				)

				--Actualizacion de leyendas a los productos activos
				
				--update CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO set leyenda = '(Leyenda personalizada por CMV)' where activo = 1
				--update p set p.leyenda =  cmvL.leyenda from banca..CAT_BANCA_PAGO_SERVICIOS_PRODUCTOS_LEYENDAS_CMV cmvL
				--join CAT_BANCA_PRODUCTOS_SERVICIOS_PAGO p
				--on
				--(
				--	cmvL.id_producto = p.id_producto
				--)

		COMMIT TRAN
		select 1 as estatus , 'OK' AS mensaje 	
	END TRY
	BEGIN CATCH
			ROLLBACK TRAN 
			select 0  as estatus , ERROR_MESSAGE() AS mensaje 		
	END CATCH
end






















