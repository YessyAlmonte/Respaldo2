use BANCA
go


-----TBL_BANCA_NOTIFICACIONES_CORREO-----
TRUNCATE TABLE "TBL_BANCA_NOTIFICACIONES_CORREO";
SET IDENTITY_INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] On
--delete from TBL_BANCA_NOTIFICACIONES_CORREO
--DBCC CHECKIDENT (TBL_BANCA_NOTIFICACIONES_CORREO, RESEED, 0)


INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (1, 2, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Genera la contraseña temporal', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/contra.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (2, 3, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>¡Te damos la bienvenida a CMV  Finanzas!</p><br/>
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'activación de “CMV Finanzas”', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (3, 4, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'bloqueo de cuenta |(contraseña incorrecta en 3 ocaciones)', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (4, 5, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'bloqueo de cuenta |(inactividad en 365 dias)', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (5, 6, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'bloqueo de cuenta |desde  el portal web o movil', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (6, 7, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'bloqueo de cuenta |desde sucursal', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (7, 8, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'bloqueo de cuenta |desde Call Center', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (8, 9, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'desbloqueo de cuenta| desde sucursal', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/desbloqueo.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (9, 10, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'desbloqueo de cuenta| desde Call Center', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/desbloqueo.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (10, 11, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'restablecimiento de contraseña', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/contra.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (11, 13, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'cancelación de servicio| desde sucursal', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cancelar.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (12, 14, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'cambio de imagen antiphishing', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cambio_img_anti.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (13, 15, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		
		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<!-- INICIO  SI ES UNA TRANSFERENCIA -->
		<div id="content-transferencia">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
				<span style="font-weight:500; ">@CuentaRetiro</span>
			</p>
			<p style="display: block !important; margin-top: -15px;">
				<span><b style="color: rgba(0,0,0,.7)">Cuenta Depósito:</b></span>
				<span style="font-weight:500; ">@CuentaDeposito</span>
			</p>
			<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
				<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
				<span style="font-weight:500;">@Importe</span>
			</p>	
		</div>
		<!-- FIN  SI ES UNA TRANSFERENCIA -->

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'transferencia realizada |entre cuentras propias', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (14, 16, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		
		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<!-- INICIO  SI ES UNA TRANSFERENCIA -->
		<div id="content-transferencia">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
				<span style="font-weight:500; ">@CuentaRetiro</span>
			</p>
			<p style="display: block !important; margin-top: -15px;">
				<span><b style="color: rgba(0,0,0,.7)">Cuenta Depósito:</b></span>
				<span style="font-weight:500; ">@CuentaDeposito</span>
			</p>
			<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
				<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
				<span style="font-weight:500;">@Importe</span>
			</p>	
		</div>
		<!-- FIN  SI ES UNA TRANSFERENCIA -->

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'transferencia realizada |cuentas de misma institución', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (15, 18, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'alta cuenta de tercero', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/alta_cuentas.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (16, 19, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		
		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<!-- INICIO  SI ES UNA TRANSFERENCIA -->
		<div id="content-transferencia">
			<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span><br/>
		     @cuentas

			<!--<p>
				<span style="font-weight:500; ">@CuentaRetiro</span>
			</p>-->

			<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
				<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
				<span style="font-weight:500;">@Importe</span>
			</p>	
		</div>
		<!-- FIN  SI ES UNA TRANSFERENCIA -->

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'depósito de Inverplus CMV', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (17, 20, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		
		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<!-- INICIO  SI ES UNA TRANSFERENCIA -->
		<div id="content-transferencia">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Cuenta Depósito:</b></span>
				<span style="font-weight:500; ">@CuentaRetiro</span>
			</p>
			<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
				<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
				<span style="font-weight:500;">@Importe</span>
			</p>	
		</div>
		<!-- FIN  SI ES UNA TRANSFERENCIA -->

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'retiro de Inverplus CMV', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (19, 23, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		
		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<!-- INICIO  SI ES UNA TRANSFERENCIA -->
		<div id="content-transferencia">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
				<span style="font-weight:500; ">@CuentaRetiro</span>
			</p>
			<p style="display: block !important; margin-top: -15px;">
				<span><b style="color: rgba(0,0,0,.7)">Cuenta Depósito:</b></span>
				<span style="font-weight:500; ">@CuentaDeposito</span>
			</p>
			<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
				<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
				<span style="font-weight:500;">@Importe</span>
			</p>	
		</div>
		<!-- FIN  SI ES UNA TRANSFERENCIA -->

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'pago realizado|Pago a Prestamo|Entre cuentas propias', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (20, 30, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente, y podras utilizarla dentro de 30 minutos</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'alta de cuentas internas | (misma institución)', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/alta_cuentas.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (21, 31, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>Puedes restablecer la contraseña de tu cuenta <a href="@link">aquí</a></p><br/>
		</div>
		


		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Link para la contraseña temporal desde call center | registro de reporte de callcenter', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (22, 32, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Bloqueo de acceso de cuenta (propio)', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (23, 33, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Bloqueo temporal respuesta incorrecta', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (24, 34, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Bloqueo temporal contrasena caduco', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (25, 40, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Solicitud de “CMV Finanzas”', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (26, 41, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'cambio del medio de notificación', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/notifiaciones.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (27, 42, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Cambio de contraseña para estado de cuenta', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/contra.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (28, 43, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'reposición de Token/NIP', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/nip.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (29, 44, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'cambio del limite de monto', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cambio_limite.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (30, 45, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'cancelación de servicio| desde Call Center', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cancelar.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (31, 46, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'registro de “CMV Finanzas”', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (32, 47, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'cambio de respuesta/pregunta', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/pregunta.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (33, 48, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'baja cuenta de tercero', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/alta_cuentas.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (34, 49, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'modificación cuenta de tercero', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/alta_cuentas.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (35, 50, N'<html>
	<head>
		<style>

		.md-100{
			width: 100%;
			margin: auto;
		}

		.md-80{
			width: 80%;
			margin: auto;
		}

		.md-70{
			width: 70%;
			margin: auto;
		}

		.md-20{
			width: 20%;
			margin: auto;
		}


		/*------------------------------------*/
		#content-principal{
			width:800px; 
			margin: auto;
		}
		/*------------------------------------*/
		#content-header{
			border-bottom: 20px solid #89BA27;
		}

		#content-header img{
			margin: 0;
		}

		/*------------------------------------*/
		#content-nombre{
			margin-top: 10px; 
			font-size: 25px; 
			color:#89BA27;
		}
		/*------------------------------------*/
		#content-operacion{
			margin-top: 10px; 
			text-align: center;
		}

		#content-operacion p{
			color:#595959;
			font-size: 25px;
			padding: 0;
			margin: 5px;
			display: inline-table;
    		width: 100%;
		}

		#operacion{
			font-weight:900 !important;
		}

		#operacion span{
			height: 25px;
			display: inline-block; 
		}

		#operacion img{
			height: 100%;
		}

		#operacion-icono {
			margin-top: 15px;
			margin-bottom: 10px;
			text-align: center;
		}

		/*------------------------------------*/
		#content-transferencia{
			margin-top: 10px; 
			font-size: 20px; 
			color:#595959;
			text-align: center;
		}

		/*------------------------------------*/
		#content-detalle{
			margin: auto;
			margin-top: 30px;
			background-color: #e4e4e4; 	
			text-align:center;
			padding: 5px;
		}
		#content-detalle p{
			font-size: 23px;
			color:#595959;
			margin: 10px;
		}
		/*------------------------------------*/
		#content-aclaracion{
			margin-top: 20px;
			text-align: center;
			font-size: 25px; 
			color:#595959;
		}
		/*------------------------------------*/
		#footer{
			background-color:#e4e4e4;
		}

		#footer-content-tips{
			display: inline-flex;
		}

		#tips-content-img{
			text-align: center;
		}

		#tips-content-tips{
			font-size: 30px; 
			color:#595959;
		}

		#tips-content-tips ul{
			font-size: 20px;
		}

		@media only screen and (max-width: 600px) {

			p, span, li{
	  			font-size: 15px !important;
	  		}

			#content-header,
			#content-nombre,
			#content-operacion,
			#content-detalle,
			#content-aclaracion,
			#footer{
				width: 90%;
				margin: auto;
			}

	  		/*------------------------------------*/
	  		#content-principal{
				width:100%; 
				margin: auto;
			}

			/*------------------------------------*/
			#content-header{
				border-bottom: 10px solid #89BA27;			
			}

			/*------------------------------------*/
			#operacion{
				font-size: 15px;	
				font-weight:900 !important;
			}

			#operacion span{
				height: 15px;
			}

			#operacion-icono img{
				width: 40px;
				height: 50px;
			}

			/*------------------------------------*/
			#content-transferencia p:last-child{
				border-bottom: 2px solid #89BA27 !important;
			}
			/*------------------------------------*/
			#footer-content-tips{
				display: block;
				padding: 10px 10px 0px 0px;
			}

			#tips-content-img,
			#tips-content-tips{
				width: 95%;
				text-align: center;
			}

			#tips-content-img img{
				width: 40px;
				height: 50px;
			}

		}
	</style>
		<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
	</head>
	<body>
		<div id="content-principal">

			<div id="content-header" class="md-100">
				<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
			</div>

			<div id="content-nombre" class="md-100">
				<p style="font-weight:900; ">@Nombre</p>
			</div>

			<div id="content-operacion" class="md-100">
				<p>La operación de</p>
				<p id="operacion">
					<span>
						<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
						&nbsp;@operacion&nbsp;
						<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
					</span>
				</p>
				<p>se realizó  exitosamente</p>
			</div>
		
			<div id="content-detalle" class="md-70">
				<p>
					<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
					<span>@fecha_hora_operacion</span>
				</p>
				<p>
					<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
					<span>@folio</span>
				</p>
			</div>

			<!-- INICIO  SI ES UNA TRANSFERENCIA -->
			<div id="content-transferencia">
				<p>
					<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
					<span style="font-weight:500; ">@CuentaRetiro</span>
				</p>
				<p style="display: block !important; margin-top: -15px;">
					<span><b style="color: rgba(0,0,0,.7)">Cuenta Depósito:</b></span>
					<span style="font-weight:500; ">@CuentaDeposito</span>
				</p>
				<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
					<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
					<span style="font-weight:500;">@Importe</span>
				</p>	
			</div>
			<!-- FIN  SI ES UNA TRANSFERENCIA -->

			<div id="content-aclaracion" class="md-100">
				<p>
					<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
					<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
					<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
					<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
				</p>
			</div>

			<!-- FOOTER -->
			<div id="footer" class="md-100">
				<div id="footer-content-tips" class="md-100">
					<div id="tips-content-img" class="md-20">
	        			<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        		</div>
					<div id="tips-content-tips" class="md-80">
		        		<p style="font-weight:900;">Tips de Seguridad:</p> 
						<ul>
							<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
							<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
						</ul>
					</div>
				</div>
	        
				<div class="md-100">
					<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
						<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
					</a>
				</div>

			</div>
		</div>
	</body>
	</html>', N'Pago a préstamo|Cuentas entre socios', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (36, 51, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		
		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<!-- INICIO  SI ES UNA TRANSFERENCIA -->
		<div id="content-transferencia">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
				<span style="font-weight:500; ">@CuentaRetiro</span>
			</p>
			<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
				<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
				<span style="font-weight:500;">@Importe</span>
			</p>	
		</div>
		<!-- FIN  SI ES UNA TRANSFERENCIA -->

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Retiro de Inverdinamica ', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (37, 52, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		
		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<!-- INICIO  SI ES UNA TRANSFERENCIA -->
		<div id="content-transferencia">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
				<span style="font-weight:500; ">@CuentaRetiro</span>
			</p>
			<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
				<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
				<span style="font-weight:500;">@Importe</span>
			</p>	
		</div>
		<!-- FIN  SI ES UNA TRANSFERENCIA -->

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Retiro de Ahorro ', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (38, 53, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		
		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<!-- INICIO  SI ES UNA TRANSFERENCIA -->
		<div id="content-transferencia">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
				<span style="font-weight:500; ">@CuentaRetiro</span>
			</p>
			<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
				<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
				<span style="font-weight:500;">@Importe</span>
			</p>	
		</div>
		<!-- FIN  SI ES UNA TRANSFERENCIA -->

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Retiro de Débito ', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (39, 54, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'baja de cuenta interna', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/alta_cuentas.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (40, 55, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Modificación de cuenta interna', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/alta_cuentas.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (41, 56, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Bloqueo automático por inactividad en el servicio en 365 días (En base al último acceso)', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (42, 57, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Bloqueo automático por bloqueo de Imagen', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (43, 58, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Bloqueo automático por bloqueo alto de Cobranza', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (44, 59, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Bloqueo automático por aplicación de quebrantos', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (45, 60, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Bloqueo automático por que se encuentra en proceso de bloqueo de exclusión', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (46, 61, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Cancelación automática por tener más de 180 días de bloqueo.', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cancelar.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (47, 62, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>

		<div id="operacion-icono">
			@imagen
		</div>
		

		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Cancelación automática por motivo de fallecimiento.', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cancelar.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (48, 79, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>Tu codigo de verificación es:</p><br/>
		</div>
		
		<div id="content-detalle" class="md-70">
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@folio&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>
', N'Envió de código para reestablecer la contraseña', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (49, 80, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		
		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Transferencia programada no efectuada ', NULL, GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (50, 81, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		
		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
				<span>@folio</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Pago programado no efectuado ', NULL, GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (51, 24, N'<html>
		<head>
			<style>

			.md-100{
				width: 100%;
				margin: auto;
			}

			.md-80{
				width: 80%;
				margin: auto;
			}

			.md-70{
				width: 70%;
				margin: auto;
			}

			.md-20{
				width: 20%;
				margin: auto;
			}


			/*------------------------------------*/
			#content-principal{
				width:800px; 
				margin: auto;
			}
			/*------------------------------------*/
			#content-header{
				border-bottom: 20px solid #89BA27;
			}

			#content-header img{
				margin: 0;
			}

			/*------------------------------------*/
			#content-nombre{
				margin-top: 10px; 
				font-size: 25px; 
				color:#89BA27;
			}
			/*------------------------------------*/
			#content-operacion{
				margin-top: 10px; 
				text-align: center;
			}

			#content-operacion p{
				color:#595959;
				font-size: 25px;
				padding: 0;
				margin: 5px;
				display: inline-table;
    			width: 100%;
			}

			#operacion{
				font-weight:900 !important;
			}

			#operacion span{
				height: 25px;
				display: inline-block; 
			}

			#operacion img{
				height: 100%;
			}

			#operacion-icono {
				margin-top: 15px;
				margin-bottom: 10px;
				text-align: center;
			}

			/*------------------------------------*/
			#content-transferencia{
				margin-top: 10px; 
				font-size: 20px; 
				color:#595959;
				text-align: center;
			}

			/*------------------------------------*/
			#content-detalle{
				margin: auto;
				margin-top: 30px;
				background-color: #e4e4e4; 	
				text-align:center;
				padding: 5px;
			}
			#content-detalle p{
				font-size: 23px;
				color:#595959;
				margin: 10px;
			}
			/*------------------------------------*/
			#content-aclaracion{
				margin-top: 20px;
				text-align: center;
				font-size: 25px; 
				color:#595959;
			}
			/*------------------------------------*/
			#footer{
				background-color:#e4e4e4;
			}

			#footer-content-tips{
				display: inline-flex;
			}

			#tips-content-img{
				text-align: center;
			}

			#tips-content-tips{
				font-size: 30px; 
				color:#595959;
			}

			#tips-content-tips ul{
				font-size: 20px;
			}

			@media only screen and (max-width: 600px) {

				p, span, li{
	  				font-size: 15px !important;
	  			}

				#content-header,
				#content-nombre,
				#content-operacion,
				#content-detalle,
				#content-aclaracion,
				#footer{
					width: 90%;
					margin: auto;
				}

	  			/*------------------------------------*/
	  			#content-principal{
					width:100%; 
					margin: auto;
				}

				/*------------------------------------*/
				#content-header{
					border-bottom: 10px solid #89BA27;			
				}

				/*------------------------------------*/
				#operacion{
					font-size: 15px;	
					font-weight:900 !important;
				}

				#operacion span{
					height: 15px;
				}

				#operacion-icono img{
					width: 40px;
					height: 50px;
				}

				/*------------------------------------*/
				#content-transferencia p:last-child{
					border-bottom: 2px solid #89BA27 !important;
				}
				/*------------------------------------*/
				#footer-content-tips{
					display: block;
					padding: 10px 10px 0px 0px;
				}

				#tips-content-img,
				#tips-content-tips{
					width: 95%;
					text-align: center;
				}

				#tips-content-img img{
					width: 40px;
					height: 50px;
				}

			}
		</style>
			<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
		</head>
		<body>
			<div id="content-principal">

				<div id="content-header" class="md-100">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
				</div>

				<div id="content-nombre" class="md-100">
					<p style="font-weight:900; ">@Nombre</p>
				</div>

				<div id="content-operacion" class="md-100">
					<p>La operación de</p>
					<p id="operacion">
						<span>
							<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
							&nbsp;@operacion&nbsp;
							<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
						</span>
					</p>
					<p>se realizó  exitosamente</p>
				</div>
		
				<div id="content-detalle" class="md-70">
					<p>
						<span><b style="color: rgba(0,0,0,.7)">Fecha programada:</b></span>
						<span>@fecha_hora_operacion</span>
					</p>
					<p>
						<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
						<span>@folio</span>
					</p>
				</div>

				<!-- INICIO  SI ES UNA TRANSFERENCIA -->
				<div id="content-transferencia">
					<p>
						<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
						<span style="font-weight:500; ">@CuentaRetiro</span>
					</p>
					<p style="display: block !important; margin-top: -15px;">
						<span><b style="color: rgba(0,0,0,.7)">Cuenta Depósito:</b></span>
						<span style="font-weight:500; ">@CuentaDeposito</span>
					</p>
					<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
						<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
						<span style="font-weight:500;">@Importe</span>
					</p>	
				</div>
				<!-- FIN  SI ES UNA TRANSFERENCIA -->

				<div id="content-aclaracion" class="md-100">
					<p>
						<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
						<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
						<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
						<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
					</p>
				</div>

				<!-- FOOTER -->
				<div id="footer" class="md-100">
					<div id="footer-content-tips" class="md-100">
						<div id="tips-content-img" class="md-20">
	        				<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        			</div>
						<div id="tips-content-tips" class="md-80">
		        			<p style="font-weight:900;">Tips de Seguridad:</p> 
							<ul>
								<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
								<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
							</ul>
						</div>
					</div>
	        
					<div class="md-100">
						<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
							<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
						</a>
					</div>

				</div>
			</div>
		</body>
		</html>', N'Pago programado|Pago a Préstamo|Entre cuentas propias', N' ', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (52, 63, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: center;
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>La operación de</p>
			<p id="operacion">
				<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>
			</p>
			<p>se realizó  exitosamente</p>
		</div>
		
		<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha de compromiso</b></span>
				<span>@fecha_compromiso</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio CMV Finanzas</b></span>
				<span>@ticket_banca</span>
			</p>
		</div>

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
				<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Registro de reporte de call center', N' ', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (53, 82, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: justify;
		
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>Le informamos que, derivado del número de reporte <span>&nbsp;@ticket_banca&nbsp;</span> que presentó a través de <span style="font-weight:900; ">&nbsp;@medio_reporte&nbsp;</span>
			con fecha @fecha_apertura_reporte; después de realizar el análisis correspondiente, su reporte ha sido resuelto.
			</p>
			<p id="operacion">
				<!--<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>-->
			</p>
			
		</div>
		
		<!--<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha </b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio CMV Finanzas</b></span>
				<span>@ticket_banca</span>
			</p>
		</div>-->

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tiene alguna duda o comentario</span> 
				<span style="font-weight:500; "> favor de comunicarse al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, o dirigirse a cualquiera de nuestras sucursales.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Reporte de acción no reconocida ', N' ', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (54, 83, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: justify;
		
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>Le informamos que, derivado del número de reporte <span>&nbsp;@ticket_banca&nbsp;</span> que presentó a través de <span style="font-weight:900; ">&nbsp;@medio_reporte&nbsp;</span>
			con fecha @fecha_apertura_reporte; después de realizar el análisis correspondiente, le informamos que su reporte ha sido resuelto como improcedente.
			</p>
			<br/>
			<br/>
			<p>
				Derivado de lo anterior y de acuerdo a lo establecido en la cláusula OCTAVA COMISIONES que se estipula dentro del contrato de apertura de CMV Finanzas, que a la letra dice: 
				“La única comisión que se le cobrará a “EL SOCIO”, será por concepto de aclaración improcedente de la cuenta (cargos o movimientos no reconocidos), 
				la cual tendrá un costo de $250.00 (doscientos cincuenta pesos 00/100 m.n.) más IVA, pagaderos por evento”. Le informamos que con esta fecha, se procederá a realizar el cobro por reclamación improcedente.
			</p>
			<p id="operacion">
				<!--<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>-->
			</p>
			
		</div>
		
		<!--<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha </b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio CMV Finanzas</b></span>
				<span>@ticket_banca</span>
			</p>
		</div>-->

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tiene alguna duda o comentario</span> 
				<span style="font-weight:500; "> favor de comunicarse al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, o dirigirse a cualquiera de nuestras sucursales.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Reporte de aclaración improcedente', N' ', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (55, 84, N'<html>
<head>
	<style>

	.md-100{
		width: 100%;
		margin: auto;
	}

	.md-80{
		width: 80%;
		margin: auto;
	}

	.md-70{
		width: 70%;
		margin: auto;
	}

	.md-20{
		width: 20%;
		margin: auto;
	}


	/*------------------------------------*/
	#content-principal{
		width:800px; 
		margin: auto;
	}
	/*------------------------------------*/
	#content-header{
		border-bottom: 20px solid #89BA27;
	}

	#content-header img{
		margin: 0;
	}

	/*------------------------------------*/
	#content-nombre{
		margin-top: 10px; 
		font-size: 25px; 
		color:#89BA27;
	}
	/*------------------------------------*/
	#content-operacion{
		margin-top: 10px; 
		text-align: justify;
		
	}

	#content-operacion p{
		color:#595959;
		font-size: 25px;
		padding: 0;
		margin: 5px;
		display: inline-table;
    	width: 100%;
	}

	#operacion{
		font-weight:900 !important;
	}

	#operacion span{
		height: 25px;
		display: inline-block; 
	}

	#operacion img{
		height: 100%;
	}

	#operacion-icono {
		margin-top: 15px;
		margin-bottom: 10px;
		text-align: center;
	}

	/*------------------------------------*/
	#content-transferencia{
		margin-top: 10px; 
		font-size: 20px; 
		color:#595959;
		text-align: center;
	}

	/*------------------------------------*/
	#content-detalle{
		margin: auto;
		margin-top: 30px;
		background-color: #e4e4e4; 	
		text-align:center;
		padding: 5px;
	}
	#content-detalle p{
		font-size: 23px;
		color:#595959;
		margin: 10px;
	}
	/*------------------------------------*/
	#content-aclaracion{
		margin-top: 20px;
		text-align: center;
		font-size: 25px; 
		color:#595959;
	}
	/*------------------------------------*/
	#footer{
		background-color:#e4e4e4;
	}

	#footer-content-tips{
		display: inline-flex;
	}

	#tips-content-img{
		text-align: center;
	}

	#tips-content-tips{
		font-size: 30px; 
		color:#595959;
	}

	#tips-content-tips ul{
		font-size: 20px;
	}

	@media only screen and (max-width: 600px) {

		p, span, li{
	  		font-size: 15px !important;
	  	}

		#content-header,
		#content-nombre,
		#content-operacion,
		#content-detalle,
		#content-aclaracion,
		#footer{
			width: 90%;
			margin: auto;
		}

	  	/*------------------------------------*/
	  	#content-principal{
			width:100%; 
			margin: auto;
		}

		/*------------------------------------*/
		#content-header{
			border-bottom: 10px solid #89BA27;			
		}

		/*------------------------------------*/
		#operacion{
			font-size: 15px;	
			font-weight:900 !important;
		}

		#operacion span{
			height: 15px;
		}

		#operacion-icono img{
			width: 40px;
			height: 50px;
		}

		/*------------------------------------*/
		#content-transferencia p:last-child{
			border-bottom: 2px solid #89BA27 !important;
		}
		/*------------------------------------*/
		#footer-content-tips{
			display: block;
			padding: 10px 10px 0px 0px;
		}

		#tips-content-img,
		#tips-content-tips{
			width: 95%;
			text-align: center;
		}

		#tips-content-img img{
			width: 40px;
			height: 50px;
		}

	}
</style>
	<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
</head>
<body>
	<div id="content-principal">

		<div id="content-header" class="md-100">
	        <img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
		</div>

		<div id="content-nombre" class="md-100">
			<p style="font-weight:900; ">@Nombre</p>
		</div>

		<div id="content-operacion" class="md-100">
			<p>Le informamos que, derivado del número de reporte <span>&nbsp;@ticket_banca&nbsp;</span> que presentó a través de <span style="font-weight:900; ">&nbsp;@medio_reporte&nbsp;</span>
			con fecha @fecha_apertura_reporte; después de realizar el análisis correspondiente, su reporte ha sido resuelto a su favor, el cual es atendido dentro del término establecido por la Ley.
			</p>
			<p id="operacion">
				<!--<span>
					<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
					&nbsp;@operacion&nbsp;
					<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
				</span>-->
			</p>
			
		</div>
		
		<!--<div id="content-detalle" class="md-70">
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Fecha </b></span>
				<span>@fecha_hora_operacion</span>
			</p>
			<p>
				<span><b style="color: rgba(0,0,0,.7)">Folio CMV Finanzas</b></span>
				<span>@ticket_banca</span>
			</p>
		</div>-->

		<div id="content-aclaracion" class="md-100">
			<p>
				<span style="font-weight:900; ">Si tiene alguna duda o comentario</span> 
				<span style="font-weight:500; "> favor de comunicarse al</span>
				<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
				<span style="font-weight:500; ">, o dirigirse a cualquiera de nuestras sucursales.</span>
			</p>
		</div>

		<!-- FOOTER -->
		<div id="footer" class="md-100">
			<div id="footer-content-tips" class="md-100">
				<div id="tips-content-img" class="md-20">
	        		<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        	</div>
		        <div id="tips-content-tips" class="md-80">
		        	<p style="font-weight:900;">Tips de Seguridad:</p> 
	                <ul>
	                    <li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
	                    <li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
	                </ul>
		        </div>
			</div>
	        
	        <div class="md-100">
				<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
				</a>
			</div>

		</div>
	</div>
</body>
</html>', N'Reporte de aclaración procedente', N' ', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (57, 70, N'<html>
		<head>
			<style>

			.md-100{
				width: 100%;
				margin: auto;
			}

			.md-80{
				width: 80%;
				margin: auto;
			}

			.md-70{
				width: 70%;
				margin: auto;
			}

			.md-20{
				width: 20%;
				margin: auto;
			}


			/*------------------------------------*/
			#content-principal{
				width:800px; 
				margin: auto;
			}
			/*------------------------------------*/
			#content-header{
				border-bottom: 20px solid #89BA27;
			}

			#content-header img{
				margin: 0;
			}

			/*------------------------------------*/
			#content-nombre{
				margin-top: 10px; 
				font-size: 25px; 
				color:#89BA27;
			}
			/*------------------------------------*/
			#content-operacion{
				margin-top: 10px; 
				text-align: center;
			}

			#content-operacion p{
				color:#595959;
				font-size: 25px;
				padding: 0;
				margin: 5px;
				display: inline-table;
    			width: 100%;
			}

			#operacion{
				font-weight:900 !important;
			}

			#operacion span{
				height: 25px;
				display: inline-block; 
			}

			#operacion img{
				height: 100%;
			}

			#operacion-icono {
				margin-top: 15px;
				margin-bottom: 10px;
				text-align: center;
			}

			/*------------------------------------*/
			#content-transferencia{
				margin-top: 10px; 
				font-size: 20px; 
				color:#595959;
				text-align: center;
			}

			/*------------------------------------*/
			#content-detalle{
				margin: auto;
				margin-top: 30px;
				background-color: #e4e4e4; 	
				text-align:center;
				padding: 5px;
			}
			#content-detalle p{
				font-size: 23px;
				color:#595959;
				margin: 10px;
			}
			/*------------------------------------*/
			#content-aclaracion{
				margin-top: 20px;
				text-align: center;
				font-size: 25px; 
				color:#595959;
			}
			/*------------------------------------*/
			#footer{
				background-color:#e4e4e4;
			}

			#footer-content-tips{
				display: inline-flex;
			}

			#tips-content-img{
				text-align: center;
			}

			#tips-content-tips{
				font-size: 30px; 
				color:#595959;
			}

			#tips-content-tips ul{
				font-size: 20px;
			}

			@media only screen and (max-width: 600px) {

				p, span, li{
	  				font-size: 15px !important;
	  			}

				#content-header,
				#content-nombre,
				#content-operacion,
				#content-detalle,
				#content-aclaracion,
				#footer{
					width: 90%;
					margin: auto;
				}

	  			/*------------------------------------*/
	  			#content-principal{
					width:100%; 
					margin: auto;
				}

				/*------------------------------------*/
				#content-header{
					border-bottom: 10px solid #89BA27;			
				}

				/*------------------------------------*/
				#operacion{
					font-size: 15px;	
					font-weight:900 !important;
				}

				#operacion span{
					height: 15px;
				}

				#operacion-icono img{
					width: 40px;
					height: 50px;
				}

				/*------------------------------------*/
				#content-transferencia p:last-child{
					border-bottom: 2px solid #89BA27 !important;
				}
				/*------------------------------------*/
				#footer-content-tips{
					display: block;
					padding: 10px 10px 0px 0px;
				}

				#tips-content-img,
				#tips-content-tips{
					width: 95%;
					text-align: center;
				}

				#tips-content-img img{
					width: 40px;
					height: 50px;
				}

			}
		</style>
			<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
		</head>
		<body>
			<div id="content-principal">

				<div id="content-header" class="md-100">
					<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
				</div>

				<div id="content-nombre" class="md-100">
					<p style="font-weight:900; ">@Nombre</p>
				</div>

				<div id="content-operacion" class="md-100">
					<p>La operación de</p>
					<p id="operacion">
						<span>
							<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
							&nbsp;@operacion&nbsp;
							<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
						</span>
					</p>
					<p>se realizó  exitosamente</p>
				</div>
		
				<div id="content-detalle" class="md-70">
					<p>
						<span><b style="color: rgba(0,0,0,.7)">Fecha programada:</b></span>
						<span>@fecha_hora_operacion</span>
					</p>
					<p>
						<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
						<span>@folio</span>
					</p>
				</div>

				<!-- INICIO  SI ES UNA TRANSFERENCIA -->
				<div id="content-transferencia">
					<p>
						<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
						<span style="font-weight:500; ">@CuentaRetiro</span>
					</p>
					<p style="display: block !important; margin-top: -15px;">
						<span><b style="color: rgba(0,0,0,.7)">Cuenta Depósito:</b></span>
						<span style="font-weight:500; ">@CuentaDeposito</span>
					</p>
					<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
						<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
						<span style="font-weight:500;">@Importe</span>
					</p>	
				</div>
				<!-- FIN  SI ES UNA TRANSFERENCIA -->

				<div id="content-aclaracion" class="md-100">
					<p>
						<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
						<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
						<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
						<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
					</p>
				</div>

				<!-- FOOTER -->
				<div id="footer" class="md-100">
					<div id="footer-content-tips" class="md-100">
						<div id="tips-content-img" class="md-20">
	        				<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        			</div>
						<div id="tips-content-tips" class="md-80">
		        			<p style="font-weight:900;">Tips de Seguridad:</p> 
							<ul>
								<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
								<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
							</ul>
						</div>
					</div>
	        
					<div class="md-100">
						<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
							<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
						</a>
					</div>

				</div>
			</div>
		</body>
		</html>', N'transferencia programada|entre cuentas propias', N' ', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (58, 85, N'<html>
				<head>
					<style>

					.md-100{
						width: 100%;
						margin: auto;
					}

					.md-80{
						width: 80%;
						margin: auto;
					}

					.md-70{
						width: 70%;
						margin: auto;
					}

					.md-20{
						width: 20%;
						margin: auto;
					}


					/*------------------------------------*/
					#content-principal{
						width:800px; 
						margin: auto;
					}
					/*------------------------------------*/
					#content-header{
						border-bottom: 20px solid #89BA27;
					}

					#content-header img{
						margin: 0;
					}

					/*------------------------------------*/
					#content-nombre{
						margin-top: 10px; 
						font-size: 25px; 
						color:#89BA27;
					}
					/*------------------------------------*/
					#content-operacion{
						margin-top: 10px; 
						text-align: center;
					}

					#content-operacion p{
						color:#595959;
						font-size: 25px;
						padding: 0;
						margin: 5px;
						display: inline-table;
    					width: 100%;
					}

					#operacion{
						font-weight:900 !important;
					}

					#operacion span{
						height: 25px;
						display: inline-block; 
					}

					#operacion img{
						height: 100%;
					}

					#operacion-icono {
						margin-top: 15px;
						margin-bottom: 10px;
						text-align: center;
					}

					/*------------------------------------*/
					#content-transferencia{
						margin-top: 10px; 
						font-size: 20px; 
						color:#595959;
						text-align: center;
					}

					/*------------------------------------*/
					#content-detalle{
						margin: auto;
						margin-top: 30px;
						background-color: #e4e4e4; 	
						text-align:center;
						padding: 5px;
					}
					#content-detalle p{
						font-size: 23px;
						color:#595959;
						margin: 10px;
					}
					/*------------------------------------*/
					#content-aclaracion{
						margin-top: 20px;
						text-align: center;
						font-size: 25px; 
						color:#595959;
					}
					/*------------------------------------*/
					#footer{
						background-color:#e4e4e4;
					}

					#footer-content-tips{
						display: inline-flex;
					}

					#tips-content-img{
						text-align: center;
					}

					#tips-content-tips{
						font-size: 30px; 
						color:#595959;
					}

					#tips-content-tips ul{
						font-size: 20px;
					}

					@media only screen and (max-width: 600px) {

						p, span, li{
	  						font-size: 15px !important;
	  					}

						#content-header,
						#content-nombre,
						#content-operacion,
						#content-detalle,
						#content-aclaracion,
						#footer{
							width: 90%;
							margin: auto;
						}

	  					/*------------------------------------*/
	  					#content-principal{
							width:100%; 
							margin: auto;
						}

						/*------------------------------------*/
						#content-header{
							border-bottom: 10px solid #89BA27;			
						}

						/*------------------------------------*/
						#operacion{
							font-size: 15px;	
							font-weight:900 !important;
						}

						#operacion span{
							height: 15px;
						}

						#operacion-icono img{
							width: 40px;
							height: 50px;
						}

						/*------------------------------------*/
						#content-transferencia p:last-child{
							border-bottom: 2px solid #89BA27 !important;
						}
						/*------------------------------------*/
						#footer-content-tips{
							display: block;
							padding: 10px 10px 0px 0px;
						}

						#tips-content-img,
						#tips-content-tips{
							width: 95%;
							text-align: center;
						}

						#tips-content-img img{
							width: 40px;
							height: 50px;
						}

					}
				</style>
					<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
				</head>
				<body>
					<div id="content-principal">

						<div id="content-header" class="md-100">
							<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
						</div>

						<div id="content-nombre" class="md-100">
							<p style="font-weight:900; ">@Nombre</p>
						</div>

						<div id="content-operacion" class="md-100">
							<p>La operación de</p>
							<p id="operacion">
								<span>
									<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
									&nbsp;@operacion&nbsp;
									<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
								</span>
							</p>
							<p>se realizó  exitosamente</p>
						</div>
		
						<div id="content-detalle" class="md-70">
							<p>
								<span><b style="color: rgba(0,0,0,.7)">Fecha programada:</b></span>
								<span>@fecha_hora_operacion</span>
							</p>
							<p>
								<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
								<span>@folio</span>
							</p>
						</div>

						<!-- INICIO  SI ES UNA TRANSFERENCIA -->
						<div id="content-transferencia">
							<p>
								<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
								<span style="font-weight:500; ">@CuentaRetiro</span>
							</p>
							<p style="display: block !important; margin-top: -15px;">
								<span><b style="color: rgba(0,0,0,.7)">Cuenta Depósito:</b></span>
								<span style="font-weight:500; ">@CuentaDeposito</span>
							</p>
							<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
								<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
								<span style="font-weight:500;">@Importe</span>
							</p>	
						</div>
						<!-- FIN  SI ES UNA TRANSFERENCIA -->

						<div id="content-aclaracion" class="md-100">
							<p>
								<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
								<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
								<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
								<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
							</p>
						</div>

						<!-- FOOTER -->
						<div id="footer" class="md-100">
							<div id="footer-content-tips" class="md-100">
								<div id="tips-content-img" class="md-20">
	        						<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        					</div>
								<div id="tips-content-tips" class="md-80">
		        					<p style="font-weight:900;">Tips de Seguridad:</p> 
									<ul>
										<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
										<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
									</ul>
								</div>
							</div>
	        
							<div class="md-100">
								<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
									<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
								</a>
							</div>

						</div>
					</div>
				</body>
				</html>', N'transferencia programada|cuentas misma institución', N' ', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (59, 86, N'
								 <html>
									<head>
										<style>

										.md-100{
											width: 100%;
											margin: auto;
										}

										.md-80{
											width: 80%;
											margin: auto;
										}

										.md-70{
											width: 70%;
											margin: auto;
										}

										.md-20{
											width: 20%;
											margin: auto;
										}


										/*------------------------------------*/
										#content-principal{
											width:800px; 
											margin: auto;
										}
										/*------------------------------------*/
										#content-header{
											border-bottom: 20px solid #89BA27;
										}

										#content-header img{
											margin: 0;
										}

										/*------------------------------------*/
										#content-nombre{
											margin-top: 10px; 
											font-size: 25px; 
											color:#89BA27;
										}
										/*------------------------------------*/
										#content-operacion{
											margin-top: 10px; 
											text-align: center;
										}

										#content-operacion p{
											color:#595959;
											font-size: 25px;
											padding: 0;
											margin: 5px;
											display: inline-table;
    										width: 100%;
										}

										#operacion{
											font-weight:900 !important;
										}

										#operacion span{
											height: 25px;
											display: inline-block; 
										}

										#operacion img{
											height: 100%;
										}

										#operacion-icono {
											margin-top: 15px;
											margin-bottom: 10px;
											text-align: center;
										}

										/*------------------------------------*/
										#content-transferencia{
											margin-top: 10px; 
											font-size: 20px; 
											color:#595959;
											text-align: center;
										}

										/*------------------------------------*/
										#content-detalle{
											margin: auto;
											margin-top: 30px;
											background-color: #e4e4e4; 	
											text-align:center;
											padding: 5px;
										}
										#content-detalle p{
											font-size: 23px;
											color:#595959;
											margin: 10px;
										}
										/*------------------------------------*/
										#content-aclaracion{
											margin-top: 20px;
											text-align: center;
											font-size: 25px; 
											color:#595959;
										}
										/*------------------------------------*/
										#footer{
											background-color:#e4e4e4;
										}

										#footer-content-tips{
											display: inline-flex;
										}

										#tips-content-img{
											text-align: center;
										}

										#tips-content-tips{
											font-size: 30px; 
											color:#595959;
										}

										#tips-content-tips ul{
											font-size: 20px;
										}

										@media only screen and (max-width: 600px) {

											p, span, li{
	  											font-size: 15px !important;
	  										}

											#content-header,
											#content-nombre,
											#content-operacion,
											#content-detalle,
											#content-aclaracion,
											#footer{
												width: 90%;
												margin: auto;
											}

	  										/*------------------------------------*/
	  										#content-principal{
												width:100%; 
												margin: auto;
											}

											/*------------------------------------*/
											#content-header{
												border-bottom: 10px solid #89BA27;			
											}

											/*------------------------------------*/
											#operacion{
												font-size: 15px;	
												font-weight:900 !important;
											}

											#operacion span{
												height: 15px;
											}

											#operacion-icono img{
												width: 40px;
												height: 50px;
											}

											/*------------------------------------*/
											#content-transferencia p:last-child{
												border-bottom: 2px solid #89BA27 !important;
											}
											/*------------------------------------*/
											#footer-content-tips{
												display: block;
												padding: 10px 10px 0px 0px;
											}

											#tips-content-img,
											#tips-content-tips{
												width: 95%;
												text-align: center;
											}

											#tips-content-img img{
												width: 40px;
												height: 50px;
											}

										}
									</style>
										<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
									</head>
									<body>
										<div id="content-principal">

											<div id="content-header" class="md-100">
												<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
											</div>

											<div id="content-nombre" class="md-100">
												<p style="font-weight:900; ">@Nombre</p>
											</div>

											<div id="content-operacion" class="md-100">
												<p>La operación de</p>
												<p id="operacion">
													<span>
														<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
														&nbsp;@operacion&nbsp;
														<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
													</span>
												</p>
												<p>se realizó  exitosamente</p>
											</div>
		
											<div id="content-detalle" class="md-70">
												<p>
													<span><b style="color: rgba(0,0,0,.7)">Fecha programada:</b></span>
													<span>@fecha_hora_operacion</span>
												</p>
												<p>
													<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
													<span>@folio</span>
												</p>
											</div>

											<!-- INICIO  SI ES UNA TRANSFERENCIA -->
											<div id="content-transferencia">
												<p>
													<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
													<span style="font-weight:500; ">@CuentaRetiro</span>
												</p>
												<p style="display: block !important; margin-top: -15px;">
													<span><b style="color: rgba(0,0,0,.7)">Cuenta Depósito:</b></span>
													<span style="font-weight:500; ">@CuentaDeposito</span>
												</p>
												<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
													<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
													<span style="font-weight:500;">@Importe</span>
												</p>	
											</div>
											<!-- FIN  SI ES UNA TRANSFERENCIA -->

											<div id="content-aclaracion" class="md-100">
												<p>
													<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
													<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
													<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
													<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
												</p>
											</div>

											<!-- FOOTER -->
											<div id="footer" class="md-100">
												<div id="footer-content-tips" class="md-100">
													<div id="tips-content-img" class="md-20">
	        											<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        										</div>
													<div id="tips-content-tips" class="md-80">
		        										<p style="font-weight:900;">Tips de Seguridad:</p> 
														<ul>
															<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
															<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
														</ul>
													</div>
												</div>
	        
												<div class="md-100">
													<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
													</a>
												</div>

											</div>
										</div>
									</body>
									</html>', N'Pago programado|Pago a Préstamo|Entre socios', N' ', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (71, 17, N'<html>
							<head>
								<style>

								.md-100{
									width: 100%;
									margin: auto;
								}

								.md-80{
									width: 80%;
									margin: auto;
								}

								.md-70{
									width: 70%;
									margin: auto;
								}

								.md-20{
									width: 20%;
									margin: auto;
								}


								/*------------------------------------*/
								#content-principal{
									width:800px; 
									margin: auto;
								}
								/*------------------------------------*/
								#content-header{
									border-bottom: 20px solid #89BA27;
								}

								#content-header img{
									margin: 0;
								}

								/*------------------------------------*/
								#content-nombre{
									margin-top: 10px; 
									font-size: 25px; 
									color:#89BA27;
								}
								/*------------------------------------*/
								#content-operacion{
									margin-top: 10px; 
									text-align: center;
								}

								#content-operacion p{
									color:#595959;
									font-size: 25px;
									padding: 0;
									margin: 5px;
									display: inline-table;
    								width: 100%;
								}

								#operacion{
									font-weight:900 !important;
								}

								#operacion span{
									height: 25px;
									display: inline-block; 
								}

								#operacion img{
									height: 100%;
								}

								#operacion-icono {
									margin-top: 15px;
									margin-bottom: 10px;
									text-align: center;
								}

								/*------------------------------------*/
								#content-transferencia{
									margin-top: 10px; 
									font-size: 20px; 
									color:#595959;
									text-align: center;
								}

								/*------------------------------------*/
								#content-detalle{
									margin: auto;
									margin-top: 30px;
									background-color: #e4e4e4; 	
									text-align:center;
									padding: 5px;
								}
								#content-detalle p{
									font-size: 23px;
									color:#595959;
									margin: 10px;
								}
								/*------------------------------------*/
								#content-aclaracion{
									margin-top: 20px;
									text-align: center;
									font-size: 25px; 
									color:#595959;
								}
								/*------------------------------------*/
								#footer{
									background-color:#e4e4e4;
								}

								#footer-content-tips{
									display: inline-flex;
								}

								#tips-content-img{
									text-align: center;
								}

								#tips-content-tips{
									font-size: 30px; 
									color:#595959;
								}

								#tips-content-tips ul{
									font-size: 20px;
								}

								@media only screen and (max-width: 600px) {

									p, span, li{
	  									font-size: 15px !important;
	  								}

									#content-header,
									#content-nombre,
									#content-operacion,
									#content-detalle,
									#content-aclaracion,
									#footer{
										width: 90%;
										margin: auto;
									}

	  								/*------------------------------------*/
	  								#content-principal{
										width:100%; 
										margin: auto;
									}

									/*------------------------------------*/
									#content-header{
										border-bottom: 10px solid #89BA27;			
									}

									/*------------------------------------*/
									#operacion{
										font-size: 15px;	
										font-weight:900 !important;
									}

									#operacion span{
										height: 15px;
									}

									#operacion-icono img{
										width: 40px;
										height: 50px;
									}

									/*------------------------------------*/
									#content-transferencia p:last-child{
										border-bottom: 2px solid #89BA27 !important;
									}
									/*------------------------------------*/
									#footer-content-tips{
										display: block;
										padding: 10px 10px 0px 0px;
									}

									#tips-content-img,
									#tips-content-tips{
										width: 95%;
										text-align: center;
									}

									#tips-content-img img{
										width: 40px;
										height: 50px;
									}

								}
							</style>
								<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
							</head>
							<body>
								<div id="content-principal">

									<div id="content-header" class="md-100">
										<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
									</div>

									<div id="content-nombre" class="md-100">
										<p style="font-weight:900; ">@Nombre</p>
									</div>

									<div id="content-operacion" class="md-100">
										<p style="display:none">La operación de</p>
										<p id="operacion">
											<span>
												<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
												&nbsp;@operacion&nbsp;
												<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
											</span>
										</p>
										<p>exitosamente</p>
									</div>
		
									<div id="content-detalle" class="md-70">
										<p>
											<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
											<span>@fecha_hora_operacion</span>
										</p>
										<p>
											<span><b style="color: rgba(0,0,0,.7)">Clave de Rastreo </b></span>
											<span>@claveRastreo</span>
										</p>
									</div>

									<!-- INICIO  SI ES UNA TRANSFERENCIA -->
									<div id="content-transferencia">
										<p>
											<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
											<span style="font-weight:500; ">@CuentaRetiro</span>
										</p>
										<p style="display: block !important; margin-top: -15px;">
											<span><b style="color: rgba(0,0,0,.7)">Cuenta Beneficiario:</b></span>
											<span style="font-weight:500; ">@CuentaDeposito</span>
										</p>
										<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
											<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
											<span style="font-weight:500;">@Importe</span>
										</p>	
									</div>
									<!-- FIN  SI ES UNA TRANSFERENCIA -->

									<div id="content-aclaracion" class="md-100">
										<p>
											<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
											<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
											<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
											<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
										</p>
									</div>

									<!-- FOOTER -->
									<div id="footer" class="md-100">
										<div id="footer-content-tips" class="md-100">
											<div id="tips-content-img" class="md-20">
	        									<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        								</div>
											<div id="tips-content-tips" class="md-80">
		        								<p style="font-weight:900;">Tips de Seguridad:</p> 
												<ul>
													<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
													<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
												</ul>
											</div>
										</div>
	        
										<div class="md-100">
											<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
												<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
											</a>
										</div>

									</div>
								</div>
							</body>
							</html>', N'SPEI REALIZADO', N' ', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (72, 88, N'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p style="display:none">La operación de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
														<p> exitosamente</p>
													</div>
		
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha programada:</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
															<span>@folio</span>
														</p>
													</div>

													<!-- INICIO  SI ES UNA TRANSFERENCIA -->
													<div id="content-transferencia">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
															<span style="font-weight:500; ">@CuentaRetiro</span>
														</p>
														<p style="display: block !important; margin-top: -15px;">
															<span><b style="color: rgba(0,0,0,.7)">Cuenta Depósito:</b></span>
															<span style="font-weight:500; ">@CuentaDeposito</span>
														</p>
														<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
															<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
															<span style="font-weight:500;">@Importe</span>
														</p>	
													</div>
													<!-- FIN  SI ES UNA TRANSFERENCIA -->

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
																	<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>', N'SPEI PROGRAMADO', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (73, 89, N'<html>
												<head>
													<style>

													.md-100{
														width: 100%;
														margin: auto;
													}

													.md-80{
														width: 80%;
														margin: auto;
													}

													.md-70{
														width: 70%;
														margin: auto;
													}

													.md-20{
														width: 20%;
														margin: auto;
													}


													/*------------------------------------*/
													#content-principal{
														width:800px; 
														margin: auto;
													}
													/*------------------------------------*/
													#content-header{
														border-bottom: 20px solid #89BA27;
													}

													#content-header img{
														margin: 0;
													}

													/*------------------------------------*/
													#content-nombre{
														margin-top: 10px; 
														font-size: 25px; 
														color:#89BA27;
													}
													/*------------------------------------*/
													#content-operacion{
														margin-top: 10px; 
														text-align: center;
													}

													#content-operacion p{
														color:#595959;
														font-size: 25px;
														padding: 0;
														margin: 5px;
														display: inline-table;
    													width: 100%;
													}

													#operacion{
														font-weight:900 !important;
													}

													#operacion span{
														height: 25px;
														display: inline-block; 
													}

													#operacion img{
														height: 100%;
													}

													#operacion-icono {
														margin-top: 15px;
														margin-bottom: 10px;
														text-align: center;
													}

													/*------------------------------------*/
													#content-transferencia{
														margin-top: 10px; 
														font-size: 20px; 
														color:#595959;
														text-align: center;
													}

													/*------------------------------------*/
													#content-detalle{
														margin: auto;
														margin-top: 30px;
														background-color: #e4e4e4; 	
														text-align:center;
														padding: 5px;
													}
													#content-detalle p{
														font-size: 23px;
														color:#595959;
														margin: 10px;
													}
													/*------------------------------------*/
													#content-aclaracion{
														margin-top: 20px;
														text-align: center;
														font-size: 25px; 
														color:#595959;
													}
													/*------------------------------------*/
													#footer{
														background-color:#e4e4e4;
													}

													#footer-content-tips{
														display: inline-flex;
													}

													#tips-content-img{
														text-align: center;
													}

													#tips-content-tips{
														font-size: 30px; 
														color:#595959;
													}

													#tips-content-tips ul{
														font-size: 20px;
													}

													@media only screen and (max-width: 600px) {

														p, span, li{
	  														font-size: 15px !important;
	  													}

														#content-header,
														#content-nombre,
														#content-operacion,
														#content-detalle,
														#content-aclaracion,
														#footer{
															width: 90%;
															margin: auto;
														}

	  													/*------------------------------------*/
	  													#content-principal{
															width:100%; 
															margin: auto;
														}

														/*------------------------------------*/
														#content-header{
															border-bottom: 10px solid #89BA27;			
														}

														/*------------------------------------*/
														#operacion{
															font-size: 15px;	
															font-weight:900 !important;
														}

														#operacion span{
															height: 15px;
														}

														#operacion-icono img{
															width: 40px;
															height: 50px;
														}

														/*------------------------------------*/
														#content-transferencia p:last-child{
															border-bottom: 2px solid #89BA27 !important;
														}
														/*------------------------------------*/
														#footer-content-tips{
															display: block;
															padding: 10px 10px 0px 0px;
														}

														#tips-content-img,
														#tips-content-tips{
															width: 95%;
															text-align: center;
														}

														#tips-content-img img{
															width: 40px;
															height: 50px;
														}

													}
												</style>
												</head>
												<body>
													<div id="content-principal">

														<div id="content-header" class="md-100">
															<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
														</div>

														<div id="content-nombre" class="md-100">
															<p style="font-weight:900; ">@Nombre</p>
														</div>

														<div id="content-operacion" class="md-100">
															<p>La operación de</p>
															<p id="operacion">
																<span>
																	<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																	&nbsp;@operacion&nbsp;
																	<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
																</span>
															</p>
															<p>se realizó  exitosamente</p>
														</div>

														<div id="operacion-icono">
															@imagen
														</div>
		

														<div id="content-detalle" class="md-70">
															<p>
																<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
																<span>@fecha_hora_operacion</span>
															</p>
															<p>
																<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
																<span>@folio</span>
															</p>
														</div>

														<div id="content-aclaracion" class="md-100">
															<p>
																<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
																<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
																<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
																<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
															</p>
														</div>

														<!-- FOOTER -->
														<div id="footer" class="md-100">
															<div id="footer-content-tips" class="md-100">
																<div id="tips-content-img" class="md-20">
	        														<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        													</div>
																<div id="tips-content-tips" class="md-80">
		        													<p style="font-weight:900;">Tips de Seguridad:</p> 
																	<ul>
																		<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
																		<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
																	</ul>
																</div>
															</div>
	        
															<div class="md-100">
																<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																	<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
																</a>
															</div>

														</div>
													</div>
												</body>
												</html>', N'Alta cuenta de externas | Diferentes instituciones', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/alta_cuentas.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (74, 90, N'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p>La operación de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
														<p>se realizó  exitosamente</p>
													</div>

													<div id="operacion-icono">
														@imagen
													</div>
		

													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
															<span>@folio</span>
														</p>
													</div>

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
																	<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>', N'Baja de cuenta externa | Diferentes instituciones', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/alta_cuentas.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (75, 91, N'<html>
										<head>
											<style>

											.md-100{
												width: 100%;
												margin: auto;
											}

											.md-80{
												width: 80%;
												margin: auto;
											}

											.md-70{
												width: 70%;
												margin: auto;
											}

											.md-20{
												width: 20%;
												margin: auto;
											}


											/*------------------------------------*/
											#content-principal{
												width:800px; 
												margin: auto;
											}
											/*------------------------------------*/
											#content-header{
												border-bottom: 20px solid #89BA27;
											}

											#content-header img{
												margin: 0;
											}

											/*------------------------------------*/
											#content-nombre{
												margin-top: 10px; 
												font-size: 25px; 
												color:#89BA27;
											}
											/*------------------------------------*/
											#content-operacion{
												margin-top: 10px; 
												text-align: center;
											}

											#content-operacion p{
												color:#595959;
												font-size: 25px;
												padding: 0;
												margin: 5px;
												display: inline-table;
    											width: 100%;
											}

											#operacion{
												font-weight:900 !important;
											}

											#operacion span{
												height: 25px;
												display: inline-block; 
											}

											#operacion img{
												height: 100%;
											}

											#operacion-icono {
												margin-top: 15px;
												margin-bottom: 10px;
												text-align: center;
											}

											/*------------------------------------*/
											#content-transferencia{
												margin-top: 10px; 
												font-size: 20px; 
												color:#595959;
												text-align: center;
											}

											/*------------------------------------*/
											#content-detalle{
												margin: auto;
												margin-top: 30px;
												background-color: #e4e4e4; 	
												text-align:center;
												padding: 5px;
											}
											#content-detalle p{
												font-size: 23px;
												color:#595959;
												margin: 10px;
											}
											/*------------------------------------*/
											#content-aclaracion{
												margin-top: 20px;
												text-align: center;
												font-size: 25px; 
												color:#595959;
											}
											/*------------------------------------*/
											#footer{
												background-color:#e4e4e4;
											}

											#footer-content-tips{
												display: inline-flex;
											}

											#tips-content-img{
												text-align: center;
											}

											#tips-content-tips{
												font-size: 30px; 
												color:#595959;
											}

											#tips-content-tips ul{
												font-size: 20px;
											}

											@media only screen and (max-width: 600px) {

												p, span, li{
	  												font-size: 15px !important;
	  											}

												#content-header,
												#content-nombre,
												#content-operacion,
												#content-detalle,
												#content-aclaracion,
												#footer{
													width: 90%;
													margin: auto;
												}

	  											/*------------------------------------*/
	  											#content-principal{
													width:100%; 
													margin: auto;
												}

												/*------------------------------------*/
												#content-header{
													border-bottom: 10px solid #89BA27;			
												}

												/*------------------------------------*/
												#operacion{
													font-size: 15px;	
													font-weight:900 !important;
												}

												#operacion span{
													height: 15px;
												}

												#operacion-icono img{
													width: 40px;
													height: 50px;
												}

												/*------------------------------------*/
												#content-transferencia p:last-child{
													border-bottom: 2px solid #89BA27 !important;
												}
												/*------------------------------------*/
												#footer-content-tips{
													display: block;
													padding: 10px 10px 0px 0px;
												}

												#tips-content-img,
												#tips-content-tips{
													width: 95%;
													text-align: center;
												}

												#tips-content-img img{
													width: 40px;
													height: 50px;
												}

											}
										</style>
										</head>
										<body>
											<div id="content-principal">

												<div id="content-header" class="md-100">
													<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
												</div>

												<div id="content-nombre" class="md-100">
													<p style="font-weight:900; ">@Nombre</p>
												</div>

												<div id="content-operacion" class="md-100">
													<p>La operación de</p>
													<p id="operacion">
														<span>
															<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
															&nbsp;@operacion&nbsp;
															<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
														</span>
													</p>
													<p>se realizó  exitosamente</p>
												</div>

												<div id="operacion-icono">
													@imagen
												</div>
		

												<div id="content-detalle" class="md-70">
													<p>
														<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
														<span>@fecha_hora_operacion</span>
													</p>
													<p>
														<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
														<span>@folio</span>
													</p>
												</div>

												<div id="content-aclaracion" class="md-100">
													<p>
														<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
														<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
														<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
														<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
													</p>
												</div>

												<!-- FOOTER -->
												<div id="footer" class="md-100">
													<div id="footer-content-tips" class="md-100">
														<div id="tips-content-img" class="md-20">
	        												<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        											</div>
														<div id="tips-content-tips" class="md-80">
		        											<p style="font-weight:900;">Tips de Seguridad:</p> 
															<ul>
																<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
																<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
															</ul>
														</div>
													</div>
	        
													<div class="md-100">
														<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
															<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
														</a>
													</div>

												</div>
											</div>
										</body>
										</html>', N'Modificación de cuentas externa | Diferentes instituciones', N'<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/alta_cuentas.png" />', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (76, 92, N'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p style="display:none">La operación de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
														<p>exitosamente</p>
													</div>
		
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Clave de Rastreo </b></span>
															<span>@claveRastreo</span>
														</p>
													</div>

													<!-- INICIO  SI ES UNA TRANSFERENCIA -->
													<div id="content-transferencia">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Cuenta Ordenante:</b></span>
															<span style="font-weight:500; ">@CuentaRetiro</span>
														</p>
														<p style="display: block !important; margin-top: -15px;">
															<span><b style="color: rgba(0,0,0,.7)">Cuenta Depósito:</b></span>
															<span style="font-weight:500; ">@CuentaDeposito</span>
														</p>
														<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
															<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
															<span style="font-weight:500;">@Importe</span>
														</p>	
													</div>
													<!-- FIN  SI ES UNA TRANSFERENCIA -->

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
																	<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>', N'SPEI RECIBIDO', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (77, 21, N'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p>La operación de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
														<p>se realizó exitosamente</p>
													</div>
													@codigoActivacion
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio </b></span>
															<span>@folio</span>
														</p>
													</div>

													<!-- INICIO  SI ES UNA TRANSFERENCIA -->
													<div id="content-transferencia">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
															<span style="font-weight:500; ">@CuentaRetiro</span>
														</p>
														
													</div>
													<!-- FIN  SI ES UNA TRANSFERENCIA -->

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
																	<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>', N'Pago de servicio', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (78, 93, N'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p style="display:none">La operación de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
													       </p>@leyenda</p>
													</div>
		
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
															<span>@folio</span>
														</p>
													</div>

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
																	<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>', N'Pago de servicio rechazado', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (79, 38, N'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p>La operación de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
														<p>se realizó exitosamente</p>
													</div>
		
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
															<span>@folio</span>
														</p>
													</div>

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
																	<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>', N'Alta de servicio', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (80, 39, N'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p>La operación de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
														<p>se realizó exitosamente</p>
													</div>
		
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
															<span>@folio</span>
														</p>
													</div>

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
																	<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>', N'Actualizacion de servicio', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (81, 94, N'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p>La operación de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
														<p>se realizó exitosamente</p>
													</div>
		
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha y Hora</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
															<span>@folio</span>
														</p>
													</div>

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
																	<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>', N'Baja de pago de servicio', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (82, 96, N'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
														<p style="display:none">La operación de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;@operacion&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
														<p> exitosamente</p>
													</div>
		
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha programada:</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
															<span>@folio</span>
														</p>
													</div>

													<!-- INICIO  SI ES UNA TRANSFERENCIA -->
													<div id="content-transferencia">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
															<span style="font-weight:500; ">@CuentaRetiro</span>
														</p>
														<p style="display: block !important; margin-top: -15px;">
															<span><b style="color: rgba(0,0,0,.7)">Cuenta Depósito:</b></span>
															<span style="font-weight:500; ">@CuentaDeposito</span>
														</p>
														<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
															<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
															<span style="font-weight:500;">@Importe</span>
														</p>	
													</div>
													<!-- FIN  SI ES UNA TRANSFERENCIA -->

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
																	<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>', N'SPEI RECHAZADO', N'', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] ([id_notificacion_correo], [id_tipo_bitacora], [cuerpo], [asunto], [url_img_operacion], [fecha_alta], [activo]) VALUES (83, 97, N'<html>
											<head>
												<style>

												.md-100{
													width: 100%;
													margin: auto;
												}

												.md-80{
													width: 80%;
													margin: auto;
												}

												.md-70{
													width: 70%;
													margin: auto;
												}

												.md-20{
													width: 20%;
													margin: auto;
												}


												/*------------------------------------*/
												#content-principal{
													width:800px; 
													margin: auto;
												}
												/*------------------------------------*/
												#content-header{
													border-bottom: 20px solid #89BA27;
												}

												#content-header img{
													margin: 0;
												}

												/*------------------------------------*/
												#content-nombre{
													margin-top: 10px; 
													font-size: 25px; 
													color:#89BA27;
												}
												/*------------------------------------*/
												#content-operacion{
													margin-top: 10px; 
													text-align: center;
												}

												#content-operacion p{
													color:#595959;
													font-size: 25px;
													padding: 0;
													margin: 5px;
													display: inline-table;
    												width: 100%;
												}

												#operacion{
													font-weight:900 !important;
												}

												#operacion span{
													height: 25px;
													display: inline-block; 
												}

												#operacion img{
													height: 100%;
												}

												#operacion-icono {
													margin-top: 15px;
													margin-bottom: 10px;
													text-align: center;
												}

												/*------------------------------------*/
												#content-transferencia{
													margin-top: 10px; 
													font-size: 20px; 
													color:#595959;
													text-align: center;
												}

												/*------------------------------------*/
												#content-detalle{
													margin: auto;
													margin-top: 30px;
													background-color: #e4e4e4; 	
													text-align:center;
													padding: 5px;
												}
												#content-detalle p{
													font-size: 23px;
													color:#595959;
													margin: 10px;
												}
												/*------------------------------------*/
												#content-aclaracion{
													margin-top: 20px;
													text-align: center;
													font-size: 25px; 
													color:#595959;
												}
												/*------------------------------------*/
												#footer{
													background-color:#e4e4e4;
												}

												#footer-content-tips{
													display: inline-flex;
												}

												#tips-content-img{
													text-align: center;
												}

												#tips-content-tips{
													font-size: 30px; 
													color:#595959;
												}

												#tips-content-tips ul{
													font-size: 20px;
												}

												@media only screen and (max-width: 600px) {

													p, span, li{
	  													font-size: 15px !important;
	  												}

													#content-header,
													#content-nombre,
													#content-operacion,
													#content-detalle,
													#content-aclaracion,
													#footer{
														width: 90%;
														margin: auto;
													}

	  												/*------------------------------------*/
	  												#content-principal{
														width:100%; 
														margin: auto;
													}

													/*------------------------------------*/
													#content-header{
														border-bottom: 10px solid #89BA27;			
													}

													/*------------------------------------*/
													#operacion{
														font-size: 15px;	
														font-weight:900 !important;
													}

													#operacion span{
														height: 15px;
													}

													#operacion-icono img{
														width: 40px;
														height: 50px;
													}

													/*------------------------------------*/
													#content-transferencia p:last-child{
														border-bottom: 2px solid #89BA27 !important;
													}
													/*------------------------------------*/
													#footer-content-tips{
														display: block;
														padding: 10px 10px 0px 0px;
													}

													#tips-content-img,
													#tips-content-tips{
														width: 95%;
														text-align: center;
													}

													#tips-content-img img{
														width: 40px;
														height: 50px;
													}

												}
											</style>
												<!--<link rel="stylesheet" type="text/css" href="estilos.css">-->
											</head>
											<body>
												<div id="content-principal">

													<div id="content-header" class="md-100">
														<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_logo_blanco.png"/>	
													</div>

													<div id="content-nombre" class="md-100">
														<p style="font-weight:900; ">@Nombre</p>
													</div>

													<div id="content-operacion" class="md-100">
													  <p style="display:none">La operación de</p>
														<p id="operacion">
															<span>
																<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Felcha-izquierda-23x27.png" />
																&nbsp;Codigo de Activaction <b>@codigoActivacion</b>  de tu producto electronico&nbsp;
																<img  src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/Flecha-derecha-23x27.png" />
															</span>
														</p>
													</div>
		
													<div id="content-detalle" class="md-70">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Fecha programada:</b></span>
															<span>@fecha_hora_operacion</span>
														</p>
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Folio</b></span>
															<span>@folio</span>
														</p>
													</div>

													<!-- INICIO  SI ES UNA TRANSFERENCIA -->
													<div id="content-transferencia">
														<p>
															<span><b style="color: rgba(0,0,0,.7)">Cuenta Retiro:</b></span>
															<span style="font-weight:500; ">@CuentaRetiro</span>
														</p>
														<p style="display: block !important; margin-top: -15px;">
															<span><b style="color: rgba(0,0,0,.7)">Cuenta Depósito:</b></span>
															<span style="font-weight:500; ">@CuentaDeposito</span>
														</p>
														<p style="border-bottom: 5px solid #89BA27; display: inline-block;">
															<span><b style="color: rgba(0,0,0,.7)">Importe:</b></span>
															<span style="font-weight:500;">@Importe</span>
														</p>	
													</div>
													<!-- FIN  SI ES UNA TRANSFERENCIA -->

													<div id="content-aclaracion" class="md-100">
														<p>
															<span style="font-weight:900; ">Si tú no realizaste esta operación</span> 
															<span style="font-weight:500; "> acude a tu sucursal o llama al</span>
															<span style="font-weight:900; ">01 800 3000 268 opción "5"</span>
															<span style="font-weight:500; ">, donde con gusto te atenderemos.</span>
														</p>
													</div>

													<!-- FOOTER -->
													<div id="footer" class="md-100">
														<div id="footer-content-tips" class="md-100">
															<div id="tips-content-img" class="md-20">
	        													<img src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/candado_grande.png" />
	        												</div>
															<div id="tips-content-tips" class="md-80">
		        												<p style="font-weight:900;">Tips de Seguridad:</p> 
																<ul>
																	<li>Caja Morelia Valladolid nunca te pedirá información adicional de tus cuentas</li>
																	<li>No Compartas tu contraseña de acceso y cámbiala periódicamente</li>
																</ul>
															</div>
														</div>
	        
														<div class="md-100">
															<a href="http://www.cajamorelia.com.mx" style="text-decoration: none;">
																<img class="md-100" src="https://www.cajamorelia.com.mx/wordpress/wp-content/uploads/2018/11/cmv_url.png"></img>
															</a>
														</div>

													</div>
												</div>
											</body>
											</html>', N'CMV Finanzas | Codigo de Activación', N'', GETDATE(), 1)

SET IDENTITY_INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_CORREO] OFF

select * from banca..[TBL_BANCA_NOTIFICACIONES_CORREO]


-----TBL_BANCA_NOTIFICACIONES_CORREO-----
TRUNCATE TABLE "TBL_BANCA_NOTIFICACIONES_SMS";
SET IDENTITY_INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ON
--delete from TBL_BANCA_NOTIFICACIONES_SMS
--DBCC CHECKIDENT (TBL_BANCA_NOTIFICACIONES_SMS, RESEED, 0)


INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (1, 3, N'CMV Finanzas, Activaci�n del servicio, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (2, 11, N'CMV Finanzas, Cambio de contrase�a, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (3, 2, N'CMV Finanzas, Restablecimiento de contrase�a, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (4, 42, N'CMV Finanzas, Cambio de contrase�a de estado de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (5, 4, N'CMV Finanzas, Bloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (6, 5, N'CMV Finanzas, Bloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (7, 6, N'CMV Finanzas, Bloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (8, 7, N'CMV Finanzas, Bloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (9, 8, N'CMV Finanzas, Bloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (10, 32, N'CMV Finanzas, Bloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (11, 33, N'CMVF inanzas, Bloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (12, 34, N'CMV Finanzas, Bloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (13, 9, N'CMV Finanzas, Desbloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (14, 10, N'CMV Finanzas, Desbloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (15, 13, N'CMV Finanzas, Cancelaci�n del servicio, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (17, 41, N'CMV Finanzas, Cambio del medio de notificaci�n, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (18, 43, N'CMV Finanzas, Reposici�n de Token/NIP, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (20, 40, N'CMV Finanzas, Solicitud del alta del servicio, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (21, 46, N'CMV Finanzas, Registro del servicio, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (22, 14, N'CMV Finanzas, Cambio de imagen antiphishing, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (23, 47, N'CMV Finanzas, Cambio de Respuesta/pregunta secreta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (24, 15, N'CMV Finanzas, Deposito a @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (25, 16, N'CMV Finanzas, Deposito a @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (26, 23, N'CMV Finanzas, Pago realizado a @producto por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (27, 50, N'CMV Finanzas, Deposito a @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (29, 19, N'CMV Finanzas, Dep�sito a Inverplus CMV @numDPF por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (30, 20, N'CMV Finanzas, D�posito a  @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (31, 51, N'CMV Finanzas, Retiro de @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (32, 52, N'CMV Finanzas, Retiro de @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (33, 53, N'CMV Finanzas, Retiro de @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (34, 18, N'CMV Finanzas, Alta de cuentas interna, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (35, 48, N'CMV Finanzas, Baja de cuentas interna, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (36, 49, N'CMV Finanzas, Modificaci�n de cuentas internas, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (37, 61, N'CMV Finanzas, Cancelaci�n del servicio, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (38, 62, N'CMV Finanzas, Cancelaci�n del servicio, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (39, 56, N'CMV Finanzas, Bloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (40, 57, N'CMV Finanzas, Bloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (41, 58, N'CMV Finanzas, Bloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (42, 59, N'CMV Finanzas, Bloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (43, 60, N'CMV Finanzas, Bloqueo de cuenta, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (48, 44, N'CMV Finanzas, Cambio de l�mites de monto, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (49, 45, N'CMV Finanzas, Cancelaci�n del servicio, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (50, 54, N'CMV Finanzas, Baja de cuentas interna, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (51, 30, N'CMV Finanzas, Alta de cuenta interna la cual podr�s utilizar en 30 min, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (52, 79, N'CMV Finanzas, Tu codigo de verificaci�n es: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (53, 80, N'CMV Finanzas Operacion programada no efectuada @fecha_hora_operacion Folio: @folio Atenci�n a socios 018003000268 opci�n 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (54, 81, N'CMV Finanzas Operacion programada no efectuada @fecha_hora_operacion Folio: @folio Atenci�n a socios 018003000268 opci�n 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (56, 63, N'CMV Finanzas le informa que su solicitud ha sido registrada folio @ticket_banca, con fecha compromiso @fecha_compromiso Atenci�n a socios 018003000268', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (57, 82, N'CMV Finanzas le informa que su solicitud de aclaraci�n @ticket_banca, ha quedado resuelta, @fecha_hora_operacion Atenci�n a socios 018003000268', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (58, 83, N'CMV Finanzas le informa que su solicitud de aclaraci�n @ticket_banca, fue improcedente, @fecha_hora_operacion Atenci�n a socios 018003000268', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (59, 84, N'CMV Finanzas le informa que su solicitud de aclaraci�n @ticket_banca, fue resuelta a su favor, @fecha_hora_operacion Atenci�n a socios 018003000268', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (61, 70, N'CMV Finanzas, Deposito programado a @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (62, 85, N'CMV Finanzas, Deposito programado a @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (66, 86, N'CMV Finanzas, Pago programado a @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (67, 24, N'CMV Finanzas, Pago programado a @producto @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (79, 17, N'CMV Finanzas, SPEI realizado a @numeroReferencia por @importe, @fecha_hora_operacion, Clave de Rastreo: @claveRastreo, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (80, 88, N'CMV Finanzas,SPEI programado a @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (81, 89, N'CMV Finanzas, Alta de cuentas externas, diferentes instituciones, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (82, 90, N'CMV Finanzas, Baja de cuenta externa, diferentes instituciones, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (83, 91, N'CMV Finanzas, Modificacion de cuentas externa, diferentes instituciones, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (84, 92, N'CMV Finanzas, Deposito por SPEI a @numeroReferencia por @importe, @fecha_hora_operacion, Clave de Rastreo: @claveRastreo, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (85, 21, N'CMV Finanzas, Retiro  por pago de servicio de @descServicio por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (86, 93, N'CMV Finanzas, Pago de servicio @descServicio rechazado por @leyenda ,@fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (87, 38, N'CMV Finanzas, Alta de servicio @descServicio ,@fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (88, 39, N'CMV Finanzas, Actualizacion de servicio @descServicio ,@fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (89, 94, N'CMV Finanzas,Baja de pago de servicio @descServicio ,@fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (90, 96, N'CMV Finanzas,SPEI RECHAZADO a @numeroReferencia por @importe, @fecha_hora_operacion, Folio: @folio, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] ([id_notificacion_sms], [id_tipo_bitacora], [cuerpo], [fecha_alta], [activo]) VALUES (91, 97, N'CMV Finanzas,el codigo de activacion de tu producto electronico es @codigoActivacion, Atenci�n a socios 018003000268 opc 5', GETDATE(), 1)

SET IDENTITY_INSERT [dbo].[TBL_BANCA_NOTIFICACIONES_SMS] Off
select * from banca..[TBL_BANCA_NOTIFICACIONES_SMS]
go