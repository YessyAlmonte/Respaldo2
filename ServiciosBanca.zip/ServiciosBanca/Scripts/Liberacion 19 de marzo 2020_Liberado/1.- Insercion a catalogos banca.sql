use banca
go

-----CAT_BANCA_TIPO_COMISIONES-----
--begin tran
TRUNCATE TABLE "CAT_BANCA_TIPO_COMISIONES";
--select * from banca..[CAT_BANCA_TIPO_COMISIONES]

--delete from CAT_BANCA_TIPO_COMISIONES
--DBCC CHECKIDENT (CAT_BANCA_TIPO_COMISIONES, RESEED, 0)

if not exists(select * from CAT_BANCA_TIPO_COMISIONES where descripcion ='Reporte de aclaraci�n improcedente')
begin
	INSERT [dbo].[CAT_BANCA_TIPO_COMISIONES] ([descripcion], [monto], [fecha_alta], [activo]) VALUES ('Reporte de aclaraci�n improcedente', 250.0000, GETDATE(), 1)
end

select * from banca..[CAT_BANCA_TIPO_COMISIONES]
--rollback tran
go

-----TBL_BANCA_AYUDA_CATEGORIA-----
--delete from TBL_BANCA_AYUDA_CATEGORIA
--DBCC CHECKIDENT (TBL_BANCA_AYUDA_CATEGORIA, RESEED, 0)
TRUNCATE TABLE "TBL_BANCA_AYUDA_CATEGORIA";

if not exists(select * from TBL_BANCA_AYUDA_CATEGORIA where titulo = 'Introducci�n')
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_CATEGORIA] ([titulo], [fecha_alta]) VALUES ( 'Introducci�n', GETDATE())
end

if not exists(select * from TBL_BANCA_AYUDA_CATEGORIA where titulo = 'Acceso al Portal de servicios electr�nicos por Internet CMV Finanzas')
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_CATEGORIA] ( [titulo], [fecha_alta]) VALUES ('Acceso al Portal de servicios electr�nicos por Internet CMV Finanzas', GETDATE())
end

if not exists(select * from TBL_BANCA_AYUDA_CATEGORIA where titulo = 'Registro a CMV Finanzas')
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_CATEGORIA] ([titulo], [fecha_alta]) VALUES ('Registro a CMV Finanzas', GETDATE())
end

if not exists(select * from TBL_BANCA_AYUDA_CATEGORIA where titulo = '�C�mo enrolo mi dispositivo?')
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_CATEGORIA] ([titulo], [fecha_alta]) VALUES ('�C�mo enrolo mi dispositivo?', GETDATE())
end

if not exists(select * from TBL_BANCA_AYUDA_CATEGORIA where titulo = '�C�mo genero un Token?')
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_CATEGORIA] ([titulo], [fecha_alta]) VALUES ('�C�mo genero un Token?', GETDATE())
end

if not exists(select * from TBL_BANCA_AYUDA_CATEGORIA where titulo = 'Acceder a los servicios de CMV Finanzas')
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_CATEGORIA] ( [titulo], [fecha_alta]) VALUES ('Acceder a los servicios de CMV Finanzas', GETDATE())
end

select * from banca..[TBL_BANCA_AYUDA_CATEGORIA]
go


-----TBL_BANCA_AYUDA_PASOS-----
TRUNCATE TABLE "TBL_BANCA_AYUDA_PASOS";
--delete from TBL_BANCA_AYUDA_PASOS
--DBCC CHECKIDENT (TBL_BANCA_AYUDA_PASOS, RESEED, 0)


if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 1)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ([descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('1. Disponer de acceso a Internet', GETDATE(), 3)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 2)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('2. Utilizar navegadores recomendados como: Google Chrome, Safari y Firefox', GETDATE(), 3)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 3)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('3. Para versiones m�viles: Android (A partir de la versi�n 4.4) / iOS (A partir de la versi�n 10.0)', GETDATE(), 3)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 4)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('4. Ser socio de Caja Morelia Valladolid S.C. de A.P. de R.L. de C.V', GETDATE(), 3)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 5)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('5. Tener dado de alta el servicio a CMV Finanzas', GETDATE(), 3)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 6)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('1. Los servicios que ofrece CMV Finanzas ', GETDATE(), 4)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 7)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('2. Sucursales y ATM�s', GETDATE(), 4)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 8)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('3. Informaci�n sobre Publicidad ', GETDATE(), 4)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 9)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('4. Centro de ayuda', GETDATE(), 4)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 10)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('5. Historia, misi�n y visi�n',   getdate(), 4)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 11)
begin	
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('6. Principios cooperativos', GETDATE(), 4)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 12)
begin	
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('7. Centro de atenci�n a socios', GETDATE(), 4)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 13)
begin	
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('1. Ingresar a la p�gina Web o aplicaci�n de CMV Finanzas', GETDATE(), 5)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 14)
begin	
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('2. Dar clic en la opci�n reg�strate', GETDATE(), 5)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 15)
begin	
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('3. Ingresar n�mero de socio', GETDATE(), 5)
end

----------------------------------------------------------------------------------------------------------------------------------

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 16)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('4. Ingresar clave de acceso temporal (capturada en sucursal)',   GETDATE(), 5)
end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 17)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('5. Dar clic en continuar',   GETDATE(), 5)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 18)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('6. Seleccionar una imagen antiphishing',   GETDATE(), 5)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 19)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('7. Seleccionar de la lista una pregunta secreta',   GETDATE(), 5)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 20)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('8. Ingresar respuesta a pregunta secreta y dar clic en continuar',   GETDATE(), 5)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 21)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('9. Ingresar una nueva contrase�a',   GETDATE(), 5)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 22)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('10. Confirmar nueva contrase�a',   GETDATE(), 5)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 23)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('11. Dar clic en confirmar, para continuar',   GETDATE(), 5)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 24)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('12. Ingresar a liga de enrolamiento enviada a correo electr�nico que se proporcion� en sucursal',   GETDATE(), 5)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 25)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('1. Se verifica que llegue la liga al correo electr�nico',   GETDATE(), 7)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 26)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('2. Continuar con los pasos proporcionados en el correo electr�nico. ',   GETDATE(), 7)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 27)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('3. Dar clic en la liga de enrolamiento (Esta ligar tiene una vigencia de 2 d�as)',   GETDATE(), 7)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 28)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('3. Al dar clic en continuar se abrir� la aplicaci�n de CMV Finanzas (Tener previamente instalada la aplicaci�n de CMV 
	Finanzas), en caso de no tenerla, se puede descargar desde las tiendas en l�nea de App Store y Google Play.',   GETDATE(), 7)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 29)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('1. Ingresar n�mero de socio y dar clic en continuar',   GETDATE(), 8)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 30)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('2. Ingresar contrase�a (capturada en el registro a CMV Finanzas)',   GETDATE(), 8)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 31)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('3. Dar clic en continuar',   GETDATE(), 8)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 32)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('4. Capturar NIP y confirmar NIP (Este NIP debe ser de 4 d�gitos y no pueden tener m�s de 3 d�gitos 
	iguales en forma consecutiva y tampoco m�s de 3 d�gitos iguales en formas ascendente o descendente',   GETDATE(), 8)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 33)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('5. Dar permisos a la aplicaci�n (En caso de que el dispositivo los necesite)',   GETDATE(), 8)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 34)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('6. Se mostrar� un mensaje de que el enrolamiento fue exitoso',   GETDATE(), 8)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 35)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('7. Se muestra la pantalla principal de �Mis cuentas� dentro de la aplicaci�n',   GETDATE(), 8)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 36)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('1. Ingresar a la aplicaci�n CMV Finanzas m�vil',   GETDATE(), 9)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 37)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('2. Dar clic en el bot�n �Token virtual�',   GETDATE(), 9)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 38)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('3. Ingresar NIP dado de alta en el registro',   GETDATE(), 9)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 39)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('4. Se muestra una serie de n�meros de 6 d�gitos',   GETDATE(), 9)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 40)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('5. Ingresar esos 6 d�gitos dentro del portal web cuando se solicite',   GETDATE(), 9)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 41)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('1. Ingresar n�mero de socio y dar clic en continuar',   GETDATE(), 12)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 42)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('2. Se muestran Iniciales del nombre del socio seguido de asteriscos y la imagen antiphishing seleccionada en el registro.',   GETDATE(), 12)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 43)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('3. Ingresar contrase�a y dar clic en Entrar/Continuar',   GETDATE(), 12)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 44)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('4. Se muestra pantalla principal de �Mis cuentas�',   GETDATE(), 12)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 45)
begin
INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('1. Dentro de la pantalla principal en la parte superior derecha se encuentra la opci�n �Cerrar Sesi�n� para el portal Web y para la aplicaci�n m�vil dentro de �M�s opciones�',   GETDATE(), 13)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 46)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('2. Al dar clic en la opci�n se muestra mensaje de confirmaci�n de cierre de sesi�n',   GETDATE(), 13)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 47)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('3. Dar clic en aceptar para cerrar la sesi�n en el portal Web',   GETDATE(), 13)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 48)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('1. Dentro del portal Web se muestra una opci�n de �Mis cuentas�',   GETDATE(), 14)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 49)
begin
	INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('2. Al dar clic en esta opci�n se muestran las cuentas de:',   GETDATE(), 14)
end

if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 50) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ('a.	Dep�sitos a la vista',   GETDATE(), 14) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 51) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'b.	Pr�stamos (en caso de tener pr�stamos activos)',   GETDATE(), 14) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 52) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'c.	Dep�sitos a plazo fijo (en caso de tener inversiones)',   GETDATE(), 14) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 53) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3.	De cada cuenta activa se muestra el saldo actual de la cuenta',   GETDATE(), 14) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 54) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Dar clic en una cuenta se muestra el detalle de la cuenta: Cuenta, Saldo, Total de dep�sitos y retiros al d�a.',   GETDATE(), 15) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 55) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Para ver los movimientos de la cuenta, dar clic en �Ver movimientos de cuenta�',   GETDATE(), 15) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 56) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Se muestran todos los movimientos del periodo actual de la cuenta, con la informaci�n de:',   GETDATE(), 15) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 57) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'a.	Fecha del movimiento',   GETDATE(), 15) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 58) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'b.	Descripci�n',   GETDATE(), 15) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 59) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'c.	Monto depositado o retirado',   GETDATE(), 15) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 60) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'd.	Saldo de la cuenta al momento de realizarse el movimiento',   GETDATE(), 15) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 61) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4.	Se podr�n buscar movimientos del periodo actual y anterior',   GETDATE(), 15) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 62) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'a.	Periodo actual: comprende de la fecha de consulta a un mes atr�s 06 de enero - 06 de diciembre',   GETDATE(), 15) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 63) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'b.	Periodo anterior: comprende de la fecha de consulta a tres meses atr�s 06 de enero - 06 de octubre',   GETDATE(), 15) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 64) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Ingresar a CMV Finanzas e ingresar n�mero de socio ',   GETDATE(), 16) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 65) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Se muestra las iniciales del nombre de socio seguido de asteriscos y la imagen antiphishing seleccionada en el registro',   GETDATE(), 16) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 66) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Se solicita ingresar la contrase�a (El socio al olvidar la clave tendr� la opci�n de recuperar su contrase�a en la opci�n (�olvid� mi clave de acceso!)',   GETDATE(), 16) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 67) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Responder pregunta secreta y dar clic en continuar/aceptar',   GETDATE(), 16) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 68) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. Ingresar y confirmar nueva contrase�a.',   GETDATE(), 16) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 69) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Ingresar Token desde el portal Web (�C�mo generar un Token?)  o NIP desde la aplicaci�n',   GETDATE(), 16) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 70) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '7. Dar clic en continuar',   GETDATE(), 16) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 71) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Seleccionar opci�n de transferencias desde la cinta principal de opciones o desde el acceso directo dentro de una cuenta de dep�sito a la vista ',   GETDATE(), 17) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 72) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Seleccionar cuenta de retiro ',   GETDATE(), 17) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 73) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Seleccionar cuenta de deposito',   GETDATE(), 17) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 74) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Ingresar monto a transferir y dar clic en continuar si la transferencia se desea realizar en el momento.',   GETDATE(), 17) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 75) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. En caso de que no se va a realizar en el momento, seleccionar la opci�n de �Programar transferencia� y dar clic en continuar',   GETDATE(), 17) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 76) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Se muestra la confirmaci�n de la transferencia (Revisar que los datos sean correctos)',   GETDATE(), 17) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 77) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '7. Dar clic en confirmar',   GETDATE(), 17) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 78) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '8. Se muestra resultado de la transferencia con las opciones y atajos de: guardar, imprimir, mis cuentas y otro pago',   GETDATE(), 17) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 79) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Seleccionar opci�n de �Inversiones� desde la cinta principal de opciones o desde el acceso directo dentro de una cuenta',   GETDATE(), 18) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 80) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Dar clic en la cuenta e ingresar el monto a retirar ',   GETDATE(), 18) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 81) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Elegir el plazo de la inversi�n',   GETDATE(), 18) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 82) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'a.	14-60 d�as',   GETDATE(), 18) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 83) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'b.	91 d�as',   GETDATE(), 18) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 84) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'c.	180 d�as',   GETDATE(), 18) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 85) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Se muestra la tasa de rendimiento conforme al monto a invertir y el plazo elegido.',   GETDATE(), 18) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 86) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. Dar clic en continuar',   GETDATE(), 18) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 87) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Se muestra la confirmaci�n de la inversi�n (Revisar que los datos sean correctos)',   GETDATE(), 18) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 88) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '7. Ingresar Token desde el portal Web (�C�mo generar un Token?)  o NIP desde la aplicaci�n',   GETDATE(), 18) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 89) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '8. Dar clic en confirmar',   GETDATE(), 18) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 90) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '9. Se muestra resultado de la inversi�n con las opciones y atajos de: mis cuentas y otra inversi�n',   GETDATE(), 18) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 91) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Seleccionar opci�n de �Inversiones� desde la cinta principal de opciones',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 92) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Dar clic en la opci�n de �cancelar inversi�n� ',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 93) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Se muestran las inversiones activas.',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 94) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Al dar clic en una inversi�n activa, se muestra una opci�n para cancelar la inversi�n',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 95) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. Dar clic en la opci�n cancelar',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 96) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Se muestra la informaci�n de:',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 97) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	�	Saldo',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 98) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	�	Fecha de apertura',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 99) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	�	N�mero de contrato',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 100) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	�	Fecha de vencimiento',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 101) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	�	Plazo de inversi�n',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 102) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	�	Tasas de inter�s',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 103) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '7. Ingresar Token desde el portal Web (�C�mo generar un Token?)  o NIP desde la aplicaci�n',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 104) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '8. Dar clic en confirmar',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 105) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '9. Se muestra resultado de la cancelaci�n de inversi�n con las opciones y atajos de: Ir a inversiones y cancelar otra inversi�n',   GETDATE(), 19) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 106) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Seleccionar opci�n de �Administraci�n� desde la cinta principal de opciones',   GETDATE(), 21) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 107) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Dar clic en el bot�n �Nueva cuenta�',   GETDATE(), 21) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 108) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Ingresar la informaci�n de:',   GETDATE(), 21) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 109) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'a.	Cuenta que se desea dar de alta de otro socio (16 d�gitos) �De d�nde obtengo la cuenta? (Al ingresar los 16 d�gitos de la cuenta se muestra el nombre del socio que se est� dando de alta)',   GETDATE(), 21) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 110) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'b.	Alias',   GETDATE(), 21) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 111) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'c.	Monto m�ximo (cantidad m�xima que se va a permitir realizar a esa cuenta dada de alta)',   GETDATE(), 21) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 112) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'd.	Correo electr�nico',   GETDATE(), 21) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 113) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Dar clic en continuar',   GETDATE(), 21) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 114) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. Se muestra la confirmaci�n del alta (Revisar que los datos sean correctos)',   GETDATE(), 21) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 115) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Ingresar Token desde el portal Web (�C�mo generar un Token?)  o NIP desde la aplicaci�n',   GETDATE(), 21) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 116) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '7. Dar clic en confirmar',   GETDATE(), 21) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 117) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '8. Se muestra resultado del alta de cuenta con las opciones y atajos de: Mis cuentas y dar de alta otra cuenta',   GETDATE(), 21) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 118) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Seleccionar opci�n de �Administraci�n� desde la cinta principal de opciones',   GETDATE(), 22) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 119) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Seleccionar una cuenta y dar clic en la opci�n ',   GETDATE(), 22) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 120) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Se muestra la informaci�n de la cuenta',   GETDATE(), 22) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 121) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Ingresar informaci�n a actualizar (solo se permite editar el correo electr�nico, alias y monto m�ximo)',   GETDATE(), 22) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 122) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. Se muestra la confirmaci�n de la edici�n (Revisar que los datos sean correctos)',   GETDATE(), 22) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 123) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Ingresar Token desde el portal Web (�C�mo generar un Token?)  o NIP desde la aplicaci�n',   GETDATE(), 22) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 124) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '7. Dar clic en continuar ',   GETDATE(), 22) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 125) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '8. Se muestra resultado de la edici�n de cuenta con las opciones y atajos de: Mis cuentas ',   GETDATE(), 22) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 126) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Seleccionar opci�n de �Administraci�n� desde la cinta principal de opciones ',   GETDATE(), 23) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 127) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Seleccionar una cuenta y dar clic en la opci�n',   GETDATE(), 23) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 128) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Se muestra la confirmaci�n de la eliminaci�n ',   GETDATE(), 23) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 129) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Dar clic en Si, continuar',   GETDATE(), 23) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 130) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. Ingresar Token desde el portal Web (�C�mo generar un Token?)  o NIP desde la aplicaci�n',   GETDATE(), 23) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 131) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Dar clic en confirmar',   GETDATE(), 23) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 132) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '7. Se muestra resultado de la eliminaci�n de cuenta',   GETDATE(), 23) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 133) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Seleccionar opci�n de transferencias desde la cinta principal de opciones ',   GETDATE(), 24) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 134) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Seleccionar la opci�n �Entre socios�',   GETDATE(), 24) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 135) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Seleccionar cuenta de retiro ',   GETDATE(), 24) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 136) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Seleccionar cuenta de dep�sito (se muestra un atajo para dar de alta una nueva cuenta en caso de que no se tenga dada de alta la cuenta a la que se va a depositar))',   GETDATE(), 24) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 137) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. Ingresar monto a transferir y dar clic en continuar si la transferencia se desea realizar en el momento.',   GETDATE(), 24) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 138) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( 'a.	En caso de que no se va a realizar en el momento, seleccionar la opci�n de �Programar transferencia� y dar clic en continuar',   GETDATE(), 24) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 139) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Se muestra la confirmaci�n de la transferencia (Revisar que los datos sean correctos)',   GETDATE(), 24) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 140) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '7. Ingresar Token desde el portal Web (�C�mo generar un Token?)  o NIP desde la aplicaci�n',   GETDATE(), 24) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 141) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '8. Dar clic en continuar',   GETDATE(), 24) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 142) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '9. Se muestra resultado de la transferencia con las opciones y atajos de: Mis cuentas y otra transferencia',   GETDATE(), 24) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 143) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Seleccionar opci�n de Administraci�n desde la cinta principal de opciones ',   GETDATE(), 25) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 144) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Seleccionar opci�n de configuraci�n y dar clic en cambiar imagen antiphishing',   GETDATE(), 25) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 145) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Elegir nueva imagen de antiphishing',   GETDATE(), 25) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 146) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Eliges la nueva imagen y te pide la clave din�mica',   GETDATE(), 25) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 147) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. Ingresar Token desde el portal Web (�C�mo generar un Token?)  o NIP desde la aplicaci�n',   GETDATE(), 25) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 148) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Dar clic en continuar',   GETDATE(), 25) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 149) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '7. Se muestra el resultado de la modificaci�n',   GETDATE(), 25) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 150) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '8. Al cerrar sesi�n y volver a ingresar desde cualquier medio, se mostrar� la nueva imagen seleccionada',   GETDATE(), 25) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 151) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Seleccionar opci�n de Administraci�n desde la cinta principal de opciones ',   GETDATE(), 26) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 152) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Seleccionar opci�n de configuraci�n y dar clic en cambio de contrase�a',   GETDATE(), 26) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 153) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Ingresar y confirmar nueva contrase�a, dar clic en continuar',   GETDATE(), 26) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 154) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Ingresar Token desde el portal Web (�C�mo generar un Token?)  o NIP desde la aplicaci�n',   GETDATE(), 26) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 155) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. Dar clic en continuar',   GETDATE(), 26) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 156) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Se muestra resultado de la modificaci�n con las opciones y atajos de: Mis cuentas ',   GETDATE(), 26) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 157) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Seleccionar opci�n de Administraci�n desde la cinta principal de opciones ',   GETDATE(), 27) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 158) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Seleccionar opci�n de configuraci�n y dar clic en cambio de pregunta secreta',   GETDATE(), 27) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 159) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Seleccionar nueva pregunta secreta e ingresar respuesta secreta',   GETDATE(), 27) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 160) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Ingresar Token desde el portal Web (�C�mo generar un Token?)  o NIP desde la aplicaci�n',   GETDATE(), 27) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 161) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. Dar clic en continuar',   GETDATE(), 27) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 162) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Se muestra resultado de la modificaci�n con las opciones y atajos de: Mis cuentas ',   GETDATE(), 27) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 163) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Seleccionar opci�n de transferencias desde la cinta principal de opciones o desde el acceso directo dentro de una cuenta de dep�sito a la vista',   GETDATE(), 28) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 164) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Seleccionar cuenta de retiro y cuenta de deposito ',   GETDATE(), 28) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 165) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Ingresar monto a transferir y seleccionar la opci�n de �Programar transferencia� ',   GETDATE(), 28) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 166) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Seleccionar la fecha en la que se desea realizar el movimiento',   GETDATE(), 28) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 167) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. Se muestra la confirmaci�n de la transferencia (Revisar que los datos sean correctos)',   GETDATE(), 28) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 168) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Dar clic en confirmar',   GETDATE(), 28) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 169) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '7. Se muestra resultado de la transferencia con las opciones y atajos de: guardar, imprimir, mis cuentas y otra transferencia',   GETDATE(), 28) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 170) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Seleccionar opci�n de pagos desde la cinta principal de opciones o desde el acceso directo dentro de una cuenta de pr�stamo',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 171) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Seleccionar cuenta de retiro',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 172) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Seleccionar cuenta de dep�sito (se muestra los pr�stamos activos)',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 173) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Seleccionar tipo de pago:',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 174) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	�	Pago para liquidar',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 175) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	�	Pago al d�a de hoy',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 176) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	�	Otra cantidad',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 177) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	Al seleccionar otra cantidad y si la cantidad es mayor que la opci�n pago al d�a de hoy, se muestran las opciones a elegir de tipo de pago de:',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 178) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	-	Reducci�n de plazo',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 179) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	-	Reducci�n de amortizaci�n',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 180) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	Una vez seleccionado el tipo de pago, dar clic en continuar si la transferencia se desea realizar en el momento.',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 181) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '	En caso de que no se va a realizar en el momento, seleccionar la opci�n de �Programar pago� y dar clic en continuar (Esta opci�n solo est� habilitado en el tipo de pago �Otra cantidad� cuando la cantidad es menor del pago al d�a de hoy)',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 182) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. Se muestra la confirmaci�n del pago (Revisar que los datos sean correctos)',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 183) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Dar clic en confirmar ',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 184) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '7. Se muestra resultado del pago con las opciones y atajos de: Guardar, Imprimir, Mis cuentas y otro pago ',   GETDATE(), 30) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 185) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '1. Seleccionar opci�n de pagos desde la cinta principal de opciones o desde el acceso directo dentro de una cuenta de pr�stamo',   GETDATE(), 31) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 186) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '2. Seleccionar cuenta de retiro y cuenta de deposito ',   GETDATE(), 31) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 187) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '3. Ingresar monto a pagar y seleccionar la opci�n de �Programar pago� ',   GETDATE(), 31) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 188) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '4. Seleccionar la fecha en la que se desea realizar el movimiento',   GETDATE(), 31) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 189) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '5. Se muestra la confirmaci�n del pago (Revisar que los datos sean correctos)',   GETDATE(), 31) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 190) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '6. Dar clic en confirmar',   GETDATE(), 31) end
if not exists(select * from TBL_BANCA_AYUDA_PASOS where id_ayuda_paso = 191) begin INSERT [dbo].[TBL_BANCA_AYUDA_PASOS] ( [descripcion], [fecha_alta], [id_ayuda_seccion]) VALUES ( '7. Se muestra resultado del pago con las opciones y atajos de: guardar, imprimir, mis cuentas y otro pago',   GETDATE(), 31) end


select * from banca..[TBL_BANCA_AYUDA_PASOS]
go

use BANCA
go
-----TBL_BANCA_AYUDA_SECCIONES-----
TRUNCATE TABLE "TBL_BANCA_AYUDA_SECCIONES";
SET IDENTITY_INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] off
--delete from TBL_BANCA_AYUDA_SECCIONES
--truncate table TBL_BANCA_AYUDA_SECCIONES
--DBCC CHECKIDENT (TBL_BANCA_AYUDA_SECCIONES, RESEED, 0)

--SET IDENTITY_INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ON 
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'La presente gu�a tiene como objetivo dar a conocer a nuestros socios la forma de operar 
	los servicios que se ofrecer�n dentro del portal de CMV finanzas y la aplicaci�n para dispositivos m�viles.', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'Recuerde que las claves y contrase�as personales son confidenciales.', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'Requisitos m�nimos', GETDATE(), 1)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'Al acceder al portal de CMV Finanzas se podr� conocer', GETDATE(), 2)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'Una vez que se solicit� el servicio en la Sucursal, el socio debe de registrarse en el portal de CMV finanzas 
	(Es importante contar con n�mero se socio y la clave de acceso temporal registrada en Sucursal)', GETDATE(), 3)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'Nota: Para poder tener acceso a todos los servicios de CMV Finanzas es importante realizar el enrolamiento en 
	un dispositivo m�vil.', GETDATE(), 3)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'Una vez que se realiz� el registro de manera correcta dentro de CMV Finanzas: ', GETDATE(), 4)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'Dentro de CMV Finanzas', GETDATE(), 4)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'', GETDATE(), 5)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'Nota: El tiempo valido de los 6 d�gitos es de 30 segundos, una vez que se acab� el tiempo, se tiene que 
	generar otro OTP, ingresando de nueva cuenta el NIP', GETDATE(), 5)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'Para acceder a los servicios de CMV Finanzas es necesario ingresar a CMV Finanzas:', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Login (Inicio de sesi�n)', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Logout (Cierre de sesi�n)', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Consulta de cuentas', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Consulta de detalle de cuenta y movimientos', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Recuperar contrase�a', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Transferencias cuentas propias', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Apertura de inversiones', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Cancelaci�n de inversiones', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'Nota: Las inversiones solo se pueden cancelar el d�a de su vencimiento ', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Alta de cuentas terceros mismo banco (entre socios)', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Editar cuentas terceros mismo banco', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Eliminar cuentas terceros mismo banco', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Transferencias terceros mismo banco (Otros socios)', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Cambio de imagen antiphishing', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Cambio de Contrase�a', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Cambiar Pregunta y Respuesta Secreta', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Programar Transferencia', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'Nota: Las transferencias programadas se aplicar�n dentro de un horario de (4:00:00 a.m. 5:00:00 am)', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Pago de Cr�ditos Propios', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'Programar pago', N'', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'Nota: Los pagos programados se aplicar�n dentro de un horario de (4:00:00 a.m. 5:00:00 am).', GETDATE(), 6)
INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] ( [titulo], [descripcion], [fecha_alta], [id_ayuda_categoria]) VALUES ( N'', N'Solo se podr�n programar los pagos con tipo de pago seleccionado �Otra cantidad� con un monto menor al pago al d�a de hoy, al momento de la consulta.', GETDATE(), 6)
--SET IDENTITY_INSERT [dbo].[TBL_BANCA_AYUDA_SECCIONES] OFF

select * from banca..[TBL_BANCA_AYUDA_SECCIONES]
go

---------------

-----TBL_BANCA_LIMITES_TRANSFERENCIAS-----
TRUNCATE TABLE "TBL_BANCA_LIMITES_TRANSFERENCIAS";
--delete from TBL_BANCA_LIMITES_TRANSFERENCIAS
--DBCC CHECKIDENT (TBL_BANCA_LIMITES_TRANSFERENCIAS, RESEED, 0)

INSERT [dbo].[TBL_BANCA_LIMITES_TRANSFERENCIAS] ( [id_limite_transferencia], [minimo], [maximo], [activo], [fecha_alta]) VALUES (1, N'1', N'50000', 1, GETDATE() )
INSERT [dbo].[TBL_BANCA_LIMITES_TRANSFERENCIAS] ( [id_limite_transferencia], [minimo], [maximo], [activo], [fecha_alta]) VALUES (2, N'06:00:00', N'23:00:00', 1, GETDATE() )
INSERT [dbo].[TBL_BANCA_LIMITES_TRANSFERENCIAS] ( [id_limite_transferencia], [minimo], [maximo], [activo], [fecha_alta]) VALUES (3, N'1', N'50000', 1, GETDATE() )
INSERT [dbo].[TBL_BANCA_LIMITES_TRANSFERENCIAS] ( [id_limite_transferencia], [minimo], [maximo], [activo], [fecha_alta]) VALUES (4, N'500', N'50000', 1, GETDATE() )
INSERT [dbo].[TBL_BANCA_LIMITES_TRANSFERENCIAS] ( [id_limite_transferencia], [minimo], [maximo], [activo], [fecha_alta]) VALUES (5, N'1', N'50000', 1, GETDATE() )
INSERT [dbo].[TBL_BANCA_LIMITES_TRANSFERENCIAS] ( [id_limite_transferencia], [minimo], [maximo], [activo], [fecha_alta]) VALUES (6, N'0', N'10000', 1, GETDATE() )
INSERT [dbo].[TBL_BANCA_LIMITES_TRANSFERENCIAS] ( [id_limite_transferencia], [minimo], [maximo], [activo], [fecha_alta]) VALUES (7, N'-1', N'-1', 1, GETDATE() )
INSERT [dbo].[TBL_BANCA_LIMITES_TRANSFERENCIAS] ( [id_limite_transferencia], [minimo], [maximo], [activo], [fecha_alta]) VALUES (8, N'1', N'50000', 1, GETDATE() )
INSERT [dbo].[TBL_BANCA_LIMITES_TRANSFERENCIAS] ( [id_limite_transferencia], [minimo], [maximo], [activo], [fecha_alta]) VALUES (9, N'1', N'50000', 1, GETDATE() )
INSERT [dbo].[TBL_BANCA_LIMITES_TRANSFERENCIAS] ( [id_limite_transferencia], [minimo], [maximo], [activo], [fecha_alta]) VALUES (10, N'1', N'10000', 1, GETDATE() )
INSERT [dbo].[TBL_BANCA_LIMITES_TRANSFERENCIAS] ( [id_limite_transferencia], [minimo], [maximo], [activo], [fecha_alta]) VALUES (11, N'1', N'50000', 1, GETDATE() )

select * from banca..[TBL_BANCA_LIMITES_TRANSFERENCIAS]
go

