﻿using ServiciosBancaEntidades;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ServiciosBancaCMV.Autenticacion
{
    public class CustomHeader : MessageHeader
    {
        private const string CUSTOM_HEADER_NAME = "";
        private const string CUSTOM_HEADER_NAMESPACE = "";
        private ServiceHeader _customData;

        public ServiceHeader CustomData
        {
            get
            {
                return _customData;
            }
        }

        public CustomHeader()
        {
        }

        public CustomHeader(ServiceHeader customData)
        {
            _customData = customData;
        }

        public override string Name
        {
            get { return (CUSTOM_HEADER_NAME); }
        }

        public override string Namespace
        {
            get { return (CUSTOM_HEADER_NAMESPACE); }
        }

        protected override void OnWriteHeaderContents(
            System.Xml.XmlDictionaryWriter writer, MessageVersion messageVersion)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ServiceHeader));
            StringWriter textWriter = new StringWriter();
            serializer.Serialize(textWriter, _customData);
            textWriter.Close();

            string text = textWriter.ToString();

            writer.WriteElementString(CUSTOM_HEADER_NAME, "Key", text.Trim());
        }

        public static ServiceHeader ReadHeader(Message request)
        {
            /*
            foreach (var item in request.Headers)
            {
                Console.WriteLine(item.Name);
            }
            
            Int32 headerPosition = request.Headers.FindHeader("Header", "http://schemas.xmlsoap.org/soap/envelope/");
            if (headerPosition == -1)
            {
                headerPosition = request.Headers.FindHeader(CUSTOM_HEADER_NAME, "http://schemas.xmlsoap.org/soap/envelope");
                if (headerPosition == -1)
                    return null;
            }

            MessageHeaderInfo headerInfo = request.Headers[headerPosition];
            XmlNode[] content = request.Headers.GetHeader<XmlNode[]>(headerPosition);
            string text = content[0].InnerText;
            XmlSerializer deserializer = new XmlSerializer(typeof(ServiceHeader));
            TextReader textReader = new StringReader(text);
            ServiceHeader customData = (ServiceHeader)deserializer.Deserialize(textReader);
            textReader.Close();
            */
            //Bitacora<Message> Bex = new Bitacora<Message>(request);
            //new Logg().Error(SerializerManager<Bitacora<Message>>.SerealizarObjtecToString(Bex));
            ServiceHeader header = new ServiceHeader();
            header.usuario = GetHeader(request ,"Usuario", "");
            header.contrasena  = GetHeader(request,"Contrasena", "");

            return header;
        }

        private static string GetHeader(Message request,string name, string ns)
        {

            if (request.Headers.FindHeader(name, ns) > -1)
                return request.Headers.GetHeader<String>(name, ns);
            else if (request.Headers.FindHeader(name, "http://schemas.xmlsoap.org/soap/envelope/") > -1)
                return request.Headers.GetHeader<String>(name, "http://schemas.xmlsoap.org/soap/envelope/");
            else
                return string.Empty;

            return string.Empty;
        }
    }
}