﻿using log4net;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace ServiciosBancaCMV.Autenticacion
{

    public class CustomMessageInspector : ServiceLog , IClientMessageInspector, IDispatchMessageInspector
    {
        //private readonly ILog log4netResponse;
        private readonly ILog log4netRequest;
        private readonly ILog log4netRequestSI;
        public CustomMessageInspector() : base()
        {
            //log4netResponse = LogManager.GetLogger("LogResponse");
            log4netRequest = LogManager.GetLogger("LogRequest");
            log4netRequestSI = LogManager.GetLogger("LogRequestSI");
        }    
        public void AfterReceiveReply(ref Message reply, object correlationState)
        {
        }

        public object AfterReceiveRequest(ref Message request, IClientChannel channel, InstanceContext instanceContext)
        {
            
            //log = LogManager.GetLogger(typeof(CustomMessageInspector));
            MessageBuffer buffer = request.CreateBufferedCopy(Int32.MaxValue);
            request = buffer.CreateMessage();
            Message messageCopy = buffer.CreateMessage();
            //para obtener el metodo y la peticion del ws 
            var action = OperationContext.Current.IncomingMessageHeaders.Action;
            var operationName = action.Substring(action.LastIndexOf("/") + 1);
            StringWriter stringWriter = new StringWriter();
            XmlTextWriter xmlTextWriter = new XmlTextWriter(stringWriter);
            xmlTextWriter.Formatting = Formatting.Indented;
            xmlTextWriter.Indentation = 1;
            xmlTextWriter.IndentChar = '\t';
            messageCopy.WriteMessage(xmlTextWriter);
            
            
            // Read the custom context data from the headers
            ServiceHeader header = CustomHeader.ReadHeader(request);

            // Add an extension to the current operation context so
            // that our custom context can be easily accessed anywhere.
            //ServerContext customContext = new ServerContext();
            string AnStringForTheResultWithNoFileds = "", XMLString = stringWriter.ToString();
            Boolean mostrarEnLogs = IsShowInLogs(XMLString);
            if (mostrarEnLogs)
            {
                AnStringForTheResultWithNoFileds = removeFields(XMLString);
                log4netRequestSI.Info("Mensaje de Entrada: (Request) \n\n" + AnStringForTheResultWithNoFileds);

            }
            /*else
            { 
                log4netRequest.Info("Mensaje de Entrada: (Request) \n\n" + stringWriter.ToString());
            }*/
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                Utilerias.validaUsuario(header.usuario, header.contrasena);
                //Debug.WriteLine("Mensaje de Entrada: " + stringWriter.ToString());
                if (mostrarEnLogs)
                {
                    new Logg().Info("Mensaje de Entrada: (Request) \n\n" + AnStringForTheResultWithNoFileds);
                }
                /*else
                {
                    new Logg().Info("Mensaje de Entrada: (Request) \n\n" + stringWriter.ToString());
                }*/
            }
            OperationContext.Current.IncomingMessageProperties.Add(
                     "CurrentContext", header);
            return null;
        }

        /*
         * Remueve un campo de un xml, basado en la posición en un stringbuilder
         * Sirve para quitar un tag de un XMLString sin necesidad de convertir
         * el String en XML
         */
        public String removeFields(String XMLString)
        {
            if (XMLString.Contains("AutenticarSocio"))
            {
                return removePartOfXML("Contrasena", removePartOfXML("Contrasena", XMLString));
            }

            if (XMLString.Contains("ActivarBanca"))
            {
                return removePartOfXML("Respuesta", removePartOfXML("NuevaContrasena", removePartOfXML("ContrasenaConfirmada", XMLString)));
            }

            if (XMLString.Contains("ValidaContrasenaTemporal"))
            {
                return removePartOfXML("ContrasenaTemporal", XMLString);
            }

            if (XMLString.Contains("TransferenciasCuentasPropias"))
            {
                return replaceDateOfXML("HoraProgramada", XMLString);
            }

            if (XMLString.Contains("TransferenciasCuentasExterna"))
            {
                return replaceDateOfXML("HoraProgramada", XMLString);
            }

            if (XMLString.Contains("PagarPrestamoCuentasPropias"))
            {
                return replaceDateOfXML("HoraTransaccion", XMLString);
            }

            if (XMLString.Contains("ObtenerComprobantesPago"))
            {
                return replaceDateOfXML("FechaInicio", replaceDateOfXML("FechaFin", XMLString));
                
            }
            if (XMLString.Contains("ObtenerDetalleCuentaResponse"))
            {
                return replaceDateOfXML("FechaVencimiento", XMLString);
            }

            return XMLString;
        }

        public String replaceDateOfXML(String part, String XMLString) {
            try
            {

                Regex r = new Regex(part + ">(.*?)</");
                Match match = r.Match(XMLString);
                String toReplace = match.Value;
                if (toReplace != null && toReplace != String.Empty)
                {
                    String stringHour = toReplace.Replace(part + ">", "").Replace("</", "");
                    DateTime newDate = Convert.ToDateTime(toReplace.Replace(part + ">", "").Replace("</", ""));
                    String letterDate = newDate.ToString("dddd d 'de' MMMM 'del' yyyy 'a las' hh:mm tt", System.Globalization.CultureInfo.CreateSpecificCulture("es-MX"));
                    letterDate = part + ">" + letterDate + "</";
                    return XMLString.Replace(toReplace, letterDate);
                }
                else
                {
                    return XMLString;
                }
            }
            catch (Exception e) {
                return XMLString;
            }
        }

        public String removeFieldsOnResponse(String XMLString)
        {
            if (XMLString.Contains("ObtenerDetalleCuentaResponse"))
            {
                //XMLString = Regex.Replace(XMLString, @"<([a-z0-9][a-z0-9][a-z0-9][a-z0-9]):NumeroTarjeta>([0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9])<\/([a-z0-9][a-z0-9][a-z0-9][a-z0-9]):NumeroTarjeta>","");
                return replaceDateOfXML("UltimoAbono", removePartOfXML("NumeroTarjeta", XMLString));
            }

            if (XMLString.Contains("ObtenerInversionesSocioResponse"))
            {
                return replaceDateOfXML("FechaCancelable", XMLString);
            }

            return XMLString;
        }

        public String removePartOfXML(String nombreEtiqueta, String XMLString)
        {
           
            string BeginTagToSearchInXML = "";
            string EndTagToSearchInXML = "";
            int start = 0, end = 0, tagStart = 0, tagEnd = 0;
            
            BeginTagToSearchInXML   = XMLString.Contains(nombreEtiqueta+">") ? nombreEtiqueta + ">" : "</>";
            //Posición primera letra del contenido de las etiquetas
            start = XMLString.IndexOf(BeginTagToSearchInXML)-6;
            //Posición contenido último caracter del contenido de la etiqueta
            if(start > 0)
            {

                tagStart = XMLString.IndexOf("<", start);
                tagEnd = XMLString.IndexOf(BeginTagToSearchInXML, start + 6 + BeginTagToSearchInXML.Length) + BeginTagToSearchInXML.Length;
            }
            return
                tagStart > 0  &&
                tagEnd > 0 
                ? XMLString.Remove(tagStart, tagEnd - tagStart) : XMLString;
           
        }

        /*
         * Se definen que requests no se desean ver en los logs
         * Ni la petición ni la respuesta
         */
        public Boolean IsShowInLogs(string Body)
        {
            String[] metodos = 
            {
                "ObtenerAyuda",
                "ObtenerTerminosCondiciones",
                "ObtenerFondoPantalla",
                "ObtenerAvisoPrivacidad",
                "ObtenerCatalogoPreguntas",
                "ObtenerCategoriasServicios",
                "ObtenerBancos",
                "ObtenerProductos",
                "ObtenerImagenesAntiphishing",
                "ObtenerLimitesTransferencias",
                "ObtenerServiciosRecurrentes",
                "ObtenerPublicidadDirigida"                                
            };
            if (metodos.Any(Body.Contains))
                return false;
            return true;
        }
        public void BeforeSendReply(ref Message reply, object correlationState)
        {

            MessageBuffer buffer = reply.CreateBufferedCopy(Int32.MaxValue);
            reply = buffer.CreateMessage();
            Message messageCopy = buffer.CreateMessage();

            if (reply.IsFault)
            {
                XmlElement elm;
                var messageFault = MessageFault.CreateFault(messageCopy, Int32.MaxValue);
                if (messageFault.HasDetail)
                {
                    log4netRequest.Info("Mensaje de Salida: " + messageFault.GetReaderAtDetailContents().ReadOuterXml());
                    log4netRequestSI.Info("Mensaje de Salida: " + messageFault.GetReaderAtDetailContents().ReadOuterXml());
                    new Logg().Error("Mensaje de Salida: " + messageFault.GetReaderAtDetailContents().ReadOuterXml());
                }
                else
                {
                    new Logg().Error(messageFault.Reason.ToString() + " | " + messageFault.Code.Name);
                    log4netRequest.Info(messageFault.Reason.ToString() + " | " + messageFault.Code.Name);
                    log4netRequestSI.Info(messageFault.Reason.ToString() + " | " + messageFault.Code.Name);
                }
            }
            else if(IsShowInLogs(messageCopy.ToString()))
            {
                /*StringWriter stringWriter = new StringWriter();
                XmlTextWriter xmlTextWriter = new XmlTextWriter(stringWriter);
                xmlTextWriter.Formatting = Formatting.Indented;
                xmlTextWriter.Indentation = 1;
                xmlTextWriter.IndentChar = '\t';*/

                /*
                messageCopy.WriteMessage(xmlTextWriter);
                if (stringWriter.ToString().Contains("ObtenerImagenesAntiphishingResponse") ||
                    stringWriter.ToString().Contains("ValidaNumeroResponse") ||
                    stringWriter.ToString().Contains("ResponseObtenerPublicidadGeneral") ||
                    stringWriter.ToString().Contains("ResponseObtenerPublicidadDirigida"))
                {

                    string cadena = stringWriter.ToString();
                    string toFind1 = "ImagenAntiphishing";
                    int start = cadena.IndexOf(toFind1) + toFind1.Length;
                    int end = cadena.IndexOf(toFind1, start); //Start after the index of 'my' since 'is' appears twice
                    if (start > 0 && end > 0)
                    {
                        StringBuilder sb = new StringBuilder(cadena);
                        sb.Remove(start, end - start);
                        cadena = sb.ToString();
                    }
                    log4netRequest.Info("Mensaje de Salida (Response): \n\n" + cadena);
                    new Logg().Info("Mensaje de Salida (Response): \n\n" + cadena);
                }
                else
                {
                    new Logg().Info("Mensaje de Salida (Response): \n\n" + stringWriter.ToString());
                    log4netRequest.Info("Mensaje de Salida (Response): \n\n" +stringWriter.ToString());
                }*/
                String ToLog = removeFieldsOnResponse(messageCopy.ToString());
                new Logg().Info("Mensaje de Salida (Response): \n\n" + ToLog);
                log4netRequest.Info("Mensaje de Salida (Response): \n\n" + ToLog);
                log4netRequestSI.Info("Mensaje de Salida (Response): \n\n" + ToLog);
            }
            OperationContext.Current.Extensions.Remove(ServerContext.Current);
        }

        


        public object BeforeSendRequest(ref Message request, IClientChannel channel)
        {
            MessageBuffer buffer = request.CreateBufferedCopy(Int32.MaxValue);
            request = buffer.CreateMessage();

            ServiceHeader customData = new ServiceHeader();

            customData.usuario = ClientContext.usuario;
            customData.contrasena = ClientContext.contrasena;

            CustomHeader header = new CustomHeader(customData);

            // Add the custom header to the request.
            request.Headers.Add(header);

            return null;
        }
    }
}
