﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiciosBancaCMV.Autenticacion
{
    class ClientContext
    {
        public static string usuario;
        public static string contrasena;


    }
}
