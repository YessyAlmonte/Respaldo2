﻿using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosBancaCMV.Imagenes
{
    
    [ServiceContract]
    public interface IImagenes
    {
        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerFondoPantalla))]
        //byte[] ObtenerFondoPantalla();
        string ObtenerFondoPantalla();

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerPublicidadGeneral))]
        ResponseObtenerPublicidadGeneral ObtenerPublicidadGeneral();

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerPublicidadDirigida))]
        ResponseObtenerPublicidadDirigida ObtenerPublicidadDirigida(RequestObtenerPublicidadDirigida request);

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerImagenesAntiphishing))]
        ResponseObtenerImagenesAntiphishing ObtenerImagenesAntiphishing();
    }
}
