﻿using log4net;
using ServiciosBancaCMV.Autenticacion;
using ServiciosBancaDAO;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Autenticacion;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;


namespace ServiciosBancaCMV.Imagenes
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Images" en el código y en el archivo de configuración a la vez.
    [CustomBehavior]
    public class Imagenes : ServiceLog, IImagenes
    {
        private readonly ILog log;

        public Imagenes() : base()
        {
            log = LogManager.GetLogger(typeof(Imagenes));
        }
        //public byte[] ObtenerFondoPantalla()
        public string ObtenerFondoPantalla()
        {
            byte[] imagen = null;
            string result = string.Empty;
            try
            {
                result = new ImagenesDAO().ObtenerFondoPantalla();
                //if (!string.IsNullOrEmpty(result))
                //{
                //    imagen = File.ReadAllBytes(result);
                //}

            }
            catch (Exception ex)
            {
                ExceptionObtenerFondoPantalla exceptionObtenerImagenFondo = new ExceptionObtenerFondoPantalla();
                exceptionObtenerImagenFondo.Codigo = 1000;
                exceptionObtenerImagenFondo.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerImagenFondo.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerFondoPantalla> Bex = new Bitacora<ExceptionObtenerFondoPantalla>("02", exceptionObtenerImagenFondo, "ObtenerImagenFondo");
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerFondoPantalla>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerFondoPantalla>(exceptionObtenerImagenFondo, exceptionObtenerImagenFondo.Mensaje);
            }
            return result;
        }

        public ResponseObtenerImagenesAntiphishing ObtenerImagenesAntiphishing()
        {
            try
            {
                log.Debug("prueba");
                return new ImagenesDAO().ObtenerImagenesAntiphishing();

            }
            catch (Exception ex)
            {
                ExceptionObtenerImagenesAntiphishing exceptionObtenerImagenesAntiphishing = new ExceptionObtenerImagenesAntiphishing();
                exceptionObtenerImagenesAntiphishing.Codigo = 1000;
                exceptionObtenerImagenesAntiphishing.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerImagenesAntiphishing.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerImagenesAntiphishing> Bex = new Bitacora<ExceptionObtenerImagenesAntiphishing>("02", exceptionObtenerImagenesAntiphishing, "ObtenerImagenesAntiphishing");
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerImagenesAntiphishing>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerImagenesAntiphishing>(exceptionObtenerImagenesAntiphishing, exceptionObtenerImagenesAntiphishing.Mensaje);
            }
        }

        public ResponseObtenerPublicidadDirigida ObtenerPublicidadDirigida(RequestObtenerPublicidadDirigida request)
        {
            try
            {
                return new ImagenesDAO().ObtenerPublicidadDirigida(request);

            }
            catch (Exception ex)
            {
                ExceptionObtenerPublicidadDirigida exceptionObtenerImagenFondo = new ExceptionObtenerPublicidadDirigida();
                exceptionObtenerImagenFondo.Codigo = 1000;
                exceptionObtenerImagenFondo.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerImagenFondo.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerPublicidadDirigida> Bex = new Bitacora<ExceptionObtenerPublicidadDirigida>("02", exceptionObtenerImagenFondo, "ObtenerImagenFondo");
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerPublicidadDirigida>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerPublicidadDirigida>(exceptionObtenerImagenFondo, exceptionObtenerImagenFondo.Mensaje);
            }

        }

        public ResponseObtenerPublicidadGeneral ObtenerPublicidadGeneral()
        {

            try
            {
                return new ImagenesDAO().ObtenerPublicidadGeneral();

            }
            catch (Exception ex)
            {
                ExceptionObtenerPublicidadGeneral exceptionObtenerPublicidadGeneral = new ExceptionObtenerPublicidadGeneral();
                exceptionObtenerPublicidadGeneral.Codigo = 1000;
                exceptionObtenerPublicidadGeneral.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerPublicidadGeneral.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerPublicidadGeneral> Bex = new Bitacora<ExceptionObtenerPublicidadGeneral>("02", exceptionObtenerPublicidadGeneral, "ObtenerImagenFondo");
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerPublicidadGeneral>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerPublicidadGeneral>(exceptionObtenerPublicidadGeneral, exceptionObtenerPublicidadGeneral.Mensaje);
            }
        }

    }
}
