﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaEntidades;
using ServiciosBancaUtils.Logg;
using ServiciosBancaUtils;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaDAO;
using ServiciosBancaEntidades.Autenticacion;
using ServiciosBancaCMV.Autenticacion;

namespace ServiciosBancaCMV.Cuenta
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Cuentas" en el código y en el archivo de configuración a la vez.
    [CustomBehavior]
    public class Cuentas : ICuentas
    {

        public ResponseObtenerCuentas ObtenerCuentas(RequestObtenerCuentas request)
        {
            try
            {
                //Bitacora<RequestObtenerCuentas> b = new Bitacora<RequestObtenerCuentas>(request.NumeroSocio.ToString(), request);
                //Logg a = new Logg();
                //a.Info(SerializerManager<Bitacora<RequestObtenerCuentas>>.SerealizarObjtecToString(b));
                return new CuentaDAO().ObtenerCuentas(request);
            }
            catch (FaultException<ExceptionObtenerCuentas> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerCuentas exceptionIniciarSesion = new ExceptionObtenerCuentas();
                exceptionIniciarSesion.Codigo = 1000;
                exceptionIniciarSesion.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionIniciarSesion.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerCuentas> Bex = new Bitacora<ExceptionObtenerCuentas>(request.NumeroSocio.ToString(), exceptionIniciarSesion, request.NumeroSocio.ToString());
                //new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerCuentas>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerCuentas>(exceptionIniciarSesion, exceptionIniciarSesion.Mensaje);
            }
        }
        private static string GetHeader(string name, string ns)
        {

            if (OperationContext.Current.IncomingMessageHeaders.FindHeader(name, ns) > -1)
                return OperationContext.Current.IncomingMessageHeaders.GetHeader<String>(name, ns);
            else if (OperationContext.Current.IncomingMessageHeaders.FindHeader(name, "http://schemas.xmlsoap.org/soap/envelope/") > -1)
                return OperationContext.Current.IncomingMessageHeaders.GetHeader<String>(name, "http://schemas.xmlsoap.org/soap/envelope/");
            else
                return string.Empty;

            return string.Empty;
        }
        public ResponseObtenerMovimientosCuenta ObtenerMovimientosCuenta(RequestObtenerMovimientosCuenta request)
        {
            try
            {                                
                return new CuentaDAO().ObtenerMovimientosCuenta(request);
            }
            catch (FaultException<ExceptionObtenerMovimientosCuenta> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionObtenerMovimientosCuenta exceptionObtenerMovimientosCuenta = new ExceptionObtenerMovimientosCuenta();
                exceptionObtenerMovimientosCuenta.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionObtenerMovimientosCuenta.Descripcion = ef.Message;
                exceptionObtenerMovimientosCuenta.Mensaje = ef.Message;
                Bitacora<ExceptionObtenerMovimientosCuenta> Bex = new Bitacora<ExceptionObtenerMovimientosCuenta>(request.NumeroSocio.ToString(), exceptionObtenerMovimientosCuenta, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerMovimientosCuenta>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerMovimientosCuenta>(exceptionObtenerMovimientosCuenta);
            }
            catch (Exception ex)
            {
                ExceptionObtenerMovimientosCuenta ExceptionObtenerMovimientosCuenta = new ExceptionObtenerMovimientosCuenta();
                ExceptionObtenerMovimientosCuenta.Codigo = 1000;
                ExceptionObtenerMovimientosCuenta.Descripcion = Utilerias.ExcepcionDebug(ex);
                ExceptionObtenerMovimientosCuenta.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerMovimientosCuenta> Bex = new Bitacora<ExceptionObtenerMovimientosCuenta>(request.NumeroSocio.ToString(), ExceptionObtenerMovimientosCuenta, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerMovimientosCuenta>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerMovimientosCuenta>(ExceptionObtenerMovimientosCuenta, ExceptionObtenerMovimientosCuenta.Mensaje);
            }
        }
        public ResponseObtenerDetalleCuenta ObtenerDetalleCuenta(RequestObtenerDetalleCuenta request)
        {
            try
            {
                Bitacora<RequestObtenerDetalleCuenta> b = new Bitacora<RequestObtenerDetalleCuenta>(request.NumeroSocio.ToString(), request);
                //new Logg().Info(SerializerManager<Bitacora<RequestObtenerCuentas>>.SerealizarObjtecToString(b));
                ResponseObtenerDetalleCuenta responseObtenerDetalleCuenta = new ResponseObtenerDetalleCuenta();
                responseObtenerDetalleCuenta.cuenta = new CuentaDAO().ObtenerDetalleCuenta(request);
                return responseObtenerDetalleCuenta;
            }
            catch (FaultException<ExceptionObtenerDetalleCuenta> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerDetalleCuenta exceptionObtenerCuenta = new ExceptionObtenerDetalleCuenta();
                exceptionObtenerCuenta.Codigo = 1000;
                exceptionObtenerCuenta.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerCuenta.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionObtenerDetalleCuenta> Bex = new Bitacora<ExceptionObtenerDetalleCuenta>(request.NumeroSocio.ToString(), exceptionObtenerCuenta, request.NumeroSocio.ToString());
                //new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerCuentas>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerDetalleCuenta>(exceptionObtenerCuenta);
            }
        }
    }
}
