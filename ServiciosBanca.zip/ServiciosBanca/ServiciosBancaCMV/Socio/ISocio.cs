﻿using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosBancaCMV.Socio
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "ISocio" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface ISocio
    {
        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerInformacionSocio))]
        ResponseObtenerInformacionSocio ObtenerInformacionSocio(RequestObtenerInformacionSocio request);

        //[OperationContract]
        [FaultContract(typeof(ExceptionRegistrarSocio))]
        ResponseRegistrarSocio RegistrarSocio(RequestRegistrarSocio request);

        [OperationContract]
        [FaultContract(typeof(ExceptionActualizarEstatus))]
        ResponseActualizarEstatus ActualizarEstatus(RequestActualizarEstatus request);

        [OperationContract]
        [FaultContract(typeof(ExceptionActivarBanca))]
        ResponseActivarBanca ActivarBanca(RequestActivarBanca request);

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerGestionBeneficiarios))]
        ResponseObtenerGestionBeneficiarios ObtenerGestionBeneficiarios(RequestObtenerGestionBeneficiarios request);


        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerNombrePorClabe))]
        ResponseObtenerNombrePorClabe ObtenerNombrePorClabe(RequestObtenerNombrePorClabe request);

        [OperationContract]
        [FaultContract(typeof(ExceptionActualizaPreguntaRespuestaSecreta))]
        ResponseActualizaPreguntaRespuestaSecreta ActualizaPreguntaRespuestaSecreta(RequestActualizaPreguntaRespuestaSecreta request);

        #region CONTRASEÑAS

        [OperationContract]
        [FaultContract(typeof(ExceptionActualizarImagenAntiphishing))]
        ResponseActualizarImagenAntiphishing ActualizarImagenAntiphishing(RequestActualizarImagenAntiphishing request);


        [OperationContract]
        [FaultContract(typeof(ExceptionValidaContrasenaTemporal))]
        ResponseValidaContrasenaTemporal ValidaContrasenaTemporal(RequestValidaContrasenaTemporal request);

        [OperationContract]
        [FaultContract(typeof(ExceptionCambiarContrasena))]
        //5)Cambio Contraseña
        ResponseCambiarContrasena CambiarContrasena(RequestCambiarContrasena request);

        [OperationContract]
        [FaultContract(typeof(ExceptionValidarRespuesta))]
        ///6)	Olvidó Contraseña  
        ResponseValidarRespuesta ValidarRespuesta(RequestValidarRespuesta request);

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerPreguntaSecreta))]
        //6)	Olvidó Contraseña
        ResponseObtenerPreguntaSecreta ObtenerPreguntaSecreta(RequestObtenerPreguntaSecreta request);

        [OperationContract]
        [FaultContract(typeof(ExceptionGenerarContrasenaTemp))]
        ResponseGenerarContrasenaTemp GenerarContrasenaTemp(RequestGenerarContrasenaTemp request);



        #endregion

        #region PAGO DE SERVICIOS

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerServiciosSocio))]
        ResponseObtenerServiciosSocio ObtenerServiciosSocio(RequestObtenerServiciosSocio request);

        [OperationContract]
        [FaultContract(typeof(ExceptionEliminarServicioSocio))]
        ResponseEliminarServicioSocio EliminarServicioSocio(RequestEliminarServicioSocio request);

        #endregion

        #region INVERSIONES

        [OperationContract]
        [FaultContract(typeof(ExceptionCancelarInversionSocio))]
        ResponseCancelarInversionSocio CancelarInversionSocio(RequestCancelarInversionSocio request);

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerInversionesSocio))]
        ResponseObtenerInversionesSocio ObtenerInversionesSocio(RequestObtenerInversionesSocio request);


        #endregion

        #region ESTADOS DE CUENTA

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerEstadoCuenta))]
        ResponseObtenerEstadoCuenta ObtenerEstadosDeCuenta(RequestObtenerEstadoCuenta request);

        [OperationContract]
        [FaultContract(typeof(ExceptionDescargaEstadoDeCuenta))]
        ResponseDescargaEstadoDeCuenta DescargaEstadoDeCuenta(RequestDescargaEstadoDeCuenta request);

        #endregion

        #region TARJETAS DE CREDITO O DEBITO
        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerTarjetas))]
        ResponseObtenerTarjetas ObtenerTarjetas(RequestObtenerTarjetas request);

        [OperationContract]
        [FaultContract(typeof(ExceptionBloquearTarjeta))]
        ResponseBloquearTarjeta BloquearTarjeta(RequestBloquearTarjeta request);

        [OperationContract]
        [FaultContract(typeof(ExceptionDesbloquearTarjeta))]
        ResponseDesbloquearTarjeta DesbloquearTarjeta(RequestDesbloquearTarjeta request);

        #endregion

        #region PAGO A PRESTAMOS
        [OperationContract]
        [FaultContract(typeof(ExceptionPagarPrestamoCuentasPropias))]
        ResponsePagarPrestamoCuentasPropias PagarPrestamoCuentasPropias(RequestPagarPrestamoCuentasPropias request);

        [OperationContract]
        [FaultContract(typeof(ExceptionPagarPrestamoCuentasMismoBanco))]
        ResponsePagarPrestamoCuentasMismoBanco PagarPrestamoCuentasMismoBanco(RequestPagarPrestamoCuentasMismoBanco request);
        #endregion

        #region BITACORA
        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerBitacoraSocio))]
        ResponseObtenerBitacoraSocio ObtenerBitacoraSocio(RequestObtenerBitacoraSocio request);
        #endregion

  

    }
}
