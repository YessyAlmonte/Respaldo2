﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using AutoMapper;
using BusCrypto;
using ServiciosBancaDAO;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Autenticacion;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.PagoDeServicios;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;

namespace ServiciosBancaCMV.Domiciliacion
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Domiciliacion" en el código y en el archivo de configuración a la vez.
    [CustomBehavior]
    public class Domiciliacion : IDomiciliacion
    {
        public ResponseAltaDomiciliacion AltaDomiciliacion(RequestAltaDomiciliacion request)
        {
            try
            {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);

                if (request.TipoDomiciliacion == TipoDomiciliacion.PagoServicios)
                {
                    WsPagoDeServicios._ResponseConsultaSaldo wsResponse = null;

                    CatalogoDAO catalogoDAO = new CatalogoDAO();
                    RequestObtenerProductos requestObtenerProductos = new RequestObtenerProductos();
                    requestObtenerProductos.IdServicio = request.IdServicio;
                    requestObtenerProductos.tipoFront = 4;

                    ResponseObtenerProductos responseObtenerProductos = new ResponseObtenerProductos();

                    try
                    {
                        responseObtenerProductos = catalogoDAO.ObtenerProductos(requestObtenerProductos);
                    }
                    catch (FaultException<ExceptionObtenerProductos> ex)
                    {
                        ExceptionAltaDomiciliacion exceptionAltaDomiciliacion = new ExceptionAltaDomiciliacion();
                        exceptionAltaDomiciliacion.Codigo = 335;
                        exceptionAltaDomiciliacion.Mensaje = "El servicio seleccionado no se puede domiciliar";
                        throw new FaultException<ExceptionAltaDomiciliacion>(exceptionAltaDomiciliacion, exceptionAltaDomiciliacion.Mensaje);

                    }


                    RequestConsultaSaldo requestConsulta = new RequestConsultaSaldo();

                    requestConsulta.IdProducto = Convert.ToInt32(responseObtenerProductos.Productos[0].IdProducto);
                    requestConsulta.IdServicio = Convert.ToInt32(request.IdServicio.ToString());
                    requestConsulta.NumeroReferencia = request.NumeroReferencia;
                    //requestConsulta.OTP
                    requestConsulta.Precio = 0;
                    requestConsulta.Monto = 0;
                    requestConsulta.MontoComision = 0;
                    requestConsulta.Telefono = "";
                    requestConsulta.TipoFront = 4;
                    requestConsulta.NumeroSocio = request.NumeroSocio;
                    requestConsulta.TipoOrigen = request.TipoOrigen;
                    //SE ASIGAN EL FolioBanca a UPC 
                    requestConsulta.EnvioUpc = 1;
                    //Se genera la hora local para gestopago
                    requestConsulta.HoraLocal = DateTime.Now.ToString("yyyyMMddHHmmss");

                    //INSTANCIAMOS UN OBJETO DEL WEB SERVICE
                    WsPagoDeServicios.PagoDeServiciosClient wsPagoServicos = new WsPagoDeServicios.PagoDeServiciosClient();

                    //MAPPER PARA CONSUMIR EL WEB SERVICE
                    Mapper.Initialize(x =>
                    {
                        x.ValidateInlineMaps = false;
                        x.CreateMap<RequestPagarServicios, WsPagoDeServicios.RequestPagarServicios>();
                    });
                    WsPagoDeServicios.RequestPagarServicios wsRequest = Mapper.Map<WsPagoDeServicios.RequestPagarServicios>(requestConsulta);
                    Mapper.Reset();

                    //SE CONSUME EL WEB SERVICE DE GESTO  DE PAGO DE SERVICIO
                    using (new OperationContextScope(wsPagoServicos.InnerChannel))
                    {
                        MessageHeader MessageHeaderUsuario = MessageHeader.CreateHeader("Usuario", "", "CMVF1nZ4S");
                        MessageHeader MessageHeaderContrasena = MessageHeader.CreateHeader("Contrasena", "", "8DED40B6E19F14D1651FDDF063CDD2");
                        OperationContext.Current.OutgoingMessageHeaders.Add(MessageHeaderUsuario);
                        OperationContext.Current.OutgoingMessageHeaders.Add(MessageHeaderContrasena);
                        wsResponse = wsPagoServicos.ConsultarSaldoSerivicio(wsRequest);
                    }

                    if (Convert.ToInt32(wsResponse.ResponseAbonar.MENSAJE.CODIGO.ToString()) != 1)
                    {
                        ExceptionAltaDomiciliacion exceptionAltaDomiciliacion = new ExceptionAltaDomiciliacion();
                        exceptionAltaDomiciliacion.Codigo = Convert.ToInt32(wsResponse.ResponseAbonar.MENSAJE.CODIGO.ToString());  //result.Codigo;
                        exceptionAltaDomiciliacion.Mensaje = wsResponse.ResponseAbonar.MENSAJE.TEXTO;
                        throw new FaultException<ExceptionAltaDomiciliacion>(exceptionAltaDomiciliacion, exceptionAltaDomiciliacion.Mensaje);
                    }



                }
                return new DomiciliacionDAO().AltaDomicilacion(request);

            }
            catch (FaultException<ExceptionAltaDomiciliacion> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionAltaDomiciliacion exceptionValidaOTP = new ExceptionAltaDomiciliacion();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionAltaDomiciliacion> Bex = new Bitacora<ExceptionAltaDomiciliacion>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionAltaDomiciliacion>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaDomiciliacion>(exceptionValidaOTP, exceptionValidaOTP.Mensaje);
            }
            catch (Exception ex)
            {
                ExceptionAltaDomiciliacion exceptionAltaCuentaInterna = new ExceptionAltaDomiciliacion();
                exceptionAltaCuentaInterna.Codigo = 1000;
                exceptionAltaCuentaInterna.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionAltaCuentaInterna.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionAltaDomiciliacion> Bex = new Bitacora<ExceptionAltaDomiciliacion>(request.NumeroSocio.ToString(), exceptionAltaCuentaInterna, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionAltaDomiciliacion>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAltaDomiciliacion>(exceptionAltaCuentaInterna, exceptionAltaCuentaInterna.Descripcion);
            }
        }

        public ResponseEliminarDomiciliacion EliminarDomiciliacion(RequestEliminarDomiciliacion request)
        {
            try
            {
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new DomiciliacionDAO().EliminarDomiciliacion(request);
            }
            catch (FaultException<ExceptionEliminarDomiciliacion> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionEliminarDomiciliacion exceptionValidaOTP = new ExceptionEliminarDomiciliacion();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionEliminarDomiciliacion> Bex = new Bitacora<ExceptionEliminarDomiciliacion>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionEliminarDomiciliacion>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionEliminarDomiciliacion>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                ExceptionEliminarDomiciliacion exceptionEliminarDomiciliacion = new ExceptionEliminarDomiciliacion();
                exceptionEliminarDomiciliacion.Codigo = 1000;
                exceptionEliminarDomiciliacion.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionEliminarDomiciliacion.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionEliminarDomiciliacion> Bex = new Bitacora<ExceptionEliminarDomiciliacion>("0", exceptionEliminarDomiciliacion, "0");
                new Logg().Error(SerializerManager<Bitacora<ExceptionEliminarDomiciliacion>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionEliminarDomiciliacion>(exceptionEliminarDomiciliacion);
            }
        }

        public ResponseObtenerPeriodicidadesServicios ObtenerPeriodicidadesServicios(RequestObtenerPeriodicidadesServicios request)
        {
            try
            {
                return new DomiciliacionDAO().ObtenerPeriodicidadesServicios(request);
            }
            catch (FaultException<ExceptionCancelarDomiciliacion> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerPeriodicidadesServicios exceptionObtenerPeriodicidades = new ExceptionObtenerPeriodicidadesServicios();
                exceptionObtenerPeriodicidades.Codigo = 1000;
                exceptionObtenerPeriodicidades.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerPeriodicidades.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerPeriodicidadesServicios>(exceptionObtenerPeriodicidades);
            }
        }

        public ResponseGenerarFormatoDomiciliacion GenerarFormatoDomiciliacion(RequestGenerarFormatoDomiciliacion request)
        {
            try
            {
                return new DomiciliacionDAO().GenerarFormatoDomiciliacion(request);
            }
            catch (FaultException<ExceptionGenerarFormatoDomiciliacion> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionGenerarFormatoDomiciliacion exceptionGenerarFormatoDomiciliacion = new ExceptionGenerarFormatoDomiciliacion();
                exceptionGenerarFormatoDomiciliacion.Codigo = 1000;
                exceptionGenerarFormatoDomiciliacion.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionGenerarFormatoDomiciliacion.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionGenerarFormatoDomiciliacion>(exceptionGenerarFormatoDomiciliacion);
            }
        }
    }
}
