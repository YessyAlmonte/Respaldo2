﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaEntidades;
using ServiciosBancaUtils.Logg;
using ServiciosBancaUtils;
using ServiciosBancaDAO;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Inversiones;
using BusCrypto;
using ServiciosBancaEntidades.Autenticacion;

namespace ServiciosBancaCMV.Inversion
{
    [CustomBehavior]
    public class Inversiones : IInversiones
    {
        public ResponseRealizarInversion RealizarInversion(RequestRealizarInversion request)
        {
            try
            {
                //request.Dias = 20;
                //request.CuentasRetiro = new List<CuentaInversion>();
                //request.NumeroSocio = "666481";
                //request.OTP = "12345";
                //request.Tasa = 4;
                //request.TipoOrigen = TipoOrigen.BANCA_WEB_;

                //CuentaInversion c = new CuentaInversion();
                //c.IdMov = 100;
                //c.Monto = 250;
                //request.CuentasRetiro.Add(c);
                //c = new CuentaInversion();
                //c.IdMov = 103;
                //c.Monto = 200;
                //request.CuentasRetiro.Add(c);


                //Bitacora<RequestRealizarInversion> b = new Bitacora<RequestRealizarInversion>(request.NumeroSocio.ToString(), request);
                //new Logg().Info(SerializerManager<Bitacora<RequestRealizarInversion>>.SerealizarObjtecToString(b));
                string result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                return new InversionesDAO().RealizarInversionesSocio(request);

            }
            catch (FaultException<ExceptionRealizarInversion> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionRealizarInversion exceptionRealizarInversion = new ExceptionRealizarInversion();
                exceptionRealizarInversion.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionRealizarInversion.Descripcion = ef.Message;
                exceptionRealizarInversion.Mensaje = ef.Message;
                
                throw new FaultException<ExceptionRealizarInversion>(exceptionRealizarInversion);
            }
            catch (Exception ex)
            {
                ExceptionRealizarInversion exceptionRealizarInversion = new ExceptionRealizarInversion();
                exceptionRealizarInversion.Codigo = 1000;
                exceptionRealizarInversion.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionRealizarInversion.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionRealizarInversion> Bex = new Bitacora<ExceptionRealizarInversion>(request.NumeroSocio.ToString(), exceptionRealizarInversion, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionRealizarInversion>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionRealizarInversion>(exceptionRealizarInversion);
            }
        }
    }
}
