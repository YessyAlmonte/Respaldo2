﻿using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosBancaCMV.Inversion
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IInversiones" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IInversiones
    {
        [OperationContract]
        [FaultContract(typeof(ExceptionRealizarInversion))]
        ResponseRealizarInversion RealizarInversion(RequestRealizarInversion request);

    }
}
