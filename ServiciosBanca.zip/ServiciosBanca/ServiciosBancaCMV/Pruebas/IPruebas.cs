﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosBancaCMV.Pruebas
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IPruebas" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IPruebas
    {
        [OperationContract]
        bool AcutalizarContraseñas();


        [OperationContract]
        string  EscribirArchivo();



        [OperationContract]
        void AltaDomicliacion();



        [OperationContract]
        string CifraInformacion(string informacion);


        [OperationContract]
        string DesCifraInformacion(string informacion);

        [OperationContract]
        string Notificacion(string numeroSocio, int bitacora);


        [OperationContract]
        string EscribirEventView(string texto);

        [OperationContract]
        string GenerarLlave();
    }
}
