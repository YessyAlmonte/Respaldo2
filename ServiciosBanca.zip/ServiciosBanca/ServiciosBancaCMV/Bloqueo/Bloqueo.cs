﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using BusCrypto;
using ServiciosBancaDAO;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;
using ServiciosBancaEntidades.Autenticacion;

namespace ServiciosBancaCMV.Bloqueo
{
    [CustomBehavior]
    public class Bloqueo : IBloqueo
    {
        BloqueoDAO bloqueoDAO = null;
        public ResponseBloqueoTemporal BloqueoTemporal(RequestBloqueoTemporal request)///FALTA VALIDAR OTP///
        {
            //ConexionAPI.ObtenerConexionSA();
            ResponseBloqueoTemporal response = new ResponseBloqueoTemporal();
            try
            {
                //Bitacora<RequestBloqueoTemporal> b = new Bitacora<RequestBloqueoTemporal>(request.NumeroSocio.ToString(), request);
                //new Logg().Info(SerializerManager<Bitacora<RequestBloqueoTemporal>>.SerealizarObjtecToString(b));
                string result =string.Empty;
                if (request.IdMotivoBloqueo == TipoBloqueo.Bloqueo_temporal_propio)
                    result = AgenteConecta.ValidarOTP(request.NumeroSocio, request.OTP);
                bloqueoDAO = new BloqueoDAO();
                response = bloqueoDAO.BloqueoTemporal(request);
            }
            catch (FaultException<ExceptionBloqueoTemporal> ex)
            {
                throw ex;
            }
            catch (FaultException ef)
            {
                ExceptionBloqueoTemporal exceptionValidaOTP = new ExceptionBloqueoTemporal();
                exceptionValidaOTP.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionValidaOTP.Descripcion = ef.Message;
                exceptionValidaOTP.Mensaje = ef.Message;
                Bitacora<ExceptionBloqueoTemporal> Bex = new Bitacora<ExceptionBloqueoTemporal>(request.NumeroSocio.ToString(), exceptionValidaOTP, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionBloqueoTemporal>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionBloqueoTemporal>(exceptionValidaOTP);
            }
            catch (Exception ex)
            {
                ExceptionBloqueoTemporal exceptionBloqueoTemporal = new ExceptionBloqueoTemporal();
                exceptionBloqueoTemporal.Codigo = 1000;
                exceptionBloqueoTemporal.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionBloqueoTemporal.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionBloqueoTemporal> Bex = new Bitacora<ExceptionBloqueoTemporal>(request.NumeroSocio.ToString(), exceptionBloqueoTemporal, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionBloqueoTemporal>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionBloqueoTemporal>(exceptionBloqueoTemporal);
            }
            return response;
        }
        public ResponseBloqueoTemporalDataBanking BloqueoTemporalDataBanking(RequestBloqueoTemporalDataBanking request)
        {
            ResponseBloqueoTemporalDataBanking response = new ResponseBloqueoTemporalDataBanking();
            try
            {
                Bitacora<RequestBloqueoTemporalDataBanking> b = new Bitacora<RequestBloqueoTemporalDataBanking>(request.NumeroSocio.ToString(), request);
                new Logg().Info(SerializerManager<Bitacora<RequestBloqueoTemporalDataBanking>>.SerealizarObjtecToString(b));
                bloqueoDAO = new BloqueoDAO();
                response = bloqueoDAO.BloqueoTemporalDataBanking(request);
            }
            catch (FaultException<ExceptionBloqueoTemporalDataBanking> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                ExceptionBloqueoTemporalDataBanking exceptionBloqueoTemporal = new ExceptionBloqueoTemporalDataBanking();
                exceptionBloqueoTemporal.Codigo = 1000;
                exceptionBloqueoTemporal.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionBloqueoTemporal.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionBloqueoTemporalDataBanking> Bex = new Bitacora<ExceptionBloqueoTemporalDataBanking>(request.NumeroSocio.ToString(), exceptionBloqueoTemporal, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionBloqueoTemporalDataBanking>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionBloqueoTemporalDataBanking>(exceptionBloqueoTemporal);
            }
            return response;
        }
    
        public ResponseDesbloqueoCuentaBanca DesbloqueoCuentaBanca(RequestDesbloqueoCuentaBanca request)
        {
            ResponseDesbloqueoCuentaBanca response = new ResponseDesbloqueoCuentaBanca();
            try
            {
                bloqueoDAO = new BloqueoDAO();
                response = bloqueoDAO.DesbloqueoCuentaBanca(request);
                return response;
            }
            catch (FaultException<ExceptionDesbloqueoCuentaBanca> ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                ExceptionDesbloqueoCuentaBanca exceptionDesbloqueoCuentaBanca = new ExceptionDesbloqueoCuentaBanca();
                exceptionDesbloqueoCuentaBanca.Codigo = 1000;
                exceptionDesbloqueoCuentaBanca.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionDesbloqueoCuentaBanca.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionDesbloqueoCuentaBanca> Bex = new Bitacora<ExceptionDesbloqueoCuentaBanca>(request.NumeroSocio.ToString(), exceptionDesbloqueoCuentaBanca, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionDesbloqueoCuentaBanca>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionDesbloqueoCuentaBanca>(exceptionDesbloqueoCuentaBanca);
            }
            return response;
        }

        //public ResponseDesbloqueoTemporalDataBanking DesbloqueoTemporalDataBanking(RequestDesbloqueoTemporalDataBanking request)
        //{
        //    ResponseDesbloqueoTemporalDataBanking response = new ResponseDesbloqueoTemporalDataBanking();
        //    try
        //    {
        //        Bitacora<RequestDesbloqueoTemporalDataBanking> b = new Bitacora<RequestDesbloqueoTemporalDataBanking>(request.NumeroSocio.ToString(), request);
        //        new Logg().Info(SerializerManager<Bitacora<RequestDesbloqueoTemporalDataBanking>>.SerealizarObjtecToString(b));
        //        bloqueoDAO = new BloqueoDAO();
        //        response = bloqueoDAO.DesbloqueoTemporalDataBanking(request);
        //    }
        //    catch (FaultException<ExceptionDesbloqueoTemporalDataBanking> ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionDesbloqueoTemporalDataBanking exceptionBloqueoTemporal = new ExceptionDesbloqueoTemporalDataBanking();
        //        exceptionBloqueoTemporal.Codigo = 1000;
        //        exceptionBloqueoTemporal.Descripcion = Utilerias.ExcepcionDebug(ex);
        //        exceptionBloqueoTemporal.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
        //        Bitacora<ExceptionDesbloqueoTemporalDataBanking> Bex = new Bitacora<ExceptionDesbloqueoTemporalDataBanking>(request.NumeroSocio.ToString(), exceptionBloqueoTemporal, request.NumeroSocio.ToString());
        //        new Logg().Error(SerializerManager<Bitacora<ExceptionDesbloqueoTemporalDataBanking>>.SerealizarObjtecToString(Bex));
        //        throw new FaultException<ExceptionDesbloqueoTemporalDataBanking>(exceptionBloqueoTemporal);
        //    }
        //    return response;
        //}


    }
}
