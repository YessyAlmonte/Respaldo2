﻿using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosBancaCMV.Bloqueo
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IBloqueo" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IBloqueo
    {
        [OperationContract]
        [FaultContract(typeof(ExceptionBloqueoTemporal))]
        ResponseBloqueoTemporal BloqueoTemporal(RequestBloqueoTemporal request);

        [OperationContract]
        [FaultContract(typeof(ExceptionBloqueoTemporalDataBanking))]
        ResponseBloqueoTemporalDataBanking BloqueoTemporalDataBanking(RequestBloqueoTemporalDataBanking request);

        //[OperationContract]
        //[FaultContract(typeof(ExceptionDesbloqueoTemporalDataBanking))]
        //ResponseDesbloqueoTemporalDataBanking DesbloqueoTemporalDataBanking(RequestDesbloqueoTemporalDataBanking request);


        [OperationContract]
        [FaultContract(typeof(ExceptionDesbloqueoCuentaBanca))]
        ResponseDesbloqueoCuentaBanca DesbloqueoCuentaBanca(RequestDesbloqueoCuentaBanca request);
    }
}
