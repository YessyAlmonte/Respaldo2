﻿using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosBancaCMV.PagoServicio
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IPagoServicio" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IPagoServicio
    {
        [OperationContract]
        [FaultContract(typeof(ExceptionPagarServicios))]
        ResponsePagarServicios PagarServicio(RequestPagarServicios request);

        [OperationContract]
        [FaultContract(typeof(ExceptionRegistrarServicio))]
        ResponseRegistrarServicio RegistrarServicio(RequestRegistrarServicio request);

        [OperationContract]
        [FaultContract(typeof(ExceptionConsultaSaldo))]
        ResponseConsultaSaldo ConsultaSaldo(RequestConsultaSaldo request);


    }
}
