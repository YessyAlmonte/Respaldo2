﻿using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosBancaCMV.Sesion
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "ISesion" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface ISesion
    {
        [OperationContract]
        [FaultContract(typeof(ExceptionValidaNumero))]
        ResponseValidaNumero ValidaNumero(RequestValidaNumero request);

        [OperationContract]
        [FaultContract(typeof(ExceptionIniciarSesion))]
        ResponseIniciarSesion AutenticarSocio(RequestIniciarSesion request);

    }
}
