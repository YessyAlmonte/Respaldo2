﻿using BusCrypto;
using ServiciosBancaDAO;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Autenticacion;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosBancaCMV.Configuracion
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Configuracion" en el código y en el archivo de configuración a la vez.
    [CustomBehavior]
    public class Configuracion : IConfiguracion
    {
     
        public ResponseObtenerLimitesTransferencias ObtenerLimitesTransferencias()
        {
            try
            {
                return new ConfiguracionDAO().ObtenerLimitesTransferencias();
            }
            catch (FaultException<ExceptionObtenerLimitesTransferencias> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerLimitesTransferencias exceptionConfiguracionAyuda = new ExceptionObtenerLimitesTransferencias();
                exceptionConfiguracionAyuda.Codigo = 1000;
                exceptionConfiguracionAyuda.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionConfiguracionAyuda.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerLimitesTransferencias>(exceptionConfiguracionAyuda);
            }
        }
    
        public ResponseObtenerAyuda ObtenerAyuda()
        {
            try
            {
                return new ConfiguracionDAO().ObtenerAyuda();
            }
            catch (FaultException<ExceptionObtenerAyuda> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerAyuda exceptionConfiguracionAyuda = new ExceptionObtenerAyuda();
                exceptionConfiguracionAyuda.Codigo = 1000;
                exceptionConfiguracionAyuda.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionConfiguracionAyuda.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionObtenerAyuda>(exceptionConfiguracionAyuda,exceptionConfiguracionAyuda.Descripcion);
            }
        }

        public ResponseObtenerAvisoPrivacidad ObtenerAvisoPrivacidad()
        {
            ResponseObtenerAvisoPrivacidad response = null;
            try
            {
                response = new ResponseObtenerAvisoPrivacidad();
                response.AvisoPrivacidad = new  ConfiguracionDAO().ObtenerValor(ConfigurationManager.AppSettings["AvisoPrivacidad"].ToString());

            }
            catch (FaultException<ExceptionObtenerAvisoPrivacidad> exG)
            {
                throw exG;
            }
            catch (Exception)
            {

                throw;
            }
            return response;
        }

        public ResponseObtenerTerminosCondiciones ObtenerTerminosCondiciones()
        {
            ResponseObtenerTerminosCondiciones response = null;
            try
            {
                response = new ResponseObtenerTerminosCondiciones();
                response.TerminosCondiciones = new ConfiguracionDAO().ObtenerValor(ConfigurationManager.AppSettings["TerminosCondiciones"].ToString());

            }
            catch (FaultException<ExceptionObtenerTerminosCondiciones> exG)
            {
                throw exG;
            }
            catch (Exception)
            {

                throw;
            }
            return response;
        }
    }
}
