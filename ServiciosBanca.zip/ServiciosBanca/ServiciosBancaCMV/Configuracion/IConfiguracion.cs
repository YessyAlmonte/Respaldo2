﻿using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosBancaCMV.Configuracion
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IConfiguracion" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IConfiguracion
    {
        [OperationContract]                 
        [FaultContract(typeof(ExceptionObtenerLimitesTransferencias))]
        ResponseObtenerLimitesTransferencias ObtenerLimitesTransferencias();


        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerAyuda))]
        ResponseObtenerAyuda ObtenerAyuda();

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerAvisoPrivacidad))]
        ResponseObtenerAvisoPrivacidad ObtenerAvisoPrivacidad();

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerTerminosCondiciones))]
        ResponseObtenerTerminosCondiciones ObtenerTerminosCondiciones();

    }
}
