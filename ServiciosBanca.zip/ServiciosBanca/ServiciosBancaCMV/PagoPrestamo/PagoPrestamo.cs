﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ServiciosBancaDAO;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;

namespace ServiciosBancaCMV.PagoPrestamo
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "PagoPrestamo" en el código y en el archivo de configuración a la vez.
    public class PagoPrestamo : IPagoPrestamo
    {
       

        public ResponseObtenerDetallePrestamo ObtenerDetallePrestamo(RequestObtenerDetallePrestamo request)
        {
            try
            {
                ResponseObtenerDetallePrestamo responseObtenerDetallePrestamo = new ResponseObtenerDetallePrestamo();
                responseObtenerDetallePrestamo.DetallePrestamo = new PagoPrestamoDAO().ObtenerDetallePrestamo(request);
                return responseObtenerDetallePrestamo;
            }
            catch (FaultException<ResponseObtenerDetallePrestamo> exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionObtenerDetallePrestamo exceptionObtenerDetallePrestamo = new ExceptionObtenerDetallePrestamo();
                exceptionObtenerDetallePrestamo.Codigo = 1000;
                exceptionObtenerDetallePrestamo.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionObtenerDetallePrestamo.Mensaje = ex.Message;
                Bitacora<ExceptionObtenerDetallePrestamo> Bex = new Bitacora<ExceptionObtenerDetallePrestamo>(request.NumeroSocio.ToString(), exceptionObtenerDetallePrestamo, request.NumeroSocio.ToString());
                //new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerCuentas>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionObtenerDetallePrestamo>(exceptionObtenerDetallePrestamo, exceptionObtenerDetallePrestamo.Mensaje);
            }
        }

        public ResponseCalcularImporteAPagar CalcularImporteAPagar(RequestCalcularImporteAPagar request)
        {
            try
            {
                return new PagoPrestamoDAO().CalcularImporteAPagar(request);
            }
            catch (FaultException<ExceptionCalcularImporteAPagar > exG)
            {
                throw exG;
            }
            catch (Exception ex)
            {
                ExceptionCalcularImporteAPagar exceptionCalcularImporteAPagar = new ExceptionCalcularImporteAPagar();
                exceptionCalcularImporteAPagar.Codigo = 1000;
                exceptionCalcularImporteAPagar.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionCalcularImporteAPagar.Mensaje = ex.Message;
                Bitacora<ExceptionCalcularImporteAPagar> Bex = new Bitacora<ExceptionCalcularImporteAPagar>(request.NumeroSocio.ToString(), exceptionCalcularImporteAPagar, request.NumeroSocio.ToString());
                //new Logg().Error(SerializerManager<Bitacora<ExceptionObtenerCuentas>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionCalcularImporteAPagar>(exceptionCalcularImporteAPagar, exceptionCalcularImporteAPagar.Mensaje);
            }
        }
    }
}
