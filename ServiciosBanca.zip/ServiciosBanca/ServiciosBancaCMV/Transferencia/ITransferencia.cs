﻿using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosBancaCMV.Transferencia
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "ITransferencia" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface ITransferencia
    {
        #region Alta de cuentas internas y externas 

        [OperationContract]
        [FaultContract(typeof(ExceptionAltaCuentaInterna))]
        ResponseAltaCuentaInterna AltaCuentaInterna(RequestAltaCuentaInterna request);

        [OperationContract]
        [FaultContract(typeof(ExceptionAltaCuentaExternaDebito))]
        ResponseAltaCuentaExternaDebito AltaCuentaExternaDebito(RequestAltaCuentaExternaDebito request);


        [OperationContract]
        [FaultContract(typeof(ExceptionAltaCuentaExternaCredito))]
        ResponseAltaCuentaExternaCredito AltaCuentaExternaCredito(RequestAltaCuentaExternaCredito request);

        [OperationContract]
        [FaultContract(typeof(ExceptionAltaCuentaExternaCelular))]
        ResponseAltaCuentaExternaCelular AltaCuentaExternaCelular(RequestAltaCuentaExternaCelular request);

        [OperationContract]
        [FaultContract(typeof(ExceptionAltaCuentaExternaClabe))]
        ResponseAltaCuentaExternaClabe AltaCuentaExternaClabe(RequestAltaCuentaExternaClabe request);
        #endregion

        #region Eliminar cuentas internas y externas 

        [OperationContract]
        [FaultContract(typeof(ExceptionEliminaCuentaExterna))]
        ResponseEliminaCuentaExterna EliminaCuentaExterna(RequestEliminaCuentaExterna request);

        [OperationContract]
        [FaultContract(typeof(ExceptionEliminarCuentaInterna))]
        ResponseEliminarCuentaInterna EliminaCuentaInterna(RequestEliminarCuentaInterna request);

        #endregion

        #region Obtener cuentas  Retiro , Deposito Internar y Externas

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerCuentasRetiro))]
        List<ResponseObtenerCuentasRetiro>ObtenerCuentasRetiro(RequestObtenerCuentasRetiro request);

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerCuentasDepositoInterna))]
        List<ResponseObtenerCuentasDepositoInterna> ObtenerCuentasDepositoInterna(RequestObtenerCuentasDepositoInterna request);

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerCuentasDepositoExternas))]
        List<ResponseObtenerCuentasDepositoExternas>ObtenerCuentasDepositoExternas(RequestObtenerCuentasDepositoExternas request);

        #endregion

        #region Transferecias Cuentas Propias y Externas

        [OperationContract]
        [FaultContract(typeof(ExceptionTransferenciasCuentasPropias))]
        ResponseTransferenciasCuentasPropias TransferenciasCuentasPropias(RequestTransferenciasCuentasPropias request);

        [OperationContract]
        [FaultContract(typeof(ExceptionTransferenciasCuentasExterna))]
        ResponseTransferenciasCuentasExterna TransferenciasCuentasExterna(RequestTransferenciasCuentasExterna request);

        [OperationContract]
        [FaultContract(typeof(ExceptionTransferenciasCuentasCredito))]
        ResponseTransferenciasCuentasCredito TransferenciasCuentasCredito(RequestTransferenciasCuentasCredito request);


        #endregion

        #region Comprobantes de Pago 


        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerComprobantePagoCEP))]
        List<ResponseObtenerComprobantePagoCEP> ObtenerComprobantesPagoCEP(RequestObtenerComprobantePagoCEP request);
                     
        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerComprobantePago))]
        ResponseObtenerComprobantePago ObtenerComprobantesPago(RequestObtenerComprobantePago request);

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerComprobantePagoPDF))]
        ResponseObtenerComprobantePagoPDF ObtenerComprobantesPagoPDF(RequestObtenerComprobantePagoPDF request);

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerComprobantePagoServicios))]
        ResponseObtenerComprobantePagoServicios ObtenerComprobantesPagoServicios(RequestObtenerComprobantePagoServicios request);


        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerComprobantePagoServicioPDF))]
        ResponseObtenerComprobantePagoServicioPDF ObtenerComprobantesPagoServicioPDF(RequestObtenerComprobantePagoServicioPDF request);


        #endregion

        #region Obtener proximas transferencias  y pagos programados
        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerProximasTransferenciasProgramadas))]
        ResponseObtenerProximasTransferenciasProgramadas ObtenerProximasTransferenciasProgramadas(RequestObtenerProximasTransferenciasProgramadas request);

        [OperationContract]
        [FaultContract(typeof(ExceptionObtenerProximosPagosProgramadas))]
        ResponseObtenerProximosPagosProgramados ObtenerProximosPagosProgramadas(RequestObtenerProximosPagosProgramados request);

        #endregion

        #region Limites Transferencias

        [OperationContract]
        [FaultContract(typeof(ExceptionValidaLimitesTransferencias))]
        ResponseValidaLimitesTransferencias ValidaLimitesTransferencias(RequestValidaLimitesTransferencias request);



        #endregion
    }
}
