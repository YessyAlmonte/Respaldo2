﻿using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosBancaCMV.Token
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IToken" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IToken
    {
        [OperationContract]
        [FaultContract(typeof(ExceptionAprovisionarToken))]
        ResponseAprovisionarToken AprovisionarToken(RequestAprovisionarToken request);

        [OperationContract]
        [FaultContract(typeof(ExceptionValidaOTP))]
        ResponseValidaOTP ValidarOTP(RequestValidaOTP request);

        [OperationContract]
        bool RevocarOTP(string numero);

        [OperationContract]
        [FaultContract(typeof(ExceptionEstatusToken))]
        ResponseEstatusToken EstatusToken (RequestEstatusToken request);

        /*[OperationContract]
        [FaultContract(typeof(ExceptionEliminarUsuario))]
        ResponseEliminarUsuario EliminarUsuario(RequestEliminarUsuario request);
        */
    }
}
