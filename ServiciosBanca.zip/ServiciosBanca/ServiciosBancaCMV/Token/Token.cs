﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using ServiciosBancaDAO;
using ServiciosBancaEntidades;
using ServiciosBancaEntidades.Exceptions;
using ServiciosBancaEntidades.Requests;
using ServiciosBancaEntidades.Responses;
using ServiciosBancaUtils;
using ServiciosBancaUtils.Logg;
using BusCrypto;
using ServiciosBancaEntidades.Autenticacion;

namespace ServiciosBancaCMV.Token
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Token" en el código y en el archivo de configuración a la vez.
    [CustomBehavior]
    public class Token : IToken
    {
        public ResponseAprovisionarToken AprovisionarToken(RequestAprovisionarToken request)
        {
   
            try
            {
                
                ServiciosBancaEntidades.Socio s = new SocioDAO().ObtenerInformacionSocioAprovisionaToken(request.NumeroSocio);
                string result = AgenteConecta.AgregarAprovisionarToken(s);
                return new TokenDAO().AprovisionarToken(request);
            }

            catch (FaultException<ExceptionAprovisionarToken> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionAprovisionarToken exceptionAprovisionarToken = new ExceptionAprovisionarToken();
                exceptionAprovisionarToken.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionAprovisionarToken.Descripcion = ef.Message;
                exceptionAprovisionarToken.Mensaje = ef.Message;
                Bitacora<ExceptionAprovisionarToken> Bex = new Bitacora<ExceptionAprovisionarToken>(request.NumeroSocio.ToString(), exceptionAprovisionarToken, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionAprovisionarToken>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAprovisionarToken>(exceptionAprovisionarToken);
            }
            catch (Exception ex)
            {
                ExceptionAprovisionarToken exceptionAprovisionarToken = new ExceptionAprovisionarToken();
                exceptionAprovisionarToken.Codigo = 1000;
                exceptionAprovisionarToken.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionAprovisionarToken.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionAprovisionarToken> Bex = new Bitacora<ExceptionAprovisionarToken>(request.NumeroSocio.ToString(), exceptionAprovisionarToken, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionAprovisionarToken>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionAprovisionarToken>(exceptionAprovisionarToken);
            }
        }

        public ResponseValidaOTP ValidarOTP(RequestValidaOTP request)
        {
            ResponseValidaOTP response = null;
            try
            {
                Bitacora<RequestValidaOTP> b = new Bitacora<RequestValidaOTP>(request.NumeroSocio.ToString(), request);
                new Logg().Info(SerializerManager<Bitacora<RequestValidaOTP>>.SerealizarObjtecToString(b));
                ServiciosBancaEntidades.Socio s = new SocioDAO().ObtenerInformacionSocioAprovisionaToken(request.NumeroSocio);
                string result = AgenteConecta.ValidarOTP(s.NumeroSocio.ToString(), request.OTP);
                response = new ResponseValidaOTP();
                response.Estatus = true;
            }
            catch (FaultException<ExceptionValidaOTP> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionValidaOTP exceptionAprovisionarToken = new ExceptionValidaOTP();
                exceptionAprovisionarToken.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionAprovisionarToken.Descripcion = ef.Message;
                exceptionAprovisionarToken.Mensaje = ef.Message;
                Bitacora<ExceptionValidaOTP> Bex = new Bitacora<ExceptionValidaOTP>(request.NumeroSocio.ToString(), exceptionAprovisionarToken, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionValidaOTP>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionValidaOTP>(exceptionAprovisionarToken,exceptionAprovisionarToken.Descripcion);
            }
            catch (Exception ex)
            {
                ExceptionValidaOTP exceptionAprovisionarToken = new ExceptionValidaOTP();
                exceptionAprovisionarToken.Codigo = 1000;
                exceptionAprovisionarToken.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionAprovisionarToken.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionValidaOTP> Bex = new Bitacora<ExceptionValidaOTP>(request.NumeroSocio.ToString(), exceptionAprovisionarToken, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionValidaOTP>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionValidaOTP>(exceptionAprovisionarToken);
            }
            return response;
        }

        public bool RevocarOTP(string numero)
        {
            try
            {
                AgenteConecta.RevocarOTP(numero);
            }
            catch (Exception ex)
            {

                throw;
            }
            return true;
        }

        public ResponseEstatusToken EstatusToken(RequestEstatusToken request)
        {
            ResponseEstatusToken response = null;
            try
            {
                Bitacora<RequestEstatusToken> b = new Bitacora<RequestEstatusToken>(request.NumeroSocio.ToString(), request);
                new Logg().Info(SerializerManager<Bitacora<RequestEstatusToken>>.SerealizarObjtecToString(b));
                ServiciosBancaEntidades.Socio s = new SocioDAO().ObtenerInformacionSocioAprovisionaToken(request.NumeroSocio);
                string result = AgenteConecta.EstatusToken(request.NumeroSocio);
                response = new ResponseEstatusToken();
                response.Estatus = result;
            }
            catch (FaultException<ExceptionEstatusToken> exG)
            {
                throw exG;
            }
            catch (FaultException ef)
            {
                ExceptionEstatusToken exceptionEstatusToken = new ExceptionEstatusToken();
                exceptionEstatusToken.Codigo = Convert.ToInt32(ef.Code.Name);
                exceptionEstatusToken.Descripcion = ef.Message;
                exceptionEstatusToken.Mensaje = ef.Message;
                Bitacora<ExceptionEstatusToken> Bex = new Bitacora<ExceptionEstatusToken>(request.NumeroSocio.ToString(), exceptionEstatusToken, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionEstatusToken>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionEstatusToken>(exceptionEstatusToken);
            }
            catch (Exception ex)
            {
                ExceptionEstatusToken exceptionEstatusToken = new ExceptionEstatusToken();
                exceptionEstatusToken.Codigo = 1000;
                exceptionEstatusToken.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionEstatusToken.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                Bitacora<ExceptionEstatusToken> Bex = new Bitacora<ExceptionEstatusToken>(request.NumeroSocio.ToString(), exceptionEstatusToken, request.NumeroSocio.ToString());
                new Logg().Error(SerializerManager<Bitacora<ExceptionEstatusToken>>.SerealizarObjtecToString(Bex));
                throw new FaultException<ExceptionEstatusToken>(exceptionEstatusToken);
            }
            return response;
        }


        public ResponseEliminarUsuario EliminarUsuario(RequestEliminarUsuario request)
        {
            ResponseEliminarUsuario response = new ResponseEliminarUsuario();
            try
            {
                response.Mensaje = AgenteConecta.EliminarUsuario(request.NumeroSocio);
                response.Estatus = true;
            }
            catch (FaultException<ExceptionEliminarUsuario> exe)
            {
                throw exe;
            }
            catch (Exception ex)
            {
                ExceptionEliminarUsuario exceptionEliminarUsuario = new ExceptionEliminarUsuario();
                exceptionEliminarUsuario.Codigo = 1000;
                exceptionEliminarUsuario.Descripcion = Utilerias.ExcepcionDebug(ex);
                exceptionEliminarUsuario.Mensaje = "El error no se encuentra en un catálogo definido por CMV";
                throw new FaultException<ExceptionEliminarUsuario>(exceptionEliminarUsuario);
            }

            return response;
        }
    }
}
