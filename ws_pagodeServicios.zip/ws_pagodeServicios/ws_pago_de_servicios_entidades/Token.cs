﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ws_pago_de_servicios_entidades
{
    public class Token
    {
        public string token { get; set; }
        public bool success { get; set; }
    }
}
