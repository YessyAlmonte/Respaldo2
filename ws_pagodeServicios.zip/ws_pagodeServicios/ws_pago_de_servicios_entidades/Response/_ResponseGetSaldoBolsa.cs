﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ws_pago_de_servicios_entidades.Response
{
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(ElementName = "RESPONSE", Namespace = "", IsNullable = false)]
    [DataContract]
    public class _ResponseGetSaldoBolsa
    {
        [DataMember]
        public double SALDO { get; set; } = 0.0;
        [DataMember]
        public string SALDO_F { get; set; } = "";
        [DataMember]
        public Mensaje MENSAJE { get; set; } = new Mensaje();
        [DataMember]
        public DateTime FECHACONSULTA { get; set; } = DateTime.Now;
        [DataMember]
        public long TIEMPORESPUESTA { get; set; } = 0;
    }
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [DataContract]
    public class Mensaje
    {
        [DataMember]
        public int CODIGO { get; set; } = -10;
        [DataMember]
        public string TEXTO { get; set; } = "";
    }
}
