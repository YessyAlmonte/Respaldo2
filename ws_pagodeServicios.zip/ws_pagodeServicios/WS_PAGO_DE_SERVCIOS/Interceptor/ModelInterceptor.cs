﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WS_PAGO_DE_SERVCIOS.Interceptor
{
    public class ModelInterceptor
    {
        public string usuario { get; set; }
        public string contrasena { get; set; }
    }
}