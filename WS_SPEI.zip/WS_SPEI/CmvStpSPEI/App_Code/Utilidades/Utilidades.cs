﻿using CmvStpEntidades.Requests;
using Microsoft.Win32;
using ServicioStpProd;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.Text;
using System.Web;
using System.Web.Configuration;

/// <summary>
/// Descripción breve de Utilidades
/// </summary>
public static class Utilidades
{

    private static string certificado;
    private static string claveCertificado;
    private static bool hambienteProd;

    public static string GenerarCadenaOrginal(ordenPagoWS orden)
    {
        string cadena = string.Empty;
        StringBuilder s = new StringBuilder();
        s.Append("|");
        s.Append((string.IsNullOrEmpty(orden.institucionContraparte.ToString()) ? "|" : "|" + orden.institucionContraparte.ToString()));//1
        s.Append((string.IsNullOrEmpty(orden.empresa.ToString()) ? "|" : "|" + orden.empresa.ToString()));//2
        s.Append((string.IsNullOrEmpty(zeroValidator(orden.fechaOperacion)) ? "|" : "|" + orden.fechaOperacion.ToString()));//3
        s.Append((string.IsNullOrEmpty(orden.folioOrigen) ? "|" : "|" + orden.folioOrigen.ToString()));//4
        s.Append((string.IsNullOrEmpty(orden.claveRastreo.ToString()) ? "|" : "|" + orden.claveRastreo.ToString()));//5
        s.Append((string.IsNullOrEmpty(zeroValidator(orden.institucionOperante)) ? "|" : "|" + orden.institucionOperante.ToString()));//6

        s.Append((string.IsNullOrEmpty(orden.monto.ToString()) ? "|" : "|" + orden.monto.ToString()));//7
        s.Append((string.IsNullOrEmpty(zeroValidator(orden.tipoPago)) ? "|" : "|" + orden.tipoPago.ToString()));//8
        s.Append((string.IsNullOrEmpty(zeroValidator(orden.tipoCuentaOrdenante)) ? "|" : "|" + orden.tipoCuentaOrdenante.ToString()));//9
        s.Append((string.IsNullOrEmpty(orden.nombreOrdenante) ? "|" : "|" + orden.nombreOrdenante.ToString()));//10
        s.Append((string.IsNullOrEmpty(orden.cuentaOrdenante) ? "|" : "|" + orden.cuentaOrdenante.ToString()));//11
        s.Append((string.IsNullOrEmpty(orden.rfcCurpOrdenante) ? "|" : "|" + orden.rfcCurpOrdenante.ToString()));//12
        s.Append((string.IsNullOrEmpty(zeroValidator(orden.tipoCuentaBeneficiario)) ? "|" : "|" + orden.tipoCuentaBeneficiario.ToString()));//13
        s.Append((string.IsNullOrEmpty(orden.nombreBeneficiario.ToString()) ? "|" : "|" + orden.nombreBeneficiario.ToString()));//14
        s.Append((string.IsNullOrEmpty(orden.cuentaBeneficiario.ToString()) ? "|" : "|" + orden.cuentaBeneficiario.ToString()));//15
        s.Append((string.IsNullOrEmpty(orden.rfcCurpBeneficiario) ? "|" : "|" + orden.rfcCurpBeneficiario.ToString()));//16
        s.Append((string.IsNullOrEmpty(orden.emailBeneficiario) ? "|" : "|" + orden.emailBeneficiario.ToString()));//17

        s.Append((string.IsNullOrEmpty(zeroValidator(orden.tipoCuentaBeneficiario2)) ? "|" : "|" + orden.tipoCuentaBeneficiario2.ToString()));//18
        s.Append((string.IsNullOrEmpty(orden.nombreBeneficiario2) ? "|" : "|" + orden.nombreBeneficiario2.ToString()));//19
        s.Append((string.IsNullOrEmpty(orden.cuentaBeneficiario2) ? "|" : "|" + orden.cuentaBeneficiario2.ToString()));//20
        s.Append((string.IsNullOrEmpty(orden.rfcCurpBeneficiario2) ? "|" : "|" + orden.rfcCurpBeneficiario2.ToString()));//21
        s.Append((string.IsNullOrEmpty(orden.conceptoPago) ? "|" : "|" + orden.conceptoPago.ToString()));//22
        s.Append((string.IsNullOrEmpty(orden.conceptoPago2) ? "|" : "|" + orden.conceptoPago2.ToString()));//23
        s.Append((string.IsNullOrEmpty(orden.claveCatUsuario1) ? "|" : "|" + orden.claveCatUsuario1.ToString()));//24
        s.Append((string.IsNullOrEmpty(orden.claveCatUsuario2) ? "|" : "|" + orden.claveCatUsuario2.ToString()));//25
        s.Append((string.IsNullOrEmpty(orden.clavePago) ? "|" : "|" + orden.clavePago.ToString()));//26
        s.Append((string.IsNullOrEmpty(orden.referenciaCobranza) ? "|" : "|" + orden.referenciaCobranza.ToString()));//27

        s.Append((string.IsNullOrEmpty(zeroValidator(orden.referenciaNumerica)) ? "|" : "|" + orden.referenciaNumerica.ToString()));//28
        s.Append((string.IsNullOrEmpty(zeroValidator(orden.tipoOperacion)) ? "|" : "|" + orden.tipoOperacion.ToString()));//29
        s.Append((string.IsNullOrEmpty(orden.topologia) ? "|" : "|" + orden.topologia.ToString()));//30
        s.Append((string.IsNullOrEmpty(orden.usuario) ? "|" : "|" + orden.usuario.ToString()));//31
        s.Append((string.IsNullOrEmpty(zeroValidator(orden.medioEntrega)) ? "|" : "|" + "|" + orden.medioEntrega.ToString()));//32
        s.Append((string.IsNullOrEmpty(zeroValidator(orden.prioridad)) ? "|" : "|" + orden.prioridad.ToString()));//33
        s.Append((string.IsNullOrEmpty(zeroValidator(orden.iva)) ? "|" : "|" + orden.iva.ToString()));//34
        s.Append("||");
        Console.WriteLine("GenerarCadenaOrginal: " + s.ToString());
        return s.ToString();

    }

    public static string generarCadenaOriginalConsultaOrdenRastreo(ConsOrdEnvRastreoSTPRequest requestToSTP)
    {
        string cadena = string.Empty;
        StringBuilder s = new StringBuilder();
        s.Append("||");
        s.Append((string.IsNullOrEmpty(requestToSTP.empresa) ? "|" : "|" + requestToSTP.empresa));
        s.Append((string.IsNullOrEmpty(zeroValidator(requestToSTP.fechaOperacion)) ? "|" : "|" + requestToSTP.fechaOperacion.ToString()));
        s.Append("|");
        s.Append((string.IsNullOrEmpty(requestToSTP.claveRastreo) ? "|" : "|" + requestToSTP.claveRastreo));
        s.Append((string.IsNullOrEmpty(zeroValidator(requestToSTP.institucionOperante)) ? "|" : "|" + requestToSTP.institucionOperante.ToString()));
        s.Append("||||||||||||||||||||||||||||||");
        return s.ToString();
    }

    public static string generarCadenaOriginalConsultaOrdenes(ConsOrdenesFechSTPRequest requestToSTP)
    {
        string cadena = string.Empty;
        StringBuilder s = new StringBuilder();
        s.Append("||");
        s.Append((string.IsNullOrEmpty(requestToSTP.empresa) ? "|" : "|" + requestToSTP.empresa));
        s.Append((string.IsNullOrEmpty(zeroValidator(requestToSTP.fechaOperacion)) ? "|" : "|" + requestToSTP.fechaOperacion.ToString()));
        s.Append("|||||||||||||||||||||||||||||||||");
        return s.ToString();
    }

    public static string generarCadenaOriginalConsultaCuentaHistorico(RequestConsultaSaldoCuentaHistorico request)
    {
        string cadena = string.Empty;
        StringBuilder s = new StringBuilder();
        s.Append(request.cuenta);
        s.Append("|");
        s.Append(request.fecha.ToString());
        return s.ToString();
    }
    private static string originaString(ordenPagoWS ordenPago)
    {
        string cadenaOriginal = "";
        cadenaOriginal = cadenaOriginal + "||";
        cadenaOriginal = cadenaOriginal + ordenPago.institucionContraparte + "|";//1
        cadenaOriginal = cadenaOriginal + ordenPago.empresa + "|";//2
        cadenaOriginal = cadenaOriginal + zeroValidator(ordenPago.fechaOperacion) + "|";//3
        cadenaOriginal = cadenaOriginal + ordenPago.folioOrigen + "|";//4
        cadenaOriginal = cadenaOriginal + ordenPago.claveRastreo + "|";//5
        cadenaOriginal = cadenaOriginal + ordenPago.institucionOperante + "|";//6
        cadenaOriginal = cadenaOriginal + ordenPago.monto + "|";//7
        cadenaOriginal = cadenaOriginal + ordenPago.tipoPago + "|";//8
        cadenaOriginal = cadenaOriginal + zeroValidator(ordenPago.tipoCuentaOrdenante) + "|";//9
        cadenaOriginal = cadenaOriginal + ordenPago.nombreOrdenante + "|";//10
        cadenaOriginal = cadenaOriginal + ordenPago.cuentaOrdenante + "|";//11
        cadenaOriginal = cadenaOriginal + ordenPago.rfcCurpOrdenante + "|";//12
        cadenaOriginal = cadenaOriginal + ordenPago.tipoCuentaBeneficiario + "|";//13
        cadenaOriginal = cadenaOriginal + ordenPago.nombreBeneficiario + "|";//14
        cadenaOriginal = cadenaOriginal + ordenPago.cuentaBeneficiario + "|";//15
        cadenaOriginal = cadenaOriginal + ordenPago.rfcCurpBeneficiario + "|";//16
        cadenaOriginal = cadenaOriginal + ordenPago.emailBeneficiario + "|";//17
        cadenaOriginal = cadenaOriginal + zeroValidator(ordenPago.tipoCuentaBeneficiario2) + "|";//18
        cadenaOriginal = cadenaOriginal + ordenPago.nombreBeneficiario2 + "|";//19
        cadenaOriginal = cadenaOriginal + ordenPago.cuentaBeneficiario2 + "|";//20
        cadenaOriginal = cadenaOriginal + ordenPago.rfcCurpBeneficiario2 + "|";//21
        cadenaOriginal = cadenaOriginal + ordenPago.conceptoPago + "|";//22
        cadenaOriginal = cadenaOriginal + ordenPago.conceptoPago2 + "|";//23
        cadenaOriginal = cadenaOriginal + ordenPago.claveCatUsuario1 + "|";//24
        cadenaOriginal = cadenaOriginal + ordenPago.claveCatUsuario2 + "|";//25
        cadenaOriginal = cadenaOriginal + ordenPago.clavePago + "|";//26
        cadenaOriginal = cadenaOriginal + ordenPago.referenciaCobranza + "|";//27
        cadenaOriginal = cadenaOriginal + ordenPago.referenciaNumerica + "|";//28
        cadenaOriginal = cadenaOriginal + zeroValidator(ordenPago.tipoOperacion) + "|";//29
        cadenaOriginal = cadenaOriginal + ordenPago.topologia + "|";//30
        cadenaOriginal = cadenaOriginal + ordenPago.usuario + "|";//31
        cadenaOriginal = cadenaOriginal + zeroValidator(ordenPago.medioEntrega) + "|";//32
        cadenaOriginal = cadenaOriginal + zeroValidator(ordenPago.prioridad) + "|";//33
        cadenaOriginal = cadenaOriginal + zeroValidator(ordenPago.iva) + "|";//34
        cadenaOriginal = cadenaOriginal + "|";
        Console.WriteLine("originaString: " + cadenaOriginal.ToString());
        return cadenaOriginal;
    }
    public static string zeroValidator(decimal number)
    {
        string finalValue = "";
        if (number != 0)
        {
            finalValue = number.ToString();
        }
        return finalValue;
    }

    private static void ObtenerConfigCertificado()
    {
        try
        {
            //RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\APISpei");
            RegistryKey key = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey(@"SOFTWARE\APISpei");
            if (key != null)
            {
                hambienteProd = WebConfigurationManager.AppSettings["servicioProductivo"].ToString().Equals("1");
                certificado = (hambienteProd ? key.GetValue("certificadoProd").ToString() : key.GetValue("certificadoPrueba").ToString());
                claveCertificado = (hambienteProd ? key.GetValue("claveCertificadoProd").ToString() : key.GetValue("claveCertificadoPrueba").ToString());
                key.Close();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public static string GeneraSello(string strCadenaOriginal)
    {
        string strSello = string.Empty;
        try
        {
            ObtenerConfigCertificado();
            //PARA GENERAR EL SELLO SE UTILIZA EL MISMO CERTIFICADO  DE PRODUCTIVO LA MISMA CONTRASEÑA Y EL MISMO ARCHIVO.KEY 
            //LO UNICO QUE CAMBIE ES EN EL WEB SERVICE HAY QUE  APUNTAR AL WEB SERVICE DE PRUEBAS
            //CON LAS CONTRASEÑAS DE PRUEBAS
            string strLlavePwd = claveCertificado; //ConfigurationManager.AppSettings["claveGeneraSello"].ToString();
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Certificado", certificado);
            X509Certificate2 x509 = new X509Certificate2(path, strLlavePwd);
            RSACryptoServiceProvider rsaProvider = (RSACryptoServiceProvider)x509.PrivateKey;
            SHA256 hasher = SHA256CryptoServiceProvider.Create();
            byte[] hashValue = rsaProvider.SignData(System.Text.Encoding.UTF8.GetBytes(strCadenaOriginal), hasher);
            strSello = System.Convert.ToBase64String(hashValue);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return strSello;
    }
    public static bool validaUsuario(string usuario, string contrasena)
    {
        if (string.Compare(usuario, "CMVF1nZ4S") == 0 && string.Compare(contrasena, "8DED40B6E19F14D1651FDDF063CDD2") == 0)
            return true;
        else
        {
            throw new FaultException("Usuario o contraseña incorrectos", new FaultCode("1000"));
        }
    }
    public static string EscribirLog(string mensaje)
    {
        string resultado = "todo bien";
        try
        {
            string folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "LogCmvSTPSPEI");
            if (!Directory.Exists(folder))
                Directory.CreateDirectory(folder);
            System.IO.File.WriteAllText(Path.Combine(folder, @"Log_" + Guid.NewGuid() + ".txt"), mensaje);
        }
        catch (Exception ex)
        {
            resultado = ex.Message;
        }
        return resultado;
    }

    public static bool validacionCampos_RegistraOrden(ordenPagoWS request)
    {
        //Se validan los campos que se generan desde el cliente
        return
            (String.IsNullOrEmpty(request.claveRastreo) || request.claveRastreo.Length < 11)
            ||
            (String.IsNullOrEmpty(request.cuentaBeneficiario) || request.cuentaBeneficiario.Length < 10)
            ||
            (String.IsNullOrEmpty(request.cuentaOrdenante) || request.cuentaOrdenante.Length < 16)
            ||
            (request.monto < 1); 
    }


}