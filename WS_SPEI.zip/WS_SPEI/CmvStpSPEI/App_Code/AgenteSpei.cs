﻿using Microsoft.Win32;
using ServicioStpProd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Web;
using System.Web.Configuration;

/// <summary>
/// Descripción breve de AgenteSpei
/// </summary>
public static class AgenteSpei
{
    private static string url = string.Empty;
    private static string hostProductivo = "";
    private static string hostPruebas = "";


    private static void InitConfig()
    {
        try
        {
            RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\APISpei");
            //RegistryKey key = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey(@"SOFTWARE\APISpei");
            if (key != null)
            {
                hostProductivo = key.GetValue("hostProductivo").ToString();
                hostPruebas = key.GetValue("hostPruebas").ToString();
                key.Close();
            }
            else
            {
                throw new Exception("No se obtuvieron los endpoint de conexión.\nConsulte la configuración con el administrador de los servicios de SPEI");
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private static BasicHttpsBinding initBasicHttpsBinding()
    {
        return new BasicHttpsBinding()
        {
            Name = "BasicHttpBinding_SpeiWebApp",
            MaxBufferSize = 2147483647,
            MaxReceivedMessageSize = 2147483647,
            SendTimeout = TimeSpan.FromMinutes(2)
        };
    }
    

    public static SpeiActualizaServicesClient SpeiActualizaServicesClient()
    {
        SpeiActualizaServicesClient client =null;
        try
        {
            InitConfig();
            url = WebConfigurationManager.AppSettings["servicioProductivo"].ToString().Equals("1") ? hostProductivo : hostPruebas;
            EndpointAddress endpointAddress = new EndpointAddress(url);
            client = new SpeiActualizaServicesClient(initBasicHttpsBinding(), endpointAddress);
        }
        catch (Exception ex){ throw new Exception("Excepcion generar desde los servicios de SPEI", ex); }

        return client;
    }


}