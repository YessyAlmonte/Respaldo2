﻿using CmvStpEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using CmvStpEntidades.Requests;

// NOTA: puede usar el comando "Cambiar nombre" del menú "Refactorizar" para cambiar el nombre de interfaz "ICmvMonitoreo" en el código y en el archivo de configuración a la vez.
[ServiceContract]
public interface ICmvMonitoreo
{
    [OperationContract]
    ResponseCheckServerStatus CheckServerStatus();

    [OperationContract]
    ResponseConsultaOrden ConsultaOrden(RequestConsultaOrdenRastreo request);

    [OperationContract]
    ResponseConsultaOrdenesFecha ConsultaOrdenesFecha(RequestConsultaOrdenesFecha request);

    [OperationContract]
    ResponseConsultaSaldoCuenta ConsultaSaldoCuenta();

    [OperationContract]
    ResponseConsultaSaldoCuentaHistorico ConsultaSaldoCuentaHistorico(RequestConsultaSaldoCuentaHistorico request);
}
