﻿using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

/// <summary>
/// 
///Necesario para log4net
/// </summary>
public class ServiceLog
{
    private readonly ILog log;
    public ServiceLog()
    {
        //Load log4net Configuration
        XmlConfigurator.Configure();
        //Get logger
        log = LogManager.GetLogger(typeof(ServiceLog));

        log.Debug("ServiceBase Constructor Call");
        //Start logging

    }
}