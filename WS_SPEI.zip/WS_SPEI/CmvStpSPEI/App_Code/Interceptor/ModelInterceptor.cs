﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CmvStpSPEI.Interceptor
{
    public class ModelInterceptor
    {
        public string usuario { get; set; }
        public string contrasena { get; set; }
    }
}