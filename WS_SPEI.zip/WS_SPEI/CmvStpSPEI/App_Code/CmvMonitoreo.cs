﻿using CmvStpDAO;
using CmvStpEntidades.Requests;
using CmvStpEntidades.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using CmvStpSPEI.Interceptor;
using ServicioStpProd;
// NOTA: puede usar el comando "Cambiar nombre" del menú "Refactorizar" para cambiar el nombre de clase "CmvMonitoreo" en el código, en svc y en el archivo de configuración a la vez.


[Interceptor]
public class CmvMonitoreo : ICmvMonitoreo
{
    //Cuenta clabe asociada a Caja Morelia
    private static string cuenta = "646180181100000006";
    public ResponseCheckServerStatus CheckServerStatus()
    {

        try
        {
            MonitoreoDAO monitoreo = new MonitoreoDAO();
            return new ResponseCheckServerStatus() { status = monitoreo.checkeoSTPProceso() };

        }
        catch (Exception e)
        {
            throw new FaultException(e.Message + "" + e.StackTrace, new FaultCode("1000"));
        }
    }
    public ResponseConsultaOrden ConsultaOrden(RequestConsultaOrdenRastreo request)
    {
        try
        {
            ConsOrdEnvRastreoSTPRequest requestToSTP = new ConsOrdEnvRastreoSTPRequest();
            requestToSTP.claveRastreo = request.claveRastreo;
            requestToSTP.empresa = "CAJA_MORELIA";
            requestToSTP.fechaOperacion = request.fechaOperacion;
            requestToSTP.institucionOperante = 90646;
            string cadenaOriginal = Utilidades.generarCadenaOriginalConsultaOrdenRastreo(requestToSTP);
            requestToSTP.firma = Utilidades.GeneraSello(cadenaOriginal);
            MonitoreoDAO dao = new MonitoreoDAO();
            return new ResponseConsultaOrden()
            {
                result = dao.consultaOrden(requestToSTP)
            };
        }
        catch(Exception e)
        {
            throw e;
        }
    }

    public ResponseConsultaOrdenesFecha ConsultaOrdenesFecha(RequestConsultaOrdenesFecha request)
    {
        try
        { 
            ConsOrdenesFechSTPRequest requestToSTP = new ConsOrdenesFechSTPRequest();
            requestToSTP.empresa = "CAJA_MORELIA";
            requestToSTP.estado = request.estado;
            requestToSTP.fechaOperacion = request.fechaOperacion;
            string cadenaOriginal = Utilidades.generarCadenaOriginalConsultaOrdenes(requestToSTP);
            requestToSTP.firma = Utilidades.GeneraSello(cadenaOriginal);
            MonitoreoDAO dao = new MonitoreoDAO();
            return new ResponseConsultaOrdenesFecha()
            { result = dao.consultaOrdenes(requestToSTP) };
        }
        catch (Exception e)
        {
            throw e;
        }

    }
    public ResponseConsultaSaldoCuenta ConsultaSaldoCuenta()
    {
        try
        {
            ConsultaSaldoCuentaSTPRequest request = new ConsultaSaldoCuentaSTPRequest();
            request.cuentaOrdenante = cuenta;
            request.firma = Utilidades.GeneraSello(cuenta);
            using(MonitoreoDAO dao = new MonitoreoDAO())
            {
                return dao.ConsultaSaldoCuenta(request);
            }
        }
        catch(Exception e)
        {
            FaultException<ResponseConsultaSaldoCuenta> a 
                = new FaultException<ResponseConsultaSaldoCuenta>(new ResponseConsultaSaldoCuenta(), String.Concat(e.Message, e.StackTrace), new FaultCode("100"));
            throw a;
        }
    }

    public ResponseConsultaSaldoCuentaHistorico ConsultaSaldoCuentaHistorico(RequestConsultaSaldoCuentaHistorico request)
    {
        try
        {
            request.cuenta = cuenta;
            string cadenaOriginal = Utilidades.generarCadenaOriginalConsultaCuentaHistorico(request);
            request.firma = Utilidades.GeneraSello(cadenaOriginal);
            request.firma = Uri.EscapeDataString(request.firma);
            using (MonitoreoDAO dao = new MonitoreoDAO())
            {
                return dao.ConsultaSaldoCuentaHistorico(request);
            }
        }
        catch (Exception e)
        {
            FaultException<ResponseConsultaSaldoCuenta> a
                = new FaultException<ResponseConsultaSaldoCuenta>(new ResponseConsultaSaldoCuenta(), String.Concat(e.Message, e.StackTrace), new FaultCode("100"));
            throw a;
        }
    }
}
