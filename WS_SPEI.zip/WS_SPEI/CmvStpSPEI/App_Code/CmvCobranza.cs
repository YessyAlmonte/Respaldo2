﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using CmvStpDAO;
using CmvStpEntidades.Exceptions;
using CmvStpEntidades.Requests;
using CmvStpEntidades.Responses;
using CmvStpSPEI.Interceptor;

// NOTA: puede usar el comando "Cambiar nombre" del menú "Refactorizar" para cambiar el nombre de clase "CmvCobranza" en el código, en svc y en el archivo de configuración a la vez.
[Interceptor]
public class CmvCobranza : ICmvCobranza
{
  
    public ResponseSendAbono SendAbono(RequestSendAbono request)
    {
        try
        {
            
            return new CobranzaDAO().SendAbono(request);
        }
        catch (FaultException<ExceptionSendAbono> ef)
        {
            throw ef;
        }
        catch (Exception ex)
        {
            ExceptionSendAbono exceptionSendAbono = new ExceptionSendAbono();
            exceptionSendAbono.Codigo = 1000;
            exceptionSendAbono.Mensaje = "El error no se encuentra en un catálogo definido por CMV: "+ex.Message;
            throw new FaultException<ExceptionSendAbono>(exceptionSendAbono);
        }
    }
}
