﻿using CmvStpEntidades;
using CmvStpSPEI.Interceptor;
using ServicioStpProd;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

// NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Service1" en el código, en svc y en el archivo de configuración.
[Interceptor]
public class Service : IService
{
    public string GetData(int value)
    {

        try
        {
            SpeiActualizaServicesClient client = AgenteSpei.SpeiActualizaServicesClient();
            ordenPagoWS ordenPago = new ordenPagoWS();

            //CmvDispersion client = new CmvDispersion();

            ordenPago.empresa = "CAJA_MORELIA";
            ordenPago.claveRastreo = "RAS0009";
            ordenPago.referenciaNumerica = 1234567;//9999999
            ordenPago.cuentaBeneficiario = "1315654198765465";
            ordenPago.tipoPago = 1;
            ordenPago.nombreBeneficiario = "Eduardo";
            ordenPago.rfcCurpBeneficiario = "ND";
            ordenPago.topologia = "T";
            ordenPago.institucionOperante = 90646;
            ordenPago.tipoCuentaBeneficiario = 40;
            ordenPago.conceptoPago = "prueba";
            ordenPago.institucionContraparte = 846;
            ordenPago.monto = 2.00M;
            ordenPago.tipoCuentaBeneficiarioSpecified = true;
            ordenPago.institucionOperanteSpecified = true;
            ordenPago.institucionContraparteSpecified = true;
            ordenPago.tipoPagoSpecified = true;
            ordenPago.referenciaNumericaSpecified = true;
            ordenPago.montoSpecified = true;
            
            ordenPago.firma = Utilidades.GeneraSello(Utilidades.GenerarCadenaOrginal(ordenPago));

            System.Net.ServicePointManager.SecurityProtocol =
            SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
            ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => {
                return true;
            };


            
            speiServiceResponse response = client.registraOrden(ordenPago, "");

            //speiServiceResponse response = client.RegistraOrden(ordenPago);

            /*MemoryStream ms = new MemoryStream();
            var dataContractSerializer = new DataContractSerializer(typeof(speiServiceResponse));
            dataContractSerializer.WriteObject(ms, orden);
            string xml = System.Text.Encoding.UTF8.GetString(ms.ToArray());
            */

            PropertyInfo[] properties = typeof(ordenPagoWS).GetProperties();



        }
        catch (Exception ex)
        {

            throw ex;
        }
        return string.Format("You entered: {0}", value);
    }
    
    public String EscribirEvent(string cadena)
    {
        string path = string.Empty;
        try
        {
            new Logg().Info("conexion string:"+ConexionAPI.ObtenerConexionSA());
            // path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Certificado","prueba.p12");
            string strLlavePwd = ConfigurationManager.AppSettings["claveGeneraSello"].ToString();
             path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Certificado", "prueba.p12");

            new Logg().Info("Estoy escribiendo: " + cadena + " path raiz: " + path);
            if (File.Exists(path))
                new Logg().Info("Existe Archivo");

            X509Certificate2 x509 = new X509Certificate2(path, strLlavePwd);
            //RSACryptoServiceProvider rsaProvider = (RSACryptoServiceProvider)x509.PrivateKey;
            //SHA256 hasher = SHA256CryptoServiceProvider.Create();
            //byte[] hashValue = rsaProvider.SignData(System.Text.Encoding.UTF8.GetBytes("1231321"), hasher);
            //return System.Convert.ToBase64String(hashValue);
        }
        catch (Exception ex)
        {
            throw new FaultException(ex.Message+" "+ex.StackTrace, new FaultCode("1000"));
        }
        return path;
    }

    public decimal Decimalcero(decimal numero)
    {
        try
        {
            return (numero * 1.00M);
        }
        catch (Exception ex)
        {

            throw new FaultException(ex.Message + " " + ex.StackTrace, new FaultCode("1000"));
        }
    }

    
}
