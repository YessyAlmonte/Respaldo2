﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using CmvStpDAO;
using CmvStpEntidades.Exceptions;
using CmvStpEntidades.Requests;
using CmvStpEntidades.Responses;
using CmvStpSPEI.Interceptor;
using ServicioStpProd;

[Interceptor]
public class CmvDispersion : ICmvDispersion
{
    public ResponseCambiaEstado CambiaEstado(RequestCambiaEstado request)
    {
        try
        {
            return new DispersionDAO().CambiaEstado(request);
        }
        catch (FaultException<ExceptionCambiaEstado> ef) {
            throw ef;
        }
        catch (Exception ex)
        {
            throw new FaultException(ex.Message + "" + ex.StackTrace, new FaultCode("1000"));
        }
    }

    

    public speiServiceResponse RegistraOrden(ordenPagoWS request)
    {
        speiServiceResponse response = null;
        SpeiActualizaServicesClient client = AgenteSpei.SpeiActualizaServicesClient();
        try
        {
            if (Utilidades.validacionCampos_RegistraOrden(request))
            {
                throw new Exception("Parametros en registra orden incorrectos");
            }
            request.conceptoPago = request.conceptoPago.Trim();
            request.empresa = "CAJA_MORELIA";
            //request.claveRastreo = "RAS0006";// CMV + TBL_BANCA_FOLIOS (CMV00000001)
            //request.referenciaNumerica = 9999999; //
            //request.cuentaBeneficiario = "846180000400000001";
            request.tipoPago = 1;
            //request.nombreBeneficiario = "Eduardo";
            //request.rfcCurpBeneficiario = "ND";
            request.topologia = "T";
            request.institucionOperante = 90646;
            //request.tipoCuentaBeneficiario = 40;
            //request.conceptoPago = "prueba";
            //request.institucionContraparte = 846;
            //request.monto = 150.00M;
            request.monto = Math.Round((request.monto * 1.00M), 2);
            request.tipoCuentaBeneficiarioSpecified = true;
            request.institucionOperanteSpecified = true;
            request.institucionContraparteSpecified = true;
            request.tipoPagoSpecified = true;
            request.referenciaNumericaSpecified = true;
            request.montoSpecified = true;

            string cadenaOriginal = Utilidades.GenerarCadenaOrginal(request);

            request.firma = Utilidades.GeneraSello(cadenaOriginal);

            System.Net.ServicePointManager.SecurityProtocol =
            SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;
            ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => {
                return true;
            };
            response = client.registraOrden(request, "");

            MemoryStream ms = new MemoryStream();
            var dataContractSerializer = new DataContractSerializer(typeof(speiServiceResponse));
            dataContractSerializer.WriteObject(ms, response);
            string xmlResponse = System.Text.Encoding.UTF8.GetString(ms.ToArray());

            ms = new MemoryStream();
            dataContractSerializer = new DataContractSerializer(typeof(ordenPagoWS));
            dataContractSerializer.WriteObject(ms, request);
            string xmlRequest = System.Text.Encoding.UTF8.GetString(ms.ToArray());

            StringBuilder mensaje = new StringBuilder();
            mensaje.Append("********   Registra Orden  ********");
            mensaje.Append("Request:\n" + xmlRequest + "\n\n");
            mensaje.Append("Cadena original:\n" + cadenaOriginal + "\n\n");
            mensaje.Append("Firma de request:\n" + request.firma);
            mensaje.Append("Response:\n" + xmlResponse + "\n\n");

            Utilidades.EscribirLog(mensaje.ToString());

        }
        catch (Exception ex)
        {
            try
            {
                CmvMonitoreo m = new CmvMonitoreo();
                ResponseConsultaOrden consulta = m.ConsultaOrden(
                    new RequestConsultaOrdenRastreo() {
                    claveRastreo = request.claveRastreo,
                    fechaOperacion = Convert.ToInt32(DateTime.Now.ToString("yyyyMMdd"))
                    });
                if(consulta.result.resultado.id > 0 && consulta.result.resultado.ordenPago != null)
                {
                    //if (validacionEstadosOrden(consulta.result.resultado.ordenPago.estado))
                    //{
                    response = new speiServiceResponse()
                    {
                        id = consulta.result.resultado.ordenPago.idEF,
                        idSpecified = true
                    };
                    return response;
                    //}                
                }
            }catch(Exception e)
            {
                /*SE INSERTA TRANSFERENCIA PENDIENTE PARA QUE DESPUES SE DEVUELVA EL DINERO*/
                //DispersionDAO dispersionDAO = new DispersionDAO();
                //dispersionDAO.IntertarTranferenciaErroneaSTP(request.claveRastreo, DateTime.Now.ToString("yyyyMMdd"),e.Message);

            }
            throw new FaultException(ex.Message + "" + ex.StackTrace, new FaultCode("1000"));
        }
        return response;
    }
    private bool validacionEstadosOrden(string estado)
    {
        /*
        C	Capturada	Es el primer estado en el que se genera una Orden Manual o por Layout
        PL	Pendiente Liberar	Es un estado transitorio entre Capturada y Liberada el cual dura segundos
        L	Liberada	Es una orden que ya a sido Liberada y lista para ser Autorizada
        PA	Pendiente Autorizar	Estado transitorio por el que pasa una orden entre liberada y autorizada
        A	Autorizada	Es el estado en el que se encuentra una orden cuando el cliente nos Autoriza procesarla
        E	Enviada	Es un estado transitorio donde se realizan las validaciones previas antes del envío del pago a Banxico
        LQ	Liquidada	Pago u Operación exitoso enviado o recibido

        XC	Por Cancelar	Es un estado transitorio en el que se encuentra la orden antes de ser Cancelada
        CN	Cancelada	Es cuando anulamos una orden desde que ingresa hasta antes de enviarla NOTA: Las ordenes Liquidadas no se pueden cancelar
        D	Devuelta	Ordenes en las que ya se realizo la devolución del dinero 
        XD	Por Devolver	Es cuando una orden ya se encuentra liquidada y el cliente requiere hacer una devolución, en este caso, la orden pasa a este estado para su análisis
        CL	Cancelada Local	Son ordenes canceladas hechas por el sistema
        CR	Canc. Rechazada	Son ordenes en las que el cliente anula el rechazo
        RL	Rechazada Local	Son ordenes rechazadas directamente por el cliente
        EA	Enviada Adapter	Es una orden enviada para ser procesada en el Adapter (STP a Banxico)
        CA	Cancelada Adapter	Es una operación que no cumple con los datos requeridos y que no se pueden volver a modificar
        RA	Rechazada Adapter	Es una operación en la que la orden tiene algún dato erróneo pero que puede ser modificada, esta se corrige y se vuelve a procesar
        RB	Rechazada Banxico	Es una orden que tiene algún dato erróneo el cual no se detecto por EF (Enlace Financiero) ni por el Adapter y Banxico la rechaza para ser corregida y volverla a procesar
        
        Fuente: https://stpmex.zendesk.com/hc/es/articles/360040200791
         
         */
        return
            estado.Equals("C")
            || estado.Equals("PL")
            || estado.Equals("L")
            || estado.Equals("PA")
            || estado.Equals("A")
            || estado.Equals("E")
            || estado.Equals("LQ")
            || estado.Equals("EA");
    }

    public ResponseEstadoCuentaCLABE NotificacionEstadoCuenta(RequestEstadoCuentaCLABE request)
    {
        try
        {
            DispersionDAO dao = new DispersionDAO();
            ResponseEstadoCuentaCLABE response = new ResponseEstadoCuentaCLABE();

            response = dao.ActualizaEstatusCuenta(request);

            return response;

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
}
