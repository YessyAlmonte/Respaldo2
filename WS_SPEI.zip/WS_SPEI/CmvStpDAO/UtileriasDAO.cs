﻿using AccesoDatos;
using CmvStpEntidades;
using SmsMailUtils;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Win32;

namespace CmvStpDAO
{
    public class UtileriasDAO
    {
        private DBManager db = null;
        #region NOTIFICACIONES 
        public List<Notificacion> ObtenerNotificacionSocio(Int32 Numero, int idTipoBitacora)
        {
            List<Notificacion> notificaciones = new List<Notificacion>();
            Notificacion notificacion = null;
            try
            {
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(5);
                    db.AddParameters(0, "@numeroSocio", Numero);
                    db.AddParameters(1, "@id_tipo_bitacora", idTipoBitacora);// CAT_BANCA_TIPOS_BITACORA -> RECIBE SPEI
                    db.AddParameters(2, "@id_tipo_notificacion", DBNull.Value);
                    db.AddParameters(3, "@noCel", DBNull.Value);
                    db.AddParameters(4, "@correo", DBNull.Value);
                    db.ExecuteReader(CommandType.StoredProcedure, "SP_BANCA_OBTENER_NOTIFICACION");

                    if (db.DataReader.Read())
                    {
                        if (db.DataReader["estatus"].ToString().Equals("200"))
                        {
                            if (db.DataReader.NextResult())
                            {
                                while (db.DataReader.Read())
                                {
                                    notificacion = new Notificacion();
                                    {
                                        notificacion.celular = db.DataReader["celular"] == DBNull.Value ? "" : db.DataReader["celular"].ToString();
                                        notificacion.correo = db.DataReader["correo"] == DBNull.Value ? "" : db.DataReader["correo"].ToString();
                                        notificacion.idTipoNotificacion = (TIPO_NOTIFICACION)Convert.ToInt16(db.DataReader["idTipoNotificacion"].ToString());
                                        notificacion.cuerpo = db.DataReader["cuerpo"] == DBNull.Value ? null : db.DataReader["cuerpo"].ToString();
                                        notificacion.asunto = db.DataReader["asunto"] == DBNull.Value ? null : db.DataReader["asunto"].ToString();
                                        if (db.DataReader["correo"] != DBNull.Value)
                                        {
                                            notificacion.para.Add(db.DataReader["correo"].ToString());
                                        }
                                    };
                                    notificaciones.Add(notificacion);
                                }
                            }
                        }
                        else
                        {
                            throw new Exception(db.DataReader["mensaje"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return notificaciones;

        }
        #endregion

        public string ToXML(Object o)
        {
            try
            {
                var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
                var serializer = new XmlSerializer(o.GetType());
                var settings = new XmlWriterSettings();
                settings.Indent = false;
                settings.OmitXmlDeclaration = true;
                using (var stream = new StringWriter())
                using (var writer = XmlWriter.Create(stream, settings))
                {
                    serializer.Serialize(writer, o, emptyNamepsaces);
                    return stream.ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private static string ObtenerGeneral(string value)
        {
            string subKey = @"SOFTWARE\APISpei";
            RegistryKey localMachineRegistry64 = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
            RegistryKey key = localMachineRegistry64.OpenSubKey(subKey, false);

            //RegistryKey key = Registry.LocalMachine.OpenSubKey(subKey, false);
            try
            {
                if (key != null)
                {
                    return Convert.ToString(key.GetValue(value));
                }
                return "";
            }
            catch (Exception e)
            {
                return "";
            }
            finally
            {
                if (key != null)
                    key.Close();
            }
        }
        public static string ObtenerAPIServer()
        {
            return ObtenerGeneral("endpointsServer");
        }
        public static string ObtenerConsultaOrdenEndpoint()
        {
            return ObtenerGeneral("consultaOrden");
        }
        public static string ObtenerConsultaSaldoCuentaEndpoint()
        {
            return ObtenerGeneral("consultaSaldoCuenta");
        }
        public static string ObtenerConsultaSaldoCuentaHistoricoEndpoint()
        {
            return ObtenerGeneral("consultaSaldoCuentaHistorico");
        }

        public static string ObtenerConsultaOrdenesEndpoint()
        {
            return ObtenerGeneral("consultaOrdenes");
        }
    }






    }
