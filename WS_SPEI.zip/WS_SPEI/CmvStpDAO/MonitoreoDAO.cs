﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Microsoft.Win32;
using System.Web.Configuration;
using System.Diagnostics;
using CmvStpEntidades.Requests;
using CmvStpEntidades.Responses.ConsultaOrdenObjects;
using CmvStpEntidades.Responses.ConsultaOrdenesObjects;
using Newtonsoft.Json;
using System.Net;
using System.Net.Security;
using CmvStpEntidades.Responses;

namespace CmvStpDAO
{
    public class MonitoreoDAO : IDisposable
    {
        string assert_string = "registraOrden";
        private HttpClient client = new HttpClient() {
            Timeout = TimeSpan.FromSeconds(7)
        };

        public ConsOrdEnvRastreoSTPResponse consultaOrden(ConsOrdEnvRastreoSTPRequest requestToSTP)
        {
            ConsOrdEnvRastreoSTPResponse response = new ConsOrdEnvRastreoSTPResponse();
            try
            {
                string server = UtileriasDAO.ObtenerAPIServer();
                HttpClient clientConsultaOrden = new HttpClient()
                {
                    Timeout = TimeSpan.FromSeconds(7),
                    BaseAddress = new Uri(server)
                };
                
                string endpoint = UtileriasDAO.ObtenerConsultaOrdenEndpoint();
                clientConsultaOrden.DefaultRequestHeaders.ConnectionClose = true;
                clientConsultaOrden.DefaultRequestHeaders.Add("Keep-Alive", "timeout=5,max=1");

                System.Net.ServicePointManager.SecurityProtocol =
                   System.Net.SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, errors) =>
                {
                    if (server.Contains("prod.stpmex.com")) return true;
                    return errors == SslPolicyErrors.None;
                };
                clientConsultaOrden.DefaultRequestHeaders.Accept.Add(
               new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                string stringRequestPayload = Newtonsoft.Json.JsonConvert.SerializeObject(requestToSTP);
                var httpContentRequest = new StringContent(stringRequestPayload, Encoding.UTF8, "application/json");

                using (HttpResponseMessage httpResponseApi = clientConsultaOrden.PostAsync(endpoint, httpContentRequest).Result)
                {
                    if (httpResponseApi.IsSuccessStatusCode)
                    {
                        var dataObjectsMonitor = httpResponseApi.Content.ReadAsStringAsync().Result;
                        response =
                                Newtonsoft.Json.JsonConvert.DeserializeObject<ConsOrdEnvRastreoSTPResponse>(dataObjectsMonitor);
                        return response;
                    }
                }
            }
            catch(Exception e)
            {
                throw e;
            }
            finally
            {

            }
            return response;
        }

        public ConsOrdenesFechSTPResponse consultaOrdenes(ConsOrdenesFechSTPRequest requestToSTP)
        {
            /*Estados:
             * E: Enviada
             * R: Recibida
             *  Fuente: https://stpmex.zendesk.com/hc/es/articles/360039781512-Consulta-Ordenes-Enviadas-o-Recibidas
             */

            ConsOrdenesFechSTPResponse  response =  new ConsOrdenesFechSTPResponse();
            try
            {

                string server = UtileriasDAO.ObtenerAPIServer();
                HttpClient clientConsultaOrden = new HttpClient()
                {
                    Timeout = TimeSpan.FromSeconds(7),
                    BaseAddress = new Uri(server)
                };

                string endpoint = UtileriasDAO.ObtenerConsultaOrdenesEndpoint();
                clientConsultaOrden.DefaultRequestHeaders.ConnectionClose = true;
                clientConsultaOrden.DefaultRequestHeaders.Add("Keep-Alive", "timeout=5,max=1");

                System.Net.ServicePointManager.SecurityProtocol =
                   System.Net.SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, errors) =>
                {                    
                    if (server.Contains("prod.stpmex.com")) return true;
                    return errors == SslPolicyErrors.None;
                };
                clientConsultaOrden.DefaultRequestHeaders.Accept.Add(
               new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                string stringRequestPayload = JsonConvert.SerializeObject(requestToSTP);
                var httpContentRequest = new StringContent(stringRequestPayload, Encoding.UTF8, "application/json");

                using (HttpResponseMessage httpResponseApi = clientConsultaOrden.PostAsync(endpoint, httpContentRequest).Result)
                {
                    if (httpResponseApi.IsSuccessStatusCode)
                    {
                        var dataObjectsMonitor = httpResponseApi.Content.ReadAsStringAsync().Result;
                        response =
                                JsonConvert.DeserializeObject<ConsOrdenesFechSTPResponse>(dataObjectsMonitor);
                        return response;
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {

            }
            return response;
        }

        HttpResponseMessage response = null;
        public Boolean checkeoSTPConnection()
        {
            client.DefaultRequestHeaders.ConnectionClose = true;
            client.DefaultRequestHeaders.Add("Keep-Alive", "timeout=5,max=1");
            bool isStatus = false;
            bool isAssert = false;
            try
            {     
                System.Net.ServicePointManager.SecurityProtocol =
                System.Net.SecurityProtocolType.Tls12;
                using (response = client.GetAsync(getServer()).Result)
                {                    
                    isStatus = response.IsSuccessStatusCode;
                    isAssert = response.Content.ReadAsStringAsync().Result.IndexOf(assert_string) > 0;
                    
                    response.Dispose();
                }
                    return
                        isStatus && isAssert;

            }catch(Exception e)
            {
                throw e;
            }
        }
        public Boolean checkeoSTPProceso()
        {
            try
            {
                string line = "";
                var process = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName = "C:\\inetpub\\process-prod.exe",
                        UseShellExecute = false,
                        RedirectStandardOutput = true,
                        CreateNoWindow = true
                    }
                };
                process.Start();

                while (!process.StandardOutput.EndOfStream)
                {                    
                    line = process.StandardOutput.ReadLine();
                }
                return line.Contains("Download OK, comunication OK");
            }
            catch(Exception e)
            {
                throw e;
            }
        }

        public ResponseConsultaSaldoCuenta ConsultaSaldoCuenta(ConsultaSaldoCuentaSTPRequest request)
        {
            ResponseConsultaSaldoCuenta response = new ResponseConsultaSaldoCuenta();
            Stopwatch stopwatch = null;
            try
            {
                string server = UtileriasDAO.ObtenerAPIServer();
                HttpClient clientConsultaSaldo = new HttpClient()
                {
                    Timeout = TimeSpan.FromSeconds(7),
                    BaseAddress = new Uri(server)
                };

                string endpoint = UtileriasDAO.ObtenerConsultaSaldoCuentaEndpoint();
                clientConsultaSaldo.DefaultRequestHeaders.ConnectionClose = true;
                clientConsultaSaldo.DefaultRequestHeaders.Add("Keep-Alive", "timeout=5,max=1");

                System.Net.ServicePointManager.SecurityProtocol =
                   System.Net.SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, errors) =>
                {
                    if (server.Contains("prod.stpmex.com")) return true;
                    return errors == SslPolicyErrors.None;
                };
                clientConsultaSaldo.DefaultRequestHeaders.Accept.Add(
               new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                string stringRequestPayload = Newtonsoft.Json.JsonConvert.SerializeObject(request);
                var httpContentRequest = new StringContent(stringRequestPayload, Encoding.UTF8, "application/json");

                stopwatch = Stopwatch.StartNew();
                using (HttpResponseMessage httpResponseApi = clientConsultaSaldo.PostAsync(endpoint, httpContentRequest).Result)
                {
                    stopwatch.Stop();
                    if (httpResponseApi.IsSuccessStatusCode)
                    {
                        var dataObjectsMonitor = httpResponseApi.Content.ReadAsStringAsync().Result;
                        response =
                                Newtonsoft.Json.JsonConvert.DeserializeObject<ResponseConsultaSaldoCuenta>(dataObjectsMonitor);
                        response.TiempoRespuesta = stopwatch.ElapsedMilliseconds;
                        return response;
                    }
                }
            }
            catch (Exception e)
            {
                stopwatch = null;
                response.ExceptionMessage = e.Message + " " + e.StackTrace;
            }
            finally
            {
                stopwatch = null;
            }
            return response;
        }


        public ResponseConsultaSaldoCuentaHistorico ConsultaSaldoCuentaHistorico(RequestConsultaSaldoCuentaHistorico request)
        {
            ResponseConsultaSaldoCuentaHistorico response = new ResponseConsultaSaldoCuentaHistorico();
            Stopwatch stopwatch = null;
            try
            {
                string server = UtileriasDAO.ObtenerAPIServer();
                HttpClient clientConsultaSaldoHistorico = new HttpClient()
                {
                    Timeout = TimeSpan.FromSeconds(7),
                    BaseAddress = new Uri(server)
                };

                string endpoint = UtileriasDAO.ObtenerConsultaSaldoCuentaHistoricoEndpoint();
                clientConsultaSaldoHistorico.DefaultRequestHeaders.ConnectionClose = true;
                clientConsultaSaldoHistorico.DefaultRequestHeaders.Add("Keep-Alive", "timeout=5,max=1");

                System.Net.ServicePointManager.SecurityProtocol =
                   System.Net.SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, errors) =>
                {
                    if (server.Contains("prod.stpmex.com")) return true;
                    return errors == SslPolicyErrors.None;
                };
                clientConsultaSaldoHistorico.DefaultRequestHeaders.Accept.Add(
               new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                endpoint = String.Concat(endpoint, request.cuenta, "?firma=", request.firma,"&fecha=",request.fecha.ToString());

                stopwatch = Stopwatch.StartNew();
                using (HttpResponseMessage httpResponseApi = clientConsultaSaldoHistorico.GetAsync(endpoint).Result)
                {
                    stopwatch.Stop();
                    if (httpResponseApi.IsSuccessStatusCode)
                    {
                        var dataObjectsMonitor = httpResponseApi.Content.ReadAsStringAsync().Result;
                        response =
                                Newtonsoft.Json.JsonConvert.DeserializeObject<ResponseConsultaSaldoCuentaHistorico>(dataObjectsMonitor);
                        response.TiempoRespuesta = stopwatch.ElapsedMilliseconds;
                        return response;
                    }
                }
            }
            catch (Exception e)
            {
                stopwatch = null;
            }
            finally
            {
                stopwatch = null;
            }
            return response;
        }


        private string getServer()
        {
            string url = "";
            try
            {
                //RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\APISpei");
                RegistryKey key = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey(@"SOFTWARE\APISpei");
                if (key != null)
                {
                    url = WebConfigurationManager.AppSettings["servicioProductivo"].ToString().Equals("1") ? 
                        key.GetValue("hostProductivo").ToString() :
                        key.GetValue("hostPruebas").ToString()+"?wsdl";
                    key.Close();
                }
                else
                {
                    throw new Exception("No se obtuvieron los endpoint de conexión.\nConsulte la configuración con el administrador de los servicios de SPEI");
                }
            }
            catch (Exception e)
            {
                url = "";
            }
            return url;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}
