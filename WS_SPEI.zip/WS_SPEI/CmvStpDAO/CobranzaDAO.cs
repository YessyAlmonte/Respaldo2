﻿using AccesoDatos;
using CmvStpEntidades;
using CmvStpEntidades.Exceptions;
using CmvStpEntidades.Requests;
using CmvStpEntidades.Responses;
using SmsMailUtils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpDAO
{
    public class CobranzaDAO
    {
        private DBManager db = null;
        public ResponseSendAbono SendAbono(RequestSendAbono request)
        {
            ResponseSendAbono responseSendAbono = null;
            //Si el sendAbono es notificación de fondeo de la cuenta concentradora
            //Evita que STP vea errores de nuestro lado
            if (request.CuentaBeneficiario.Equals("646180181100000006"))
            {
                responseSendAbono = new ResponseSendAbono();
                responseSendAbono.Estado = true;
                responseSendAbono.mensaje = "OK";
                responseSendAbono.TipoDevolucion = TipoDevolucion.Ninguno;
                responseSendAbono.FolioRastreo = request.ClaveRastreo;
                return responseSendAbono;
            }
            try
            {
                responseSendAbono = new ResponseSendAbono();
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(16);
                    db.AddParameters(0, "Id", request.Id);
                    db.AddParameters(1, "FechaOperacion", request.FechaOperacion);
                    db.AddParameters(2, "InstitucionOrdenante", request.InstitucionOrdenante);
                    db.AddParameters(3, "InstitucionBeneficiara", request.InstitucionBeneficiara);
                    db.AddParameters(4, "ClaveRastreo", request.ClaveRastreo);
                    db.AddParameters(5, "Monto", request.Monto);
                    db.AddParameters(6, "NombreOrdenante", request.NombreOrdenante);
                    db.AddParameters(7, "TipoCuentaOrdenante", request.TipoCuentaOrdenante);
                    db.AddParameters(8, "CuentaOrdenante", request.CuentaOrdenante);
                    db.AddParameters(9, "RfcCurpOrdenante", request.RfcCurpOrdenante);
                    db.AddParameters(10, "NombreBenificiario", request.NombreBenificiario);
                    db.AddParameters(11, "TipoCuentaBeneficiario", request.TipoCuentaBeneficiario);
                    db.AddParameters(12, "CuentaBeneficiario", request.CuentaBeneficiario);
                    db.AddParameters(13, "RfcCurpBeneficiario", request.RfcCurpBeneficiario);
                    db.AddParameters(14, "ConceptoPago", request.ConceptoPago);
                    db.AddParameters(15, "RefereneciaNumerica", request.RefereneciaNumerica);
                    db.AddParameters(16, "Empresa", request.Empresa);
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_RECIBE_TRANSFERENCIA_EXTERNA");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            responseSendAbono.Estado = true;
                            responseSendAbono.mensaje = "OK";
                            responseSendAbono.TipoDevolucion = TipoDevolucion.Ninguno;
                            responseSendAbono.FolioRastreo = request.ClaveRastreo;
                            List<Notificacion> notificaciones = (new UtileriasDAO().ObtenerNotificacionSocio(Convert.ToInt32(db.DataReader["numeroSocio"].ToString()),92));
                            SmsMail.validarTipoNotificaion(notificaciones);
                            //foreach (Notificacion n in notificaciones)
                            //{
                            //    switch (n.idTipoNotificacion)
                            //    {
                            //        case TIPO_NOTIFICACION.SMS:
                            //            SmsMail.SendSmsBanca(n);
                            //            break;
                            //        case TIPO_NOTIFICACION.CORREO_ELECTRONICO:
                            //            SmsMail.SendCorreExterno(n);
                            //            break;
                            //        default:
                            //            break;
                            //    }
                            //}
                        }
                        else
                        {
                            responseSendAbono.Estado = false;
                            responseSendAbono.mensaje = db.DataReader["mensaje"].ToString();
                            responseSendAbono.TipoDevolucion = TipoDevolucion.Beneficiario_no_reconoce_el_pago;
                            responseSendAbono.FolioRastreo = request.ClaveRastreo;
                        }
                    }
                }
            }
            
            catch (Exception ex)
            {
                ExceptionSendAbono exceptionSendAbono = new ExceptionSendAbono();
                exceptionSendAbono.Codigo = Convert.ToInt32(TipoDevolucion.Beneficiario_no_reconoce_el_pago);
                exceptionSendAbono.TipoDevolucion = TipoDevolucion.Beneficiario_no_reconoce_el_pago;
                exceptionSendAbono.Mensaje = db.DataReader["mensaje"].ToString();
                exceptionSendAbono.FolioRastreo = request.ClaveRastreo;
                throw new FaultException<ExceptionSendAbono>(exceptionSendAbono);
            }

            return responseSendAbono;

        }

    }
}
