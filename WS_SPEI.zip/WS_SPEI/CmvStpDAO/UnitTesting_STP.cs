﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CmvStpEntidades.Requests;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SmsMailUtils;
using System.Threading;

namespace CmvStpDAO
{
    [TestClass]
    public class UnitTesting_STP
    {
        [TestMethod()]
        public void TestWSDLRetrieving()
        {
            MonitoreoDAO dao = new MonitoreoDAO();
            Assert.IsTrue(dao.checkeoSTPConnection());
        }

        [TestMethod()]
        public void TestWSDLRetrievingWithProcess()
        {
            MonitoreoDAO dao = new MonitoreoDAO();
            Assert.IsTrue(dao.checkeoSTPProceso());
        }

       [TestMethod()]
       [Description("Send messages, DLL Testing")]
       public void SendMessage_WhenHappyPathBalta()
        {
            List<Notificacion> notificaciones = new List<Notificacion>();
            Notificacion n = new Notificacion();
            n.celular = "4361159794";
            n.correo = "baltamlh.529@gmail.com";
            n.idTipoNotificacion = TIPO_NOTIFICACION.SMS;
            n.cuerpo = "UnitTesting messages";
            n.asunto = "Unit Testing";
            n.para.Add("baltamlh.529@gmail.com");
            notificaciones.Add(n);            
            SmsMail.validarTipoNotificaion(notificaciones);
            Thread.Sleep(5000);
        }

        [TestMethod()]
        [Description("Send messages, DLL Testing")]
        public void SendMessage_WhenHappyPathLalo()
        {
            List<Notificacion> notificaciones = new List<Notificacion>();
            Notificacion n = new Notificacion();
            n.celular = "4433584441";
            n.correo = "baltamlh.529@gmail.com";
            n.idTipoNotificacion = TIPO_NOTIFICACION.SMS;
            n.cuerpo = "UnitTesting messages";
            n.asunto = "Unit Testing";
            n.para.Add("baltamlh.529@gmail.com");
            notificaciones.Add(n);
            SmsMail.validarTipoNotificaion(notificaciones);
            Thread.Sleep(5000);
        }

        [TestMethod()]
        [Description("Send messages, DLL Testing")]
        public void SendSMS_WhenHappyPath()
        {
            List<Notificacion> notificaciones = new List<Notificacion>();
            Notificacion n = new Notificacion();
            n.celular = "4361159794";
            n.correo = "baltamlh.529@gmail.com";
            n.idTipoNotificacion = TIPO_NOTIFICACION.SMS;
            n.cuerpo = "UnitTesting messages";
            n.asunto = "Unit Testing";
            n.para.Add("baltamlh.529@gmail.com");
           // notificaciones.Add(n);
            SmsMail.SendSms(n);
            Thread.Sleep(5000);
        }


        [TestMethod()]
        [Description("Send cambia estado")]
        public void CambiaEstado_WhenHappyPath()
        {
            RequestCambiaEstado request = new RequestCambiaEstado();
            request.CausaDevolucion = "Ninguno";
            request.Empresa = "CAJA_MORELIA";
            request.Estado = true;
            request.FolioOrigen = "CMV00003391";
            request.Id = "8215422";

            DispersionDAO dao = new DispersionDAO();
            dao.CambiaEstado(request);
        }

        [TestMethod]
        [Description("Get consultaSaldo from STP")]
        public void ConsultaSaldo_WhenHappyPath()
        {
            ConsultaSaldoCuentaSTPRequest request = new ConsultaSaldoCuentaSTPRequest();
            //request.cuentaOrdenante = cuenta;
            //request.firma = Utilidades.GeneraSello(cuenta);
        }



    }
}
