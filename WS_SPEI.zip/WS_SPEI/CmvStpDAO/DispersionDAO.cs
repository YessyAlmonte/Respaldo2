﻿using AccesoDatos;
using CmvStpEntidades;
using CmvStpEntidades.Exceptions;
using CmvStpEntidades.Requests;
using CmvStpEntidades.Responses;
using SmsMailUtils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;

namespace CmvStpDAO
{
    public class DispersionDAO
    {
        private DBManager db = null;
        public DispersionDAO()
        {

        }
        public ResponseCambiaEstado CambiaEstado(RequestCambiaEstado request)
        {
            ResponseCambiaEstado responseCambiaEstado = null;
            try
            {
                TipoDevolucion causaDevolucion;
                causaDevolucion = Enum.TryParse<TipoDevolucion>(request.CausaDevolucion, true, out causaDevolucion) ? causaDevolucion : TipoDevolucion.Ninguno;
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    responseCambiaEstado = new ResponseCambiaEstado();
                    db.Open();
                    db.CreateParameters(7);
                    db.AddParameters(0, "Id", request.Id);
                    db.AddParameters(1, "@empresa", request.Empresa);
                    db.AddParameters(2, "@folioOrigen", request.FolioOrigen);
                    db.AddParameters(3, "@estado", request.Estado);
                    db.AddParameters(4, "@causaDevolucion", causaDevolucion);
                    db.AddParameters(5, "@request", new UtileriasDAO().ToXML(request));
                    db.AddParameters(6, "@DescCausaDevolucion", request.CausaDevolucion);                    
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_CAMBIA_ESTADO_SPEI");
                    if (db.DataReader.Read())
                    {
                        if (db.DataReader["estatus"].ToString().Equals("200"))
                        {
                            responseCambiaEstado.Estatus = true;
                            responseCambiaEstado.Mensaje = "ok";
                            responseCambiaEstado.FolioRastreo = request.FolioOrigen;
                            int idTipoBitacora = request.Estado == true ? 17 : 96;
                            List<Notificacion> notificaciones = new UtileriasDAO().ObtenerNotificacionSocio(Convert.ToInt32(db.DataReader["numeroSocio"].ToString()), idTipoBitacora);
                            SmsMail.validarTipoNotificaion(notificaciones);
                            //foreach(Notificacion n in notificaciones)
                            //{
                            //    switch (n.idTipoNotificacion)
                            //    {
                            //        case TIPO_NOTIFICACION.SMS:
                            //            SmsMail.SendSmsBanca(n);
                            //            break;
                            //        case TIPO_NOTIFICACION.CORREO_ELECTRONICO:
                            //            SmsMail.SendCorreExterno(n);
                            //            break;
                            //        default:
                            //            break;
                            //    }
                            //}
                        }
                            
                        else
                        {
                            ExceptionCambiaEstado exceptionCambiaEstado = new ExceptionCambiaEstado();
                            exceptionCambiaEstado.Estatus = Convert.ToInt32(db.DataReader["estatus"].ToString());
                            exceptionCambiaEstado.Mensaje = db.DataReader["mensaje"].ToString();
                            exceptionCambiaEstado.Descripcion = string.Empty;
                            exceptionCambiaEstado.FolioRastreo = request.FolioOrigen;
                            throw new FaultException<ExceptionCambiaEstado>(exceptionCambiaEstado);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return  responseCambiaEstado;
                
        }


        public bool IntertarTranferenciaErroneaSTP(string claveRastreo, string cadenaFechaOperacion, string mensajeError)
        {
            bool transferenciaAgregada = false;
            try
            {
                //TipoDevolucion causaDevolucion;
                //causaDevolucion = Enum.TryParse<TipoDevolucion>(request.CausaDevolucion, true, out causaDevolucion) ? causaDevolucion : TipoDevolucion.Ninguno;
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    
                    db.Open();
                    db.CreateParameters(3);
                    db.AddParameters(0, "@claveRastreo", claveRastreo);
                    db.AddParameters(1, "@cadenaFechaOperacion", cadenaFechaOperacion);
                    db.AddParameters(2, "@mensajeError", mensajeError);
                    
                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_INSERTAR_TRANSFERENCIA_ERRONEA_STP");
                    if (db.DataReader.Read())
                    {
                        if (db.DataReader["estatus"].ToString().Equals("200"))
                        {
                            transferenciaAgregada = true;                            
                        }

                        else
                        {
                            //db.DataReader["error_message"].ToString();
                            transferenciaAgregada = false;

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return transferenciaAgregada;

        }

        //Motitoreo de estatus de cuentas CLABE en STP
        //private DBManager db = null;
        public ResponseEstadoCuentaCLABE ActualizaEstatusCuenta(RequestEstadoCuentaCLABE request)
        {
            ResponseEstadoCuentaCLABE responseEstadoCuenta = new ResponseEstadoCuentaCLABE();

            //responseEstadoCuenta.estaus = 200;//Convert.ToInt32(db.DataReader["estatus"].ToString());
            //responseEstadoCuenta.mensaje = "OK";


            EstatusCuentaInterbancaria idEstatusCuenta;
            int estatusSTP;
            string mensajePersonalizado = "";

            if (request.estado.ToUpper() == "A")
            {
                idEstatusCuenta = EstatusCuentaInterbancaria.Cuenta_activa_en_STP;
                estatusSTP = 0;
                mensajePersonalizado = "Alta de cuenta exitosa";
            }
            else if(request.estado.ToUpper() == "B")
            {
                idEstatusCuenta = EstatusCuentaInterbancaria.Cuenta_cancelada_en_STP;
                estatusSTP = 0;
                mensajePersonalizado = "Baja de cuenta exitosa";
            }
            else
            {
                idEstatusCuenta = EstatusCuentaInterbancaria.Cuenta_no_procesada_por_STP;
                estatusSTP = -1;
                mensajePersonalizado = "Cuenta no procesada";
            }

            
            try
            {
                responseEstadoCuenta = new ResponseEstadoCuentaCLABE();
                using (db = new DBManager(ConexionAPI.ObtenerConexionSA()))
                {
                    db.Open();
                    db.CreateParameters(4);
                    db.AddParameters(0, "@estatusSTP", estatusSTP);
                    db.AddParameters(1, "@mensajeSTP", request.observaciones);
                    db.AddParameters(2, "@idEstatusCuenta", idEstatusCuenta);
                    db.AddParameters(3, "@cuenta", request.cuenta);

                    db.ExecuteReader(System.Data.CommandType.StoredProcedure, "SP_BANCA_ACTUALIZAR_ESTATUS_CUENTA_STP_SOCIO");
                    while (db.DataReader.Read())
                    {
                        if (Convert.ToInt32(db.DataReader["estatus"].ToString()) == 200)
                        {
                            responseEstadoCuenta.estaus = Convert.ToInt32(db.DataReader["estatus"].ToString());
                            responseEstadoCuenta.mensaje = mensajePersonalizado;                            
                        }
                        else
                        {
                            responseEstadoCuenta.estaus = Convert.ToInt32(db.DataReader["estatus"].ToString());
                            responseEstadoCuenta.mensaje = db.DataReader["error_message"].ToString();                            
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                /*ExceptionSendAbono exceptionSendAbono = new ExceptionSendAbono();
                exceptionSendAbono.Codigo = Convert.ToInt32(TipoDevolucion.Beneficiario_no_reconoce_el_pago);
                exceptionSendAbono.TipoDevolucion = TipoDevolucion.Beneficiario_no_reconoce_el_pago;
                exceptionSendAbono.Mensaje = db.DataReader["mensaje"].ToString();
                exceptionSendAbono.FolioRastreo = request.ClaveRastreo;
                throw new FaultException<ExceptionSendAbono>(exceptionSendAbono);*/
            throw ex;
            }

            return responseEstadoCuenta;

        }
    }
}
