﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades
{
    [DataContract]
    public enum TipoDevolucion
    {
        [EnumMember]
        Ninguno = 0,

        [EnumMember]
        Cuenta_inexistente = 1,

        [EnumMember]
        Cuenta_bloqueada = 2,

        [EnumMember]
        Cuenta_cancelada = 3,

        [EnumMember]
        Cuenta_en_otra_divisa = 5,

        [EnumMember]
        Cuenta_no_pertenece_al_banco_receptor = 6,
        [EnumMember]
        Cuenta_no_pertenece_al_participante_receptor = 6,

        [EnumMember]
        Beneficiario_no_reconoce_el_pago = 13,

        [EnumMember]
        Falta_información_mandatorio_para_completar_el_pago = 14,
        [EnumMember]
        Falta_información_mandatoria_para_completar_el_pago = 14,
        [EnumMember]
        Falta_informacion_mandatoria_para_completar_el_pago=14,

        [EnumMember]
        Tipo_de_pago_erroneo = 15,
        [EnumMember]
        Tipo_de_pago_erróneo = 15,

        [EnumMember]
        Tipo_de_operación_errónea = 16,
        [EnumMember]
        Tipo_de_operacion_erronea = 16,

        [EnumMember]
        Tipo_de_cuenta_no_corresponde = 17,

        [EnumMember]
        A_solicitud_del_emisor = 18,

        [EnumMember]
        Carácter_invalido = 19,
        [EnumMember]
        Caracter_invalido = 19,

        [EnumMember]
        Excede_el_límite_de_saldo_autorizado_de_la_cuenta = 20,
        [EnumMember]
        Excede_el_limite_de_saldo_autorizado_de_la_cuenta = 20,

        [EnumMember]
        Excede_el_límite_de_abonos_permitidos_en_el_mes_en_la_cuenta = 21,
        [EnumMember]
        Excede_el_limite_de_abonos_permitidos_en_el_mes_en_la_cuenta = 21,

        [EnumMember]
        Número_de_telefonia_movil_no_registrado = 22,
        [EnumMember]
        Numero_de_telefonia_movil_no_registrado = 22,
        [EnumMember]
        Número_de_línea_de_telefonía_móvil_no_registrado = 22,
        [EnumMember]
        Número_de_linea_de_telefonia_movil_no_registrado = 22,

        [EnumMember]
        Cuenta_adicional_no_recibe_pagos_que_no_proceden_de_Banxico = 23,


        [EnumMember]
        Estructura_de_la_Información_adicional_incorrecta = 24,
        [EnumMember]
        Estructura_de_la_Informacion_adicional_incorrecta = 24,

        [EnumMember]
        Falta_instrucción_para_dispersar_recursos_de_clientes_por_alcanzar_limite_al_saldo = 25,
        [EnumMember]
        Falta_instruccion_para_dispersar_recursos_de_clientes_por_alcanzar_limite_al_saldo = 25,

        [EnumMember]
        Resolución_resultante_del_Convenio_de_Colaboración_para_la_Protección_del_Cliente_Emisor = 26,
        [EnumMember]
        Resolucion_resultante_del_Convenio_de_Colaboracion_para_la_Proteccion_del_Cliente_Emisor = 26,

        [EnumMember]
        Pago_opcional_no_aceptado_por_el_Participante_Receptor = 27

    }

    [DataContract]
    public enum TipoPago
    {
        [EnumMember]
        Tercero_Tercero = 1

    }

    [DataContract]
    public enum TipoCuenta
    {
        [EnumMember]
        Tarjeta_de_Debito = 3,
        [EnumMember]
        Teléfono_celular = 10,
        [EnumMember]
        CLABE = 40
    }


    [DataContract]
    public enum TipoErrorRegistraOrden
    {
        [EnumMember]
        Otros = 0,
        [EnumMember]
        Rastreo_Duplicado = -1,
        [EnumMember]
        Orden_Duplicada = -2,
        [EnumMember]
        Dato_obligatorio_institucion_contraparte = -5,
        [EnumMember]
        Empresa_Invalida_O_Institucion_Operante_Invalida = -6,
        [EnumMember]
        Institucion_Invalida = -9,
        [EnumMember]
        Medio_Entrega_Invalido = -10,
        [EnumMember]
        Tipo_Operacion_Invalida = -12,
        [EnumMember]
        Tipo_Pago_Invalida = -13,
        [EnumMember]
        Fecha_Operacion_Invalida = -16,
        [EnumMember]
        Monto_Invalido = -20,
        [EnumMember]
        Digito_Verificador_Invalido = -21,
        [EnumMember]
        Institucion_No_Coincide_En_Clabe = -22,
        [EnumMember]
        Longitud_Clabe_Incorrecta = -23,
        [EnumMember]
        Longitud_Rastreo_Invalida = -26,
        [EnumMember]
        Valor_inválido_Se_aceptan_caracteres_a_z_A_Z_0_9 = -34,
    }

    [DataContract]
    public enum EstatusCuentaInterbancaria
    {
        [EnumMember]
        Cuenta_pendiente_por_registrar = 1,
        [EnumMember]
        Cuenta_activa_en_STP,
        [EnumMember]
        Cuenta_cancelada_en_Caja_Morelia_Valladolid,
        [EnumMember]
        Cuenta_cancelada_en_STP,
        [EnumMember]
        Cuenta_no_procesada_por_STP,
        [EnumMember]
        Cuenta_en_revision_STP,
    }

}
