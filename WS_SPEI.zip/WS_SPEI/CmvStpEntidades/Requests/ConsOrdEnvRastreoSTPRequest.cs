﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Requests
{
    public class ConsOrdEnvRastreoSTPRequest
    {
        public string claveRastreo { get; set; }
        //El formato de la fecha será AAAAMMDD
        public Int64 fechaOperacion { get; set; }
        public Int64 institucionOperante { get; set; }
        public string empresa { get; set; }
        public string firma { get; set; }
    }
}
