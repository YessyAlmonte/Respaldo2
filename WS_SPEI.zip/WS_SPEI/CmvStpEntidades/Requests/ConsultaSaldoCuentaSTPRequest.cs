﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Requests
{
    public class ConsultaSaldoCuentaSTPRequest
    {
        public string cuentaOrdenante { get; set; } = "";
        public string firma { get; set; } = "";

    }
}
