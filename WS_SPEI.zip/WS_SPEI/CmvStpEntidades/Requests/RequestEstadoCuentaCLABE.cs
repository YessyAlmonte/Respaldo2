﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Requests
{
    [DataContract]
    public class RequestEstadoCuentaCLABE
    {
        [DataMember(IsRequired = true)]
        public Int64 cuenta { get; set; }
        [DataMember(IsRequired = true)]
        public string empresa { get; set; }
        [DataMember(IsRequired = true)]
        public string estado { get; set; }
        [DataMember(IsRequired = true)]
        public string observaciones { get; set; }
    }
}
