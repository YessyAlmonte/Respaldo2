﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Requests
{
    [DataContract]
    public class RequestConsultaOrdenesFecha
    {
        [DataMember]
        public string estado { get; set; }

        [DataMember]
        public int fechaOperacion { get; set; } = 0;
    }
}
