﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Requests
{
    [DataContract]
    public class RequestCambiaEstado
    {
        /// <summary>
        /// Id asignado a la orden liquidada en STP.
        /// </summary>
        [DataMember(IsRequired = true)]
        public string Id { get; set; }
        /// <summary>
        /// Nombre de la empresa que está configurada en “STP”.
        /// </summary>
        [DataMember(IsRequired = true)]
        public string Empresa { get; set; }

        /// <summary>
        /// Un folio específico de la aplicación llamante que identifique a ésta orden de pago.
        /// Si no se incluye, por defecto se toma el valor de la clave de rastreo(si se incluye).
        /// </summary>
        [DataMember(IsRequired = true)]
        public string FolioOrigen { get; set; }

        /// <summary>
        ///  1 = Operacion exitosa
        ///  0 = Devolucion
        /// </summary>
        [DataMember(IsRequired = true)]
        public bool Estado { get; set; }

        [DataMember(IsRequired = true)]
        public string CausaDevolucion { get; set; }
    }
}
