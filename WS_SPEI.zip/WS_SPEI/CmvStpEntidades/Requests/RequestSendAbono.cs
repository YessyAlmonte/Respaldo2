﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Requests
{
    [DataContract]
    public class RequestSendAbono
    {
        [DataMember(IsRequired = true)]
        public string Id { get; set; }
        [DataMember(IsRequired = true)]
        public string FechaOperacion { get; set; }
        [DataMember(IsRequired = true)]
        public string InstitucionOrdenante { get; set; }
        [DataMember(IsRequired = true)]
        public string InstitucionBeneficiara { get; set; }
        [DataMember(IsRequired = true)]
        public string ClaveRastreo { get; set; }
        [DataMember(IsRequired = true)]
        public Decimal Monto { get; set; }
        [DataMember(IsRequired = true)]
        public string NombreOrdenante { get; set; }

        [DataMember(IsRequired = true)]
        public int TipoCuentaOrdenante { get; set; }

        [DataMember(IsRequired = true)]
        public string CuentaOrdenante { get; set; }
        [DataMember(IsRequired = true)]
        public string RfcCurpOrdenante { get; set; }
        [DataMember(IsRequired = true)]
        public string NombreBenificiario { get; set; }

        [DataMember(IsRequired = true)]
        public int TipoCuentaBeneficiario { get; set; }

        [DataMember(IsRequired = true)]
        public string CuentaBeneficiario { get; set; }
        [DataMember(IsRequired = true)]
        public string RfcCurpBeneficiario { get; set; }
        [DataMember(IsRequired = true)]
        public string ConceptoPago { get; set; }
        [DataMember(IsRequired = true)]
        public  Int64 RefereneciaNumerica { get; set; }
        [DataMember(IsRequired = true)]
        public string Empresa { get; set; }
    }
}
