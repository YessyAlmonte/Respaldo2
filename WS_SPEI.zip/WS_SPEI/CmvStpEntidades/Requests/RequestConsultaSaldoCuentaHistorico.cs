﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Requests
{
    [DataContract]
    public class RequestConsultaSaldoCuentaHistorico
    {
        [DataMember]
        public int fecha { get; set; } = 0;

        public string cuenta { get; set; } = "";
        public string firma { get; set; } = "";
    }
}
