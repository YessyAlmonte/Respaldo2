﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace CmvStpEntidades.Requests
{
    [DataContract]
    public class RequestConsultaOrdenRastreo
    {
        [DataMember]
        public string claveRastreo { get; set; }

        [DataMember]
        //El formato de la fecha será AAAAMMDD
        public Int64 fechaOperacion { get; set; }
    }
}
