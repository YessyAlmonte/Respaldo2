﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Exceptions
{
    [DataContract]
    public class ExceptionSendAbono
    {
        [DataMember]
        public int Codigo { get; set; }
        [DataMember]
        public String Mensaje { get; set; }
        [DataMember]
        public TipoDevolucion TipoDevolucion { get; set; }
        [DataMember]
        public string FolioRastreo { get; set; } 
    }
}
