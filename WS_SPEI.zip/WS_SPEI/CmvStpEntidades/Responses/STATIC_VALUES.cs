﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Responses
{
    public static class STATIC_VALUES
    {
        public static string OK_ExceptionMessage { get; set; } = "OK";
        public static string OK_descripcionError { get; set; } = "OK";
    }
}
