﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Responses
{
    [DataContract]
    public class ResponseSendAbono
    {
        [DataMember]
        public bool Estado { get; set; }

        [DataMember]
        public String mensaje { get; set; }
        [DataMember]
        public TipoDevolucion TipoDevolucion { get; set; }
        [DataMember]
        public string FolioRastreo { get; set; }
    }
}
