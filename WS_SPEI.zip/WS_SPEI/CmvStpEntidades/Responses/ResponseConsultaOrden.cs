﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace CmvStpEntidades.Responses
{
    [DataContract]
    public class ResponseConsultaOrden
    {
        [DataMember]
        public ConsultaOrdenObjects.ConsOrdEnvRastreoSTPResponse result { get; set; } = new ConsultaOrdenObjects.ConsOrdEnvRastreoSTPResponse();
    }
}
