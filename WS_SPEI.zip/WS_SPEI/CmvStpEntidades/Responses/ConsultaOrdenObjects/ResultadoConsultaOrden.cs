﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace CmvStpEntidades.Responses.ConsultaOrdenObjects
{
    [DataContract]
    public class ResultadoConsultaOrden
    {
        [DataMember]
        public int id { get; set; } = -1;
        [DataMember]
        public OrdenPago ordenPago { get; set; } = null;
    }
}
