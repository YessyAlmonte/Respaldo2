﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace CmvStpEntidades.Responses.ConsultaOrdenObjects
{
    [DataContract]
    public class OrdenPago
    {
        [DataMember]
        public int causaDevolucion { get; set; }
        [DataMember]
        public string clavePago { get; set; }
        [DataMember]
        public string claveRastreo { get; set; }
        [DataMember]
        public string claveRastreoDevolucion { get; set; }
        [DataMember]
        public string conceptoPago { get; set; }
        [DataMember]
        public string conceptoPago2 { get; set; }
        [DataMember]
        public string cuentaBeneficiario { get; set; }
        [DataMember]
        public string cuentaBeneficiario2 { get; set; }
        [DataMember]
        public string cuentaOrdenante { get; set; }
        [DataMember]
        public string empresa { get; set; }
        [DataMember]
        public string estado { get; set; }
        [DataMember]
        public Int64 fechaOperacion { get; set; }
        [DataMember]
        public string folioOrigen { get; set; }
        [DataMember]
        public string idCliente { get; set; }
        [DataMember]
        public int idEF { get; set; }
        [DataMember]
        public Int64 institucionContraparte { get; set; }
        [DataMember]
        public Int64 institucionOperante { get; set; }
        [DataMember]
        public Int64 medioEntrega { get; set; }
        [DataMember]
        public Double monto { get; set; }
        [DataMember]
        public string nombreBeneficiario { get; set; }
        [DataMember]
        public string nombreBeneficiario2 { get; set; }
        [DataMember]
        public string nombreOrdenante { get; set; }
        [DataMember]
        public Int32 prioridad { get; set; }
        [DataMember]
        public string referenciaCobranza { get; set; }
        [DataMember]
        public Int64 referenciaNumerica { get; set; }
        [DataMember]
        public string rfcCurpBeneficiari { get; set; }
        [DataMember]
        public string rfcCurpBeneficiario2 { get; set; }
        [DataMember]
        public string rfcCurpOrdenante { get; set; }
        [DataMember]
        public Int64 tipoCuentaBeneficiario { get; set; }
        [DataMember]
        public Int64 tipoCuentaOrdenante { get; set; }
        [DataMember]
        public Int64 tipoPago { get; set; }
        [DataMember]
        public string topologia { get; set; }
        [DataMember]
        public Int64 tsAcuseBanxico { get; set; }
        [DataMember]
        public Int64 tsCaptura { get; set; }
        [DataMember]
        public Int64 tsDevolucion { get; set; }
        [DataMember]
        public Int64 tsDevolucionRecibida { get; set; }
        [DataMember]
        public Int64 tsEntrega { get; set; }
        [DataMember]
        public Int64 tsLiquidacion { get; set; }
        [DataMember]
        public string usuario { get; set; }

    }
}
