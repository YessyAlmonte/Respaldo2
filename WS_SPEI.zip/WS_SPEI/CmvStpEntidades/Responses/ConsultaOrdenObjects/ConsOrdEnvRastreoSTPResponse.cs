﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace CmvStpEntidades.Responses.ConsultaOrdenObjects
{
    [DataContract]
    public class ConsOrdEnvRastreoSTPResponse
    {
        [DataMember]
        public ResultadoConsultaOrden resultado { get; set; } = new ResultadoConsultaOrden();
    }
}
