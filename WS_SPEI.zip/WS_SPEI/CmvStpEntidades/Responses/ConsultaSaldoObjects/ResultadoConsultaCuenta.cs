﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Responses.ConsultaSaldoObjects
{
    [DataContract]
    public class ResultadoConsultaCuenta
    {
        [DataMember]
        public int id { get; set; } = -1;
        [DataMember]
        public SaldoCuenta saldoCuenta { get; set; } = new SaldoCuenta();
        [DataMember]
        public string descripcionError { get; set; } = STATIC_VALUES.OK_descripcionError;
    }
}
