﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Responses.ConsultaSaldoObjects
{
    [DataContract]
    public class SaldoCuenta
    {
        [DataMember]
        public double cargosPendientes { get; set; } = 0.0;
        [DataMember]
        public double saldo { get; set; } = 0.0;

    }
}
