﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Responses
{
   [DataContract]
   public class ResponseCambiaEstado
    {
        [DataMember]
        public bool Estatus { get; set; }
        [DataMember]
        public string Mensaje { get; set; }
        [DataMember]
        public string FolioRastreo { get; set; }
    }
}
