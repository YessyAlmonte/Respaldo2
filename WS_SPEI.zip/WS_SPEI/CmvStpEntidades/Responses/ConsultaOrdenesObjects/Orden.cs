﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Responses.ConsultaOrdenesObjects
{
    [DataContract]
    public class Orden
    {
        [DataMember]
        public string clavePago { get; set; }
        [DataMember]
        public string claveRastreo { get; set; }
        [DataMember]
        public string conceptoPago { get; set; }
        [DataMember]
        public string conceptoPago2 { get; set; }
        [DataMember]
        public string cuentaBeneficiario { get; set; }
        [DataMember]
        public string cuentaBeneficiario2 { get; set; }
        [DataMember]
        public string cuentaOrdenante { get; set; }
        [DataMember]
        public string empresa { get; set; }
        [DataMember]
        public string estado { get; set; }
        [DataMember]
        public Int32 fechaOperacion { get; set; } = 0;
        [DataMember]
        public Int32 institucionContraparte { get; set; } = 0;
        [DataMember]
        public Int32 institucionOperante { get; set; } = 0;
        [DataMember]
        public Int32 medioEntrega { get; set; } = 0;
        [DataMember] 
        public Double monto { get; set; } = 0;
        [DataMember]
        public string nombreBeneficiario { get; set; }
        [DataMember]
        public string nombreBeneficiario2 { get; set; }
        [DataMember]
        public string nombreOrdenante { get; set; }
        [DataMember]
        public int prioridad { get; set; } = 0;
        [DataMember]
        public string referenciaCobranza { get; set; }
        [DataMember]
        public Int32 referenciaNumerica { get; set; } = 0;
        [DataMember]
        public string rfcCurpBeneficiario { get; set; }
        [DataMember]
        public string rfcCurpBeneficiario2 { get; set; }
        [DataMember]
        public string rfcCurpOrdenante { get; set; }
        [DataMember]
        public Int32 tipoCuentaBeneficiario { get; set; } = 0;
        [DataMember]
        public Int32 tipoCuentaOrdenante { get; set; } = 0;
        [DataMember]
        public Int32 tipoPago { get; set; } = 0;
        [DataMember]
        public string topologia { get; set; }
        [DataMember]
        public Int64 tsAcuseBanxico { get; set; } = 0;
        [DataMember]
        public Int64 tsCaptura { get; set; } = 0;
        [DataMember]
        public Int32 tsEntrega { get; set; } = 0;
        [DataMember]
        public Int64 tsLiquidacion { get; set; } = 0;
        [DataMember]
        public string usuario { get; set; }



        [DataMember]
        public Int32 causaDevolucion { get; set; } = 0;
        [DataMember]
        public string claveRastreoDevolucion { get; set; }
        [DataMember]
        public Int64 tsDevolucion { get; set; } = 0;
        [DataMember]
        public Int64 tsDevolucionRecibida { get; set; } = 0;
    }
}
