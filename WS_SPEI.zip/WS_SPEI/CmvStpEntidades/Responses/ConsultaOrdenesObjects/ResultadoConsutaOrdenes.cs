﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CmvStpEntidades.Responses.ConsultaOrdenesObjects
{
    [DataContract]
    public class ResultadoConsutaOrdenes
    {
        [DataMember]
        public int id { get; set; } = 0;
        [DataMember]
        List<Orden> lst { get; set; } = null;

        [DataMember]
        public string descripcionError { get; set; }
    }
}
